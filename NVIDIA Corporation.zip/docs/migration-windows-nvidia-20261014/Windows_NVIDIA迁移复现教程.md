# 在另一台 Windows + NVIDIA 电脑上迁移复现 DefectResearcher + LabelGuard

编写日期：2026年10月14日。目标系统由用户确认：Windows、有NVIDIA显卡。教程以64位Windows、x64 Python/Node为基础；GPU型号是否受当前PyTorch支持，需要在目标机检查。

当前源码没有“迁移所有功能后自动验收”的一键安装器。本教程分层迁移：先CPU固定案例，再正式数据工具，再GPU对照，最后AGH/MCP。诊断与受限研究流程还需要原始历史证据。正在研发且未通过的功能，迁移后仍不能标为已完成。

本次在原电脑已核实：Python3.12.13、Torch2.5.1+cu124、Torchvision0.20.1+cu124、Ultralytics8.4.155、PyYAML6.0.3、CUDA可用、RTX4050 Laptop；`pip check`通过。本文没有在另一台电脑执行，目标机必须按验收标准保存新的结果。

## 1. 先确定迁移范围

| 层级 | 可以复现的功能 | 需要带走的内容 |
| --- | --- | --- |
| A：CPU固定案例 | 4正常、4实际修复、4拒绝、30几何参考和保存任务检查 | 已验收CPU ZIP；Python>=3.10；不需GPU/Key |
| B：正式数据工具 | 数据审计、独立几何、可信标签副本修复 | 项目源码、研究checker/geometry、原始COCO、图片、转换数据、划分、权重及对应清单 |
| C：GPU固定对照 | 同权重完整验证集640/960实际推理 | B全部内容、原训练清单与权重、匹配的视觉环境、兼容显卡/驱动 |
| D：诊断与受限报告 | 读取固定历史预测，诊断及CPU证据报告 | B/C所需来源，加完整上游任务与冻结证据；路径和hash一致 |
| E：Agnes网页/MCP | 新模型会话调用数据工具或受限CPU工作流 | 可运行AGH、Node、目标机新Provider配置、MCP注册/信任/启用、实际工具审批 |

没有GPU时仍可做A/B及部分D。迁移本身不包含自动训练；使用现有`best.pt`即可。

## 2. 首选方案：保留原来的绝对目录布局

要复现B–E，目标机优先使用真实的E盘目录：

```text
E:\PythonProject\AGH_\
  defect_researcher\
    defect_researcher\
    tools\
    fixtures\
    config\
    docs\
    outputs\
    run.py
    run_agh.py
    run_research_mcp_v2.py
  agnes-harness\

E:\PythonProject\projects\cableinspect-ad-code\project_start\
  cableinspect_geometry.py
  数据处理\7检查YOLO标注数据.py
  dataset\CableInspect_YOLO\
  splits_anomaly_grouped\
  runs\baseline\yolo11n_640\

E:\Datasets\线缆\CableInspect-AD\
E:\Anaconda_envs\envs\MMIOC_env\
```

前三条数据/源码路径尤其重要。当前split文本逐行保存`E:\Datasets\...`绝对路径；`data.yaml`和`experiment_manifest.json`绑定原数据路径与hash；历史预测、产物清单和源码锁也包含绝对路径。

因此，改变盘符或数据根目录后，仅修改`config/local.json`不能保证compare、diagnose或历史工作流可运行。不要批量替换封存JSON、重写完成标记或为了通过而更新历史hash。重定向/目录联接也不是通用解决办法，部分来源检查明确拒绝链接。

目标机没有E盘时，A层CPU包可直接放任意目录。B–E若改为D盘等新布局，属于新的来源迁移：需保留旧证据，另建迁移映射、划分/数据/权重绑定及新验收。当前没有已验收的通用重绑定工具，所以本文的完整复现命令以同路径布局为前提；不要把改路径后的失败称作环境已通过。

## 3. 在原电脑准备文件

### 3.1 CPU最小包

直接复制现有文件，不必重新构建：

```text
E:\PythonProject\AGH_\defect_researcher\outputs\submission-bundle-v1-r1-exclusive\DefectResearcher-CPU-v1.zip
```

当前大小92,006字节，SHA256：

```text
7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61
```

还可以复制整个`delivery\labelguard-contest-candidate-20261014-v1`，其中包含CPU源码、验证脚本、说明和脱敏历史会话。

### 3.2 正式数据工具的必要文件

| 来源 | 必须保留的内容 |
| --- | --- |
| 本项目 | 内层`defect_researcher/`、`tools/`、`fixtures/`、`config/local.json`、`config/example.json`、根目录Python入口、`pyproject.toml`；演示另需对应ZIP和build_receipt |
| 原研究项目 | `cableinspect_geometry.py`、`数据处理/7检查YOLO标注数据.py`及许可/来源材料 |
| 转换数据 | `dataset/CableInspect_YOLO`整目录：所有images、labels、metadata、`data.yaml`、`manifest.json` |
| 原始数据 | `CableInspect-AD`根下`cable_1.json`、`cable_2.json`、`cable_3.json`及对应全部图片；保持实际大小写和层级 |
| 数据划分 | `splits_anomaly_grouped`整目录：train、val、test、excluded_buffer文本 |
| 检测基线 | `runs/baseline/yolo11n_640/experiment_manifest.json`及`weights/best.pt`；保留整个该基线目录最方便 |
| 教程附件 | 本目录的`source-reference.json`与`constraints-source-python312.txt` |

权重不能只带一个孤立的best.pt：compare还会检查相邻训练清单、训练尺寸、数据清单、划分和权重hash。当前权重SHA256为：

```text
57d430496f764593b49547897161fbafa93afaca83cc9942a3cc8c2e282d0d75
```

不复制旧`.runtime/agh`、Provider密钥、个人账户/秘密存储或整个旧Conda环境。目标机重新建环境和账号配置。

### 3.3 诊断及研究报告的额外证据

最省排查的方式是，在个人迁移中保留研发`outputs`内需要的历史任务、源码归档和冻结清单，排除私有账户/临时运行目录。若做精简复制，至少核对下列来源：

| 目录/文件 | 用途 |
| --- | --- |
| `outputs/8d1d6900c7d74c90a29824495684807d/`整目录 | diagnose和尺度复算固定的640/960上游任务；包括其嵌套几何闸门 |
| `outputs/plan-alignment-review-20261012/` | 冻结尺度附录 |
| `outputs/diagnosis-d35fab352e614cf7a3bf4c9236987cf8/` | 受限报告固定诊断来源 |
| `outputs/1c68e87faed946d490a5ad802186146a/` | 切片保存科学证据与独立核验 |
| `outputs/09c5ce4aceb7426e87af5334bdb03eb4/` | 原失败计算记录；完成标记必须继续缺失 |
| `outputs/research-workflow-implementation-v1/` | 工作流冻结与源码归档 |
| `outputs/research-mcp-implementation-v2/` | V2 MCP源码锁及归档 |
| `outputs/agh-research-workflow-model-v1/server-config.json`及其必要workspace目录 | 既有受限MCP配置/输出位置 |

这个表是关键入口索引，不是历史闭包的完整文件白名单。尤其V2 MCP还会逐一核对freeze的25 sources、25 archive与968 preserved_files。精简包必须把其中引用的文件逐项带走；只带freeze.json本身不足。

可以在原机查看实际清单与所需总字节数，而不复制文件：

```powershell
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
$migFreeze = Get-Content 'outputs/research-workflow-implementation-v1/freeze.json' -Raw -Encoding utf8 | ConvertFrom-Json
$migFrozenRows = @($migFreeze.sources) + @($migFreeze.archive) + @($migFreeze.preserved_files)
$migFrozenRows | Select-Object path,size_bytes,sha256
$migFrozenRows | Measure-Object -Property size_bytes -Sum
```

保存历史证据时保留字节和文件时间。复制目录可使用下面这种非镜像模式；将示例替换为所需任务目录，目标为空目录：

```powershell
robocopy '原电脑任务目录' '移动硬盘上的新备份目录' /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ
if ($LASTEXITCODE -ge 8) { throw '复制存在失败，请检查日志。' }
```

robocopy的0–7返回值不是统一失败码；8及以上需要处理。不要使用/MIR或/PURGE。从备份恢复到目标E盘后，再逐项核对hash。

### 3.4 AGH运行时

复现当前本地修改版，需完整复制：

```text
E:\PythonProject\AGH_\defect_researcher\outputs\agh-title-repair-v2\
```

其中实际入口为：

```text
runtime\packages\cli\dist\local\agnes.mjs
```

必须连同daemon、worker、Web、bundled-plugins、运行时node_modules和原生agnes-system.node一起带走。只复制agnes.mjs，或删除运行时node_modules，会破坏运行目录。

原机的`start_web.ps1`还会核对`repair_verification.json`引用的AGH源文件；若想使用这个原脚本，需连同这些源文件、Node/Python固定路径全部满足。本文改用显式`run_agh.py --entry`启动，避免依赖旧脚本的本机安装位置。

全量AGH源码可另外复制，或保留当前checkout快照与锁文件。最新GitHub主线不等于当前冻结版本，重新构建也未必包含并列bundle中的本地标题修复。

## 4. 目标机先完成CPU验证

安装64位Python>=3.10；只做CPU验证时可以使用目标机现有合适的Python，不需要Conda或视觉包。下载入口见[Python官方Windows页面](https://www.python.org/downloads/windows/)。

假定CPU ZIP放在`D:\DefectResearcher-migration`：

```powershell
Set-Location 'D:\DefectResearcher-migration'
$migZip = 'D:\DefectResearcher-migration\DefectResearcher-CPU-v1.zip'
$migExpectedZipHash = '7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61'
if ((Get-FileHash -LiteralPath $migZip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $migExpectedZipHash) {
    throw 'CPU包hash不匹配。'
}
Expand-Archive -LiteralPath $migZip -DestinationPath 'D:\DefectResearcher-migration\cpu-extracted'
Set-Location 'D:\DefectResearcher-migration\cpu-extracted\DefectResearcher-CPU-v1'
$migCpuEvidence = 'D:\DefectResearcher-migration\cpu-evidence-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
python -I -S -B tools/migration_smoke_v1.py --output $migCpuEvidence
if ($LASTEXITCODE -ne 0) { throw "CPU验证失败，查看 $migCpuEvidence" }
$migCpuResult = Get-Content (Join-Path $migCpuEvidence 'migration_acceptance.json') -Raw -Encoding utf8 | ConvertFrom-Json
$migCpuResult | Select-Object status,groups,geometry_counts,errors | ConvertTo-Json -Depth 6
```

解压位置和证据位置都应是新目录；不要覆盖旧结果。不要在不可变CPU包内部安装环境、添加教程或写结果，因为包会核对完整文件成员和hash。

验收：命令exit0且`migration_acceptance.json.status=passed`，12例分别满足冻结答案，4实际修复、非预期修改0、30几何参考通过，保存任务与隔离检查通过。目标机的新回执才是跨机CPU复现证据。

## 5. 目标机安装正式研究环境

### 5.1 创建Python环境

使用Miniconda或Anaconda的终端。为保持当前命名和可能的来源路径，优先创建：

```powershell
conda create --prefix 'E:\Anaconda_envs\envs\MMIOC_env' python=3.12.13 pip -y
conda activate 'E:\Anaconda_envs\envs\MMIOC_env'
python --version
python -c "import sys; print(sys.executable)"
```

若当前Conda channel找不到精确3.12.13，先保留该安装错误；可以选择可用的3.12版本做功能迁移，但必须记录版本差异，不能称环境精确相同。不直接搬运原Conda目录。

### 5.2 NVIDIA驱动与PyTorch

先安装适用于目标显卡的NVIDIA驱动，并在新终端执行：

```powershell
nvidia-smi
```

能显示显卡和驱动后，再安装原版本PyTorch。官方旧版本页面提供Windows的CUDA12.4安装组合：[PyTorch 2.5.1官方安装说明](https://pytorch.org/get-started/previous-versions/#v251)。

```powershell
python -m pip install torch==2.5.1 torchvision==0.20.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cu124
```

这里使用wheel包含的CUDA运行组件。`nvidia-smi`显示的CUDA版本不是Python中torch.version.cuda的同义字段；以实际PyTorch检查为准。驱动要求参考[NVIDIA兼容性文档](https://docs.nvidia.com/deploy/cuda-compatibility/minor-version-compatibility.html)。

目标显卡架构必须受该旧Torch wheel支持；有NVIDIA显卡不自动代表兼容。若报`no kernel image`或明确提示架构不受支持，先不要运行正式对照。换用支持的硬件，或另建受支持的新Torch环境并登记新版本验证；不能偷偷升级后称原环境复现。

### 5.3 安装视觉依赖并约束版本

回到迁移后的项目目录：

```powershell
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
$migConstraints = 'docs/migration-windows-nvidia-20261014/constraints-source-python312.txt'
python -m pip install ultralytics==8.4.155 PyYAML==6.0.3 -c $migConstraints
python -m pip check
```

附带constraints由原机44个已安装distribution版本生成，用于限制依赖解析，文件不含账号或包下载凭据。它不是带wheel/hash的离线锁包，也不保证其他机器能下载到所有精确版本。它不会安装其中未被此次依赖图要求的包。需要完整复制版本集合时，应另下载匹配Windows x64/Python3.12的wheel及hash，而不绕过冲突。

若出现找不到版本/解析冲突，保留具体包名和报错，停止该层验收。不要直接去掉约束升级全部包。Ultralytics版本页面见[8.4.155](https://pypi.org/project/ultralytics/8.4.155/)。

验证依赖、GPU和最小CUDA算子：

```powershell
python -X utf8 -B -c "import torch,ultralytics,yaml; print('torch=',torch.__version__,'torchvision environment CUDA=',torch.version.cuda,'ultralytics=',ultralytics.__version__,'yaml=',yaml.__version__); assert torch.cuda.is_available(), 'CUDA unavailable'; print(torch.cuda.get_device_name(0)); a=torch.ones(1,device='cuda'); print(a.cpu().item())"
```

这只是环境与CUDA算子检查，不是检测或科学实验验收。后续compare固定使用CUDA0；多GPU机器注意设备0的实际显卡。

## 6. 配置、文件指纹与正式数据验收

### 6.1 同路径方案保留原local.json

同布局情况下直接保留原字节，不需要把相对路径配置重写成绝对路径。执行：

```powershell
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
python -X utf8 -B run.py paths
```

如需另建配置，六字段是research_root、dataset_root、raw_root、split_dir、weights_path、output_root，schema_version为1。`output_root`必须与受保护输入隔离；正式修复用硬链接复制图片，数据图片和新副本最好处于同一NTFS卷。改动配置可能与既有来源锁或历史任务配置冲突，不能直接沿用旧严格验收。

### 6.2 核对本教程19个关键文件

教程附件`source-reference.json`记录原机版本及19个锚点文件hash。可以在同路径目标机做只读核对：

```powershell
$migReference = Get-Content 'docs/migration-windows-nvidia-20261014/source-reference.json' -Raw -Encoding utf8 | ConvertFrom-Json
$migAnchorChecks = foreach ($migRow in $migReference.files) {
    $migPresent = Test-Path -LiteralPath $migRow.path -PathType Leaf
    $migSame = $false
    if ($migPresent) {
        $migSame = ((Get-Item -LiteralPath $migRow.path).Length -eq $migRow.size_bytes) -and
            ((Get-FileHash -LiteralPath $migRow.path -Algorithm SHA256).Hash.ToLowerInvariant() -eq $migRow.sha256)
    }
    [pscustomobject]@{path=$migRow.path;exists=$migPresent;matches=$migSame}
}
$migAnchorChecks | Format-Table -AutoSize
if (@($migAnchorChecks | Where-Object { -not $_.matches }).Count -gt 0) {
    throw '关键输入存在缺失或字节差异。'
}
```

这是关键锚点检查，不覆盖所有图片、标签、源码或运行时；随后仍要跑业务工具。原始/转换图片都要传，不能只通过19个hash就宣布全数据迁移成功。

### 6.3 保存本机新验收

```powershell
$migStamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$migEvidenceRoot = Join-Path (Get-Location).Path ('outputs/migration-verification-' + $migStamp)
New-Item -ItemType Directory -Path $migEvidenceRoot | Out-Null

python -X utf8 -B run.py audit | Tee-Object -FilePath (Join-Path $migEvidenceRoot 'audit-cli.json')
if ($LASTEXITCODE -ne 0) { throw '数据审计失败。' }

python -X utf8 -B run.py verify | Tee-Object -FilePath (Join-Path $migEvidenceRoot 'verify-cli.json')
if ($LASTEXITCODE -ne 0) { throw '独立几何验证失败。' }

python -X utf8 -B run.py repair | Tee-Object -FilePath (Join-Path $migEvidenceRoot 'repair-cli.json')
if ($LASTEXITCODE -ne 0) { throw '修复未产生合格副本，请查看是refused还是执行/复验失败。' }
```

首次目标机还可重新跑固定人工案例：

```powershell
python -X utf8 -B tools/run_labelguard_acceptance.py
```

接受条件：audit合格；verify的`status=completed`且`summary.verification_status=passed`；repair的`repair_status=passed`且独立`verification_status=passed`。正常数据0修改是预期正常副本，不计生产修复成功率。`refused`是有效拒绝记录，但不是可使用的修复副本，CLI会返回非零。

本机原记录4479图/3864框可作为人数/范围核对参考；以目标机新任务的完整结果为准。

## 7. 目标机执行新的640/960对照

只有第5/6步通过后执行：

```powershell
python -X utf8 -B run.py compare | Tee-Object -FilePath (Join-Path $migEvidenceRoot 'compare-cli.json')
if ($LASTEXITCODE -ne 0) { throw '受控对照失败，保留失败目录。' }
$migCompareResult = Get-Content (Join-Path $migEvidenceRoot 'compare-cli.json') -Raw -Encoding utf8 | ConvertFrom-Json
$migCompareResult | Select-Object task_id,status,summary | ConvertTo-Json -Depth 8
```

它会实际推理完整640张验证图，两次评估使用同一个640训练权重、FP32、batch1、640/960尺寸。不会重训、使用测试集或自动改为CPU。结果写入新的任务目录。

用现有复核入口检查新任务；其计分复算复用`detection_metrics`，不把它称为第二套独立AP实现：

```powershell
python -X utf8 -B tools/verify_resolution_run.py $migCompareResult.task_id --config 'config/local.json' --output (Join-Path $migEvidenceRoot 'compare-crosscheck.json')
if ($LASTEXITCODE -ne 0) { throw '新对照产物复核失败。' }
```

接受条件是执行及产物核验通过、数据/权重/协议正确、原输入未变。不同GPU、驱动或依赖可能导致数值和耗时差异，必须记录并比较，不能预填历史41.07%/36.52%或承诺逐字节相同。

## 8. 诊断与本地受限研究报告

### 8.1 复现固定历史诊断

```powershell
python -X utf8 -B run.py diagnose | Tee-Object -FilePath (Join-Path $migEvidenceRoot 'diagnose-cli.json')
if ($LASTEXITCODE -ne 0) { throw '固定历史诊断失败，检查上游闭包/来源。' }
$migDiagnosis = Get-Content (Join-Path $migEvidenceRoot 'diagnose-cli.json') -Raw -Encoding utf8 | ConvertFrom-Json
python -X utf8 -B tools/verify_diagnosis_run.py $migDiagnosis.task_id --config 'config/local.json' --output (Join-Path $migEvidenceRoot 'diagnosis-crosscheck.json')
if ($LASTEXITCODE -ne 0) { throw '诊断独立复核失败。' }
```

诊断源码严格固定源ID`8d1d6900c7d74c90a29824495684807d`，重新compare生成的新ID不会自动被使用。只传原预测而遗漏原manifest、completion、嵌套geometry或源输入，会被拒绝。

### 8.2 新ID运行受限CPU报告

确认第3.3节封存科学证据齐全，再执行：

```powershell
$migRequest = Get-Content 'config/research-workflow-v1.example.json' -Raw -Encoding utf8 | ConvertFrom-Json
$migRequest.request_id = 'migration-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
$migRequest.case_id = 'repair_coordinates'
$migRequestPath = Join-Path $migEvidenceRoot 'workflow-request.json'
$migRequest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $migRequestPath -Encoding utf8
python -X utf8 -B -m defect_researcher.research_workflow_v1 --request $migRequestPath
if ($LASTEXITCODE -ne 0) { throw '本地受限工作流失败。' }
```

查看`outputs/research-workflow-v1-<request_id>/report.md`和独立核验。它处理固定人工案例并读取历史验证资料，不运行新检测或模型。不要复用旧request_id，不能拿已经完成的旧任务作为目标机新验收。

## 9. 迁移AGH网页

### 9.1 保留当前修改版运行目录

这是接近原机运行版本的优先路径。安装[Node.js 24.15.0 Windows x64](https://nodejs.org/download/release/v24.15.0/)，完整保留第3.4节目录。

```powershell
node --version
node -p "process.arch"
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
$migPython = (python -c "import sys; print(sys.executable)").Trim()
$migNode = (Get-Command node.exe).Source
$migAghEntry = 'E:\PythonProject\AGH_\defect_researcher\outputs\agh-title-repair-v2\runtime\packages\cli\dist\local\agnes.mjs'
& $migNode $migAghEntry --help
python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry serve
```

终端保持运行，打开`http://127.0.0.1:4177/`，以实际启动输出端口为准。此命令在目标项目创建新的隔离`.runtime/agh`，不要求复制旧账号库。

原`start_web.ps1`写死`E:\Anaconda_envs\envs\MMIOC_env\python.exe`与`E:\nodejs24.15.0\node.exe`，并核对原修改版来源。目标机安装路径不同时直接用上面的显式入口；不要为了方便改封存清单。

运行时缺少VC DLL时安装[Microsoft官方x64 Visual C++运行库](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170)。若原生模块报ABI/架构错误，需要匹配Node/平台或重新构建，再做目标机验收。

### 9.2 可选：从当前源码快照重新构建

若不使用原机完整运行目录，安装Node>=24.10、pnpm10.34.5、Visual Studio C++ Build Tools和Windows SDK。VS安装参考[Microsoft C++工具安装说明](https://learn.microsoft.com/en-us/cpp/build/vscpp-step-0-installation?view=msvc-170)。

```powershell
Set-Location 'E:\PythonProject\AGH_\agnes-harness'
npm.cmd install --global pnpm@10.34.5
pnpm.cmd --version
pnpm.cmd install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { throw 'AGH依赖安装失败。' }

. .\.github\scripts\prepare-windows-native.ps1 -CacheRoot "$env:LOCALAPPDATA\node-gyp\Cache"
pnpm.cmd --filter @agnes/cli build:local
if ($LASTEXITCODE -ne 0) { throw 'AGH构建失败。' }
node .\packages\cli\dist\local\agnes.mjs --help
```

这里dot-source headers脚本，使其设置的环境变量在当前PowerShell中保留。不要覆盖正在使用的运行目录；已有实例先按官方daemon stop结束。

再从项目目录用`run_agh.py --entry`指向新构建的`E:\PythonProject\AGH_\agnes-harness\packages\cli\dist\local\agnes.mjs`。此构建是新的运行来源，不能自动称为原并列修复版；标题用量与严格模型验收需要重新核实。

### 9.3 目标机设置Provider

在网页Provider设置中选择Agnes，填自己的Base URL/Key，测试连接，选择账号实际返回的模型并保存。历史使用过`agnes-3.0-flash`，但目标账号的可用模型以当前目录为准。Key只填设置页，不写到项目JSON或迁移教程。

新电脑没有复制旧`.runtime`时，原会话URL不会自动出现。查看历史证据使用官方脱敏HTML/JSONL；新电脑的执行验证必须新建会话并保存新导出。模型服务的在线输出不能保证逐字相同。

## 10. 在目标机重新注册基础MCP

保留serve终端，打开另一个PowerShell并激活环境。每次新终端重新声明变量；CLI和网页必须使用同一显式入口/项目home：

```powershell
conda activate 'E:\Anaconda_envs\envs\MMIOC_env'
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
$migPython = (python -c "import sys; print(sys.executable)").Trim()
$migNode = (Get-Command node.exe).Source
$migAghEntry = 'E:\PythonProject\AGH_\defect_researcher\outputs\agh-title-repair-v2\runtime\packages\cli\dist\local\agnes.mjs'

python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp add dr-basic --name 'DefectResearcher basic tools' --stdio $migPython --arg -B --arg 'E:\PythonProject\AGH_\defect_researcher\run.py' --arg --config --arg 'E:\PythonProject\AGH_\defect_researcher\config\local.json' --arg mcp --allow-tool audit_dataset --allow-tool verify_label_geometry --allow-tool repair_label_copy --allow-tool compare_validation_resolutions --allow-tool diagnose_validation_errors --allow-tool compare_validation_slices --allow-tool get_task_status
```

只在目标机没有此服务时add；已存在时先get，不要重复注册。这里用短ID`dr-basic`，降低qualified工具名称过长的风险。

依次读取最新revision、信任、再次读取、启用：

```powershell
python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp get dr-basic
$migRevision = Read-Host '粘贴刚显示的当前revision'
python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp trust dr-basic --expected-revision $migRevision
if ($LASTEXITCODE -ne 0) { throw 'MCP信任失败。' }

python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp get dr-basic
$migRevision = Read-Host '粘贴此次get显示的最新revision'
python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp enable dr-basic --expected-revision $migRevision
if ($LASTEXITCODE -ne 0) { throw 'MCP启用失败。' }

python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp status dr-basic
python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp tools dr-basic
```

ready及七工具目录只证明连接和目录可用。网页新建任务，先让模型调用audit_dataset，再用相同task_id查询get_task_status；及时点击实际Allow once。核对终态、业务summary及证据，再分别验收几何与修复。

可以使用这个首次提示：

> 调用audit_dataset审计当前配置的数据。取得task_id后只用get_task_status查询同一任务直到终态，报告执行状态、发现和证据位置。不要启动检测、切片或训练。

切片工具虽保留目录，但固定候选已停止，原计算失败。迁移验证不需要重跑这个已停止候选。

## 11. 可选：迁移受限CPU工作流MCP

只在历史闭包、25+25+968冻结文件及本地报告流程通过后使用。保留原`source_lock-model.json`和原server-config的字节，同E盘布局：

```powershell
$migWorkflowLock = 'E:\PythonProject\AGH_\defect_researcher\outputs\research-mcp-implementation-v2\source_lock-model.json'
$migWorkflowLockHash = '2555fa18ec8ea33bee5744679b7d42b62725d990b8e87bda3a9fa88c5705fbb6'
if ((Get-FileHash -LiteralPath $migWorkflowLock -Algorithm SHA256).Hash.ToLowerInvariant() -ne $migWorkflowLockHash) {
    throw '工作流来源锁不同。'
}

python -X utf8 -B run_agh.py --node $migNode --entry $migAghEntry mcp add dr-workflow --name 'Bounded CPU research workflow V2' --stdio $migPython --arg -B --arg 'E:\PythonProject\AGH_\defect_researcher\run_research_mcp_v2.py' --arg --config --arg 'E:\PythonProject\AGH_\defect_researcher\outputs\agh-research-workflow-model-v1\server-config.json' --arg --source-lock --arg $migWorkflowLock --arg --expected-lock-sha256 --arg $migWorkflowLockHash --allow-tool run_bounded_research_workflow_v1 --allow-tool get_research_workflow_status_v1
```

再按第10节的get/trust/get/enable/status/tools流程，服务ID改为dr-workflow。每个请求使用新request_id，启动参数是case_id和冻结CPU budget，不传文件路径。

上述过程验证功能连接，不自动迁移原专用scope插件、原session ID或预算账本，也不等于旧23项严格模型验收在新电脑再次通过。若要同等受限模型验收，需新部署身份、专用工作区、scope/来源绑定、模型账本、审批与独立会话复核；不能复用原已消耗的任务期限。

## 12. 可选：迁移CPU网页面板

把研发`tools/local_demo_v1.py`、`tools/demo_evidence_v1.html`及已验收ZIP/build_receipt按原项目相对位置保留：

```powershell
Set-Location 'E:\PythonProject\AGH_\defect_researcher'
$migDemoOutput = 'outputs/actual-demo-v1-migration-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff')
python -X utf8 -B tools/local_demo_v1.py --output $migDemoOutput --port 8766
```

打开`http://127.0.0.1:8766/`，点击运行，查看目标机新CPU回执。这个面板不是AGH，也不会调用模型/GPU。只传CPU ZIP可以运行第4节，但没有研发面板的完整文件与固定来源位置时不能直接运行这个入口。

## 13. 两图恢复及未完成研究入口

两图恢复V2是本地实测过的专用协议，需要原冻结后端、来源、输入和新的共享预算登记；它没有普通MCP启动工具，不能用`slices --resume-from`替代。更换显卡/依赖后，后端来源和有效predictor参数也需新验收。目前没有跨机一键迁移该协议的已验收入口。

完整640图恢复、新科学MCP和完整三组比较同样不能因为复制源码或登记工具就宣布通过。原机最新V14诊断仍failed/stopped，新的科学恢复目前是工程准备。先迁移已稳定A–E层，专用恢复与新实验按新电脑的明确协议另做工程和真实业务验收。

## 14. 迁移通过标准

| 检查项 | 合格证据 |
| --- | --- |
| CPU案例 | 新migration_acceptance.json为passed，12例/30参考及独立检查通过 |
| 关键字节 | 19锚点一致；完整业务来源检查通过，不能用19项代替全输入 |
| 环境 | 实际Python/Torch/Ultralytics/CUDA/显卡已记录，pip check通过，CUDA算子可运行 |
| 数据工具 | 新audit、verify、repair满足各自业务summary；原输入未变 |
| 新GPU对照 | 新任务completed、comparison_status passed，完整预测/环境/来源链与复核有效 |
| 历史诊断 | 固定原来源完整，新诊断及独立复核通过 |
| 本地报告 | 新request_id、报告声明与证据一致，独立门控通过 |
| AGH/MCP | 目标机新会话真实工具调用、审批、同ID状态读取、对应新产物与官方导出 |
| 专用恢复/系统比较 | 新协议真实验收；未做则明确pending，不借旧结果补填 |

## 15. 常见问题

| 表现 | 优先检查与处理 |
| --- | --- |
| 能paths但audit找不到图片 | split中的绝对路径、原图是否完整、实际大小写；配置解析不等于数据可运行 |
| Training data.yaml path mismatch | 训练清单、data.yaml与目标目录不一致；同路径恢复，或另做新来源迁移，不改旧hash骗过检查 |
| Frozen source/manifest changed | 换行转换、缺文件、改源码、改配置或丢了源码归档；重新按字节复制，保留失败 |
| diagnose缺上游 | 必须带固定原ID整任务及源输入，不能指向最新compare任务 |
| workflow冻结失败 | 25 sources/25 archive/968 preserved引用文件不完整；不能只带freeze本身 |
| repair跨卷链接失败 | 需要同卷NTFS图片与副本输出，检查权限；不自动改修复机制 |
| CUDA unavailable或kernel image错误 | 驱动、CUDA wheel、显卡架构兼容性；不要自动改CPU/精度/协议 |
| start_web找不到Node | 原脚本写死了安装位置；使用显式run_agh.py参数 |
| .node/VC DLL加载失败 | 完整运行目录、Node24.15/x64、VC运行库；必要时新构建并重新验收 |
| MCP已启用但不ready | executable绝对路径、cwd/来源锁、stdio启动错误、信任revision与工具名称长度 |
| qualified工具名过长 | 使用短服务ID并重新注册新定义，保留旧失败；不要改工具身份后省略复核 |
| AGH网页没有旧会话 | 新home不会带旧数据库；历史用脱敏HTML看，新验证用新会话 |
| 模型任务审批超时 | 及时处理Allow once；服务信任不替代每次实际审批 |

## 16. 本教程附件与来源

- `source-reference.json`：原机Python/44包版本、19个关键文件hash及记录的源硬件。不是全包manifest，不包含Key。
- `constraints-source-python312.txt`：来自原机installed metadata的版本约束，供目标机视觉依赖解析使用，不是离线wheel包。
- 已有本机CPU包说明：`../delivery-package-v1.md`。
- 现有功能与边界：`../项目功能与使用说明_20261014.md`。
- AGH本地安装/MCP指南：`E:\PythonProject\AGH_\agnes-harness\docs\guide\install.zh-CN.md`和`mcp.zh-CN.md`。

建议实际顺序：复制CPU包并通过A → 同路径恢复数据/源码 → 建环境并通过B → 新GPU对照C → 带完整历史闭包验证D → 新Provider/MCP验收E。只通过某一层，就报告该层完成，后续仍pending。
