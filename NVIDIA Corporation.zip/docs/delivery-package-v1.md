# DefectResearcher 可迁移 CPU 交付包 v1

v1是已经实现构建器和迁移smoke入口的初始CPU交付里程碑，范围为12个冻结人工LabelGuard案例、30个独立几何标准案例及12项保存任务交叉核验。最终比赛证据与报告状态保持pending，后续由v2补入经过验收的最终来源与证据。

构建入口为`tools/build_submission_bundle_v1.py`，默认只创建尚不存在的`outputs/submission-bundle-v1-exclusive/`。已存在目录直接拒绝，原有outputs不会被覆盖或修订。构建器逐项复制显式白名单，核对源文件复制前后SHA256；不遍历复制整个项目。

```powershell
python -B tools/build_submission_bundle_v1.py
```

白名单包含LabelGuard所需的8个Python模块、执行/核验/smoke/构建工具、两个冻结fixture、`pyproject.toml`、原项目README、本文、公开路径config示例及实际`config/submission-team.json`。研究依赖只含`cableinspect_geometry.py`和`数据处理/7检查YOLO标注数据.py`，同时保留相邻上游仓库的`license.txt`。修复路径执行生产geometry，独立Verifier使用另写的解析参考及固定答案；源checker与geometry共享实现，不当作独立证据。`task_runtime.py`保留源文件原样，其他业务的延迟导入入口未包括在本CPU闭包中，不能调用GPU/实验任务。

上游AGH `LICENSE`和`NOTICE`完整保留，`agh-runtime-fixes.json`记录本地标题取消结算与用量保存修复涉及的三个TypeScript文件路径、当前hash和历史修复后hash。此包不包含AGH运行时二进制或这些TypeScript源文件，也不声称已安装/验证可用AGH。许可声明不擅自补填：DefectResearcher代码无明确再分发许可；既有project_start新增geometry/checker的作者、逐文件许可和再分发条件仍需确认，上游Apache-2.0许可证文本仅按来源保存。

包明确排除所有旧outputs、未稳定V12源码、私有`.runtime/`、Provider配置与凭据、`node_modules/`、`config/local.json`、缓存、全量数据、检测权重与CPU闭包外的模型/GPU源文件。团队信息按actual config保存：三条咸鱼、常州工学院、w/c/l，成员角色、导师及官方身份要求保持pending。

ZIP形成前扫描全部白名单和生成文件中的可识别凭据文字，包括私钥头、常见Provider/GitHub/AWS令牌、Bearer字面量及明文凭据赋值。结果只记录规则、路径、行号，不输出疑似凭据值。没有规则命中表示此次扫描通过，不证明任意形式的秘密不存在。扫描失败禁止形成交付ZIP。ZIP限制为200 MiB，最终大小和SHA256记录在包外`build_receipt.json`。

`HASHES.json`覆盖包内所有文件，唯一排除其自身以避免递归hash；manifest本身的SHA256由包外构建回执记录。新目录`artifact_manifest.json`进一步覆盖ZIP、完整manifest、构建回执和实际迁移证据，唯一排除自身。解压后文件成员、大小与hash逐项重验。

构建器使用生成的ZIP实际解压至`migration-new-path/DefectResearcher-CPU-v1/`，在该新路径执行隔离Python `-I -S -B`，不加载site-packages。smoke强制拒绝Torch/Ultralytics等模型/GPU库、网络访问和子进程，读取包内geometry并创建新的人工输入；真实执行4个正常副本、4个修复副本和4个拒绝路径，随后独立核对任务完成链、源文件不变、实际修改记录、修复后几何与固定答案。30个独立geometry fixture亦实际运行。

移至其他新路径后可按下列命令独立复现。输出必须是新的目录且处于不可变包之外，重复运行请选新的输出名称。

```powershell
Set-Location '<解压目录>\DefectResearcher-CPU-v1'
python -I -S -B tools/migration_smoke_v1.py --output '..\smoke-evidence-new'
```

Python最低版本3.10，无需安装额外包。smoke执行前后都核对包的完整manifest，`migration_acceptance.json`保存实际12例outcomes、独立复核结果、30例结果、模块来源、时长和隔离检查。构建器成功必须同时满足子进程exit 0和迁移回执passed。`paths`配置解析不计作迁移验收。

本机ZIP解压至新路径的CPU验收只能证明该闭包在同一台机器重新运行。其他机器/操作系统、AGH和Provider安装、MCP信任/审批、全量数据与权重、CUDA/GPU推理、最终模型规则合规、最终证据报告及视频均为pending；v1不作全栈跨机通过、最终提交完成、完整科研自治或生产修复正确率声明。

首轮构建`outputs/submission-bundle-v1-exclusive/`保留失败：Windows的`platform.platform()`会尝试启动系统子进程，被smoke隔离守卫拒绝，尚未执行案例。新源码改用`sys.platform`和`sys.getwindowsversion()`直接读取信息；修复后必须用新的`--output outputs/submission-bundle-v1-r1-exclusive`构建，原失败目录不得覆盖。

修复后实际构建与迁移结果以`outputs/submission-bundle-v1-r1-exclusive/build_receipt.json`和其`migration-evidence/migration_acceptance.json`为准，文件中未出现passed不得追认通过。该包仅保存在本地，未进行外部发布。
