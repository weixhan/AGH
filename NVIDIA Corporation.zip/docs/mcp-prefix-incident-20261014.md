# V11 MCP 挂载失败：原生工具前缀生成与扩展合约不一致

审查日期：2026-10-14。审查范围：只读追踪 AGH 快照、审计日志、动态 MCP 扩展加载路径；不运行模型、GPU 推理或业务实验，不修改冻结 V11 源码、原生代码或原生构建文件。

## 已确认根因

`dr-compare-v11-diagnostic` 的 MCP 服务定义能够通过独立连接测试，但 AGH 将它转换为动态扩展时生成了 39 字符的 `capabilities.tools.prefix`，超过扩展 manifest 合约允许的 33 字符。Host 在连接工厂执行前拒绝 manifest，留下空扩展行。因此 `onFirstAttempt` 和 `onStatus` 均未执行，行运行时返回缺失的状态；worker 随后将这一结果误报为服务“不属于当前快照”。

这是一处原生生成器与原生合约的不一致。V11 的长服务 ID 触发了问题；不是 Python MCP 服务的初始化或工具目录失败，也不是磁盘快照缺少该服务。

## 最小证据链

| 证据 | 位置和结果 |
|---|---|
| 服务确实在快照中 | `.runtime/agh/data/resource-control/worker-snapshots/local-dev.json`：`mcp` 有 14 个条目，含 V11 diagnostic；其状态为 `enabled`、`trusted`。 |
| Host 拒绝动态扩展 | `.runtime/agh/data/audit/host.jsonl:613`：2026-10-13T16:29:43.420Z，`agnes/mcp-dr-compare-v11-diagnostic-f399e7e8`，`extension.failed`、`E_EXT_LOAD`、`invalid extension manifest`。重启/重连后同类证据位于行 678、829、916、981、1068、1133。 |
| 对照服务器成功加载 | 同一审计文件行 607、980、1132：`agnes/mcp-dr-compare-v10-7fb634a2` 为 `extension.loaded`。 |
| 两个官方校验器独立复现 | 用快照条目调用 `mcpServerRowsFromDefinitions`，只构造行，不执行工厂；`checkManifest` 与 `validateExtensionManifest` 均返回唯一错误 `/capabilities/tools/prefix`、`PATTERN`。 |
| 误导性外层错误 | `../agnes-harness/packages/worker-runtime/src/main.ts:659`：缺失状态时抛出 `MCP server ... is not part of the current snapshot`。诊断副本日志 `outputs/comparison-suite-v11-diagnostic/service_debug3.stderr.log` 记录了此底层异常。 |
| 独立连接与生命周期操作不同 | `outputs/comparison-suite-v11-diagnostic/mcp_reconciliation.json` 保留 `mcp/test` 成功、`mcp/enable` 失败；`service_debug_reconnect3.json` 保留重连失败、`model_requests: 0`。 |

官方校验器的本次实际结果：

```text
dr-compare-v10
  prefix: mcp_dr_compare_v10_7fb634a2_
  length: 28
  checkManifest: ok
  validateExtensionManifest: ok

dr-compare-v11-diagnostic
  prefix: mcp_dr_compare_v11_diagnostic_f399e7e8_
  length: 39
  checkManifest: /capabilities/tools/prefix PATTERN
  validateExtensionManifest: /capabilities/tools/prefix PATTERN
```

## 合约和运行时路径

`../agnes-harness/packages/protocol/schema/extension-manifest.json:16` 的前缀 pattern 是：

```regex
^(?:[a-z][a-z0-9_]{0,31}_)?$
```

其非空字符串总长度最多 **33**，不能直接称为“总长度 32”。首字母、最多 31 个中间字符和尾部下划线合计 33。当前协议显式规定了这个界限；本次审查未找到解释其设计动机的文档。

`../agnes-harness/packages/base/src/mcp/naming.ts` 的 `SLUG_MAX = 40`，生成形式为 `mcp_<slug>_<hash8>_`。固定开销为 14，因此最多可以生成 54 字符前缀；若保持当前 manifest 合约，可读 slug 必须最多 19 字符。

`../agnes-harness/packages/worker-runtime/src/mcp-server-rows.ts` 把该前缀直接填入动态 manifest。`Host.extensionRows.prepare` 为行提供动态工厂，`extensionRows.apply` 通过运行时目标发布器挂载；行生命周期调用 `builtinRows.load`。`../agnes-harness/packages/host/src/ext-host/builtin-row-host.ts` 先做 manifest admission，再调用工厂；失败记录为 `extension.failed`，并返回失败 handle。`../agnes-harness/packages/host/src/assemble/ext-rows.ts` 的 facade 行允许失败 handle 留作空行，不令整棵树失败。

因此树的构建/发布本身可以完成，但 MCP 扩展工厂没有启动。`createMcpRowRuntime.apply` 的 `started` 数组没有该行的 promise，`statuses` 没有该服务，且服务未被定义预检标记为 `skipped`。`applyMcpRowChange` 返回 `undefined`，最终触发上述误导性异常。单纯重启或重连不能修复这个确定性的 manifest 拒绝。

## 项目恢复边界

本次项目选择 V12 短 MCP 服务 ID 作为恢复适配层，保持原生合约和原生文件字节不变。V11 保留为 setup failure、0 模型请求的冻结证据；不覆盖其 source lock、失败操作 ID、回执或原始截止时间。

V12 激活前，应把所用服务器 ID 经 `mcpLocalToolPrefix` 转换后，用官方 `checkManifest` / `validateExtensionManifest` 校验完整动态 manifest，而不是只检查 ID 自身长度。然后按顺序核验 `mcp/test`、`mcp/enable`、`mcp/status`、`mcp/tools`；只有生命周期状态为 ready 且目录含预期工具时，才进入模型实验。本记录本身不代表 V12 已准备完成或已经启用。

原生修复的两种方向：缩短生成器的 slug 会遵守现有合约，但改变长 ID 对应的本地工具名；放宽 schema 可以保留既有名字，但属于协议兼容性变更，需要再生成所有引用 `Capabilities` 的协议类型并重建运行时。后者不自动扩大工具权限：注册仍受 manifest 指定的精确前缀、lease 的 `startsWith` 约束以及工具名 64 字符总上限限制。但不能仅替换单个构建文件中的正则，也不适合在本次冻结实验里修改原生合约。若未来处理，应选择与工具名上限及至少一个后缀字符一致的前缀上限，并明确兼容性。

## 已有测试中的缺口与建议

`../agnes-harness/packages/base/test/mcp/naming.test.ts` 目前显式断言长 ID 前缀最多 54 字符；`register.test.ts` 的长 ID 测试使用工具注册 API 模拟对象。这些测试未验证生成 manifest 能通过真实 Host admission。`worker-runtime/test/mcp-server-rows.test.ts` 只在短 ID 上核验声明与注册使用相同前缀；不能捕获本事故。

未来上游修复应扩展已有测试，不新增重复实现的测试：

1. `mcp-server-rows.test.ts`：加入当前 V11 ID，以及长度边界两侧的服务器 ID，断言生成的完整 manifest 能通过官方校验器，或返回明确的逐服务跳过状态。
2. `mcp-row-runtime.test.ts`：通过真实测试 Host 加载长 ID，核验首次尝试、ready / unavailable 状态与目录；加入工厂之前 admission 失败的场景，确保在快照中的服务不会返回缺失状态或误报“不在快照”。
3. 原生修复若涉及 schema：扩展 `extension-api/test/manifest.test.ts`、`protocol/test/ajv-parity.test.ts` 的前缀边界表，并运行 `pnpm --filter @agnes/protocol gen:check`。
4. 运行受影响已有测试：`packages/base/test/mcp/naming.test.ts`、`packages/base/test/mcp/register.test.ts`、`packages/worker-runtime/test/mcp-server-rows.test.ts`、`packages/worker-runtime/test/mcp-row-runtime.test.ts`，按真实进程测试所属层执行。

本次已完成快照读取、审计比对和零连接的官方 manifest 校验器复现。未修改或运行原生回归套件；以上是上游修复的验证要求。
