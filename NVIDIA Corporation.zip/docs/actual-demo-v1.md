# DefectResearcher CPU 包的四分钟真实工具演示

本演示使用一个新建的本地证据面板，实际执行已经验收的CPU ZIP工具并读取新生成的产物。它不是AGH界面的模拟，不展示虚构模型回答，也不将历史记录播放当作新的AGH执行。视频素材只保存在本地，公开链接、访问性验证和正式提交仍待完成。

## 可复现入口

面板由`tools/local_demo_v1.py`和`tools/demo_evidence_v1.html`组成。后端仅监听`127.0.0.1`，运行按钮启动解压包中的`python -I -S -B tools/migration_smoke_v1.py`。新任务ID和新证据目录由后端创建，页面轮询真实子进程结果。只有exit 0且独立回执为passed才显示通过。

```powershell
python -B tools/local_demo_v1.py --output outputs/actual-demo-v1-new --port 8766
```

打开`http://127.0.0.1:8766`可实际操作。输出名称必须新建；原包、历史outputs和旧演示任务不覆盖。CPU包来源锁定为`outputs/submission-bundle-v1-r1-exclusive/DefectResearcher-CPU-v1.zip`，SHA256为`7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61`。

## 本机录制能力

已发现本机Edge：`C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe`。bundled Node依赖中存在Playwright 1.62.1。PATH及常见缓存中没有FFmpeg/ffprobe，Anaconda中没有Playwright/cv2/imageio_ffmpeg。

Playwright官方CDN的FFmpeg v1011已下载到新目录`outputs/demo-runtime-v1/`，下载回执保存源URL、archive hash与大小，原`COPYING.LGPLv2.1`保留。其精简构建支持VP8/WebM和PNG，不具备H264编码器，因此本演示录为WebM。这里记录的是本机实查能力，不要求修改系统PATH或安装全局依赖。

`tools/record_demo_v1.mjs`启动临时无登录、开启Chromium sandbox的Edge实例，只允许访问本机面板；以1280×720连续录制240秒。浏览器recordVideo记录真实页面渲染和真实按钮操作，没有用拼接截图、加速、结果替换或合成AGH画面制作“演示”。视频为静音，页面中文文字承担讲解。

```powershell
$env:PLAYWRIGHT_BROWSERS_PATH = '<项目目录>\outputs\demo-runtime-v1'
node tools/record_demo_v1.mjs --output outputs/actual-demo-v1-new/media --playwright-path '<bundled依赖>\node_modules\playwright'
```

首次录制前可用`--preflight`与新的输出目录检查布局、页面错误和ZIP来源hash。受限沙箱直接启动浏览器可能返回`spawn EPERM`；本次对只访问本机面板、写入新本地目录的命令通过自动审批后执行。未登录外部账号，未上传、发布或发送材料。

## 连续录像节奏

| 时间 | 真实操作与画面 | 可核查内容 |
| --- | --- | --- |
| 0:00–0:30 | 项目问题与领域贡献 | 说明AGH底座与本项目机制，明确这是实际CPU面板 |
| 0:30–0:45 | 固定ZIP来源与新任务入口 | 展示包大小/hash和实际工具命令 |
| 0:45–1:25 | 点击运行，等待真实工具发布结果 | 真实新任务ID、实际耗时、12例结果；没有预设完成率 |
| 1:25–1:40 | 打开正常案例 | 零修改与独立复核；不当作一次实际修复 |
| 1:40–2:00 | 打开坐标修复 | 真实before/after文字和changed-file记录 |
| 2:00–2:20 | 打开metadata旋转修复 | 有依据的metadata变更与固定答案 |
| 2:20–2:50 | 打开hash不符、来源缺失拒绝 | 真实拒绝理由，修改数0，不生成副本 |
| 2:50–3:25 | 打开独立核验 | 30例几何、144项保存任务检查、14项smoke约束 |
| 3:25–4:00 | 来源与成果边界 | 原创归属待成员核对，V12/AGH/GPU/跨机/发布提交pending |

录制结束后必须对WebM实际解码，核对真实时长在180–300秒、尺寸、文件hash/大小、关键帧与字幕数字。`recording_receipt.json`记录操作时间线、新CPU任务ID、页面错误、真实API结果及连续录制说明；没有解码QA回执前只能标“已录制，待媒体验收”。

此素材证明的是新路径CPU人工案例工具执行，不替代赛事要求的Agnes核心任务记录或其他AGH运行证据。历史检测和恢复结论在项目报告另列；本录像没有新检测、GPU或模型调用。最终模型合规、成员身份、真实公开项目链接、公开视频可访问链接及正式提交回执继续待补充。

## 本轮已完成素材

新录像位于`outputs/actual-demo-v1-r1/media/DefectResearcher-CPU-actual-demo-v1.webm`，实际时长240.68秒，1280×720、VP8、25fps、静音；13,591,566字节，SHA256为`4893c66ae547d82b7a89a99bf2537b95a98174645ea7ad7b71894db7ca10339e`。八个时间点实际解码通过，媒体与任务交叉核验13/13通过，八帧已逐一目视检查。录像中新CPU任务为`demo-1435788f96c4448589bde3fd56b8f205`，实际27.457秒；12例全部通过、4例真实修改、非预期修改0、30例几何通过、保存任务144/144和smoke14/14通过。

首轮录像在约85秒案例详情更新时因重复DOM ID中止，原CPU任务本身通过；失败录像、失败记录与修复前源码保留在`outputs/actual-demo-v1/`，未当作完整视频。修复后先只读预检12个实际案例详情，再在全新输出目录录制完整视频。CPU验收服务在录制和QA完成后停止；可按本文新目录命令重新启动。

本轮状态是“已完成真实CPU演示素材”，最终赛事演示仍需实际Agnes+AGH核心连续至少三步的证据与画面。V12/V13或新修改runtime未因本CPU录像获得真实模型通过认定。外部发布与视频上传仍未执行。
