# 完整验证集 640/960 第二组评估步骤恢复验收准备

版本 v1；2026-10-14。对应原方案 §10.2、§10.3、§11.2。本文与准备脚本只登记可审查的方案和工程契约，真实实验与 integrated AGH loop 尚未执行、尚未验收。

目标：在同一份冻结输入和配置下完成新审计与第一组 640 评估，使第二组 960 在步骤完成标记发布前出现可核验故障；恢复只重跑完整 960 步骤，并与同批新无故障参考比对。

## 已有实现及其可复用边界

| 实现 | 当前能力 | 本验收需要的新增部分 |
| --- | --- | --- |
| `defect_researcher/resolution_comparison.py` | `_protocol` 固定完整 640 张 val、同一个 640 训练权重、FP32 CUDA0；`_prepare_inputs` 核验训练/数据/像素来源；两组真实推理、独立计分和完成标记最后发布 | `run_comparison` 每次新建目录并整体执行，没有 resume 入口；每组没有独立产物清单、验证结果和完成标记。需新增版本的步骤控制器，而不修改既有执行器 |
| `defect_researcher/sliced_business_recovery_v2.py` 与 worker | shared ledger 先预约调用再闭合实际成本，哈希链、固定故障、旧失败保存、同一开始时间与 deadline、最终标记迟到拒收 | 两图、pass 0..8、40 调用/60 GPU 秒/300 wall 秒硬编码，不能直接替代完整验证集评估。复用机制并新建适配版本，保留旧来源 |
| `defect_researcher/research_mcp_runtime_v2.py` 与 server | 后台 worker、服务器来源锁、start/status 两工具、注册时捕获 epoch/monotonic deadline、完成状态独立核查 | 当前严格 CPU-only、人工 LabelGuard 案例和封存历史科学证据；显式禁止新推理、GPU、任意 resume。新增科学作用域与工具版本，不扩大旧作用域 |
| `tools/verify_resolution_run.py` | 独立读取成员、来源/产物哈希、GT、环境与预测并复算 | 该脚本复算指标仍复用 `detection_metrics`，不能称第二套独立 AP 实现。新恢复验证器需额外核查步骤复用、故障、预算链、参考一致性 |

已保存的同权重任务 `resolution-c39c94bc8d0a4095bf92b86db4f293f9` 有两组真实完整验证推理与独立产物核查。它是历史来源证据，不能充当本次“新无故障参考执行”，更不能用来回填原失败。准备脚本重新核验其顶层产物字节链，并明确标注未重新运行科学验证器；可选的全输入快照重新读取/哈希全部冻结输入。既有两图切片恢复与原方案 §10.2 的第二组完整评估故障分别验收。

## 新实验的冻结协议

- 完整固定 640 张 val；不选两张、不抽样、不访问测试预测；train_imgsz=640，eval_imgsz 分别 640/960；权重只读且相同。
- FP32、CUDA0、batch=1、prediction_confidence=0.001、nms_iou=0.7、max_det=300、rect=false、augment=false、agnostic_nms=false、quantize=null、nms=null；TF32 关闭；不换权重、不训练、不暗改 batch 或阈值。
- `nms=null` 来源于既有实际 predictor 记录；新增 backend 必须核验有效值及其类型，不能静默改成 false。设备、dtype、实际 imgsz、调用参数、依赖版本/源码与像素来源均入锁。
- 本次只验收恢复机制。参数变化、方法选择和新性能提升结论不属于此实验；结果允许与原假设不一致。

| 阶段 | 实际执行 | 成功证据与处理 |
| --- | --- | --- |
| 注册 | 固定协议、输入与执行来源锁、共享预算；创建新 ID | 在新 audit 前捕获 epoch/monotonic；原注册只写一次 |
| 审计与几何闸门 | 执行新的 audit 与 independent geometry gate | 完整产物链与结果通过；两组与恢复共用这些有效步骤 |
| reference | 完整 eval_640，再完整 eval_960 | 无故障新参考，两个步骤各自验证并发布完成标记 |
| fault | 完整 eval_640，再完整 eval_960 | 640 步骤完成；960 所有预测返回、计分产物就绪且调用成本闭合，在发布其步骤完成标记前只注入一次故障 |
| resume | 重读原注册、失败、共享 ledger、来源锁与已完成步骤 | 核验审计、几何、640 后只新建 `resume/eval_960`；完整重跑 640 张，拒绝使用 fault960 临时预测/指标 |
| review | 独立验证器重新读文件、复算并比对新 reference 与恢复结果 | 保持原 fault 目录字节不变；全部门槛及原 deadline 内通过后，父实验最后发布 completion |

注入边界为 `after_all_predictions_and_metrics_closed_before_step_completion`。故障步骤可留下临时预测与指标，但没有可信步骤完成标记，因此不是有效可复用步骤。这演示原方案承诺的步骤级同配置重跑，不宣称逐图补跑、训练 checkpoint 续跑或真实随机 CUDA 异常恢复。注入规则、fault 次数与失败原因必须在执行前冻结。

## 预算与持久化规则

五次完整组评估分别是 reference640/reference960/fault640/fault960/resume960。每组 640 次正式 `model.predict` 入口及 1 次预热，所以确定性计数为正式 3200、预热 5，总计 **3205 次预测入口**。框架内部 warmup 不冒充该入口计数，相关 GPU 时间仍如实计入；不允许额外恢复重试。

历史任务环境记录约 31.16 秒/32.14 秒的组耗时和约 183 秒的整个任务 wall，含一次几何与来源哈希；这些只帮助估算，不是本实验实际耗时。GPU 累计预算与原 wall 上限须在新增 worker 准备完成、来源锁冻结后正式登记。准备脚本默认将这两个值保留 null；`--wall-seconds` 和 `--gpu-seconds` 仅生成候选值，并保持 `execution_budget_registered=false`。旧两图 40/60/300 预算不能挪用或重置为本次预算。

新 ledger 采用既有共享哈希链与调用预约/闭合模式，移除两图特定枚举并绑定本次唯一注册身份。预约先 fsync；实际 predict 返回后记录 UTC 起止、CUDA event GPU cost、包含同步的 elapsed cost及环境。共享预算含三臂、预热、失败960、恢复960，wall 含注册后的 setup、audit、锁核验、计分、独立复核和最后发布。

失去 closed-cost receipt、worker 强杀、未完成 journal 尾行或未结束调用时，成本记 unknown 并拒绝 resume；不得用已知其他调用数补填。硬 deadline 来自最初注册，worker 启动、状态查询和恢复不能重新授时。超预算或晚到完成标记隔离拒收，不回填原 fault。唯一恢复重试前还必须足够预约剩余 641 次入口。

## 步骤复用与文件契约

新实验建议包含 `registration.json`、`protocol.json`、`input_manifest.json`、`source_lock.json`、`shared_journal.jsonl`、`shared_budget.json`、`audit/`、`geometry_gate/`、`reference/eval_{640,960}/`、`fault/eval_{640,960}/`、`fault/failure.json`、`resume/eval_960/`、`independent_verification.json`、`recovery_report.md`、`artifact_manifest.json`，最后是父实验 `completion.json`。

每个成功步骤包含预测/审计结果、环境、计分、`verification.json`、`artifact_manifest.json` 与最后写入的 `completion.json`。完成标记绑定任务/步骤 ID、协议/输入/执行来源摘要、产物清单 hash 与精确文件集合；来源文件当前大小/hash、成员顺序、GT、实际环境均须重核。没有 marker、空 manifest、路径越界、重复项、hash 不符、已过原 deadline 均不能复用。`completion.json` 存在或某字段 completed 不足以成立。

失败960仅保存在原 fault目录；恢复建立新子目录，引用原 failure hash与 journal head，不修改其文件。对原 fault目录做恢复前后全树快照。640的预测/计分/marker字节必须一致，事件轨迹和实际调用日志必须证明640未在resume阶段再次调用。

## 参考一致性与拒绝条件

执行前提议冻结以下比较规则，正式 source freeze 后不能事后放宽：完整成员/顺序/GT/类别 ID/预测数量与操作点 TP/FP/FN 精确相等；对应预测 xyxy 绝对容差 1e-4 像素、confidence 1e-6、相对容差 0；指标复算绝对容差 1e-10。预测按执行前登记的对应规则比对，不能在看到差异后选择更有利的匹配。必须比对640 reference/fault、960 reference/resume；两端均由保存预测重新计分。计时与显存报告实际值，不要求相等。

仅排除明确非确定性字段（UTC、路径中的新 ID、耗时、显存）后建立规范化科学摘要；未排除的差异一律报告，不能把总体 mAP 接近代替逐图一致。当前容差是方案，不是已取得的结果；若运行出现超差异则失败并调查，不能当场更改容差通过。

通过需要同时证明：新audit/geometry有效；新两组真实reference有效；fault640完成且只故障一次；fault960和fault父目录没有completion；已完成步骤未重跑；完整960同配置仅重试一次；cost全部闭合且原预算/时钟没有重置；原fault字节保留；当前输入和执行源码不变；复算与参考一致；独立验证器拒绝标准错误；最后发布父marker。任一门槛缺证据，真实恢复验收保持 pending或failed。

## 可运行的准备检查

新增脚本默认只向stdout打印准备JSON，不写既有outputs。它不会导入torch/ultralytics、反序列化权重、执行audit、调用GPU/Agnes、注册MCP或发布实验completion。

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
E:\Anaconda_envs\envs\MMIOC_env\python.exe tools\prepare_resolution_recovery_v1.py --fixture-check
E:\Anaconda_envs\envs\MMIOC_env\python.exe tools\prepare_resolution_recovery_v1.py
# 完整读取和哈希源输入，只读且可能需要更长时间：
E:\Anaconda_envs\envs\MMIOC_env\python.exe tools\prepare_resolution_recovery_v1.py --full-input-snapshot
```

工作目录为 `E:\PythonProject\AGH_\defect_researcher`。fixture仅在既有 `.runtime/test-tmp` 下独占新建临时子目录写小JSON，检查后删除该子目录；Windows沙箱的OS tempfile 0700目录可能拒绝嵌套写入，因此遵循现有测试workspace做法。fixture验证完成步骤hash门槛、故障目录保存、只安排960以及拒绝来源变化/open-call/过期/预算不足/二次重试/损坏640。其 passed 只表示工程契约测试通过，`real_recovery_accepted=false`。准备JSON中的当前source lock不包含尚未编写的worker与独立恢复verifier，所以不是可执行实验冻结包。

本次准备核查：工程契约 fixture **11/11** 通过；默认准备核验历史任务顶层 **10** 项产物并记录 **18** 个当前来源锁；完整只读快照核查 **640** 张 val、**596** 个 GT 框、**10,256** 个来源文件。检查结束时 torch/ultralytics 均未导入，新增 detector/GPU/model 调用均为 **0**。完整快照JSON本次只在进程内生成并输出摘要，未写入既有outputs，也未形成执行注册或完成marker。

## 后续实施顺序与 integrated AGH loop

1. 新建受控分辨率 backend与步骤 worker。从冻结 `_infer` 复用数据/参数/FP32检查，在新的实现中加入每次预测入口预约与闭合成本；不能只在整个 `_infer` 外估算调用成本。不修改已有冻结来源。
2. 新建完整分辨率恢复 coordinator/ledger与独立 verifier，复用来源锁、独占创建、原时钟anchor和标记最后发布机制；真实GPU执行前完成契约和坏产物拒绝测试，正式冻结预算/依赖/容差/全部执行文件。
3. 串行执行新的三臂真实验收并独立复核；如果失败保留任务、实际消耗、原期限和所有来源。
4. 新增服务器管理的科学MCP作用域，模型参数只允许预登记experiment/request ID与预算引用；不允许路径、命令、backend、配置覆盖或任意resume目标。现有CPU MCP和V11来源保持原定义。
5. 真实Agnes在一个AGH任务中依次选择审计、诊断/假设、预登记新实验、状态读取、核验、结论更新并根据预登记条件启动失败步骤恢复；轨迹、作用域、模型成本、artifact链和证据声明独立验收。

第3项只证明本次完整组评估业务恢复；第5项才补足当前待跑的 integrated AGH research loop。历史模型artifact-read、CPU workflow passed、fixture passed、真实两图恢复均不能替代这个连续科研任务。
