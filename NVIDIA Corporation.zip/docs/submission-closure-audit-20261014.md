# DefectResearcher + LabelGuard：以独立验证、受控实验和可追溯恢复支撑电缆缺陷研究

材料核查日期：2026年10月14日。本文是可保存的交付整理稿和闭合清单，不是比赛提交成功证明，也不是新模型会话验收记录。

## 1. 本轮整理结果与证据边界

已整理项目说明正文、结论与证据映射、核心证据文件的当前 SHA256、迁移说明、来源表及3–5分钟演示脚本。现有README、进度、原方案和已保存验证文件足以支持受限能力说明；完整9次试跑/36次比较、同任务新实验科研闭环、实际可迁移包、真实演示视频和提交凭据仍待闭合。

本轮只读取既有材料，计算索引文件哈希并创建本文。没有运行检测、训练、模型请求或GPU任务，没有重算全部科学指标，也没有修改历史源码、冻结协议、原失败状态或完成链。索引中的“已记录状态”来自保存的验证文件，不代表本轮重新运行对应Verifier。V11正在主流程处理MCP生命周期问题；本文不将登记、预检或连接修复计为模型验收通过。

审查范围包括：`../README.md`、`../项目进度总览.md`、`../开发进度.md`、`../../DefectResearcher_参赛项目方案.md`、`../参赛方案对照审查_20261012.md`、`../config/submission-team.json`及第4节指定证据。原方案§13.2的本地交付清单用于本次对照；有效赛事通知、正式提交页面与主办方模型规则尚未在本文中重新联网确认。

## 2. 提交身份

| 字段 | 当前可信值 | 处理方式 |
| --- | --- | --- |
| 队伍 | 三条咸鱼 | 用户已提供；与报名系统一致性待核实 |
| 学校 | 常州工学院 | 用户已提供；与报名系统一致性待核实 |
| 成员 | w、c、l | 按用户已提供名称保留，不推断实名或学籍 |
| 成员职责 | 待补充 | 不把原方案A/B/C自动映射为w/c/l |
| 指导教师 | 待补充；如不适用应明确说明 | 配置当前为null |
| 报名身份核验 | 未完成 | 配置`registration_identity_verified=false` |
| 其他正式表单身份要求 | 待补充 | 以有效官方表单为准 |

身份来源：[submission-team.json](../config/submission-team.json)。学生团队独立完成声明需要成员核对实际贡献及既有/第三方代码来源后确认；本文不代替成员作事实声明或签署。

## 3. 可直接复用的项目报告正文

### 问题与方法

电缆缺陷研究不仅需要检测分数，还需要确认标注几何、实验来源、控制变量与失败后结果是否可信。DefectResearcher + LabelGuard以Agnes Harness（AGH）承载模型与工具执行，通过可信来源检查、独立几何验证、受限标签副本修复、同权重对照、证据驱动停止和步骤级恢复，保存人工可复核的研究产物。

AGH原生提供模型/工具调用、MCP管理、审批、任务状态和会话记录。本项目的领域增量包括：独立解析标注几何与固定答案；只依据可唯一确定的可信来源修复隔离副本；冻结数据、权重和实验条件；独立复算指标；核对来源与完成链；以共享预算约束恢复；对报告结论绑定证据并拒绝无依据发布。仅接入AGH或MCP本身不作为领域创新证明。

### 已有结果

| 结果 | 可报告结论 | 证据 | 明确范围 |
| --- | --- | --- | --- |
| 数据与独立几何 | 当前研究划分4479图/3864框，独立几何核验0差异；30冻结几何案例通过 | E01–E03 | 一致性不证明人工标注真实性或检测性能 |
| 标签副本修复 | 12个人工隔离案例包含4正常、4实际修复、4拒绝；正式数据副本修改数0 | E04–E06 | 生产数据修复正确率不适用，不能写100% |
| 同权重640/960 | 两组真实验证集推理，训练尺寸640、同一权重，仅评估尺寸改变；总体指标下降 | E07–E09、E13 | 单权重、单验证集；原严格会话27/29未全通过 |
| 漏检/误报诊断 | 科学复核61/61、模型会话31/31；固定阈值候选未满足正常图误报预算，停止 | E10–E11 | 复用已保存预测，没有本轮新检测 |
| 固定切片 | 保存科学证据99/99、模型只读会话54/54；候选应停止 | E12、E24–E25 | 原计算任务仍failed；保存产物复核不追认原执行 |
| 两图步骤恢复 | 复用2个检查点，只补16次正式调用；控制/恢复结果在冻结容差内一致 | E14–E15 | 固定两图、一个已知成本故障、本地执行 |
| 受限跨工具CPU流程 | 输入类别、证据与预算改变路径；独立检查后发布完成链 | E16 | CPU领域控制器选择内部步骤，没有新增实验 |
| Agnes跨工具入口 | 一个固定人工修复案例的模型启动、同任务读取与证据总结23/23通过；历史保全9/9 | E17–E18 | 3次主流程模型请求；未补审该历史阶段全部原生标题费用 |
| 案例级模型行动 | V6同一正常人工案例C/U/F各一次诊断通过 | E19 | 不是同条件完整系统比较或优越性证据 |

同权重对照采用同一640训练权重，权重SHA256为`57d430496f764593b49547897161fbafa93afaca83cc9942a3cc8c2e282d0d75`。采用项目独立匹配/AP定义，与既有训练基线的Ultralytics指标不能混用。

| 验证集指标 | 全图640 | 全图960 | 固定切片融合 |
| --- | ---: | ---: | ---: |
| mAP50 | 41.07% | 36.52% | 27.82% |
| mAP50–95 | 16.53% | 13.73% | 10.87% |
| TP / FP / FN | 231 / 149 / 365 | 202 / 252 / 394 | 243 / 2913 / 353 |
| 正常图出现误报 | 5/245 | 10/245 | 223/245 |

原方案面积比小于0.5%的small包含94个GT，640/960的TP为5→13（召回5.32%→13.83%）；面积小于32²像素的旧tiny包含4个GT，TP为0→0。局部small召回增加伴随总体AP下降和FP149→252，不能概括为“提高分辨率整体有效”。尺度口径补充见E13。表内切片与全图结果均来自封存验证集；未使用测试集选择后续方法。

固定切片的五项接受门槛失败，因此后续控制流程保留停止行动。没有性能提升可以是有效研究结果，但必须保留失败、更新行动并说明边界；本项目已有证据支持本候选停止，不支持新候选自动研究完成。

两图恢复的V2真实执行共39次外层预测入口、GPU3.566122秒、含核验与发布总13.281秒，分别低于冻结40次/60秒/300秒预算。故障段留下2份有效检查点，新目录只补16次正式调用；独立发布前后各67/67。原V1失败的23次调用继续单列，不用V2成功覆盖。该结果不能外推到640图恢复、未知成本强制终止、原方案第二组640/960评估故障或部署可靠性。

### 保留失败与当前未完成

V8修复分支业务通过，但原生标题usage未知，联合验收失败；历史费用总数维持null。V9拒绝分支业务正确，但运行进程仍来自修改前版本，修改版执行来源验收失败。V10仅完成启动失败保全，0新模型请求、0联合正确完成，不是接入验收。E23仅是V11登记快照，不能计入新模型成功。

目前不能声明完整科研自治、新登记实验同任务执行已验收、完整9/36比较已完成或系统优于对照组。研究任务的完整范围、最终费用、最新运行版本和后续新验收结果必须另以其原始证据闭合。

## 4. 证据索引与当前文件指纹

每个ID指向现有文件。打包应保留对应任务目录、源码冻结清单、协议、源结果、manifest/completion、独立复核和官方脱敏会话；单独复制验证JSON或完成标记不足以复现来源链。本文ID用于提交材料导航，不替换业务报告中原有`evidence_id`。

| ID | 现有文件 | 已记录状态与用途 |
| --- | --- | --- |
| E01 | [首轮审计会话复核](../outputs/agh-first-audit/verification.json) | passed，18检查；模型→AGH→MCP审计 |
| E02 | [几何模型会话](../outputs/agh-geometry-verification/model_run_verification.json) | passed，19检查 |
| E03 | [几何独立复核](../outputs/agh-geometry-verification/independent_verification.json) | passed，20检查 |
| E04 | [12人工案例复核](../outputs/labelguard-local-checks-20261010/cases-verification.json) | passed，synthetic_only=true |
| E05 | [正式副本复核](../outputs/labelguard-local-checks-20261010/full-run-verification.json) | passed，14检查；changed_files=0 |
| E06 | [副本修复模型会话](../outputs/agh-label-repair/model_run_verification.json) | passed，19检查；正式副本0修改 |
| E07 | [同权重对照科学复核](../outputs/agh-resolution-comparison/independent_verification.json) | passed，46/46 |
| E08 | [同权重对照严格会话](../outputs/agh-resolution-comparison/model_run_verification.json) | failed，27/29；科学通过、范围未全过 |
| E09 | [同权重对照结果](../outputs/8d1d6900c7d74c90a29824495684807d/comparison_result.json) | completed；配置、环境及科学数字 |
| E10 | [诊断科学复核](../outputs/agh-diagnosis-model/independent_verification.json) | passed，61/61 |
| E11 | [诊断模型会话](../outputs/agh-diagnosis-model/model_run_verification.json) | passed，31/31 |
| E12 | [切片只读模型会话](../outputs/agh-sliced-artifact-model-v3/model_run_verification.json) | passed，54/54；读取保存证据 |
| E13 | [尺度口径附录](../outputs/plan-alignment-review-20261012/scale_alignment.json) | passed；94 small与4 tiny分开统计 |
| E14 | [两图恢复汇总](../outputs/sliced-business-acceptance-v2/verification.json) | passed，13检查；发布前后各67 |
| E15 | [两图恢复发布后复核](../outputs/sliced-business-acceptance-v2/postpublication_verification.json) | passed，67/67 |
| E16 | [CPU流程最终复核](../outputs/research-workflow-local-acceptance-v1/final_verification.json) | passed；17最终检查、178流程检查 |
| E17 | [受限跨工具模型复核](../outputs/research-mcp-model-verification-v3/verification.json) | passed，23/23 |
| E18 | [历史保全](../outputs/research-mcp-model-verification-v3/history_preservation.json) | passed，9/9；不与其他文件集合相加 |
| E19 | [V6正常样例诊断](../outputs/comparison-pilot-v6/verification.json) | passed_engineering_diagnostic；单案例C/U/F |
| E20 | [V8修复诊断](../outputs/comparison-pilot-v8/verification.json) | failed；联合正确数0，费用未知保留 |
| E21 | [V9运行版本审计](../outputs/comparison-pilot-v9/runtime_closure_audit.json) | failed_modified_runtime_execution_binding |
| E22 | [V10启动失败保全](../outputs/comparison-pilot-v10/final_closure_verification.json) | passed_preservation_only_not_acceptance |
| E23 | [V11诊断登记](../outputs/comparison-suite-v11-diagnostic/stage_ledger.json) | preregistered_not_executed；仅登记快照 |
| E24 | [切片科学独立复核](../outputs/1c68e87faed946d490a5ad802186146a/independent_verification.json) | passed，99/99；原计算失败不变 |
| E25 | [切片保存科学结果](../outputs/1c68e87faed946d490a5ad802186146a/recovery_result.json) | completed；候选停止与原失败分开 |

2026年10月14日本次读取时的SHA256：

```text
E01 180571e436be628b1ecb507fc9ed4ab21546a248d455bddd895febcc390916aa
E02 2e5b28a2f1ffff097f19d5e01d1622f65fd2123ce3296a3033c3598021ef1849
E03 7aa4053068b872cd8457086868609a7975f32cb94332440572f0b9e3a3a71ab4
E04 db986f108588d5560e7ef0bcc43db03e76d3197ae71641699879cd903ef07bdc
E05 7e79877230121f546e8a10d1ca6a755937ec4622002f3e2e8e853ce51b246e5a
E06 fc8d03a2fa0d600125017ea4fcd92a1fceb17ee2f05fd252e4c9bdad019f81b5
E07 00cd6d2832daa66f71656af512ba7500b9f3f6d3c2926f8730c7ce539c5bb439
E08 1f9fb8f329f3ec197b467f38f9937fe11a194288e64cdbb3eebb25780dbbd1d5
E09 4a397bd1bbc708ed5b55676918c3c54cfde97af5009a33eca92700dc32627f75
E10 7e4247701e940be3728d00011cd7c3849f5501190f66b7a2e13b1a35dc9ae45d
E11 47c7fbd4ea7658856b74188d75ddced64e2c3a2e1abf4de31c14559ca3034468
E12 54987801785bc0dc89a71790b49145bb066bbb083019dcce1eff8dfd863f7d30
E13 40225aca87d9404f98a8e070a03f0d1f73cfcd1d73cd024525f750c54eeef0b3
E14 130a0d94cb28467fef70198ffafb165b173477b17184dbae94e985cecf1ff1db
E15 267087f63d767af052957f685f39166e32e3a699328026deb0ebd5044ee36cd4
E16 001d2ce464f59e8917f8d533912b84c2751d49190c70a157d75039853f811763
E17 1c047020103449d0df576bb37d4d5b53b6709e0e2848e4dbb6718249d23fdedb
E18 4f25c6d7839519ccc76977ad856d4d363dcb05763410647b7243526d12b1f35d
E19 a5297041f251f70cec4810ee24a08661651d3cf4fd48620a94dfa32c6a46a3ac
E20 d7a4e8c73ef39ff29bba66818b809644ff8681db02ed31140efe731066ea479a
E21 3dad91aaa581ac384ce70b372552cd37cf3b5b9c493bdae84d819b2cf78f15e0
E22 5524e1629c0f4ed4542e9794bebd862eb17b5f387356b1ae890ca676bba48370
E23 7b0f30482e9bedb55560fbcc80e06c9073b4be554ba354a2d512e3ee5b44da99
E24 977d8025e400e694ae5aad92b82efe67421fb878bc5690b5e98b65ec4f1598df
E25 af147ddc6f5d4ddb02ec2ec018bd8c93dda245e641cc40f3968d1666df35d188
```

这些指纹用于检查引用文件是否变化。它们不是全包manifest，也不能仅凭相等就判定模型/科学验收通过。任一新结果必须新增明确的结果文件、对应协议/事件/预算与独立验收，保持旧ID及旧失败含义。

## 5. 可迁移运行说明与打包规格

### 当前已有与未闭合

`config/example.json`支持相对路径及`${research_root}`引用；解析基准为项目目录，或外置配置所在目录。配置路径由`DEFECT_RESEARCHER_CONFIG`或CLI的`--config`指定，`output_root`必须与所有受保护输入分离。

`pyproject.toml`声明Python>=3.10、dependencies=[]。这覆盖本项目标准库工具的基础条件，未声明检测所需PyTorch、Ultralytics、PyYAML或CUDA环境。E09的真实检测环境是Python3.12.13、PyTorch2.5.1+cu124、Ultralytics8.4.155、CUDA12.4、FP32、batch1、CUDA0、RTX4050 Laptop GPU；迁移机器与此环境的等价性仍待实际验证。AGH本地源码要求Node>=24.10、pnpm10.34.5，完整本地运行目录通过`pnpm --filter @agnes/cli build:local`构建。

核心审计仍依赖外部`project_start`研究代码、转换数据、划分、源COCO和冻结权重。已保存诊断/科学协议固定上游任务及来源哈希，部分历史证据含原机绝对路径。改配置、复制完成标记或替换冻结文件中的路径都不足以证明跨机复现；新执行必须建立新来源链并保留历史原件。历史包可以提供离线阅读，但不能预写“跨机Verifier已通过”。

### 建议归档目录

```text
submission/
  README.md                       入口、能力边界、阅读及执行方式
  report.md                       本文第3节及最终新证据结论
  evidence-index.md                本文第4节、会话/产物与哈希导航
  source-and-contribution.md       来源、模型、团队实际贡献
  code/defect_researcher/          选定版本代码、工具、标准案例及协议
  code/cableinspect-research/      运行确需的研究代码与划分；保留来源
  config/example.json             相对路径模板
  environment/                    Python包版本、AGH版本/源码改动、锁文件
  evidence/                       白名单任务证据、会话与源码冻结清单
  demo/demo.mp4                    实际录制、3–5分钟
  MANIFEST.sha256                 最终归档全文件指纹
```

数据与权重按许可和实际交付范围附上获取方式或纳入单独材料；不将整份数据/权重默认为项目原创。包中的配置必须与包内/包外资源约定一致，至少对解压后的`paths`、标准案例和一个受限业务路径完成验收，再签署可迁移声明。

建议采用显式白名单构建包，排除`.runtime/`、Provider凭据、`config/local.json`、临时缓存、未选定输出和无关生成目录。官方脱敏会话仍需对最终包逐文件复核，不能把“官方导出”当成全包无凭据保证。本轮没有生成ZIP或执行全包凭据扫描，包状态保持待制作。

### 可用的初始运行说明

在解压后项目目录运行；操作前修改模板为实际配置：

```powershell
Copy-Item -LiteralPath '.\config\example.json' -Destination '.\config\local.json'
python -B run.py --config '.\config\local.json' paths
```

`paths`仅解析配置，不证明外部输入或科学来源已齐备。输入准备完成后，审计/几何验证/修复必须输出新的独立任务目录。不要在“安装完成检查”中自动执行全验证集推理。

本地受限CPU流程入口为：

```powershell
python -B -m defect_researcher.research_workflow_v1 --request config/research-workflow-v1.example.json
```

示例`request_id=manual-v1-001`仅可首次使用；每次新任务先创建独立请求文件并更换ID，原预算不能重置。这个入口内部读取冻结科学来源，既有来源缺失时应停止，不是自包含的零依赖示例。

AGH安装/运行和Provider配置使用随包保留的对应版本官方说明；本机入口`run_agh.py`可通过`--entry`指定完整AGH入口。新机器注册MCP必须读取实际revision、信任实际新定义并启用，不能复制本机`.runtime/agh`或旧信任状态。业务写操作的`Allow once`与MCP信任是分别核验的执行证据。

## 6. 来源、模型与原创声明待办

| 材料 | 本地核查到的来源 | 提交说明需保留 |
| --- | --- | --- |
| Agnes Harness | 相邻`agnes-harness`源码；LICENSE及package.json记录Apache-2.0，NOTICE存在 | 版本/提交或源码指纹、官方来源、许可证及NOTICE；本地标题用量修复单列 |
| CableInspect-AD | 本地`cable_1.json`的info记录Hydro-Quebec、v1.0、2024；license.txt记录Attribution-NonCommercial-ShareAlike4.0 International | 作者/版本/数据获取方式、许可原文、划分与转换方法 |
| YOLO/Ultralytics | 安装包METADATA记录Ultralytics8.4.155、License=AGPL-3.0；冻结权重来自既有YOLO11n基线 | 检测器名称、版本、权重来源/训练配置/hash、使用方式及对应来源说明 |
| 既有CableInspect研究代码 | `project_start`中的几何、检查、实验及基线代码 | 哪些代码既有、哪些本次新增；作者/再分发许可待补充 |
| 新增DefectResearcher代码 | 当前业务适配、独立Verifier、协议、预算与恢复逻辑 | w/c/l实际贡献待本人填写；项目代码许可尚待明确 |
| Agnes模型 | 既有真实会话记录`agnes-3.0-flash` | 以最终运行记录填写模型/provider/版本/调用环节；新会话另列 |

本地COCO记录的数据下载入口为`https://hydroquebec.com/data/documents-donnees/donnees-ouvertes/zip/CableInspect-AD.zip`，许可入口为`https://creativecommons.org/licenses/by-nc-sa/4.0/`；本文未检验这些远程地址目前是否可下载。这里记录来源文件中的事实，不提供再分发合规结论。

本地既有说明保存了赛事模型规则冲突：飞书指南与官网/正式通知对第三方模型使用的口径不同。项目明确使用Agnes决策模型及YOLO11n检测工具；须保留双方原文/有效日期与赛事方对专业工具内模型调用的正式澄清。没有澄清前保持“模型规则合规性待确认”，不得写“全部符合赛事模型要求”。

## 7. 3–5分钟演示录制脚本

目标时长4分30秒。当前脚本已整理，视频文件尚未录制/核验。真实操作与读取历史证据在画面/字幕中分别标明；长推理可剪辑，但必须显示实际任务ID、执行时间和剪辑说明。

| 时间 | 画面/动作 | 讲解与验收点 |
| --- | --- | --- |
| 0:00–0:30 | 打开项目入口及团队信息，显示任务输入、范围和预算 | 介绍电缆研究问题；身份只用已知值 |
| 0:30–1:20 | 展示一个真实工具路径与来源核验，打开人工标准案例及答案 | 明示人工隔离样例；可信副本与原输入分别显示 |
| 1:20–2:10 | 打开同权重冻结协议、权重hash及640/960源结果 | 标明历史真实推理；说明唯一控制变量与验证集范围 |
| 2:10–3:10 | 展示两图V2故障段、2检查点、恢复段与独立复核 | 标明历史真实恢复；只补16调用，原V1失败保留 |
| 3:10–4:00 | 打开模型会话、同任务证据报告及切片stop结论 | 当前实测路径只使用已独立通过的结果；V11未过则显示待验收 |
| 4:00–4:30 | 打开证据索引、最终范围与费用限制 | 说明负结果、small/tiny口径、未完成项；避免完整自治/优越性声明 |

如最终版本保留“同任务新实验自动研究闭环”的标题承诺，视频必须展示该新登记任务的输入、真实实验执行、独立核验及结论更新；拼接不同历史任务不能满足这一承诺。视频制作后记录文件hash、时长、录制日期、所展示任务ID和字幕数字校对结果；目前这些字段均待填。

## 8. 闭合顺序与完成判据

| 优先级 | 剩余工作 | 可检查的闭合产物 |
| --- | --- | --- |
| P0 | 修复V11生命周期并在锁定来源/原预算下完成新会话联合验收 | 对应新协议、官方连续事件、实际runtime身份、全部调用/标题成本、工程+业务+范围+预算独立通过；旧失败不改 |
| P0并行 | 核对有效赛事通知、模型规则与提交身份 | 有效规则快照、冲突澄清、队伍身份核验和实际贡献声明 |
| P1 | 冻结同条件比较并执行9次试跑；通过后执行36次正式比较 | 同数据/模型/工具/预算与共同事后评价器；完整分母、失败、无据结论、误修改及成本记录；不得拼接不同版本诊断 |
| P1 | 闭合仍承诺的新实验研究任务 | 同任务审计→诊断→注册假设→真实受控实验→独立验证→结论/行动更新→证据报告；无候选时停止的限定成果另说明 |
| P1并行 | 形成最终可发布报告与机器可检查索引 | 每条最终结论有有效证据；新增结果只在独立验收后补入，费用未知保持null |
| P2 | 构建白名单可迁移包并解压复核 | 完整代码/依赖/来源/案例/证据、MANIFEST、凭据扫描、路径与至少一个受限路径的迁移验收 |
| P2 | 实际录制并核验3–5分钟演示 | 视频文件、时长/hash、任务ID、实际/历史字幕与数字校对 |
| P3 | 上传正式提交材料 | 文件/链接可打开、身份及规则满足、最终提交回执；只有回执存在才标已提交 |

原方案本地记录的提交时间为2026年10月15日12:00（北京时间），本文未重新验证它仍有效。安排上传缓冲应以有效通知为准；不能以材料文档创建时间替代验收或提交时间。

## 9. 当前交付清单

- [x] 已知团队信息整理，未知身份与贡献明确待补充。
- [x] 可直接复用的项目报告正文与能力边界。
- [x] 25个核心证据入口及本次读取时SHA256。
- [x] 同权重与切片科学结论、失败及费用未知分别保留。
- [x] 迁移说明、包目录规格、来源表及演示脚本整理。
- [ ] V11新模型联合验收及其最新闭合结果。
- [ ] 完整9次试跑/36次正式比较。
- [ ] 完整新实验科研任务验收或最终限定范围的明确说明。
- [ ] 有效赛事规则确认、报名身份与学生实际贡献声明。
- [ ] 最终独立报告门控与机器可检查的完整包manifest。
- [ ] 实际ZIP/归档包、解压迁移验收和最终凭据扫描。
- [ ] 实际3–5分钟视频文件及数字校对。
- [ ] 正式提交回执。

本文完成的是独立材料整理。其存在不将任何待办自动变为完成，也不扩展已冻结实测范围。
