# LabelGuard：由 Agnes 在 AGH 中核验标注、修复可信副本并提交证据报告

版本：主提交说明草稿 v1，2026-10-14。队伍：三条咸鱼；学校：常州工学院。本文收敛主作品到已实测的标注质量任务。公开视频、公开项目内容、正式身份字段及提交回执尚未补齐，本文不表示已经参赛提交成功。

## 1. 项目摘要

电缆缺陷标注包含旋转、边界裁剪、类别和来源映射。转换后的标签即使能被程序读取，也可能与原始几何不一致。LabelGuard 将标注处理分成独立核验、可信副本修复、再次核验和证据报告：输入正常时保留其含义，来源可信且错误可确定时只修复副本，来源缺失或身份不可信时拒绝修改。

Agnes 通过 Agnes Harness（AGH）选择并调用受限 MCP 动作，AGH 提供真实模型运行、工具调度、逐项审批和会话记录。项目代码负责几何标准、来源约束、副本修改、独立业务验收及报告证据绑定。核心演示是一个有固定输入、固定预算和明确停止条件的标注任务。

当前主证据是同一真实 Agnes 会话中的四次连续工具动作：`verify_input → repair_copy → verify_copy → publish_report`。其工程检查为 10/10，业务独立检查为 19/19；原 V13 联合验收仍为失败，原因和原记录保留。CPU 交付包另在本机新解压路径实际通过 12 个冻结案例，它用于无需模型的业务复现。

## 2. AGH 与模型实际参与的核心任务

| 字段 | 实际记录 |
| --- | --- |
| 模型 | `agnes-3.0-flash` |
| 会话 | `92465fc1-8f69-4c7d-bcf8-4fd0c346f20e` |
| 试验句柄 | `cmp_6b357026ab64462d9163524a96b4de2f` |
| 隔离输入 | 冻结人工案例 `repair_coordinates`，3 张样例图像、1 条原始标注；比较协议中的 F 分支 |
| MCP 接口 | 单一工具 `execute_case_action_v1`；本次限定名为 `mcp_dr_cmp13_d_62309eb3_execute_case_action_v1` |
| 真实调用 | 四次独立动作，各有模型调用、审批、执行结果和证据记录；每次采用 `Allow once` |
| 预算与用量 | 原始总预算 7 次模型请求、120 秒、6 个领域调用单位；实际 5 次主模型请求加 1 次原生标题请求，合计 6 次；领域调用单位 5，记录总时长约 58.54 秒 |
| 本次推理边界 | 检测器调用 0、训练调用 0、GPU 秒数 0；未加载 YOLO 权重 |

四个步骤是同一 MCP 工具的四次动作调用。模型看到每步返回后再选择下一步，程序没有把四步藏进一次自动执行调用。动作参数只接受已登记句柄、动作枚举及发布时的结构化报告；输入路径、预算、命令和处理分支由服务端固定登记，模型不能任意指定。

| 步骤 | 工具返回及后续行为 |
| --- | --- |
| `verify_input` | 独立核验原输入，`semantic_status=failed`，`issue_count=2`；据此进入副本修复路径 |
| `repair_copy` | 创建隔离副本，实际修正 1 个标签文件；副本另有 `data.yaml` 与 `manifest.json` 配置重绑定，原输入字节保持不变 |
| `verify_copy` | 模型显式再次调用独立核验，`semantic_status=passed`，`issue_count=0`；修复操作内部的核验没有代替这一步 |
| `publish_report` | 模型提交 `outcome=repaired`、`target=copy` 的报告，引用本次三个证据 ID 和真实字段；业务门禁接受并在本地产生发布回执 |

此处“发布”指本地任务的受控报告落盘。未向公开平台发布，也未完成赛事平台提交。报告 SHA256 为 `30873f0bd06cef6b0a8db6f9b893e9b584c1744bbee7a2c8ecc170f01a35a361`。

## 3. 验收结果及必须保留的限制

| 验收层 | 当前结果与解释 |
| --- | --- |
| 模型工程链 | 10/10：核验官方连续会话、固定来源、原钟/预算、真实请求与标题用量、工具结果配对、逐项审批和最终回合。主模型 `turn/end` 为 `completed`，官方 JSONL 与 HTML 导出成功 |
| 业务独立核验 | 19/19：原输入成员与字节不变、真实修复符合固定答案、动作证据完整、预算未重置、报告声明有证据、业务发布被正确接受；6 个原子声明无不支持项 |
| 原 V13 联合验收 | **失败，保持失败。** 原运行来源检查器错误假定 `turn/end` 含有 `turn` 字段，标题终态为 `failed / invalid-title`；不能以单独工程/业务通过替代原联合结论 |
| 后续判据与复核 | V14 判据修正了原生事件绑定，并将标题格式与真实请求用量分开。对旧 V13 事件的 2/2 运行来源补充复核属于后来的只读审查，不能计作一次 V14 新运行，也不改写原 V13 失败；`title_generated=false` |
| 模型可见记录 | 官方导出对 `evidence.summary.max_errors.yolo` 存在数值遮罩，工程核验保留遮罩而未从保存结果回填；不能声称模型收到未遮罩的该数值。业务核验另检查保存的原始领域产物 |
| 适用范围 | 一次人工修复案例的真实模型调用链；不能推导生产修复正确率、一般自主能力或对照优势 |

本主版本不把 9 次试跑、36 次系统比较、完整科研新实验或全分辨率故障恢复写成已完成。其他新会话若最终请求中止或用量未知，仍按原联合失败记录，不能合并到本会话的成功业务结论。

## 4. CPU 业务复现与测试样例

已验收的本地包是 `outputs/submission-bundle-v1-r1-exclusive/DefectResearcher-CPU-v1.zip`：92,006 字节，SHA256 为 `7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61`。这是已有 CPU 里程碑，尚未合并上述 V13 模型证据，也未按实际参赛身份改成最终文件名。

构建时实际解压到新目录，使用隔离 Python 执行业务并保存产物；仅解析路径配置不计作通过。本次环境为 Windows、Python 3.13.9；源码声明最低 Python 3.10，本次没有逐版本或跨操作系统验收。隔离进程未加载 site-packages，拒绝模型库、网络和子进程，模型/检测/GPU 调用均为 0。

| 组别 | 冻结案例 | 实际结果 |
| --- | --- | --- |
| 正常与边界 | 无旋转、四分之一周旋转、边界裁剪、空标签 | 4/4，通过；标签内容零修改 |
| 可修复 | 坐标错误、类别错误、缺失标签、旋转 metadata 错误 | 4/4，通过；各有 1 个真实标签或 metadata 修正 |
| 应拒绝 | 源 hash 不符、类别映射不一致、身份歧义、缺失来源 | 4/4，通过；正确拒绝，未创建修复副本 |

整体为 12/12；真实修复 4 例，非预期修改 0 例；30 个独立几何标准案例为 30/30，其中 29 个人工案例和 1 个冻结历史参考案例；12 份保存任务共 144/144 项独立复核；迁移 smoke 为 14/14。固定几何标准也包含预期错误路径，遇到预期错误并正确拒绝才算该案例通过。

可在用户选择的全新解压目录复现，输出必须位于不可变包之外，且名称尚未存在：

```powershell
Set-Location '<解压目录>\DefectResearcher-CPU-v1'
python -I -S -B tools/migration_smoke_v1.py --output '..\smoke-evidence-new'
```

以新产出的 `migration_acceptance.json`、每例业务产物和独立复核回执判断此次结果。上述现有记录只证明同一台机器换路径实际运行；另一台机器、完整 AGH 安装、Provider/MCP 配置和权限迁移均待验证。CPU 包不包含模型账户或 AGH 运行时，不能用此命令重演 Agnes 会话。

## 5. 文件清单、环境与证据入口

以下路径相对 `E:\PythonProject\AGH_\defect_researcher`。既有模型证据以冻结副本和对应 hash 为准；列出的工作区源码不自动替代当时执行版本。

| 文件或目录 | 用途 |
| --- | --- |
| `defect_researcher/comparison_case_runtime_v13.py`、`comparison_protocol_v13.py`、`comparison_mcp_server_v13.py` | 固定句柄/预算的动作后端、报告协议及 MCP 传输 |
| `run_comparison_mcp_v13.py`、`agent/comparison_case_task_v13.md` | 服务启动入口和受限模型任务说明 |
| `tools/comparison_scope_guard_v13.mjs`、`run_comparison_suite_v13.mjs` | AGH 调用范围与原始请求/会话记录；重新启动真实运行需要独立配置和明确预算，不由 CPU smoke 触发 |
| `tools/verify_comparison_case_v13.py`、`verify_comparison_model_v13.py`、`verify_comparison_runtime_v13.py` | 分别保存业务、模型工程、原运行来源核验口径；原失败检查器保留 |
| `outputs/comparison-implementation-v13-diagnostic/freeze.json`、`source_lock.json`、`source/` | V13 执行来源完整清单及冻结副本；freeze SHA256：`b05f74c5cd4a88a06204844d38301ca67a38fc259845636e64502349cebcd51e` |
| `outputs/comparison-suite-v13-diagnostic/model_runs/cmp_6b357026ab64462d9163524a96b4de2f/` | `run_result.json`、官方 `session.jsonl`、`session.html`、`runtime_binding.json`；真实模型调用、审批、结果、标题与运行进程记录 |
| `outputs/comparison-suite-v13-diagnostic/runtime/trials/cmp_6b357026ab64462d9163524a96b4de2f/` | 登记、动作/预算日志、领域副本及核验、`candidate.json`、`gate.json`、`publication.json`、`completion.json` |
| `outputs/comparison-suite-v13-diagnostic/closure_summary.json`、`final_closure_verification.json` | 10/10 与 19/19 详细结果、原联合失败和未运行分支；没有用单个完成文件代替完整验收 |
| `docs/comparison-runtime-acceptance-v14.md` | 新运行来源判据与旧 V13 补充复核的解释；原记录不回写 |
| `tools/build_submission_bundle_v1.py`、`migration_smoke_v1.py` | CPU 白名单构建和真实新路径复现入口 |
| `outputs/submission-bundle-v1-r1-exclusive/build_receipt.json`、`migration-evidence/`、`artifact_manifest.json` | 包大小/hash、扫描与实际迁移结果、完整本地证据清单 |
| `config/submission-team.json`、`config/example.json`、`pyproject.toml` | 用户提供的实际团队配置、公开路径示例和 Python 依赖声明 |
| `docs/delivery-package-v1.md`、`docs/用户录屏步骤_20261014.md` | CPU 交付范围及用户自行制作最终真实录屏的步骤 |

真实模型运行使用本机 AGH、Node.js 24.15.0、Python 后端及已配置 Agnes Provider。执行记录绑定 `outputs/agh-title-repair-v2/runtime/` 的本地构建、进程与三个运行 bundle；该运行时有本地修复，不能描述为未经修改的官方发行版。安装、账户、凭据和逐项审批需要在目标环境另行配置。公开 CPU 包仅需 Python 标准库。

最终整理材料时应明确选择源码、公开配置与必要证据，不复制整个 `.runtime`、`node_modules`、`config/local.json`、账户凭据、全量数据或权重。现有 CPU 包采用显式白名单，包内 `HASHES.json` 覆盖除自身以外的全部文件，manifest 自身 hash 在包外回执保存；可识别凭据规则扫描无命中，但不将规则扫描等同于任意秘密均不存在。

## 6. 来源、项目贡献与许可

| 来源 | 本主作品的使用与归属说明 |
| --- | --- |
| Agnes / AGH | 第三方模型与执行底座。模型请求、MCP、审批和官方会话机制来自上游；完整上游 `LICENSE`、`NOTICE` 按来源保存。项目没有把这些能力声明为团队原创 |
| 本项目新增实现 | 业务适配、独立解析几何参考、冻结标准案例、可信副本/拒绝规则、预算/来源登记、报告门禁及验收工具是项目代码。实际作者、成员分工及赛事期间贡献需团队核对，不凭代码存在补写学生独立完成声明 |
| 既有研究仓库 | 复用 `cableinspect_geometry.py` 和 `数据处理/7检查YOLO标注数据.py` 的必要 geometry/checker；来源为 `E:\PythonProject\projects\cableinspect-ad-code\project_start`。生产 geometry 与原 checker 共享实现，独立证据由另写的参考及固定答案提供 |
| 第三方许可 | CPU 包保留研究仓库上游 `license.txt` 的 Apache-2.0 文本；新增 geometry/checker 的逐文件作者、许可和再分发条件尚未确认，不能据上游文本推定所有新增文件已获授权。DefectResearcher 尚无明确代码再分发许可，状态 pending |
| 本地 AGH 修复 | 标题请求结算、用量保存及标题诊断事件名修正是本地工程变更，来源与构建在回执中保存。CPU 包记录修复说明，不分发 AGH 二进制，也不把修复声明为本主案例的领域创新 |
| 历史数据/模型 | CableInspect-AD、YOLO11n/Ultralytics 及既有研究性能仅可作为明确标注的历史补充；该历史工作曾使用检测模型，不能笼统宣称整个仓库历史只调用过 Agnes。本主四动作与 CPU 验收没有新检测调用 |

团队配置目前为 w、c、l 三个用户提供的成员标识，成员角色为空；指导教师为空，官方报名身份尚未核验。正式姓名、队长、组别、编号、真实分工和独立完成声明由成员本人确认。本文不自动映射原方案的 A/B/C 分工，不编造许可或资格。

## 7. 提交前待补字段

依据已保存的 2026-10-14 公开规则核验，AGH 核心连续步骤、真实模型证据、正常/边界/失败样例、可复现入口和来源说明应随主作品提供。当前材料可支撑上述有限任务的说明；最终参赛资格与完整合规仍需依实际报名和提交字段核对。

| 项目 | 当前状态与完成依据 |
| --- | --- |
| 主作品实际模型声明 | 本主版本模型为 Agnes，记录含模型名和真实调用链；历史 YOLO 工作若保留须独立声明。官方第三方模型规则冲突仍见 `docs/contest-rules-verification-20261014.md`，不把缩小范围写成全面合规证书 |
| 3–5 分钟真实核心演示 | 用户自行录制并上传；本地已有 CPU 录屏只作为业务复现里程碑，不能替代 AGH 核心连续调用演示。查看保存会话应标注为回放，不称现场新运行 |
| 视频链接 | pending；需评审可访问且无需登录参赛者账号的有效主链接，可另有备用链接/访问码 |
| 公开项目内容 | pending；已有草稿不等于发布成功，需真实平台、有效链接、截图和发布日期 |
| 最终提交包 | 用户自行制作；已有 CPU ZIP 未覆盖全部主证据，最终包需核对所选来源、许可、凭据和完整 hash 清单，大小不超过 200 MB |
| 文件命名与身份 | pending；按实际 `组别-参赛编号-队伍名称-队长姓名` 填写，本文未读取已登录报名/提交页 |
| 成员分工、独立完成与许可 | pending；由成员核实实际贡献和授权情况 |
| 外部提交完成 | pending；以官方成功回执、提交时间和锁定版本为准，本次未发布、发送、报名或提交 |

本版本适合据实介绍“Agnes 在 AGH 中完成受限标注副本修复，并由独立业务门禁约束报告”的作品。更广的 DefectResearcher 科研闭环、检测性能提升、全恢复与系统比较仍不属于本主版本已经完成的结论。
