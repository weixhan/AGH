# 同会话受限科研 MCP：显式故障恢复与证据约束的科学决策

本版本实现了新的两工具stdio适配器、固定动作状态机、后台工作器和AGH公共hook scope。当前是工程合约，通过CPU fixture与零连接官方manifest核验后才能冻结来源；本文件和proposal不表示服务已注册、模型已执行、GPU已运行或完整科研自治已成立。

文件为`defect_researcher/resolution_research_mcp_v1.py`、`defect_researcher/resolution_research_mcp_server_v1.py`、`run_resolution_research_mcp_v1.py`、`fixtures/resolution_research_mcp_protocol_v1.json`、`tools/resolution_research_scope_guard_v1.mjs`。独立核验使用另外的`tools/verify_resolution_recovery_v1.py`。具体接入字段见`config/mcp-resolution-research-v1-proposal.json`。

工具只有`research_action_v1`和`research_read_v1`，参数精确为`request_id`及`action`。ID的JSON Schema枚举来自实际部署protocol，仅允许一个固定值；动作也是枚举。模型不能传路径、预算、命令、方法参数、测试依赖、后端或任意续跑对象。新SID `dr-science-v1`通过官方零连接动态manifest检查，实际prefix为`mcp_dr_science_v1_4414bba3_`；两个qualified名称均在官方长度上限内。

第一步`audit_geometry`调用同一Python环境的`prepare_task`登记原域钟，然后实际执行新的`run_preflight`审计及独立几何闸门。通过后，模型调用`register_hypothesis`，保存依据、固定假设和运行前冻结的候选准则。主要假设检验已知成本第二组故障能否只补缺失960组、保持完整预测等价。分辨率候选只使用新`reference_640`与`reference_960`的`mAP50`、`mAP50_95`及`operating_point.normal_image_fp_rate`：AP不得下降、正常图误报率不得增加；`operating_point.normal_images`须为有效正分母。字段缺失、非有限或分母不足时，只能按证据不足停止，不接受候选，也不运行下一实验。

`start_registered_experiment`启动独立工作器，立即返回running；它只调用`run_until_fault`，执行reference640、reference960、fault640、fault960，并停在实际`recovery_pending`。它不调用便利入口`run_task`，不会自动恢复。主机等待owned worker终态后，用`followUp`或`steer`继续原AGH session，不能新开会话或重置期限。模型读取实际故障后，才可以明确选择`resume_registered_failure`一次，或`stop_insufficient_evidence`。未知、开放或失败检测器成本拒绝恢复。恢复工作器只调用`resume_task`，重开同一ledger、沿用原钟、只补resume960并完成业务独立验收。

终态读取之后，模型调用`independent_review`重新核验真实完成产物，取得实际metric字段与冻结准则支持的唯一决策动作，再明确选择`decide_stop_resolution`、`decide_retain_resolution`或`decide_insufficient_evidence`。不符合预登记准则的选择被拒绝。`publish_report`在发布前再次独立只读核验，并保存证据、模型实际选择、停止/保留计划与`new_experiment_registered=false`。失败实验可以形成诚实的停止研究报告，但不会得到虚假的真实恢复通过标记。

域预算从prepare前开始，1800秒包含准备、审计/几何、五组、业务Verifier与父completion；GPU300秒、3205预测入口（3200正式+5热身）、恢复最多一次。外层2400秒包括模型、审批、主机等待、终态阅读和后续科学报告。业务completion须已在原域期限内发布；较晚的只读报告必须仍在原外层期限内，不能延长域执行。报告明确保存两种期限及业务completion文件发布时间。

scope只守住13次primary请求，原生标题最多1次、total最多14由root runner的原始总账独立核验；标题usage或cost未知意味着联合验收失败。guard绑定第一个有效primary请求的唯一session，不允许相同workspace换session重新获得预算。每个动作只能一次；status只有至多1 running、1 fault、1 completed/failed，scope最多接纳3次status调用，独立模型review一次。禁止旧服务器、shell、browser、等待工具、另一个候选及平行推测动作。

部署需root在新目录生成`resolution_research_mcp_deployment_v1` protocol：精确字段为`schema_version`、`kind`、`request_id`、`task_id`、`workspace_root`、`started_epoch`、`started_monotonic`、`deadline_epoch`、`deadline_monotonic`、`contract_sha256`。`task_id`必须为`resolution-research-v1-`加固定ID，两个outer deadline分别等于原started加2400。root最终source lock须为`kind=resolution_research_mcp_source_lock_v1`、`status=passed_engineering_only`，每行精确为绝对`path`、`sha256`、`size_bytes`，包含五个MCP执行来源、coordinator/backend/ledger、独立verifier及本地config；它必须等这些来源稳定后创建。MCP不能创建或扩宽该pin。

```powershell
python -B run_resolution_research_mcp_v1.py --protocol '<pinned deployment protocol>' --expected-protocol-sha256 '<SHA256>' --source-lock '<accepted full source lock>' --expected-lock-sha256 '<SHA256>'
```

`Runtime.inspect_owned_worker()`以及同模块CLI的`--inspect`只供host观察running/fault/complete，不启动或恢复，不消耗模型status额度。host等待保留原2400秒期限；不能把该接口暴露为模型任意轮询工具。stdio launcher固定cwd和首个sys.path为项目ROOT，后台使用同一个`sys.executable`及ROOT cwd；coordinator还会严格核验完整sys.path和已安装依赖来源，漂移应拒绝执行，不伪造环境指纹。

工程检查命令：

```powershell
python -B -m unittest discover -s tests -p test_resolution_research_mcp_v1.py -v
node --test-isolation=none --test tools/test_resolution_research_scope_guard_v1.mjs
node tools/check_resolution_research_mcp_identity_v1.mjs
```

Python tests明确为fixture-only，没有真实parent completion；JS guard使用模拟hook payload，官方identity检查connections=0、model_requests=0、gpu_tasks=0。`node --test`默认进程隔离在本沙箱返回spawn EPERM，因此使用Node支持的同进程test isolation方式，不因权限错误省略测试或转称通过。实际AGH激活、模型/GPU联合验收和题名费用由root在来源稳定后另行执行。最终ZIP及最终录屏由用户自行制作，本任务不制作或外部发布。
