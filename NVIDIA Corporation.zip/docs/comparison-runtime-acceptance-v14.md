# V14：依据真实原生事件校验运行来源与标题用量

本次变更在V14登记之前完成。V13原执行、源码、归档、失败判定和6次实际模型请求保持不变，其冻结SHA256为`b05f74c5cd4a88a06204844d38301ca67a38fc259845636e64502349cebcd51e`。

V13真实会话的`turn/end`只有结束原因和最后助手序号，没有`turn`字段。旧检查器以及它的人工fixture错误地假设该字段存在。V14改为将原生标题请求的`startSeq`精确绑定唯一可信`turn/start`的序号，并核对该start的turn、同lane、同模型/route、后续completed end以及原子标题结算；缺失、混合或重复轮次均拒绝。

标题是辅助会话名称，内容格式校验与主业务正确性、实际模型用量分别记录。V14只允许两种标题终态：generated，或failed且明确reason=invalid-title。后一种须同时具备可信真实provider发送、2xx response、实际非零token用量、正常时钟，无取消、重复、非法usage或interrupted。其他标题失败及未知用量仍使联合验收失败。报告始终输出原生标题status/reason以及`title_generated=false`，不把格式失败称为标题生成成功。

业务独立核验、运行进程与bundle绑定、固定来源、每项Allow once及7请求/120秒总预算保持原约束。新的两分支诊断、9次试跑和36次正式比较使用同一V14判据；本次只读调试旧V13记录的结果不回写原失败，也不计作V14新模型实测。
