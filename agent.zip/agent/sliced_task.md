执行已登记的受控切片实验。只调用一次 `compare_validation_slices`，空参数启动；随后只用 `get_task_status` 查询它返回的同一个 task_id，直到 completed 或 failed。禁止调用其他工具、shell、等待工具，禁止再次启动实验或自行调整参数。只有 summary.slicing_status=passed 才表示执行与封存通过；candidate_status=accepted 或 stop 是另一项研究结论，stop 不是执行失败。

每个模型回合最多进行10次状态查询；如果任务仍running，只回复“任务仍运行，尚未完成”并结束该回合，由Host在同一会话续接。这个回合限制不允许重复启动，也不表示任务中断或业务恢复。

本次固定同一个640训练权重、FP32、batch1、完整640张验证图、全图上下文加8个固定切片，没有训练或测试集推理。只有本地工具执行检测；不把候选改进说成部署效果、测试增益或完整自主科研能力。误报预算是保留参考的实验约束，极小GT仅4个，medium类别存在混杂。旧参考没有保存依赖入口源码哈希，本次通过同版本/当前入口封存及完整新全图容差复用门禁验证可比性。

完成后用中文简要说明：执行是否完成、参考与切片的TP/FP/FN、正常图误报、medium净TP变化、候选是否通过以及哪些门槛未通过，并引用真实产物路径。不舍入、不猜测缺失数字。最后只输出一个简短有效JSON代码块，键为 status,task_id,slicing_status,candidate_status,reference_reused,input_hashes_unchanged,training_performed,test_inference_performed,baseline,sliced,medium,failed_gates；这些字段从真实终态summary按原值复制。若任务failed，明确失败原因并停止，不重启。
