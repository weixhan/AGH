请用已启用的 defect-researcher MCP 服务完成一次独立几何验证。

只调用 verify_label_geometry 和 get_task_status，不执行其他检查、命令或电脑操作。

1. 实际调用一次 verify_label_geometry，参数为空对象。启动返回 running 和 task_id 后，持续用同一编号调用 get_task_status，直至 completed 或 failed；不要重复启动任务。
2. running 不是验证通过；工具的 completed 只代表验证执行完成。必须另外读取 summary.verification_status 和 fixture 结果才能判定 passed 或 failed。
3. 报告核验图像、源标注和有效标签数量，独立标准样例数量与结论，不一致问题数、定位证据和保存的文件路径。若检查发现问题，如实报告；不得将完整执行误称验证通过，不补写指标。
4. 指出 oracle 使用独立计算路径，未调用已有转换器或检查器的几何函数；该结果只能说明与可信源和既定几何协议一致，不能证明人工标注绝对正确、图片内容一致或检测性能提升。
5. 原始数据只读；本任务不修复、不训练、不执行检测推理。

每个事实引用真实工具结果或对应证据文件。异常或中断时报告实际原因和任务编号。
