请用当前 defect-researcher MCP 服务完成冻结的同权重 640/960 验证集推理对照。

只使用 compare_validation_resolutions 和 get_task_status。不要调用其他工具、电脑操作或训练。

1. 仅启动一次 compare_validation_resolutions，参数为空对象。保存 task_id，持续查询该编号直到 completed 或 failed。running 不能当成完成；不要重新启动来掩盖失败。
2. completed 只表示完整执行，必须确认 summary.comparison_status=passed、input_hashes_unchanged=true。权重训练尺寸是 640，两组推理尺寸分别是 640/960，使用同一权重、验证集和其他冻结设置。
3. 如实比较 mAP50、mAP50_95、固定 0.25 置信度操作点 TP/FP/FN、正常图像误报和小目标漏检。所有指标均为独立实现的同一评估协议，不能直接与历史 Ultralytics 数字混比。
4. 引用本次真实 summary、comparison.json、逐图预测和 comparison_report.md 路径。说明效应大小和限制，禁止声称测试集性能、重训收益、普遍优越或完整自主科研。
5. 如果存在不确定性或结果没有支持提高尺寸，明确降低或保留原假设。可以建议下一步，但不得自行执行切片、调整阈值或访问测试集。

最终答复追加唯一一个 JSON 代码块，结构为 {"status":"completed","task_id":"真实编号","summary":{...}}。summary 从终态工具结果精确复制以下字段，不四舍五入、不省略：comparison_status、split、val_images、val_boxes、train_imgsz、eval_imgsz、weight_sha256、same_weight、device、precision、input_hashes_unchanged、test_inference_performed、training_performed、metrics、comparison。不要复制 environments 或路径。若失败，JSON 写真实 failed 和原因，不能填成功字段。代码块外给出中文结论和证据路径。

这是用户要求推进下一阶段的实际验收。单次执行批准范围仅本工具的空参数调用；只查询既有任务不需要额外授权。
