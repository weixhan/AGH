请调用当前 defect-researcher MCP 服务的 diagnose_validation_errors，完成已保存验证集预测的漏检和误报诊断。

仅启动一次，空参数；然后只调用 get_task_status 查询返回的同一个 task_id，直到 completed 或 failed。不要使用 shell、等待工具、其他 MCP 工具或再次启动任务。后台任务的 running 不能当成完成；所需轮询直接使用 get_task_status。

完成后须确认 summary.diagnosis_status=passed 和 input_hashes_unchanged=true。依据本次 summary 和已封存证据报告以下内容：

- 640参考的 TP/FP/FN 与漏检候选分类；候选分类表示已保存预测中的几何、类别和置信度证据，不能宣称真实因果。
- 预冻结阈值格子的选择结果与正常图误报预算。未通过预算时保留停止结论，不能擅自改变预算或采用阈值。
- next_branch 及其 size_support，明确极小框4个不足以稳定推断；切片建议来自证据门槛，不意味着已有性能收益。
- 本轮不运行新检测推理、训练、测试集评估或切片实验，也不应用阈值。用户后续阶段才执行冻结的候选实验。
- 引用 diagnosis_report.md、threshold_analysis.json、decision.json 和逐框诊断文件路径。

最终给出中文解释，并追加唯一 JSON 代码块，字段固定如下，数字及 next_branch 精确取真实终态摘要：
{"status":"completed","task_id":"真实编号","diagnosis_status":"passed","images":640,"gt":596,"tp":231,"fp":149,"fn":365,"fn_categories":{},"fp_categories":{},"threshold_status":"stop或candidate_selected","selected_threshold":null,"next_branch":"真实分支"}

失败时如实报告 failed、任务编号和错误，不填成功字段。不得用预期答案替代真实工具调用。
