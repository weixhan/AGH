请实际调用本项目的 audit_dataset 工具，检查 CableInspect-AD 数据与现有冻结权重的来源。

audit_dataset 会立即返回 running 和 task_id。随后调用 get_task_status 查询同一 task_id。只有返回 completed 才报告审计通过；running 时建议间隔约 5 秒继续查询，直至 completed 或 failed，失败时说明实际原因。不要重复启动多个审计。若本轮受到中断或执行限制而无法继续，明确给出任务编号和当前步骤，不补写结果。

读取最终工具返回的 status、summary、evidence、artifacts、errors 和 limitations：

1. 若审计通过，报告核验的图像数量、标注数量、验证集可访问性，以及保存的审计证据路径。
2. 若失败，报告实际错误及其所在步骤，不声明通过，不自动修改数据，不启动模型推理。
3. 明确这是数据与来源审计。共享几何函数的检查器不构成独立验证器，审计结果不等于检测性能提升。
4. 每个事实引用真实工具结果或证据文件，不填写未得到的指标。

本任务只需完成一次审计；后续实验另行登记。
