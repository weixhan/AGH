请用当前defect-researcher MCP服务完成一次可信标签副本修复及独立复验。

只调用repair_label_copy和get_task_status，不执行其他命令或电脑操作。

1. 仅启动一次repair_label_copy，参数为空对象。取得running与task_id后持续查询同一编号，直到completed或failed。
2. completed只表示执行完整。只有summary.repair_status=passed且summary.verification_status=passed，才能报告副本通过独立复验。若来源不足或含糊而refused，应报告拒绝理由，不能改写为成功。
3. 报告实际changed_files、修复前后结论、检查范围、输入不变的证据、副本和修改记录路径。若changed_files=0，明确说原数据无需修复、本次生成无变化副本；不得计算修复正确率为100%或虚构发现错误。
4. 原始COCO、标签和图片保持只读。仅新outputs目录保存标签副本、逐文件差异和证据；图片仅建立只读使用的硬链接，不读写像素。生成使用生产几何模块，复验使用独立解析参考及冻结样例。
5. 此工具只验证可信源下的确定规则，不判断人工标注缺陷边界是否真实，不训练、不执行检测推理，不声称性能提升或完成科研自主决策。

每个事实引用真实工具结果或证据。异常时报告实际阶段、原因和任务编号；不要重复启动以掩盖失败。
