"""Deadline-anchored V2 implementation of the two-tool MCP stdio transport for the bounded research workflow.

This adapter does not expose the old seven-tool research server. Its arguments
are identifiers and a frozen CPU-only budget; paths remain local configuration.
The public workflow API remains V1. Implementation V2 binds the deadline-aware
worker explicitly and never accepts clock anchors or deadline overrides from
the model.
Each UTF-8 line is one JSON-RPC message or batch. Production stdout is reserved
for protocol frames, including while the runtime's worker is active.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import os
from pathlib import Path
import re
import sys
from typing import Any, BinaryIO

from .research_protocol_v1 import load_protocol, validate_request


PROTOCOL_VERSION = "2025-03-26"
SUPPORTED_PROTOCOL_VERSIONS = {PROTOCOL_VERSION, "2024-11-05"}
SERVER_NAME = "defect-researcher-bounded-workflow-v2"
SERVER_VERSION = "2.0.0"
RUN_TOOL_NAME = "run_bounded_research_workflow_v1"
STATUS_TOOL_NAME = "get_research_workflow_status_v1"
WORKFLOW_ID_PATTERN = r"^research-workflow-v1-[A-Za-z0-9][A-Za-z0-9_-]{0,63}$"
_WORKFLOW_ID = re.compile(WORKFLOW_ID_PATTERN)
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
_REQUEST_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$"


def _tools() -> list[dict]:
    protocol = load_protocol()
    caps = protocol["budget_caps"]
    return [
        {
            "name": RUN_TOOL_NAME,
            "description": (
                "Start one bounded CPU-only research workflow on a frozen isolated "
                "synthetic LabelGuard case and sealed historical validation evidence. "
                "Returns promptly with workflow_id and running; poll only "
                "get_research_workflow_status_v1 for that ID. A fresh independent "
                "publication check is required for completed. No detector inference, "
                "training, GPU, network model request, caller paths, resume or new "
                "budget is supported. Research refusal or insufficient evidence is "
                "a valid completed report; inspect research_status and evidence claims."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {
                    "request_id": {"type": "string", "pattern": _REQUEST_ID_PATTERN,
                                   "maxLength": 64},
                    "case_id": {"type": "string",
                                "enum": protocol["case_specification"]["case_ids"]},
                    "budget": {
                        "type": "object",
                        "properties": {
                            "domain_invocations": {"type": "integer", "minimum": 0,
                                                   "maximum": caps["domain_invocations"]},
                            "wall_seconds": {"type": "number", "exclusiveMinimum": 0,
                                             "maximum": caps["wall_seconds"]},
                            "gpu_seconds": {"type": "number", "enum": [0]},
                            "model_requests": {"type": "integer", "enum": [0]},
                        },
                        "required": ["domain_invocations", "wall_seconds",
                                     "gpu_seconds", "model_requests"],
                        "additionalProperties": False,
                    },
                },
                "required": ["request_id", "case_id", "budget"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": False, "destructiveHint": False,
                            "idempotentHint": False, "openWorldHint": False},
        },
        {
            "name": STATUS_TOOL_NAME,
            "description": (
                "Read one bounded workflow started by run_bounded_research_workflow_v1. "
                "Completed includes fresh independent artifact verification and "
                "evidence-linked claims; running is not completion. This tool cannot "
                "start, resume, repair or increase the workflow budget."
            ),
            "inputSchema": {
                "type": "object",
                "properties": {"workflow_id": {"type": "string",
                                                "pattern": WORKFLOW_ID_PATTERN,
                                                "maxLength": 85}},
                "required": ["workflow_id"],
                "additionalProperties": False,
            },
            "annotations": {"readOnlyHint": True, "destructiveHint": False,
                            "idempotentHint": True, "openWorldHint": False},
        },
    ]


def _valid_id(value: Any) -> bool:
    # The supported AGH stdio contract uses string or integer request IDs.
    return type(value) is str or type(value) is int


def _json_value(value: Any) -> bool:
    if value is None or type(value) in (str, bool, int):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(_json_value(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and _json_value(item) for key, item in value.items())
    return False


def _error(request_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": request_id,
            "error": {"code": code, "message": message}}


def _result(request_id: Any, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _arguments(name: str, arguments: Any) -> dict:
    if type(arguments) is not dict:
        raise ValueError("Tool arguments must be an object")
    if name == RUN_TOOL_NAME:
        if set(arguments) != {"request_id", "case_id", "budget"}:
            raise ValueError("Run requires exactly request_id, case_id and budget")
        value = validate_request({"schema_version": 1, "workflow_version": 1,
                                  **copy.deepcopy(arguments)})
        return {field: value[field] for field in ("request_id", "case_id", "budget")}
    if set(arguments) != {"workflow_id"} or type(arguments["workflow_id"]) is not str:
        raise ValueError("Status requires exactly one safe workflow_id")
    if _WORKFLOW_ID.fullmatch(arguments["workflow_id"]) is None:
        raise ValueError("workflow_id is outside the bounded workflow namespace")
    return copy.deepcopy(arguments)


class ResearchMCPServer:
    """One initialized stdio session with exactly two constrained tools."""

    def __init__(self, configuration: dict | None = None,
                 config_path: str | Path | None = None, runtime: Any = None):
        self.configuration = copy.deepcopy(configuration)
        self.config_path = config_path
        self.runtime = runtime
        self.initialized = False
        self.ready = False
        self.protocol_version = PROTOCOL_VERSION

    def handle_message(self, message: Any) -> dict | list | None:
        if not _json_value(message):
            return _error(None, -32600, "Invalid JSON-RPC value")
        if type(message) is list:
            if not message:
                return _error(None, -32600, "Invalid request: empty batch")
            responses = []
            for item in message:
                response = self._handle_request(item)
                if response is not None:
                    responses.append(response)
            return responses or None
        return self._handle_request(message)

    def _handle_request(self, message: Any) -> dict | None:
        if type(message) is not dict:
            return _error(None, -32600, "Invalid request: expected an object")
        request_id = message.get("id")
        response_id = request_id if _valid_id(request_id) else None
        if (set(message) - {"jsonrpc", "id", "method", "params"}
                or message.get("jsonrpc") != "2.0"
                or type(message.get("method")) is not str):
            return _error(response_id, -32600, "Invalid JSON-RPC request")
        if "id" in message and not _valid_id(request_id):
            return _error(None, -32600, "Request ID must be a string or integer")
        is_notification = "id" not in message
        method = message["method"]
        params = message.get("params", {})
        if type(params) is not dict:
            return None if is_notification else _error(request_id, -32602,
                                                       "Parameters must be an object")
        # Notifications never execute a tool, even after initialization.
        if is_notification:
            if method == "notifications/initialized" and self.initialized and not params:
                self.ready = True
            return None
        if method == "ping":
            return _result(request_id, {}) if not params else _error(
                request_id, -32602, "Ping accepts an empty parameters object")
        if method == "initialize":
            if self.initialized:
                return _error(request_id, -32600, "Session is already initialized")
            client = params.get("clientInfo")
            if (set(params) - {"protocolVersion", "capabilities", "clientInfo", "_meta"}
                    or type(params.get("protocolVersion")) is not str
                    or not params["protocolVersion"]
                    or type(params.get("capabilities")) is not dict
                    or type(client) is not dict
                    or type(client.get("name")) is not str or not client["name"]
                    or type(client.get("version")) is not str or not client["version"]
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "Invalid initialize parameters")
            self.initialized = True
            requested = params["protocolVersion"]
            self.protocol_version = (requested if requested in SUPPORTED_PROTOCOL_VERSIONS
                                     else PROTOCOL_VERSION)
            return _result(request_id, {
                "protocolVersion": self.protocol_version,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            })
        if not self.ready:
            return _error(request_id, -32002,
                          "Complete initialize and notifications/initialized first")
        if method == "tools/list":
            if (set(params) - {"cursor", "_meta"} or params.get("cursor") is not None
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "This tool directory has no cursor")
            tools = _tools()
            if self.protocol_version == "2024-11-05":
                for tool in tools:
                    tool.pop("annotations")
            return _result(request_id, {"tools": tools})
        if method == "tools/call":
            if (set(params) - {"name", "arguments", "_meta"}
                    or type(params.get("name")) is not str
                    or params["name"] not in {RUN_TOOL_NAME, STATUS_TOOL_NAME}
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "Unknown tool or call parameters")
            name = params["name"]
            try:
                arguments = _arguments(name, params.get("arguments"))
            except (TypeError, ValueError):
                return _error(request_id, -32602, "Invalid bounded tool arguments")
            return _result(request_id, self._run_tool(name, arguments))
        return _error(request_id, -32601, "Method not found")

    def _run_tool(self, name: str, arguments: dict) -> dict:
        expected_id = ("research-workflow-v1-" + arguments["request_id"]
                       if name == RUN_TOOL_NAME else arguments["workflow_id"])
        stage = "runtime_initialization"
        try:
            if self.runtime is None:
                from .research_mcp_runtime_v2 import Runtime
                self.runtime = Runtime(configuration=copy.deepcopy(self.configuration),
                                       config_path=self.config_path)
            stage = "workflow_start" if name == RUN_TOOL_NAME else "workflow_status"
            report = (self.runtime.start(arguments) if name == RUN_TOOL_NAME
                      else self.runtime.get_status(arguments))
            if type(report) is not dict or not _json_value(report):
                raise ValueError("Runtime report must be a finite JSON object")
            report = copy.deepcopy(report)
            if report.get("status") not in {"running", "completed", "failed"}:
                raise ValueError("Runtime report has an unknown status")
            if report.get("workflow_id") != expected_id:
                raise ValueError("Runtime workflow ID differs from the requested workflow")
            if report["status"] == "completed":
                verification = report.get("verification")
                if (type(verification) is not dict or verification.get("status") != "passed"
                        or type(verification.get("checks_total")) is not int
                        or verification["checks_total"] < 1
                        or type(verification.get("checks_passed")) is not int
                        or verification["checks_passed"] != verification["checks_total"]
                        or type(verification.get("completion_sha256")) is not str
                        or _SHA256.fullmatch(verification["completion_sha256"]) is None):
                    raise ValueError("Completed report lacks independent publication verification")
            content = json.dumps(report, ensure_ascii=False, allow_nan=False)
            failed = report["status"] == "failed"
        except Exception as exc:
            failed = True
            content = json.dumps({
                "status": "failed", "workflow_id": expected_id,
                "errors": [{"stage": stage, "type": type(exc).__name__,
                            "message": str(exc)}],
            }, ensure_ascii=False, allow_nan=False)
        return {"content": [{"type": "text", "text": content}], "isError": failed}


def _reject_constant(value: str) -> None:
    raise ValueError("Nonfinite JSON constant")


def _finite_float(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Nonfinite JSON number")
    return number


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON object key")
        value[key] = item
    return value


def serve(configuration: dict | None = None, *, config_path: str | Path | None = None,
          runtime: Any = None, stdin: BinaryIO | None = None,
          stdout: BinaryIO | None = None) -> None:
    source = sys.stdin.buffer if stdin is None else stdin
    destination = sys.stdout.buffer if stdout is None else stdout
    if stdout is None:
        # This is process-wide and lasts until exit so worker output cannot
        # race a per-call stdout context and corrupt protocol frames.
        sys.stdout = sys.stderr
    server = ResearchMCPServer(configuration, config_path, runtime)
    for line in source:
        try:
            message = json.loads(line.decode("utf-8"), parse_constant=_reject_constant,
                                 parse_float=_finite_float, object_pairs_hook=_unique_object)
            response = server.handle_message(message)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            response = _error(None, -32700, "Parse error: expected strict UTF-8 JSON")
        except Exception:
            response = _error(None, -32603, "Internal server error")
        if response is not None:
            encoded = json.dumps(response, ensure_ascii=True, separators=(",", ":"),
                                 allow_nan=False).encode("utf-8")
            destination.write(encoded + b"\n")
            destination.flush()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Deadline-anchored bounded research MCP implementation V2 (workflow API V1)")
    parser.add_argument("--config", type=Path, help="Local configuration JSON path")
    parser.add_argument("--source-lock", type=Path, required=True,
                        help="Local implementation source lock JSON path")
    parser.add_argument("--expected-lock-sha256", required=True,
                        help="Pinned SHA256 of the implementation source lock")
    args = parser.parse_args(argv)
    if _SHA256.fullmatch(args.expected_lock_sha256) is None:
        parser.error("--expected-lock-sha256 must be 64 lowercase hexadecimal characters")
    try:
        source_lock = args.source_lock.resolve(strict=True)
        os.environ["DEFECT_RESEARCH_MCP_SOURCE_LOCK_PATH"] = str(source_lock)
        os.environ["DEFECT_RESEARCH_MCP_SOURCE_LOCK_SHA256"] = args.expected_lock_sha256
        from .research_mcp_runtime_v2 import Runtime
        runtime = Runtime(config_path=args.config)
        serve(runtime=runtime)
    except (BrokenPipeError, KeyboardInterrupt):
        pass
    except Exception as error:
        print(f"Bounded research MCP startup refused: {type(error).__name__}: {error}",
              file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
