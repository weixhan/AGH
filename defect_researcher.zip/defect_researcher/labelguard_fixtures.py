"""Build isolated LabelGuard fixtures from frozen source and golden literals.

This module never imports a geometry implementation to create an answer. The
production module is copied as an input for the real repair tool, then hashed.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil

FIXTURE_PATH = Path(__file__).resolve().parents[1] / "fixtures" / "labelguard_cases.json"
EXPECTED_FIXTURE_SHA256 = "3dd74146b0ad7f481ca1d5d3adaa5353182ff999b66d0e9f7a32472c54fefa6b"
CASE_IDS = (
    "normal_unrotated", "normal_quarter_turn", "normal_clipped", "normal_empty_label",
    "repair_coordinates", "repair_class", "repair_missing_label", "repair_metadata_rotation",
    "refuse_source_hash", "refuse_class_mapping", "refuse_ambiguous_identity", "refuse_missing_source",
)
COUNT_KEYS = (
    "images", "normal_images", "abnormal_images", "annotations", "source_annotations",
    "nonzero_rotation_attributes", "rotated_annotations", "clipped_annotations", "invalid_annotations",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def load_case_spec() -> dict:
    if sha256(FIXTURE_PATH) != EXPECTED_FIXTURE_SHA256:
        raise ValueError("Frozen LabelGuard spec SHA256 does not match its pinned reference")
    value = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
    if value.get("schema_version") != 1 or value.get("synthetic_only") is not True:
        raise ValueError("LabelGuard fixtures must identify schema 1 and synthetic-only provenance")
    cases = value.get("cases", [])
    if tuple(case["id"] for case in cases) != CASE_IDS:
        raise ValueError("All twelve frozen cases must be retained in their declared order")
    counts = {group: sum(case["group"] == group for case in cases)
              for group in ("normal", "repairable", "refused")}
    if counts != value.get("denominators") or counts != {"normal": 4, "repairable": 4, "refused": 4}:
        raise ValueError("LabelGuard acceptance requires fixed 4/4/4 denominators")
    return value


def snapshot_inputs(configuration: dict) -> dict:
    """Record all original bytes, including the copied production module."""
    result = {}
    for key in ("research_root", "dataset_root", "raw_root", "split_dir"):
        root = Path(configuration[key])
        for path in sorted(root.rglob("*")):
            if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
                raise ValueError("Linked fixture inputs are not accepted")
            if path.is_file():
                role = key + "/" + path.relative_to(root).as_posix()
                result[role] = {"path": str(path), "size_bytes": path.stat().st_size, "sha256": sha256(path)}
    return result


def label_tree_hash(dataset: Path, split: str) -> str:
    digest = hashlib.sha256()
    for path in sorted((dataset / "labels" / split).glob("*.txt")):
        digest.update(path.relative_to(dataset).as_posix().encode("utf-8") + b"\0")
        digest.update(path.read_bytes() + b"\0")
    return digest.hexdigest()


def build_case(case_root: Path, case: dict, spec: dict, production_research_root: Path) -> dict:
    """Create one new case, inject its declared fault, then freeze every input."""
    case_root = case_root.resolve()
    case_root.mkdir(parents=True, exist_ok=False)
    roots = {key: case_root / name for key, name in (
        ("research_root", "research"), ("dataset_root", "dataset"),
        ("raw_root", "raw"), ("split_dir", "splits"), ("output_root", "task_outputs"))}
    for path in roots.values():
        path.mkdir()
    production_module = production_research_root.resolve() / "cableinspect_geometry.py"
    if not production_module.is_file():
        raise FileNotFoundError("The configured research root lacks cableinspect_geometry.py")
    copied_module = roots["research_root"] / "cableinspect_geometry.py"
    shutil.copyfile(production_module, copied_module)
    if sha256(production_module) != sha256(copied_module):
        raise ValueError("Production geometry module changed while the fixture copied it")
    dataset, raw, splits = roots["dataset_root"], roots["raw_root"], roots["split_dir"]
    source, golden = case["source"], case["golden"]
    source_hashes, split_hashes, counts = {}, {}, {}
    golden_labels, golden_metadata = {}, {}
    categories = [{"id": int(key), "name": value} for key, value in spec["base"]["categories"].items()]
    width, height = source["dimensions"]
    for index, image_spec in enumerate(spec["base"]["images"], 1):
        split = image_spec["split"]
        name, image_id = image_spec["file_name"], image_spec["image_id"]
        source_json = f"cable_{index}.json"
        image_path = raw / name
        image_path.parent.mkdir()
        image_path.write_bytes(spec["base"]["image_bytes_utf8"].encode("utf-8"))
        for kind in ("images", "labels", "metadata"):
            (dataset / kind / split).mkdir(parents=True)
        shutil.copyfile(image_path, dataset / "images" / split / image_path.name)
        annotations, items = [], []
        if split == source["annotation_split"]:
            attributes = {"rotation": source["rotation"], "gradation": source["gradation"],
                          "anomaly_id": source["anomaly_id"]}
            annotations = [{"id": source["annotation_id"], "image_id": image_id,
                            "category_id": source["category_id"], "bbox": source["bbox"], "attributes": attributes}]
            items = [{"annotation_id": source["annotation_id"], "image_id": image_id,
                      "category_id": source["category_id"], "class": spec["base"]["categories"][str(source["category_id"])],
                      "source_json": source_json, "original_bbox": source["bbox"], "rotation": float(source["rotation"]),
                      "rotated_corners": [[float(value) for value in point] for point in golden["rotated_corners"]],
                      "hbb_xyxy": [float(value) for value in golden["hbb_xyxy"]],
                      "bbox_clipped": golden["bbox_clipped"], "geometry_version": "hbb_v1",
                      "gradation": source["gradation"], "anomaly_id": source["anomaly_id"]}]
        relative_label = f"labels/{split}/{image_path.stem}.txt"
        relative_meta = f"metadata/{split}/{image_path.stem}.json"
        label = golden["label"] if annotations else ""
        metadata = {"image": name, "source_json": source_json, "image_id": image_id,
                    "width": width, "height": height, "geometry_version": "hbb_v1", "annotations": items}
        (dataset / relative_label).write_text(label, encoding="utf-8", newline="\n")
        write_json(dataset / relative_meta, metadata)
        golden_labels[relative_label] = label
        golden_metadata[relative_meta] = metadata
        source_path = raw / source_json
        write_json(source_path, {"categories": categories,
                                "images": [{"id": image_id, "file_name": name, "width": width, "height": height}],
                                "annotations": annotations})
        source_hashes[source_json] = sha256(source_path)
        split_path = splits / f"{split}.txt"
        split_path.write_text(str(image_path) + "\n", encoding="utf-8", newline="\n")
        split_hashes[split_path.name] = sha256(split_path)
        count = {key: 0 for key in COUNT_KEYS}
        count.update(images=1, normal_images=int(not annotations), abnormal_images=int(bool(annotations)),
                     annotations=len(annotations), source_annotations=len(annotations),
                     nonzero_rotation_attributes=int(bool(annotations) and source["rotation"] != 0),
                     rotated_annotations=int(bool(annotations) and source["rotation"] % 360 != 0),
                     clipped_annotations=int(bool(annotations) and golden["bbox_clipped"]))
        counts[split] = count
    excluded = splits / "excluded_buffer.txt"
    excluded.write_bytes(b"")
    split_hashes[excluded.name] = sha256(excluded)
    (dataset / "data.yaml").write_text("path: " + dataset.as_posix() + "\n\ntrain: images/train\nval: images/val\ntest: images/test\n\nnames:\n"
                                      + "".join(f"  {int(key) - 1}: {value}\n" for key, value in spec["base"]["categories"].items()),
                                      encoding="utf-8", newline="\n")
    manifest = {"geometry_version": "hbb_v1", "raw_root": str(raw), "split_dir": str(splits), "output": str(dataset),
                "geometry_module_sha256": sha256(copied_module), "source_sha256": source_hashes,
                "split_sha256": split_hashes, "label_tree_sha256": {split: label_tree_hash(dataset, split) for split in spec["base"]["splits"]},
                "categories": spec["base"]["categories"], "counts": counts,
                "totals": {key: sum(count[key] for count in counts.values()) for key in COUNT_KEYS},
                "raw_images": 3, "raw_annotations": 1, "excluded_buffer_images": 0}
    mutation = case["mutation"]
    kind = mutation["kind"]
    if kind == "label_replace":
        (dataset / mutation["relative"]).write_text(mutation["value"], encoding="utf-8", newline="\n")
    elif kind == "label_remove":
        (dataset / mutation["relative"]).unlink()
    elif kind == "metadata_replace_geometry":
        path = dataset / mutation["relative"]
        value = json.loads(path.read_text(encoding="utf-8"))
        value["annotations"][0].update(mutation["values"])
        write_json(path, value)
    elif kind == "source_hash_mismatch":
        manifest["source_sha256"][mutation["file"]] = mutation["declared_sha256"]
    elif kind in ("source_category_name", "source_duplicate_image"):
        path = raw / mutation["file"]
        value = json.loads(path.read_text(encoding="utf-8"))
        if kind == "source_category_name":
            next(item for item in value["categories"] if item["id"] == mutation["category_id"])["name"] = mutation["value"]
        else:
            value["images"].append(dict(value["images"][0]))
        write_json(path, value)
        manifest["source_sha256"][mutation["file"]] = sha256(path)
    elif kind == "source_remove":
        (raw / mutation["file"]).unlink()
    elif kind != "none":
        raise ValueError("Unknown frozen fixture mutation")
    write_json(dataset / "manifest.json", manifest)
    configuration = {key: str(path) for key, path in roots.items()}
    configuration["weights_path"] = str(roots["research_root"] / "unused.pt")
    frozen = {"case_id": case["id"], "synthetic_only": True, "spec_sha256": EXPECTED_FIXTURE_SHA256,
              "production_module": {"source_path": str(production_module), "copy_path": str(copied_module),
                                    "sha256": sha256(copied_module)},
              "configuration": configuration, "golden_labels": golden_labels, "golden_metadata": golden_metadata,
              "files": snapshot_inputs(configuration)}
    snapshot = case_root / "frozen_inputs.json"
    write_json(snapshot, frozen)
    return {"configuration": configuration, "frozen": frozen, "snapshot_path": str(snapshot), "snapshot_sha256": sha256(snapshot)}
