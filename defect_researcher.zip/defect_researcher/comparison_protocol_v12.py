"""Preregistered, strict contracts for the isolated three-arm comparison.

Case identities and literal answers stay in the private protocol. Public tools
receive opaque trial handles only. This module uses only the standard library.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
import re
import uuid

ROOT = Path(__file__).resolve().parents[1]
CASE_PATH = ROOT / "fixtures" / "labelguard_cases.json"
CASE_SHA256 = "3dd74146b0ad7f481ca1d5d3adaa5353182ff999b66d0e9f7a32472c54fefa6b"
CASE_IDS = ("normal_unrotated", "normal_quarter_turn", "normal_clipped", "normal_empty_label",
            "repair_coordinates", "repair_class", "repair_missing_label", "repair_metadata_rotation",
            "refuse_source_hash", "refuse_class_mapping", "refuse_ambiguous_identity", "refuse_missing_source")
PILOT_CASES = ("normal_unrotated", "repair_coordinates", "refuse_source_hash")
ARMS = ("C", "U", "F")
ACTIONS = ("inspect_input", "verify_input", "repair_copy", "verify_copy", "read_science", "publish_report")
BUDGET = {"domain_invocations": 6, "model_requests": 7, "wall_seconds": 120,
          "gpu_seconds": 0, "detector_calls": 0}
CHECKLIST = ["inspect_input", "verify_input", "repair only when returned evidence permits",
             "verify_copy after actual repair", "read_science", "publish_report"]
TREATMENT = {"C": "deterministic checklist; actual model requests zero",
             "U": "model selects actions; no forced publication gate; voluntary verification available",
             "F": "same model task and tools; forced current-evidence publication gate"}
AUTHORIZATION_POLICY = "same bounded isolated-write authorization policy; U/F actual AGH Allow once, C actual host authorized_scope_once via MCP"
EVALUATION_SCOPE = "fixed artificial case population; no new detector, training or GPU execution"
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}\Z")
_FIELD = re.compile(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*\Z")
_HANDLE = re.compile(r"cmp_[0-9a-f]{32}\Z")

REPORT_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["schema_version", "trial_handle", "outcome", "target", "evidence_ids", "claims", "scope"],
    "properties": {
        "schema_version": {"type": "integer", "const": 1},
        "trial_handle": {"type": "string", "pattern": "^cmp_[0-9a-f]{32}$", "minLength": 36, "maxLength": 36},
        "outcome": {"type": "string", "enum": ["clean", "repaired", "refused"]},
        "target": {"type": "string", "enum": ["input", "copy", "none"]},
        "evidence_ids": {"type": "array", "minItems": 1, "maxItems": 6, "uniqueItems": True,
                         "items": {"type": "string", "minLength": 1, "maxLength": 128,
                                   "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$"}},
        "claims": {"type": "array", "minItems": 1, "maxItems": 32, "items": {
            "type": "object", "additionalProperties": False,
            "required": ["name", "field", "value", "evidence_id"],
            "properties": {"name": {"type": "string", "minLength": 1, "maxLength": 128},
                           "field": {"type": "string", "minLength": 1, "maxLength": 256,
                                     "pattern": "^[A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*)*$"},
                           "value": {},
                           "evidence_id": {"type": "string", "minLength": 1, "maxLength": 128,
                                           "pattern": "^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$"}}}},
        "scope": {"type": "object", "additionalProperties": False,
                  "required": ["synthetic_only", "historical_evidence_reused", "new_detector_calls", "gpu_seconds"],
                  "properties": {"synthetic_only": {"type": "boolean", "const": True},
                                 "historical_evidence_reused": {"type": "boolean"},
                                 "new_detector_calls": {"type": "integer", "const": 0},
                                 "gpu_seconds": {"type": "number", "const": 0}}},
    },
}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def _keys(value, keys, name):
    if type(value) is not dict or set(value) != set(keys):
        raise ValueError(name + " has missing or unknown fields")


def _identifier(value, name):
    if type(value) is not str or not _ID.fullmatch(value):
        raise ValueError(name + " is not a safe identifier")


def _finite_json(value, depth=0):
    if depth > 16:
        raise ValueError("Claim value is too deeply nested")
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float and math.isfinite(value):
        return
    if type(value) is list:
        for item in value:
            _finite_json(item, depth + 1)
        return
    if type(value) is dict and all(type(key) is str for key in value):
        for item in value.values():
            _finite_json(item, depth + 1)
        return
    raise ValueError("Claim values must be finite JSON")


def load_case_spec():
    if digest(CASE_PATH) != CASE_SHA256:
        raise ValueError("Frozen literal case specification changed")
    value = strict_json(CASE_PATH)
    if value.get("synthetic_only") is not True or tuple(case["id"] for case in value["cases"]) != CASE_IDS:
        raise ValueError("Literal case population changed")
    if value["denominators"] != {"normal": 4, "repairable": 4, "refused": 4}:
        raise ValueError("Literal denominators changed")
    return value


def validate_report(report, trial_handle=None):
    """Common schema safety only; intentionally does not assert claim truth."""
    _keys(report, REPORT_SCHEMA["required"], "Report")
    if type(report["schema_version"]) is not int or report["schema_version"] != 1:
        raise ValueError("Report schema_version must be integer 1")
    if type(report["trial_handle"]) is not str or not _HANDLE.fullmatch(report["trial_handle"]):
        raise ValueError("trial_handle must be an opaque comparison handle")
    if trial_handle is not None and report["trial_handle"] != trial_handle:
        raise ValueError("Report belongs to another trial")
    pairs = {"clean": "input", "repaired": "copy", "refused": "none"}
    if type(report["outcome"]) is not str or pairs.get(report["outcome"]) != report["target"]:
        raise ValueError("Report outcome/target pairing differs")
    evidence_ids = report["evidence_ids"]
    if type(evidence_ids) is not list or not 1 <= len(evidence_ids) <= 6:
        raise ValueError("Report must cite one to six evidence records")
    for identity in evidence_ids:
        _identifier(identity, "evidence_id")
    if len(set(evidence_ids)) != len(evidence_ids):
        raise ValueError("Report evidence IDs replayed")
    claims = report["claims"]
    if type(claims) is not list or not 1 <= len(claims) <= 32:
        raise ValueError("Report must contain one to 32 atomic claims")
    names = []
    for claim in claims:
        _keys(claim, ("name", "field", "value", "evidence_id"), "Claim")
        if type(claim["name"]) is not str or not 1 <= len(claim["name"]) <= 128:
            raise ValueError("Claim name length differs")
        if type(claim["field"]) is not str or len(claim["field"]) > 256 or not _FIELD.fullmatch(claim["field"]):
            raise ValueError("Claim field must be a dotted object field")
        if claim["evidence_id"] not in evidence_ids:
            raise ValueError("Claim cites evidence outside report evidence IDs")
        _finite_json(claim["value"])
        names.append(claim["name"])
    if len(set(names)) != len(names):
        raise ValueError("Atomic claim names replayed")
    scope = report["scope"]
    _keys(scope, ("synthetic_only", "historical_evidence_reused", "new_detector_calls", "gpu_seconds"), "Report scope")
    if scope["synthetic_only"] is not True or type(scope["historical_evidence_reused"]) is not bool:
        raise ValueError("Report must distinguish artificial inputs from historical evidence")
    if type(scope["new_detector_calls"]) is not int or scope["new_detector_calls"] != 0:
        raise ValueError("No new detector execution is authorized")
    if type(scope["gpu_seconds"]) not in (int, float) or scope["gpu_seconds"] != 0:
        raise ValueError("No GPU execution is authorized")
    return copy.deepcopy(report)


def validate_action_arguments(arguments):
    if type(arguments) is not dict or set(arguments) not in ({"trial_handle", "action"}, {"trial_handle", "action", "report"}):
        raise ValueError("Action contains missing or unknown fields")
    if type(arguments["trial_handle"]) is not str or not _HANDLE.fullmatch(arguments["trial_handle"]):
        raise ValueError("trial_handle must be an opaque comparison handle")
    if arguments["action"] not in ACTIONS:
        raise ValueError("Unknown comparison action")
    if (arguments["action"] == "publish_report") != ("report" in arguments):
        raise ValueError("Only publish_report accepts the required report")
    if "report" in arguments:
        validate_report(arguments["report"], arguments["trial_handle"])
    return copy.deepcopy(arguments)


def evaluate_candidate(report, evidence, *, trial_handle, require_verified=False, check_claims=True):
    """Lazy bridge to the independent stdlib gate, without loading a runtime."""
    from tools.verify_comparison_case_v12 import evaluate_candidate as evaluate
    return evaluate(report, evidence, trial_handle=trial_handle,
                    require_verified=require_verified, check_claims=check_claims)


def make_protocol(run_id, *, model, task_prompt, tool_catalog, source_paths,
                  generation_settings=None, stage="pilot"):
    """Create a private, source-bound plan before any trial is armed.

    Identical U/F prompts, models, settings, input case identities and action
    catalog are represented once, rather than as independently editable arms.
    """
    _identifier(run_id, "run_id")
    if stage not in ("pilot", "formal"):
        raise ValueError("Comparison stage must be pilot or formal")
    if type(model) is not dict or not model or type(task_prompt) is not str or not task_prompt.strip():
        raise ValueError("An explicit model and common nonempty task prompt are required")
    if type(tool_catalog) is not list or not tool_catalog:
        raise ValueError("The common actual tool catalog is required")
    load_case_spec()
    sources = []
    for name, path in sorted(source_paths.items()):
        resolved = Path(path).resolve()
        sources.append({"role": name, "path": str(resolved), "sha256": digest(resolved),
                        "size_bytes": resolved.stat().st_size})
    case_ids = PILOT_CASES if stage == "pilot" else CASE_IDS
    trials = []
    for index, case_id in enumerate(case_ids):
        order = ARMS[index % 3:] + ARMS[:index % 3]
        for arm in order:
            trials.append({"trial_id": f"{run_id}-{len(trials) + 1:02d}",
                           "trial_handle": "cmp_" + uuid.uuid4().hex,
                           "case_id": case_id, "arm": arm,
                           "forced_publication_gate": arm == "F"})
    protocol = {"schema_version": 1, "kind": "isolated_three_arm_comparison_v12",
                "run_id": run_id, "stage": stage, "synthetic_only": True,
                "case_specification_sha256": CASE_SHA256,
                "case_ids": list(case_ids), "trials": trials,
                "common": {"model": copy.deepcopy(model), "task_prompt": task_prompt,
                           "task_prompt_sha256": hashlib.sha256(task_prompt.encode("utf-8")).hexdigest(),
                           "tool_catalog": copy.deepcopy(tool_catalog),
                           "tool_catalog_sha256": hashlib.sha256(canonical(tool_catalog)).hexdigest(),
                           "generation_settings": copy.deepcopy(generation_settings or {}),
                           "budget": copy.deepcopy(BUDGET), "sources": sources,
                           "original_input_policy": "same immutable case files for all three arms",
                           "approvals": AUTHORIZATION_POLICY},
                "checklist": copy.deepcopy(CHECKLIST), "treatment": copy.deepcopy(TREATMENT),
                "denominators": {"planned_per_arm": len(case_ids), "recovery_time": "not_measured"},
                "evaluation_scope": EVALUATION_SCOPE}
    validate_protocol(protocol)
    return protocol


def validate_protocol(protocol):
    _keys(protocol, ("schema_version", "kind", "run_id", "stage", "synthetic_only", "case_specification_sha256",
                     "case_ids", "trials", "common", "checklist", "treatment", "denominators", "evaluation_scope"), "Protocol")
    if type(protocol["schema_version"]) is not int or protocol["schema_version"] != 1 or protocol["kind"] != "isolated_three_arm_comparison_v12":
        raise ValueError("Comparison protocol version differs")
    _identifier(protocol["run_id"], "run_id")
    expected = list(PILOT_CASES if protocol["stage"] == "pilot" else CASE_IDS)
    if protocol["stage"] not in ("pilot", "formal") or protocol["case_ids"] != expected or protocol["case_specification_sha256"] != CASE_SHA256:
        raise ValueError("Case selection changed")
    common = protocol["common"]
    _keys(common, ("model", "task_prompt", "task_prompt_sha256", "tool_catalog", "tool_catalog_sha256",
                   "generation_settings", "budget", "sources", "original_input_policy", "approvals"), "Common conditions")
    if (type(common["budget"]) is not dict or set(common["budget"]) != set(BUDGET)
            or any(type(common["budget"][key]) is not int or common["budget"][key] != value for key, value in BUDGET.items())
            or protocol["synthetic_only"] is not True):
        raise ValueError("Common scope or available budget changed")
    if (type(common["model"]) is not dict or not common["model"]
            or type(common["generation_settings"]) is not dict
            or type(common["tool_catalog"]) is not list or not common["tool_catalog"]
            or type(common["task_prompt"]) is not str or not common["task_prompt"].strip()):
        raise ValueError("Common model, prompt, settings and actual tool catalog must be explicit")
    _finite_json(common["model"])
    _finite_json(common["generation_settings"])
    sources = common["sources"]
    if type(sources) is not list or not sources:
        raise ValueError("Protocol must bind its implementation sources")
    roles, paths = [], []
    for source in sources:
        _keys(source, ("role", "path", "sha256", "size_bytes"), "Protocol source")
        if (type(source["role"]) is not str or not source["role"] or type(source["path"]) is not str
                or not Path(source["path"]).is_absolute() or type(source["sha256"]) is not str
                or re.fullmatch(r"[0-9a-f]{64}", source["sha256"]) is None
                or type(source["size_bytes"]) is not int or source["size_bytes"] < 0
                or digest(source["path"]) != source["sha256"] or Path(source["path"]).stat().st_size != source["size_bytes"]):
            raise ValueError("Protocol bound source changed or has an invalid record")
        roles.append(source["role"])
        paths.append(str(Path(source["path"]).resolve()))
    if len(set(roles)) != len(roles) or len(set(paths)) != len(paths):
        raise ValueError("Protocol source role or path is replayed")
    if (common["original_input_policy"] != "same immutable case files for all three arms"
            or common["approvals"] != AUTHORIZATION_POLICY or protocol["checklist"] != CHECKLIST
            or protocol["treatment"] != TREATMENT or protocol["evaluation_scope"] != EVALUATION_SCOPE):
        raise ValueError("Registered authorization, checklist, treatment or interpretation changed")
    if common["task_prompt_sha256"] != hashlib.sha256(common["task_prompt"].encode("utf-8")).hexdigest() or common["tool_catalog_sha256"] != hashlib.sha256(canonical(common["tool_catalog"])).hexdigest():
        raise ValueError("Common model task/tool hashes changed")
    trials = protocol["trials"]
    if type(trials) is not list or len(trials) != len(expected) * 3:
        raise ValueError("Fixed comparison denominator changed")
    handles, identities = [], []
    for index, trial in enumerate(trials):
        _keys(trial, ("trial_id", "trial_handle", "case_id", "arm", "forced_publication_gate"), "Trial")
        _identifier(trial["trial_id"], "trial_id")
        if type(trial["trial_handle"]) is not str or not _HANDLE.fullmatch(trial["trial_handle"]):
            raise ValueError("trial_handle must be an opaque comparison handle")
        case_index = index // 3
        order = ARMS[case_index % 3:] + ARMS[:case_index % 3]
        if trial["case_id"] != expected[case_index] or trial["arm"] != order[index % 3] or trial["forced_publication_gate"] is not (trial["arm"] == "F"):
            raise ValueError("Preregistered rotated trial order or gate treatment changed")
        handles.append(trial["trial_handle"])
        identities.append(trial["trial_id"])
    if len(set(handles)) != len(handles) or len(set(identities)) != len(identities):
        raise ValueError("Trial identity/handle replayed")
    if protocol["denominators"] != {"planned_per_arm": len(expected), "recovery_time": "not_measured"}:
        raise ValueError("Comparison denominators changed")
    return copy.deepcopy(protocol)
