"""Frozen FP32 resolution inference with a reservation for every predict entry.

Importing this module does not import torch or Ultralytics. Production callers
omit ``test_dependencies``; injected dependencies always mark returned evidence
as a fixture and cannot be accepted as a real experiment.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import inspect
import math
import os
from pathlib import Path
import platform
import sys
import time
from typing import Any, Callable

from .audit import _artifact_record
from .geometry_verifier import CATEGORIES


FROZEN_FIELDS = {
    "schema_version": 1, "split": "val", "expected_images": 640, "train_imgsz": 640,
    "eval_imgsz": [640, 960], "device": "0", "precision": "FP32", "batch": 1,
    "prediction_confidence": .001, "nms_iou": .7, "max_det": 300,
    "rect": False, "augment": False, "agnostic_nms": False,
    "operating_confidence": .25, "matching_iou": .5, "allow_tf32": False,
    "test_inference": False, "weight_change": False, "training_performed": False,
    "selection_data": "validation_only", "fallback": "fail_without_changing_protocol",
}
CONTROL_KEYS = ("imgsz", "batch", "conf", "iou", "max_det", "rect", "augment",
                "agnostic_nms", "quantize", "nms", "device")


@dataclass(frozen=True)
class TestDependencies:
    """Explicit Python-only injection; never exposed in a production MCP schema."""
    torch: Any
    model_factory: Callable
    ultralytics_version: str = "fixture-ultralytics"
    perf_counter: Callable = time.perf_counter
    fixture_only: bool = True


def _equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return (left.keys() == right.keys()
                and all(type(key) is type(next(k for k in right if k == key)) for key in left)
                and all(_equal(left[key], right[key]) for key in left))
    if type(left) is list:
        return len(left) == len(right) and all(_equal(a, b) for a, b in zip(left, right))
    return left == right


def _finite(value, *, nonnegative=True):
    return (type(value) in (int, float) and math.isfinite(value)
            and (not nonnegative or value >= 0))


def _validate_request(records, imgsz, protocol, step_id):
    if type(imgsz) is not int or imgsz not in (640, 960):
        raise ValueError("Only frozen eval_imgsz 640/960 are supported")
    if type(protocol) is not dict:
        raise ValueError("The frozen inference protocol must be a dictionary")
    for key, expected in FROZEN_FIELDS.items():
        if key not in protocol or not _equal(protocol[key], expected):
            raise ValueError(f"Frozen inference protocol changed: {key}")
    for key in ("nms", "quantize"):
        if key in protocol and protocol[key] is not None:
            raise ValueError(f"Frozen inference protocol requires exact null: {key}")
    if type(records) is not list or len(records) != 640:
        raise ValueError("A group must contain all 640 frozen validation images")
    if type(step_id) is not str or not step_id:
        raise ValueError("A server-owned step identity is required")
    ids = []
    for row in records:
        if (type(row) is not dict or row.get("split") != "val"
                or type(row.get("image_id")) is not str or not row["image_id"]
                or type(row.get("image_path")) is not str or not row["image_path"]
                or type(row.get("width")) is not int or row["width"] <= 0
                or type(row.get("height")) is not int or row["height"] <= 0
                or type(row.get("ground_truth")) is not list):
            raise ValueError("Invalid complete validation record")
        ids.append(row["image_id"])
    if len(set(ids)) != 640 or ids != sorted(ids):
        raise ValueError("Frozen validation IDs must be unique and sorted")


def _options(imgsz, directory):
    return {"imgsz": imgsz, "batch": 1, "device": "0", "half": False,
            "quantize": None, "nms": None, "conf": .001, "iou": .7, "max_det": 300,
            "rect": False, "augment": False, "agnostic_nms": False,
            "save": False, "save_txt": False, "save_crop": False, "save_json": False,
            "show": False, "verbose": False, "project": str(directory / "prediction_runtime"),
            "name": f"imgsz_{imgsz}", "exist_ok": True, "stream": False}


def _controls(model, torch, options, capture, *, require_input):
    classes = {key - 1: value for key, value in CATEGORIES.items()}
    if not _equal(model.names, classes):
        raise ValueError("Checkpoint class mapping changed")
    if next(model.model.parameters()).dtype != torch.float32:
        raise ValueError("Actual model parameters are not FP32")
    current_device = torch.cuda.current_device()
    if type(current_device) is not int or current_device != 0:
        raise ValueError("CUDA cost events must use the frozen current device 0")
    if (torch.backends.cuda.matmul.allow_tf32 is not False
            or torch.backends.cudnn.allow_tf32 is not False
            or torch.backends.cudnn.benchmark is not False
            or torch.backends.cudnn.deterministic is not True):
        raise ValueError("Effective TF32/cuDNN controls changed")
    predictor = model.predictor
    if predictor is None:
        if require_input:
            raise ValueError("Actual predictor is missing after prediction")
        return None
    effective = {}
    for key in CONTROL_KEYS:
        if not hasattr(predictor.args, key):
            raise ValueError(f"Actual predictor option is missing: {key}")
        actual = getattr(predictor.args, key)
        if not _equal(actual, options[key]):
            raise ValueError(f"Actual predictor option changed: {key}")
        effective[key] = actual
    if (type(predictor.model.fp16) is not bool or predictor.model.fp16 is not False
            or str(predictor.model.device) != "cuda:0"
            or not _equal(list(predictor.imgsz), [options["imgsz"], options["imgsz"]])):
        raise ValueError("Actual predictor FP32/device/imgsz changed")
    if require_input and (capture.get("dtype") != torch.float32
                          or capture.get("device") != "cuda:0" or capture.get("seen") is not True):
        raise ValueError("Actual inference input dtype/device was not observed as FP32 CUDA0")
    return effective


def _predictions(value, row):
    if Path(value.path).resolve() != Path(row["image_path"]).resolve():
        raise ValueError("Prediction source path changed")
    if not _equal(list(value.orig_shape), [row["height"], row["width"]]):
        raise ValueError("Prediction original dimensions changed")
    boxes = value.boxes
    xyxy, conf, classes = boxes.xyxy.cpu().tolist(), boxes.conf.cpu().tolist(), boxes.cls.cpu().tolist()
    if not (type(xyxy) is list and type(conf) is list and type(classes) is list
            and len(xyxy) == len(conf) == len(classes) and len(xyxy) <= 300):
        raise ValueError("Prediction tensor counts differ or exceed max_det")
    predictions = []
    for box, confidence, class_id in zip(xyxy, conf, classes):
        if (not _finite(class_id) or int(class_id) != class_id or int(class_id) not in range(7)
                or not _finite(confidence) or not .001 <= confidence <= 1
                or type(box) is not list or len(box) != 4 or any(not _finite(v) for v in box)
                or not 0 <= box[0] < box[2] <= row["width"]
                or not 0 <= box[1] < box[3] <= row["height"]):
            raise ValueError("Invalid predicted class/confidence/original-pixel box")
        predictions.append({"class_id": int(class_id), "xyxy": [float(v) for v in box],
                            "confidence": float(confidence)})
    speed = dict(value.speed)
    if any(not _finite(v) for v in speed.values()):
        raise ValueError("Invalid predictor speed metadata")
    return predictions, speed


def _callable_sources():
    from ultralytics.engine.model import Model
    from ultralytics.engine.predictor import BasePredictor
    from ultralytics.models.yolo.detect.predict import DetectionPredictor
    from ultralytics.utils import ops
    from ultralytics.utils.nms import non_max_suppression
    functions = {"YOLO.predict": Model.predict, "BasePredictor.preprocess": BasePredictor.preprocess,
                 "BasePredictor.inference": BasePredictor.inference,
                 "BasePredictor.setup_source": BasePredictor.setup_source,
                 "DetectionPredictor.postprocess": DetectionPredictor.postprocess,
                 "scale_boxes": ops.scale_boxes, "NMS": non_max_suppression}
    return {name: _artifact_record(Path(inspect.getsourcefile(function)).resolve())
            for name, function in functions.items()}


def infer_group(records, weights, imgsz, protocol, directory, ledger, step_id,
                *, test_dependencies=None):
    """Return score-compatible rows and actual environment for exactly one group.

    ``ledger.reserve(kind, step_id, image_id, imgsz)`` creates a durable ticket;
    ``ledger.check()`` rechecks the original deadline immediately before predict;
    ``ledger.closed(ticket, status, elapsed_seconds, gpu_seconds, **details)``
    records actual closed cost. Unknown GPU cost is None and always raises.
    """
    _validate_request(records, imgsz, protocol, step_id)
    if any(not callable(getattr(ledger, name, None)) for name in ("reserve", "check", "closed")):
        raise TypeError("Caller must provide the original shared reservation ledger")
    if test_dependencies is not None and (type(test_dependencies) is not TestDependencies
                                          or test_dependencies.fixture_only is not True):
        raise ValueError("Dependency injection is permitted only as an explicit fixture")
    directory = Path(directory).resolve(strict=True)
    if not directory.is_dir():
        raise ValueError("Caller-owned group directory is required")
    keys = {"YOLO_CONFIG_DIR": str(directory / "runtime_settings"),
            "YOLO_AUTOINSTALL": "false", "MPLBACKEND": "Agg"}
    prior = {key: os.environ.get(key) for key in keys}
    torch = model = hook = None
    capture = {}
    try:
        ledger.check()
        (directory / "runtime_settings").mkdir(exist_ok=True)
        os.environ.update(keys)
        if test_dependencies is None:
            import torch as torch_module
            import ultralytics
            from ultralytics import YOLO
            torch, factory = torch_module, YOLO
            ultra_version, counter = ultralytics.__version__, time.perf_counter
            real_detector = True
        else:
            torch, factory = test_dependencies.torch, test_dependencies.model_factory
            ultra_version, counter = test_dependencies.ultralytics_version, test_dependencies.perf_counter
            real_detector = False
        if not torch.cuda.is_available():
            raise RuntimeError("Frozen GPU protocol requires CUDA0; CPU fallback is forbidden")
        if not isinstance(torch.__version__, str) or type(ultra_version) is not str:
            raise ValueError("Actual dependency version metadata is malformed")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        model = factory(str(weights), task="detect")
        model.model.float()
        options = _options(imgsz, directory)
        _controls(model, torch, options, capture, require_input=False)

        def observe_input(module, arguments):
            if not arguments:
                raise ValueError("Actual model input tensor is missing")
            tensor = arguments[0]
            capture.update(dtype=tensor.dtype, device=str(tensor.device), seen=True)
            if tensor.dtype != torch.float32 or str(tensor.device) != "cuda:0":
                raise ValueError("Actual inference input tensor must be FP32 CUDA0")

        hook = model.model.register_forward_pre_hook(observe_input)
        completed_calls, gpu_total, elapsed_total = 0, 0., 0.

        def predict(row, kind):
            nonlocal completed_calls, gpu_total, elapsed_total
            _controls(model, torch, options, capture, require_input=False)
            torch.cuda.synchronize()
            gpu_start, gpu_end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            ticket = ledger.reserve(kind, step_id, row["image_id"], imgsz)
            started, utc_started = counter(), datetime.now(timezone.utc).isoformat()
            capture.clear()
            entered = returned = event_started = False
            result = error = None
            try:
                gpu_start.record()
                event_started = True
                ledger.check()
                entered = True
                values = model.predict(source=row["image_path"], **options)
                returned = True
                if type(values) is not list or len(values) != 1:
                    raise ValueError("Predictor must return exactly one observation")
                _controls(model, torch, options, capture, require_input=True)
                predictions, speed = _predictions(values[0], row)
                result = predictions, speed
            except BaseException as exc:
                error = exc
            gpu_seconds = None
            timing_error = None
            try:
                if not event_started:
                    raise RuntimeError("CUDA start event did not complete")
                gpu_end.record()
                torch.cuda.synchronize()
                gpu_seconds = gpu_start.elapsed_time(gpu_end) / 1000
                if not _finite(gpu_seconds):
                    raise ValueError("CUDA cost is nonfinite or negative")
            except BaseException as exc:
                timing_error, gpu_seconds = exc, None
            elapsed = counter() - started
            if not _finite(elapsed) or elapsed <= 0:
                timing_error = ValueError("Monotonic elapsed cost is invalid")
            if gpu_seconds is not None and _finite(elapsed) and gpu_seconds > elapsed + .05:
                timing_error = ValueError("CUDA cost exceeds synchronized elapsed cost")
                gpu_seconds = None
            if error is None and timing_error is not None:
                error = RuntimeError("Actual prediction cost is unknown; group cannot resume")
            status = "passed" if error is None else "failed"
            ledger.closed(ticket, status, elapsed, gpu_seconds,
                          utc_started=utc_started, utc_finished=datetime.now(timezone.utc).isoformat(),
                          cost_known=timing_error is None, prediction_entered=entered,
                          prediction_returned=returned, step_id=step_id, image_id=row["image_id"],
                          imgsz=imgsz, kind=kind,
                          error_type=type(error).__name__ if error is not None else None,
                          error_message=str(error) if error is not None else None,
                          timing_error_type=type(timing_error).__name__ if timing_error is not None else None)
            if error is not None:
                raise error
            completed_calls += 1
            gpu_total += gpu_seconds
            elapsed_total += elapsed
            return result[0], result[1], elapsed, gpu_seconds

        output = []
        with torch.inference_mode(), torch.autocast(device_type="cuda", enabled=False):
            _, _, warmup_seconds, warmup_gpu_seconds = predict(records[0], "warmup")
            torch.cuda.reset_peak_memory_stats()
            group_started = counter()
            for row in records:
                predictions, speed, seconds, gpu_seconds = predict(row, "formal")
                output.append({**row, "predictions": predictions, "eval_imgsz": imgsz,
                               "device": "0", "precision": "FP32", "elapsed_seconds": seconds,
                               "gpu_seconds": gpu_seconds, "ultralytics_speed_ms": speed})
            group_seconds = counter() - group_started
        effective = _controls(model, torch, options, capture, require_input=True)
        environment = {"python": platform.python_version(), "python_executable": sys.executable,
                       "torch": str(torch.__version__), "ultralytics": ultra_version,
                       "cuda": torch.version.cuda, "cudnn": torch.backends.cudnn.version(), "device": "0",
                       "gpu_name": torch.cuda.get_device_name(0),
                       "gpu_total_bytes": torch.cuda.get_device_properties(0).total_memory,
                       "precision": "FP32", "tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
                       "tf32_cudnn": torch.backends.cudnn.allow_tf32,
                       "cudnn_benchmark": torch.backends.cudnn.benchmark,
                       "cudnn_deterministic": torch.backends.cudnn.deterministic,
                       "actual_predictor_options": effective,
                       "actual_predictor_imgsz": list(model.predictor.imgsz),
                       "actual_predictor_fp16": model.predictor.model.fp16,
                       "actual_predictor_device": str(model.predictor.model.device),
                       "actual_current_cuda_device": torch.cuda.current_device(),
                       "actual_input_dtype": str(capture["dtype"]), "actual_input_device": capture["device"],
                       "warmup_images": 1, "warmup_seconds": warmup_seconds,
                       "warmup_gpu_seconds": warmup_gpu_seconds, "group_elapsed_seconds": group_seconds,
                       "prediction_entry_calls": completed_calls, "formal_calls": len(output), "warmup_calls": 1,
                       "closed_prediction_gpu_seconds": gpu_total, "closed_prediction_elapsed_seconds": elapsed_total,
                       "peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                       "model_parameters_dtype": str(next(model.model.parameters()).dtype),
                       "prediction_entry": "YOLO.predict", "real_detector_used": real_detector,
                       "fixture_only": not real_detector, "backend_source": _artifact_record(Path(__file__).resolve()),
                       "callable_sources": _callable_sources() if real_detector else {}}
        ledger.check()
        return output, environment
    finally:
        active_error = sys.exc_info()[1]
        cleanup_error = None
        try:
            if hook is not None:
                hook.remove()
        except BaseException as exc:
            cleanup_error = exc
        model = None
        try:
            if torch is not None:
                torch.cuda.empty_cache()
        except BaseException as exc:
            cleanup_error = cleanup_error or exc
        for key, value in prior.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        if cleanup_error is not None:
            if active_error is not None:
                active_error.add_note(f"Backend cleanup failed: {type(cleanup_error).__name__}: {cleanup_error}")
            else:
                raise cleanup_error
