"""Shared, bounded case actions for the C/U/F comparison.

The host registers the artificial case and treatment before exposing an opaque
handle. Every treatment reads the same prepared bytes and can choose the same
six actions. Only F applies the independent business gate at publication. This
module does not choose a sequence, invoke Agnes, or run a detector.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import time
import uuid

from .config import PROJECT_ROOT, PATH_KEYS, load_config
from . import research_domain_v1 as domain
from .research_science_v1 import read_scientific_evidence

OWNER = "defect_researcher.comparison_case_runtime_v14"
HANDLE = re.compile(r"cmp_[0-9a-f]{32}\Z")
TRIAL_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,95}\Z")
SHA = re.compile(r"[0-9a-f]{64}\Z")
LOCK_PATH_ENV = "DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH"
LOCK_SHA_ENV = "DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256"
FREEZE = PROJECT_ROOT / "outputs/research-workflow-implementation-v1/freeze.json"
FREEZE_SHA256 = "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"
ACTION_COSTS = {"inspect_input": 0, "verify_input": 1, "repair_copy": 3,
                "verify_copy": 1, "read_science": 1, "publish_report": 0}
BUDGET = {"domain_invocations": 6, "model_requests": 7, "wall_seconds": 120,
          "gpu_seconds": 0}


class BudgetError(ValueError):
    """A closed cost, clock or original budget does not permit continuation."""


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    location = unlinked(Path(path))
    return {"path": str(location), "sha256": sha(location),
            "size_bytes": location.stat().st_size}


def read(path):
    def unique(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def write_exclusive(path, value):
    path = Path(path)
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    temporary = path.with_name(path.name + ".writing-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def unlinked(path):
    path = Path(path).absolute()
    for parent in (path, *path.parents):
        if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
            raise ValueError("Linked comparison input/output paths are refused")
    return path.resolve()


def _check_record(item):
    if (type(item) is not dict or not {"path", "sha256", "size_bytes"} <= set(item)
            or type(item["path"]) is not str or not Path(item["path"]).is_absolute()
            or type(item["sha256"]) is not str or not SHA.fullmatch(item["sha256"])
            or type(item["size_bytes"]) is not int or item["size_bytes"] < 0):
        raise ValueError("Source binding is invalid")
    if record(item["path"]) != {key: item[key] for key in ("path", "sha256", "size_bytes")}:
        raise ValueError("Bound source or evidence bytes changed")


def _frozen_sources():
    if sha(FREEZE) != FREEZE_SHA256:
        raise ValueError("Prior source freeze changed")
    frozen = read(FREEZE)
    if (frozen.get("status") != "passed" or len(frozen.get("sources", [])) != 25
            or len(frozen.get("archive", [])) != 25
            or len(frozen.get("preserved_files", [])) != 968):
        raise ValueError("Prior frozen population changed")
    for key in ("sources", "archive", "preserved_files"):
        for item in frozen[key]:
            _check_record(item)


def _deployment_pin():
    path, expected = os.environ.get(LOCK_PATH_ENV), os.environ.get(LOCK_SHA_ENV)
    if path is None and expected is None:
        return None  # The production launcher requires the pin; local tests do not.
    if (not path or type(expected) is not str or not SHA.fullmatch(expected)
            or not Path(path).is_absolute()):
        raise ValueError("Deployment pin requires an absolute path and SHA256 pair")
    location = unlinked(path)
    if not location.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError("Deployment source lock is outside the project")
    pin = {"path": str(location), "sha256": expected}
    _check_pin(pin)
    return pin


def _check_pin(pin):
    if sha(pin["path"]) != pin["sha256"]:
        raise ValueError("Comparison deployment source lock changed")
    value = read(pin["path"])
    if (value.get("schema_version") != 1 or value.get("kind") != "comparison_case_implementation_v1"
            or value.get("status") != "passed" or type(value.get("files")) is not list
            or not value["files"]):
        raise ValueError("Comparison deployment source lock is not accepted")
    paths = []
    for item in value["files"]:
        _check_record(item)
        paths.append(str(Path(item["path"]).resolve()))
    required = (Path(__file__), PROJECT_ROOT / "defect_researcher/comparison_protocol_v14.py",
                PROJECT_ROOT / "tools/verify_comparison_case_v14.py",
                PROJECT_ROOT / "defect_researcher/comparison_mcp_server_v14.py",
                PROJECT_ROOT / "run_comparison_mcp_v14.py", FREEZE,
                PROJECT_ROOT / "config/local.json")
    if len(paths) != len(set(paths)) or any(str(path.resolve()) not in paths for path in required):
        raise ValueError("Comparison source lock omits a required implementation member")


def _configuration(configuration, config_path):
    baseline = load_config(PROJECT_ROOT / "config/local.json")
    if configuration is not None and config_path is not None:
        raise ValueError("Choose configuration or config_path")
    result = load_config(config_path) if config_path is not None else dict(configuration or baseline)
    if set(result) != set(PATH_KEYS) or any(type(item) is not str for item in result.values()):
        raise ValueError("Comparison configuration requires only the fixed path keys")
    result = {key: str(unlinked(value)) for key, value in result.items()}
    if any(result[key] != baseline[key] for key in PATH_KEYS[:-1]):
        raise ValueError("Only host-owned output_root may differ from local configuration")
    output = Path(result["output_root"])
    if not output.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError("Comparison outputs must remain inside the project")
    for key in PATH_KEYS[:-1]:
        protected = Path(result[key])
        if output == protected or output.is_relative_to(protected) or protected.is_relative_to(output):
            raise ValueError("Comparison outputs overlap a protected input")
    return result


def _journal(path):
    path = Path(path)
    if not path.exists():
        return []
    raw = path.read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise BudgetError("Comparison journal has an unfinished write")
    rows = []
    previous = "0" * 64
    for line in raw.splitlines():
        def unique(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise BudgetError("Repeated comparison journal JSON key")
                value[key] = item
            return value
        value = json.loads(line, object_pairs_hook=unique,
                           parse_constant=lambda item: (_ for _ in ()).throw(BudgetError("Nonfinite journal value")))
        if (type(value) is not dict
                or set(value) != {"schema_version", "sequence", "event", "previous_sha256", "record", "sha256"}
                or type(value["schema_version"]) is not int or value["schema_version"] != 1
                or type(value["sequence"]) is not int or value["sequence"] != len(rows)
                or type(value["event"]) is not str or type(value["record"]) is not dict
                or value["previous_sha256"] != previous
                or value["sha256"] != hashlib.sha256(canonical(
                    {key: item for key, item in value.items() if key != "sha256"})).hexdigest()):
            raise BudgetError("Comparison journal chain changed")
        rows.append(value)
        previous = value["sha256"]
    return rows


def append(path, event, value):
    path = Path(path)
    rows = _journal(path)
    entry = {"schema_version": 1, "sequence": len(rows), "event": event,
             "previous_sha256": rows[-1]["sha256"] if rows else "0" * 64,
             "record": value}
    entry["sha256"] = hashlib.sha256(canonical(entry)).hexdigest()
    with path.open("ab") as stream:
        stream.write(canonical(entry) + b"\n")
        stream.flush()
        os.fsync(stream.fileno())
    return entry


class Runtime:
    """Filesystem-backed single-trial operations; root-only preparation/arming."""

    def __init__(self, configuration=None, config_path=None, *, clock=None, epoch_clock=None):
        self.configuration = _configuration(configuration, config_path)
        self.root = unlinked(self.configuration["output_root"])
        self.clock = clock or time.monotonic
        self.epoch_clock = epoch_clock or time.time
        self.pin = _deployment_pin()

    @contextmanager
    def _lock(self, directory):
        path = directory / ".action.lock"
        with path.open("xb") as stream:
            stream.write(OWNER.encode("utf-8"))
        try:
            yield
        finally:
            # Only this owned single file is removed; failed records remain.
            path.unlink()

    def prepare(self, trial_id, case_id, arm, trial_handle=None):
        """Register one treatment against the one shared case input directory."""
        if type(trial_id) is not str or not TRIAL_ID.fullmatch(trial_id):
            raise ValueError("Host trial identity must be a safe directory name")
        if arm not in ("C", "U", "F") or type(arm) is not str:
            raise ValueError("Host treatment must be C, U or F")
        if trial_handle is not None and (type(trial_handle) is not str or not HANDLE.fullmatch(trial_handle)):
            raise ValueError("Host preregistered handle must match the opaque handle schema")
        domain._spec_case(case_id)  # Host-only; rejects arbitrary input/path selection.
        _frozen_sources()
        if self.pin is not None:
            _check_pin(self.pin)
        self.root.mkdir(parents=True, exist_ok=True)
        unlinked(self.root)
        trials = self.root / "trials"
        trials.mkdir(exist_ok=True)
        unlinked(trials)
        identity_lock = trials / (trial_id + ".identity.json")
        if identity_lock.exists() or (trial_handle is not None and (trials / trial_handle).exists()):
            raise FileExistsError("Trial identity or handle already exists; preparation cannot reset")
        input_parent = self.root / "inputs"
        input_parent.mkdir(exist_ok=True)
        unlinked(input_parent)
        inputs = input_parent / case_id
        prepared_path = input_parent / (case_id + ".prepared.json")
        input_lock = input_parent / (case_id + ".prepare.lock")
        with input_lock.open("xb"):
            pass
        try:
            if prepared_path.exists():
                prepared = read(prepared_path)
                if prepared.get("case_root") != str(inputs) or prepared.get("case_id") != case_id:
                    raise ValueError("Shared prepared case identity changed")
                snapshot = domain.snapshot_case(prepared)
            else:
                if inputs.exists():
                    raise FileExistsError("Incomplete shared preparation is preserved and cannot reset")
                prepared = domain.prepare_case(inputs, case_id, self.configuration["research_root"])
                snapshot = domain.snapshot_case(prepared)
                write_exclusive(prepared_path, prepared)
        finally:
            input_lock.unlink()
        handle = trial_handle or "cmp_" + uuid.uuid4().hex
        write_exclusive(identity_lock, {"trial_id": trial_id, "trial_handle": handle})
        directory = trials / handle
        directory.mkdir(exist_ok=False)
        (directory / "evidence").mkdir()
        files = [record(__file__), record(PROJECT_ROOT / "defect_researcher/comparison_protocol_v14.py"),
                 record(PROJECT_ROOT / "tools/verify_comparison_case_v14.py"),
                 record(PROJECT_ROOT / "config/local.json"), record(FREEZE)]
        binding = {"files": files, "prior_freeze_sha256": FREEZE_SHA256}
        if self.pin is not None:
            binding["deployment_lock"] = self.pin
        registration = {"schema_version": 1, "kind": "comparison_case_trial_v1", "owner": OWNER,
                        "trial_id": trial_id, "trial_handle": handle, "case_id": case_id, "arm": arm,
                        "configuration": self.configuration, "prepared_case": prepared,
                        "input_snapshot": snapshot, "source_binding": binding}
        write_exclusive(directory / "registration.json", registration)
        write_exclusive(directory / "registration_binding.json", record(directory / "registration.json"))
        return {"schema_version": 1, "trial_handle": handle, "status": "prepared"}

    def _registration(self, handle):
        if type(handle) is not str or not HANDLE.fullmatch(handle):
            raise ValueError("trial_handle must be an owned opaque handle")
        directory = unlinked(self.root / "trials" / handle)
        _check_record(read(directory / "registration_binding.json"))
        value = read(directory / "registration.json")
        if (value.get("schema_version") != 1 or value.get("kind") != "comparison_case_trial_v1"
                or value.get("owner") != OWNER or value.get("trial_handle") != handle
                or value.get("configuration") != self.configuration or value.get("arm") not in ("C", "U", "F")):
            raise ValueError("Trial registration changed or belongs to another runtime")
        for item in value["source_binding"]["files"]:
            _check_record(item)
        bound_pin = value["source_binding"].get("deployment_lock")
        if bound_pin != self.pin:
            raise ValueError("Deployment pin differs from registered trial")
        if bound_pin is not None:
            _check_pin(bound_pin)
        _frozen_sources()
        if domain.snapshot_case(value["prepared_case"]) != value["input_snapshot"]:
            raise ValueError("Shared original inputs changed")
        return directory, value

    def arm(self, trial_handle, epoch=None, monotonic=None):
        """Start the original Python clock before the model prompt; never reset."""
        # Capture anchors before registration/source I/O, so that cost is included.
        epoch = self.epoch_clock() if epoch is None else epoch
        monotonic = self.clock() if monotonic is None else monotonic
        if any(type(value) not in (int, float) or not math.isfinite(value) or value < 0
               for value in (epoch, monotonic)):
            raise ValueError("Trusted original anchors must be finite and nonnegative")
        directory, registration = self._registration(trial_handle)
        with self._lock(directory):
            if (directory / "arm.json").exists():
                raise FileExistsError("Trial already armed; original budget cannot reset")
            now_e, now_m = self.epoch_clock(), self.clock()
            if epoch > now_e or monotonic > now_m:
                raise BudgetError("Original clock anchors may not be in the future")
            arm = {"schema_version": 1, "trial_handle": trial_handle,
                   "started_epoch": float(epoch), "started_monotonic": float(monotonic),
                   "deadline_epoch": float(epoch) + 120, "deadline_monotonic": float(monotonic) + 120,
                   "budget": BUDGET, "registration_sha256": sha(directory / "registration.json")}
            write_exclusive(directory / "arm.json", arm)
            write_exclusive(directory / "arm_binding.json", record(directory / "arm.json"))
            append(directory / "budget.jsonl", "ledger_opened", {**arm,
                   "used_domain_invocations": 0, "pending": None,
                   "current_epoch": now_e, "current_monotonic": now_m})
            self._budget(directory, arm)
        return copy.deepcopy(arm)

    def _armed(self, directory):
        _check_record(read(directory / "arm_binding.json"))
        value = read(directory / "arm.json")
        budget = value.get("budget")
        if (type(value.get("schema_version")) is not int or value["schema_version"] != 1
                or type(budget) is not dict or set(budget) != set(BUDGET)
                or any(type(budget[key]) is not int or budget[key] != expected
                       for key, expected in BUDGET.items())
                or value.get("registration_sha256") != sha(directory / "registration.json")
                or value.get("deadline_epoch") != value["started_epoch"] + 120
                or value.get("deadline_monotonic") != value["started_monotonic"] + 120):
            raise BudgetError("Original trial budget or anchors changed")
        return value

    def _budget(self, directory, arm, *, allow_pending=False, allow_expired=False):
        rows = _journal(directory / "budget.jsonl")
        if not rows or rows[0]["event"] != "ledger_opened":
            raise BudgetError("Trial has no original budget journal")
        if any(rows[0]["record"].get(key) != value for key, value in arm.items()):
            raise BudgetError("Journal original clock/budget differs from the armed trial")
        used, pending = 0, None
        last_e, last_m = arm["started_epoch"], arm["started_monotonic"]
        for row in rows:
            item = row["record"]
            for key, previous in (("current_epoch", last_e), ("current_monotonic", last_m)):
                current = item.get(key, previous)
                if type(current) not in (int, float) or not math.isfinite(current) or current < previous:
                    raise BudgetError("Budget journal contains an invalid or backwards clock")
            last_e = item.get("current_epoch", last_e)
            last_m = item.get("current_monotonic", last_m)
            if row["event"] == "action_reserved":
                if pending is not None or item.get("reserved_cost") != ACTION_COSTS.get(item.get("action")):
                    raise BudgetError("Budget reservations overlap or have unknown cost")
                pending = {"action": item["action"], "reserved_cost": item["reserved_cost"]}
            elif row["event"] == "action_closed":
                actual = item.get("actual_cost")
                if (pending is None or item.get("action") != pending["action"]
                        or type(actual) is not int or not 0 <= actual <= pending["reserved_cost"]):
                    raise BudgetError("Budget cost receipt has no matching reservation")
                used += actual
                pending = None
                if item.get("used_domain_invocations") != used:
                    raise BudgetError("Cumulative domain cost receipt changed")
            elif row["event"] != "ledger_opened" or row["sequence"] != 0:
                raise BudgetError("Unknown budget journal event")
        now_e, now_m = self.epoch_clock(), self.clock()
        if any(type(value) not in (int, float) or not math.isfinite(value) for value in (now_e, now_m)):
            raise BudgetError("Original trial clock is not a finite number")
        if now_e < last_e or now_m < last_m:
            raise BudgetError("Original trial clock moved backwards")
        expired = now_e >= arm["deadline_epoch"] or now_m >= arm["deadline_monotonic"]
        if expired and not allow_expired:
            raise BudgetError("Original trial wall deadline expired")
        if used > 6 or (pending is not None and not allow_pending):
            raise BudgetError("Original domain budget exceeded or actual cost remains unknown")
        return {"domain_invocations_used": used,
                "domain_invocations_reserved": pending["reserved_cost"] if pending else 0,
                "domain_invocations_remaining": 6 - used - (pending["reserved_cost"] if pending else 0),
                "model_requests_cap": 7, "gpu_seconds": 0,
                "model_requests": None, "model_request_accounting": "external_official_sdk_ledger",
                "journal_sha256": sha(directory / "budget.jsonl"),
                "started_epoch": arm["started_epoch"], "started_monotonic": arm["started_monotonic"],
                "deadline_epoch": arm["deadline_epoch"], "deadline_monotonic": arm["deadline_monotonic"],
                "current_epoch": now_e, "current_monotonic": now_m,
                "elapsed_wall_seconds": max(now_e - arm["started_epoch"], now_m - arm["started_monotonic"]),
                "expired": expired, "pending": pending}

    def _close(self, directory, arm, action, actual):
        # A late operation still closes its known cost first. The subsequent
        # publication check rejects expiry without pretending its cost unknown.
        pending_budget = self._budget(directory, arm, allow_pending=True, allow_expired=True)
        if (type(actual) is not int or not 0 <= actual <= ACTION_COSTS[action]
                or pending_budget["pending"] != {"action": action, "reserved_cost": ACTION_COSTS[action]}):
            raise BudgetError("Actual action cost is unknown or exceeds its reserved cap")
        append(directory / "budget.jsonl", "action_closed", {
            "action": action, "actual_cost": actual,
            "used_domain_invocations": pending_budget["domain_invocations_used"] + actual,
            "current_epoch": self.epoch_clock(), "current_monotonic": self.clock()})
        return self._budget(directory, arm)

    def _evidence(self, directory):
        return [read(path) for path in sorted((directory / "evidence").glob("*.json"))]

    def _inspect(self, prepared):
        """Read useful source/label facts, without a geometry verifier or goldens."""
        configuration = prepared["configuration"]
        dataset, raw = Path(configuration["dataset_root"]), Path(configuration["raw_root"])
        manifest = read(dataset / "manifest.json")
        annotations, labels, metadata = [], [], []
        unique_identities = True
        mapping_consistent = True
        hashes_match = True
        expected = manifest.get("categories", {})
        declared = manifest.get("source_sha256", {})
        for name, expected_sha in declared.items():
            location = raw / name
            if not location.exists():
                hashes_match = False
                continue
            hashes_match = hashes_match and sha(location) == expected_sha
            source = read(location)
            categories = {str(item["id"]): item["name"] for item in source.get("categories", [])}
            mapping_consistent = mapping_consistent and categories == expected
            images = source.get("images", [])
            identities = [(item.get("id"), item.get("file_name")) for item in images]
            unique_identities = unique_identities and len(identities) == len(set(identities))
            image_by_id = {item.get("id"): item for item in images}
            for item in source.get("annotations", []):
                image = image_by_id.get(item.get("image_id"), {})
                annotations.append({"bbox": item.get("bbox"), "rotation": item.get("attributes", {}).get("rotation", 0),
                    "category_id": item.get("category_id"), "image_dimensions": [image.get("width"), image.get("height")]})
        for location in sorted((dataset / "labels").rglob("*.txt")):
            labels.append({"name": location.relative_to(dataset).as_posix(), "text": location.read_text(encoding="utf-8")})
        for location in sorted((dataset / "metadata").rglob("*.json")):
            value = read(location)
            for item in value.get("annotations", []):
                metadata.append({key: item.get(key) for key in ("rotation", "hbb_xyxy", "rotated_corners", "category_id")})
        image_stems = {(path.parent.name, path.stem) for path in (dataset / "images").rglob("*") if path.is_file()}
        label_stems = {(path.parent.name, path.stem) for path in (dataset / "labels").rglob("*.txt")}
        summary = {"label_files": len(labels), "image_files": len(image_stems),
                   "missing_labels": len(image_stems - label_stems),
                   "declared_source_hashes_match": hashes_match,
                   "class_mapping_consistent": mapping_consistent,
                   "unique_image_identities": unique_identities,
                   "source_annotations": annotations, "label_contents": labels,
                   "metadata_geometry": metadata}
        return {"kind": "source_inspection", "synthetic_only": True,
                "geometry_verifier_called": False, "inference_performed": False,
                "summary": summary, "files": list(domain.snapshot_case(prepared).values())}

    @staticmethod
    def _public_evidence(value):
        result = value["result"]
        summary = copy.deepcopy(result.get("summary", {}))
        # Keep source facts and counts. Host paths and saved task identities never
        # become model-selected capabilities or disclose the private case/treatment.
        for key in tuple(summary):
            if key.endswith(("_root", "_path", "_task")) or key in ("configuration", "task_id", "case_id"):
                summary.pop(key)
        if value["action"] in ("verify_input", "repair_copy", "verify_copy"):
            summary.pop("counts", None)
            summary.pop("fixture_counts", None)
            summary.pop("issue_samples", None)
        public = {"evidence_id": value["evidence_id"], "action": value["action"], "summary": summary}
        for key in ("semantic_status", "execution_status", "synthetic_only", "inference_performed", "geometry_verifier_called"):
            if key in result:
                public[key] = result[key]
        if result.get("source_guard") is not None:
            guard = result["source_guard"]
            public["source_guard"] = {key: guard[key] for key in ("kind", "status", "read_only", "original_inputs_unchanged") if key in guard}
        public["claim_fields"] = "Fields address the saved result, e.g. summary.issue_count or semantic_status."
        return public

    def execute(self, arguments):
        if type(arguments) is not dict or set(arguments) not in (
                {"trial_handle", "action"}, {"trial_handle", "action", "report"}):
            raise ValueError("Arguments must contain only trial_handle/action and publication report")
        return self.action(arguments["trial_handle"], arguments["action"], arguments.get("report"))

    def action(self, trial_handle, action, report=None):
        if type(action) is not str or action not in ACTION_COSTS:
            raise ValueError("Action is not in the shared bounded catalog")
        if (action == "publish_report") != (report is not None):
            raise ValueError("Only publish_report requires a report")
        directory, registration = self._registration(trial_handle)
        with self._lock(directory):
            if (directory / "completion.json").exists() or (directory / "failure.json").exists():
                raise ValueError("Trial is terminal; failed or published history cannot resume")
            arm = self._armed(directory)
            actions = _journal(directory / "actions.jsonl")
            if any(row["record"].get("action") == action for row in actions):
                raise ValueError("Each case action may be attempted once; replay is refused")
            budget = self._budget(directory, arm)
            if ACTION_COSTS[action] > budget["domain_invocations_remaining"]:
                raise BudgetError("Insufficient domain capacity for the action's worst-case cost")
            append(directory / "budget.jsonl", "action_reserved", {
                "action": action, "reserved_cost": ACTION_COSTS[action],
                "used_domain_invocations": budget["domain_invocations_used"],
                "current_epoch": self.epoch_clock(), "current_monotonic": self.clock()})
            append(directory / "actions.jsonl", "action_started", {"action": action, "budget": budget})
            try:
                prepared = registration["prepared_case"]
                if action == "publish_report":
                    result = self._publish(directory, registration, arm, report)
                else:
                    if action == "inspect_input":
                        value, actual = self._inspect(prepared), 0
                    elif action == "verify_input":
                        value = domain.verify_case(prepared, directory / "domain_input", "check")
                        actual = value["cost"]["domain_tool_calls"]
                    elif action == "repair_copy":
                        value = domain.repair_case(prepared, directory / "domain_repair", "repair")
                        actual = value["cost"]["domain_tool_calls"]
                    elif action == "verify_copy":
                        repairs = [entry for entry in self._evidence(directory) if entry["action"] == "repair_copy"]
                        if len(repairs) != 1:
                            raise ValueError("verify_copy requires this trial's passed repair artifact")
                        value = domain.verify_copy(prepared, repairs[0]["result"], directory / "domain_copy", "check")
                        actual = value["cost"]["domain_tool_calls"]
                    else:
                        value, actual = read_scientific_evidence(), 1
                    self._close(directory, arm, action, actual)
                    if domain.snapshot_case(prepared) != registration["input_snapshot"]:
                        raise ValueError("Original inputs changed during the action")
                    identity = trial_handle + "_" + action
                    evidence = {"evidence_id": identity, "trial_handle": trial_handle,
                                "action": action, "result": value}
                    if action in ("verify_input", "repair_copy", "verify_copy"):
                        task = Path(value["task_dir"])
                        manifest = task / "artifact_manifest.json"
                        evidence["task_manifest"] = record(manifest if manifest.exists() else task / "failure.json")
                    evidence_path = directory / "evidence" / (action + ".json")
                    write_exclusive(evidence_path, evidence)
                    result = {"schema_version": 1, "trial_handle": trial_handle,
                              "action": action, "status": "executed",
                              "evidence": self._public_evidence(evidence),
                              "budget": self._budget(directory, arm)}
                if len(canonical(result)) > 4000:
                    raise ValueError("Public action result exceeds its bounded size")
                append(directory / "actions.jsonl", "action_finished", {
                    "action": action, "evidence_id": result.get("evidence", {}).get("evidence_id"),
                    "status": result["status"], "public_result": result,
                    "budget": self._budget(directory, arm)})
                # Action/source/output I/O consumes the original wall budget too.
                self._budget(directory, arm)
                return result
            except BaseException as error:
                if not (directory / "failure.json").exists():
                    write_exclusive(directory / "failure.json", {
                        "schema_version": 1, "trial_handle": trial_handle, "status": "failed",
                        "stage": action, "error_type": type(error).__name__, "error": str(error),
                        "original_deadline_epoch": arm["deadline_epoch"],
                        "original_deadline_monotonic": arm["deadline_monotonic"],
                        "completion_not_authorized": True})
                # A candidate marker emitted just before a late I/O deadline is
                # retained under a rejection name; it cannot authorize success.
                marker = directory / "completion.json"
                if marker.exists():
                    marker.rename(directory / "completion_rejected.json")
                raise

    def _publish(self, directory, registration, arm, report):
        from .comparison_protocol_v14 import evaluate_candidate
        if type(report) is not dict or report.get("trial_handle") != registration["trial_handle"]:
            raise ValueError("Report must bind this opaque trial handle")
        write_exclusive(directory / "candidate.json", report)
        enforced = registration["arm"] == "F"
        gate = evaluate_candidate(report, self._evidence(directory),
                                  trial_handle=registration["trial_handle"],
                                  require_verified=enforced, check_claims=enforced)
        write_exclusive(directory / "gate.json", gate)
        budget = self._close(directory, arm, "publish_report", 0)
        # The independent gate performs no new geometry/domain invocation. Its
        # hash/source/result checks and writes use the same original wall clock.
        self._registration(registration["trial_handle"])
        accepted = gate.get("status") == "passed"
        publication = {"schema_version": 1, "trial_handle": registration["trial_handle"],
                       "accepted": accepted, "gate_enforced": enforced,
                       "candidate_sha256": sha(directory / "candidate.json"),
                       "gate_sha256": sha(directory / "gate.json"), "budget": budget}
        write_exclusive(directory / "publication.json", publication)
        self._budget(directory, arm)
        if accepted:
            write_exclusive(directory / "completion.json", {
                "schema_version": 1, "trial_handle": registration["trial_handle"],
                "status": "published", "publication_sha256": sha(directory / "publication.json"),
                "candidate_sha256": publication["candidate_sha256"],
                "gate_enforced": enforced, "budget": self._budget(directory, arm)})
        else:
            write_exclusive(directory / "failure.json", {
                "schema_version": 1, "trial_handle": registration["trial_handle"],
                "status": "rejected", "stage": "publish_report", "reason": "publication_gate_rejected",
                "gate_sha256": publication["gate_sha256"], "completion_not_authorized": True})
        return {"schema_version": 1, "trial_handle": registration["trial_handle"],
                "action": "publish_report", "status": "published" if accepted else "rejected",
                "publication": {"accepted": accepted,
                                "report_sha256": publication["candidate_sha256"]},
                "errors": [{"code": "publication_gate_rejected"}] if not accepted else [],
                "budget": self._budget(directory, arm)}

    def status(self, trial_handle):
        directory, _ = self._registration(trial_handle)
        if not (directory / "arm.json").exists():
            return {"schema_version": 1, "trial_handle": trial_handle, "status": "prepared"}
        arm = self._armed(directory)
        terminal = "failed" if (directory / "failure.json").exists() else (
            "published" if (directory / "completion.json").exists() else "armed")
        return {"schema_version": 1, "trial_handle": trial_handle, "status": terminal,
                "original_deadline_epoch": arm["deadline_epoch"],
                "original_deadline_monotonic": arm["deadline_monotonic"]}


def main(argv=None):
    parser = argparse.ArgumentParser(description="Private host comparison preparation and clock arming")
    parser.add_argument("--config", required=True)
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--trial-id", required=True)
    prepare.add_argument("--case-id", required=True)
    prepare.add_argument("--arm", choices=("C", "U", "F"), required=True)
    prepare.add_argument("--trial-handle")
    arm = sub.add_parser("arm")
    arm.add_argument("--trial-handle", required=True)
    status = sub.add_parser("status")
    status.add_argument("--trial-handle", required=True)
    args = parser.parse_args(argv)
    runtime = Runtime(config_path=args.config)
    if args.command == "prepare":
        result = runtime.prepare(args.trial_id, args.case_id, args.arm, args.trial_handle)
    elif args.command == "arm":
        result = runtime.arm(args.trial_handle)
    else:
        result = runtime.status(args.trial_handle)
    sys.stdout.write(canonical(result).decode("utf-8") + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
