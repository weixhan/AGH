"""JSON-stable version metadata for a future business recovery version.

PyTorch exposes ``torch.__version__`` as ``TorchVersion``, a string subclass.
JSON saves the same bytes as a plain string. Frozen V3 recovery deliberately
compares types as well as values, so comparing those two representations fails.
This subclass normalizes only the known ``torch`` version metadata field.
Predictor controls, tensor/device evidence, dependency hashes and all other
fields retain the original strict V3 validation. Nothing routes this backend
into a completed or failed V1 experiment or restarts any detector operation.
"""
from __future__ import annotations

from .sliced_worker_v3 import DetectorBackend as FrozenDetectorBackend


NORMALIZED_VERSION_FIELDS = frozenset({"torch"})


def json_stable_version_metadata(environment):
    """Copy one known version string to its JSON representation, without casts.

String subclasses become plain strings only in known version metadata fields.
Non-string versions stay untouched and fail the existing typed comparison.
Scientific strings, numeric controls and booleans are never normalized here.
"""
    if type(environment) is not dict:
        raise ValueError("Backend environment must be an exact metadata dictionary")
    result = dict(environment)
    for key in NORMALIZED_VERSION_FIELDS:
        version = result.get(key)
        if isinstance(version, str) and type(version) is not str:
            result[key] = str(version)
    return result


class DetectorBackendV2(FrozenDetectorBackend):
    """Keep fixed detector behavior; normalize its JSON version metadata only."""

    def environment(self, initial=False):
        return json_stable_version_metadata(super().environment(initial=initial))
