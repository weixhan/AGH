"""Single-action MCP transport for the frozen fair comparison case interface.

The model selects one action on a privately prepared opaque trial handle. Arm,
case, input paths, clocks and budgets remain in server-owned trial registration.
Publication is an attempt, not an assertion of independent evaluator success;
the transport adds no treatment-dependent gate. All arms share this catalogue.
Production stdout contains UTF-8 JSON-RPC frames only.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import os
from pathlib import Path
import re
import sys
from typing import Any, BinaryIO

from .comparison_protocol_v1 import ACTIONS, REPORT_SCHEMA, validate_action_arguments


PROTOCOL_VERSION = "2025-03-26"
SUPPORTED_PROTOCOL_VERSIONS = {PROTOCOL_VERSION, "2024-11-05"}
SERVER_NAME = "defect-researcher-comparison-cases-v1"
SERVER_VERSION = "1.0.0"
ACTION_TOOL_NAME = "execute_case_action_v1"
TRIAL_HANDLE_PATTERN = r"^cmp_[0-9a-f]{32}$"
_TRIAL_HANDLE = re.compile(TRIAL_HANDLE_PATTERN)
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
LOCK_PATH_ENV = "DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH"
LOCK_SHA_ENV = "DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256"


def _tools() -> list[dict]:
    return [{
        "name": ACTION_TOOL_NAME,
        "description": (
            "Execute one explicit action on the server-owned isolated trial. "
            "inspect_input reads raw structure without an independent geometry check; "
            "verify_input checks input geometry; repair_copy creates a separate label "
            "copy; verify_copy checks that copy; read_science reads sealed historical "
            "validation evidence; publish_report submits an evidence-linked report. "
            "Reports require report only for publish_report. Published records are "
            "publication attempts; assess returned publication and evidence. "
            "Caller paths, case or treatment selection, clocks, budgets, training, "
            "detector inference, network model requests and GPU work are unavailable."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "trial_handle": {"type": "string", "pattern": TRIAL_HANDLE_PATTERN,
                                 "minLength": 36, "maxLength": 36},
                "action": {"type": "string", "enum": list(ACTIONS)},
                "report": copy.deepcopy(REPORT_SCHEMA),
            },
            "required": ["trial_handle", "action"],
            "additionalProperties": False,
            "allOf": [{
                "if": {"properties": {"action": {"const": "publish_report"}},
                       "required": ["action"]},
                "then": {"properties": {"report": {}}, "required": ["report"]},
                "else": {"not": {"properties": {"report": {}}, "required": ["report"]}},
            }],
        },
        "annotations": {"readOnlyHint": False, "destructiveHint": False,
                        "idempotentHint": False, "openWorldHint": False},
    }]


def _valid_id(value: Any) -> bool:
    # The supported AGH stdio contract uses string or integer request IDs.
    return type(value) is str or type(value) is int


def _json_value(value: Any) -> bool:
    if value is None or type(value) in (str, bool, int):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(_json_value(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and _json_value(item) for key, item in value.items())
    return False


def _error(request_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": request_id,
            "error": {"code": code, "message": message}}


def _result(request_id: Any, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _arguments(name: str, arguments: Any) -> dict:
    if name != ACTION_TOOL_NAME or type(arguments) is not dict:
        raise ValueError("Only explicit action arguments are supported")
    handle, action = arguments.get("trial_handle"), arguments.get("action")
    if type(handle) is not str or _TRIAL_HANDLE.fullmatch(handle) is None:
        raise ValueError("trial_handle must be one opaque registered identifier")
    if type(action) is not str or action not in ACTIONS:
        raise ValueError("Unknown case action")
    return validate_action_arguments(arguments)


class ComparisonMCPServer:
    """One initialized stdio session with one explicit case-action tool."""

    def __init__(self, configuration: dict | None = None,
                 config_path: str | Path | None = None, runtime: Any = None):
        self.configuration = copy.deepcopy(configuration)
        self.config_path = config_path
        self.runtime = runtime
        self.initialized = False
        self.ready = False
        self.protocol_version = PROTOCOL_VERSION

    def handle_message(self, message: Any) -> dict | list | None:
        if not _json_value(message):
            return _error(None, -32600, "Invalid JSON-RPC value")
        if type(message) is list:
            if not message:
                return _error(None, -32600, "Invalid request: empty batch")
            responses = []
            for item in message:
                response = self._handle_request(item)
                if response is not None:
                    responses.append(response)
            return responses or None
        return self._handle_request(message)

    def _handle_request(self, message: Any) -> dict | None:
        if type(message) is not dict:
            return _error(None, -32600, "Invalid request: expected an object")
        request_id = message.get("id")
        response_id = request_id if _valid_id(request_id) else None
        if (set(message) - {"jsonrpc", "id", "method", "params"}
                or message.get("jsonrpc") != "2.0"
                or type(message.get("method")) is not str):
            return _error(response_id, -32600, "Invalid JSON-RPC request")
        if "id" in message and not _valid_id(request_id):
            return _error(None, -32600, "Request ID must be a string or integer")
        is_notification = "id" not in message
        method = message["method"]
        params = message.get("params", {})
        if type(params) is not dict:
            return None if is_notification else _error(request_id, -32602,
                                                       "Parameters must be an object")
        # Notifications never execute a tool, even after initialization.
        if is_notification:
            if method == "notifications/initialized" and self.initialized and not params:
                self.ready = True
            return None
        if method == "ping":
            return _result(request_id, {}) if not params else _error(
                request_id, -32602, "Ping accepts an empty parameters object")
        if method == "initialize":
            if self.initialized:
                return _error(request_id, -32600, "Session is already initialized")
            client = params.get("clientInfo")
            if (set(params) - {"protocolVersion", "capabilities", "clientInfo", "_meta"}
                    or type(params.get("protocolVersion")) is not str
                    or not params["protocolVersion"]
                    or type(params.get("capabilities")) is not dict
                    or type(client) is not dict
                    or type(client.get("name")) is not str or not client["name"]
                    or type(client.get("version")) is not str or not client["version"]
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "Invalid initialize parameters")
            self.initialized = True
            requested = params["protocolVersion"]
            self.protocol_version = (requested if requested in SUPPORTED_PROTOCOL_VERSIONS
                                     else PROTOCOL_VERSION)
            return _result(request_id, {
                "protocolVersion": self.protocol_version,
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
            })
        if not self.ready:
            return _error(request_id, -32002,
                          "Complete initialize and notifications/initialized first")
        if method == "tools/list":
            if (set(params) - {"cursor", "_meta"} or params.get("cursor") is not None
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "This tool directory has no cursor")
            tools = _tools()
            if self.protocol_version == "2024-11-05":
                for tool in tools:
                    tool.pop("annotations")
            return _result(request_id, {"tools": tools})
        if method == "tools/call":
            if (set(params) - {"name", "arguments", "_meta"}
                    or type(params.get("name")) is not str
                    or params["name"] not in {ACTION_TOOL_NAME}
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(request_id, -32602, "Unknown tool or call parameters")
            name = params["name"]
            try:
                arguments = _arguments(name, params.get("arguments"))
            except (TypeError, ValueError):
                return _error(request_id, -32602, "Invalid registered case-action arguments")
            return _result(request_id, self._run_tool(name, arguments))
        return _error(request_id, -32601, "Method not found")

    def _run_tool(self, name: str, arguments: dict) -> dict:
        stage = "runtime_initialization"
        try:
            if self.runtime is None:
                from .comparison_case_runtime_v1 import Runtime
                self.runtime = Runtime(configuration=copy.deepcopy(self.configuration),
                                       config_path=self.config_path)
            stage = "case_action"
            report = self.runtime.execute(copy.deepcopy(arguments))
            if type(report) is not dict or not _json_value(report):
                raise ValueError("Runtime report must be a finite JSON object")
            report = copy.deepcopy(report)
            if (type(report.get("schema_version")) is not int or report["schema_version"] != 1
                    or report.get("status") not in {"executed", "published", "rejected"}
                    or report.get("trial_handle") != arguments["trial_handle"]
                    or report.get("action") != arguments["action"]):
                raise ValueError("Runtime result is not bound to this case action")
            # A published U-arm attempt may lack a gate. Enforcing an independent
            # publication gate here would silently erase the intended treatment.
            content = json.dumps(report, ensure_ascii=False, allow_nan=False)
            failed = report["status"] == "rejected"
        except Exception as exc:
            failed = True
            content = json.dumps({
                "schema_version": 1, "status": "rejected",
                "trial_handle": arguments["trial_handle"], "action": arguments["action"],
                "errors": [{"stage": stage, "type": type(exc).__name__,
                            "code": "case_action_refused",
                            "message": "Case action refused; inspect the host-owned failure evidence."}],
            }, ensure_ascii=False, allow_nan=False)
        return {"content": [{"type": "text", "text": content}], "isError": failed}


def _reject_constant(value: str) -> None:
    raise ValueError("Nonfinite JSON constant")


def _finite_float(value: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Nonfinite JSON number")
    return number


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON object key")
        value[key] = item
    return value


def serve(configuration: dict | None = None, *, config_path: str | Path | None = None,
          runtime: Any = None, stdin: BinaryIO | None = None,
          stdout: BinaryIO | None = None) -> None:
    source = sys.stdin.buffer if stdin is None else stdin
    destination = sys.stdout.buffer if stdout is None else stdout
    if stdout is None:
        # This is process-wide and lasts until exit so worker output cannot
        # race a per-call stdout context and corrupt protocol frames.
        sys.stdout = sys.stderr
    server = ComparisonMCPServer(configuration, config_path, runtime)
    for line in source:
        try:
            message = json.loads(line.decode("utf-8"), parse_constant=_reject_constant,
                                 parse_float=_finite_float, object_pairs_hook=_unique_object)
            response = server.handle_message(message)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            response = _error(None, -32700, "Parse error: expected strict UTF-8 JSON")
        except Exception:
            response = _error(None, -32603, "Internal server error")
        if response is not None:
            encoded = json.dumps(response, ensure_ascii=True, separators=(",", ":"),
                                 allow_nan=False).encode("utf-8")
            destination.write(encoded + b"\n")
            destination.flush()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Frozen fair comparison case-action MCP service")
    parser.add_argument("--config", type=Path, required=True,
                        help="Server-owned comparison configuration JSON path")
    parser.add_argument("--source-lock", type=Path, required=True,
                        help="Local implementation source lock JSON path")
    parser.add_argument("--expected-lock-sha256", required=True,
                        help="Pinned SHA256 of the implementation source lock")
    args = parser.parse_args(argv)
    if _SHA256.fullmatch(args.expected_lock_sha256) is None:
        parser.error("--expected-lock-sha256 must be 64 lowercase hexadecimal characters")
    protocol_stdout = sys.stdout.buffer
    sys.stdout = sys.stderr
    try:
        source_lock = args.source_lock.resolve(strict=True)
        os.environ[LOCK_PATH_ENV] = str(source_lock)
        os.environ[LOCK_SHA_ENV] = args.expected_lock_sha256
        from .comparison_case_runtime_v1 import Runtime
        runtime = Runtime(config_path=args.config)
        serve(runtime=runtime, stdout=protocol_stdout)
    except (BrokenPipeError, KeyboardInterrupt):
        pass
    except Exception as error:
        print(f"Comparison case MCP startup refused: {type(error).__name__}: {error}",
              file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
