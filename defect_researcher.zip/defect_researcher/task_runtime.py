"""One background worker shared by audit and independent geometry verification."""
from __future__ import annotations

import copy
import json
import os
import re
import threading
import uuid
from pathlib import Path
from typing import Any

from .audit import _configured_paths, _sha256, _timestamp, audit_dataset


_LOCK = threading.RLock()
_TASKS: dict[str, dict[str, Any]] = {}
_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}")
AUDIT_TOOL = "audit_dataset"
GEOMETRY_TOOL = "verify_label_geometry"
REPAIR_TOOL = "repair_label_copy"
COMPARISON_TOOL = "compare_validation_resolutions"
DIAGNOSIS_TOOL = "diagnose_validation_errors"
SLICING_TOOL = "compare_validation_slices"
SLICED_ARTIFACT_RECOVERY_TOOL = "verify_sliced_artifact_recovery"
_TASK_ARTIFACTS = {
    SLICED_ARTIFACT_RECOVERY_TOOL: {"result": "recovery_result.json", "required": {
        "recovery_result.json", "recovery_protocol.json", "recovery_source_manifest.json",
        "independent_verification.json", "events.jsonl", "recovery_report.md"}},
    SLICING_TOOL: {"result": "sliced_result.json", "required": {
        "sliced_result.json", "protocol.json", "inputs.json", "events.jsonl",
        "pass_observations.jsonl", "predictions_sliced.jsonl", "fusion_details.jsonl",
        "context_reuse.json", "environment.json", "budget.json", "checkpoint_index.json",
        "checkpoint_journal.jsonl", "budget_snapshot.json",
        "metrics_baseline.json", "metrics_sliced.json", "sliced_comparison.json", "decision.json",
        "sliced_report.md"}},
    DIAGNOSIS_TOOL: {"result": "diagnosis_result.json", "required": {
        "diagnosis_result.json", "protocol.json", "inputs.json", "events.jsonl",
        "diagnosis_summary.json", "gt_details.jsonl", "fp_details.jsonl",
        "threshold_analysis.json", "decision.json", "diagnosis_report.md"}},
    COMPARISON_TOOL: {"result": "comparison_result.json", "required": {
        "comparison_result.json", "protocol.json", "inputs.json", "events.jsonl",
        "predictions_640.jsonl", "predictions_960.jsonl", "metrics_640.json",
        "metrics_960.json", "comparison.json", "comparison_report.md"}},
    REPAIR_TOOL: {"result": "repair_result.json", "required": {
        "repair_result.json", "repair_changes.jsonl", "input_manifest.json", "events.jsonl", "copy_manifest.json"}},
    AUDIT_TOOL: {
        "result": "audit_result.json",
        "required": {
            "dataset_check.json", "val_accessibility.json", "checker.log",
            "events.jsonl", "audit_result.json",
        },
    },
    GEOMETRY_TOOL: {
        "result": "verification_result.json",
        "required": {
            "verification_result.json", "geometry_details.jsonl", "fixture_results.json",
            "input_manifest.json", "events.jsonl",
        },
    },
}


def _task_tool(value: dict) -> str:
    # Absence means legacy audit, never an arbitrary third artifact contract.
    tool = value.get("tool", AUDIT_TOOL)
    if not isinstance(tool, str) or tool not in _TASK_ARTIFACTS:
        raise ValueError("Task tool is not supported")
    return tool


def _failure(task_id: str | None, stage: str, exc: BaseException, **details: Any) -> dict:
    return {
        "task_id": task_id, "status": "failed", "finished_at": _timestamp(),
        "errors": [{"stage": stage, "type": type(exc).__name__, "message": str(exc)}],
        **details,
    }


def _recent_events(task_dir: Path) -> list[dict]:
    path = task_dir / "events.jsonl"
    if not path.is_file():
        return []
    events = []
    with path.open("rb") as stream:
        stream.seek(0, os.SEEK_END)
        size = stream.tell()
        stream.seek(max(0, size - 128 * 1024))
        lines = stream.read().decode("utf-8", errors="replace").splitlines()
    for line in lines[-20:]:
        try:
            event = json.loads(line)
            if isinstance(event, dict):
                events.append(event)
        except (json.JSONDecodeError, ValueError):
            # An in-flight append can leave the last line temporarily partial.
            continue
    return events


def _running(task_id: str, entry: dict, task_dir: Path) -> dict:
    events = _recent_events(task_dir)
    return {
        "task_id": task_id, "tool": entry["tool"],
        "status": "running", "started_at": entry["started_at"],
        "finished_at": None, "worker_pid": entry["worker_pid"],
        "configuration": entry["configuration"], "output_dir": str(task_dir),
        "recent_events": events,
        "current_stage": events[-1].get("stage") if events else "worker_starting",
        "errors": [], "limitations": ["This task is not resumable after its worker process exits."],
    }


def _verify_label_geometry(configuration: dict, task_id: str) -> dict:
    # Keep the original audit path usable without importing the new verifier.
    from .geometry_verifier import verify_label_geometry

    return verify_label_geometry(configuration, task_id=task_id)


def _worker(task_id: str, configuration: dict, tool: str) -> None:
    try:
        if tool == AUDIT_TOOL:
            report = audit_dataset(configuration, task_id=task_id)
        elif tool == GEOMETRY_TOOL:
            report = _verify_label_geometry(configuration, task_id)
        elif tool == REPAIR_TOOL:
            from .label_repair import repair_label_copy
            report = repair_label_copy(configuration, task_id)
        elif tool == COMPARISON_TOOL:
            from .resolution_comparison import run_comparison
            report = run_comparison(configuration, task_id)
        elif tool == DIAGNOSIS_TOOL:
            from .diagnosis_task import run_diagnosis
            report = run_diagnosis(configuration, task_id)
        elif tool == SLICING_TOOL:
            from .sliced_task import run_sliced_comparison
            report = run_sliced_comparison(configuration, task_id)
        else:
            raise ValueError("This saved-task kind has no background start operation")
        if not isinstance(report, dict) or report.get("status") not in {"completed", "failed"}:
            raise ValueError(f"{tool} returned no terminal task result")
        if report.get("task_id") != task_id or _task_tool(report) != tool:
            raise ValueError("Task worker result ID/tool differs from the launched task")
    except BaseException as exc:
        stage = {AUDIT_TOOL: "audit_worker", GEOMETRY_TOOL: "geometry_worker", REPAIR_TOOL: "repair_worker", COMPARISON_TOOL: "comparison_worker", DIAGNOSIS_TOOL: "diagnosis_worker", SLICING_TOOL: "slicing_worker"}.get(tool, "worker_start")
        report = _failure(task_id, stage, exc, tool=tool)
    with _LOCK:
        _TASKS[task_id]["report"] = report


def start_audit(configuration: dict) -> dict:
    """Start an audit under the shared single-worker limit."""
    return _start_task(configuration, AUDIT_TOOL)


def start_geometry_verification(configuration: dict) -> dict:
    """Start geometry verification under the shared single-worker limit."""
    return _start_task(configuration, GEOMETRY_TOOL)


def start_label_repair(configuration: dict) -> dict:
    return _start_task(configuration, REPAIR_TOOL)


def start_resolution_comparison(configuration: dict) -> dict:
    return _start_task(configuration, COMPARISON_TOOL)


def start_diagnosis(configuration: dict) -> dict:
    return _start_task(configuration, DIAGNOSIS_TOOL)


def start_sliced_comparison(configuration: dict) -> dict:
    return _start_task(configuration, SLICING_TOOL)


def _start_task(configuration: dict, tool: str) -> dict:
    """Start one non-daemon worker and return immediately with its task ID."""
    task_id = uuid.uuid4().hex
    try:
        if not isinstance(configuration, dict):
            raise TypeError("configuration must be a dictionary")
        if tool not in {AUDIT_TOOL, GEOMETRY_TOOL, REPAIR_TOOL, COMPARISON_TOOL, DIAGNOSIS_TOOL, SLICING_TOOL}:
            raise ValueError("This saved-task kind is read-only and cannot start a worker")
        paths = _configured_paths(configuration)
        resolved = copy.deepcopy(configuration)
        resolved.update({key: str(path) for key, path in paths.items()})
        with _LOCK:
            for active_id, entry in _TASKS.items():
                if entry["thread"].is_alive():
                    return _failure(task_id, "worker_start", RuntimeError(
                        "A task worker is already running; poll the active task before starting another"
                    ), tool=tool, active_task_id=active_id, active_tool=entry["tool"])
            task_dir = paths["output_root"] / task_id
            if task_dir.exists():
                raise FileExistsError(f"Generated task directory already exists: {task_dir}")
            thread = threading.Thread(
                target=_worker, args=(task_id, resolved, tool),
                name=f"defect-{tool}-{task_id}", daemon=False,
            )
            entry = {
                "thread": thread, "tool": tool, "configuration": resolved,
                "output_root": paths["output_root"], "worker_pid": os.getpid(),
                "started_at": _timestamp(), "report": None,
            }
            _TASKS[task_id] = entry
            try:
                thread.start()
            except BaseException:
                _TASKS.pop(task_id, None)
                raise
            return _running(task_id, entry, task_dir)
    except Exception as exc:
        return _failure(task_id, "worker_start", exc, tool=tool)


def _task_file(task_dir: Path, filename: str) -> Path:
    path = task_dir / filename
    if path.resolve().parent != task_dir.resolve():
        raise ValueError(f"Task artifact points outside the task directory: {path}")
    if not path.is_file():
        raise FileNotFoundError(f"Missing task artifact: {path}")
    return path


def _json_object(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Task artifact must contain an object: {path}")
    return value


def _completed_report(task_dir: Path, task_id: str, expected_tool: str | None = None) -> dict:
    """Treat the final marker as necessary, then verify every listed file."""
    completion = _json_object(_task_file(task_dir, "completion.json"))
    if completion.get("status") != "completed" or completion.get("task_id") != task_id:
        raise ValueError("Completion marker status/task_id differs from the requested task")
    tool = _task_tool(completion)
    if expected_tool is not None and tool != expected_tool:
        raise ValueError("Completion marker tool differs from the launched task")
    manifest_path = _task_file(task_dir, "artifact_manifest.json")
    if Path(completion.get("artifact_manifest", "")).resolve() != manifest_path.resolve():
        raise ValueError("Completion marker references a different artifact manifest")
    if _sha256(manifest_path) != completion.get("artifact_manifest_sha256"):
        raise ValueError("Artifact manifest SHA256 differs from completion marker")
    manifest = _json_object(manifest_path)
    if manifest.get("task_id") != task_id or manifest.get("status") != "completed":
        raise ValueError("Artifact manifest status/task_id differs from completion marker")
    if _task_tool(manifest) != tool:
        raise ValueError("Artifact manifest tool differs from completion marker")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("Artifact manifest contains no file records")
    verified = {}
    for record in files:
        if not isinstance(record, dict):
            raise ValueError("Artifact manifest contains a malformed file record")
        name = record.get("name")
        if (not isinstance(name, str) or not name or Path(name).name != name
                or "/" in name or "\\" in name or name in {".", ".."} or name in verified):
            raise ValueError("Artifact manifest filenames must be unique single file names")
        if name in {"completion.json", "artifact_manifest.json"}:
            raise ValueError("Artifact manifest cannot hash itself or its final marker")
        artifact_path = _task_file(task_dir, name)
        if Path(record.get("path", "")).resolve() != artifact_path.resolve():
            raise ValueError(f"Artifact record references a different file: {name}")
        digest = _sha256(artifact_path)
        if digest != record.get("sha256") or artifact_path.stat().st_size != record.get("size_bytes"):
            raise ValueError(f"Artifact hash/size verification failed: {name}")
        verified[name] = digest
    required = _TASK_ARTIFACTS[tool]["required"]
    missing = required - verified.keys()
    if missing:
        raise ValueError(f"Artifact manifest omits required files: {', '.join(sorted(missing))}")
    if completion.get("artifacts_sha256") != verified:
        raise ValueError("Completion artifact hashes differ from the verified manifest")
    report = _json_object(_task_file(task_dir, _TASK_ARTIFACTS[tool]["result"]))
    if report.get("task_id") != task_id or report.get("status") != "completed":
        raise ValueError("Task result status/task_id differs from its completion marker")
    if _task_tool(report) != tool:
        raise ValueError("Task result tool differs from its completion marker")
    if tool == GEOMETRY_TOOL and (
        not isinstance(report.get("summary"), dict)
        or report["summary"].get("verification_status") not in {"passed", "failed"}
    ):
        raise ValueError("Geometry verification result has no passed/failed findings status")
    if tool == REPAIR_TOOL:
        _verify_copy(task_dir, report)
    if tool == COMPARISON_TOOL:
        _verify_comparison(task_dir, report)
    if tool == DIAGNOSIS_TOOL:
        _verify_diagnosis(task_dir, report)
    if tool == SLICING_TOOL:
        from .sliced_task import verify_sliced_artifacts
        verify_sliced_artifacts(task_dir, report)
    if tool == SLICED_ARTIFACT_RECOVERY_TOOL:
        from .sliced_artifact_recovery import verify_sliced_artifact_recovery
        verify_sliced_artifact_recovery(task_dir, report)
    report["recent_events"] = _recent_events(task_dir)
    return report


def _verify_diagnosis(task_dir: Path, report: dict) -> None:
    from .diagnosis_task import _protocol, FILES
    expected = _protocol()
    protocol = _json_object(task_dir / "protocol.json")
    if any(protocol.get(key) != value or type(protocol.get(key)) is not type(value) for key, value in expected.items()):
        raise ValueError("Diagnostic protocol differs from the frozen contract")
    summary = report.get("summary", {})
    if (summary.get("diagnosis_status") != "passed" or summary.get("input_hashes_unchanged") is not True
            or any(summary.get(key) is not False for key in ("new_inference_performed", "training_performed", "test_inference_performed"))):
        raise ValueError("Diagnostic result lacks its passed read-only evidence status")
    source_dir = task_dir.parent / expected["source_task_id"]
    source = _completed_report(source_dir, expected["source_task_id"], COMPARISON_TOOL)
    if source.get("configuration") != report.get("configuration"):
        raise ValueError("Diagnostic source configuration differs")
    evidence = report.get("evidence", {})
    if evidence.get("source_task_id") != expected["source_task_id"] or evidence.get("protocol_sha256") != _sha256(Path(__file__).resolve().parents[1] / "fixtures" / "diagnosis_protocol.json"):
        raise ValueError("Diagnostic source identity or protocol hash differs")
    if any(Path(report.get("artifacts", {}).get(key, "")).resolve() != (task_dir / name).resolve() for key, name in FILES.items()):
        raise ValueError("Diagnostic artifact pointers differ from this task")
    for key, name in (("source_completion_sha256", "completion.json"),
                      ("source_manifest_sha256", "artifact_manifest.json"),
                      ("predictions_640_sha256", "predictions_640.jsonl"),
                      ("predictions_960_sha256", "predictions_960.jsonl")):
        if evidence.get(key) != _sha256(source_dir / name) or protocol.get(key) != evidence.get(key):
            raise ValueError("Diagnostic source artifact binding differs")
    details = _json_object(task_dir / "diagnosis_summary.json")
    thresholds = _json_object(task_dir / "threshold_analysis.json")
    decision = _json_object(task_dir / "decision.json")
    inputs = _json_object(task_dir / "inputs.json")
    if (inputs.get("task_id") != report["task_id"] or inputs.get("source_task_id") != expected["source_task_id"]
            or inputs.get("all_unchanged") is not True or not isinstance(inputs.get("files"), list)
            or len(inputs["files"]) != summary.get("input_files")
            or any(inputs.get(key) != value for key, value in evidence.items())):
        raise ValueError("Diagnostic input evidence differs from its summary or source binding")
    roles = set()
    for entry in inputs["files"]:
        if (not isinstance(entry, dict) or not isinstance(entry.get("role"), str) or entry["role"] in roles
                or entry.get("unchanged") is not True or entry.get("sha256_before") != entry.get("sha256_after")
                or not isinstance(entry.get("sha256_before"), str) or re.fullmatch(r"[0-9a-f]{64}", entry["sha256_before"]) is None):
            raise ValueError("Diagnostic input manifest has inconsistent unchanged hashes")
        roles.add(entry["role"])
    for size in (640, 960):
        binding = [entry for entry in inputs["files"] if entry["role"] == f"source_artifact/predictions_{size}.jsonl"]
        if len(binding) != 1 or binding[0]["sha256_before"] != evidence[f"predictions_{size}_sha256"]:
            raise ValueError("Diagnostic input manifest has no matching source prediction hash")
    if decision.get("source_task_id") != expected["source_task_id"] or decision.get("predictions_sha256") != evidence["predictions_640_sha256"]:
        raise ValueError("Diagnostic decision source identity or prediction hash differs")
    if (details.get("reference") != summary.get("reference")
            or details.get("descriptive_960") != summary.get("descriptive_960")
            or thresholds.get("selection") != summary.get("threshold_selection")
            or decision.get("selection") != summary.get("threshold_selection")
            or decision.get("recommendations") != summary.get("recommendations")
            or decision.get("evidence_id") != evidence.get("evidence_id")
            or decision.get("automatically_applied") is not False or decision.get("new_inference_budget") != 0):
        raise ValueError("Diagnostic summary or decision differs across sealed artifacts")
    for size, key in ((640, "reference"), (960, "descriptive_960")):
        point = details[key].get("operating_point", {})
        previous = source["summary"]["metrics"][str(size)]["operating_point"]
        if (details[key].get("images") != 640 or details[key].get("gt") != 596
                or any(point.get(field) != previous.get(field) for field in ("tp", "fp", "fn", "precision", "recall", "normal_images"))
                or point.get("normal_fp_images") != previous.get("normal_images_with_false_positives")
                or sum(details[key].get("fn_categories", {}).values()) != point.get("fn")
                or sum(details[key].get("fp_categories", {}).values()) != point.get("fp")):
            raise ValueError("Diagnostic counts differ from the independently scored source experiment")
    # Recompute the business findings from bound predictions, so resealing a
    # misleading category/threshold decision cannot make it a completed task.
    from .detection_diagnosis import diagnose_detections
    from .geometry_verifier import CATEGORIES
    records = [json.loads(line) for line in (source_dir / "predictions_640.jsonl").read_text(encoding="utf-8").splitlines()]
    options = {key: expected[key] for key in ("prediction_floor", "normal_fp_budget", "max_normal_fp_images",
                                               "min_tp_gain", "min_gain_images", "min_scale_gt", "min_scale_fn")}
    options["threshold_grid"] = tuple(expected["threshold_grid"])
    calculated = diagnose_detections(records, {key - 1: value for key, value in CATEGORIES.items()},
                                    expected["confidence_threshold"], expected["iou_threshold"], **options)
    calculated["summary"]["operating_point"] = calculated["operating_point"]
    if (details["reference"] != calculated["summary"]
            or any(details.get(key) != calculated[key] for key in ("per_class", "per_size", "per_region"))
            or thresholds != {"protocol": calculated["protocol"], "curve": calculated["threshold_curve"], "selection": calculated["selection"]}
            or decision["recommendations"] != calculated["recommendations"]):
        raise ValueError("Diagnostic findings do not recompute from the bound predictions")
    for key in ("gt_details", "fp_details"):
        stored = [json.loads(line) for line in (task_dir / f"{key}.jsonl").read_text(encoding="utf-8").splitlines()]
        if stored != calculated[key]:
            raise ValueError("Diagnostic box details do not recompute from the bound predictions")


def _verify_comparison(task_dir: Path, report: dict) -> None:
    """A sealed comparison must still refer to its own passed geometry gate."""
    summary = report.get("summary", {})
    if summary.get("comparison_status") != "passed" or summary.get("input_hashes_unchanged") is not True:
        raise ValueError("Comparison has no passed verdict or unchanged input evidence")
    gate_dir = task_dir / "geometry_gate" / "gate"
    if gate_dir.resolve() != gate_dir.absolute() or not gate_dir.is_dir():
        raise ValueError("Geometry gate escapes its expected directory")
    gate = _completed_report(gate_dir, "gate", GEOMETRY_TOOL)
    if (gate["summary"]["verification_status"] != "passed" or
            gate["configuration"]["dataset_root"] != report["configuration"]["dataset_root"]):
        raise ValueError("Comparison geometry gate did not verify the configured dataset")
    protocol = _json_object(task_dir / "protocol.json")
    from .resolution_comparison import _protocol
    expected = _protocol()
    if (any(protocol.get(key) != value for key, value in expected.items())
            or summary.get("split") != "val" or summary.get("eval_imgsz") != [640, 960]
            or summary.get("train_imgsz") != 640 or summary.get("same_weight") is not True
            or summary.get("precision") != "FP32" or summary.get("device") != "0"
            or summary.get("test_inference_performed") is not False
            or summary.get("training_performed") is not False
            or summary.get("weight_sha256") != protocol.get("weight_sha256")):
        raise ValueError("Comparison is not the frozen same-weight validation protocol")
    marker = _json_object(task_dir / "completion.json")
    if marker.get("geometry_completion_sha256") != _sha256(gate_dir / "completion.json"):
        raise ValueError("Geometry completion differs from comparison publication")
    if (summary.get("geometry_task_id") != "gate" or
            Path(summary.get("geometry_completion", "")).resolve() != (gate_dir / "completion.json").resolve()):
        raise ValueError("Comparison points to an unrelated geometry gate")
    inputs = _json_object(task_dir / "inputs.json")
    if inputs.get("task_id") != report["task_id"] or inputs.get("all_unchanged") is not True:
        raise ValueError("Comparison input manifest has no unchanged verdict")
    metrics = {str(size): _json_object(task_dir / f"metrics_{size}.json") for size in (640, 960)}
    if (metrics["640"].get("dataset_signature") != metrics["960"].get("dataset_signature") or
            metrics["640"].get("counts", {}).get("images") != summary.get("val_images") or
            metrics["960"].get("counts", {}).get("images") != summary.get("val_images") or
            any(value.get("counts", {}).get("gt") != summary.get("val_boxes") for value in metrics.values())):
        raise ValueError("Comparison metric image/GT identities or counts differ")
    for size, value in metrics.items():
        selected = {key: value[key] for key in ("mAP50", "mAP50_95", "operating_point")}
        if summary.get("metrics", {}).get(size) != selected:
            raise ValueError("Comparison summary differs from saved metrics")
    if summary.get("comparison") != _json_object(task_dir / "comparison.json"):
        raise ValueError("Comparison summary differs from paired analysis")


def _verify_copy(task_dir: Path, report: dict) -> None:
    """A top-level marker cannot vouch for damaged or unrelated nested copies."""
    from .geometry_verifier import _safe
    summary = report.get("summary", {})
    copied = _json_object(_task_file(task_dir, "copy_manifest.json"))
    if copied.get("task_id") != report["task_id"] or copied.get("tool") != REPAIR_TOOL:
        raise ValueError("Copy manifest task/tool differs")
    changes = [json.loads(line) for line in _task_file(task_dir, "repair_changes.jsonl").read_text(encoding="utf-8").splitlines()]
    if len(changes) != summary.get("changed_files") or len({row["relative_path"] for row in changes}) != len(changes):
        raise ValueError("Repair change count or identities differ")
    if summary.get("repair_status") == "refused":
        if (summary.get("verification_status") is not None or changes or copied.get("copy_root") is not None
                or copied.get("files") != [] or copied.get("images") != [] or copied.get("after_verification") is not None
                or (task_dir / "dataset_copy").exists()):
            raise ValueError("Refused repair publishes modifications or a copy")
        return
    if summary.get("repair_status") != "passed" or summary.get("verification_status") != "passed":
        raise ValueError("Repair has no passed/refused outcome and independent verdict")
    root = _safe(task_dir / "dataset_copy", task_dir, file=False)
    if Path(copied.get("copy_root", "")).resolve() != root or Path(summary.get("copy_root", "")).resolve() != root or copied.get("verification_status") != "passed":
        raise ValueError("Copy root or independent verdict differs")
    names = set()
    for row in copied.get("files", []):
        relative = row.get("relative_path")
        if not isinstance(relative, str) or relative in names or relative.startswith("images/"):
            raise ValueError("Copy file names must be unique non-image paths")
        path = _safe(root / relative, root)
        if path.relative_to(root).as_posix() != relative or Path(row.get("path", "")).resolve() != path:
            raise ValueError("Copy file path differs from the sealed location")
        if _sha256(path) != row.get("sha256") or path.stat().st_size != row.get("size_bytes"):
            raise ValueError("Copy file hash/size differs: " + relative)
        names.add(relative)
    actual = set()
    image_names = set()
    for path in root.rglob("*"):
        _safe(path, root, file=path.is_file())
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            (image_names if relative.startswith("images/") else actual).add(relative)
    if actual != names or not {"manifest.json", "data.yaml"} <= names:
        raise ValueError("Copy text membership differs")
    image_records = copied.get("images", [])
    if len(image_records) != len({row.get("relative_path") for row in image_records}) or {row.get("relative_path") for row in image_records} != image_names:
        raise ValueError("Copy image membership differs")
    source_dataset = Path(report["configuration"]["dataset_root"])
    for row in image_records:
        relative = row["relative_path"]
        path = _safe(root / relative, root)
        source = _safe(source_dataset / relative, source_dataset)
        if row.get("storage") != "hardlink" or Path(row.get("path", "")).resolve() != path or Path(row.get("source_path", "")).resolve() != source or not os.path.samefile(source, path):
            raise ValueError("Copy image hard-link provenance differs")
    nested = copied.get("after_verification", {})
    nested_dir = _safe(task_dir / "after_verification" / "after", task_dir, file=False)
    if (nested.get("task_id") != "after" or Path(nested.get("output_root", "")).resolve() != nested_dir.parent
            or Path(nested.get("result_path", "")).resolve() != nested_dir / "verification_result.json"
            or Path(nested.get("completion_path", "")).resolve() != nested_dir / "completion.json"
            or nested.get("verification_status") != "passed"):
        raise ValueError("Independent verifier reference points outside its expected task")
    verified = _completed_report(nested_dir, "after", GEOMETRY_TOOL)
    if verified["summary"]["verification_status"] != "passed" or verified["configuration"]["dataset_root"] != str(root):
        raise ValueError("Independent verifier did not pass this exact copy")


def get_task_status(configuration: dict, task_id: str) -> dict:
    """Read a live task or verify its saved result, including after restart."""
    try:
        if not isinstance(task_id, str) or not _ID_PATTERN.fullmatch(task_id):
            raise ValueError("task_id must be a safe single directory name")
        if not isinstance(configuration, dict):
            raise TypeError("configuration must be a dictionary")
        paths = _configured_paths(configuration)
        task_dir = paths["output_root"] / task_id
        resolved_task = task_dir.resolve()
        resolved_output = paths["output_root"].resolve()
        same_parent = resolved_task.parent == resolved_output
        if not same_parent:
            # Windows can return an extended-length prefix for an existing
            # child while its parent uses a conventional drive spelling.
            # Compare filesystem identity rather than weakening containment.
            try:
                same_parent = os.path.samefile(resolved_task.parent, resolved_output)
            except OSError:
                same_parent = False
        if not same_parent or resolved_task.name != task_id:
            raise ValueError(f"Task directory resolves outside its configured location: {resolved_task}; root={resolved_output}")
        with _LOCK:
            entry = _TASKS.get(task_id)
            if entry is not None and entry["output_root"] != paths["output_root"]:
                entry = None
            live = entry is not None and entry["thread"].is_alive()
            report = copy.deepcopy(entry["report"]) if entry is not None else None
        if (task_dir / "completion.json").exists():
            return _completed_report(task_dir, task_id, entry["tool"] if entry is not None else None)
        if live:
            return _running(task_id, entry, task_dir)
        if (task_dir / "failure.json").is_file():
            failure = _json_object(_task_file(task_dir, "failure.json"))
            if failure.get("task_id") != task_id or failure.get("status") != "failed":
                raise ValueError("Saved failure has an inconsistent status/task_id")
            failure_tool = _task_tool(failure)
            if entry is not None and failure_tool != entry["tool"]:
                raise ValueError("Saved failure tool differs from the launched task")
            failure["recent_events"] = _recent_events(task_dir)
            return failure
        if report is not None and report.get("status") == "failed":
            report["recent_events"] = _recent_events(task_dir)
            return report
        if not task_dir.exists():
            raise FileNotFoundError(f"Unknown task: no saved directory or live worker for {task_id}")
        return {
            "task_id": task_id, "status": "failed", "interrupted": True,
            "finished_at": _timestamp(), "output_dir": str(task_dir),
            "recent_events": _recent_events(task_dir),
            "errors": [{"stage": "task_status", "type": "InterruptedTask",
                        "message": "Task has no completion marker and no live worker in this process"}],
            "limitations": ["The interrupted task was not resumed; start a new task to audit again."],
        }
    except Exception as exc:
        return _failure(task_id, "task_status", exc)
