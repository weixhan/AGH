"""Source-bound CPU domain calls for the bounded research controller.

The twelve inputs are artificial LabelGuard cases with frozen literal answers.
These calls execute the existing verifier and copy repair; they perform no
model, GPU, image decoding, training, or detection inference.  A completed
execution can have a failed geometry verdict or a refused repair.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from typing import Any

from . import geometry_verifier, independent_geometry, label_repair, labelguard_fixtures, task_runtime

SCHEMA_VERSION = 1
CALL_UPPER_BOUNDS = {"verify_label_geometry": 1, "repair_label_copy": 3, "verify_copy": 1}
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}")
_INPUT_KEYS = ("research_root", "dataset_root", "raw_root", "split_dir")


def _record(path: Path) -> dict:
    path = path.resolve()
    return {"path": str(path), "sha256": labelguard_fixtures.sha256(path),
            "size_bytes": path.stat().st_size}


def _digest(value: Any) -> str:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def _unlinked(path: Path) -> Path:
    for member in (path, *path.parents):
        if member.is_symlink() or (hasattr(member, "is_junction") and member.is_junction()):
            raise ValueError("Linked domain input/output paths are not accepted")
    return path.resolve()


def _spec_case(case_id: str) -> tuple[dict, dict]:
    if not isinstance(case_id, str):
        raise TypeError("case_id must be a frozen LabelGuard case name")
    specification = labelguard_fixtures.load_case_spec()
    matches = [case for case in specification["cases"] if case["id"] == case_id]
    if len(matches) != 1:
        raise ValueError("case_id is not one of the twelve frozen LabelGuard cases")
    return specification, matches[0]


def _dependencies(production_root: Path) -> dict:
    paths = {"adapter": Path(__file__), "case_builder": Path(labelguard_fixtures.__file__),
             "case_spec": labelguard_fixtures.FIXTURE_PATH,
             "geometry_verifier": Path(geometry_verifier.__file__),
             "independent_oracle": Path(independent_geometry.__file__),
             "oracle_fixtures": independent_geometry.FIXTURE_PATH,
             "label_repair": Path(label_repair.__file__),
             "saved_task_reader": Path(task_runtime.__file__),
             "production_geometry": production_root / "cableinspect_geometry.py"}
    return {name: _record(_unlinked(path)) for name, path in paths.items()}


def prepare_case(root: str | Path, case_id: str,
                 production_research_root: str | Path) -> dict:
    """Build one fresh artificial input with no caller-controlled model path."""
    specification, case = _spec_case(case_id)
    case_root = _unlinked(Path(root).absolute())
    production = _unlinked(Path(production_research_root).absolute())
    dependencies = _dependencies(production)
    built = labelguard_fixtures.build_case(case_root, case, specification, production)
    if dependencies != _dependencies(production):
        raise ValueError("Domain dependencies changed during artificial input preparation")
    return {"schema_version": SCHEMA_VERSION, "kind": "bounded_research_prepared_case",
            "case_id": case_id, "case_group": case["group"], "case_expected": case["expected"],
            "synthetic_only": True, "case_root": str(case_root),
            "configuration": built["configuration"],
            "source_snapshot": _record(Path(built["snapshot_path"])),
            "source_files": built["frozen"]["files"], "source_dependencies": dependencies,
            "inference_performed": False, "model_used": False}


def _validate_prepared(prepared: dict) -> tuple[dict, dict]:
    if (not isinstance(prepared, dict) or prepared.get("schema_version") != SCHEMA_VERSION
            or type(prepared.get("schema_version")) is not int
            or prepared.get("kind") != "bounded_research_prepared_case"
            or prepared.get("synthetic_only") is not True
            or prepared.get("inference_performed") is not False
            or prepared.get("model_used") is not False):
        raise ValueError("Domain calls require a source-bound artificial prepared case")
    _, case = _spec_case(prepared.get("case_id"))
    if prepared.get("case_expected") != case["expected"] or prepared.get("case_group") != case["group"]:
        raise ValueError("Prepared case differs from its frozen case specification")
    root = _unlinked(Path(prepared["case_root"]))
    snapshot = root / "frozen_inputs.json"
    if prepared.get("source_snapshot") != _record(snapshot):
        raise ValueError("Artificial input snapshot hash/size/path changed")
    frozen = geometry_verifier._json(snapshot)
    configuration = prepared.get("configuration")
    if (configuration != frozen.get("configuration") or frozen.get("case_id") != case["id"]
            or frozen.get("synthetic_only") is not True
            or frozen.get("spec_sha256") != labelguard_fixtures.EXPECTED_FIXTURE_SHA256):
        raise ValueError("Prepared input configuration or frozen identity differs")
    expected = {key: str(root / child) for key, child in (
        ("research_root", "research"), ("dataset_root", "dataset"),
        ("raw_root", "raw"), ("split_dir", "splits"), ("output_root", "task_outputs"))}
    expected["weights_path"] = str(root / "research" / "unused.pt")
    if configuration != expected:
        raise ValueError("Prepared configuration escapes its artificial input root")
    for key in _INPUT_KEYS:
        _unlinked(Path(configuration[key]))
    if prepared.get("source_files") != frozen.get("files"):
        raise ValueError("Prepared original-byte inventory differs from frozen snapshot")
    current = labelguard_fixtures.snapshot_inputs(configuration)
    if current != frozen["files"]:
        raise ValueError("Artificial original input membership/hash changed")
    dependencies = prepared.get("source_dependencies")
    if not isinstance(dependencies, dict) or "production_geometry" not in dependencies:
        raise ValueError("Prepared case has no bound domain dependency inventory")
    production = Path(dependencies["production_geometry"]["path"]).parent
    if dependencies != _dependencies(production):
        raise ValueError("Domain dependency membership/hash changed")
    if frozen["production_module"]["sha256"] != dependencies["production_geometry"]["sha256"]:
        raise ValueError("Artificial copied geometry differs from the bound production module")
    return configuration, frozen


def snapshot_case(prepared: dict) -> dict:
    """Public read-only source refresh; raise when frozen bytes have drifted."""
    configuration, _ = _validate_prepared(prepared)
    return labelguard_fixtures.snapshot_inputs(configuration)


def classify_geometry(evidence: dict) -> str:
    """Fail closed; route only independently completed, known label findings.

    Case names and literal expected answers are deliberately not consulted.
    The only execution-failure exception is an absent expected label whose
    exact path and trusted-source plan passed the narrow read-only guard.
    """
    if (not isinstance(evidence, dict) or evidence.get("tool") != "verify_label_geometry"
            or evidence.get("action") != "verify_label_geometry"
            or evidence.get("synthetic_only") is not True
            or evidence.get("inference_performed") is not False
            or evidence.get("model_used") is not False
            or not isinstance(evidence.get("input_before_after"), dict)
            or evidence["input_before_after"].get("unchanged") is not True):
        return "untrusted"
    if evidence.get("execution_status") == "failed":
        guard = evidence.get("source_guard", {})
        if (isinstance(guard, dict) and evidence.get("semantic_status") == "execution_failed"
                and guard.get("kind") == "missing_label_trusted_source_guard_v1"
                and guard.get("status") == "passed"
                and guard.get("original_inputs_unchanged") is True
                and guard.get("oracle_fixture_status") == "passed"
                and guard.get("planned_changed_files") == [guard.get("missing_label", {}).get("relative_path")]
                and isinstance(guard.get("missing_label", {}).get("relative_path"), str)):
            return "repairable"
        return "untrusted"
    if evidence.get("execution_status") != "completed" or evidence.get("task_chain_verified") is not True:
        return "untrusted"
    summary = evidence.get("summary", {})
    if (not isinstance(summary, dict) or summary.get("independent_geometry_verification") is not True
            or summary.get("inference_performed") is not False
            or summary.get("inputs_unchanged") is not True
            or summary.get("fixture_status") != "passed"):
        return "untrusted"
    issues = summary.get("issues_by_code")
    if not isinstance(issues, dict) or any(
            not isinstance(name, str) or type(count) is not int or count < 1
            for name, count in issues.items()):
        return "untrusted"
    if type(summary.get("issue_count")) is not int or summary["issue_count"] != sum(issues.values()):
        return "untrusted"
    if evidence.get("semantic_status") == "passed" and summary.get("verification_status") == "passed" and not issues:
        return "clean"
    allowed = {"declared_label_tree_hash", "yolo_geometry", "label_class", "metadata_geometry"}
    actual_differences = {"yolo_geometry", "label_class", "metadata_geometry"}
    if (evidence.get("semantic_status") == "failed" and summary.get("verification_status") == "failed"
            and issues and set(issues) <= allowed and set(issues) & actual_differences):
        return "repairable"
    return "untrusted"


def _missing_label_guard(configuration: dict, report: dict, directory: Path) -> dict:
    """Diagnose one absent label without repairing or hiding verifier failure."""
    guard = {"kind": "missing_label_trusted_source_guard_v1", "status": "untrusted",
             "read_only": True, "domain_tool_calls": 0, "original_inputs_unchanged": False}
    errors = report.get("errors", [])
    prefix = "Missing geometry input: "
    if (report.get("status") != "failed" or len(errors) != 1
            or errors[0].get("stage") != "label_geometry"
            or errors[0].get("type") != "FileNotFoundError"
            or not errors[0].get("message", "").startswith(prefix)):
        return guard
    try:
        missing = _unlinked(Path(errors[0]["message"][len(prefix):]))
        dataset = Path(configuration["dataset_root"])
        relative = missing.relative_to(dataset).as_posix()
        parts = Path(relative).parts
        if (len(parts) != 3 or parts[0] != "labels" or parts[1] not in geometry_verifier.SPLITS
                or missing.suffix != ".txt" or missing.exists()):
            raise ValueError("Failure does not identify one absent expected dataset label")
        fixtures = geometry_verifier._json(directory / "fixture_results.json")
        if fixtures.get("status") != "passed":
            raise ValueError("Missing label has no passed independent oracle fixture result")
        from .audit import _configured_paths
        paths = _configured_paths(configuration)
        before, image_before = label_repair._inventory(paths)
        _, plan, _ = label_repair._trusted_plan(paths, before)
        changed = sorted(item["relative_path"] for item in plan if item["changed"])
        missing_items = [item for item in plan if item["relative_path"] == relative]
        if (changed != [relative] or len(missing_items) != 1
                or missing_items[0]["original"] is not None
                or missing_items[0]["source_path"] != str(missing)):
            raise ValueError("Trusted-source diagnosis finds other differences or unrelated missing membership")
        if label_repair._inventory(paths) != (before, image_before):
            raise ValueError("Inputs changed during the read-only trusted-source diagnosis")
        guard.update(status="passed", original_inputs_unchanged=True, oracle_fixture_status="passed",
                     missing_label={"path": str(missing), "relative_path": relative},
                     planned_changed_files=changed, source_inventory_sha256=_digest(before),
                     trusted_manifest=_record(dataset / "manifest.json"),
                     source_scope="fixed raw/split hashes, class mapping, unique identity, membership and manifest counts",
                     limitations=["Initial independent geometry execution remains failed; this guard diagnoses the missing label only.",
                                  "Any new copy must pass the repair's independent verifier and a separate explicit verifier."])
    except (ValueError, FileNotFoundError, KeyError, TypeError, OSError) as error:
        guard["reason"] = {"type": type(error).__name__, "message": str(error)}
    return guard


def _output_configuration(configuration: dict, output_root: str | Path, task_id: str) -> dict:
    if not isinstance(task_id, str) or not _ID.fullmatch(task_id):
        raise ValueError("task_id must be a safe single directory name")
    output = _unlinked(Path(output_root).absolute())
    result = {**configuration, "output_root": str(output)}
    # The existing path gate forbids outputs overlapping any original inputs.
    from .audit import _configured_paths
    _configured_paths(result)
    if (output / task_id).exists():
        raise FileExistsError("A domain task directory already exists; history cannot be overwritten")
    return result


def _task_files(directory: Path) -> list[dict]:
    result = []
    if directory.is_dir():
        for path in sorted(directory.rglob("*")):
            _unlinked(path)
            if path.is_file():
                result.append({"relative_path": path.relative_to(directory).as_posix(), **_record(path)})
    return result


def _literal_matches(actual: Any, expected: Any, field: str | None = None) -> bool:
    if field in ("rotated_corners", "hbb_xyxy"):
        return geometry_verifier._numeric(actual, expected, 1e-8)[0]
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(
            key in actual and _literal_matches(actual[key], value, key) for key, value in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(
            _literal_matches(a, b) for a, b in zip(actual, expected))
    return actual == expected


def _nested_calls(report: dict, directory: Path) -> tuple[int, list[dict]]:
    """Count the repair's real before/after calls, including saved failures."""
    result = []
    stages = {"before": "before_verification", "after": "after_independent_verification"}
    for name, stage in stages.items():
        root = directory / (name + "_verification")
        task = root / name
        attempted = (task.is_dir() or any(error.get("stage") == stage for error in report.get("errors", []))
                     or (name == "before" and "before_verification_status" in report.get("summary", {}))
                     or (name == "after" and report.get("summary", {}).get("after_verification_task") == "after"))
        if attempted:
            configuration = {**report.get("configuration", {}), "output_root": str(root)}
            if name == "after":
                configuration["dataset_root"] = str(directory / "dataset_copy")
            saved = task_runtime.get_task_status(configuration, name)
            result.append({"task_id": name, "tool": "verify_label_geometry", "task_dir": str(task),
                           "execution_status": saved.get("status"),
                           "semantic_status": saved.get("summary", {}).get("verification_status", "execution_failed"),
                           "configuration": configuration})
    return len(result), result


def _evidence(prepared: dict, configuration: dict, task_id: str,
              report: dict, action: str, before: dict, frozen: dict) -> dict:
    directory = Path(configuration["output_root"]) / task_id
    saved = task_runtime.get_task_status(configuration, task_id)
    completed = report.get("status") == "completed"
    chain = (completed and saved.get("status") == "completed"
             and saved.get("tool") == report.get("tool")
             and saved.get("summary") == report.get("summary")
             and saved.get("configuration") == report.get("configuration"))
    if completed and not chain:
        raise ValueError("The executed domain task does not pass its saved completion chain")
    if not completed and saved.get("status") != "failed":
        raise ValueError("The failed domain task has no corresponding saved failure")
    source_guard = (_missing_label_guard(configuration, report, directory)
                    if action == "verify_label_geometry" and not completed else None)
    after = labelguard_fixtures.snapshot_inputs(prepared["configuration"])
    if before != after or after != frozen["files"]:
        raise ValueError("Original artificial input bytes changed during the domain call")
    _validate_prepared(prepared)
    summary = report.get("summary", {})
    semantic = (summary.get("repair_status") if action == "repair_label_copy"
                else summary.get("verification_status")) if completed else "execution_failed"
    if semantic not in {"passed", "failed", "refused", "execution_failed"}:
        raise ValueError("Domain task has no explicit semantic verdict")
    nested_count, nested = _nested_calls(report, directory) if action == "repair_label_copy" else (0, [])
    geometry_calls = nested_count if action == "repair_label_copy" else 1
    repair_calls = int(action == "repair_label_copy")
    artifacts = {key: _record(Path(value)) for key, value in report.get("artifacts", {}).items()
                 if Path(value).is_file()}
    checks = {"original_input_bytes_unchanged": True, "source_snapshot_unchanged": True,
              "saved_completion_chain_verified": chain}
    if action == "repair_label_copy" and semantic == "passed":
        copy = directory / "dataset_copy"
        changes = [json.loads(line) for line in (directory / "repair_changes.jsonl").read_text(
            encoding="utf-8").splitlines()]
        checks.update({"copied_labels_match_literal_goldens": all(
            (copy / name).read_bytes() == value.encode("utf-8") for name, value in frozen["golden_labels"].items()),
            "copied_metadata_match_literal_goldens": all(_literal_matches(
                geometry_verifier._json(copy / name), value) for name, value in frozen["golden_metadata"].items()),
            "changes_match_frozen_case_scope": sorted(row["relative_path"] for row in changes)
                == sorted(prepared["case_expected"]["changed_files"]),
            "positive_repair_changes": prepared["case_group"] != "repairable" or len(changes) > 0})
    return {"schema_version": SCHEMA_VERSION, "kind": "bounded_research_domain_evidence",
            "action": action, "tool": report.get("tool"), "task_id": task_id,
            "task_dir": str(directory), "case_id": prepared["case_id"],
            "synthetic_only": True, "configuration": configuration,
            "source_snapshot": prepared["source_snapshot"], "source_dependencies": prepared["source_dependencies"],
            "execution_status": report.get("status"), "semantic_status": semantic,
            "task_chain_verified": chain, "summary": summary, "errors": report.get("errors", []),
            "artifacts": artifacts, "task_files": _task_files(directory), "nested_tasks": nested,
            "source_guard": source_guard,
            "input_before_after": {"before": before, "after": after, "before_sha256": _digest(before),
                                   "after_sha256": _digest(after), "unchanged": True},
            "acceptance_checks": checks, "inference_performed": False, "model_used": False,
            "cost": {"domain_tool_calls": geometry_calls + repair_calls,
                     "geometry_verification_calls": geometry_calls, "repair_calls": repair_calls,
                     "gpu_seconds": 0.0, "model_requests": 0, "inference_calls": 0},
            "limitations": ["These are artificial LabelGuard inputs, not newly discovered live-data defects.",
                            "No image decoding, training, detection inference, or model requests are performed.",
                            "Completed execution and passed/refused/failed semantic verdicts are distinct."]}


def verify_case(prepared: dict, output_root: str | Path, task_id: str) -> dict:
    """Actually run independent geometry verification on the original case."""
    configuration, frozen = _validate_prepared(prepared)
    configuration = _output_configuration(configuration, output_root, task_id)
    before = labelguard_fixtures.snapshot_inputs(prepared["configuration"])
    report = geometry_verifier.verify_label_geometry(configuration, task_id)
    return _evidence(prepared, configuration, task_id, report, "verify_label_geometry", before, frozen)


def repair_case(prepared: dict, output_root: str | Path, task_id: str) -> dict:
    """Actually repair a new copy; reserve the three-call upper bound first."""
    configuration, frozen = _validate_prepared(prepared)
    configuration = _output_configuration(configuration, output_root, task_id)
    before = labelguard_fixtures.snapshot_inputs(prepared["configuration"])
    report = label_repair.repair_label_copy(configuration, task_id)
    return _evidence(prepared, configuration, task_id, report, "repair_label_copy", before, frozen)


def verify_copy(prepared: dict, repair_evidence: dict,
                output_root: str | Path, task_id: str) -> dict:
    """Perform a fresh explicit verifier call on this exact verified repair copy."""
    configuration, frozen = _validate_prepared(prepared)
    if (not isinstance(repair_evidence, dict) or repair_evidence.get("kind") != "bounded_research_domain_evidence"
            or repair_evidence.get("action") != "repair_label_copy"
            or repair_evidence.get("tool") != "repair_label_copy"
            or repair_evidence.get("case_id") != prepared["case_id"]
            or repair_evidence.get("source_snapshot") != prepared["source_snapshot"]
            or repair_evidence.get("synthetic_only") is not True
            or repair_evidence.get("execution_status") != "completed"
            or repair_evidence.get("semantic_status") != "passed"
            or repair_evidence.get("task_chain_verified") is not True):
        raise ValueError("Explicit copy verification requires this case's passed repair evidence")
    repair_config = repair_evidence.get("configuration", {})
    if any(repair_config.get(key) != configuration[key] for key in (*_INPUT_KEYS, "weights_path")):
        raise ValueError("Repair evidence points to an unrelated artificial input")
    repair_dir = Path(repair_config["output_root"]) / repair_evidence["task_id"]
    if repair_evidence.get("task_dir") != str(repair_dir) or repair_evidence.get("task_files") != _task_files(repair_dir):
        raise ValueError("Bound repair artifact membership/hash changed")
    saved = task_runtime.get_task_status(repair_config, repair_evidence["task_id"])
    if (saved.get("status") != "completed" or saved.get("tool") != "repair_label_copy"
            or saved.get("summary") != repair_evidence["summary"]
            or saved.get("summary", {}).get("repair_status") != "passed"):
        raise ValueError("Saved repair completion chain or semantic result changed")
    copy_root = _unlinked(repair_dir / "dataset_copy")
    if saved["summary"].get("copy_root") != str(copy_root):
        raise ValueError("Repair copy points outside its saved task")
    configuration = _output_configuration({**configuration, "dataset_root": str(copy_root)}, output_root, task_id)
    before = labelguard_fixtures.snapshot_inputs(prepared["configuration"])
    report = geometry_verifier.verify_label_geometry(configuration, task_id)
    evidence = _evidence(prepared, configuration, task_id, report, "verify_copy", before, frozen)
    evidence["repair_source"] = {"task_id": repair_evidence["task_id"], "task_dir": str(repair_dir),
                                 "completion": _record(repair_dir / "completion.json"),
                                 "copy_root": str(copy_root)}
    return evidence
