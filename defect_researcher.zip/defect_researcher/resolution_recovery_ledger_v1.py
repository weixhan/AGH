"""Single-writer, durable accounting for five ordered full-validation groups.

Replay uses live admission rules. Read-only inspection never takes the writer
lock. This module imports neither a detector nor a GPU runtime.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from functools import wraps
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
import threading

STEPS = {'reference_640': 640, 'reference_960': 960,
         'fault_640': 640, 'fault_960': 960, 'resume_960': 960}
GROUPS = tuple(STEPS)
TICKET_KEYS = {'call_index', 'kind', 'step_id', 'image_id', 'imgsz'}
ROW_KEYS = {'schema_version', 'sequence', 'previous_sha256', 'registration_sha256',
            'event', 'at_epoch', 'at_monotonic', 'wall_seconds', 'payload', 'sha256'}
CLOSED_KEYS = {'ticket', 'status', 'elapsed_seconds', 'gpu_seconds', 'cost_known', 'details'}
DETAIL_KEYS = {'utc_started', 'utc_finished', 'cost_known', 'prediction_entered',
               'prediction_returned', 'step_id', 'image_id', 'imgsz', 'kind',
               'error_type', 'error_message', 'timing_error_type'}
SHA = re.compile(r'[0-9a-f]{64}\Z')


def synchronized(function):
    @wraps(function)
    def guarded(self, *args, **kwargs):
        with self._mutex:
            return function(self, *args, **kwargs)
    return guarded


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode('utf8')


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def decode(text):
    def pairs(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError('Duplicate ledger JSON key')
            result[key] = item
        return result
    return json.loads(text, object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def finite(value, *, positive=False):
    return (type(value) in (int, float) and math.isfinite(value)
            and (value > 0 if positive else value >= 0))


def exact(value, keys, name):
    if type(value) is not dict or set(value) != keys:
        raise ValueError(name + ' has missing or unknown fields')


def unlinked(path):
    path = Path(path).absolute()
    for member in (path, *path.parents):
        if member.is_symlink() or (hasattr(member, 'is_junction') and member.is_junction()):
            raise ValueError('Linked ledger paths are refused')
    return path.resolve()


def validate_registration(registration):
    exact(registration, {'budgets', 'image_ids', 'started_epoch', 'started_monotonic'}, 'Registration')
    limits = registration['budgets']
    required = {'max_prediction_calls': 3205, 'max_formal_calls': 3200,
                'max_warmup_calls': 5, 'max_recovery_attempts': 1}
    exact(limits, set(required) | {'max_task_wall_seconds', 'max_gpu_seconds'}, 'Budgets')
    if any(type(limits[key]) is not int or limits[key] != value for key, value in required.items()):
        raise ValueError('Full-validation fixed prediction population differs')
    if any(not finite(limits[key], positive=True) for key in ('max_task_wall_seconds', 'max_gpu_seconds')):
        raise ValueError('Finite task/GPU limits must be registered before execution')
    ids = registration['image_ids']
    if (type(ids) is not list or len(ids) != 640
            or any(type(identity) is not str or not identity.strip() for identity in ids)
            or len(set(ids)) != 640 or ids != sorted(ids)):
        raise ValueError('Exactly 640 unique nonempty sorted validation IDs are required')
    if any(not finite(registration[key]) for key in ('started_epoch', 'started_monotonic')):
        raise ValueError('Original task clock anchors are required')
    return deepcopy(registration)


class Ledger:
    def __init__(self, directory, registration, *, create=False, clock=None, read_only=False):
        self._mutex = threading.RLock()
        if type(create) is not bool or type(read_only) is not bool or (create and read_only):
            raise ValueError('Invalid ledger creation/inspection mode')
        self.registration = validate_registration(registration)
        self.registration_sha256 = digest(self.registration)
        self.directory = unlinked(directory)
        if not self.directory.is_dir():
            raise ValueError('Caller-owned ledger directory is required')
        self.clock = clock or time
        self.path = unlinked(self.directory / 'shared_prediction_journal.jsonl')
        self.read_only, self._released, self._writer = read_only, False, None
        self._writer_path = None
        self.head, self.sequence = '0' * 64, 0
        self.calls, self.gpu_seconds, self.elapsed_seconds = [], 0.0, 0.0
        self.formal_calls, self.warmup_calls = 0, 0
        self.active, self.cost_known, self.has_failed_call = None, True, False
        self._last_epoch = self.registration['started_epoch']
        self._last_monotonic = self.registration['started_monotonic']
        self._journal_hasher, self._journal_size = hashlib.sha256(), 0
        try:
            if not read_only:
                self._acquire_writer()
            self._time()
            if create:
                with self.path.open('xb') as stream:
                    stream.flush()
                    os.fsync(stream.fileno())
            else:
                self._load()
                self._time()
        except BaseException:
            self.close()
            raise

    def _acquire_writer(self):
        path = unlinked(self.directory / 'shared_prediction_writer.lock')
        stream = path.open('a+b')
        try:
            if stream.seek(0, 2) == 0:
                stream.write(b'\0')
                stream.flush()
            stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            stream.close()
            raise ValueError('Another ledger writer owns this task') from error
        self._writer = stream
        self._writer_path = path

    @synchronized
    def close(self):
        stream, self._writer = self._writer, None
        self._released = True
        if stream is not None:
            try:
                stream.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            finally:
                stream.close()

    def __enter__(self):
        self._assert_open()
        return self

    def __exit__(self, *_):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def _assert_open(self, *, writable=False):
        if self._released:
            raise ValueError('Ledger handle has been released')
        if writable and (self.read_only or self._writer is None):
            raise ValueError('Read-only inspection cannot admit or close predictions')

    def _assert_current(self):
        self._assert_open()
        if digest(self.registration) != self.registration_sha256:
            raise ValueError('Registered budget, membership or clock anchor changed')
        if self._writer is not None:
            current = unlinked(self._writer_path).stat()
            held = os.fstat(self._writer.fileno())
            if (current.st_dev, current.st_ino) != (held.st_dev, held.st_ino):
                raise ValueError('Writer lock file identity changed')
        if unlinked(self.path) != self.path:
            raise ValueError('Ledger path changed')
        raw = self.path.read_bytes()
        if len(raw) != self._journal_size or hashlib.sha256(raw).digest() != self._journal_hasher.digest():
            raise ValueError('Journal changed outside the current writer; stale ledger refused')

    def _time(self):
        epoch, mono = self.clock.time(), self.clock.monotonic()
        if (not finite(epoch) or not finite(mono)
                or epoch < self._last_epoch or mono < self._last_monotonic):
            raise ValueError('Original task clock moved backwards or is unavailable')
        wall = max(epoch - self.registration['started_epoch'], mono - self.registration['started_monotonic'])
        if not finite(wall):
            raise ValueError('Invalid original task elapsed time')
        self._last_epoch, self._last_monotonic = epoch, mono
        return epoch, mono, wall

    def _admit(self, wall):
        limits = self.registration['budgets']
        if wall >= limits['max_task_wall_seconds'] or self.elapsed_seconds >= limits['max_task_wall_seconds']:
            raise ValueError('Original task deadline or shared elapsed-cost budget expired')
        if not self.cost_known or self.has_failed_call:
            raise ValueError('Unknown cost or failed detector call forbids further prediction')
        if not finite(self.gpu_seconds) or self.gpu_seconds >= limits['max_gpu_seconds']:
            raise ValueError('Shared GPU budget exhausted or unknown')

    @synchronized
    def check(self):
        self._assert_open(writable=True)
        self._assert_current()
        _, _, wall = self._time()
        self._admit(wall)
        return {'wall_seconds': wall, 'gpu_seconds': self.gpu_seconds, 'prediction_calls': len(self.calls)}

    def _ticket_shape(self, ticket):
        exact(ticket, TICKET_KEYS, 'Prediction ticket')
        if (type(ticket['call_index']) is not int or ticket['call_index'] < 1
                or type(ticket['kind']) is not str or ticket['kind'] not in ('warmup', 'formal')
                or type(ticket['step_id']) is not str or ticket['step_id'] not in STEPS
                or type(ticket['image_id']) is not str or ticket['image_id'] not in self.registration['image_ids']
                or type(ticket['imgsz']) is not int or ticket['imgsz'] != STEPS[ticket['step_id']]):
            raise ValueError('Invalid typed prediction ticket')

    def _reservation(self, ticket, wall):
        self._ticket_shape(ticket)
        self._admit(wall)
        if self.active is not None:
            raise ValueError('An open prediction reservation cannot be overlapped')
        limits, count = self.registration['budgets'], len(self.calls)
        if count >= limits['max_prediction_calls']:
            raise ValueError('Shared prediction-call budget exhausted')
        if (self.warmup_calls if ticket['kind'] == 'warmup' else self.formal_calls) >= limits['max_' + ticket['kind'] + '_calls']:
            raise ValueError('Shared typed prediction-call budget exhausted')
        group, position = divmod(count, 641)
        step = GROUPS[group]
        expected = {'call_index': count + 1, 'kind': 'warmup' if position == 0 else 'formal',
                    'step_id': step, 'image_id': self.registration['image_ids'][max(position - 1, 0)], 'imgsz': STEPS[step]}
        if ticket != expected:
            raise ValueError('Frozen five-group order or ordered 640-member population differs')

    def _details(self, details, ticket, known):
        if type(details) is not dict or not set(details) <= DETAIL_KEYS:
            raise ValueError('Receipt details have unknown fields')
        if 'cost_known' in details and details['cost_known'] is not known:
            raise ValueError('Receipt cost-known declaration differs from actual cost')
        for key in ('prediction_entered', 'prediction_returned'):
            if key in details and type(details[key]) is not bool:
                raise ValueError('Receipt prediction flags must be booleans')
        for key in ('step_id', 'image_id', 'imgsz', 'kind'):
            if key in details and (type(details[key]) is not type(ticket[key]) or details[key] != ticket[key]):
                raise ValueError('Receipt details disagree with the reserved identity')
        for key in ('utc_started', 'utc_finished'):
            if key in details and (type(details[key]) is not str or not details[key]):
                raise ValueError('Invalid UTC receipt timestamp')
        for key in ('error_type', 'error_message', 'timing_error_type'):
            if key in details and details[key] is not None and type(details[key]) is not str:
                raise ValueError('Invalid receipt error metadata')

    def _closure(self, payload):
        exact(payload, CLOSED_KEYS, 'Closed receipt')
        ticket = payload['ticket']
        self._ticket_shape(ticket)
        if self.active is None or ticket != self.active:
            raise ValueError('Receipt does not close the one reserved prediction')
        if type(payload['status']) is not str or payload['status'] not in ('passed', 'failed'):
            raise ValueError('Invalid prediction terminal status')
        elapsed, gpu = payload['elapsed_seconds'], payload['gpu_seconds']
        if any(value is not None and not finite(value) for value in (elapsed, gpu)):
            raise ValueError('Invalid actual prediction cost')
        known = elapsed is not None and gpu is not None
        if payload['cost_known'] is not known:
            raise ValueError('Persisted cost-known declaration differs from actual cost')
        self._details(payload['details'], ticket, known)

    def _apply(self, event, payload):
        if event == 'reserved':
            self.active = deepcopy(payload)
            self.calls.append({**deepcopy(payload), 'status': 'open'})
            self.warmup_calls += payload['kind'] == 'warmup'
            self.formal_calls += payload['kind'] == 'formal'
        else:
            self.calls[-1].update(deepcopy(payload))
            self.active = None
            self.cost_known = self.cost_known and payload['cost_known']
            self.has_failed_call = self.has_failed_call or payload['status'] == 'failed'
            if payload['gpu_seconds'] is not None:
                self.gpu_seconds += payload['gpu_seconds']
            if payload['elapsed_seconds'] is not None:
                self.elapsed_seconds += payload['elapsed_seconds']

    def _append(self, event, payload):
        self._assert_open(writable=True)
        self._assert_current()
        epoch, mono, wall = self._time()
        if event == 'reserved':
            self._reservation(payload, wall)
        else:
            self._closure(payload)
        base = {'schema_version': 1, 'sequence': self.sequence + 1, 'previous_sha256': self.head,
                'registration_sha256': self.registration_sha256, 'event': event,
                'at_epoch': epoch, 'at_monotonic': mono, 'wall_seconds': wall, 'payload': deepcopy(payload)}
        row = {**base, 'sha256': digest(base)}
        raw = canonical(row) + b'\n'
        with self.path.open('ab') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        self._journal_hasher.update(raw)
        self._journal_size += len(raw)
        self.sequence, self.head = row['sequence'], row['sha256']
        self._apply(event, payload)

    @synchronized
    def reserve(self, kind, step_id, image_id, imgsz):
        self.check()
        ticket = {'call_index': len(self.calls) + 1, 'kind': kind, 'step_id': step_id, 'image_id': image_id, 'imgsz': imgsz}
        self._append('reserved', ticket)
        return deepcopy(ticket)

    @synchronized
    def closed(self, ticket, status, elapsed_seconds, gpu_seconds, **details):
        # A late receipt records actual cost; it cannot authorize another call.
        payload = {'ticket': deepcopy(ticket), 'status': status, 'elapsed_seconds': elapsed_seconds,
                   'gpu_seconds': gpu_seconds, 'cost_known': elapsed_seconds is not None and gpu_seconds is not None,
                   'details': deepcopy(details)}
        self._append('closed', payload)

    def _load(self):
        data = self.path.read_bytes()
        if data and not data.endswith(b'\n'):
            raise ValueError('Partial journal tail; no safe recovery')
        last_epoch, last_mono = self.registration['started_epoch'], self.registration['started_monotonic']
        for line in data.splitlines():
            row = decode(line)
            exact(row, ROW_KEYS, 'Journal row')
            base = {key: value for key, value in row.items() if key != 'sha256'}
            if (type(row['schema_version']) is not int or row['schema_version'] != 1
                    or type(row['sequence']) is not int or row['sequence'] != self.sequence + 1
                    or any(type(row[key]) is not str or not SHA.fullmatch(row[key]) for key in
                           ('previous_sha256', 'registration_sha256', 'sha256'))
                    or row['previous_sha256'] != self.head or row['registration_sha256'] != self.registration_sha256
                    or row['sha256'] != digest(base)):
                raise ValueError('Journal identity, order or hash-chain mismatch')
            epoch, mono, wall = row['at_epoch'], row['at_monotonic'], row['wall_seconds']
            if (not all(finite(value) for value in (epoch, mono, wall)) or epoch < last_epoch or mono < last_mono
                    or wall != max(epoch - self.registration['started_epoch'], mono - self.registration['started_monotonic'])):
                raise ValueError('Persisted original clock is invalid, backwards or inconsistent')
            if type(row['event']) is not str or row['event'] not in ('reserved', 'closed'):
                raise ValueError('Unknown journal event')
            if row['event'] == 'reserved':
                self._reservation(row['payload'], wall)
            else:
                self._closure(row['payload'])
            self._apply(row['event'], row['payload'])
            self.sequence, self.head = row['sequence'], row['sha256']
            last_epoch, last_mono = epoch, mono
        self._last_epoch, self._last_monotonic = last_epoch, last_mono
        self._journal_hasher, self._journal_size = hashlib.sha256(data), len(data)
        if self.active is not None:
            self.cost_known = False

    @synchronized
    def summary(self):
        self._assert_current()
        _, _, wall = self._time()
        limits = self.registration['budgets']
        cost_known = self.cost_known and self.active is None
        complete_groups = sum(len(group) == 641 and all(row['status'] == 'passed' and row.get('cost_known') is True for row in group)
                              for index in range(5) for group in [self.calls[index * 641:(index + 1) * 641]])
        return {'schema_version': 1, 'registration_sha256': self.registration_sha256,
                'prediction_calls': len(self.calls), 'formal_calls': self.formal_calls, 'warmup_calls': self.warmup_calls,
                'gpu_seconds': self.gpu_seconds if cost_known else None, 'known_gpu_seconds': self.gpu_seconds,
                'elapsed_prediction_seconds': self.elapsed_seconds, 'wall_seconds': wall, 'cost_known': cost_known,
                'open_call': deepcopy(self.active), 'failed_detector_call': self.has_failed_call,
                'complete_groups': complete_groups, 'all_groups_complete': complete_groups == 5 and cost_known and not self.has_failed_call,
                'within_registered_limits': wall < limits['max_task_wall_seconds']
                    and self.elapsed_seconds <= limits['max_task_wall_seconds'] and self.gpu_seconds <= limits['max_gpu_seconds'] and cost_known,
                'journal_events': self.sequence, 'journal_head_sha256': self.head,
                'journal_path': str(self.path), 'journal_sha256': self._journal_hasher.hexdigest(), 'journal_size_bytes': self._journal_size,
                'captured_at': datetime.now(timezone.utc).isoformat()}
