"""Command-line entry point for the first DefectResearcher tool."""
from __future__ import annotations

import argparse
import json
import sys

from .config import load_config


def main() -> int:
    parser = argparse.ArgumentParser(description="DefectResearcher: audit data and save evidence")
    parser.add_argument("--config", help="Path configuration JSON; no credentials")
    parser.add_argument("command", choices=("paths", "audit", "verify", "repair", "compare", "diagnose", "slices", "mcp"))
    parser.add_argument("--resume-from", help="Failed sliced task ID; only slices supports verified checkpoint reuse")
    args = parser.parse_args()
    if args.resume_from and args.command != "slices":
        parser.error("--resume-from is supported only by slices")
    try:
        configuration = load_config(args.config)
        if args.command == "paths":
            result = configuration
        elif args.command == "mcp":
            from .mcp_server import serve
            serve(configuration)
            return 0
        elif args.command == "verify":
            from .geometry_verifier import verify_label_geometry
            result = verify_label_geometry(configuration)
        elif args.command == "repair":
            from .label_repair import repair_label_copy
            result = repair_label_copy(configuration)
        elif args.command == "compare":
            from .resolution_comparison import run_comparison
            result = run_comparison(configuration)
        elif args.command == "diagnose":
            from .diagnosis_task import run_diagnosis
            result = run_diagnosis(configuration)
        elif args.command == "slices":
            from .sliced_task import run_sliced_comparison
            result = run_sliced_comparison(configuration, resume_from=args.resume_from)
        else:
            from .audit import audit_dataset
            result = audit_dataset(configuration)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if args.command == "verify":
            return 0 if (result.get("status") == "completed" and
                         result.get("summary", {}).get("verification_status") == "passed") else 1
        if args.command == "repair":
            return 0 if (result.get("status") == "completed" and
                         result.get("summary", {}).get("repair_status") == "passed" and
                         result.get("summary", {}).get("verification_status") == "passed") else 1
        if args.command == "compare":
            return 0 if (result.get("status") == "completed" and
                         result.get("summary", {}).get("comparison_status") == "passed") else 1
        if args.command == "diagnose":
            return 0 if (result.get("status") == "completed" and
                         result.get("summary", {}).get("diagnosis_status") == "passed") else 1
        if args.command == "slices":
            return 0 if (result.get("status") == "completed" and
                         result.get("summary", {}).get("slicing_status") == "passed") else 1
        return 1 if (result.get("status") == "failed" or
                     result.get("summary", {}).get("verification_status") == "failed") else 0
    except (OSError, ValueError) as error:
        print(json.dumps({"status": "failed", "errors": [str(error)]}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
