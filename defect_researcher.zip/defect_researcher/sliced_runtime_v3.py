"""Read-only, fixed-code routing for V3 and preserved historical task evidence.

This sidecar is intentionally separate from the frozen MCP runtime. It does
not register a new start tool or load Python paths supplied by saved artifacts.
"""
from __future__ import annotations

import os
from pathlib import Path

from .audit import _configured_paths, _sha256
from . import task_runtime as historical
from . import sliced_task_v3 as runner


def _directory(configuration, task_id):
    if not isinstance(configuration, dict):
        raise TypeError("configuration must be a dictionary")
    if not isinstance(task_id, str) or not historical._ID_PATTERN.fullmatch(task_id):
        raise ValueError("task_id must be a safe single directory name")
    paths = _configured_paths(configuration)
    directory = paths["output_root"] / task_id
    resolved, root = directory.resolve(), paths["output_root"].resolve()
    same_parent = resolved.parent == root
    if not same_parent:
        try:
            same_parent = os.path.samefile(resolved.parent, root)
        except OSError:
            same_parent = False
    if not same_parent or resolved.name != task_id:
        raise ValueError("Task evidence escapes its configured output directory")
    return directory, paths


def _contract(directory, task_id):
    protocol = historical._json_object(historical._task_file(directory, "protocol.json"))
    expected = runner._protocol()
    if (protocol.get("task_id") != task_id or protocol.get("tool") != runner.TOOL
            or type(protocol.get("execution_io_version")) is not int
            or protocol["execution_io_version"] != runner.EXECUTION_VERSION
            or any(key not in protocol or not runner._contract_equal(protocol[key], value) for key, value in expected.items())
            or protocol.get("protocol_sha256") != _sha256(runner.PROTOCOL_PATH)):
        raise ValueError("Unknown V3 tool/protocol/schema/implementation version")
    inputs = historical._json_object(historical._task_file(directory, "inputs.json"))
    if inputs.get("task_id") != task_id:
        raise ValueError("V3 inputs reference another task")
    runner.validate_execution_manifest(inputs, protocol.get("execution_source_sha256"),
                                       protocol.get("scientific_inputs_sha256"))


def _completed_v3(directory, task_id, paths):
    """Verify the full completion chain, then use the named V3 semantic reader."""
    _contract(directory, task_id)
    marker = historical._json_object(historical._task_file(directory, "completion.json"))
    if marker.get("task_id") != task_id or marker.get("tool") != runner.TOOL or marker.get("status") != "completed":
        raise ValueError("V3 completion identity differs")
    manifest_path = historical._task_file(directory, "artifact_manifest.json")
    if (Path(marker.get("artifact_manifest", "")).resolve() != manifest_path.resolve()
            or marker.get("artifact_manifest_sha256") != _sha256(manifest_path)):
        raise ValueError("V3 completion manifest pointer/hash differs")
    manifest = historical._json_object(manifest_path)
    if manifest.get("task_id") != task_id or manifest.get("tool") != runner.TOOL or manifest.get("status") != "completed":
        raise ValueError("V3 manifest identity differs")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("V3 manifest has no artifacts")
    verified = {}
    for record in files:
        if not isinstance(record, dict):
            raise ValueError("V3 artifact record is not an object")
        name = record.get("name")
        if (not isinstance(name, str) or not name or Path(name).name != name
                or "/" in name or "\\" in name or name in {".", "..", "completion.json", "artifact_manifest.json"}
                or name in verified):
            raise ValueError("V3 artifact names are not unique direct files")
        path = historical._task_file(directory, name)
        if (Path(record.get("path", "")).resolve() != path.resolve()
                or type(record.get("size_bytes")) is not int or record["size_bytes"] != path.stat().st_size
                or record.get("sha256") != _sha256(path)):
            raise ValueError(f"V3 artifact hash/size/path differs: {name}")
        verified[name] = record["sha256"]
    required = {name for key, name in runner.FILES.items() if key not in {"manifest", "completion"}}
    if required - verified.keys() or marker.get("artifacts_sha256") != verified:
        raise ValueError("V3 artifact manifest/marker lacks its exact required files")
    published = (directory / "completion.json").stat().st_mtime_ns
    if published < max([manifest_path.stat().st_mtime_ns, *[
            historical._task_file(directory, name).stat().st_mtime_ns for name in verified]]):
        raise ValueError("V3 completion marker was not published last")
    report = historical._json_object(historical._task_file(directory, runner.FILES["result"]))
    if (report.get("task_id") != task_id or report.get("tool") != runner.TOOL
            or report.get("status") != "completed"
            or report.get("configuration") != {key: str(value) for key, value in paths.items()}):
        raise ValueError("V3 result identity/configuration differs")
    runner.verify_sliced_artifacts(directory, report)
    report["recent_events"] = historical._recent_events(directory)
    return report


def get_task_status(configuration, task_id):
    """Historical tools delegate unchanged; only the named V3 contract uses V3."""
    try:
        directory, paths = _directory(configuration, task_id)
        marker_path, failure_path = directory / "completion.json", directory / "failure.json"
        if marker_path.exists():
            marker = historical._json_object(historical._task_file(directory, "completion.json"))
            tool = marker.get("tool", historical.AUDIT_TOOL)
            if tool == runner.TOOL:
                return _completed_v3(directory, task_id, paths)
            if not isinstance(tool, str) or tool not in historical._TASK_ARTIFACTS:
                raise ValueError("Unknown saved task tool; no verifier can be selected")
            return historical.get_task_status(configuration, task_id)
        if failure_path.exists():
            failure = historical._json_object(historical._task_file(directory, "failure.json"))
            tool = failure.get("tool", historical.AUDIT_TOOL)
            if tool == runner.TOOL:
                if failure.get("task_id") != task_id or failure.get("status") != "failed":
                    raise ValueError("V3 saved failure identity differs")
                if (directory / "protocol.json").exists():
                    _contract(directory, task_id)
                failure["recent_events"] = historical._recent_events(directory)
                return failure
            if not isinstance(tool, str) or tool not in historical._TASK_ARTIFACTS:
                raise ValueError("Unknown saved failure tool")
            return historical.get_task_status(configuration, task_id)
        if (directory / "protocol.json").exists():
            protocol = historical._json_object(historical._task_file(directory, "protocol.json"))
            if protocol.get("tool") == runner.TOOL:
                _contract(directory, task_id)
                raise ValueError("V3 task has no completion marker or terminal failure; no success can be inferred")
        return historical.get_task_status(configuration, task_id)
    except Exception as error:
        return historical._failure(task_id, "v3_task_status", error)
