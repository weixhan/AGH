"""One fixed, source-bound two-image business recovery acceptance.

This coordinator owns the experiment clock and all three arms. An unfinished
call is evidence of unknown cost, never permission to predict again.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

from .audit import _atomic_text, _sha256, _timestamp
from .sliced_task_v3 import validate_inference_controls, _new_budget, _assemble

ROOT = Path(__file__).resolve().parents[1]
TOOL = "verify_sliced_business_recovery"
PURPOSE = "two-image-known-cost-step-recovery-v1"
FREEZE_PATH = ROOT / "outputs/sliced-business-implementation-v1/freeze.json"
PREPARATION_PATH = ROOT / "outputs/sliced-business-preparation-v1/input_manifest.json"
SOURCE_PATHS = (
    "defect_researcher/sliced_business_recovery.py",
    "defect_researcher/sliced_business_worker.py",
    "fixtures/sliced_business_protocol.json",
    "tools/prepare_sliced_business_protocol.py",
    "tools/verify_sliced_business_recovery.py",
    "defect_researcher/sliced_worker_v3.py",
    "defect_researcher/sliced_task_v3.py",
    "defect_researcher/sliced_journal.py",
    "defect_researcher/sliced_inference.py",
    "defect_researcher/audit.py",
    "tools/verify_sliced_journal.py",
    "tests/test_sliced_business_protocol.py",
    "tests/test_sliced_business_worker.py",
    "tests/test_sliced_business_verifier.py",
    "tests/test_sliced_business_recovery.py",
)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def _pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("Duplicate JSON key")
        value[key] = item
    return value


def decode(data):
    return json.loads(data, object_pairs_hook=_pairs,
                      parse_constant=lambda token: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def read(path):
    return decode(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    _atomic_text(Path(path), json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _helper(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / filename)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def protocol():
    return _helper("business_preparation", "prepare_sliced_business_protocol.py").read_protocol()


def source_digest(rows):
    return digest(sorted([{"path": Path(row["path"]).resolve().relative_to(ROOT).as_posix(),
                           "sha256": row["sha256"]} for row in rows], key=lambda row: row["path"]))


def validate_freeze(value):
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1 or value.get("tool") != TOOL or value.get("purpose") != PURPOSE:
        raise ValueError("Wrong implementation freeze purpose")
    rows = value.get("sources", [])
    expected = {str((ROOT / path).resolve()) for path in SOURCE_PATHS}
    actual = [str(Path(row["path"]).resolve()) for row in rows]
    if len(actual) != len(expected) or set(actual) != expected:
        raise ValueError("Execution source set changed")
    for row in rows:
        path = Path(row["path"])
        if path.stat().st_size != row["size_bytes"] or _sha256(path) != row["sha256"]:
            raise ValueError("Frozen execution source bytes changed")
    if source_digest(rows) != value.get("execution_source_sha256"):
        raise ValueError("Execution source digest changed")
    return value


def _finite(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value) and value >= 0


def _utc(value):
    if not isinstance(value, str):
        raise ValueError("Actual call UTC timestamp is missing")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Actual call UTC timestamp lacks timezone")
    return parsed.timestamp()


class SharedExperimentLedger:
    """Durable, single-writer call reservation and closed-cost accounting."""

    def __init__(self, request):
        self.request = request
        self.directory = Path(request["experiment_directory"]).resolve()
        self.coordinator = read(self.directory / "coordinator.json")
        coordinator = self.coordinator
        if (type(coordinator.get("schema_version")) is not int or coordinator["schema_version"] != 1
                or coordinator.get("tool") != TOOL or coordinator.get("purpose") != PURPOSE
                or type(coordinator.get("real_detector_used")) is not bool
                or any(not _finite(coordinator.get(key)) for key in ("start_epoch", "start_monotonic", "deadline_epoch"))
                or coordinator["deadline_epoch"] != coordinator["start_epoch"] + 300
                or any(not isinstance(coordinator.get(key), str) or re.fullmatch(r"[0-9a-f]{64}", coordinator[key]) is None
                       for key in ("protocol_sha256", "input_manifest_sha256", "execution_source_sha256", "implementation_freeze_sha256"))):
            raise ValueError("Original shared coordinator identity or deadline changed")
        self.path = self.directory / "shared_journal.jsonl"
        self.rows = []
        if self.path.exists():
            raw = self.path.read_bytes()
            if raw and not raw.endswith(b"\n"):
                raise ValueError("Unfinished shared journal tail; resume refused")
            for line in raw.splitlines():
                self.rows.append(decode(line))
        self._replay()

    def _replay(self):
        head, pending, calls, gpu = "0" * 64, None, 0, 0.
        previous_elapsed = 0.
        keys = {"schema_version", "event_seq", "event_type", "previous_event_sha256", "event_sha256", "payload"}
        for sequence, row in enumerate(self.rows, 1):
            body = {key: item for key, item in row.items() if key != "event_sha256"}
            if (set(row) != keys or type(row["event_seq"]) is not int or row["event_seq"] != sequence
                    or type(row["schema_version"]) is not int or row["schema_version"] != 1 or row["previous_event_sha256"] != head
                    or row["event_sha256"] != digest(body)):
                raise ValueError("Shared journal hash chain changed")
            payload = row["payload"]
            for key in ("experiment_id", "protocol_sha256", "input_manifest_sha256", "execution_source_sha256"):
                if payload.get(key) != self.coordinator[key]:
                    raise ValueError("Shared journal identity changed")
            if (payload.get("arm") not in ("control", "fault", "resume") or payload.get("kind") not in ("warmup", "formal")
                    or type(payload.get("local_call_index")) is not int or payload["local_call_index"] < 1
                    or type(payload.get("pass_id")) is not int or payload["pass_id"] not in range(9)
                    or payload.get("image_id") not in ("C01_B01_frame_000030", "C01_B01_frame_000066")
                    or not _finite(payload.get("elapsed_seconds")) or payload["elapsed_seconds"] < previous_elapsed
                    or not _finite(payload.get("utc_epoch")) or payload["utc_epoch"] < self.coordinator["start_epoch"]):
                raise ValueError("Invalid shared call record")
            previous_elapsed = payload["elapsed_seconds"]
            if payload["elapsed_seconds"] > 300 or payload["utc_epoch"] > self.coordinator["deadline_epoch"]:
                raise ValueError("Shared wall deadline exceeded")
            if row["event_type"] == "started":
                if payload["elapsed_seconds"] >= 300 or payload["utc_epoch"] >= self.coordinator["deadline_epoch"]:
                    raise ValueError("Call began after original shared wall deadline")
                if pending is not None or type(payload["shared_call_index"]) is not int or payload["shared_call_index"] != calls + 1:
                    raise ValueError("Shared call sequence or open call changed")
                if calls >= 40 or gpu >= 60:
                    raise ValueError("Call began after shared budget exhausted")
                pending = payload
                calls += 1
            elif row["event_type"] == "finished":
                if pending is None or any(payload.get(key) != pending[key] for key in (
                        "shared_call_index", "arm", "kind", "image_id", "pass_id", "local_call_index")):
                    raise ValueError("Shared finished call has no matching reservation")
                attempt = payload.get("attempt", {})
                if (attempt.get("status") not in ("passed", "failed") or not attempt.get("utc_finished")
                        or any(not _finite(attempt.get(key)) for key in ("gpu_seconds", "elapsed_seconds"))
                        or any(type(attempt.get(key)) is not type(pending[other]) or attempt[key] != pending[other] for key, other in (
                            ("call_index", "local_call_index"), ("image_id", "image_id"), ("pass_id", "pass_id")))):
                    raise ValueError("Shared actual call cost unknown; resume refused")
                if (attempt["elapsed_seconds"] <= 0 or attempt["gpu_seconds"] > attempt["elapsed_seconds"] + .05
                        or _utc(attempt["utc_finished"]) < _utc(attempt.get("utc_started"))):
                    raise ValueError("Shared actual timing is invalid; resume refused")
                gpu += attempt["gpu_seconds"]
                pending = None
            else:
                raise ValueError("Unexpected shared journal event")
            head = row["event_sha256"]
        self.head, self.pending, self.calls, self.gpu_seconds = head, pending, calls, gpu

    def elapsed(self):
        return max(time.monotonic() - self.coordinator["start_monotonic"],
                   time.time() - self.coordinator["start_epoch"])

    def check(self):
        if canonical(self.coordinator.get("limits")) != canonical({"max_detector_calls": 40, "max_gpu_seconds": 60, "max_wall_seconds": 300}):
            raise ValueError("Shared limits changed")
        if self.pending is not None:
            raise ValueError("Unfinished shared call; prediction refused")
        if self.calls > 40 or self.gpu_seconds > 60:
            raise RuntimeError("Shared actual cost budget exceeded")
        if self.elapsed() >= 300 or time.time() >= self.coordinator["deadline_epoch"]:
            raise RuntimeError("Original shared wall deadline exhausted")

    def _append(self, event, payload):
        body = {"schema_version": 1, "event_seq": len(self.rows) + 1, "event_type": event,
                "previous_event_sha256": self.head, "payload": payload}
        row = {**body, "event_sha256": digest(body)}
        with self.path.open("ab") as stream:
            stream.write(canonical(row) + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        self.rows.append(row)
        self._replay()

    def before_call(self, kind, image_id, pass_id, local_call_index):
        self.check()
        if self.calls >= 40 or self.gpu_seconds >= 60:
            raise RuntimeError("Shared budget exhausted before prediction")
        payload = {"shared_call_index": self.calls + 1, "arm": self.request["arm"], "kind": kind,
                   "image_id": image_id, "pass_id": pass_id, "local_call_index": local_call_index,
                   "utc_epoch": time.time(), "elapsed_seconds": self.elapsed(),
                   **{key: self.coordinator[key] for key in (
                       "experiment_id", "protocol_sha256", "input_manifest_sha256", "execution_source_sha256")}}
        self._append("started", payload)
        return payload["shared_call_index"]

    def finish_call(self, index, attempt):
        if self.pending is None or self.pending["shared_call_index"] != index:
            raise ValueError("Unknown shared reservation")
        payload = {**self.pending, "attempt": deepcopy(attempt), "utc_epoch": time.time(),
                   "elapsed_seconds": self.elapsed()}
        # Write actual evidence even when its cost/time breaks a gate.
        self._append("finished", payload)
        self.check()


def science_identity(manifest_sha, protocol_sha, arm):
    return digest({"input_manifest_sha256": manifest_sha, "protocol_sha256": protocol_sha,
                   "arm_group": "control" if arm == "control" else "fault"})


def journal_identity(request):
    from .sliced_journal import execution_identity
    return execution_identity({"protocol_sha256": request["protocol_sha256"],
        "weight_sha256": request["protocol"]["weight_sha256"],
        "scientific_inputs_sha256": request["scientific_inputs_sha256"],
        "execution_source_sha256": request["execution_source_sha256"]})


def validate_worker_request(request):
    if (type(request.get("execution_io_version")) is not int or request["execution_io_version"] != 1
            or request.get("tool") != TOOL or request.get("arm") not in ("control", "fault", "resume")):
        raise ValueError("Wrong dedicated business request")
    directory = Path(request["directory"]).resolve()
    parent = Path(request["experiment_directory"]).resolve()
    if directory.parent != parent or directory.name != request["arm"]:
        raise ValueError("Worker output arm changed")
    saved_protocol = protocol()
    if canonical(request.get("protocol")) != canonical(saved_protocol):
        raise ValueError("Fixed two-image business protocol changed")
    for filename, field in (("protocol.json", "protocol_sha256"), ("input_manifest.json", "input_manifest_sha256"),
                            ("implementation_freeze.json", "implementation_freeze_sha256")):
        if _sha256(parent / filename) != request[field]:
            raise ValueError("Saved experiment binding changed")
    if _sha256(parent / "protocol.json") != _sha256(ROOT / "fixtures/sliced_business_protocol.json"):
        raise ValueError("Frozen recipe bytes changed")
    frozen = validate_freeze(read(parent / "implementation_freeze.json"))
    if _sha256(FREEZE_PATH) != request["implementation_freeze_sha256"]:
        raise ValueError("Trusted code archive changed")
    if request["execution_source_sha256"] != frozen["execution_source_sha256"]:
        raise ValueError("Requested execution source changed")
    manifest = read(parent / "input_manifest.json")
    _helper("business_preparation", "prepare_sliced_business_protocol.py").validate_registration(manifest, fresh=True)
    if (canonical(request["records"]) != canonical(manifest["records"])
            or canonical(request["reference_environment"]) != canonical(manifest["reference_environment"])
            or request["weights_path"] != manifest["configuration"]["weights_path"]
            or request["image_sha256"] != {row["image_id"]: saved_protocol["preregistered_inputs"][row["image_id"] + "/image"] for row in manifest["records"]}
            or request["scientific_inputs_sha256"] != science_identity(request["input_manifest_sha256"], request["protocol_sha256"], request["arm"])):
        raise ValueError("Worker pixels, records or arm group changed")
    # The historical reference did not seal actual input dtype/device. Require
    # its available predictor controls here; the worker seals fresh tensors.
    from .sliced_worker_v3 import _validate_reference_options
    _validate_reference_options(request["reference_environment"])
    shared = SharedExperimentLedger(request)
    for field in ("experiment_id", "protocol_sha256", "input_manifest_sha256", "execution_source_sha256", "implementation_freeze_sha256"):
        if shared.coordinator[field] != request[field]:
            raise ValueError("Coordinator source or experiment changed")
    shared.check()
    if request["arm"] == "resume":
        _validate_fault(parent, request)
    return request


def recover_stopped_worker(directory, request, protocol):
    from .sliced_journal import load_journal, atomic_write_json
    directory = Path(directory)
    try:
        replay = load_journal(directory, protocol, journal_identity(request), check_published=False,
                              inspection_only_allow_truncated_tail=True)
        budget, index = replay.budget, replay.checkpoint_index
        budget["resumable"] = False
    except Exception as error:
        budget, index = read(directory / "budget.json"), read(directory / "checkpoint_index.json")
        budget.update(resumable=False, journal_replay_error={"type": type(error).__name__, "message": str(error)})
    budget["stopped_journal_materialized"] = True
    atomic_write_json(directory / "budget.json", budget)
    atomic_write_json(directory / "checkpoint_index.json", index)
    return budget


def _validate_fault(parent, request):
    fault = Path(parent) / "fault"
    original = read(fault / "worker_request.json")
    injection = read(fault / "fault.json")
    receipt = read(fault / "worker_receipt.json")
    if (receipt.get("status") != "failed" or receipt.get("error", {}).get("type") != "InjectedBusinessFault"
            or receipt.get("resumable") is not True or receipt.get("observations") != 2):
        raise ValueError("Only the preregistered known-cost failure may resume")
    for key in ("experiment_id", "protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256"):
        if injection.get(key) != original[key] or original[key] != request[key]:
            raise ValueError("Fault identity changed before resume")
    rule = request["protocol"]["fault"]
    if (injection.get("fault_rule_sha256") != digest(rule) or injection.get("image_id") != rule["image_id"]
            or injection.get("pass_id") != rule["pass_index"] or injection.get("boundary") != rule["boundary"]
            or injection.get("output_sha256") != digest(injection.get("prediction_output"))
            or any(not _finite(injection.get("timing", {}).get(key)) for key in ("gpu_seconds", "elapsed_seconds"))):
        raise ValueError("Fault rule, actual returned output or closed cost changed")
    return injection


def _snapshot_tree(directory):
    return [{"path": str(path.relative_to(directory)).replace("\\", "/"),
             "sha256": _sha256(path), "size_bytes": path.stat().st_size}
            for path in sorted(Path(directory).rglob("*")) if path.is_file()]


def _copy_resume(parent, request):
    from .sliced_journal import load_journal
    prior, destination = parent / "fault", parent / "resume"
    _validate_fault(parent, request)
    prior_request = read(prior / "worker_request.json")
    replay = load_journal(prior, request["protocol"], journal_identity(prior_request), check_published=True,
                          require_resumable=True, now_epoch=time.time())
    if len(replay.checkpoint_index["checkpoints"]) != 2 or len(replay.budget["formal_attempts"]) != 3:
        raise ValueError("Fault checkpoint/call prefix changed")
    destination.mkdir()
    (destination / "checkpoints").mkdir()
    for filename in ("checkpoint_journal.jsonl", "fault.json"):
        shutil.copyfile(prior / filename, destination / filename)
    for row in replay.checkpoint_index["checkpoints"]:
        shutil.copyfile(prior / row["relative_path"], destination / row["relative_path"])
    budget = deepcopy(replay.budget)
    budget["resume_chain"].append({"task_id": "fault", "failure_sha256": _sha256(prior / "failure.json"),
        "budget_sha256": _sha256(prior / "budget.json"), "checkpoint_index_sha256": _sha256(prior / "checkpoint_index.json"),
        "journal_head_sha256": replay.journal_sha256, "journal_file_sha256": _sha256(prior / "checkpoint_journal.jsonl"),
        "copied_observations": 2})
    write(destination / "budget.json", budget)
    write(destination / "checkpoint_index.json", replay.checkpoint_index)
    request["resume_environment"] = read(prior / "environment.json")


def _base_request(parent, arm, coordinator, manifest, recipe):
    return {"directory": str(parent / arm), "experiment_directory": str(parent), "arm": arm,
        "experiment_id": coordinator["experiment_id"], "tool": TOOL, "execution_io_version": 1,
        "protocol": recipe, **{key: coordinator[key] for key in (
            "protocol_sha256", "input_manifest_sha256", "implementation_freeze_sha256", "execution_source_sha256")},
        "scientific_inputs_sha256": science_identity(coordinator["input_manifest_sha256"], coordinator["protocol_sha256"], arm),
        "records": manifest["records"], "reference_environment": manifest["reference_environment"],
        "resume_environment": None, "weights_path": manifest["configuration"]["weights_path"],
        "image_sha256": {record["image_id"]: recipe["preregistered_inputs"][record["image_id"] + "/image"] for record in manifest["records"]},
        "task_monotonic_elapsed_before_worker": max(time.monotonic() - coordinator["start_monotonic"], time.time()-coordinator["start_epoch"])}


def _quarantine_completion(parent):
    """Retain rejected marker bytes without exposing a success filename."""
    parent = Path(parent).resolve()
    source, destination = parent / "completion.json", parent / "completion_rejected.json"
    if source.parent.resolve() != parent or destination.parent.resolve() != parent:
        raise ValueError("Completion quarantine escaped its experiment directory")
    if source.exists():
        source.rename(destination)


def _publish_marker(parent, marker, ledger):
    write(parent / "completion.json", marker)
    try:
        # Publication/fsync is part of the budget, not just serialization.
        ledger.check()
    except Exception:
        _quarantine_completion(parent)
        raise
    return marker


def _coordinate(parent, *, backend_factory=None):
    from .sliced_business_worker import _execute
    parent = Path(parent).resolve()
    coordinator, recipe = read(parent / "coordinator.json"), read(parent / "protocol.json")
    if (parent.parent != (ROOT / "outputs").resolve() or parent.name != coordinator.get("experiment_id")
            or re.fullmatch(r"sliced-business-v1-[a-zA-Z0-9_-]{1,64}", parent.name) is None
            or (backend_factory is None and coordinator.get("real_detector_used") is not True)
            or (backend_factory is not None and coordinator.get("real_detector_used") is not False)):
        raise ValueError("Dedicated coordinator output or real-detector identity changed")
    manifest = read(parent / "input_manifest.json")
    fault_before = None
    for arm in ("control", "fault", "resume"):
        request = _base_request(parent, arm, coordinator, manifest, recipe)
        directory = Path(request["directory"])
        if arm == "resume":
            fault_before = _snapshot_tree(parent / "fault")
            _copy_resume(parent, request)
        else:
            directory.mkdir()
            write(directory / "budget.json", _new_budget(coordinator["start_epoch"]))
            write(directory / "checkpoint_index.json", {"schema_version": 1, "checkpoints": []})
        write(directory / "worker_request.json", request)
        receipt = _execute(request, **({"backend_factory": backend_factory} if backend_factory else {}))
        index = read(directory / "checkpoint_index.json")
        observations = [read(directory / row["relative_path"])["observation"] for row in index["checkpoints"]]
        _atomic_text(directory / "pass_observations.jsonl", "".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in observations))
        if arm == "fault":
            _validate_fault(parent, _base_request(parent, "resume", coordinator, manifest, recipe))
            write(directory / "failure.json", {"schema_version": 1, "status": "failed", "error": receipt["error"],
                  "original_failure_preserved": True, "shared_clock_reset": False})
        elif receipt.get("status") != "completed":
            raise RuntimeError(f"{arm} stopped: {receipt}")
        else:
            predictions, _, fusion = _assemble(manifest["records"], observations, recipe)
            for filename, rows in (("predictions_sliced.jsonl", predictions), ("fusion_details.jsonl", fusion)):
                _atomic_text(directory / filename, "".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in rows))
        SharedExperimentLedger(request).check()
    if fault_before != _snapshot_tree(parent / "fault"):
        raise ValueError("Original failed arm changed during recovery")
    shared = SharedExperimentLedger(request)
    preservation = []
    for row in manifest["preserved_files"]:
        current = _sha256(Path(row["path"]))
        preservation.append({**row, "sha256_after": current, "unchanged": current == row["sha256"]})
    if not all(row["unchanged"] for row in preservation):
        raise ValueError("Historical evidence or frozen source changed")
    result = {"schema_version": 1, "status": "awaiting_independent_verification", "tool": TOOL, "purpose": PURPOSE,
        "experiment_id": coordinator["experiment_id"], "real_detector_used": coordinator["real_detector_used"],
        "expected_counts": recipe["expected_counts"], "detector_calls": shared.calls, "gpu_seconds": shared.gpu_seconds,
        "shared_totals": {"detector_calls": shared.calls, "formal_calls": sum(row["event_type"] == "started" and row["payload"]["kind"] == "formal" for row in shared.rows),
                          "warmup_calls": sum(row["event_type"] == "started" and row["payload"]["kind"] == "warmup" for row in shared.rows), "gpu_seconds": shared.gpu_seconds},
        "elapsed_seconds_at_review": shared.elapsed(), "fault_tree_before_resume": fault_before,
        "fault_tree_after_resume": _snapshot_tree(parent / "fault"), "preservation_after": preservation,
        "all_640_recovery_verified": False, "scientific_performance_claim": False, "model_requests": 0}
    write(parent / "business_result.json", result)
    _atomic_text(parent / "business_report.md", f"# 两图已知成本业务恢复验收\n\n实验 {coordinator['experiment_id']}。固定正常图与缺陷图各一张，故障在第三次正式调用返回后注入。\n\n"
        f"实际外层调用 {shared.calls}，累计 GPU {shared.gpu_seconds:.6f} 秒。独立验证通过后才发布完成标记。\n\n"
        "范围限于一次已知成本故障、两个有效检查点与缺失步骤续跑；不代表全量恢复、强制终止恢复或检测性能提升。\n")
    checker = _helper("independent_business_verifier", "verify_sliced_business_recovery.py")
    review = checker.review(parent, prepublication=True)
    write(parent / "independent_verification.json", review)
    if review.get("status") != "passed":
        raise ValueError(f"Independent business verification failed: {review}")
    shared.check()
    result.update(status="passed", elapsed_seconds=shared.elapsed(), independent_verification_sha256=_sha256(parent / "independent_verification.json"))
    # Keep the exact reviewed result immutable; final elapsed belongs in the final marker.
    candidate = {"schema_version": 1, "status": "passed", "experiment_id": coordinator["experiment_id"],
        "tool": TOOL, "purpose": PURPOSE, "detector_calls": shared.calls, "gpu_seconds": shared.gpu_seconds,
        "elapsed_seconds": shared.elapsed(), "business_result_sha256": _sha256(parent / "business_result.json"),
        "independent_verification_sha256": _sha256(parent / "independent_verification.json"),
        "real_detector_used": coordinator["real_detector_used"]}
    write(parent / "completion_candidate.json", candidate)
    artifacts = [row for row in _snapshot_tree(parent) if row["path"] != "coordinator.log"]
    write(parent / "artifact_manifest.json", {"schema_version": 1, "experiment_id": coordinator["experiment_id"], "files": artifacts})
    shared.check()
    marker = {**candidate, "utc_completed": _timestamp(), "completed_epoch": time.time(), "elapsed_seconds": shared.elapsed(),
              "artifact_manifest_sha256": _sha256(parent / "artifact_manifest.json"),
              "completion_candidate_sha256": _sha256(parent / "completion_candidate.json")}
    return _publish_marker(parent, marker, shared)


def run_experiment(input_manifest_path=None, *, experiment_id=None):
    """Run exactly once under one absolute parent subprocess deadline."""
    start_epoch, start_monotonic = time.time(), time.monotonic()
    experiment_id = experiment_id or "sliced-business-v1-" + uuid.uuid4().hex
    if re.fullmatch(r"sliced-business-v1-[a-zA-Z0-9_-]{1,64}", experiment_id) is None:
        raise ValueError("Invalid experiment identifier")
    parent = ROOT / "outputs" / experiment_id
    parent.mkdir()
    try:
        recipe = protocol()
        frozen = validate_freeze(read(FREEZE_PATH))
        source = Path(input_manifest_path or PREPARATION_PATH)
        manifest = read(source)
        _helper("business_preparation", "prepare_sliced_business_protocol.py").validate_registration(manifest, fresh=True)
        shutil.copyfile(ROOT / "fixtures/sliced_business_protocol.json", parent / "protocol.json")
        shutil.copyfile(source, parent / "input_manifest.json")
        shutil.copyfile(FREEZE_PATH, parent / "implementation_freeze.json")
        coordinator = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE, "experiment_id": experiment_id,
            "start_epoch": start_epoch, "start_monotonic": start_monotonic, "deadline_epoch": start_epoch + 300,
            "limits": recipe["shared_budgets"], "protocol_sha256": _sha256(parent / "protocol.json"),
            "input_manifest_sha256": _sha256(parent / "input_manifest.json"),
            "implementation_freeze_sha256": _sha256(parent / "implementation_freeze.json"),
            "execution_source_sha256": frozen["execution_source_sha256"], "real_detector_used": True}
        write(parent / "coordinator.json", coordinator)
        remaining = 300 - max(time.monotonic() - start_monotonic, time.time()-start_epoch)
        if remaining <= 0:
            raise RuntimeError("Shared deadline exhausted in preparation")
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
        with (parent / "coordinator.log").open("wb") as stream:
            process = subprocess.Popen([sys.executable, "-B", "-m", "defect_researcher.sliced_business_recovery",
                                        "--coordinate", str(parent)], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, env=environment)
            try:
                code = process.wait(timeout=remaining)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=10)
                raise RuntimeError("Hard shared deadline terminated coordinator; open costs cannot resume")
        if code != 0 or not (parent / "completion.json").is_file():
            raise RuntimeError("Experiment failed; read coordinator.log and failure.json")
        if max(time.monotonic()-start_monotonic, time.time()-start_epoch) >= 300:
            raise RuntimeError("Parent observed completion after original shared deadline")
        return read(parent / "completion.json")
    except Exception as error:
        _quarantine_completion(parent)
        write(parent / "failure.json", {"schema_version": 1, "status": "failed", "experiment_id": experiment_id,
                "tool": TOOL, "purpose": PURPOSE, "error": {"type": type(error).__name__, "message": str(error)},
                "elapsed_seconds": max(time.monotonic()-start_monotonic, time.time()-start_epoch),
                "original_deadline_reset": False, "automatic_retry_performed": False})
        raise


def main():
    if len(sys.argv) == 3 and sys.argv[1] == "--coordinate":
        _coordinate(Path(sys.argv[2]))
        return 0
    marker = run_experiment()
    print(json.dumps(marker, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
