"""Separate GT-based recall strata from prediction-based precision strata."""
from __future__ import annotations

from collections import Counter
import math

SIZES = ("small", "medium", "large")
REGIONS = tuple(f"{row}_{column}" for row in ("top", "middle", "bottom") for column in ("left", "center", "right"))


def _keys(box, width, height):
    if len(box) != 4 or not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in box):
        raise ValueError("Coordinates must be finite numbers")
    x1, y1, x2, y2 = box
    if x2 <= x1 or y2 <= y1:
        raise ValueError("Box area must be positive")
    area = (x2 - x1) * (y2 - y1)
    size = "small" if area < 1024 else "medium" if area < 9216 else "large"
    x = min(2, max(0, int((x1 + x2) / (2 * width) * 3)))
    y = min(2, max(0, int((y1 + y2) / (2 * height) * 3)))
    return {"size_bucket": size, "region": REGIONS[y * 3 + x]}


def stratified_statistics(records, gt_details, fp_details, confidence=.25):
    images = {row["image_id"]: row for row in records}
    if len(images) != len(records):
        raise ValueError("Duplicate image identity")
    gt_counts = {field: Counter() for field in ("size_bucket", "region")}
    gt_tp = {field: Counter() for field in gt_counts}
    pred_tp = {field: Counter() for field in gt_counts}
    pred_fp = {field: Counter() for field in gt_counts}
    expected_gt = {(r["image_id"], i) for r in records for i in range(len(r["ground_truth"]))}
    expected_active = {(r["image_id"], i) for r in records for i, p in enumerate(r["predictions"]) if p["confidence"] >= confidence}
    seen_gt, used, seen_fp = set(), set(), set()
    for row in gt_details:
        identity = (row["image_id"], row["gt_index"])
        if identity not in expected_gt or identity in seen_gt:
            raise ValueError("GT rows do not form a unique source population")
        seen_gt.add(identity)
        record = images[row["image_id"]]
        truth = record["ground_truth"][row["gt_index"]]
        if row["xyxy"] != truth["xyxy"] or row["class_id"] != truth["class_id"]:
            raise ValueError("GT row differs from its source")
        keys = _keys(truth["xyxy"], record["width"], record["height"])
        for field, value in keys.items():
            gt_counts[field][value] += 1
        if row["status"] == "tp":
            predicted = (row["image_id"], row["matched_prediction_index"])
            if predicted not in expected_active or predicted in used:
                raise ValueError("A TP prediction must be active and consumed once")
            used.add(predicted)
            prediction = record["predictions"][row["matched_prediction_index"]]
            if prediction["class_id"] != truth["class_id"]:
                raise ValueError("A TP must have the GT class")
            for field, value in keys.items():
                gt_tp[field][value] += 1
            for field, value in _keys(prediction["xyxy"], record["width"], record["height"]).items():
                pred_tp[field][value] += 1
        elif row["status"] != "fn" or row["matched_prediction_index"] is not None:
            raise ValueError("Unknown or inconsistent GT status")
    if seen_gt != expected_gt:
        raise ValueError("Missing GT details")
    for row in fp_details:
        identity = (row["image_id"], row["prediction_index"])
        if identity not in expected_active or identity in used or identity in seen_fp:
            raise ValueError("FP population overlaps TPs or is duplicated/inactive")
        seen_fp.add(identity)
        record = images[row["image_id"]]
        prediction = record["predictions"][row["prediction_index"]]
        if row["xyxy"] != prediction["xyxy"] or row["class_id"] != prediction["class_id"]:
            raise ValueError("FP row differs from its source")
        for field, value in _keys(prediction["xyxy"], record["width"], record["height"]).items():
            pred_fp[field][value] += 1
    if used | seen_fp != expected_active:
        raise ValueError("Active predictions do not partition into TP and FP")
    result = {"schema_version": "separate-gt-and-prediction-strata-v1",
              "protocol": {"confidence_threshold": confidence,
                           "recall_grouping": "ground_truth_box_size_or_center",
                           "precision_grouping": "prediction_box_size_or_center",
                           "matching": "reuse_hash_bound_verified_one_to_one_matches"}}
    for field, values in (("size_bucket", SIZES), ("region", REGIONS)):
        result[field] = [{field: value, "gt": gt_counts[field][value], "tp_gt": gt_tp[field][value],
                          "fn_gt": gt_counts[field][value] - gt_tp[field][value],
                          "recall_gt": gt_tp[field][value] / gt_counts[field][value] if gt_counts[field][value] else None,
                          "tp_predictions": pred_tp[field][value], "fp_predictions": pred_fp[field][value],
                          "precision_predictions": pred_tp[field][value] / (pred_tp[field][value] + pred_fp[field][value])
                          if pred_tp[field][value] + pred_fp[field][value] else None} for value in values]
    return result
