"""Independently verify configured COCO-to-HBB/YOLO geometry without changing inputs."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import uuid
from typing import Any

from .audit import _atomic_text, _artifact_record, _configured_paths, _sha256, _timestamp

SPLITS = ("train", "val", "test")
CATEGORIES = {1: "broken_strand", 2: "welded_strand", 3: "bent_strand",
              4: "long_scratch", 5: "crushed", 6: "spaced_strand", 7: "deposit"}
YOLO_TOLERANCE = 5.1e-9  # Existing labels are serialized to eight decimal places.
PIXEL_TOLERANCE = 1e-8
FILES = {"verification_result": "verification_result.json", "geometry_details": "geometry_details.jsonl",
         "fixture_results": "fixture_results.json", "input_manifest": "input_manifest.json",
         "events": "events.jsonl", "artifact_manifest": "artifact_manifest.json", "completion": "completion.json"}
LIMITATIONS = [
    "The independent analytic oracle verifies the documented hbb_v1 conversion semantics; "
    "it does not establish that human annotations describe the true defect boundaries.",
    "This checks train/val/test label geometry and provenance, not predictions, model accuracy or test-set tuning.",
    "Image membership and COCO dimensions are checked; image pixels and checkpoint weights are not read or hashed.",
]


def _dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _write(path: Path, value: Any) -> None:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _event(directory: Path, stage: str, status: str, **fields: Any) -> None:
    with (directory / FILES["events"]).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_dump({"at": _timestamp(), "stage": stage, "status": status, **fields}) + "\n")
        stream.flush()


def _json(path: Path) -> dict:
    def invalid_constant(value: str) -> None:
        raise ValueError(f"Non-finite JSON number in {path}: {value}")

    def unique_object(pairs: list) -> dict:
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON field in {path}: {key}")
            result[key] = value
        return result

    value = json.loads(path.read_text(encoding="utf-8-sig"), parse_constant=invalid_constant,
                       object_pairs_hook=unique_object)
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    # The parser accepts numeric overflow such as 1e400, even with parse_constant.
    _dump(value)
    return value


def _safe(path: Path, root: Path, *, file: bool = True) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError(f"Input path escapes configured root: {path}")
    for parent in (path, *path.parents):
        if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
            raise ValueError(f"Linked input path is not accepted: {path}")
        if parent == root:
            break
    if file and not path.is_file():
        raise FileNotFoundError(f"Missing geometry input: {path}")
    if not file and not path.is_dir():
        raise FileNotFoundError(f"Missing geometry input directory: {path}")
    return resolved


def _sources(paths: dict[str, Path], oracle: Any) -> dict[str, Path]:
    sources = {"verifier": Path(__file__).resolve(), "oracle": Path(oracle.__file__).resolve(),
               "fixtures": Path(oracle.FIXTURE_PATH).resolve()}
    package_root = Path(__file__).resolve().parents[1]
    for name, path in sources.items():
        _safe(path, package_root)
    for name in ("manifest.json", "data.yaml"):
        sources[f"dataset/{name}"] = _safe(paths["dataset_root"] / name, paths["dataset_root"])
    for cable in ("cable_1", "cable_2", "cable_3"):
        sources[f"raw/{cable}.json"] = _safe(paths["raw_root"] / f"{cable}.json", paths["raw_root"])
    for split in SPLITS:
        sources[f"splits/{split}.txt"] = _safe(paths["split_dir"] / f"{split}.txt", paths["split_dir"])
        for kind in ("labels", "metadata"):
            directory = _safe(paths["dataset_root"] / kind / split, paths["dataset_root"], file=False)
            for path in sorted(directory.iterdir()):
                # Nested directories and linked entries are refused rather than silently omitted.
                sources[f"{kind}/{split}/{path.name}"] = _safe(path, paths["dataset_root"])
    excluded = paths["split_dir"] / "excluded_buffer.txt"
    if excluded.exists():
        sources["splits/excluded_buffer.txt"] = _safe(excluded, paths["split_dir"])
    return sources


def _relative(value: Any) -> str:
    if not isinstance(value, str):
        raise ValueError("COCO file_name must be a string")
    value = value.replace("\\", "/").replace("Cable_", "cable_")
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or ".." in path.parts or ":" in value:
        raise ValueError(f"Unsafe COCO image path: {value}")
    return path.as_posix()


def _identifier(value: Any, label: str) -> Any:
    if isinstance(value, bool) or not isinstance(value, (int, str)) or str(value) == "":
        raise ValueError(f"Invalid {label}: {value!r}")
    return value


def _database(paths: dict[str, Path]) -> dict:
    records = {}
    for cable in ("cable_1", "cable_2", "cable_3"):
        name = f"{cable}.json"
        data = _json(paths["raw_root"] / name)
        categories = {}
        for category in data["categories"]:
            identifier = _identifier(category["id"], "category ID")
            if identifier in categories:
                raise ValueError(f"Duplicate category ID in {name}: {identifier}")
            categories[identifier] = category["name"].replace(" ", "_")
        if categories != CATEGORIES:
            raise ValueError(f"COCO class mapping differs from the fixed seven classes: {name}")
        images, annotation_ids = {}, set()
        for image in data["images"]:
            identifier = _identifier(image["id"], "image ID")
            relative = _relative(image["file_name"])
            if identifier in images or relative in records:
                raise ValueError(f"Duplicate COCO image ID/path in {name}: {identifier}, {relative}")
            _safe(paths["raw_root"] / relative, paths["raw_root"])
            for dimension in ("width", "height"):
                if isinstance(image[dimension], bool) or not isinstance(image[dimension], int) or image[dimension] <= 0:
                    raise ValueError(f"Invalid COCO dimensions: {name}, image={identifier}")
            images[identifier] = relative
            records[relative] = {"image": image, "annotations": [], "source_json": name}
        for annotation in data["annotations"]:
            identifier = _identifier(annotation["id"], "annotation ID")
            if identifier in annotation_ids:
                raise ValueError(f"Duplicate COCO annotation ID in {name}: {identifier}")
            annotation_ids.add(identifier)
            image_id = _identifier(annotation["image_id"], "annotation image ID")
            category_id = _identifier(annotation["category_id"], "annotation category ID")
            if image_id not in images or category_id not in CATEGORIES:
                raise ValueError(f"Unknown annotation image/category in {name}: {identifier}")
            records[images[image_id]]["annotations"].append(annotation)
    return records


def _split_paths(paths: dict[str, Path], records: dict) -> dict[str, list[str]]:
    result, seen, stems = {}, set(), set()
    for split in (*SPLITS, "excluded_buffer"):
        path = paths["split_dir"] / f"{split}.txt"
        result[split] = []
        if split == "excluded_buffer" and not path.exists():
            continue
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            if not line.strip():
                continue
            source = Path(line.strip())
            if not source.is_absolute():
                raise ValueError(f"Split entry must be absolute: {split}: {line}")
            relative = _safe(source, paths["raw_root"]).relative_to(paths["raw_root"]).as_posix()
            stem = source.stem.casefold()
            if relative not in records or relative in seen or stem in stems:
                raise ValueError(f"Unknown/duplicate split image or flattened name: {split}: {relative}")
            seen.add(relative)
            stems.add(stem)
            result[split].append(relative)
    if seen != set(records):
        raise ValueError("Splits plus excluded buffer do not cover all COCO images")
    if any(records[path]["annotations"] for path in result["excluded_buffer"]):
        raise ValueError("Excluded buffer contains annotated images")
    return result


def _numeric(actual: Any, expected: Any, tolerance: float) -> tuple[bool, float | None]:
    if isinstance(expected, (list, tuple)):
        if not isinstance(actual, (list, tuple)) or len(actual) != len(expected):
            return False, None
        comparisons = [_numeric(a, e, tolerance) for a, e in zip(actual, expected)]
        errors = [error for _, error in comparisons if error is not None]
        return all(ok for ok, _ in comparisons), max(errors, default=0.0)
    if isinstance(actual, bool) or not isinstance(actual, (int, float)) or not math.isfinite(actual):
        return False, None
    error = abs(actual - expected)
    if not math.isfinite(error):
        return False, None
    return error <= tolerance, error


class _Findings:
    def __init__(self) -> None:
        self.counts: Counter = Counter()
        self.samples: list[dict] = []
        self.max_errors = {"yolo": 0.0, "hbb_pixels": 0.0, "corners_pixels": 0.0}

    def add(self, code: str, identity: dict, **fields: Any) -> dict:
        issue = {"code": code, **identity, **fields}
        self.counts[code] += 1
        if len(self.samples) < 10:
            # Samples stay small even for membership or corrupt-metadata findings.
            self.samples.append(issue)
        return issue


def _class_mapping(path: Path) -> dict[int, str]:
    names, in_names = {}, False
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        if line.strip() == "names:":
            in_names = True
            continue
        if in_names and line.strip():
            match = re.fullmatch(r"\s+(\d+):\s*([A-Za-z0-9_]+)\s*", line)
            if not match or int(match[1]) in names:
                raise ValueError("data.yaml names must contain unique integer-to-name rows")
            names[int(match[1])] = match[2]
    return names


def _verify(paths: dict[str, Path], manifest: dict, oracle: Any, stream: Any, findings: _Findings) -> dict:
    records = _database(paths)
    split_paths = _split_paths(paths, records)
    totals, split_counts = Counter(), {}
    if manifest.get("geometry_version") != "hbb_v1":
        findings.add("geometry_version", {}, expected="hbb_v1", observed=manifest.get("geometry_version"))
    if manifest.get("categories") != {str(k): v for k, v in CATEGORIES.items()}:
        findings.add("manifest_class_mapping", {})
    if _class_mapping(paths["dataset_root"] / "data.yaml") != {k - 1: v for k, v in CATEGORIES.items()}:
        findings.add("yaml_class_mapping", {})
    for split in SPLITS:
        counts = Counter()
        expected_names = {Path(relative).stem for relative in split_paths[split]}
        for kind, suffix in (("labels", ".txt"), ("metadata", ".json"), ("images", ".png")):
            directory = _safe(paths["dataset_root"] / kind / split, paths["dataset_root"], file=False)
            entries = list(directory.iterdir())
            for entry in entries:
                _safe(entry, paths["dataset_root"])
            actual = {entry.name for entry in entries}
            expected = {name + suffix for name in expected_names}
            if actual != expected:
                findings.add("membership", {"split": split, "kind": kind},
                             missing=sorted(expected - actual)[:5], extra=sorted(actual - expected)[:5],
                             missing_count=len(expected - actual), extra_count=len(actual - expected))
        tree_hash = hashlib.sha256()
        for path in sorted((paths["dataset_root"] / "labels" / split).glob("*.txt")):
            tree_hash.update(path.relative_to(paths["dataset_root"]).as_posix().encode("utf-8") + b"\0")
            tree_hash.update(path.read_bytes() + b"\0")
        if tree_hash.hexdigest() != manifest.get("label_tree_sha256", {}).get(split):
            findings.add("declared_label_tree_hash", {"split": split})
        for relative in split_paths[split]:
            record = records[relative]
            image = record["image"]
            identity = {"split": split, "image": relative, "image_id": image["id"], "source_json": record["source_json"]}
            stem = Path(relative).stem
            label_path = _safe(paths["dataset_root"] / "labels" / split / f"{stem}.txt", paths["dataset_root"])
            meta_path = _safe(paths["dataset_root"] / "metadata" / split / f"{stem}.json", paths["dataset_root"])
            labels = [line.split() for line in label_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
            metadata = _json(meta_path)
            items = metadata.get("annotations")
            if not isinstance(items, list) or any(not isinstance(item, dict) for item in items):
                raise ValueError(f"Metadata annotations must be an object array: {meta_path}")
            ids = [item.get("annotation_id") for item in items]
            if len(set(map(str, ids))) != len(ids):
                raise ValueError(f"Duplicate metadata annotation ID: {meta_path}")
            image_issues = []
            for field, expected in {"image": relative, "source_json": record["source_json"], "image_id": image["id"],
                                    "width": image["width"], "height": image["height"], "geometry_version": "hbb_v1"}.items():
                if metadata.get(field) != expected or type(metadata.get(field)) is not type(expected):
                    image_issues.append(findings.add("metadata_image", identity, field=field))
            valid_index = 0
            for annotation in record["annotations"]:
                counts["source_annotations"] += 1
                aid = {**identity, "annotation_id": annotation["id"]}
                attributes = annotation.get("attributes") or {}
                try:
                    raw_rotation = attributes.get("rotation", 0)
                    if isinstance(raw_rotation, bool):
                        raise ValueError("rotation must not be a boolean")
                    rotation = float(raw_rotation)
                    expected = oracle.oracle_geometry(annotation["bbox"], rotation, image["width"], image["height"])
                    _dump(expected)
                except (TypeError, ValueError, OverflowError) as error:
                    raise ValueError(f"Invalid source geometry: source_json={record['source_json']}, "
                                     f"image={relative}, annotation_id={annotation['id']}: {error}") from error
                counts["nonzero_rotation_attributes"] += int(rotation != 0)
                counts["rotated_annotations"] += int(rotation % 360 != 0)
                issues, errors = [], {}
                if expected["hbb"] is None:
                    counts["invalid_annotations"] += 1
                    stream.write(_dump({"record_type": "annotation", **aid, "status": "invalid_source_box",
                                        "source_bbox": annotation["bbox"], "rotation": rotation, "expected": expected,
                                        "differences": []}) + "\n")
                    continue
                counts["annotations"] += 1
                counts["clipped_annotations"] += int(expected["clipped"])
                label = labels[valid_index] if valid_index < len(labels) else None
                item = items[valid_index] if valid_index < len(items) else {}
                if label is None or len(label) != 5:
                    issues.append(findings.add("label_shape", aid, row=valid_index + 1))
                else:
                    try:
                        category = int(label[0])
                        values = [float(value) for value in label[1:]]
                    except ValueError:
                        category, values = None, []
                    if category != annotation["category_id"] - 1:
                        issues.append(findings.add("label_class", aid, observed=label[0], expected=annotation["category_id"] - 1))
                    finite = len(values) == 4 and all(math.isfinite(v) and 0 <= v <= 1 for v in values)
                    ok, error = _numeric(values, expected["yolo"], YOLO_TOLERANCE) if finite else (False, None)
                    if error is not None:
                        errors["yolo"] = error
                        findings.max_errors["yolo"] = max(findings.max_errors["yolo"], error)
                    if not ok:
                        issues.append(findings.add("yolo_geometry" if finite else "label_nonfinite_or_range", aid, max_error=error))
                for field, target, tolerance, metric in (
                    ("original_bbox", annotation["bbox"], 0.0, None), ("rotation", rotation, 0.0, None),
                    ("hbb_xyxy", expected["hbb"], PIXEL_TOLERANCE, "hbb_pixels"),
                    ("rotated_corners", expected["corners"], PIXEL_TOLERANCE, "corners_pixels"),
                ):
                    ok, error = _numeric(item.get(field), target, tolerance)
                    if metric and error is not None:
                        errors[metric] = error
                        findings.max_errors[metric] = max(findings.max_errors[metric], error)
                    if not ok:
                        issues.append(findings.add("metadata_geometry", aid, field=field, max_error=error))
                for field, target in {"annotation_id": annotation["id"], "image_id": image["id"],
                                      "source_json": record["source_json"], "category_id": annotation["category_id"],
                                      "class": CATEGORIES[annotation["category_id"]], "bbox_clipped": expected["clipped"],
                                      "geometry_version": "hbb_v1", "gradation": attributes.get("gradation"),
                                      "anomaly_id": attributes.get("anomaly_id")}.items():
                    identity_field = field in ("annotation_id", "image_id", "category_id", "bbox_clipped")
                    if (field not in item or item[field] != target
                            or (identity_field and type(item[field]) is not type(target))):
                        issues.append(findings.add("metadata_provenance", aid, field=field))
                stream.write(_dump({"record_type": "annotation", **aid, "status": "failed" if issues else "passed",
                                    "source_bbox": annotation["bbox"], "rotation": rotation, "category_id": annotation["category_id"],
                                    "label_row": valid_index + 1, "observed_label": label, "expected": expected,
                                    "observed_metadata": {field: item.get(field) for field in (
                                        "annotation_id", "image_id", "category_id", "class", "source_json", "original_bbox",
                                        "rotation", "hbb_xyxy", "rotated_corners", "bbox_clipped", "geometry_version")},
                                    "max_errors": errors, "differences": issues}) + "\n")
                valid_index += 1
            if len(labels) != valid_index or len(items) != valid_index:
                image_issues.append(findings.add("annotation_count", identity, expected=valid_index,
                                                label_rows=len(labels), metadata_rows=len(items)))
            stream.write(_dump({"record_type": "image", **identity, "source_annotations": len(record["annotations"]),
                                "expected_label_rows": valid_index, "label_rows": len(labels), "metadata_rows": len(items),
                                "differences": image_issues}) + "\n")
            counts["images"] += 1
            counts["abnormal_images" if valid_index else "normal_images"] += 1
        keys = ("images", "normal_images", "abnormal_images", "annotations", "source_annotations",
                "nonzero_rotation_attributes", "rotated_annotations", "clipped_annotations", "invalid_annotations")
        split_counts[split] = {key: counts[key] for key in keys}
        totals.update(counts)
        if split_counts[split] != manifest.get("counts", {}).get(split):
            findings.add("manifest_split_counts", {"split": split}, observed=split_counts[split])
    summary = {"counts": split_counts, "totals": {key: totals[key] for key in keys},
               "raw_images": len(records), "raw_annotations": sum(len(r["annotations"]) for r in records.values()),
               "excluded_buffer_images": len(split_paths["excluded_buffer"])}
    for key in ("totals", "raw_images", "raw_annotations", "excluded_buffer_images"):
        if summary[key] != manifest.get(key):
            findings.add("manifest_global_counts", {}, field=key)
    return summary


def verify_label_geometry(configuration: dict, task_id: str | None = None) -> dict:
    """Publish a completed verification (passed or failed), or a distinct execution failure."""
    task_id = task_id if task_id is not None else f"geometry-{uuid.uuid4().hex}"
    result = {"task_id": task_id, "tool": "verify_label_geometry", "status": "running",
              "started_at": _timestamp(), "finished_at": None, "configuration": {}, "summary": {},
              "artifacts": {}, "evidence": {}, "errors": [], "limitations": list(LIMITATIONS)}
    task_dir, stage, temporary = None, "configuration", None
    try:
        if not isinstance(configuration, dict):
            raise TypeError("configuration must be a dictionary")
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name of at most 128 characters")
        paths = _configured_paths(configuration)
        result["configuration"] = {key: str(value) for key, value in paths.items()}
        paths["output_root"].mkdir(parents=True, exist_ok=True)
        destination = paths["output_root"] / task_id
        destination.mkdir(exist_ok=False)
        task_dir = destination
        _event(task_dir, stage, "passed")
        from . import independent_geometry as oracle
        stage = "input_provenance"
        sources = _sources(paths, oracle)
        before = {name: {**_artifact_record(path), "role": name} for name, path in sources.items()}
        manifest = _json(paths["dataset_root"] / "manifest.json")
        findings = _Findings()
        for group, prefix in (("source_sha256", "raw"), ("split_sha256", "splits")):
            expected_hashes = manifest.get(group)
            if not isinstance(expected_hashes, dict):
                raise ValueError(f"Dataset manifest requires {group}")
            required = {name.split("/", 1)[1] for name in sources if name.startswith(prefix + "/")}
            listed = set(expected_hashes)
            if listed != required:
                findings.add("declared_hash_membership", {}, group=group,
                             missing=sorted(required - listed), extra=sorted(listed - required))
            for name, digest in expected_hashes.items():
                role = f"{prefix}/{name}"
                if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
                    findings.add("declared_hash_format", {}, input=role)
                if role not in before or before[role]["sha256"] != digest:
                    findings.add("declared_input_hash", {}, input=role)
        _event(task_dir, stage, "passed", input_files=len(sources))
        stage = "oracle_fixtures"
        fixtures = oracle.run_fixture_suite()
        if fixtures.get("status") != "passed":
            findings.add("oracle_fixtures", {}, fixture_status=fixtures.get("status"))
        _write(task_dir / FILES["fixture_results"], fixtures)
        _event(task_dir, stage, fixtures.get("status", "failed"))
        stage = "label_geometry"
        temporary = task_dir / f".geometry_details.{uuid.uuid4().hex}.tmp"
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            summary = _verify(paths, manifest, oracle, stream, findings)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, task_dir / FILES["geometry_details"])
        temporary = None
        stage = "input_immutability"
        current = _sources(paths, oracle)
        if current != sources:
            raise ValueError("Input file membership changed while geometry verification was running")
        checked = []
        for name, path in sources.items():
            after = _artifact_record(path)
            checked.append({"role": name, "path": str(path), "size_bytes": before[name]["size_bytes"],
                            "sha256_before": before[name]["sha256"], "sha256_after": after["sha256"],
                            "unchanged": after == {key: value for key, value in before[name].items() if key != "role"}})
        _write(task_dir / FILES["input_manifest"], {"task_id": task_id, "tool": result["tool"],
                                                   "files": checked, "all_unchanged": all(r["unchanged"] for r in checked)})
        if not all(row["unchanged"] for row in checked):
            raise ValueError("Input hash/size changed while geometry verification was running")
        result["evidence"] = {name: {"path": str(path), "sha256": before[name]["sha256"]}
                              for name, path in sources.items() if not name.startswith(("labels/", "metadata/"))}
        result["summary"] = {**summary, "verification_status": "failed" if findings.counts else "passed",
                             "independent_geometry_verification": True, "inference_performed": False,
                             "geometry_version": "hbb_v1", "input_files_hashed": len(sources),
                             "inputs_unchanged": True, "fixture_status": fixtures.get("status"),
                             "fixture_counts": fixtures.get("counts", {}),
                             "issue_count": sum(findings.counts.values()), "issues_by_code": dict(findings.counts),
                             "issue_samples": findings.samples, "max_errors": findings.max_errors,
                             "tolerances": {"yolo": YOLO_TOLERANCE, "pixels": PIXEL_TOLERANCE}}
        _event(task_dir, stage, "passed", input_files=len(sources))
        stage = "artifact_publication"
        result["artifacts"] = {name: str(task_dir / filename) for name, filename in FILES.items()}
        result["status"], result["finished_at"] = "completed", _timestamp()
        _event(task_dir, stage, "ready", verification_status=result["summary"]["verification_status"], completion_published_last=True)
        _write(task_dir / FILES["verification_result"], result)
        artifacts = [_artifact_record(task_dir / filename) for name, filename in FILES.items()
                     if name not in ("artifact_manifest", "completion")]
        artifact_manifest = task_dir / FILES["artifact_manifest"]
        _write(artifact_manifest, {"task_id": task_id, "tool": result["tool"], "status": "completed",
                                  "created_at": _timestamp(), "files": artifacts, "input_evidence": result["evidence"]})
        for record in artifacts:
            if _artifact_record(Path(record["path"])) != record:
                raise ValueError(f"Artifact hash verification failed: {record['name']}")
        _write(task_dir / FILES["completion"], {"task_id": task_id, "tool": result["tool"], "status": "completed",
                                                "finished_at": result["finished_at"], "artifact_manifest": str(artifact_manifest),
                                                "artifact_manifest_sha256": _sha256(artifact_manifest),
                                                "artifacts_sha256": {r["name"]: r["sha256"] for r in artifacts}})
        return result
    except Exception as exc:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"].append({"stage": stage, "type": type(exc).__name__, "message": str(exc)})
        if temporary is not None:
            temporary.unlink(missing_ok=True)
        if task_dir is not None:
            try:
                (task_dir / FILES["completion"]).unlink(missing_ok=True)
                _event(task_dir, stage, "failed", error_type=type(exc).__name__, message=str(exc))
                result["artifacts"] = {p.stem: str(p) for p in task_dir.iterdir() if p.is_file()}
                result["artifacts"]["failure"] = str(task_dir / "failure.json")
                _write(task_dir / "failure.json", result)
            except Exception as error:
                result["errors"].append({"stage": "failure_publication", "type": type(error).__name__, "message": str(error)})
        return result
