"""Read-only candidate diagnostics for saved, post-NMS validation predictions.

The matching and IoU calculations here are handwritten independently of the
metric scorer. Categories describe candidate evidence, not causes of errors.
Nothing in this module runs inference, changes a threshold, or reads a file.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import math


DEFAULT_THRESHOLD_GRID = (.05, .10, .15, .20, .25, .30, .40, .50)
FN_CATEGORIES = ("matching_conflict", "localized_low_confidence", "wrong_class_candidate",
                 "localization_candidate", "no_overlap_candidate")
FP_CATEGORIES = ("duplicates", "wrong_class", "localization", "background")
SIZE_BUCKETS = ("small", "medium", "large")
REGIONS = tuple(f"{vertical}_{horizontal}"
                for vertical in ("top", "middle", "bottom")
                for horizontal in ("left", "center", "right"))
LIMITATIONS = [
    "Categories describe overlap/confidence candidates, not causal explanations.",
    "Only saved predictions above the frozen inference confidence floor are observable.",
    "Saved predictions are post-NMS and max_det filtered; suppressed or discarded candidates are unavailable.",
    "Original-pixel size bins are descriptive and do not establish a scale effect.",
    "Threshold selection uses this validation set and fixed practical gates, not statistical significance.",
    "A selected threshold is a research recommendation only; no threshold is applied and no new inference is performed.",
]


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number")
    return float(value)


def _integer(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")
    return value


def _class_names(class_names):
    if isinstance(class_names, (list, tuple)):
        names = dict(enumerate(class_names))
    elif isinstance(class_names, dict):
        names = {}
        for key, value in class_names.items():
            if isinstance(key, bool) or not (isinstance(key, int) or isinstance(key, str) and key.isdecimal()):
                raise ValueError("class_names keys must be nonnegative integer IDs")
            identifier = int(key)
            if identifier in names:
                raise ValueError("class_names contains duplicate numeric IDs")
            names[identifier] = value
    else:
        raise ValueError("class_names must be a list or class-ID dictionary")
    if not names or any(key < 0 or not isinstance(value, str) or not value for key, value in names.items()):
        raise ValueError("class_names must contain nonempty names and nonnegative IDs")
    return dict(sorted(names.items()))


def _normalize(records, names, prediction_floor):
    if not isinstance(records, list):
        raise ValueError("records must be a list")
    result, seen = [], set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("each image record must be a dictionary")
        identifier = record.get("image_id")
        if not isinstance(identifier, str) or not identifier or identifier in seen:
            raise ValueError("image_id must be a unique nonempty string")
        seen.add(identifier)
        width, height = (_number(record.get(key), key) for key in ("width", "height"))
        if width <= 0 or height <= 0:
            raise ValueError("image dimensions must be positive")
        normalized = {"image_id": identifier, "width": width, "height": height}
        for kind in ("ground_truth", "predictions"):
            items = record.get(kind)
            if not isinstance(items, list):
                raise ValueError(f"{kind} must be a list")
            boxes = []
            for item in items:
                if not isinstance(item, dict):
                    raise ValueError("each box must be a dictionary")
                class_id = item.get("class_id")
                if isinstance(class_id, bool) or not isinstance(class_id, int) or class_id not in names:
                    raise ValueError("box class_id must be an integer in class_names")
                xyxy = item.get("xyxy")
                if not isinstance(xyxy, (list, tuple)) or len(xyxy) != 4:
                    raise ValueError("xyxy must contain four coordinates")
                xyxy = tuple(_number(value, "box coordinate") for value in xyxy)
                if xyxy[2] <= xyxy[0] or xyxy[3] <= xyxy[1]:
                    raise ValueError("box must have positive width and height")
                box = {"class_id": class_id, "xyxy": xyxy}
                if kind == "predictions":
                    confidence = _number(item.get("confidence"), "confidence")
                    if not prediction_floor <= confidence <= 1:
                        raise ValueError("confidence must be between prediction_floor and 1")
                    box["confidence"] = confidence
                boxes.append(box)
            normalized[kind] = boxes
        result.append(normalized)
    return sorted(result, key=lambda record: record["image_id"])


def _area(box):
    return (box[2] - box[0]) * (box[3] - box[1])


def _iou(left, right):
    intersection_width = max(0.0, min(left[2], right[2]) - max(left[0], right[0]))
    intersection_height = max(0.0, min(left[3], right[3]) - max(left[1], right[1]))
    intersection = intersection_width * intersection_height
    union = _area(left) + _area(right) - intersection
    if not math.isfinite(union) or not math.isfinite(intersection) or union <= 0:
        raise ValueError("box geometry overflow or invalid union")
    return intersection / union


def _size(box):
    area = _area(box)
    if not math.isfinite(area):
        raise ValueError("box area overflow")
    return "small" if area < 32 ** 2 else "medium" if area < 96 ** 2 else "large"


def _region(box, width, height):
    x = min(2, max(0, int(((box[0] / width + box[2] / width) / 2) * 3)))
    y = min(2, max(0, int(((box[1] / height + box[3] / height) / 2) * 3)))
    return REGIONS[y * 3 + x]


def _prepare(records):
    prepared = []
    for record in records:
        truth, predictions = record["ground_truth"], record["predictions"]
        prepared.append({
            "record": record,
            "overlaps": [[_iou(pred["xyxy"], gt["xyxy"]) for gt in truth] for pred in predictions],
            "order": sorted(range(len(predictions)), key=lambda index: (-predictions[index]["confidence"], index)),
        })
    return prepared


def _match(prepared, confidence, matching_iou):
    """Per-image same-class greedy matching; IoU ties use the first GT index."""
    all_matches = {}
    for item in prepared:
        record = item["record"]
        truth, predictions = record["ground_truth"], record["predictions"]
        pred_to_gt, gt_to_pred = {}, {}
        for prediction_index in item["order"]:
            prediction = predictions[prediction_index]
            if prediction["confidence"] < confidence:
                continue
            selected, largest = None, -1.0
            for gt_index, gt in enumerate(truth):
                overlap = item["overlaps"][prediction_index][gt_index]
                if (gt_index not in gt_to_pred and gt["class_id"] == prediction["class_id"]
                        and overlap >= matching_iou and overlap > largest):
                    selected, largest = gt_index, overlap
            pred_to_gt[prediction_index] = selected
            if selected is not None:
                gt_to_pred[selected] = prediction_index
        all_matches[record["image_id"]] = {"pred_to_gt": pred_to_gt, "gt_to_pred": gt_to_pred}
    return all_matches


def _point(prepared, matches, confidence, matching_iou):
    tp = fp = fn = normal_images = normal_fp_images = 0
    for item in prepared:
        record = item["record"]
        match = matches[record["image_id"]]
        image_tp = len(match["gt_to_pred"])
        image_fp = len(match["pred_to_gt"]) - image_tp
        tp += image_tp
        fp += image_fp
        fn += len(record["ground_truth"]) - image_tp
        if not record["ground_truth"]:
            normal_images += 1
            normal_fp_images += image_fp > 0
    return {"confidence_threshold": confidence, "iou_threshold": matching_iou,
            "tp": tp, "fp": fp, "fn": fn, "predictions": tp + fp,
            "precision": tp / (tp + fp) if tp + fp else 0.0,
            "recall": tp / (tp + fn) if tp + fn else 0.0,
            "normal_images": normal_images, "normal_fp_images": normal_fp_images,
            "normal_image_fp_rate": normal_fp_images / normal_images if normal_images else None}


def _best(indices, overlaps):
    # Strict improvement preserves the first (smallest input) index on ties.
    selected, largest = None, -1.0
    for index in indices:
        if overlaps[index] > largest:
            selected, largest = index, overlaps[index]
    return selected, largest if selected is not None else 0.0


def _prediction_candidate(index, record, overlaps, pred_to_gt):
    if index is None:
        return None
    prediction = record["predictions"][index]
    return {"prediction_index": index, "class_id": prediction["class_id"],
            "confidence": prediction["confidence"], "iou": overlaps[index],
            "matched_gt_index": pred_to_gt.get(index)}


def _gt_candidate(index, record, overlaps, gt_to_pred):
    if index is None:
        return None
    return {"gt_index": index, "class_id": record["ground_truth"][index]["class_id"],
            "iou": overlaps[index], "matched_prediction_index": gt_to_pred.get(index)}


def _details(prepared, matches, names, confidence, matching_iou):
    gt_rows, fp_rows = [], []
    for item in prepared:
        record = item["record"]
        image_id = record["image_id"]
        truth, predictions = record["ground_truth"], record["predictions"]
        match = matches[image_id]
        pred_to_gt, gt_to_pred = match["pred_to_gt"], match["gt_to_pred"]
        for gt_index, gt in enumerate(truth):
            overlaps = [row[gt_index] for row in item["overlaps"]]
            same = [index for index, pred in enumerate(predictions) if pred["class_id"] == gt["class_id"]]
            any_index, any_iou = _best(range(len(predictions)), overlaps)
            same_index, same_iou = _best(same, overlaps)
            category, category_index = None, None
            if gt_index not in gt_to_pred:
                conflict = [index for index in same if predictions[index]["confidence"] >= confidence
                            and overlaps[index] >= matching_iou
                            and pred_to_gt.get(index) is not None and pred_to_gt[index] != gt_index]
                low = [index for index in same if predictions[index]["confidence"] < confidence
                       and overlaps[index] >= matching_iou]
                wrong = [index for index, pred in enumerate(predictions)
                         if pred["class_id"] != gt["class_id"] and overlaps[index] >= matching_iou]
                local = [index for index in range(len(predictions)) if overlaps[index] > 0]
                for name, candidates in zip(FN_CATEGORIES, (conflict, low, wrong, local, [])):
                    if candidates or name == "no_overlap_candidate":
                        category = name
                        category_index, _ = _best(candidates, overlaps)
                        break
            gt_rows.append({
                "evidence_id": f"{image_id}:gt:{gt_index}", "image_id": image_id,
                "gt_index": gt_index, "class_id": gt["class_id"], "class_name": names[gt["class_id"]],
                "xyxy": list(gt["xyxy"]), "area": _area(gt["xyxy"]),
                "size_bucket": _size(gt["xyxy"]), "region": _region(gt["xyxy"], record["width"], record["height"]),
                "status": "tp" if gt_index in gt_to_pred else "fn", "fn_category": category,
                "matched_prediction_index": gt_to_pred.get(gt_index),
                "best_any_class_iou": any_iou, "best_same_class_iou": same_iou,
                "best_any_candidate": _prediction_candidate(any_index, record, overlaps, pred_to_gt),
                "best_same_candidate": _prediction_candidate(same_index, record, overlaps, pred_to_gt),
                "category_candidate": _prediction_candidate(category_index, record, overlaps, pred_to_gt),
            })
        for prediction_index in sorted(pred_to_gt):
            if pred_to_gt[prediction_index] is not None:
                continue
            prediction = predictions[prediction_index]
            overlaps = item["overlaps"][prediction_index]
            same = [index for index, gt in enumerate(truth) if gt["class_id"] == prediction["class_id"]]
            any_index, any_iou = _best(range(len(truth)), overlaps)
            same_index, same_iou = _best(same, overlaps)
            duplicate = [index for index in same if overlaps[index] >= matching_iou and index in gt_to_pred]
            wrong = [index for index, gt in enumerate(truth)
                     if gt["class_id"] != prediction["class_id"] and overlaps[index] >= matching_iou]
            local = [index for index in range(len(truth)) if overlaps[index] > 0]
            for category, candidates in zip(FP_CATEGORIES, (duplicate, wrong, local, [])):
                if candidates or category == "background":
                    category_index, _ = _best(candidates, overlaps)
                    break
            fp_rows.append({
                "evidence_id": f"{image_id}:prediction:{prediction_index}", "image_id": image_id,
                "prediction_index": prediction_index, "class_id": prediction["class_id"],
                "class_name": names[prediction["class_id"]], "confidence": prediction["confidence"],
                "xyxy": list(prediction["xyxy"]), "area": _area(prediction["xyxy"]),
                "size_bucket": _size(prediction["xyxy"]),
                "region": _region(prediction["xyxy"], record["width"], record["height"]),
                "fp_category": category, "best_any_class_iou": any_iou, "best_same_class_iou": same_iou,
                "best_any_gt": _gt_candidate(any_index, record, overlaps, gt_to_pred),
                "best_same_gt": _gt_candidate(same_index, record, overlaps, gt_to_pred),
                "category_gt": _gt_candidate(category_index, record, overlaps, gt_to_pred),
            })
    return gt_rows, fp_rows


def _groups(gt_rows, fp_rows, key, values):
    groups = []
    for value in values:
        truth = [row for row in gt_rows if row[key] == value]
        false = [row for row in fp_rows if row[key] == value]
        missed = [row for row in truth if row["status"] == "fn"]
        tp, fp, fn = len(truth) - len(missed), len(false), len(missed)
        groups.append({key: value, "gt": len(truth), "tp": tp, "fp": fp, "fn": fn,
                       "images_with_gt": len({row["image_id"] for row in truth}),
                       "images_with_fn": len({row["image_id"] for row in missed}),
                       "images_with_fp": len({row["image_id"] for row in false}),
                       "precision": tp / (tp + fp) if tp + fp else None,
                       "recall": tp / len(truth) if truth else None,
                       "fn_categories": {name: sum(row["fn_category"] == name for row in missed) for name in FN_CATEGORIES},
                       "fp_categories": {name: sum(row["fp_category"] == name for row in false) for name in FP_CATEGORIES}})
    return groups


def diagnose_detections(records, class_names, conf_threshold=.25, match_iou=.5, *,
                        threshold_grid=DEFAULT_THRESHOLD_GRID, prediction_floor=.001,
                        normal_fp_budget=5 / 245, max_normal_fp_images=5,
                        min_tp_gain=5, min_gain_images=5, min_scale_gt=20, min_scale_fn=10):
    """Diagnose original-coordinate records and a pre-frozen threshold grid.

    Matching is confidence descending, then input prediction index; a prediction
    consumes the highest-IoU available same-class GT, choosing first GT on ties.
    FN categories follow FN_CATEGORIES priority; they examine all stored boxes.
    FP categories follow FP_CATEGORIES priority and examine active predictions.
    Threshold selection maximizes TP, then precision, then threshold under both
    normal-image FP budgets and the frozen TP/image-gain practical gates.
    """
    confidence = _number(conf_threshold, "conf_threshold")
    matching_iou = _number(match_iou, "match_iou")
    floor = _number(prediction_floor, "prediction_floor")
    budget = _number(normal_fp_budget, "normal_fp_budget")
    if not 0 <= floor <= confidence <= 1 or not 0 < matching_iou <= 1 or not 0 <= budget <= 1:
        raise ValueError("invalid confidence, IoU, floor or normal FP budget")
    for value, label, minimum in ((max_normal_fp_images, "max_normal_fp_images", 0),
                                  (min_tp_gain, "min_tp_gain", 1), (min_gain_images, "min_gain_images", 1),
                                  (min_scale_gt, "min_scale_gt", 1), (min_scale_fn, "min_scale_fn", 1)):
        _integer(value, label, minimum)
    if not isinstance(threshold_grid, (list, tuple)) or not threshold_grid:
        raise ValueError("threshold_grid must be a nonempty frozen list or tuple")
    grid = [_number(value, "threshold_grid") for value in threshold_grid]
    if grid != sorted(set(grid)) or any(not floor <= value <= 1 for value in grid) or confidence not in grid:
        raise ValueError("threshold_grid must be strictly increasing, above floor, and include baseline")
    names = _class_names(class_names)
    records = _normalize(records, names, floor)
    prepared = _prepare(records)
    baseline_matches = _match(prepared, confidence, matching_iou)
    baseline = _point(prepared, baseline_matches, confidence, matching_iou)
    gt_rows, fp_rows = _details(prepared, baseline_matches, names, confidence, matching_iou)
    per_class = _groups(gt_rows, fp_rows, "class_id", names)
    for entry in per_class:
        entry["class_name"] = names[entry["class_id"]]
    per_size = _groups(gt_rows, fp_rows, "size_bucket", SIZE_BUCKETS)
    per_region = _groups(gt_rows, fp_rows, "region", REGIONS)
    curve = []
    for threshold in grid:
        matches = baseline_matches if threshold == confidence else _match(prepared, threshold, matching_iou)
        point = _point(prepared, matches, threshold, matching_iou)
        recovered = lost = gain_images = 0
        for item in prepared:
            image_id = item["record"]["image_id"]
            previous = set(baseline_matches[image_id]["gt_to_pred"])
            current = set(matches[image_id]["gt_to_pred"])
            recovered += len(current - previous)
            lost += len(previous - current)
            gain_images += len(current) > len(previous)
        point.update({"recovered_fn": recovered, "lost_tp": lost,
                      "tp_gain": point["tp"] - baseline["tp"], "gain_images_vs_baseline": gain_images,
                      "within_normal_fp_budget": point["normal_image_fp_rate"] is not None
                          and point["normal_fp_images"] <= max_normal_fp_images
                          and point["normal_image_fp_rate"] <= budget})
        point["eligible_for_selection"] = (point["within_normal_fp_budget"]
            and point["tp_gain"] >= min_tp_gain and gain_images >= min_gain_images)
        curve.append(point)
    eligible = [point for point in curve if point["eligible_for_selection"]]
    selected = max(eligible, key=lambda point: (point["tp"], point["precision"], point["confidence_threshold"])) if eligible else None
    selection = {
        "status": "selected" if selected is not None else "stop",
        "reason": "fixed_grid_gain_and_normal_fp_budget_passed" if selected else
                  "normal_image_denominator_missing" if not baseline["normal_images"] else
                  "no_fixed_grid_threshold_passes_gain_and_normal_fp_budget",
        "baseline_threshold": confidence,
        "selected_threshold": selected["confidence_threshold"] if selected else None,
        "selected_operating_point": selected,
        "candidate_thresholds": [point["confidence_threshold"] for point in eligible],
        "threshold_applied": False,
    }
    missed = [row for row in gt_rows if row["status"] == "fn"]
    low_confidence = [row for row in missed if row["fn_category"] == "localized_low_confidence"]
    spatial = [row for row in missed if row["fn_category"] in ("localization_candidate", "no_overlap_candidate")]
    overall_spatial_rate = len(spatial) / len(gt_rows) if gt_rows else None
    slice_support = []
    for size in SIZE_BUCKETS:
        truths = [row for row in gt_rows if row["size_bucket"] == size]
        candidates = [row for row in spatial if row["size_bucket"] == size]
        rate = len(candidates) / len(truths) if truths else None
        supported = (size != "large" and len(truths) >= min_scale_gt and len(candidates) >= min_scale_fn
                     and overall_spatial_rate is not None and rate > overall_spatial_rate)
        slice_support.append({"size_bucket": size, "gt": len(truths), "candidate_fn": len(candidates),
                              "candidate_fn_rate": rate, "overall_candidate_fn": len(spatial),
                              "overall_gt": len(gt_rows), "overall_candidate_fn_rate": overall_spatial_rate,
                              "affected_images": len({row["image_id"] for row in candidates}),
                              "supported": supported,
                              "reason": "candidate_fn_enrichment_with_minimum_support" if supported else
                                        "reference_large_bin" if size == "large" else
                                        "insufficient_gt_support" if len(truths) < min_scale_gt else
                                        "insufficient_candidate_fn_support" if len(candidates) < min_scale_fn else
                                        "no_candidate_fn_enrichment"})
    slice_candidates = [entry for entry in slice_support if entry["supported"]]
    recommendations = {
        "next_branch": "threshold_analysis" if selected else "sliced_inference_controlled" if slice_candidates else "stop_pending_evidence",
        "threshold_analysis": {
            "status": "candidate_supported" if selected else "stop",
            "evidence_count": len(low_confidence),
            "affected_images": len({row["image_id"] for row in low_confidence}),
            "evidence_ids": [row["evidence_id"] for row in low_confidence],
            "selected_threshold": selection["selected_threshold"],
            "selected_tp_gain": selected["tp_gain"] if selected else None,
            "selected_gain_images": selected["gain_images_vs_baseline"] if selected else None,
            "limitations": ["Low-confidence overlap candidates can compete for a GT; recovery is counted by rematching.",
                            "The normal-image FP budget does not constrain false positives on defect-containing images.",
                            "The selected validation operating point has no independent test-set confirmation."],
        },
        "slicing": {
            "status": "candidate_supported" if slice_candidates else "insufficient_evidence",
            "evidence_count": len(spatial),
            "affected_images": len({row["image_id"] for row in spatial}),
            "evidence_ids": [row["evidence_id"] for row in spatial],
            "size_support": slice_support,
            "limitations": ["Candidate FN enrichment can reflect class composition, position or annotation effects.",
                            "Slicing is a controlled experiment candidate, not a proven cause or expected improvement.",
                            "A size bin below min_scale_gt cannot support a stable size-specific conclusion."],
        },
        "limitations": list(LIMITATIONS),
    }
    protocol = {
        "confidence_threshold": confidence, "iou_threshold": matching_iou,
        "threshold_grid": grid, "prediction_floor": floor,
        "normal_fp_budget": budget, "max_normal_fp_images": max_normal_fp_images,
        "min_tp_gain": min_tp_gain, "min_gain_images": min_gain_images,
        "min_scale_gt": min_scale_gt, "min_scale_fn": min_scale_fn,
        "matching": "confidence_descending_same_class_greedy_available_max_iou",
        "confidence_tie_break": "input_prediction_index", "iou_tie_break": "input_gt_index",
        "candidate_iou_tie_break": "input_candidate_index",
        "fn_category_priority": list(FN_CATEGORIES), "fp_category_priority": list(FP_CATEGORIES),
        "size_bins_original_pixels": {"small": "area < 32^2", "medium": "32^2 <= area < 96^2", "large": "area >= 96^2"},
        "region_bins": "box_center_normalized_to_image_three_equal_rows_and_columns",
        "selection_tie_break": ["maximum_tp", "maximum_precision", "highest_confidence_threshold"],
        "slicing_gate": "small_or_medium_gt>=min_scale_gt_and_candidate_fn>=min_scale_fn_and_candidate_fn_rate>overall_candidate_fn_rate",
        "threshold_applied": False, "new_inference": False, "training_performed": False,
    }
    return {
        "schema_version": "detection-diagnosis-v1", "protocol": protocol,
        "records_sha256": hashlib.sha256(json.dumps(records, sort_keys=True, ensure_ascii=False,
                                                     separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest(),
        "summary": {"images": len(records), "gt": len(gt_rows),
                    "stored_predictions": sum(len(record["predictions"]) for record in records),
                    "fn_categories": {name: sum(row["fn_category"] == name for row in missed) for name in FN_CATEGORIES},
                    "fp_categories": {name: sum(row["fp_category"] == name for row in fp_rows) for name in FP_CATEGORIES}},
        "operating_point": baseline, "gt_details": gt_rows, "fp_details": fp_rows,
        "per_class": per_class, "per_size": per_size, "per_region": per_region,
        "threshold_curve": curve, "selection": selection, "recommendations": recommendations,
    }
