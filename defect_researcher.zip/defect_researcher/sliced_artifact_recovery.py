"""Zero-prediction acceptance of saved sliced-comparison artifacts.

The original failed task is never edited or promoted to completed. A separate
task records an independent review of its finished computation, with a new
600-second review budget and the original pipeline failure preserved.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import time

from .audit import _artifact_record, _atomic_text, _configured_paths, _sha256, _timestamp

TOOL = "verify_sliced_artifact_recovery"
DEFAULT_SOURCE_ID = "09c5ce4aceb7426e87af5334bdb03eb4"
DEFAULT_TASK_ID = "1c68e87faed946d490a5ad802186146a"
MAX_REVIEW_SECONDS = 600
REVIEWER = Path(__file__).resolve().parents[1] / "tools" / "verify_sliced_artifact_recovery.py"
FILES = {"result": "recovery_result.json", "protocol": "recovery_protocol.json",
         "source_manifest": "recovery_source_manifest.json", "independent": "independent_verification.json",
         "events": "events.jsonl", "report": "recovery_report.md", "configuration": "review_configuration.json",
         "manifest": "artifact_manifest.json", "completion": "completion.json"}
LIMITATIONS = [
    "The original Agnes business task remains failed and has no completion marker.",
    "This task independently reviews saved computation; it performs no detector prediction or training.",
    "The separate 600-second artifact-review budget does not reset the original 1800-second pipeline deadline.",
    "Validation-only, frame-correlated results do not establish test gain or deployment readiness.",
]


def _read(path):
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError("Expected a JSON object")
    return value


def _write(path, value):
    _atomic_text(Path(path), json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n")


def _canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _equal(left, right):
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isfinite(left) and math.isfinite(right) and left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_equal(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_equal(a, b) for a, b in zip(left, right))
    return left == right


def _safe_id(value):
    if not isinstance(value, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", value) is None:
        raise ValueError("Use a safe, single-directory task ID")
    return value


def _event(directory, stage, status, **details):
    with (directory / FILES["events"]).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"at": _timestamp(), "stage": stage, "status": status, **details},
                                ensure_ascii=False, allow_nan=False)+"\n")


def _source_file_identity(info):
    # Windows stat/DirEntry expose creation ctime while fstat exposes change
    # ctime. Handle-to-path identity therefore uses the shared fields only.
    return (info.st_dev, info.st_ino, info.st_mode, info.st_size, info.st_mtime_ns)


def _source_entry_matches(expected, actual):
    # Windows enumeration has zero dev/ino and a creation-time ctime; opened
    # file handles have an identity and metadata-change ctime. Compare shared
    # enumeration fields first, then use the full handle identity during reads.
    if not expected.st_ino and not expected.st_dev:
        return _source_file_identity(expected)[2:5] == _source_file_identity(actual)[2:5]
    return _source_file_identity(expected) == _source_file_identity(actual)


def _require_plain_source_entry(info):
    # Windows junctions are reparse points, even when is_symlink() is false.
    if (stat.S_ISLNK(info.st_mode)
            or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)):
        raise ValueError("Linked or escaping original evidence is forbidden")
    if not (stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)):
        raise ValueError("Only regular original files and directories are allowed")


def _source_file_digest(path, expected):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        before = os.fstat(stream.fileno())
        _require_plain_source_entry(before)
        if not _source_entry_matches(expected, before):
            raise ValueError("Original source file changed while opening it")
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
        after = os.fstat(stream.fileno())
    current = path.lstat()
    _require_plain_source_entry(current)
    if (_source_file_identity(before) != _source_file_identity(after)
            or before.st_ctime_ns != after.st_ctime_ns
            or _source_file_identity(before) != _source_file_identity(current)):
        raise ValueError("Original source file changed while hashing it")
    return value.hexdigest()


def _source_manifest(source):
    source = Path(source)
    root_info = source.lstat()
    _require_plain_source_entry(root_info)
    if not stat.S_ISDIR(root_info.st_mode):
        raise ValueError("Original source must be a plain directory")
    source = source.resolve(strict=True)  # Once per pass; descendants cannot contain links or junctions.
    rows, directories, pending = [], [], [(source, "", root_info)]
    while pending:
        directory, prefix, expected = pending.pop()
        with os.scandir(directory) as entries:
            # Opening a directory refreshes Windows' enumeration metadata.
            before = directory.lstat()
            _require_plain_source_entry(before)
            if (not stat.S_ISDIR(before.st_mode)
                    or (expected.st_ino and expected.st_ino != before.st_ino)
                    or (expected.st_dev and expected.st_dev != before.st_dev)):
                raise ValueError("Original source directory changed while opening it")
            directories.append((directory, before))
            for entry in entries:
                if entry.name in (".", "..") or "/" in entry.name or "\\" in entry.name:
                    raise ValueError("Unsafe original source directory entry")
                relative = prefix + entry.name
                path = directory / entry.name
                info = entry.stat(follow_symlinks=False)
                _require_plain_source_entry(info)
                if stat.S_ISDIR(info.st_mode):
                    pending.append((path, relative+"/", info))
                else:
                    rows.append({"relative_path": relative, "size_bytes": info.st_size,
                                 "sha256": _source_file_digest(path, info)})
    for directory, before in directories:
        after = directory.lstat()
        _require_plain_source_entry(after)
        if not _source_entry_matches(before, after):
            raise ValueError("Original source directory changed while scanning it: "+str(directory))
    rows.sort(key=lambda row: row["relative_path"])
    return {"schema_version": 1, "origin_task_id": source.name, "source_directory": str(source),
            "files": rows, "file_count": len(rows),
            "original_completion_absent": not any(row["relative_path"] == "completion.json" for row in rows)}


def _check_source_manifest(source, manifest):
    if (type(manifest.get("schema_version")) is not int or manifest["schema_version"] != 1
            or manifest.get("original_completion_absent") is not True
            or type(manifest.get("file_count")) is not int or manifest["file_count"] <= 0
            or manifest["file_count"] != len(manifest.get("files", []))):
        raise ValueError("Original failed-task manifest identity differs")
    if not _equal(_source_manifest(source), manifest):
        raise ValueError("Original failed-task files changed; recovery acceptance refused")


def _timed_source_scan(source, directory, stage, expected=None):
    clock = time.perf_counter()
    _event(directory, stage, "running", fresh_content_sha256=True)
    try:
        actual = _source_manifest(source)
        if expected is not None and not _equal(actual, expected):
            raise ValueError("Original failed-task files changed; recovery acceptance refused")
    except Exception as error:
        _event(directory, stage, "failed", elapsed_seconds=time.perf_counter()-clock,
               type=type(error).__name__, message=str(error))
        raise
    _event(directory, stage, "passed", elapsed_seconds=time.perf_counter()-clock,
           source_files_checked=actual["file_count"],
           source_bytes_checked=sum(row["size_bytes"] for row in actual["files"]), fresh_content_sha256=True)
    return actual


def _source_state(source):
    failure = _read(source/"failure.json")
    budget = _read(source/"budget.json")
    request = _read(source/"worker_request.json")
    receipt = _read(source/"worker_receipt.json")
    environment = _read(source/"environment.json")
    if (failure.get("status") != "failed" or failure.get("task_id") != source.name
            or failure.get("tool") != "compare_validation_slices" or (source/"completion.json").exists()):
        raise ValueError("Only the preserved, unpublished failed sliced task may supply evidence")
    if (receipt.get("status") != "completed" or type(receipt.get("observations")) is not int
            or receipt["observations"] != request["protocol"]["budgets"]["successful_observations"]
            or budget.get("successful_observations") != receipt["observations"]
            or budget.get("inference_finished_epoch") is None or budget.get("resumable") is not True):
        raise ValueError("Artifact recovery requires complete, known-cost detector computation")
    expected = request["reference_environment"]["actual_predictor_options"]
    if expected.get("nms", "missing") is not None or not _equal(environment.get("actual_predictor_options"), expected):
        raise ValueError("Exact original NMS-null controls must be preserved; False is not equivalent")
    with (source/"checkpoint_journal.jsonl").open("r", encoding="utf-8") as stream:
        header = json.loads(stream.readline())
    return failure, budget, request, header["payload"]["identity"]["journal_source_sha256"]


def _deadline(started_epoch, started_monotonic):
    elapsed = max(time.time()-started_epoch, time.perf_counter()-started_monotonic)
    if elapsed > MAX_REVIEW_SECONDS:
        raise TimeoutError("Separate 600-second artifact-review deadline exceeded")
    return elapsed


def _invoke_review(configuration, task_id, source_id, directory, output, remaining):
    if remaining <= 0:
        raise TimeoutError("No artifact-review time remains")
    with (directory/"independent_review.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen([sys.executable, "-B", str(REVIEWER), task_id, "--origin-id", source_id,
                                    "--recovery-directory", str(directory), "--config", str(directory/FILES["configuration"]),
                                    "--output", str(output)], stdout=log, stderr=subprocess.STDOUT,
                                   cwd=str(REVIEWER.parent.parent), creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        try:
            process.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            raise TimeoutError("Independent artifact reviewer exceeded its remaining 600-second budget")
    if process.returncode != 0 or not output.is_file():
        raise ValueError("Independent artifact review failed; no completion may be published")
    return _read(output)


def _review_passed(review, protocol, source_manifest_sha256, failure_sha256, source_summary):
    spec = importlib.util.spec_from_file_location("saved_artifact_review_contract", REVIEWER)
    contract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(contract)  # Constants only; no scientific review runs.
    checks = review.get("checks")
    counts = (review.get("passed_checks"), review.get("total_checks"))
    if (review.get("status") != "passed" or not isinstance(checks, dict) or set(checks) != set(contract.REQUIRED_CHECKS)
            or type(review.get("artifact_review_implementation_version")) is not int
            or review["artifact_review_implementation_version"] != 3
            or any(value is not True for value in checks.values())
            or any(type(count) is not int for count in counts) or counts[0] != counts[1]
            or counts[0] != len(checks) or counts[0] <= 0):
        raise ValueError("Independent review must have typed, nonzero, fully passed checks")
    expected = {"task_id": protocol["task_id"], "computation_task_id": protocol["computation_task_id"],
                "artifact_review_implementation_version": 3,
                "source_task_id": protocol["computation_task_id"], "execution_source_sha256": protocol["execution_source_sha256"],
                "source_failure_sha256": failure_sha256, "source_manifest_sha256": source_manifest_sha256,
                "task_protocol_sha256": protocol["protocol_sha256"],
                "independent_reviewer_sha256": protocol["independent_reviewer_sha256"],
                "primary_scientific_verifier_sha256": contract.PRIMARY_SHA256,
                "kind": "saved_sliced_artifact_recovery_review", "prepublication": True,
                "schema_version": 1, "model_used": False, "gpu_inference_performed_by_reviewer": False,
                "new_predict_calls": 0, "new_gpu_calls": 0, "new_gpu_seconds": 0,
                "original_business_status": "failed", "original_completion_absent": True,
                "original_pipeline_acceptance_passed": False,
                "original_budget_reset": False, "original_final_review_completed_within_1800_seconds": False,
                "verified_source_summary_sha256": _canonical(source_summary)}
    if any(not _equal(review.get(key), value) for key, value in expected.items()):
        raise ValueError("Independent review source/protocol/failed-task bindings differ")
    if any(type(review.get(key)) is not int or review[key] != 0 for key in ("new_predict_calls", "new_gpu_calls", "new_gpu_seconds")):
        raise ValueError("Independent artifact reviewer must record exactly zero new prediction/GPU calls")
    if not _equal(review.get("verified_source_summary"), source_summary):
        raise ValueError("Independent review did not verify the exact source summary")
    seconds = review.get("recovery_review_seconds")
    if (isinstance(seconds, bool) or not isinstance(seconds, (int,float)) or not math.isfinite(seconds)
            or seconds < 0 or seconds > MAX_REVIEW_SECONDS):
        raise ValueError("Independent review elapsed time is invalid or exceeds 600 seconds")
    return True


def _summary(source_summary, source_id):
    cost_keys = ("successful_observations", "formal_calls", "warmup_calls", "gpu_seconds", "inference_wall_seconds",
                 "total_task_wall_seconds", "total_task_wall_seconds_recorded_at")
    value = {key: content for key, content in source_summary.items() if key not in cost_keys}
    value.update(operation_kind="artifact_only_recovery", artifact_recovery_status="passed",
                 source_original_status="failed", source_computation_task_id=source_id,
                 original_completion_absent=True, original_pipeline_acceptance_passed=False,
                 original_final_review_completed_within_1800_seconds=False, original_budget_reset=False,
                 new_detection_inference_performed=False, new_formal_calls=0, new_warmup_calls=0,
                 new_gpu_calls=0, new_gpu_seconds=0., new_training_performed=False,
                 source_execution={key: source_summary[key] for key in cost_keys if key in source_summary})
    return value


def _verify_recovery_receipt_and_semantics(task_dir, report):
    """Producer-internal checks; its mandatory final fresh scan closes publication."""
    directory = Path(task_dir).resolve()
    protocol = _read(directory/FILES["protocol"])
    if (report.get("tool") != TOOL or report.get("status") not in ("completed", "verifying")
            or type(protocol.get("schema_version")) is not int or protocol["schema_version"] != 1
            or report.get("task_id") != directory.name or protocol.get("task_id") != directory.name
            or protocol.get("protocol_id") != "saved-sliced-artifacts-readonly-recovery-v1"
            or type(protocol.get("artifact_review_implementation_version")) is not int
            or protocol["artifact_review_implementation_version"] != 3
            or protocol.get("original_budget_reset") is not False
            or protocol.get("original_pipeline_acceptance_passed") is not False
            or protocol.get("original_business_status") != "failed" or protocol.get("original_completion_absent") is not True
            or protocol.get("original_final_review_completed_within_1800_seconds") is not False
            or protocol.get("source_computation_task_id") != protocol.get("computation_task_id")
            or protocol.get("nms_expected", "missing") is not None
            or type(protocol.get("max_recovery_wall_seconds")) is not int or protocol["max_recovery_wall_seconds"] != 600):
        raise ValueError("Recovery result/protocol identity or read-only contract differs")
    if (protocol.get("producer_source_sha256") != _sha256(Path(__file__).resolve())
            or protocol.get("independent_reviewer_sha256") != _sha256(REVIEWER)
            or any(type(protocol.get(key)) is not int or protocol[key] != 0 for key in
                   ("new_predict_calls", "new_gpu_calls", "new_warmup_calls"))
            or type(protocol.get("new_gpu_seconds")) not in (int,float) or protocol["new_gpu_seconds"] != 0
            or protocol.get("new_detection_inference_performed") is not False):
        raise ValueError("Recovery implementation hash or zero-prediction contract differs")
    configuration = _configured_paths(report["configuration"])
    if not _equal(_read(directory/FILES["configuration"]), report["configuration"]):
        raise ValueError("Recovery saved review configuration differs from its result")
    if report["status"] == "completed":
        pointers = report.get("artifacts", {})
        if set(pointers) != set(FILES) or any(Path(pointers[key]).resolve() != (directory/name).resolve()
                                             for key,name in FILES.items()):
            raise ValueError("Recovery artifact pointers differ from this completed task")
    source_id = _safe_id(protocol["computation_task_id"])
    source = configuration["output_root"]/source_id
    _require_plain_source_entry(source.lstat())
    if Path(protocol["execution_directory"]).resolve() != source or source == directory:
        raise ValueError("Recovery source must be the preserved original task directory")
    source_manifest = _read(directory/FILES["source_manifest"])
    failure, _, request, journal_source = _source_state(source)
    if not _equal(failure.get("configuration"), report["configuration"]):
        raise ValueError("Recovery configuration differs from the original computation")
    review = _read(directory/FILES["independent"])
    evidence = report.get("evidence", {})
    protocol_for_review = {**protocol, "protocol_sha256": _sha256(directory/FILES["protocol"])}
    _review_passed(review, protocol_for_review, _sha256(directory/FILES["source_manifest"]), _sha256(source/"failure.json"), failure["summary"])
    expected_evidence = {"source_computation_task_id": source_id, "source_failure_sha256": _sha256(source/"failure.json"),
                         "source_manifest_sha256": _sha256(directory/FILES["source_manifest"]),
                         "recovery_protocol_sha256": _sha256(directory/FILES["protocol"]),
                         "independent_verification_sha256": _sha256(directory/FILES["independent"]),
                         "producer_source_sha256": _sha256(Path(__file__).resolve()), "independent_reviewer_sha256": _sha256(REVIEWER),
                         "execution_source_sha256": request["execution_source_sha256"], "journal_source_sha256": journal_source}
    if any(not _equal(protocol.get(key), value) for key,value in (
            ("source_failure_sha256", expected_evidence["source_failure_sha256"]),
            ("source_manifest_sha256", expected_evidence["source_manifest_sha256"]),
            ("source_inputs_sha256", _sha256(source/"inputs.json")),
            ("execution_source_sha256", request["execution_source_sha256"]), ("journal_source_sha256",journal_source))):
        raise ValueError("Recovery protocol original source hashes differ")
    if any(not _equal(evidence.get(key), value) for key, value in expected_evidence.items()):
        raise ValueError("Recovery result evidence hash bindings differ")
    if not _equal(report.get("summary"), _summary(review["verified_source_summary"], source_id)):
        raise ValueError("Recovery summary differs from independently verified source evidence")
    timing = report.get("timing", {})
    seconds = timing.get("recovery_wall_seconds")
    if (isinstance(seconds,bool) or not isinstance(seconds,(int,float)) or not math.isfinite(seconds)
            or seconds < review["recovery_review_seconds"] or seconds > MAX_REVIEW_SECONDS
            or timing.get("original_pipeline_budget_reset") is not False):
        raise ValueError("Recovery wall budget is invalid; original pipeline budget cannot reset")
    return True


def verify_sliced_artifact_recovery(task_dir, report):
    """Public saved-task reads always hash every original file afresh."""
    _verify_recovery_receipt_and_semantics(task_dir, report)
    directory = Path(task_dir).resolve()
    protocol = _read(directory/FILES["protocol"])
    configuration = _configured_paths(report["configuration"])
    source = configuration["output_root"]/_safe_id(protocol["computation_task_id"])
    _check_source_manifest(source, _read(directory/FILES["source_manifest"]))
    return True


def run_sliced_artifact_recovery(configuration, task_id=DEFAULT_TASK_ID, *, source_id=DEFAULT_SOURCE_ID):
    started_epoch, started_monotonic = time.time(), time.perf_counter()
    result = {"task_id": task_id, "tool": TOOL, "status": "running", "started_at": _timestamp(), "finished_at": None,
              "configuration": {}, "summary": {}, "evidence": {}, "artifacts": {}, "errors": [], "limitations": list(LIMITATIONS)}
    directory, stage = None, "configuration"
    try:
        task_id, source_id = _safe_id(task_id), _safe_id(source_id)
        paths = _configured_paths(configuration)
        result["configuration"] = {key: str(value) for key, value in paths.items()}
        source = paths["output_root"]/source_id
        target = (paths["output_root"]/task_id).resolve()
        if target == source or target.parent != paths["output_root"].resolve():
            raise ValueError("Use a distinct new task directly under the configured output root")
        target.mkdir(parents=True, exist_ok=False)
        directory = target
        _event(directory, stage, "passed", new_detector_calls=0)
        stage = "source_failed_computation_validation"
        stage_clock = time.perf_counter()
        _require_plain_source_entry(source.lstat())
        failure, budget, request, journal_source = _source_state(source)
        manifest = _timed_source_scan(source, directory, "source_initial_content_scan")
        _write(directory/FILES["source_manifest"], manifest)
        protocol = {"schema_version": 1, "protocol_id": "saved-sliced-artifacts-readonly-recovery-v1", "task_id": task_id,
                    "artifact_review_implementation_version": 3,
                    "computation_task_id": source_id, "source_computation_task_id": source_id, "execution_directory": str(source),
                    "original_business_status": "failed", "original_pipeline_acceptance_passed": False,
                    "original_completion_absent": True, "original_budget_reset": False,
                    "original_final_review_completed_within_1800_seconds": False,
                    "original_pipeline_deadline_epoch": budget["task_started_epoch"]+request["protocol"]["budgets"]["max_task_wall_seconds"],
                    "new_predict_calls": 0, "new_gpu_calls": 0, "new_gpu_seconds": 0, "new_warmup_calls": 0,
                    "new_detection_inference_performed": False, "nms_expected": None,
                    "recovery_started_epoch": started_epoch, "max_recovery_wall_seconds": MAX_REVIEW_SECONDS,
                    "execution_source_sha256": request["execution_source_sha256"], "journal_source_sha256": journal_source,
                    "producer_source_sha256": _sha256(Path(__file__).resolve()), "independent_reviewer_sha256": _sha256(REVIEWER),
                    "source_failure_sha256": _sha256(source/"failure.json"),
                    "source_manifest_sha256": _sha256(directory/FILES["source_manifest"]),
                    "source_inputs_sha256": _sha256(source/"inputs.json"),
                    "independent_verification_path": str(paths["output_root"]/"sliced-artifact-recovery-prepublication"/(task_id+".json"))}
        _write(directory/FILES["protocol"], protocol)
        _write(directory/FILES["configuration"], result["configuration"])
        _event(directory, stage, "passed", source_original_status="failed", original_completion_absent=True,
               original_pipeline_acceptance_passed=False, elapsed_seconds=time.perf_counter()-stage_clock,
               source_files_checked=manifest["file_count"],
               source_bytes_checked=sum(row["size_bytes"] for row in manifest["files"]))
        stage = "independent_saved_science_review"
        stage_clock = time.perf_counter()
        _event(directory, stage, "running", remaining_wall_seconds=MAX_REVIEW_SECONDS-_deadline(started_epoch, started_monotonic))
        external = Path(protocol["independent_verification_path"])
        external.parent.mkdir(parents=True, exist_ok=True)
        if external.exists():
            raise ValueError("A pre-existing independent review receipt must be preserved")
        review = _invoke_review(result["configuration"], task_id, source_id, directory, external,
                                MAX_REVIEW_SECONDS-_deadline(started_epoch, started_monotonic))
        _deadline(started_epoch, started_monotonic)
        _review_passed(review, {**protocol, "protocol_sha256": _sha256(directory/FILES["protocol"])},
                       _sha256(directory/FILES["source_manifest"]), _sha256(source/"failure.json"), failure["summary"])
        _write(directory/FILES["independent"], review)
        result["summary"] = _summary(review["verified_source_summary"], source_id)
        result["evidence"] = {"source_computation_task_id": source_id, "source_failure_sha256": _sha256(source/"failure.json"),
                              "source_manifest_sha256": _sha256(directory/FILES["source_manifest"]),
                              "recovery_protocol_sha256": _sha256(directory/FILES["protocol"]),
                              "independent_verification_sha256": _sha256(directory/FILES["independent"]),
                              "producer_source_sha256": _sha256(Path(__file__).resolve()), "independent_reviewer_sha256": _sha256(REVIEWER),
                              "execution_source_sha256": request["execution_source_sha256"], "journal_source_sha256": journal_source}
        _event(directory, stage, "passed", independent_checks=review["total_checks"],
               new_detector_calls=0, candidate_status=result["summary"]["candidate_status"],
               elapsed_seconds=time.perf_counter()-stage_clock,
               source_files_checked=manifest["file_count"],
               source_bytes_checked=sum(row["size_bytes"] for row in manifest["files"]))
        stage = "artifact_only_publication"
        stage_clock = time.perf_counter()
        result["status"], result["finished_at"] = "verifying", _timestamp()
        result["timing"] = {"recovery_wall_seconds": _deadline(started_epoch, started_monotonic),
                            "max_recovery_wall_seconds": MAX_REVIEW_SECONDS, "original_pipeline_budget_reset": False}
        _verify_recovery_receipt_and_semantics(directory, result)
        _deadline(started_epoch, started_monotonic)
        _timed_source_scan(source, directory, "source_final_content_scan", expected=manifest)
        _deadline(started_epoch, started_monotonic)
        result["status"], result["finished_at"] = "completed", _timestamp()
        result["timing"]["recovery_wall_seconds"] = _deadline(started_epoch, started_monotonic)
        result["artifacts"] = {key: str(directory/name) for key, name in FILES.items()}
        _write(directory/FILES["result"], result)
        _atomic_text(directory/FILES["report"], "# 保存切片产物的独立复核\n\n复核任务：`"+task_id+"`。\n\n原计算任务：`"+source_id+"`，原任务仍为 failed。\n\n本次新检测调用、预热和 GPU 调用均为 0；采用单独 600 秒产物复核预算，未重置原任务 1800 秒预算。\n\n独立复核通过；候选状态：`"+result["summary"]["candidate_status"]+"`。\n\n```json\n"+json.dumps(result["summary"],ensure_ascii=False,indent=2)+"\n```\n")
        _event(directory, stage, "ready", completion_published_last=True, original_business_status="failed",
               elapsed_seconds=time.perf_counter()-stage_clock,
               source_files_checked=manifest["file_count"],
               source_bytes_checked=sum(row["size_bytes"] for row in manifest["files"]))
        records = [_artifact_record(directory/name) for key,name in FILES.items() if key not in ("manifest","completion")]
        if (directory/"independent_review.log").is_file():
            records.append(_artifact_record(directory/"independent_review.log"))
        _write(directory/FILES["manifest"], {"task_id": task_id, "tool": TOOL, "status": "completed", "files": records,
                                            "input_evidence": result["evidence"]})
        candidate = {"task_id": task_id, "tool": TOOL, "status": "completed", "finished_at": result["finished_at"],
                     "artifact_manifest": str(directory/FILES["manifest"]), "artifact_manifest_sha256": _sha256(directory/FILES["manifest"]),
                     "artifacts_sha256": {row["name"]: row["sha256"] for row in records}, **result["evidence"]}
        _write(directory/"completion_candidate.json", candidate)
        if any(_artifact_record(Path(row["path"])) != row for row in records):
            raise ValueError("Recovery artifact changed before final publication")
        _deadline(started_epoch, started_monotonic)
        _atomic_text(directory/FILES["completion"], (directory/"completion_candidate.json").read_text(encoding="utf-8"))
        return result
    except Exception as error:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"].append({"stage": stage, "type": type(error).__name__, "message": str(error)})
        if directory is not None:
            _event(directory, stage, "failed", type=type(error).__name__, message=str(error))
            _write(directory/"failure.json", result)
        return result
