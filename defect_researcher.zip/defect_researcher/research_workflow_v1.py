"""Bounded CPU workflow over real isolated repairs and sealed research evidence.

This is a local domain controller. It does not claim model autonomy, fresh
detector execution, arbitrary recovery, or completion of the contest project.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

from .config import load_config
from . import research_domain_v1 as domain
from .research_protocol_v1 import BudgetError, BudgetLedger, load_protocol, validate_request
from .research_science_v1 import ROOT, digest, file_record, read, read_scientific_evidence

TOOL = "run_bounded_research_workflow_v1"
TOP_FILES = ("request.json", "protocol.json", "runtime.json", "input_case.json", "input_snapshots.json",
             "source_registry.json", "events.jsonl", "budget.jsonl", "evidence.json", "plan.json",
             "result.json", "claims.json", "report.md", "independent_verification.json")
SOURCE_PATHS = (
    "defect_researcher/research_protocol_v1.py", "defect_researcher/research_domain_v1.py",
    "defect_researcher/research_science_v1.py", "defect_researcher/research_workflow_v1.py",
    "tools/verify_research_workflow_v1.py", "tools/review_plan_scale_alignment.py",
    "fixtures/research_workflow_protocol_v1.json", "fixtures/research_science_sources_v1.json",
    "fixtures/labelguard_cases.json", "fixtures/geometry_cases.json",
    "defect_researcher/audit.py", "defect_researcher/config.py", "defect_researcher/geometry_verifier.py",
    "defect_researcher/independent_geometry.py", "defect_researcher/label_repair.py",
    "defect_researcher/labelguard_fixtures.py", "defect_researcher/task_runtime.py",
)
REPORT_SCOPE = (
    "范围：隔离人工LabelGuard输入与已封存验证集研究证据；本次不执行检测推理、训练或模型请求。\n"
    "两种数据来源分别核验，不将历史科学结果当作人工案例上的检测表现。"
)


def write(path, value):
    encoded = json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    Path(path).write_text(encoded, encoding="utf-8", newline="\n")


def _sources(research_root):
    paths = [ROOT / path for path in SOURCE_PATHS] + [Path(research_root) / "cableinspect_geometry.py"]
    return {"schema_version": 1, "files": [file_record(path, str(index)) for index, path in enumerate(paths)]}


def _fresh_sources(registry):
    if any(digest(row["path"]) != row["sha256"] or Path(row["path"]).stat().st_size != row["size_bytes"]
           for row in registry["files"]):
        raise ValueError("Workflow execution source changed after registration")


def _checker(directory, prepublication):
    path = ROOT / "tools/verify_research_workflow_v1.py"
    spec = importlib.util.spec_from_file_location("_bounded_research_workflow_independent_checker", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify(directory, prepublication=prepublication)


def _render(result, plan, claims):
    lines = ["# 受限研究流程验收报告", "", REPORT_SCOPE, "", f"workflow_id: {result['workflow_id']}",
             f"case_id: {result['case_id']}", f"research_status: {result['research_status']}",
             f"next_action: {plan['next_action']}", ""]
    for claim in claims:
        value = json.dumps(claim["value"], ensure_ascii=False, sort_keys=True)
        lines.append(f"- {claim['claim_id']}: {value} [evidence={claim['evidence_id']}; field={claim['field']}]")
    return "\n".join(lines) + "\n"


def run_workflow(request, configuration=None):
    """Run exactly one new workflow; old directories and ledgers cannot resume."""
    request = validate_request(request)
    configuration = configuration or load_config()
    output_root = Path(configuration["output_root"]).resolve()
    workflow_id = "research-workflow-v1-" + request["request_id"]
    directory = output_root / workflow_id
    if directory.exists():
        raise FileExistsError("A workflow with this request ID exists; no overwrite or budget reset")
    # No workflow output may overlap any configured input or dependency roots.
    for key in ("research_root", "dataset_root", "raw_root", "split_dir", "weights_path"):
        protected = Path(configuration[key]).resolve()
        if directory == protected or directory.is_relative_to(protected) or protected.is_relative_to(directory):
            raise ValueError("Workflow output overlaps protected input")
    directory.mkdir(parents=True, exist_ok=False)
    ledger = BudgetLedger(directory, request)
    entries, events, tool_path, claims = [], [], [], []
    current_state = None
    prepared = None
    sources = None

    def event(state, action, reason, ids=()):
        nonlocal current_state
        clock = ledger.snapshot()
        row = {"seq": len(events) + 1, "from_state": current_state, "state": state, "action": action,
               "reason": reason, "evidence_ids": list(ids), "elapsed_seconds": clock["elapsed_wall_seconds"],
               "budget_used": clock["used_domain_invocations"]}
        with (directory / "events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        events.append(row)
        current_state = state

    def invoke(action, cost, function, kind):
        _fresh_sources(sources)
        domain.snapshot_case(prepared)
        token = ledger.reserve(action, cost)
        tool_path.append(action)
        event("running", action, "worst_case_cost_reserved_before_action")
        value = function()
        actual = 1 if kind == "science" else value["cost"]["domain_tool_calls"]
        ledger.close(token, actual_cost=actual)
        identity = f"{workflow_id}:{kind}:{len(entries) + 1}"
        if kind == "science":
            entry = {**value, "evidence_id": identity}
        else:
            entry = {"evidence_id": identity, "kind": kind, "origin": "new_execution",
                     "files": [{"role": key, **record} for key, record in value["artifacts"].items()],
                     "summary": value["summary"], "domain": value}
        entries.append(entry)
        event("awaiting_evidence", action, "closed_cost_receipt_returned", [identity])
        return entry

    def claim(entry, field):
        value = entry
        for key in field.split("."):
            value = value[key]
        claims.append({"claim_id": f"claim-{len(claims) + 1:03d}", "evidence_id": entry["evidence_id"],
                       "field": field, "value": value})

    try:
        event("planned", "plan", "fixed_request_and_original_shared_deadline")
        write(directory / "request.json", request)
        write(directory / "protocol.json", load_protocol())
        snap = ledger.snapshot()
        runtime = {"schema_version": 1, "workflow_id": workflow_id,
                   **{key: snap[key] for key in ("started_epoch", "deadline_epoch", "started_monotonic", "deadline_monotonic", "budget")}}
        write(directory / "runtime.json", runtime)
        sources = _sources(configuration["research_root"])
        write(directory / "source_registry.json", sources)
        prepared = domain.prepare_case(directory / "case_inputs", request["case_id"], configuration["research_root"])
        write(directory / "input_case.json", prepared)
        before = domain.snapshot_case(prepared)
        research_status, next_action, reason = "insufficient_evidence", "stop_budget", "insufficient_reserved_domain_budget"
        hypotheses = []
        try:
            initial = invoke("verify_label_geometry", 1,
                             lambda: domain.verify_case(prepared, directory / "domain_initial", "initial"), "geometry")
            for field in ("verification_status", "issue_count", "inputs_unchanged"):
                if field in initial["summary"]:
                    claim(initial, "summary." + field)
            decision = domain.classify_geometry(initial["domain"])
            if decision == "untrusted":
                research_status, next_action = "refused", "stop_untrusted_source"
                reason = "independent_initial_findings_or_trusted_sources_do_not_authorize_repair"
            else:
                event("verified", "assess_input", "input_findings_allow_" + decision, [initial["evidence_id"]])
                if decision == "repairable":
                    repaired = invoke("repair_label_copy", 3,
                                      lambda: domain.repair_case(prepared, directory / "domain_repairs", "repair"), "repair")
                    for field in ("repair_status", "changed_files", "verification_status"):
                        if field in repaired["summary"]:
                            claim(repaired, "summary." + field)
                    if repaired["domain"]["semantic_status"] != "passed":
                        research_status, next_action = "refused", "stop_untrusted_source"
                        reason = "trusted_copy_repair_did_not_publish_a_verified_copy"
                    else:
                        event("verified", "assess_repair", "repair_copy_published_with_independent_verification", [repaired["evidence_id"]])
                        copy = invoke("verify_copy", 1,
                                      lambda: domain.verify_copy(prepared, repaired["domain"], directory / "domain_copy_checks", "copy"), "copy_geometry")
                        claim(copy, "summary.verification_status")
                        if copy["domain"]["semantic_status"] != "passed":
                            raise ValueError("Explicit independent verification of copy failed")
                        event("verified", "assess_copy", "explicit_copy_check_passed", [copy["evidence_id"]])
                if decision == "clean" or next_action != "stop_untrusted_source":
                    science = invoke("read_scientific_evidence", 1, read_scientific_evidence, "science")
                    for field in ("relative_small.gt", "relative_small.tp_640", "relative_small.tp_960",
                                  "relative_small.recall_640", "relative_small.recall_960", "tiny_small.gt",
                                  "tiny_small.tp_640", "tiny_small.tp_960", "resolution.fp_640", "resolution.fp_960",
                                  "resolution.map50_640", "resolution.map50_960", "slicing.candidate_status", "slicing.failed_gates"):
                        claim(science, "summary." + field)
                    event("verified", "assess_science", "sealed_results_and_scale_definitions_checked", [science["evidence_id"]])
                    hypotheses = [
                        {"hypothesis_id": "resolution_relative_small", "status": "descriptive_gain_with_overall_cost",
                         "evidence_ids": [science["evidence_id"]], "reason": "relative_small_recall_gains_do_not_remove_overall_AP_and_FP_cost"},
                        {"hypothesis_id": "threshold_grid", "status": science["summary"]["diagnosis"]["threshold_status"],
                         "evidence_ids": [science["evidence_id"]], "reason": "sealed_normal_image_FP_budget_rejects_threshold_candidates"},
                        {"hypothesis_id": "fixed_slicing", "status": science["summary"]["slicing"]["candidate_status"],
                         "evidence_ids": [science["evidence_id"]], "reason": "five_frozen_scientific_gates_failed"},
                    ]
                    research_status, next_action = "stopped", "stop_no_registered_candidate"
                    reason = "candidate_stopped_and_no_new_preregistered_experiment_within_zero_inference_scope"
        except BudgetError as error:
            ledger.check()  # An expired deadline or an open reservation remains a failure.
            research_status, next_action, reason = "insufficient_evidence", "stop_budget", str(error)
        ids = [entry["evidence_id"] for entry in entries]
        event("stopped", "stop", reason, ids)
        plan = {"hypotheses": hypotheses, "next_action": next_action, "reason": reason, "evidence_ids": ids}
        after = domain.snapshot_case(prepared)
        snapshots = {"before": before, "after": after, "unchanged": before == after}
        if not snapshots["unchanged"]:
            raise ValueError("Original artificial inputs changed")
        _fresh_sources(sources)
        ledger.check()
        result = {"schema_version": 1, "tool": TOOL, "workflow_id": workflow_id, "status": "completed",
                  "research_status": research_status, "case_id": request["case_id"], "synthetic_only": True,
                  "new_inference_calls": 0, "new_model_requests": 0, "actual_tool_path": tool_path,
                  "domain_invocations": ledger.used_domain_invocations, "plan_status": next_action,
                  "claims_count": len(claims), "final_budget": ledger.snapshot(), "error": None,
                  "limitations": ["CPU workflow uses artificial input fixtures and reuses sealed real validation evidence.",
                                  "No new Agnes conversation or detector experiment occurred in this workflow.",
                                  "This does not establish the original 640/960 failure scenario or full research autonomy."]}
        for name, value in (("input_snapshots.json", snapshots), ("evidence.json", {"schema_version": 1, "workflow_id": workflow_id, "entries": entries}),
                            ("plan.json", plan), ("result.json", result), ("claims.json", {"claims": claims})):
            write(directory / name, value)
        (directory / "report.md").write_text(_render(result, plan, claims), encoding="utf-8", newline="\n")
        verification = _checker(directory, prepublication=True)
        if verification.get("status") != "passed":
            write(directory / "independent_verification.json", verification)
            raise ValueError("Independent workflow report gate failed: " + json.dumps(verification.get("errors", verification.get("error")), ensure_ascii=False))
        write(directory / "independent_verification.json", verification)
        ledger.check()
        _fresh_sources(sources)
        records = [{"role": name, "name": name, **file_record(directory / name, name)} for name in TOP_FILES]
        manifest = {"workflow_id": workflow_id, "status": "completed", "files": records}
        write(directory / "artifact_manifest.json", manifest)
        ledger.check()
        marker = {"workflow_id": workflow_id, "status": "completed", "state": "completed",
                  "artifact_manifest_sha256": digest(directory / "artifact_manifest.json"),
                  "artifacts_sha256": {row["name"]: row["sha256"] for row in records},
                  "independent_verification_sha256": digest(directory / "independent_verification.json"),
                  "finished_at": datetime.now(timezone.utc).isoformat(), "completed_epoch": time.time(),
                  "elapsed_seconds": ledger.snapshot()["elapsed_wall_seconds"],
                  "domain_invocations": ledger.used_domain_invocations, "original_deadline_epoch": ledger.deadline_epoch}
        write(directory / "completion.json", marker)
        ledger.check()
        return {**result, "directory": str(directory), "completion": str(directory / "completion.json")}
    except Exception as error:
        marker = directory / "completion.json"
        if marker.exists():
            marker.replace(directory / "completion_rejected.json")
        failure = {"workflow_id": workflow_id, "tool": TOOL, "status": "failed", "resumable": False,
                   "error": {"type": type(error).__name__, "message": str(error)},
                   "actual_tool_path": tool_path, "original_deadline_epoch": ledger.deadline_epoch,
                   "new_inference_calls": 0, "new_model_requests": 0}
        try:
            failure["budget"] = ledger.snapshot()
        except Exception as journal_error:
            failure["budget_error"] = str(journal_error)
        write(directory / "failure.json", failure)
        return {**failure, "directory": str(directory)}


def read_workflow_status(directory):
    """Read a finished workflow only after fresh independent verification."""
    directory = Path(directory).resolve()
    if (directory / "failure.json").is_file():
        return read(directory / "failure.json")
    if not (directory / "completion.json").is_file():
        return {"status": "running", "directory": str(directory)}
    verification = _checker(directory, prepublication=False)
    if verification.get("status") != "passed":
        return {"status": "failed", "error": "Independent saved workflow verification failed", "verification": verification}
    return {**read(directory / "result.json"), "verification": verification}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path)
    parser.add_argument("--status", type=Path)
    args = parser.parse_args()
    if bool(args.request) == bool(args.status):
        parser.error("Choose exactly one of --request or --status")
    result = read_workflow_status(args.status) if args.status else run_workflow(read(args.request))
    print(json.dumps({k: result.get(k) for k in ("status", "workflow_id", "research_status", "actual_tool_path", "domain_invocations", "directory", "error")}, ensure_ascii=False, indent=2))
    return 0 if result.get("status") == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
