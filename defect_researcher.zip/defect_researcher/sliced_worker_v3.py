"""Version 3 fixed-protocol worker with the sealed external NMS semantics.

The parent owns an independent wall-clock deadline. A stopped process never
publishes a completion marker; a checkpoint contains only a validated pass.
"""
from __future__ import annotations

import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import platform
import sys
import time

from .audit import _artifact_record, _atomic_text, _sha256, _timestamp


EXPECTED_PREDICTOR_OPTIONS = {
    "imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
    "rect": False, "augment": False, "agnostic_nms": False,
    "quantize": None, "nms": None,
}


def _validate_predictor_options(options, *, context):
    """Reject coercion: None and False select different predictor semantics."""
    if type(options) is not dict or options.keys() != EXPECTED_PREDICTOR_OPTIONS.keys():
        raise ValueError(f"{context} predictor options are missing or contain unexpected controls")
    for key, expected in EXPECTED_PREDICTOR_OPTIONS.items():
        actual = options[key]
        if type(actual) is not type(expected) or actual != expected:
            raise ValueError(f"{context} predictor option changed: {key}")
    return dict(options)


def _validate_reference_options(environment):
    if type(environment) is not dict or "actual_predictor_options" not in environment:
        raise ValueError("Sealed reference predictor options are required before backend construction")
    return _validate_predictor_options(environment["actual_predictor_options"], context="Sealed reference")


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _write(path, value):
    _atomic_text(Path(path), json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _pixels(array):
    import numpy as np
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def _canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


class DetectorBackend:
    """The same YOLO.predict entry and FP32 controls as the sealed reference."""

    def __init__(self, request):
        _validate_reference_options(request.get("reference_environment"))
        directory = Path(request["directory"])
        os.environ["YOLO_CONFIG_DIR"] = str(directory / "runtime_settings")
        os.environ["YOLO_AUTOINSTALL"] = "false"
        os.environ["MPLBACKEND"] = "Agg"
        import torch
        import ultralytics
        import cv2
        from ultralytics import YOLO
        self.torch, self.ultralytics, self.cv2 = torch, ultralytics, cv2
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA device 0 is required; CPU fallback is forbidden")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        self.model = YOLO(request["weights_path"], task="detect")
        self.model.model.float()
        if self.model.names != {int(k): v for k, v in request["protocol"]["class_names"].items()}:
            raise ValueError("Checkpoint classes differ from the frozen protocol")
        self.directory = directory
        self.options = {"imgsz": 640, "batch": 1, "device": "0", "half": False, "quantize": None,
                        "conf": .001, "iou": .7, "max_det": 300, "rect": False,
                        "augment": False, "agnostic_nms": False, "nms": None, "save": False, "save_txt": False,
                        "save_crop": False, "save_json": False, "show": False, "verbose": False,
                        "project": str(directory / "prediction_runtime"), "name": "imgsz_640",
                        "exist_ok": True, "stream": False}
        self.actual_input_dtype = None
        self.actual_input_device = None
        self.last_timing = None
        def capture(module, arguments):
            tensor = arguments[0]
            self.actual_input_dtype, self.actual_input_device = str(tensor.dtype), str(tensor.device)
        self.input_hook = self.model.model.register_forward_pre_hook(capture)
        torch.cuda.reset_peak_memory_stats()
        self.expected_environment = request["reference_environment"]
        # Version mismatch is rejected before the first detector prediction.
        current = self.environment(initial=True)
        for key in ("python", "torch", "ultralytics", "cuda", "cudnn", "gpu_name", "gpu_total_bytes"):
            if current[key] != self.expected_environment[key]:
                raise ValueError(f"Reference dependency/backend version differs: {key}")

    def predict(self, source, expected_shape):
        self.last_timing = None
        _validate_reference_options(self.expected_environment)
        _validate_predictor_options({key: self.options[key] for key in EXPECTED_PREDICTOR_OPTIONS
                                     if key in self.options}, context="Requested")
        # A reused predictor must have the sealed control identity before the
        # next CUDA event or model call. Never use a new call to repair drift.
        if self.model.predictor is not None:
            self._effective_options()
        torch = self.torch
        torch.cuda.synchronize()
        started = time.perf_counter()
        gpu_start, gpu_end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        gpu_start.record()
        try:
            with torch.inference_mode(), torch.autocast(device_type="cuda", enabled=False):
                results = self.model.predict(source=source, **self.options)
            effective = self._effective_options()
            if len(results) != 1:
                raise ValueError("Predictor must return exactly one observation")
            value = results[0]
            if isinstance(source, str) and Path(value.path).resolve() != Path(source).resolve():
                raise ValueError("Context predictor source identity changed")
            if tuple(value.orig_shape) != tuple(expected_shape):
                raise ValueError("Predictor original shape changed")
            predictor = self.model.predictor
            if (list(predictor.imgsz) != [640, 640] or str(predictor.model.device) != "cuda:0"
                    or predictor.model.fp16 or next(self.model.model.parameters()).dtype != torch.float32
                    or self.actual_input_dtype != "torch.float32" or self.actual_input_device != "cuda:0"
                    or torch.backends.cuda.matmul.allow_tf32 or torch.backends.cudnn.allow_tf32):
                raise ValueError("Effective single-image FP32/CUDA controls changed")
            boxes = value.boxes
            predictions = [{"class_id": int(cls), "confidence": float(conf), "xyxy": list(map(float, box))}
                           for box, conf, cls in zip(boxes.xyxy.cpu().tolist(), boxes.conf.cpu().tolist(), boxes.cls.cpu().tolist())]
            return {"local_predictions": predictions, "effective_options": effective,
                    "orig_shape": list(value.orig_shape), "device": "cuda:0", "precision": "FP32",
                    "actual_input_dtype": self.actual_input_dtype, "actual_input_device": self.actual_input_device,
                    "model_parameters_dtype": str(next(self.model.model.parameters()).dtype),
                    "ultralytics_speed_ms": dict(value.speed)}
        finally:
            try:
                gpu_end.record()
                torch.cuda.synchronize()
                self.last_timing = {"elapsed_seconds": time.perf_counter() - started,
                                    "gpu_seconds": gpu_start.elapsed_time(gpu_end) / 1000}
            except Exception:
                # Unknown device time must never become a resumable zero-cost call.
                self.last_timing = {"elapsed_seconds": time.perf_counter() - started, "gpu_seconds": None}

    def _effective_options(self):
        predictor = self.model.predictor
        if predictor is None or not hasattr(predictor, "args"):
            raise ValueError("Effective predictor options are missing after backend creation")
        effective = {}
        for key in EXPECTED_PREDICTOR_OPTIONS:
            if not hasattr(predictor.args, key):
                raise ValueError(f"Effective predictor option is missing: {key}")
            effective[key] = getattr(predictor.args, key)
        return _validate_predictor_options(effective, context="Effective")

    def environment(self, initial=False):
        effective = None if initial else self._effective_options()
        torch, ultralytics = self.torch, self.ultralytics
        from ultralytics.engine.model import Model
        from ultralytics.engine.predictor import BasePredictor
        from ultralytics.models.yolo.detect.predict import DetectionPredictor
        from ultralytics.utils import ops
        from ultralytics.utils.nms import non_max_suppression
        callables = {"YOLO.predict": Model.predict, "BasePredictor.pre_transform": BasePredictor.pre_transform,
                     "BasePredictor.preprocess": BasePredictor.preprocess, "BasePredictor.setup_source": BasePredictor.setup_source,
                     "BasePredictor.inference": BasePredictor.inference, "DetectionPredictor.postprocess": DetectionPredictor.postprocess,
                     "scale_boxes": ops.scale_boxes, "NMS": non_max_suppression}
        sources = {name: _artifact_record(Path(inspect.getsourcefile(function)).resolve()) for name, function in callables.items()}
        value = {"python": platform.python_version(), "python_executable": sys.executable,
                 "torch": torch.__version__, "ultralytics": ultralytics.__version__, "cv2": self.cv2.__version__,
                 "cuda": torch.version.cuda, "cudnn": torch.backends.cudnn.version(), "device": "0",
                 "gpu_name": torch.cuda.get_device_name(0), "gpu_total_bytes": torch.cuda.get_device_properties(0).total_memory,
                 "precision": "FP32", "tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
                 "tf32_cudnn": torch.backends.cudnn.allow_tf32, "cudnn_benchmark": torch.backends.cudnn.benchmark,
                 "cudnn_deterministic": torch.backends.cudnn.deterministic, "callable_sources": sources,
                 "prediction_entry": "YOLO.predict", "context_source_type": "original_path",
                 "tile_source_type": "cv2_decoded_BGR_contiguous_ndarray", "model_parameters_dtype": str(next(self.model.model.parameters()).dtype),
                 "legacy_dependency_source_hashes_available": False,
                 "peak_allocated_bytes": torch.cuda.max_memory_allocated()}
        if not initial:
            value.update(actual_predictor_options=effective,
                         actual_predictor_imgsz=list(self.model.predictor.imgsz), actual_predictor_fp16=self.model.predictor.model.fp16,
                         actual_predictor_device=str(self.model.predictor.model.device),
                         actual_input_dtype=self.actual_input_dtype, actual_input_device=self.actual_input_device)
        return value

    def close(self):
        self.input_hook.remove()
        del self.model
        self.torch.cuda.empty_cache()


def _check_budget(budget, protocol, *, now=None):
    now = time.time() if now is None else now
    limits = protocol["budgets"]
    if len(budget["formal_attempts"]) > limits["max_formal_calls"]:
        raise RuntimeError("Formal call budget exceeded")
    if len(budget["warmup_attempts"]) > limits["max_warmup_calls"]:
        raise RuntimeError("Warmup call budget exceeded")
    if budget["gpu_seconds"] > limits["max_gpu_seconds"]:
        raise RuntimeError("Cumulative GPU budget exceeded")
    if (budget.get("inference_started_epoch") is not None
            and max(budget.get("inference_wall_seconds", 0), now-budget["inference_started_epoch"]) > limits["max_inference_wall_seconds"]):
        raise TimeoutError("Inference wall deadline exceeded; it is never reset on resume")
    if max(budget.get("task_wall_seconds", 0), now-budget["task_started_epoch"]) > limits["max_task_wall_seconds"]:
        raise TimeoutError("Task wall deadline exceeded; it is never reset on resume")


def _check_prediction_budget(budget, protocol, *, now=None):
    """An exactly exhausted ledger can be inspected, but cannot start a call."""
    now = time.time() if now is None else now
    _check_budget(budget, protocol, now=now)
    limits = protocol["budgets"]
    if budget["gpu_seconds"] >= limits["max_gpu_seconds"]:
        raise RuntimeError("Cumulative GPU budget exhausted before prediction")
    if (budget.get("inference_started_epoch") is not None
            and max(budget.get("inference_wall_seconds", 0), now-budget["inference_started_epoch"]) >= limits["max_inference_wall_seconds"]):
        raise TimeoutError("Inference wall deadline reached before prediction")
    if max(budget.get("task_wall_seconds", 0), now-budget["task_started_epoch"]) >= limits["max_task_wall_seconds"]:
        raise TimeoutError("Task wall deadline reached before prediction")


def _starting_environment(backend, prior_environment):
    """Resume a cold predictor using verified prior controls, without a warmup."""
    from .sliced_task_v3 import _equal, validate_inference_controls
    cold_resume = (prior_environment is not None and isinstance(backend, DetectorBackend)
                   and backend.model.predictor is None)
    environment = backend.environment(initial=True) if cold_resume else backend.environment()
    if prior_environment is not None:
        validate_inference_controls(prior_environment)
        for key, value in environment.items():
            if key != "peak_allocated_bytes" and (key not in prior_environment or not _equal(value, prior_environment[key])):
                raise ValueError(f"Resumed dependency/control identity changed: {key}")
        environment = {**prior_environment, **environment}
    validate_inference_controls(environment)
    return environment


def _execute(request, backend_factory=DetectorBackend):
    """Execute a request; fake backends are supplied only by isolated tests."""
    from .sliced_task_v3 import validate_worker_request, validate_inference_controls
    validate_worker_request(request)
    _validate_reference_options(request.get("reference_environment"))
    prior_environment = request.get("resume_environment")
    if prior_environment is not None:
        validate_inference_controls(prior_environment)
    import cv2
    import numpy as np
    from .sliced_inference import tiles, map_predictions
    from .sliced_journal import PassJournal, JOURNAL_FILE, write_immutable_json
    directory, protocol = Path(request["directory"]), request["protocol"]
    checkpoint_dir = directory / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    budget = _read(directory / "budget.json")
    index = _read(directory / "checkpoint_index.json")
    completed = {(r["image_id"], r["pass_id"]): r for r in index["checkpoints"]}
    backend, journal = None, None
    segment_started = time.perf_counter()
    task_before = max(budget["task_wall_seconds"], request.get("task_monotonic_elapsed_before_worker", 0))
    inference_before = budget["inference_wall_seconds"]
    inference_segment_started = segment_started if budget.get("inference_started_epoch") is not None else None
    segment = {"utc_started": _timestamp(), "utc_finished": None,
               "task_wall_seconds_before": task_before, "inference_wall_seconds_before": inference_before,
               "monotonic_task_seconds": 0., "monotonic_inference_seconds": 0.}
    budget.setdefault("wall_segments", []).append(segment)
    def save_budget():
        # Growing attempt/index arrays remain in memory. The append journal is
        # durable before/after each call; scalar snapshots are only a cache.
        now = time.time()
        segment["monotonic_task_seconds"] = time.perf_counter()-segment_started
        segment["monotonic_inference_seconds"] = 0. if inference_segment_started is None else time.perf_counter()-inference_segment_started
        budget["inference_wall_seconds"] = 0. if budget.get("inference_started_epoch") is None else max(
            inference_before+segment["monotonic_inference_seconds"], now-budget["inference_started_epoch"])
        budget["task_wall_seconds"] = max(task_before+segment["monotonic_task_seconds"], now-budget["task_started_epoch"])
        budget["formal_calls"] = len(budget["formal_attempts"])
        budget["warmup_calls"] = len(budget["warmup_attempts"])
        budget["successful_observations"] = len(index["checkpoints"])
    def call(source, shape, image_id, pass_id, warmup=False):
        nonlocal inference_segment_started
        save_budget()
        _check_prediction_budget(budget, protocol)
        collection = budget["warmup_attempts" if warmup else "formal_attempts"]
        limit = protocol["budgets"]["max_warmup_calls" if warmup else "max_formal_calls"]
        if len(collection) >= limit:
            raise RuntimeError("Call budget exhausted before prediction")
        if budget.get("inference_started_epoch") is None:
            budget["inference_started_epoch"] = time.time()
            budget["inference_started_at"] = _timestamp()
            inference_segment_started = time.perf_counter()
        attempt = {"call_index": len(collection) + 1, "image_id": image_id, "pass_id": pass_id,
                   "status": "started", "utc_started": _timestamp(), "utc_finished": None,
                   "elapsed_seconds": None, "gpu_seconds": None}
        collection.append(attempt)
        save_budget()
        journal.started(attempt, warmup=warmup)  # fsync before actual prediction.
        try:
            value = backend.predict(source, shape)
            attempt["status"] = "passed"
            return value, attempt
        except Exception as error:
            attempt.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
            raise
        finally:
            timing = backend.last_timing or {"elapsed_seconds": None, "gpu_seconds": None}
            attempt.update(timing, utc_finished=_timestamp())
            seconds = timing.get("gpu_seconds")
            elapsed = timing.get("elapsed_seconds")
            if isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed < 0:
                budget["resumable"] = False
            if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds < 0:
                budget["resumable"] = False
            else:
                budget["gpu_seconds"] += seconds
            save_budget()
            journal.finished(attempt, warmup=warmup)
    try:
        identity = {"protocol_sha256": request["protocol_sha256"], "weight_sha256": protocol["weight_sha256"],
                    "scientific_inputs_sha256": request["scientific_inputs_sha256"],
                    "execution_source_sha256": request["execution_source_sha256"]}
        if type(request.get("execution_io_version")) is not int or request["execution_io_version"] != 3:
            raise ValueError("Only source-bound version 3 durability requests may run")
        save_budget()
        if (directory / JOURNAL_FILE).exists():
            journal = PassJournal.resume(directory, protocol, budget, index, identity)
        else:
            journal = PassJournal(directory, protocol, budget, index, identity)
        _check_budget(budget, protocol)
        backend = backend_factory(request)
        if not budget["warmup_attempts"]:
            first = request["records"][0]
            if _sha256(Path(first["image_path"])) != request["image_sha256"][first["image_id"]]:
                raise ValueError("Warmup source bytes changed; prediction refused")
            call(first["image_path"], (first["height"], first["width"]), first["image_id"], 0, warmup=True)
            _check_budget(budget, protocol)
        environment = _starting_environment(backend, prior_environment)
        # Peak allocation varies by run and is descriptive; control identity is
        # made from fixed environment fields, not the current peak counter.
        environment_identity = _canonical({k: v for k, v in environment.items() if k != "peak_allocated_bytes"})
        _write(directory / "environment.json", environment)
        for image_index, record in enumerate(request["records"]):
            raw_hash = _sha256(Path(record["image_path"]))
            if raw_hash != request["image_sha256"][record["image_id"]]:
                raise ValueError("Image bytes changed before observation")
            image = cv2.imread(record["image_path"], cv2.IMREAD_COLOR)
            if image is None or list(image.shape) != [record["height"], record["width"], 3] or image.dtype != np.uint8:
                raise ValueError("BGR image decoding differs from the fixed population")
            decoded_hash = _pixels(image)
            for crop_record in tiles(record["width"], record["height"]):
                pass_id, crop = crop_record["pass_id"], crop_record["crop"]
                x0, y0, x1, y1 = crop
                array = np.ascontiguousarray(image[y0:y1, x0:x1])
                identity = {"image_id": record["image_id"], "image_index": image_index, "pass_id": pass_id,
                            "crop": crop, "source_image_sha256": raw_hash, "decoded_image_sha256": decoded_hash,
                            "input_pixels_sha256": _pixels(array), "protocol_sha256": request["protocol_sha256"],
                            "weight_sha256": protocol["weight_sha256"], "scientific_inputs_sha256": request["scientific_inputs_sha256"]}
                key = (record["image_id"], pass_id)
                if key in completed:
                    entry = completed[key]
                    checkpoint = _read(directory / entry["relative_path"])
                    if checkpoint["identity"] != identity or checkpoint["environment_identity"] != environment_identity:
                        raise ValueError("Checkpoint pixel/protocol/environment identity differs; resume refused")
                    continue
                value, attempt = call(record["image_path"] if pass_id == 0 else array,
                                      (y1-y0, x1-x0), record["image_id"], pass_id)
                _validate_predictor_options(value.get("effective_options"), context="Observation")
                predictions = value["local_predictions"]
                if len(predictions) > protocol["max_det"] or any(p["confidence"] < protocol["prediction_confidence"] for p in predictions):
                    raise ValueError("Per-pass predictions violate count/confidence floor")
                global_predictions = map_predictions(predictions, crop, record["width"], record["height"], pass_id)
                observation = {**identity, **value, "global_predictions": global_predictions,
                               "elapsed_seconds": attempt["elapsed_seconds"], "gpu_seconds": attempt["gpu_seconds"],
                               "call_index": attempt["call_index"], "environment_identity": environment_identity}
                if not budget["resumable"]:
                    raise RuntimeError("Unknown GPU time forbids a successful observation")
                _check_budget(budget, protocol)
                filename = f"checkpoints/{image_index:04d}-{pass_id}.json"
                path = directory / filename
                metadata = write_immutable_json(path, {"identity": identity, "environment_identity": environment_identity,
                                                      "observation": observation, "observation_sha256": _canonical(observation)})
                entry = {"image_id": record["image_id"], "pass_id": pass_id, "relative_path": filename,
                         **metadata, "call_index": attempt["call_index"]}
                index["checkpoints"].append(entry)
                completed[key] = entry
                save_budget()
                journal.checkpoint(entry)
                if len(index["checkpoints"]) == 1 or len(index["checkpoints"]) % 32 == 0:
                    journal.snapshot()
        _check_budget(budget, protocol)
        if len(index["checkpoints"]) != protocol["budgets"]["successful_observations"]:
            raise ValueError("Worker lacks the complete unique observation population")
        final_environment = backend.environment()
        _validate_reference_options(final_environment)
        environment = {**environment, **final_environment,
                       "peak_allocated_bytes": max(environment.get("peak_allocated_bytes", 0), final_environment.get("peak_allocated_bytes", 0))}
        _write(directory / "environment.json", environment)
        budget["inference_finished_at"] = _timestamp()
        budget["inference_finished_epoch"] = time.time()
        segment["utc_finished"] = _timestamp()
        save_budget()
        journal.snapshot()
        publication = journal.publish("completed")
        receipt = {"status": "completed", "observations": len(index["checkpoints"]),
                   "environment_sha256": _sha256(directory / "environment.json"),
                   **publication, "journal_version": 2,
                   "journal_file_sha256": _sha256(directory / JOURNAL_FILE),
                   "journal_file_size_bytes": (directory / JOURNAL_FILE).stat().st_size,
                   "durability_io": journal.stats}
        _write(directory / "worker_receipt.json", receipt)
        return receipt
    except Exception as error:
        segment["utc_finished"] = _timestamp()
        save_budget()
        publication_error = None
        try:
            if journal is not None:
                journal.snapshot()
                journal.publish("failed")
        except Exception as final_error:
            publication_error = {"type": type(final_error).__name__, "message": str(final_error)}
            journal.close()
            # The stopped journal, including unknown/open attempts, is the
            # recovery authority even when full-file publication failed.
            from .sliced_task_v3 import _recover_stopped_worker
            _recover_stopped_worker(directory, request, protocol)
            budget = _read(directory / "budget.json")
        receipt = {"status": "failed", "error": {"type": type(error).__name__, "message": str(error)},
                   "observations": budget["successful_observations"], "resumable": budget["resumable"]}
        if publication_error:
            receipt["publication_error"] = publication_error
        _write(directory / "worker_receipt.json", receipt)
        return receipt
    finally:
        if journal is not None:
            journal.close()
        if backend is not None:
            backend.close()


def main():
    from .sliced_task_v3 import _protocol, _equal
    request = _read(sys.argv[1])
    if not _equal(request["protocol"],_protocol()):
        raise ValueError("Worker request differs from the frozen protocol")
    result = _execute(request)
    return 0 if result["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
