"""Read-only dataset checks with isolated, verifiable task outputs."""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import struct
import sys
import threading
import types
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


_IMPORT_LOCK = threading.RLock()
_MISSING = object()
_PATH_KEYS = (
    "research_root", "dataset_root", "raw_root", "split_dir",
    "weights_path", "output_root",
)
_LIMITATIONS = [
    "The reused checker shares the dataset conversion geometry module; "
    "this is a consistency audit, not an independent geometry verifier.",
    "Validation image access checks read PNG headers, not full pixel decoding "
    "or a hash of every image's contents.",
    "Weights are hashed without deserializing the checkpoint or running "
    "inference; this audit does not establish model accuracy.",
    "The source checker audits existing train, val and test labels and metadata. "
    "It does not evaluate predictions or select methods using test metrics.",
]


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_text(path: Path, content: str) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _write_json(path: Path, value: Any) -> None:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _event(task_dir: Path, stage: str, status: str, **details: Any) -> None:
    item = {"at": _timestamp(), "stage": stage, "status": status, **details}
    with (task_dir / "events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(item, ensure_ascii=False, allow_nan=False) + "\n")
        stream.flush()


def _configured_paths(configuration: dict) -> dict[str, Path]:
    paths = {}
    for key in _PATH_KEYS:
        value = configuration.get(key)
        if not isinstance(value, (str, os.PathLike)) or not str(value).strip():
            raise ValueError(f"Configuration requires a nonempty path: {key}")
        path = Path(value).expanduser()
        if not path.is_absolute():
            raise ValueError(f"Configuration path must be absolute: {key}={value}")
        paths[key] = path.resolve()
    output = paths["output_root"]
    for key in _PATH_KEYS[:-1]:
        protected = paths[key]
        if output == protected or output.is_relative_to(protected) or protected.is_relative_to(output):
            raise ValueError(f"output_root must be separate from {key}")
    return paths


def _require_file(path: Path, label: str) -> None:
    if not path.is_file():
        raise FileNotFoundError(f"Missing {label}: {path}")


def _run_checker(
    research_root: Path, dataset_root: Path, raw_root: Path, split_dir: Path,
) -> tuple[dict, str]:
    """Load the exact configured modules without creating source bytecode."""
    checker_path = research_root / "数据处理" / "7检查YOLO标注数据.py"
    geometry_path = research_root / "cableinspect_geometry.py"
    stdout, stderr = io.StringIO(), io.StringIO()
    with _IMPORT_LOCK:
        previous_path = sys.path.copy()
        previous_geometry = sys.modules.get("cableinspect_geometry", _MISSING)
        previous_bytecode = sys.dont_write_bytecode
        try:
            sys.dont_write_bytecode = True
            sys.path.insert(0, str(research_root))
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                geometry = types.ModuleType("cableinspect_geometry")
                geometry.__file__ = str(geometry_path)
                sys.modules["cableinspect_geometry"] = geometry
                exec(compile(geometry_path.read_text(encoding="utf-8-sig"),
                             str(geometry_path), "exec"), geometry.__dict__)
                checker = types.ModuleType(f"_defect_dataset_checker_{uuid.uuid4().hex}")
                checker.__file__ = str(checker_path)
                exec(compile(checker_path.read_text(encoding="utf-8-sig"),
                             str(checker_path), "exec"), checker.__dict__)
                report = checker.check_dataset(dataset_root, raw_root, split_dir)
        finally:
            sys.path[:] = previous_path
            sys.dont_write_bytecode = previous_bytecode
            if previous_geometry is _MISSING:
                sys.modules.pop("cableinspect_geometry", None)
            else:
                sys.modules["cableinspect_geometry"] = previous_geometry
    if not isinstance(report, dict) or report.get("status") != "passed":
        raise ValueError(f"Dataset checker did not return a passed result: {report!r}")
    log = stdout.getvalue()
    if stderr.getvalue():
        log += "\n[stderr]\n" + stderr.getvalue()
    return report, log


def _png_header(path: Path) -> tuple[int, int]:
    _require_file(path, "validation image")
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"Validation image has no readable PNG header: {path}")
    width, height = struct.unpack(">II", header[16:24])
    if width == 0 or height == 0:
        raise ValueError(f"Validation image has invalid dimensions: {path}")
    return width, height


def _validation_accessibility(paths: dict[str, Path]) -> dict:
    split_path = paths["split_dir"] / "val.txt"
    _require_file(split_path, "validation split list")
    entries = [line.strip() for line in split_path.read_text(encoding="utf-8-sig").splitlines()
               if line.strip()]
    if not entries:
        raise ValueError(f"Validation split is empty: {split_path}")
    for entry in entries:
        raw_image = Path(entry).resolve()
        raw_image.relative_to(paths["raw_root"])
        dataset_image = paths["dataset_root"] / "images" / "val" / raw_image.name
        source_dimensions = _png_header(raw_image)
        if _png_header(dataset_image) != source_dimensions:
            raise ValueError(f"Validation source/YOLO image dimensions differ: {dataset_image}")
    return {
        "status": "passed", "images_checked": len(entries),
        "source_images_readable": len(entries), "yolo_images_readable": len(entries),
        "method": "Read and compare the PNG signature and IHDR dimensions for every val image",
        "split_path": str(split_path), "split_sha256": _sha256(split_path),
    }


def _artifact_record(path: Path) -> dict:
    return {"name": path.name, "path": str(path),
            "size_bytes": path.stat().st_size, "sha256": _sha256(path)}


def audit_dataset(configuration: dict, task_id: str | None = None) -> dict:
    """Audit configured inputs, publishing completion only after hash checks.

    Inputs are opened only for reading. Every accepted task gets a fresh output
    directory; existing directories are rejected without modifying them.
    """
    task_id = task_id if task_id is not None else f"audit-{uuid.uuid4().hex}"
    result = {
        "task_id": task_id, "tool": "audit_dataset", "status": "running",
        "started_at": _timestamp(), "finished_at": None,
        "configuration": {}, "summary": {}, "artifacts": {},
        "evidence": {}, "errors": [], "limitations": list(_LIMITATIONS),
    }
    task_dir = None
    stage = "configuration"
    try:
        if not isinstance(configuration, dict):
            raise TypeError("configuration must be a dictionary")
        result["configuration"] = json.loads(json.dumps(configuration, default=str))
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name of at most 128 characters")
        paths = _configured_paths(configuration)
        result["configuration"].update({key: str(path) for key, path in paths.items()})
        destination = paths["output_root"] / task_id
        for key in ("dataset_root", "raw_root", "split_dir"):
            if destination.is_relative_to(paths[key]):
                raise ValueError(f"Output directory must be outside read-only {key}: {destination}")
        paths["output_root"].mkdir(parents=True, exist_ok=True)
        destination.mkdir(exist_ok=False)
        task_dir = destination
        _event(task_dir, stage, "started", task_id=task_id)

        stage = "input_provenance"
        for key in ("research_root", "dataset_root", "raw_root", "split_dir"):
            if not paths[key].is_dir():
                raise FileNotFoundError(f"Missing configured {key} directory: {paths[key]}")
        source_files = {
            "checker": paths["research_root"] / "数据处理" / "7检查YOLO标注数据.py",
            "geometry": paths["research_root"] / "cableinspect_geometry.py",
            "dataset_manifest": paths["dataset_root"] / "manifest.json",
            "weights": paths["weights_path"],
        }
        for name, path in source_files.items():
            _require_file(path, name)
            result["evidence"][name] = {"path": str(path), "sha256": _sha256(path)}
        manifest = json.loads(source_files["dataset_manifest"].read_text(encoding="utf-8"))
        expected_geometry_hash = manifest.get("geometry_module_sha256")
        if expected_geometry_hash and expected_geometry_hash != result["evidence"]["geometry"]["sha256"]:
            raise ValueError("Geometry source hash differs from the dataset manifest")
        _event(task_dir, stage, "passed")

        stage = "validation_accessibility"
        validation = _validation_accessibility(paths)
        _event(task_dir, stage, "passed", images_checked=validation["images_checked"])
        stage = "dataset_checker"
        checker_report, checker_log = _run_checker(
            paths["research_root"], paths["dataset_root"], paths["raw_root"], paths["split_dir"],
        )
        if checker_report.get("counts", {}).get("val", {}).get("images") != validation["images_checked"]:
            raise ValueError("Validation accessibility count differs from the dataset checker")
        for name, path in source_files.items():
            if _sha256(path) != result["evidence"][name]["sha256"]:
                raise ValueError(f"Input changed while the audit was running: {path}")
        _event(task_dir, stage, "passed")

        stage = "artifact_publication"
        result["summary"] = {
            "checker_status": checker_report["status"],
            "geometry_version": checker_report.get("geometry_version"),
            "counts": checker_report.get("counts", {}),
            "excluded_buffer_images": checker_report.get("excluded_buffer_images"),
            "validation_accessibility": validation,
            "independent_geometry_verification": False, "inference_performed": False,
        }
        result["artifacts"] = {name: str(task_dir / filename) for name, filename in {
            "audit_result": "audit_result.json", "dataset_check": "dataset_check.json",
            "val_accessibility": "val_accessibility.json", "checker_log": "checker.log",
            "events": "events.jsonl", "artifact_manifest": "artifact_manifest.json",
            "completion": "completion.json",
        }.items()}
        _write_json(task_dir / "dataset_check.json", checker_report)
        _write_json(task_dir / "val_accessibility.json", validation)
        _atomic_text(task_dir / "checker.log", checker_log)
        _event(task_dir, stage, "ready", completion_published_last=True)
        result["status"] = "completed"
        result["finished_at"] = _timestamp()
        _write_json(task_dir / "audit_result.json", result)
        records = [_artifact_record(task_dir / filename) for filename in (
            "dataset_check.json", "val_accessibility.json", "checker.log",
            "events.jsonl", "audit_result.json",
        )]
        artifact_manifest_path = task_dir / "artifact_manifest.json"
        _write_json(artifact_manifest_path, {
            "task_id": task_id, "tool": "audit_dataset", "status": "completed", "created_at": _timestamp(),
            "files": records, "input_evidence": result["evidence"],
        })
        published = json.loads(artifact_manifest_path.read_text(encoding="utf-8"))
        for record in published["files"]:
            if _artifact_record(Path(record["path"])) != record:
                raise ValueError(f"Artifact hash verification failed: {record['path']}")
        _write_json(task_dir / "completion.json", {
            "task_id": task_id, "tool": "audit_dataset", "status": "completed", "finished_at": result["finished_at"],
            "artifact_manifest": str(artifact_manifest_path),
            "artifact_manifest_sha256": _sha256(artifact_manifest_path),
            "artifacts_sha256": {record["name"]: record["sha256"] for record in records},
        })
        return result
    except Exception as exc:
        result["status"] = "failed"
        result["finished_at"] = _timestamp()
        result["errors"].append({"stage": stage, "type": type(exc).__name__, "message": str(exc)})
        if task_dir is not None:
            try:
                _event(task_dir, stage, "failed", error_type=type(exc).__name__, message=str(exc))
                result["artifacts"] = {path.stem: str(path) for path in task_dir.iterdir() if path.is_file()}
                result["artifacts"]["failure"] = str(task_dir / "failure.json")
                _write_json(task_dir / "failure.json", result)
            except Exception as persist_error:
                result["errors"].append({"stage": "failure_publication", "type": type(persist_error).__name__,
                                         "message": str(persist_error)})
        else:
            result["limitations"].append("Failure occurred before a new task directory could be created; "
                                         "no existing task directory was modified.")
        return result
