"""Frozen, validation-only detector comparison with independently scored artifacts."""
from __future__ import annotations

import json
import math
import os
from pathlib import Path
import platform
import re
import sys
import time
import uuid
from typing import Any

from .audit import _artifact_record, _atomic_text, _configured_paths, _png_header, _sha256, _timestamp
from .geometry_verifier import _json, _safe, _sources, CATEGORIES, verify_label_geometry

PROTOCOL_PATH = Path(__file__).resolve().parents[1] / "fixtures" / "resolution_protocol.json"
TOOL = "compare_validation_resolutions"
FILES = {
    "protocol": "protocol.json", "inputs": "inputs.json", "events": "events.jsonl",
    "predictions_640": "predictions_640.jsonl", "predictions_960": "predictions_960.jsonl",
    "metrics_640": "metrics_640.json", "metrics_960": "metrics_960.json",
    "comparison": "comparison.json", "report": "comparison_report.md",
    "comparison_result": "comparison_result.json", "artifact_manifest": "artifact_manifest.json",
    "completion": "completion.json",
}
LIMITATIONS = [
    "This is a frozen-weight validation comparison, not retraining, test evaluation, or proof of research autonomy.",
    "The independent metric algorithm is declared in each score; its AP is not interchangeable with historical Ultralytics metrics.",
    "Timing includes image loading and the prediction API; it is not a standardized throughput benchmark.",
    "Validation images can be correlated across frames; paired image bootstrap intervals are descriptive, not independent-defect confidence bounds.",
]


def _dump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _write(path: Path, value: Any) -> None:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _event(directory: Path, stage: str, status: str, **details: Any) -> None:
    with (directory / FILES["events"]).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(_dump({"at": _timestamp(), "stage": stage, "status": status, **details}) + "\n")
        stream.flush()


def _protocol() -> dict:
    value = _json(PROTOCOL_PATH)
    # Accept no configurable split, resolution, device, thresholds, or fallback.
    required = {"schema_version": 1, "split": "val", "expected_images": 640,
                "train_imgsz": 640, "eval_imgsz": [640, 960], "device": "0", "precision": "FP32",
                "batch": 1, "prediction_confidence": 0.001, "nms_iou": 0.7, "max_det": 300,
                "rect": False, "augment": False, "agnostic_nms": False, "operating_confidence": 0.25,
                "matching_iou": 0.5, "allow_tf32": False, "test_inference": False,
                "weight_change": False, "training_performed": False, "selection_data": "validation_only",
                "fallback": "fail_without_changing_protocol"}
    for key, target in required.items():
        if value.get(key) != target or type(value.get(key)) is not type(target):
            raise ValueError(f"Frozen protocol field differs: {key}")
    return value


def _prepare_inputs(paths: dict[str, Path], protocol: dict) -> tuple[list[dict], dict[str, Path], dict]:
    import yaml
    from . import independent_geometry
    from . import detection_metrics

    dataset = paths["dataset_root"]
    weights = _safe(paths["weights_path"], paths["research_root"])
    if weights.name != "best.pt" or weights.parent.name != "weights":
        raise ValueError("The frozen comparison requires the configured trained best.pt checkpoint")
    training_path = _safe(weights.parent.parent / "experiment_manifest.json", paths["research_root"])
    training, manifest = _json(training_path), _json(dataset / "manifest.json")
    if training.get("status") != "completed":
        raise ValueError("Training manifest is not completed")
    if training.get("geometry_version") != "hbb_v1" or manifest.get("geometry_version") != "hbb_v1":
        raise ValueError("Frozen geometry version must be hbb_v1")
    for group in ("training_args", "actual_training_args"):
        arguments = training.get(group, {})
        if arguments.get("imgsz") != protocol["train_imgsz"] or isinstance(arguments.get("imgsz"), bool):
            raise ValueError(f"Training image size mismatch in {group}")
        if Path(arguments.get("data", "")).resolve() != (dataset / "data.yaml").resolve():
            raise ValueError(f"Training data.yaml path mismatch in {group}")
    for field, expected in (("data_root", dataset), ("data_yaml", dataset / "data.yaml")):
        if Path(training.get(field, "")).resolve() != expected.resolve():
            raise ValueError(f"Training manifest path mismatch: {field}")
    for field, actual in (("data_yaml_sha256", _sha256(dataset / "data.yaml")),
                          ("dataset_manifest_sha256", _sha256(dataset / "manifest.json")),
                          ("best_weights_sha256", _sha256(weights))):
        if training.get(field) != actual:
            raise ValueError(f"Frozen training evidence hash mismatch: {field}")
    if training.get("dataset_manifest") != manifest or training.get("split_sha256") != manifest.get("split_sha256"):
        raise ValueError("Training dataset/split snapshot differs from current dataset manifest")
    data = yaml.safe_load((dataset / "data.yaml").read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or Path(data.get("path", "")).resolve() != dataset:
        raise ValueError("data.yaml must use the configured dataset root")
    if data.get("val") != "images/val" or data.get("names") != {key - 1: value for key, value in CATEGORIES.items()}:
        raise ValueError("data.yaml validation path or class mapping differs")

    sources = _sources(paths, independent_geometry)
    sources.update({"weights": weights, "training_manifest": training_path,
                    "comparison_runner": Path(__file__).resolve(), "comparison_protocol": PROTOCOL_PATH,
                    "detection_metrics": Path(detection_metrics.__file__).resolve(),
                    "config_loader": Path(__file__).with_name("config.py")})
    membership = {}
    for split in ("train", "val", "test", "excluded_buffer"):
        split_file = _safe(paths["split_dir"] / f"{split}.txt", paths["split_dir"])
        if _sha256(split_file) != manifest.get("split_sha256", {}).get(split_file.name):
            raise ValueError(f"Frozen split hash differs: {split}")
        members = []
        for line in split_file.read_text(encoding="utf-8-sig").splitlines():
            if line.strip():
                members.append(_safe(Path(line.strip()), paths["raw_root"]))
        if len(set(members)) != len(members):
            raise ValueError(f"Duplicate split membership: {split}")
        membership[split] = members
    if len(membership["val"]) != protocol["expected_images"]:
        raise ValueError("Validation image count differs from frozen protocol")
    if {p.name for p in (dataset / "images" / "val").iterdir()} != {p.name for p in membership["val"]}:
        raise ValueError("Validation image directory differs from frozen split membership")
    for split in ("train", "test", "excluded_buffer"):
        if set(membership["val"]) & set(membership[split]):
            raise ValueError(f"Validation membership overlaps {split}; inference refused")
    records, seen_names = [], set()
    for raw_image in membership["val"]:
        if raw_image.name in seen_names:
            raise ValueError("Validation basenames are not unique")
        seen_names.add(raw_image.name)
        image = _safe(dataset / "images" / "val" / raw_image.name, dataset)
        label = _safe(dataset / "labels" / "val" / f"{image.stem}.txt", dataset)
        metadata_path = _safe(dataset / "metadata" / "val" / f"{image.stem}.json", dataset)
        metadata = _json(metadata_path)
        width, height = _png_header(image)
        if _png_header(raw_image) != (width, height) or metadata.get("width") != width or metadata.get("height") != height:
            raise ValueError(f"Validation dimensions differ: {image.name}")
        if _sha256(raw_image) != _sha256(image):
            raise ValueError(f"Validation source pixel bytes differ: {image.name}")
        if metadata.get("image") != raw_image.relative_to(paths["raw_root"]).as_posix():
            raise ValueError(f"Validation metadata identity differs: {image.name}")
        ground_truth = []
        for row in label.read_text(encoding="utf-8-sig").splitlines():
            if not row.strip():
                continue
            parts = row.split()
            if len(parts) != 5 or not re.fullmatch(r"[0-6]", parts[0]):
                raise ValueError(f"Invalid validation label: {label}")
            x, y, w, h = [float(value) for value in parts[1:]]
            if not all(math.isfinite(value) and 0 <= value <= 1 for value in (x, y, w, h)) or w <= 0 or h <= 0:
                raise ValueError(f"Nonfinite/out-of-range validation label: {label}")
            ground_truth.append({"class_id": int(parts[0]),
                                 "xyxy": [(x - w / 2) * width, (y - h / 2) * height,
                                          (x + w / 2) * width, (y + h / 2) * height],
                                 "source_label": row})
        records.append({"image_id": image.stem, "width": width, "height": height, "split": "val",
                        "image_path": str(image), "source_path": str(raw_image), "label_path": str(label),
                        "metadata_path": str(metadata_path), "ground_truth": ground_truth})
        sources[f"images/val/{image.name}"] = image
        sources[f"raw_images/val/{raw_image.relative_to(paths['raw_root']).as_posix()}"] = raw_image
    if manifest.get("counts", {}).get("val", {}).get("images") != len(records) or manifest.get("counts", {}).get("val", {}).get("annotations") != sum(len(r["ground_truth"]) for r in records):
        raise ValueError("Validation counts differ from dataset manifest")
    records.sort(key=lambda row: row["image_id"])
    provenance = {"weight_sha256": _sha256(weights), "training_manifest_path": str(training_path),
                  "training_manifest_sha256": _sha256(training_path), "dataset_manifest_sha256": _sha256(dataset / "manifest.json"),
                  "data_yaml_sha256": _sha256(dataset / "data.yaml"), "train_imgsz": protocol["train_imgsz"]}
    return records, sources, provenance


def _snapshot(sources: dict[str, Path]) -> dict[str, dict]:
    return {role: {**_artifact_record(path), "role": role} for role, path in sorted(sources.items())}


def _unchanged(sources: dict[str, Path], before: dict, directory: Path, *, publication: bool = False) -> None:
    current = _snapshot(sources)
    checked = [{"role": role, "path": record["path"], "size_bytes": record["size_bytes"],
                "sha256_before": record["sha256"], "sha256_after": current[role]["sha256"],
                "unchanged": current[role] == record} for role, record in before.items()]
    if publication:
        previous = _json(directory / FILES["inputs"])
        previous.update(files=checked, all_unchanged=all(row["unchanged"] for row in checked))
        _write(directory / FILES["inputs"], previous)
    if not all(row["unchanged"] for row in checked):
        raise ValueError("Frozen input bytes or sizes changed during comparison")


def _infer(records: list[dict], weights: Path, imgsz: int, protocol: dict, directory: Path) -> tuple[list[dict], dict]:
    # Environment is task-local before importing Ultralytics: no research/settings/cache writes.
    os.environ["YOLO_CONFIG_DIR"] = str(directory / "runtime_settings")
    os.environ["YOLO_AUTOINSTALL"] = "false"
    os.environ["MPLBACKEND"] = "Agg"
    import torch
    import ultralytics
    from ultralytics import YOLO
    if not torch.cuda.is_available():
        raise RuntimeError("Frozen GPU protocol requires CUDA device 0; no automatic CPU fallback")
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    model = YOLO(str(weights), task="detect")
    model.model.float()
    if model.names != {key - 1: value for key, value in CATEGORIES.items()}:
        raise ValueError("Checkpoint class mapping differs from frozen classes")
    options = {"imgsz": imgsz, "batch": protocol["batch"], "device": protocol["device"],
               "half": False, "quantize": None, "conf": protocol["prediction_confidence"], "iou": protocol["nms_iou"],
               "max_det": protocol["max_det"], "rect": False, "augment": False, "agnostic_nms": False,
               "save": False, "save_txt": False, "save_crop": False, "save_json": False,
               "show": False, "verbose": False, "project": str(directory / "prediction_runtime"),
               "name": f"imgsz_{imgsz}", "exist_ok": True, "stream": False}
    def predict(record: dict) -> Any:
        values = model.predict(source=record["image_path"], **options)
        if len(values) != 1 or model.predictor.model.fp16 or next(model.model.parameters()).dtype != torch.float32:
            raise ValueError("Predictor did not preserve single-image FP32 inference")
        expected_options = {key: options[key] for key in ("imgsz", "batch", "conf", "iou", "max_det", "rect", "augment", "agnostic_nms", "quantize")}
        if any(getattr(model.predictor.args, key) != expected for key, expected in expected_options.items()):
            raise ValueError("Actual predictor settings differ from frozen protocol")
        if list(model.predictor.imgsz) != [imgsz, imgsz] or str(model.predictor.model.device) != "cuda:0":
            raise ValueError("Actual predictor resolution/device differs from frozen protocol")
        return values[0]
    output = []
    with torch.inference_mode(), torch.autocast(device_type="cuda", enabled=False):
        torch.cuda.synchronize()
        warmup_start = time.perf_counter()
        predict(records[0])
        torch.cuda.synchronize()
        warmup_seconds = time.perf_counter() - warmup_start
        torch.cuda.reset_peak_memory_stats()
        group_start = time.perf_counter()
        for index, record in enumerate(records, 1):
            torch.cuda.synchronize()
            started = time.perf_counter()
            value = predict(record)
            torch.cuda.synchronize()
            seconds = time.perf_counter() - started
            if Path(value.path).resolve() != Path(record["image_path"]).resolve():
                raise ValueError("Predictor returned a different validation source path")
            if tuple(value.orig_shape) != (record["height"], record["width"]):
                raise ValueError(f"Prediction original image dimensions differ: {record['image_id']}")
            boxes = value.boxes
            predictions = [{"class_id": int(class_id), "xyxy": list(map(float, xyxy)), "confidence": float(confidence)}
                           for xyxy, confidence, class_id in zip(boxes.xyxy.cpu().tolist(), boxes.conf.cpu().tolist(), boxes.cls.cpu().tolist())]
            output.append({**record, "predictions": predictions, "eval_imgsz": imgsz,
                           "device": protocol["device"], "precision": "FP32", "elapsed_seconds": seconds,
                           "ultralytics_speed_ms": dict(value.speed)})
            if index % 40 == 0 or index == len(records):
                _event(directory, f"inference_{imgsz}", "running", completed_images=index, total_images=len(records))
        elapsed = time.perf_counter() - group_start
        peak = torch.cuda.max_memory_allocated()
    environment = {"python": platform.python_version(), "python_executable": sys.executable,
                   "torch": torch.__version__, "ultralytics": ultralytics.__version__, "cuda": torch.version.cuda,
                   "cudnn": torch.backends.cudnn.version(), "device": protocol["device"],
                   "gpu_name": torch.cuda.get_device_name(0), "gpu_total_bytes": torch.cuda.get_device_properties(0).total_memory,
                   "precision": "FP32", "tf32_matmul": torch.backends.cuda.matmul.allow_tf32,
                   "tf32_cudnn": torch.backends.cudnn.allow_tf32, "warmup_images": 1,
                   "cudnn_benchmark": torch.backends.cudnn.benchmark, "cudnn_deterministic": torch.backends.cudnn.deterministic,
                   "actual_predictor_options": {key: getattr(model.predictor.args, key) for key in ("imgsz", "batch", "conf", "iou", "max_det", "rect", "augment", "agnostic_nms", "quantize", "nms")},
                   "actual_predictor_imgsz": list(model.predictor.imgsz), "actual_predictor_fp16": model.predictor.model.fp16,
                   "actual_predictor_device": str(model.predictor.model.device),
                   "warmup_seconds": warmup_seconds, "group_elapsed_seconds": elapsed,
                   "peak_allocated_bytes": peak, "model_parameters_dtype": str(next(model.model.parameters()).dtype)}
    del model
    torch.cuda.empty_cache()
    return output, environment


def _validate_predictions(observed: list[dict], expected: list[dict], imgsz: int) -> None:
    if len(observed) != len(expected):
        raise ValueError(f"Inference count differs at resolution {imgsz}")
    for record, original in zip(observed, expected):
        for field in ("image_id", "width", "height", "split", "ground_truth", "image_path", "source_path", "label_path", "metadata_path"):
            if record.get(field) != original.get(field):
                raise ValueError(f"Frozen validation identity/ground truth changed: {field}")
        if record.get("split") != "val" or record.get("eval_imgsz") != imgsz or record.get("device") != "0" or record.get("precision") != "FP32":
            raise ValueError("Inference protocol changed")
        predictions = record.get("predictions")
        if not isinstance(predictions, list) or len(predictions) > 300:
            raise ValueError("Invalid prediction list/count")
        for prediction in predictions:
            class_id, box, confidence = prediction.get("class_id"), prediction.get("xyxy"), prediction.get("confidence")
            if isinstance(class_id, bool) or not isinstance(class_id, int) or class_id not in range(7):
                raise ValueError("Invalid predicted class")
            if not isinstance(confidence, (float, int)) or isinstance(confidence, bool) or not math.isfinite(confidence) or not 0.001 <= confidence <= 1:
                raise ValueError("Invalid predicted confidence")
            if not isinstance(box, list) or len(box) != 4 or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in box):
                raise ValueError("Nonfinite/invalid prediction box")
            if not (0 <= box[0] < box[2] <= record["width"] and 0 <= box[1] < box[3] <= record["height"]):
                raise ValueError("Prediction is not valid original-pixel xyxy")


def _report(result: dict, metrics: dict[int, dict], comparison: dict) -> str:
    rows = ["# 固定权重验证集分辨率对照", "", "同一个 640 训练权重，仅改变 eval_imgsz。验证集用于研究选择，未进行测试集推理。", "",
            f"任务：`{result['task_id']}`；验证图像 {result['summary']['val_images']} 张；标注框 {result['summary']['val_boxes']} 个。", "",
            "| 指标 | eval_imgsz 640 | eval_imgsz 960 |", "|---|---:|---:|"]
    for label, getter in (("独立 mAP50", lambda x: x["mAP50"]), ("独立 mAP50-95", lambda x: x["mAP50_95"]),
                          ("固定置信度 0.25 精确率", lambda x: x["operating_point"]["precision"]),
                          ("固定置信度 0.25 召回率", lambda x: x["operating_point"]["recall"]),
                          ("小框召回率", lambda x: x["operating_point"]["small_recall"]),
                          ("正常图像误报率", lambda x: x["operating_point"]["normal_image_fp_rate"])):
        values = [getter(metrics[size]) for size in (640, 960)]
        rows.append(f"| {label} | {values[0]} | {values[1]} |")
    rows += ["", "## 配对结果", "", "```json", json.dumps(comparison, ensure_ascii=False, indent=2, allow_nan=False), "```", "",
             "## 证据与边界", "", f"权重 SHA256：`{result['summary']['weight_sha256']}`。",
             "", "独立几何闸门通过；输入哈希复查通过。逐图原始像素坐标、置信度、类别、GT 源标签均已保存。",
             "", *[f"- {limitation}" for limitation in LIMITATIONS], ""]
    return "\n".join(rows)


def run_comparison(configuration: dict[str, str], task_id: str | None = None) -> dict:
    """Create one isolated comparison; execution/input failures never publish completion."""
    task_id = task_id if task_id is not None else f"resolution-{uuid.uuid4().hex}"
    result = {"task_id": task_id, "tool": TOOL, "status": "running", "started_at": _timestamp(), "finished_at": None,
              "configuration": {}, "summary": {}, "evidence": {}, "artifacts": {}, "errors": [], "limitations": list(LIMITATIONS)}
    directory, stage = None, "configuration"
    try:
        if not isinstance(configuration, dict):
            raise TypeError("configuration must be a dictionary")
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name")
        paths = _configured_paths(configuration)
        result["configuration"] = {key: str(value) for key, value in paths.items()}
        paths["output_root"].mkdir(parents=True, exist_ok=True)
        destination = paths["output_root"] / task_id
        destination.mkdir(exist_ok=False)
        directory = destination
        protocol = _protocol()
        _event(directory, stage, "passed")
        stage = "freeze_inputs"
        records, sources, provenance = _prepare_inputs(paths, protocol)
        before = _snapshot(sources)
        _write(directory / FILES["protocol"], {**protocol, "task_id": task_id, **provenance,
                                             "image_ids": [row["image_id"] for row in records]})
        _write(directory / FILES["inputs"], {"task_id": task_id, "files": list(before.values()), "all_unchanged": None,
                                           "validation_image_ids": [row["image_id"] for row in records], "provenance": provenance})
        _event(directory, stage, "passed", files=len(sources), val_images=len(records))
        stage = "geometry_gate"
        gate_configuration = {**configuration, "output_root": str(directory / "geometry_gate")}
        gate = verify_label_geometry(gate_configuration, "gate")
        if gate.get("status") != "completed" or gate.get("summary", {}).get("verification_status") != "passed":
            raise ValueError("Independent geometry gate did not pass; inference refused")
        gate_root = directory / "geometry_gate" / "gate"
        if not (gate_root / "completion.json").is_file():
            raise ValueError("Independent geometry gate completion evidence is missing")
        _unchanged(sources, before, directory)
        _event(directory, stage, "passed", geometry_task_id="gate")
        from .detection_metrics import score_detections, compare_scores
        metrics, environments = {}, {}
        for imgsz in protocol["eval_imgsz"]:
            stage = f"inference_{imgsz}"
            _unchanged(sources, before, directory)
            _event(directory, stage, "running", total_images=len(records))
            predictions, environment = _infer(records, paths["weights_path"], imgsz, protocol, directory)
            _validate_predictions(predictions, records, imgsz)
            if environment.get("device") != protocol["device"] or environment.get("precision") != protocol["precision"]:
                raise ValueError("Actual inference device/precision differs from frozen protocol")
            environments[imgsz] = environment
            _atomic_text(directory / FILES[f"predictions_{imgsz}"], "".join(_dump(row) + "\n" for row in predictions))
            stage = f"independent_metrics_{imgsz}"
            metrics[imgsz] = score_detections(predictions, list(CATEGORIES.values()),
                                             conf_threshold=protocol["operating_confidence"], match_iou=protocol["matching_iou"])
            _write(directory / FILES[f"metrics_{imgsz}"], metrics[imgsz])
            _event(directory, stage, "passed", images=len(predictions))
        stage = "paired_comparison"
        comparison = compare_scores(metrics[640], metrics[960])
        _write(directory / FILES["comparison"], comparison)
        # Reread all source membership and hashes before publication, including val pixel bytes.
        stage = "input_immutability"
        current_records, current_sources, current_provenance = _prepare_inputs(paths, protocol)
        if current_records != records or current_sources != sources or current_provenance != provenance:
            raise ValueError("Frozen input membership/validation data changed during comparison")
        _unchanged(sources, before, directory, publication=True)
        result["evidence"] = {role: {"path": value["path"], "sha256": value["sha256"]} for role, value in before.items()
                              if role in ("weights", "training_manifest", "dataset/manifest.json", "dataset/data.yaml", "comparison_protocol", "detection_metrics", "comparison_runner")}
        result["summary"] = {"comparison_status": "passed", "split": "val", "val_images": len(records),
                             "val_boxes": sum(len(r["ground_truth"]) for r in records), "train_imgsz": 640, "eval_imgsz": [640, 960],
                             "weight_sha256": provenance["weight_sha256"], "same_weight": True, "device": protocol["device"],
                             "precision": "FP32", "inputs_unchanged": True, "input_files_hashed": len(sources),
                             "input_hashes_unchanged": True,
                             "geometry_task_id": "gate", "geometry_completion": str(gate_root / "completion.json"),
                             "independent_geometry_verification": True, "test_inference_performed": False,
                             "training_performed": False, "environments": {str(k): v for k, v in environments.items()},
                             "metrics": {str(k): {"mAP50": v["mAP50"], "mAP50_95": v["mAP50_95"], "operating_point": v["operating_point"]} for k, v in metrics.items()},
                             "comparison": comparison}
        _event(directory, stage, "passed", input_files=len(sources))
        stage = "artifact_publication"
        result["artifacts"] = {key: str(directory / filename) for key, filename in FILES.items()}
        result["artifacts"]["geometry_completion"] = str(gate_root / "completion.json")
        result["status"], result["finished_at"] = "completed", _timestamp()
        _atomic_text(directory / FILES["report"], _report(result, metrics, comparison))
        _event(directory, stage, "ready", completion_published_last=True)
        _write(directory / FILES["comparison_result"], result)
        artifacts = [_artifact_record(directory / filename) for key, filename in FILES.items() if key not in ("artifact_manifest", "completion")]
        gate_manifest = _artifact_record(gate_root / "artifact_manifest.json")
        gate_completion = _artifact_record(gate_root / "completion.json")
        artifact_manifest = directory / FILES["artifact_manifest"]
        _write(artifact_manifest, {"task_id": task_id, "tool": TOOL, "status": "completed", "created_at": _timestamp(),
                                  "files": artifacts, "geometry_gate": {"completion": gate_completion, "manifest": gate_manifest}, "input_evidence": result["evidence"]})
        for record in artifacts + [gate_manifest, gate_completion]:
            if _artifact_record(Path(record["path"])) != record:
                raise ValueError("Output artifact changed before publication")
        _write(directory / FILES["completion"], {"task_id": task_id, "tool": TOOL, "status": "completed", "finished_at": result["finished_at"],
                                                "artifact_manifest": str(artifact_manifest), "artifact_manifest_sha256": _sha256(artifact_manifest),
                                                "artifacts_sha256": {r["name"]: r["sha256"] for r in artifacts},
                                                "geometry_completion_sha256": gate_completion["sha256"]})
        return result
    except Exception as error:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"].append({"stage": stage, "type": type(error).__name__, "message": str(error)})
        if directory is not None:
            try:
                (directory / FILES["completion"]).unlink(missing_ok=True)
                _event(directory, stage, "failed", error_type=type(error).__name__, message=str(error))
                result["artifacts"] = {p.stem: str(p) for p in directory.iterdir() if p.is_file()}
                result["artifacts"]["failure"] = str(directory / "failure.json")
                _write(directory / "failure.json", result)
            except Exception as failure:
                result["errors"].append({"stage": "failure_publication", "type": type(failure).__name__, "message": str(failure)})
        return result
