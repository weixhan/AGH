"""Generate bounded label copies from trusted COCO, then verify independently."""
from __future__ import annotations

from collections import Counter
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import uuid

from .audit import _artifact_record, _atomic_text, _configured_paths, _sha256, _timestamp
from . import geometry_verifier as verifier

TOOL = "repair_label_copy"
FILES = {"repair_result": "repair_result.json", "repair_changes": "repair_changes.jsonl",
         "input_manifest": "input_manifest.json", "events": "events.jsonl",
         "copy_manifest": "copy_manifest.json", "artifact_manifest": "artifact_manifest.json",
         "completion": "completion.json"}
LIMITATIONS = [
    "Only trusted-source label/metadata discrepancies are repaired in a fresh copy; human defect boundaries are not assessed.",
    "Images are hard-linked for membership only. Image pixels and weights are neither read nor written.",
    "Clean copies with zero changed label/metadata files are not successful repairs of actual defects.",
    "This is not detection inference, accuracy improvement or resumable business recovery.",
]


def _write(path: Path, value: dict) -> None:
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _event(directory: Path, stage: str, status: str, **fields) -> None:
    with (directory / "events.jsonl").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"at": _timestamp(), "stage": stage, "status": status, **fields},
                                ensure_ascii=False, allow_nan=False) + "\n")


def _inventory(paths: dict) -> tuple[dict, dict]:
    """Hash text inputs and code, recording absent trusted files explicitly."""
    from . import independent_geometry
    sources = {"repair_code": Path(__file__).resolve(), "verifier": Path(verifier.__file__).resolve(),
               "oracle": Path(independent_geometry.__file__).resolve(), "fixtures": independent_geometry.FIXTURE_PATH,
               "production_geometry": paths["research_root"] / "cableinspect_geometry.py"}
    sources.update({f"raw/{name}.json": paths["raw_root"] / f"{name}.json"
                    for name in ("cable_1", "cable_2", "cable_3")})
    sources.update({f"splits/{name}.txt": paths["split_dir"] / f"{name}.txt"
                    for name in (*verifier.SPLITS, "excluded_buffer")})
    sources.update({f"dataset/{name}": paths["dataset_root"] / name for name in ("manifest.json", "data.yaml")})
    images = {}
    for split in verifier.SPLITS:
        for kind in ("labels", "metadata", "images"):
            directory = paths["dataset_root"] / kind / split
            if directory.exists():
                verifier._safe(directory, paths["dataset_root"], file=False)
                for path in sorted(directory.iterdir()):
                    verifier._safe(path, paths["dataset_root"])
                    relative = path.relative_to(paths["dataset_root"]).as_posix()
                    if kind == "images":
                        stat = path.stat()
                        images[relative] = {"path": str(path), "size_bytes": stat.st_size,
                                            "inode": stat.st_ino, "device": stat.st_dev,
                                            "mtime_ns": stat.st_mtime_ns}
                    else:
                        sources[relative] = path
    inventory = {}
    for role, path in sources.items():
        path = Path(path)
        if path.exists():
            # The only allowed non-dataset inputs are fixed configured source/code files.
            root = paths["raw_root"] if role.startswith("raw/") else paths["split_dir"] if role.startswith("splits/") else (
                paths["dataset_root"] if role.startswith(("dataset/", "labels/", "metadata/"))
                else paths["research_root"] if role == "production_geometry" else Path(__file__).resolve().parents[1])
            verifier._safe(path, root)
            inventory[role] = {"path": str(path.resolve()), "exists": True,
                               "size_bytes": path.stat().st_size, "sha256": _sha256(path)}
        else:
            inventory[role] = {"path": str(path.resolve()), "exists": False, "size_bytes": None, "sha256": None}
    return inventory, images


def _load_production(path: Path):
    specification = importlib.util.spec_from_file_location("_labelguard_geometry_" + uuid.uuid4().hex, path)
    if specification is None or specification.loader is None:
        raise ValueError("Cannot load trusted production geometry")
    module = importlib.util.module_from_spec(specification)
    # Execute reviewed local source without writing a __pycache__ into the research checkout.
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    if module.GEOMETRY_VERSION != "hbb_v1":
        raise ValueError("Production geometry version differs from hbb_v1")
    return module


def _labels_match(data: bytes | None, expected: list) -> bool:
    if data is None:
        return False
    try:
        rows = [line.split() for line in data.decode("utf-8-sig").splitlines() if line.strip()]
        if len(rows) != len(expected):
            return False
        for row, target in zip(rows, expected):
            if len(row) != 5 or int(row[0]) != target[0]:
                return False
            values = [float(value) for value in row[1:]]
            if any(not math.isfinite(value) or not 0 <= value <= 1 for value in values):
                return False
            if not verifier._numeric(values, target[1], verifier.YOLO_TOLERANCE)[0]:
                return False
        return True
    except (ValueError, UnicodeError):
        return False


def _metadata_match(actual: dict | None, target: dict) -> bool:
    if not isinstance(actual, dict):
        return False
    for key in ("image", "image_id", "source_json", "width", "height", "geometry_version"):
        if actual.get(key) != target[key] or type(actual.get(key)) is not type(target[key]):
            return False
    items = actual.get("annotations")
    if not isinstance(items, list) or len(items) != len(target["annotations"]):
        return False
    for item, expected in zip(items, target["annotations"]):
        if not isinstance(item, dict):
            return False
        for key, value in expected.items():
            if key in ("hbb_xyxy", "rotated_corners", "original_bbox", "rotation"):
                tolerance = verifier.PIXEL_TOLERANCE if key in ("hbb_xyxy", "rotated_corners") else 0.0
                if not verifier._numeric(item.get(key), value, tolerance)[0]:
                    return False
            elif key not in item or item[key] != value or (
                    key in ("annotation_id", "image_id", "category_id", "bbox_clipped") and type(item[key]) is not type(value)):
                return False
    return True


def _trusted_plan(paths: dict, before: dict) -> tuple[dict, list, dict]:
    """Refuse uncertain sources before creating a dataset copy."""
    manifest = verifier._json(paths["dataset_root"] / "manifest.json")
    if manifest.get("geometry_version") != "hbb_v1" or manifest.get("categories") != {str(k): v for k, v in verifier.CATEGORIES.items()}:
        raise ValueError("Trusted manifest geometry/class mapping differs")
    if verifier._class_mapping(paths["dataset_root"] / "data.yaml") != {k - 1: v for k, v in verifier.CATEGORIES.items()}:
        raise ValueError("Trusted YAML class mapping differs")
    for group, prefix in (("source_sha256", "raw"), ("split_sha256", "splits")):
        wanted = {role.split("/", 1)[1]: row for role, row in before.items() if role.startswith(prefix + "/")
                  and (row["exists"] or not role.endswith("excluded_buffer.txt"))}
        declared = manifest.get(group)
        if not isinstance(declared, dict) or set(declared) != set(wanted):
            raise ValueError(f"Trusted {group} membership differs or is incomplete")
        for name, row in wanted.items():
            if not row["exists"] or not isinstance(declared[name], str) or not re.fullmatch(r"[0-9a-f]{64}", declared[name]) or declared[name] != row["sha256"]:
                raise ValueError(f"Trusted source hash missing or different: {prefix}/{name}")
    geometry = before["production_geometry"]
    if not geometry["exists"] or manifest.get("geometry_module_sha256") != geometry["sha256"]:
        raise ValueError("Production geometry does not match the trusted module hash")
    records = verifier._database(paths)
    split_paths = verifier._split_paths(paths, records)
    module = _load_production(Path(geometry["path"]))
    plan, split_counts = [], {}
    for split in verifier.SPLITS:
        stems = {Path(relative).stem for relative in split_paths[split]}
        for kind, extension in (("labels", ".txt"), ("metadata", ".json"), ("images", ".png")):
            directory = paths["dataset_root"] / kind / split
            observed = {path.name for path in directory.iterdir()} if directory.is_dir() else set()
            expected = {stem + extension for stem in stems}
            if observed - expected or (kind == "images" and observed != expected):
                raise ValueError(f"Uncertain {kind} membership: {split}")
        counts = Counter()
        for relative in split_paths[split]:
            record = records[relative]
            image, rows, items = record["image"], [], []
            for annotation in record["annotations"]:
                bbox = annotation["bbox"]
                if (not isinstance(bbox, list) or len(bbox) != 4 or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in bbox)
                        or bbox[2] <= 0 or bbox[3] <= 0):
                    raise ValueError(f"Invalid source bbox: {record['source_json']}, annotation={annotation['id']}")
                attributes = annotation.get("attributes") or {}
                if not isinstance(attributes, dict) or isinstance(attributes.get("rotation", 0), bool):
                    raise ValueError(f"Invalid source attributes: annotation={annotation['id']}")
                rotation = float(attributes.get("rotation", 0))
                if not math.isfinite(rotation):
                    raise ValueError(f"Non-finite rotation: annotation={annotation['id']}")
                hbb, clipped = module.coco_bbox_to_hbb(bbox, image["width"], image["height"], rotation)
                yolo, _ = module.coco_bbox_to_yolo(bbox, image["width"], image["height"], rotation)
                if hbb is None or yolo is None:
                    raise ValueError(f"Source bbox has no visible intersection: annotation={annotation['id']}")
                rows.append([annotation["category_id"] - 1, yolo])
                items.append({"source_json": record["source_json"], "image_id": image["id"], "annotation_id": annotation["id"],
                              "category_id": annotation["category_id"], "class": verifier.CATEGORIES[annotation["category_id"]],
                              "original_bbox": bbox, "rotation": rotation,
                              "rotated_corners": module.coco_bbox_to_rotated_corners(bbox, rotation), "hbb_xyxy": list(hbb),
                              "bbox_clipped": clipped, "geometry_version": "hbb_v1",
                              "gradation": attributes.get("gradation"), "anomaly_id": attributes.get("anomaly_id")})
                counts["source_annotations"] += 1
                counts["annotations"] += 1
                counts["nonzero_rotation_attributes"] += int(rotation != 0)
                counts["rotated_annotations"] += int(rotation % 360 != 0)
                counts["clipped_annotations"] += int(clipped)
            counts["images"] += 1
            counts["abnormal_images" if rows else "normal_images"] += 1
            metadata = {"image": relative, "source_json": record["source_json"], "image_id": image["id"],
                        "width": image["width"], "height": image["height"], "geometry_version": "hbb_v1", "annotations": items}
            stem = Path(relative).stem
            label_path, meta_path = (paths["dataset_root"] / "labels" / split / (stem + ".txt"),
                                     paths["dataset_root"] / "metadata" / split / (stem + ".json"))
            label_before = label_path.read_bytes() if label_path.exists() else None
            meta_before = meta_path.read_bytes() if meta_path.exists() else None
            try:
                old_metadata = verifier._json(meta_path) if meta_path.exists() else None
            except (ValueError, UnicodeError):
                old_metadata = None
            label_same, metadata_same = _labels_match(label_before, rows), _metadata_match(old_metadata, metadata)
            generated_label = "\n".join(str(category) + " " + " ".join(f"{value:.8f}" for value in values) for category, values in rows).encode("utf-8")
            generated_meta = (json.dumps(metadata, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
            for path, original, same, generated in ((label_path, label_before, label_same, generated_label),
                                                    (meta_path, meta_before, metadata_same, generated_meta)):
                plan.append({"relative_path": path.relative_to(paths["dataset_root"]).as_posix(), "source_path": str(path),
                             "original": original, "content": original if same else generated, "changed": not same,
                             "source_json": record["source_json"], "image": relative, "image_id": image["id"],
                             "annotation_ids": [ann["id"] for ann in record["annotations"]]})
        keys = ("images", "normal_images", "abnormal_images", "annotations", "source_annotations", "nonzero_rotation_attributes",
                "rotated_annotations", "clipped_annotations", "invalid_annotations")
        split_counts[split] = {key: counts[key] for key in keys}
    totals = {key: sum(counts[key] for counts in split_counts.values()) for key in keys}
    if manifest.get("counts") != split_counts or manifest.get("totals") != totals or manifest.get("raw_images") != len(records) or manifest.get("raw_annotations") != sum(len(r["annotations"]) for r in records.values()) or manifest.get("excluded_buffer_images") != len(split_paths["excluded_buffer"]):
        raise ValueError("Trusted manifest counts differ from source/splits")
    return manifest, plan, {"counts": split_counts, "totals": totals, "split_paths": split_paths}


def _tree_hash(dataset: Path, split: str) -> str:
    import hashlib
    digest = hashlib.sha256()
    for path in sorted((dataset / "labels" / split).glob("*.txt")):
        digest.update(path.relative_to(dataset).as_posix().encode("utf-8") + b"\0")
        digest.update(path.read_bytes() + b"\0")
    return digest.hexdigest()


def repair_label_copy(configuration: dict, task_id: str | None = None) -> dict:
    task_id = task_id if task_id is not None else "label-copy-" + uuid.uuid4().hex
    result = {"task_id": task_id, "tool": TOOL, "status": "running", "started_at": _timestamp(),
              "finished_at": None, "configuration": {}, "summary": {}, "artifacts": {},
              "evidence": {}, "errors": [], "limitations": list(LIMITATIONS)}
    directory, stage = None, "configuration"
    try:
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name")
        paths = _configured_paths(configuration)
        result["configuration"] = {key: str(value) for key, value in paths.items()}
        paths["output_root"].mkdir(parents=True, exist_ok=True)
        destination = paths["output_root"] / task_id
        destination.mkdir(exist_ok=False)
        directory = destination
        _event(directory, stage, "passed")
        stage = "input_inventory"
        before, images_before = _inventory(paths)
        stage = "before_verification"
        before_config = {**result["configuration"], "output_root": str(directory / "before_verification")}
        before_report = verifier.verify_label_geometry(before_config, "before")
        before_status = before_report.get("summary", {}).get("verification_status") if before_report.get("status") == "completed" else "execution_failed"
        _event(directory, stage, "recorded", execution_status=before_report.get("status"), verification_status=before_status)
        stage = "trusted_source_and_plan"
        refusal = None
        try:
            manifest, plan, counts = _trusted_plan(paths, before)
        except (ValueError, FileNotFoundError, KeyError, TypeError) as error:
            refusal = {"stage": stage, "type": type(error).__name__, "message": str(error)}
            manifest, plan, counts = {}, [], {}
        copy_manifest = {"task_id": task_id, "tool": TOOL, "copy_root": None, "files": [], "images": [],
                         "after_verification": None, "verification_status": None}
        changes, configuration_changes = [], []
        if refusal:
            _event(directory, stage, "refused", reason=refusal["message"])
            summary = {"repair_status": "refused", "verification_status": None,
                       "before_verification_status": before_status, "changed_files": 0,
                       "decision": "insufficient_trusted_evidence", "refusal_reasons": [refusal]}
        else:
            _event(directory, stage, "passed", planned_changes=sum(item["changed"] for item in plan))
            # Revalidate all frozen text inputs before creating any copy.
            if _inventory(paths) != (before, images_before):
                raise ValueError("Input membership/hash changed during repair planning")
            stage = "copy_generation"
            copy_root = directory / "dataset_copy"
            copy_root.mkdir()
            for split in verifier.SPLITS:
                for kind in ("labels", "metadata", "images"):
                    (copy_root / kind / split).mkdir(parents=True)
            for item in plan:
                target = copy_root / item["relative_path"]
                with target.open("xb") as stream:
                    stream.write(item["content"])
                if item["changed"]:
                    import hashlib
                    original = item["original"]
                    changes.append({"task_id": task_id, "relative_path": item["relative_path"],
                                    "operation": "create_missing" if original is None else "replace_from_trusted_source",
                                    "source_json": item["source_json"], "image": item["image"],
                                    "image_id": item["image_id"], "annotation_ids": item["annotation_ids"],
                                    "before_sha256": hashlib.sha256(original).hexdigest() if original is not None else None,
                                    "after_sha256": _sha256(target), "before": original.decode("utf-8-sig", errors="replace") if original is not None else None,
                                    "after": item["content"].decode("utf-8"), "source_sha256": before["raw/" + item["source_json"]]["sha256"]})
            for relative, image in images_before.items():
                target = copy_root / relative
                os.link(image["path"], target)
                copy_manifest["images"].append({"relative_path": relative, "path": str(target),
                                                "source_path": image["path"], "storage": "hardlink"})
            yaml = (paths["dataset_root"] / "data.yaml").read_text(encoding="utf-8-sig")
            replacement = "path: " + json.dumps(copy_root.as_posix(), ensure_ascii=False)
            yaml = re.sub(r"^path:.*$", replacement, yaml, count=1, flags=re.MULTILINE) if re.search(r"^path:", yaml, re.MULTILINE) else replacement + "\n" + yaml
            _atomic_text(copy_root / "data.yaml", yaml)
            copied_manifest = {**manifest, "output": str(copy_root),
                               "label_tree_sha256": {split: _tree_hash(copy_root, split) for split in verifier.SPLITS},
                               "labelguard_copy": {"task_id": task_id, "input_dataset": str(paths["dataset_root"]),
                                                   "input_manifest_sha256": before["dataset/manifest.json"]["sha256"],
                                                   "production_geometry_sha256": before["production_geometry"]["sha256"],
                                                   "label_metadata_changed_files": len(changes)}}
            _write(copy_root / "manifest.json", copied_manifest)
            configuration_changes = ["data.yaml", "manifest.json"]
            copy_manifest["copy_root"] = str(copy_root)
            for path in sorted(copy_root.rglob("*")):
                if path.is_file() and not path.relative_to(copy_root).as_posix().startswith("images/"):
                    copy_manifest["files"].append({"relative_path": path.relative_to(copy_root).as_posix(), **_artifact_record(path)})
            _event(directory, stage, "passed", changed_files=len(changes), image_links=len(images_before))
            stage = "after_independent_verification"
            after_config = {**result["configuration"], "dataset_root": str(copy_root), "output_root": str(directory / "after_verification")}
            after_report = verifier.verify_label_geometry(after_config, "after")
            from .task_runtime import get_task_status
            verified = get_task_status(after_config, "after")
            if verified.get("status") != "completed" or verified.get("summary", {}).get("verification_status") != "passed":
                raise ValueError("Generated copy failed independent verification: " + json.dumps(
                    {"status": verified.get("status"), "summary": verified.get("summary"), "errors": verified.get("errors")}, ensure_ascii=False))
            copy_manifest["after_verification"] = {"task_id": "after", "output_root": after_config["output_root"],
                                                     "result_path": after_report["artifacts"]["verification_result"],
                                                     "completion_path": after_report["artifacts"]["completion"], "verification_status": "passed"}
            copy_manifest["verification_status"] = "passed"
            summary = {"repair_status": "passed", "verification_status": "passed", "before_verification_status": before_status,
                       "decision": "repaired_copy" if changes else "normal_no_change", "changed_files": len(changes),
                       "changed_labels": sum(row["relative_path"].startswith("labels/") for row in changes),
                       "changed_metadata": sum(row["relative_path"].startswith("metadata/") for row in changes),
                       "configuration_changes": configuration_changes, "counts": counts["counts"], "totals": counts["totals"],
                       "independent_geometry_verification": True, "fixture_counts": verified["summary"]["fixture_counts"],
                       "inference_performed": False, "copy_root": str(copy_root)}
            _event(directory, stage, "passed")
        stage = "input_immutability"
        after, images_after = _inventory(paths)
        if (before, images_before) != (after, images_after):
            raise ValueError("Original input membership/hash or image stat changed during label copy")
        input_rows = [{"role": role, "path": row["path"], "exists_before": row["exists"], "exists_after": after[role]["exists"],
                       "size_bytes": row["size_bytes"], "sha256_before": row["sha256"], "sha256_after": after[role]["sha256"],
                       "unchanged": row == after[role]} for role, row in before.items()]
        _write(directory / "input_manifest.json", {"task_id": task_id, "tool": TOOL, "all_unchanged": True,
                                                   "files": input_rows, "image_membership_and_stat_unchanged": True,
                                                   "images_checked": len(images_before), "image_pixels_hashed": False})
        with (directory / "repair_changes.jsonl").open("x", encoding="utf-8", newline="\n") as stream:
            for change in changes:
                stream.write(json.dumps(change, ensure_ascii=False, allow_nan=False) + "\n")
        _write(directory / "copy_manifest.json", copy_manifest)
        result["summary"] = {**summary, "inputs_unchanged": True, "input_files_hashed": sum(row["exists"] for row in before.values()),
                             "before_verification_task": "before", "after_verification_task": "after" if not refusal else None}
        result["evidence"] = {"before_verification_result": before_report.get("artifacts", {}).get("verification_result"),
                              "before_verification_output_root": before_config["output_root"],
                              "source_hashes": {role: row["sha256"] for role, row in before.items() if role.startswith(("raw/", "splits/"))},
                              "production_geometry_sha256": before["production_geometry"]["sha256"]}
        result["artifacts"] = {key: str(directory / filename) for key, filename in FILES.items()}
        result["status"], result["finished_at"] = "completed", _timestamp()
        _event(directory, stage, "passed")
        stage = "artifact_publication"
        if copy_manifest["copy_root"] is not None:
            root = Path(copy_manifest["copy_root"])
            expected_files = {row["relative_path"] for row in copy_manifest["files"]}
            actual_files = {path.relative_to(root).as_posix() for path in root.rglob("*")
                            if path.is_file() and not path.relative_to(root).as_posix().startswith("images/")}
            if actual_files != expected_files:
                raise ValueError("Copy membership changed before publication")
            for row in copy_manifest["files"]:
                path = verifier._safe(root / row["relative_path"], root)
                if str(path) != row["path"] or _sha256(path) != row["sha256"] or path.stat().st_size != row["size_bytes"]:
                    raise ValueError("Copy hash/size changed before publication: " + row["relative_path"])
            for row in copy_manifest["images"]:
                if not os.path.samefile(root / row["relative_path"], row["source_path"]):
                    raise ValueError("Image membership no longer uses the recorded hard link")
            if get_task_status(after_config, "after").get("summary", {}).get("verification_status") != "passed":
                raise ValueError("Independent verification completion chain changed before publication")
        _event(directory, stage, "ready", repair_status=summary["repair_status"], completion_published_last=True)
        _write(directory / "repair_result.json", result)
        records = [_artifact_record(directory / filename) for key, filename in FILES.items() if key not in ("artifact_manifest", "completion")]
        _write(directory / "artifact_manifest.json", {"task_id": task_id, "tool": TOOL, "status": "completed", "files": records})
        for record in records:
            if _artifact_record(Path(record["path"])) != record:
                raise ValueError("Repair artifact changed during publication: " + record["name"])
        _write(directory / "completion.json", {"task_id": task_id, "tool": TOOL, "status": "completed",
                                                "finished_at": result["finished_at"], "artifact_manifest": str(directory / "artifact_manifest.json"),
                                                "artifact_manifest_sha256": _sha256(directory / "artifact_manifest.json"),
                                                "artifacts_sha256": {row["name"]: row["sha256"] for row in records}})
        return result
    except Exception as error:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"] = [{"stage": stage, "type": type(error).__name__, "message": str(error)}]
        if directory is not None:
            _event(directory, stage, "failed", error=str(error))
            _write(directory / "failure.json", result)
        return result
