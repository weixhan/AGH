"""Independent box scoring for a frozen validation-set inference comparison.

No library matching/AP implementation is imported. AP uses confidence-ordered,
same-class greedy matching and the precision envelope at 101 recall levels.
It can differ from Ultralytics metrics; historical library numbers are not a
direct baseline for this evaluator. Predictions must already be in original
image coordinates and include the same inference confidence floor in both arms.
"""
from __future__ import annotations

from bisect import bisect_left
import hashlib
import json
import math
import random
from statistics import fmean


IOU_THRESHOLDS = tuple(round(0.50 + index * 0.05, 2) for index in range(10))
BOOTSTRAP_SEED = 42
BOOTSTRAP_RESAMPLES = 2000
SMALL_AREA = 32 ** 2


def _finite(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number")
    return float(value)


def _names(class_names):
    if isinstance(class_names, (list, tuple)):
        names = dict(enumerate(class_names))
    elif isinstance(class_names, dict):
        names = {}
        for key, value in class_names.items():
            if isinstance(key, bool) or not (isinstance(key, int) or isinstance(key, str) and key.isdecimal()):
                raise ValueError("class_names keys must be nonnegative integer class IDs")
            identifier = int(key)
            if identifier in names:
                raise ValueError("class_names has duplicate numeric IDs")
            names[identifier] = value
    else:
        raise ValueError("class_names must be a list or class-ID dictionary")
    if not names or any(key < 0 or not isinstance(value, str) or not value for key, value in names.items()):
        raise ValueError("class_names must contain nonempty names and nonnegative IDs")
    return dict(sorted(names.items()))


def _box(item, names, prediction):
    identifier = item.get("class_id")
    if isinstance(identifier, bool) or not isinstance(identifier, int) or identifier not in names:
        raise ValueError("box class_id is not an integer in class_names")
    coordinates = item.get("xyxy")
    if not isinstance(coordinates, (list, tuple)) or len(coordinates) != 4:
        raise ValueError("xyxy must contain four coordinates")
    coordinates = tuple(_finite(value, "box coordinate") for value in coordinates)
    x1, y1, x2, y2 = coordinates
    if x2 <= x1 or y2 <= y1:
        raise ValueError("box must have positive width and height")
    normalized = {"class_id": identifier, "xyxy": coordinates}
    if prediction:
        confidence = _finite(item.get("confidence"), "confidence")
        if not 0 <= confidence <= 1:
            raise ValueError("confidence must be in [0, 1]")
        normalized["confidence"] = confidence
    return normalized


def _records(records, names):
    if not isinstance(records, list):
        raise ValueError("records must be a list")
    normalized, seen = [], set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("each image record must be a dictionary")
        image_id = record.get("image_id")
        if not isinstance(image_id, str) or not image_id or image_id in seen:
            raise ValueError("image_id must be a unique nonempty string")
        seen.add(image_id)
        width, height = (_finite(record.get(field), field) for field in ("width", "height"))
        if width <= 0 or height <= 0:
            raise ValueError("image dimensions must be positive")
        lists = {}
        for key in ("ground_truth", "predictions"):
            values = record.get(key)
            if not isinstance(values, list) or any(not isinstance(item, dict) for item in values):
                raise ValueError(f"{key} must be a list of box dictionaries")
            lists[key] = [_box(item, names, key == "predictions") for item in values]
        normalized.append({"image_id": image_id, "width": width, "height": height, **lists})
    return sorted(normalized, key=lambda record: record["image_id"])


def _area(box):
    x1, y1, x2, y2 = box
    return (x2 - x1) * (y2 - y1)


def _iou(left, right):
    intersection = max(0.0, min(left[2], right[2]) - max(left[0], right[0])) * max(
        0.0, min(left[3], right[3]) - max(left[1], right[1]))
    return intersection / (_area(left) + _area(right) - intersection)


def _match(predictions, candidates, threshold):
    """One GT can be consumed once; higher-confidence predictions act first."""
    consumed, matches = {}, []
    for image_id, prediction_index, _ in predictions:
        used = consumed.setdefault(image_id, set())
        selected, largest = None, -1.0
        for gt_index, overlap in candidates[(image_id, prediction_index)]:
            if gt_index not in used and overlap >= threshold and overlap > largest:
                selected, largest = gt_index, overlap
        matches.append(selected)
        if selected is not None:
            used.add(selected)
    return matches


def _ap(matches, gt_count):
    if not gt_count:
        return None
    if not matches:
        return 0.0
    precision, recall, true_positives = [], [], 0
    for count, matched in enumerate(matches, 1):
        true_positives += int(matched is not None)
        precision.append(true_positives / count)
        recall.append(true_positives / gt_count)
    for index in range(len(precision) - 2, -1, -1):
        precision[index] = max(precision[index], precision[index + 1])
    sampled = []
    for index in range(101):
        position = bisect_left(recall, index / 100)
        sampled.append(precision[position] if position < len(precision) else 0.0)
    return fmean(sampled)


def _rates(tp, fp, fn):
    return {"tp": tp, "fp": fp, "fn": fn,
            "precision": tp / (tp + fp) if tp + fp else 0.0,
            "recall": tp / (tp + fn) if tp + fn else 0.0}


def score_detections(records, class_names, conf_threshold=0.25, match_iou=0.5):
    """Score raw predictions, separately from the fixed confidence operating point.

    AP averages only classes with at least one GT. For an entirely GT-free set,
    AP is reported as 0 with ``ap_defined=False``; no accuracy claim is possible.
    Empty denominators produce 0 for aggregate P/R and null for small-object and
    normal-image rates. No NMS, clipping, confidence-floor changes or ignored GT
    are applied by this evaluator.
    """
    confidence = _finite(conf_threshold, "conf_threshold")
    overlap = _finite(match_iou, "match_iou")
    if not 0 <= confidence <= 1 or not 0 < overlap <= 1:
        raise ValueError("conf_threshold must be in [0,1] and match_iou in (0,1]")
    names = _names(class_names)
    records = _records(records, names)
    rows = {record["image_id"]: {
        "image_id": record["image_id"], "gt": len(record["ground_truth"]),
        "predictions": sum(pred["confidence"] >= confidence for pred in record["predictions"]),
        "tp": 0, "fp": 0, "fn": len(record["ground_truth"]),
        "small_gt": sum(_area(gt["xyxy"]) < SMALL_AREA for gt in record["ground_truth"]),
        "small_fn": sum(_area(gt["xyxy"]) < SMALL_AREA for gt in record["ground_truth"]),
    } for record in records}
    per_class = []
    for class_id, class_name in names.items():
        predictions, candidates, gt_count, class_small_gt, images_with_class = [], {}, 0, 0, 0
        lookup = {}
        for record in records:
            image_id = record["image_id"]
            gt = [(index, truth) for index, truth in enumerate(record["ground_truth"])
                  if truth["class_id"] == class_id]
            gt_count += len(gt)
            images_with_class += bool(gt)
            class_small_gt += sum(_area(truth["xyxy"]) < SMALL_AREA for _, truth in gt)
            lookup[image_id] = record["ground_truth"]
            for prediction_index, prediction in enumerate(record["predictions"]):
                if prediction["class_id"] == class_id:
                    predictions.append((image_id, prediction_index, prediction["confidence"]))
                    candidates[(image_id, prediction_index)] = [
                        (index, _iou(prediction["xyxy"], truth["xyxy"])) for index, truth in gt]
        # Image ID and input prediction index make confidence ties reproducible.
        predictions.sort(key=lambda entry: (-entry[2], entry[0], entry[1]))
        ap = {f"{threshold:.2f}": _ap(_match(predictions, candidates, threshold), gt_count)
              for threshold in IOU_THRESHOLDS}
        selected_predictions = [entry for entry in predictions if entry[2] >= confidence]
        matches = _match(selected_predictions, candidates, overlap)
        tp, small_tp = 0, 0
        for (image_id, _, _), matched in zip(selected_predictions, matches):
            row = rows[image_id]
            if matched is None:
                row["fp"] += 1
            else:
                tp += 1
                row["tp"] += 1
                row["fn"] -= 1
                if _area(lookup[image_id][matched]["xyxy"]) < SMALL_AREA:
                    small_tp += 1
                    row["small_fn"] -= 1
        per_class.append({"class_id": class_id, "class_name": class_name,
                          "gt": gt_count, "images_with_class": images_with_class,
                          "predictions": len(predictions), "ap_defined": bool(gt_count),
                          "AP50": ap["0.50"], "AP50_95": fmean(ap.values()) if gt_count else None,
                          "ap_by_iou": ap,
                          "operating_point": {**_rates(tp, len(matches) - tp, gt_count - tp),
                                              "predictions": len(matches), "small_gt": class_small_gt,
                                              "small_fn": class_small_gt - small_tp}})
    per_image = []
    for row in rows.values():
        row.update(_rates(row["tp"], row["fp"], row["fn"]))
        per_image.append(row)
    totals = {key: sum(row[key] for row in per_image) for key in ("tp", "fp", "fn", "small_gt", "small_fn")}
    normal = [row for row in per_image if row["gt"] == 0]
    normal_fp = sum(row["fp"] > 0 for row in normal)
    included = [entry for entry in per_class if entry["ap_defined"]]
    canonical = [{"image_id": record["image_id"], "width": record["width"], "height": record["height"],
                  "ground_truth": sorted(record["ground_truth"], key=lambda gt: (gt["class_id"], gt["xyxy"]))}
                 for record in records]
    signature = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":"),
                                          ensure_ascii=False, allow_nan=False).encode("utf-8")).hexdigest()
    return {
        "schema_version": "independent-detection-metrics-v1",
        "dataset_signature": signature,
        "counts": {"images": len(records), "gt": sum(row["gt"] for row in per_image),
                   "predictions": sum(len(record["predictions"]) for record in records)},
        "mAP50": fmean(entry["AP50"] for entry in included) if included else 0.0,
        "mAP50_95": fmean(entry["AP50_95"] for entry in included) if included else 0.0,
        "ap_defined": bool(included), "ap_classes": [entry["class_id"] for entry in included],
        "per_class": per_class,
        "operating_point": {
            "confidence_threshold": confidence, "iou_threshold": overlap,
            **_rates(totals["tp"], totals["fp"], totals["fn"]),
            "predictions": totals["tp"] + totals["fp"],
            "precision_defined": bool(totals["tp"] + totals["fp"]),
            "recall_defined": bool(totals["tp"] + totals["fn"]),
            "small_gt": totals["small_gt"], "small_fn": totals["small_fn"],
            "small_recall": (totals["small_gt"] - totals["small_fn"]) / totals["small_gt"]
                            if totals["small_gt"] else None,
            "normal_images": len(normal), "normal_images_with_false_positives": normal_fp,
            "normal_image_fp_rate": normal_fp / len(normal) if normal else None,
        },
        "per_image": per_image,
        "protocol": {"evaluator": "independent-detection-metrics-v1",
                     "matching": "confidence_descending_same_class_greedy_max_available_iou",
                     "confidence_ties": "image_id_then_input_prediction_index",
                     "iou_thresholds": list(IOU_THRESHOLDS), "ap_recall_points": 101,
                     "ap_average": "macro_over_classes_with_ground_truth",
                     "small_object_area_lt": SMALL_AREA, "coordinate_space": "original_image_xyxy"},
        "limitations": [
            "Independent matching and 101-point AP can differ from Ultralytics; historical library metrics are not directly comparable.",
            "AP uses every supplied prediction; inference confidence floor, NMS and max_det must be frozen equally outside this scorer.",
            "Boxes are neither clipped nor suppressed. Small GT means original-image area < 32^2 pixels.",
            "No GT-free classes enter mean AP. Entirely GT-free sets have ap_defined=false and numerical AP=0.",
        ],
    }


def _percentile(sorted_values, fraction):
    position = (len(sorted_values) - 1) * fraction
    lower, upper = math.floor(position), math.ceil(position)
    return sorted_values[lower] + (sorted_values[upper] - sorted_values[lower]) * (position - lower)


def compare_scores(score640, score960):
    """Describe a paired validation comparison without claiming general superiority.

    The caller freezes one weight, preprocessing/inference settings and validation
    split. This function additionally rejects changed GT, class labels or scorer
    definitions. Bootstrap resamples GT-containing images, not physical groups.
    """
    if score640.get("schema_version") != "independent-detection-metrics-v1" or score960.get("schema_version") != score640.get("schema_version"):
        raise ValueError("both scores must use independent-detection-metrics-v1")
    if score640.get("dataset_signature") != score960.get("dataset_signature"):
        raise ValueError("comparison requires identical images, dimensions and ground truth")
    if score640.get("protocol") != score960.get("protocol"):
        raise ValueError("comparison requires identical metric protocols")
    if [(entry["class_id"], entry["class_name"]) for entry in score640["per_class"]] != [
            (entry["class_id"], entry["class_name"]) for entry in score960["per_class"]]:
        raise ValueError("comparison requires identical class names")
    left, right = score640["operating_point"], score960["operating_point"]
    if any(left[key] != right[key] for key in ("confidence_threshold", "iou_threshold")):
        raise ValueError("comparison requires identical operating-point thresholds")
    left_rows = {row["image_id"]: row for row in score640["per_image"]}
    right_rows = {row["image_id"]: row for row in score960["per_image"]}
    if left_rows.keys() != right_rows.keys() or any(left_rows[key]["gt"] != right_rows[key]["gt"]
                                                  for key in left_rows):
        raise ValueError("comparison requires one paired row per identical image")
    deltas = [right_rows[key]["recall"] - left_rows[key]["recall"] for key in sorted(left_rows)
              if left_rows[key]["gt"] > 0]
    rng = random.Random(BOOTSTRAP_SEED)
    samples = sorted(fmean(rng.choices(deltas, k=len(deltas))) for _ in range(BOOTSTRAP_RESAMPLES)) if deltas else []
    delta_metrics = {key: score960[key] - score640[key] for key in ("mAP50", "mAP50_95")}
    delta_metrics.update({key: right[key] - left[key] if left[key] is not None and right[key] is not None else None
                          for key in ("precision", "recall", "small_recall", "normal_image_fp_rate")})
    return {
        "schema_version": "validation-comparison-v1", "scope": "validation_only_same_weight",
        "delta_direction": "960_minus_640", "delta_960_minus_640": delta_metrics,
        "paired_recall": {"eligible_images": len(deltas), "mean_delta": fmean(deltas) if deltas else None,
                          "ci95": [_percentile(samples, .025), _percentile(samples, .975)] if samples else None,
                          "seed": BOOTSTRAP_SEED, "resamples": BOOTSTRAP_RESAMPLES,
                          "unit": "image_with_at_least_one_gt",
                          "note": "Macro mean of paired per-image recall differences at the fixed confidence/IoU point; excludes normal images and is not AP uncertainty."},
        "limitations": [
            "Validation-only descriptive comparison; do not extrapolate to test data, deployment or stable superiority.",
            "One frozen weight does not establish training-resolution effects or seed stability; the caller must verify the weight hash and inference controls.",
            "Image bootstrap assumes independent images; correlated cable/physical-anomaly groups are not handled and confidence intervals can be optimistic.",
            "Independent matching/AP can differ from Ultralytics; historical library metrics must not be directly mixed with these scores.",
        ],
    }
