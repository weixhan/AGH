"""Frozen full-context plus fixed-tile validation experiment and sealed reader."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

from .audit import _artifact_record, _atomic_text, _configured_paths, _sha256, _timestamp

TOOL = "compare_validation_slices"
PROTOCOL_PATH = Path(__file__).resolve().parents[1] / "fixtures" / "sliced_protocol.json"
FROZEN_PROTOCOL_SHA256 = "14e59c73d0e08728a6ec0aed5cb243926440cfed477d189c756f166e5c9785fe"
FILES = {"protocol": "protocol.json", "inputs": "inputs.json", "events": "events.jsonl",
         "observations": "pass_observations.jsonl", "predictions": "predictions_sliced.jsonl",
         "fusion": "fusion_details.jsonl", "context_reuse": "context_reuse.json", "environment": "environment.json",
         "budget": "budget.json", "metrics_baseline": "metrics_baseline.json", "metrics_sliced": "metrics_sliced.json",
         "comparison": "sliced_comparison.json", "decision": "decision.json", "result": "sliced_result.json",
         "report": "sliced_report.md", "checkpoint_index": "checkpoint_index.json",
         "journal": "checkpoint_journal.jsonl", "budget_snapshot": "budget_snapshot.json",
         "worker_request": "worker_request.json", "worker_receipt": "worker_receipt.json",
         "manifest": "artifact_manifest.json", "completion": "completion.json"}
EXECUTION_SOURCE_ROLES = ("sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
                          "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier")
LIMITATIONS = [
    "This joint crop/context/fusion validation strategy does not isolate a pure resolution effect.",
    "The reference sealed Python/Torch/Ultralytics/CUDA/cuDNN/GPU and effective options; historical OpenCV version, actual input dtype and dependency callable-source hashes are unavailable. Current sources/input dtype and all 640 fresh contexts are checked.",
    "A successful execution and a candidate satisfying metric constraints are distinct outcomes.",
    "Frame-correlated validation evidence is not held-out test gain, deployment readiness or proof of research autonomy.",
    "Checkpoint recovery is a business-step mechanism; AGH transport reconnection is separate.",
]


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _write(path, value):
    _atomic_text(Path(path), json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _jsonl(path, values):
    _atomic_text(Path(path), "".join(json.dumps(v, ensure_ascii=False, allow_nan=False) + "\n" for v in values))


def _rows(path):
    return [json.loads(row) for row in Path(path).read_text(encoding="utf-8").splitlines() if row.strip()]


def _event(directory, stage, status, **details):
    with (directory / FILES["events"]).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"at": _timestamp(), "stage": stage, "status": status, **details}, ensure_ascii=False, allow_nan=False) + "\n")


def _canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _execution_source_sha256(before):
    """Bind durability and execution implementations separately from scientific inputs."""
    return _canonical({role: {"path": before[role]["path"], "sha256": before[role]["sha256"],
                              "size_bytes": before[role]["size_bytes"]} for role in EXECUTION_SOURCE_ROLES})


def _journal_identity(request):
    from .sliced_journal import execution_identity
    return execution_identity({"protocol_sha256": request["protocol_sha256"],
                               "weight_sha256": request["protocol"]["weight_sha256"],
                               "scientific_inputs_sha256": request["scientific_inputs_sha256"],
                               "execution_source_sha256": request["execution_source_sha256"]})


def _equal(left, right):
    """JSON equality with bool distinct from every numeric value."""
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int,float)) and isinstance(right, (int,float)):
        return math.isfinite(left) and math.isfinite(right) and left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_equal(left[k],right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_equal(a,b) for a,b in zip(left,right))
    return left == right


def _protocol():
    if _sha256(PROTOCOL_PATH) != FROZEN_PROTOCOL_SHA256:
        raise ValueError("Frozen sliced protocol bytes changed")
    value = _read(PROTOCOL_PATH)
    required = {"schema_version": 1, "source_task_id": "8d1d6900c7d74c90a29824495684807d",
                "diagnosis_task_id": "diagnosis-d35fab352e614cf7a3bf4c9236987cf8", "split": "val",
                "train_imgsz": 640, "eval_imgsz": 640, "device": "0", "precision": "FP32", "batch": 1,
                "prediction_confidence": .001, "nms_iou": .7, "max_det": 300, "rect": False,
                "augment": False, "agnostic_nms": False, "allow_tf32": False, "quantize": None,
                "global_nms_iou": .7, "global_max_det": 300, "training_performed": False,
                "test_inference_performed": False, "weight_change": False, "automatically_apply_threshold": False,
                "fallback": "fail_without_changing_protocol", "selection_data": "validation_only"}
    for key, expected in required.items():
        if value.get(key) != expected or type(value.get(key)) is not type(expected):
            raise ValueError(f"Frozen sliced protocol differs: {key}")
    return value


def _dependency_sources():
    # Bind installed implementation bytes before any prediction, including the
    # actual OpenCV binary. No dependency settings or cache files are written.
    sources = {}
    for package, relative in (("ultralytics", ("engine/model.py", "engine/predictor.py", "models/yolo/detect/predict.py",
                                            "utils/ops.py", "utils/nms.py", "data/loaders.py")),
                              ("cv2", ("__init__.py",))):
        spec = importlib.util.find_spec(package)
        if spec is None or spec.origin is None:
            raise ImportError(f"Frozen inference dependency missing: {package}")
        root = Path(spec.origin).resolve().parent
        for filename in relative:
            path = root / filename
            if not path.is_file():
                raise ValueError(f"Expected dependency implementation missing: {path}")
            sources[f"dependency/{package}/{filename}"] = path
        if package == "cv2":
            binaries = sorted(root.glob("*.pyd"))
            if not binaries:
                raise ValueError("OpenCV Windows binary is missing")
            for path in binaries:
                sources[f"dependency/cv2/{path.name}"] = path
    return sources


def _load_source(paths, protocol):
    from . import diagnosis_task
    from .task_runtime import _completed_report, DIAGNOSIS_TOOL, COMPARISON_TOOL
    source, sources, before, arms = diagnosis_task._load_source(paths, diagnosis_task._protocol())
    diagnosis = paths["output_root"] / protocol["diagnosis_task_id"]
    _completed_report(diagnosis, protocol["diagnosis_task_id"], DIAGNOSIS_TOOL)
    source_report = _completed_report(source, protocol["source_task_id"], COMPARISON_TOOL)
    decision = _read(diagnosis / "decision.json")
    if decision.get("evidence_id") != protocol["evidence_id"] or decision.get("source_task_id") != protocol["source_task_id"]:
        raise ValueError("Slicing decision source binding differs")
    if decision.get("recommendations", {}).get("next_branch") != "sliced_inference_controlled":
        raise ValueError("Frozen diagnostic evidence did not select the slicing branch")
    artifact_names = ["completion.json", "artifact_manifest.json", *[r["name"] for r in _read(diagnosis / "artifact_manifest.json")["files"]]]
    for name in artifact_names:
        path = (diagnosis / name).resolve()
        if path.parent != diagnosis.resolve():
            raise ValueError("Diagnostic artifact outside its task")
        sources[f"diagnosis_artifact/{name}"] = path
    evidence_paths = {"diagnosis_review": paths["output_root"] / "diagnosis-local-verification.json"}
    for role in protocol["source_evidence_sha256"]:
        if role.startswith("diagnosis/"):
            evidence_paths[role] = diagnosis / role.split("/", 1)[1]
        elif role.startswith("comparison/"):
            evidence_paths[role] = source / role.split("/", 1)[1]
    for role, expected in protocol["source_evidence_sha256"].items():
        if role not in evidence_paths or _sha256(evidence_paths[role]) != expected:
            raise ValueError(f"Pre-registered evidence bytes changed: {role}")
        sources[f"preregistered/{role}"] = evidence_paths[role]
    if _sha256(paths["weights_path"]) != protocol["weight_sha256"]:
        raise ValueError("Frozen weight bytes changed")
    records = arms[640]
    _population(records, protocol)
    sources.update({"sliced_protocol": PROTOCOL_PATH, "sliced_runner": Path(__file__).resolve(),
                    "sliced_worker": Path(__file__).with_name("sliced_worker.py"),
                    "sliced_journal": Path(__file__).with_name("sliced_journal.py"),
                    "sliced_core": Path(__file__).with_name("sliced_inference.py"),
                    "stratified_statistics": Path(__file__).with_name("stratified_statistics.py"),
                    "sliced_independent_verifier": Path(__file__).resolve().parents[1] / "tools" / "verify_sliced_run.py",
                    "sliced_journal_independent_verifier": Path(__file__).resolve().parents[1] / "tools" / "verify_sliced_journal.py",
                    **_dependency_sources()})
    from .resolution_comparison import _snapshot
    before = _snapshot(sources)
    environment = source_report["summary"]["environments"]["640"]
    return source, diagnosis, sources, before, records, environment


def _population(records, protocol):
    observed = {"images": len(records), "gt": sum(len(r["ground_truth"]) for r in records),
                "normal_images": sum(not r["ground_truth"] for r in records),
                "medium_gt": 0, "medium_images": 0}
    ids = [r["image_id"] for r in records]
    if len(set(ids)) != len(ids) or ids != sorted(ids):
        raise ValueError("Duplicate or noncanonical validation image IDs")
    for record in records:
        if record["width"] != protocol["population"]["width"] or record["height"] != protocol["population"]["height"]:
            raise ValueError("Frozen image dimensions changed")
        medium = sum(32**2 <= (g["xyxy"][2]-g["xyxy"][0]) * (g["xyxy"][3]-g["xyxy"][1]) < 96**2 for g in record["ground_truth"])
        observed["medium_gt"] += medium
        observed["medium_images"] += bool(medium)
    if any(observed[k] != protocol["population"][k] for k in observed):
        raise ValueError("Frozen validation population changed")


def _input_recheck(sources, before, directory, task_id, evidence):
    rows = []
    for role, record in before.items():
        current = _artifact_record(sources[role])
        rows.append({"role": role, "path": record["path"], "size_bytes": record["size_bytes"],
                     "sha256_before": record["sha256"], "sha256_after": current["sha256"],
                     "unchanged": current == {k: v for k, v in record.items() if k != "role"}})
    _write(directory / FILES["inputs"], {"task_id": task_id, "files": rows, "all_unchanged": all(r["unchanged"] for r in rows), **evidence})
    if not all(r["unchanged"] for r in rows):
        raise ValueError("Input bytes changed during sliced inference")


def _new_budget(task_started_epoch):
    return {"schema_version": 1, "task_started_epoch": task_started_epoch, "task_started_at": _timestamp(),
            "inference_started_epoch": None, "inference_started_at": None, "inference_finished_epoch": None,
            "inference_finished_at": None, "gpu_seconds": 0., "formal_attempts": [], "warmup_attempts": [],
            "formal_calls": 0, "warmup_calls": 0, "successful_observations": 0, "inference_wall_seconds": 0.,
            "task_wall_seconds": 0., "resumable": True, "resume_chain": [], "wall_segments": []}


def _validate_budget(budget, protocol, observations=None, *, live=False):
    limits = protocol["budgets"]
    formal, warmups = budget["formal_attempts"], budget["warmup_attempts"]
    if budget.get("resumable") is not True or len(formal) > limits["max_formal_calls"] or len(warmups) > limits["max_warmup_calls"]:
        raise ValueError("Budget is exhausted or has unknown device time")
    gpu = 0.
    for collection in (formal, warmups):
        for index, row in enumerate(collection, 1):
            if type(row["call_index"]) is not int or row["call_index"] != index or type(row["pass_id"]) is not int or row["status"] not in ("passed", "failed") or not row.get("utc_finished"):
                raise ValueError("Incomplete/noncanonical call ledger cannot be resumed or completed")
            for key in ("elapsed_seconds", "gpu_seconds"):
                if isinstance(row[key], bool) or not isinstance(row[key], (int, float)) or not math.isfinite(row[key]) or row[key] < 0:
                    raise ValueError("Invalid elapsed/device time in call ledger")
            gpu += row["gpu_seconds"]
    if abs(gpu-budget["gpu_seconds"]) > 1e-9 or gpu > limits["max_gpu_seconds"]:
        raise ValueError("Cumulative GPU ledger differs or exceeds the budget")
    if any(type(budget[k]) is not int for k in ("formal_calls", "warmup_calls", "successful_observations")) or budget["formal_calls"] != len(formal) or budget["warmup_calls"] != len(warmups):
        raise ValueError("Call totals differ from the durable ledger")
    failures = sum(r["status"] == "failed" for r in formal)
    if failures > limits["max_failed_pass_retries"]:
        raise ValueError("Failed-pass retry budget exceeded")
    if budget["inference_wall_seconds"] > limits["max_inference_wall_seconds"] or budget["task_wall_seconds"] > limits["max_task_wall_seconds"]:
        raise ValueError("Recorded wall budget exceeded")
    segments = budget.get("wall_segments")
    if not isinstance(segments, list) or not segments:
        raise ValueError("Missing monotonic execution wall-clock segments")
    for segment in segments:
        if not segment.get("utc_finished"):
            raise ValueError("Unclosed monotonic execution segment")
        for key in ("task_wall_seconds_before", "inference_wall_seconds_before", "monotonic_task_seconds", "monotonic_inference_seconds"):
            if isinstance(segment[key], bool) or not isinstance(segment[key], (int,float)) or not math.isfinite(segment[key]) or segment[key] < 0:
                raise ValueError("Invalid monotonic wall segment")
    if (budget["task_wall_seconds"]+1e-6 < segments[-1]["task_wall_seconds_before"]+segments[-1]["monotonic_task_seconds"]
            or budget["inference_wall_seconds"]+1e-6 < segments[-1]["inference_wall_seconds_before"]+segments[-1]["monotonic_inference_seconds"]):
        raise ValueError("Cumulative wall budget omits its monotonic execution segment")
    if live:
        from .sliced_worker import _check_budget
        _check_budget(budget, protocol)
    if observations is not None:
        successful = {r["call_index"]: r for r in formal if r["status"] == "passed"}
        if len(successful) != len(observations) or budget["successful_observations"] != len(observations):
            raise ValueError("Successful calls differ from unique checkpoint observations")
        for row in observations:
            attempt = successful.get(row["call_index"])
            if type(row["call_index"]) is not int or attempt is None or any(not _equal(attempt[k],row[k]) for k in ("image_id", "pass_id", "elapsed_seconds", "gpu_seconds")):
                raise ValueError("Observation does not bind its successful call ledger row")


def _checkpoint_rows(directory, scientific_identity=None):
    index = _read(directory / FILES["checkpoint_index"])
    seen, observations = set(), []
    for entry in index["checkpoints"]:
        key = (entry["image_id"], entry["pass_id"])
        path = (directory / entry["relative_path"]).resolve()
        if path.parent != (directory / "checkpoints").resolve() or key in seen:
            raise ValueError("Duplicate or escaping checkpoint identity")
        seen.add(key)
        if _sha256(path) != entry["sha256"] or path.stat().st_size != entry["size_bytes"]:
            raise ValueError("Checkpoint hash/size differs; damaged outputs are not silently retried")
        checkpoint = _read(path)
        row = checkpoint["observation"]
        if (checkpoint["observation_sha256"] != _canonical(row) or row["image_id"] != key[0]
                or row["pass_id"] != key[1] or row["call_index"] != entry["call_index"]
                or checkpoint["environment_identity"] != row["environment_identity"]
                or any(not _equal(row[k],v) for k, v in checkpoint["identity"].items())):
            raise ValueError("Checkpoint output and identity bindings differ")
        if scientific_identity is not None and row["scientific_inputs_sha256"] != scientific_identity:
            raise ValueError("Checkpoint source-input identity differs")
        observations.append(row)
    observations.sort(key=lambda r: (r["image_id"], r["pass_id"]))
    return observations


def _resume(paths, previous_id, directory, protocol, before, scientific_identity):
    from .sliced_journal import load_journal
    if not isinstance(previous_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", previous_id):
        raise ValueError("resume_from must be a safe single directory name")
    previous = paths["output_root"] / previous_id
    if (previous / FILES["completion"]).exists() or _read(previous / "failure.json")["status"] != "failed":
        raise ValueError("Only preserved failed tasks may be resumed into a new task directory")
    prior_protocol = _read(previous / FILES["protocol"])
    if any(not _equal(prior_protocol.get(k),v) for k, v in protocol.items()) or prior_protocol["scientific_inputs_sha256"] != scientific_identity:
        raise ValueError("Resume protocol/source snapshot differs")
    prior_inputs = _read(previous / FILES["inputs"])
    expected = {role: (record["path"], record["sha256"]) for role, record in before.items()}
    observed = {r["role"]: (r["path"], r["sha256_before"]) for r in prior_inputs["files"]}
    if observed != expected:
        raise ValueError("Resume input bytes differ from the preserved attempt")
    if not (previous / FILES["journal"]).is_file():
        raise ValueError("Version 1 caches cannot be imported into source-bound version 2 execution")
    prior_request = _read(previous / FILES["worker_request"])
    expected_execution = _execution_source_sha256(before)
    if (type(prior_request.get("execution_io_version")) is not int or prior_request["execution_io_version"] != 2
            or prior_request.get("execution_source_sha256") != expected_execution):
        raise ValueError("Resume execution source/durability version differs")
    identity = _journal_identity(prior_request)
    replay = load_journal(previous, protocol, identity, require_resumable=True)
    observations = _checkpoint_rows(previous, scientific_identity)
    budget = _read(previous / FILES["budget"])
    journal_budget_matches = _equal(budget, replay.budget)
    if replay.status == "running":
        keys = ("formal_attempts", "warmup_attempts", "formal_calls", "warmup_calls", "successful_observations",
                "gpu_seconds", "task_started_epoch", "inference_started_epoch", "resumable", "resume_chain")
        journal_budget_matches = all(_equal(budget[k], replay.budget[k]) for k in keys)
        journal_budget_matches = journal_budget_matches and all(budget[k] >= replay.budget[k] for k in
                                                                ("task_wall_seconds", "inference_wall_seconds"))
    if not journal_budget_matches or not _equal(_read(previous / FILES["checkpoint_index"]), replay.checkpoint_index):
        raise ValueError("Resume full budget/index differ from durable journal replay")
    _validate_budget(budget, protocol, observations, live=True)
    if len(observations) == protocol["budgets"]["successful_observations"] and budget["inference_finished_epoch"] is not None:
        raise ValueError("Completed inference failed later; it requires an artifact-only repair protocol")
    prior_index = _read(previous / FILES["checkpoint_index"])
    (directory / "checkpoints").mkdir()
    for row in prior_index["checkpoints"]:
        shutil.copyfile(previous / row["relative_path"], directory / row["relative_path"])
    shutil.copyfile(previous / FILES["journal"], directory / FILES["journal"])
    budget["resume_chain"].append({"task_id": previous_id, "failure_sha256": _sha256(previous / "failure.json"),
                                   "budget_sha256": _sha256(previous / FILES["budget"]),
                                   "checkpoint_index_sha256": _sha256(previous / FILES["checkpoint_index"]),
                                   "journal_head_sha256": replay.journal_sha256,
                                   "journal_file_sha256": _sha256(previous / FILES["journal"]),
                                   "copied_observations": len(observations)})
    _write(directory / FILES["budget"], budget)
    _write(directory / FILES["checkpoint_index"], prior_index)
    return _read(previous / FILES["environment"]) if (previous / FILES["environment"]).is_file() else None


def _recover_stopped_worker(directory, request, protocol, *, forced=False, elapsed_seconds=0., deadline_seconds=None):
    """Materialize stopped journal evidence, never recreate an unfinished call.

    Only a terminated writer may be inspected this way. A truncated final line
    is retained intact and its valid prefix is exported as nonresumable.
    """
    from .sliced_journal import load_journal, atomic_write_json
    directory = Path(directory)
    try:
        replay = load_journal(directory, protocol, _journal_identity(request), check_published=False,
                              inspection_only_allow_truncated_tail=True)
        budget, index = replay.budget, replay.checkpoint_index
        budget["call_count_known"] = not budget.get("uncertain_journal_tail", False)
        attempts = [*budget["formal_attempts"], *budget["warmup_attempts"]]
        budget["gpu_total_cost_known"] = budget["call_count_known"] and all(
            row.get("status") in ("passed", "failed") and not isinstance(row.get("gpu_seconds"), bool)
            and isinstance(row.get("gpu_seconds"), (int, float)) and math.isfinite(row["gpu_seconds"])
            and row["gpu_seconds"] >= 0 for row in attempts)
    except Exception as error:
        # Damaged complete records have no acceptable reconstructed ledger.
        # Preserve all original journal bytes and explicitly forbid reuse.
        budget = _read(directory / FILES["budget"])
        index = _read(directory / FILES["checkpoint_index"])
        budget.update(resumable=False, call_count_known=False, gpu_total_cost_known=False,
                      journal_replay_error={"type": type(error).__name__, "message": str(error)})
    now = time.time()
    budget["task_wall_seconds"] = max(budget["task_wall_seconds"], now-budget["task_started_epoch"],
                                       request.get("task_monotonic_elapsed_before_worker", 0.)+elapsed_seconds)
    if budget.get("inference_started_epoch") is not None:
        budget["inference_wall_seconds"] = max(budget["inference_wall_seconds"], now-budget["inference_started_epoch"])
    for segment in budget.get("wall_segments", []):
        if segment.get("utc_finished") is None:
            segment.update(utc_finished=_timestamp(),
                           monotonic_task_seconds=max(segment["monotonic_task_seconds"],
                                                      budget["task_wall_seconds"]-segment["task_wall_seconds_before"]),
                           monotonic_inference_seconds=max(segment["monotonic_inference_seconds"],
                                                           budget["inference_wall_seconds"]-segment["inference_wall_seconds_before"]))
    budget["stopped_journal_materialized"] = True
    if forced:
        budget.update(resumable=False, hard_deadline_terminated=True, deadline_seconds=deadline_seconds)
    atomic_write_json(directory / FILES["budget"], budget)
    atomic_write_json(directory / FILES["checkpoint_index"], index)
    return budget


def _run_worker(directory, request, protocol):
    request_path = directory / FILES["worker_request"]
    _write(request_path, request)
    budget = _read(directory / FILES["budget"])
    now = time.time()
    task_remaining = protocol["budgets"]["max_task_wall_seconds"] - max(now-budget["task_started_epoch"], request["task_monotonic_elapsed_before_worker"])
    infer_remaining = protocol["budgets"]["max_inference_wall_seconds"]
    if budget["inference_started_epoch"] is not None:
        infer_remaining -= now-budget["inference_started_epoch"]
    timeout = min(task_remaining, infer_remaining)
    if timeout <= 0:
        raise TimeoutError("Independent worker deadline already expired")
    # No shell, detached console or device/precision fallback is involved.
    with (directory / "worker.log").open("w", encoding="utf-8") as log:
        worker_started = time.perf_counter()
        process = subprocess.Popen([sys.executable, "-B", "-m", "defect_researcher.sliced_worker", str(request_path)],
                                   cwd=str(Path(__file__).resolve().parents[1]), stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            _recover_stopped_worker(directory, request, protocol, forced=True,
                                    elapsed_seconds=time.perf_counter()-worker_started, deadline_seconds=timeout)
            raise TimeoutError("Independent worker hard deadline terminated inference; unknown unfinished GPU cost forbids resume")
    if not (directory / FILES["worker_receipt"]).is_file():
        _recover_stopped_worker(directory, request, protocol, elapsed_seconds=time.perf_counter()-worker_started)
        raise RuntimeError("Stopped inference worker has no receipt; durable journal evidence preserved")
    receipt = _read(directory / FILES["worker_receipt"])
    if process.returncode != 0 or receipt["status"] != "completed":
        raise RuntimeError(f"Frozen inference failed without fallback: {receipt.get('error', receipt)}")
    for key, filename in (("environment_sha256", FILES["environment"]), ("budget_sha256", FILES["budget"]),
                          ("checkpoint_index_sha256", FILES["checkpoint_index"]), ("journal_file_sha256", FILES["journal"])):
        if receipt[key] != _sha256(directory / filename):
            raise ValueError("Worker receipt hash binding differs")


def _assemble(baseline, observations, protocol):
    from .sliced_inference import tiles, map_predictions, fuse_predictions
    lookup = {(r["image_id"], r["pass_id"]): r for r in observations}
    if len(lookup) != len(observations) or len(observations) != protocol["budgets"]["successful_observations"]:
        raise ValueError("Duplicate or incomplete formal observation population")
    sliced, contexts, fusion = [], [], []
    for record in baseline:
        candidates = []
        for tile in tiles(record["width"], record["height"]):
            row = lookup.get((record["image_id"], tile["pass_id"]))
            if row is None or row["crop"] != tile["crop"]:
                raise ValueError("Missing or changed fixed observation")
            globals_ = map_predictions(row["local_predictions"], row["crop"], record["width"], record["height"], row["pass_id"])
            if globals_ != row["global_predictions"]:
                raise ValueError("Observation global coordinates differ from the fixed local mapping")
            candidates.extend(globals_)
            if tile["pass_id"] == 0:
                contexts.append({**record, "predictions": row["local_predictions"]})
        final, trace = fuse_predictions(candidates, protocol["global_nms_iou"], protocol["global_max_det"])
        sliced.append({**record, "predictions": final, "eval_imgsz": 640, "device": "0", "precision": "FP32",
                       "inference_strategy": "full_context_plus_eight_fixed_tiles"})
        fusion.append({"image_id": record["image_id"], "candidate_count": len(candidates), "final_count": len(final), "trace": trace})
    return sliced, contexts, fusion


def _context_reuse(baseline, contexts, protocol, source_hash):
    from .detection_metrics import score_detections
    tolerance = protocol["reference_tolerance"]
    max_confidence = max_coordinate = 0.
    for old, new in zip(baseline, contexts):
        if old["image_id"] != new["image_id"] or len(old["predictions"]) != len(new["predictions"]):
            raise ValueError("reference_reuse_refused: context population/count differs")
        for left, right in zip(old["predictions"], new["predictions"]):
            if left["class_id"] != right["class_id"]:
                raise ValueError("reference_reuse_refused: context class/order differs")
            max_confidence = max(max_confidence, abs(left["confidence"]-right["confidence"]))
            max_coordinate = max(max_coordinate, *[abs(a-b) for a,b in zip(left["xyxy"], right["xyxy"])])
    if max_confidence > tolerance["confidence_abs"] or max_coordinate > tolerance["coordinate_abs"]:
        raise ValueError("reference_reuse_refused: context predictions exceed frozen tolerance")
    names = {int(k): v for k, v in protocol["class_names"].items()}
    metrics = [score_detections(r, names, protocol["operating_point"]["confidence"], protocol["operating_point"]["match_iou"]) for r in (baseline, contexts)]
    maximum_ap = max(abs(metrics[0][key]-metrics[1][key]) for key in ("mAP50", "mAP50_95"))
    for key in ("tp", "fp", "fn", "normal_images", "normal_images_with_false_positives", "normal_image_fp_rate"):
        if metrics[0]["operating_point"][key] != metrics[1]["operating_point"][key]:
            raise ValueError(f"reference_reuse_refused: context operating metric differs: {key}")
    if maximum_ap > tolerance["metric_abs"]:
        raise ValueError("reference_reuse_refused: context AP exceeds frozen tolerance")
    return {"status": "passed", "samples_matched": len(contexts), "count_order_class_equal": True,
            "maximum_confidence_abs_difference": max_confidence, "maximum_coordinate_abs_difference": max_coordinate,
            "metric_abs_difference": maximum_ap, "operating_counts_equal": True,
            "source_predictions_sha256": source_hash, "rtol": 0}


def _summary(analysis, budget, input_files):
    compact = {}
    for arm in ("baseline", "sliced"):
        metric = analysis[f"{arm}_metrics"]
        point = metric["operating_point"]
        compact[arm] = {"mAP50": metric["mAP50"], "mAP50_95": metric["mAP50_95"],
                        **{k: point[k] for k in ("tp", "fp", "fn", "precision", "recall")},
                        "normal_fp_images": point["normal_images_with_false_positives"],
                        "normal_image_fp_rate": point["normal_image_fp_rate"],
                        "normal_fp_boxes": analysis["normal_false_positives"][arm]["fp_boxes"]}
    return {"slicing_status": "passed", "candidate_status": analysis["scientific_decision"]["status"],
            "reference_reused": True, **compact,
            "medium": {"gt": analysis["population"]["medium_gt"], "images": analysis["population"]["medium_images"],
                       **{k: analysis["gains"][k] for k in ("medium_tp_gain", "medium_gain_images", "medium_recovered_gt", "medium_lost_gt")}},
            "failed_gates": analysis["scientific_decision"]["failed_gates"],
            "population": analysis["population"], "gains": analysis["gains"],
            "metrics": {"baseline": {k: analysis["baseline_metrics"][k] for k in ("mAP50", "mAP50_95", "operating_point")},
                        "sliced": {k: analysis["sliced_metrics"][k] for k in ("mAP50", "mAP50_95", "operating_point")}},
            "split": "val", "train_imgsz": 640, "eval_imgsz": 640, "precision": "FP32", "device": "0", "same_weight": True,
            "input_hashes_unchanged": True, "input_files": input_files, "successful_observations": budget["successful_observations"],
            "formal_calls": budget["formal_calls"], "warmup_calls": budget["warmup_calls"], "gpu_seconds": budget["gpu_seconds"],
            "inference_wall_seconds": budget["inference_wall_seconds"], "training_performed": False,
            "test_inference_performed": False, "threshold_changed": False}


def _independent_review(directory, result, output_path, deadline_remaining):
    """Run the separate oracle before publishing identical candidate bytes."""
    if deadline_remaining <= 0:
        raise TimeoutError("Task deadline expired before independent review")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with (directory / "independent_review.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen([sys.executable, "-B", str(Path(__file__).resolve().parents[1] / "tools" / "verify_sliced_run.py"),
                                    str(directory), "--prepublication", "--output", str(output_path)],
                                   cwd=str(Path(__file__).resolve().parents[1]), stdout=log, stderr=subprocess.STDOUT,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        try:
            process.wait(timeout=deadline_remaining)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)
            raise TimeoutError("Total task hard deadline terminated the independent review")
    review = _read(output_path)
    bindings = _review_bindings(directory, result, "completion_candidate.json")
    if process.returncode != 0 or not _review_passed(review,result["task_id"],bindings):
        raise ValueError("Independent prepublication review failed; final completion is forbidden")
    if review.get("task_completion_sha256") != _sha256(directory / "completion_candidate.json") or review.get("prepublication") is not True:
        raise ValueError("Independent review did not bind the exact prepublication candidate")
    return review


def _review_bindings(directory, result, marker_name):
    """Bind the receipt to current task and both parent marker bytes."""
    protocol = _protocol()
    paths = _configured_paths(result["configuration"])
    return {
        "task_completion_sha256": _sha256(directory / marker_name),
        "task_manifest_sha256": _sha256(directory / FILES["manifest"]),
        "task_protocol_sha256": _sha256(directory / FILES["protocol"]),
        "source_completion_sha256": _sha256(paths["output_root"] / protocol["source_task_id"] / "completion.json"),
        "diagnosis_completion_sha256": _sha256(paths["output_root"] / protocol["diagnosis_task_id"] / "completion.json"),
    }


def _review_passed(review, task_id, bindings):
    checks=review.get("checks")
    wall=review.get("acceptance_total_wall_seconds")
    return (review.get("status") == "passed" and review.get("task_id") == task_id
            and type(review.get("passed_checks")) is int and type(review.get("total_checks")) is int
            and isinstance(checks,dict) and bool(checks)
            and review["passed_checks"] == review["total_checks"] == len(checks)
            and all(value is True for value in checks.values())
            and all(review.get(key) == value for key,value in bindings.items())
            and not isinstance(wall,bool) and isinstance(wall,(int,float)) and math.isfinite(wall) and 0 < wall <= 1800)


def verify_sliced_artifacts(directory: Path, report: dict):
    """Semantic recheck in addition to the generic runtime's sealed-file checks."""
    directory = Path(directory)
    protocol, saved = _protocol(), _read(directory / FILES["protocol"])
    if any(not _equal(saved.get(k),v) for k, v in protocol.items()) or saved["task_id"] != report["task_id"]:
        raise ValueError("Saved sliced protocol differs from the fixed protocol")
    evidence = report["evidence"]
    if (any(not _equal(evidence.get(k),saved.get("task_evidence_id" if k == "evidence_id" else k)) for k in evidence)
            or evidence["protocol_sha256"] != _sha256(PROTOCOL_PATH)):
        raise ValueError("Sliced evidence differs across the sealed contract")
    paths = _configured_paths(report["configuration"])
    source, diagnosis = paths["output_root"] / protocol["source_task_id"], paths["output_root"] / protocol["diagnosis_task_id"]
    for key, path in (("source_completion_sha256", source / "completion.json"), ("source_manifest_sha256", source / "artifact_manifest.json"),
                      ("source_predictions_sha256", source / "predictions_640.jsonl"), ("diagnosis_completion_sha256", diagnosis / "completion.json")):
        if evidence[key] != _sha256(path):
            raise ValueError("Sliced parent evidence SHA differs")
    inputs = _read(directory / FILES["inputs"])
    if inputs.get("all_unchanged") is not True or inputs["task_id"] != report["task_id"]:
        raise ValueError("Sliced input verdict differs")
    entries = inputs["files"]
    if len({r["role"] for r in entries}) != len(entries):
        raise ValueError("Duplicate source-input roles")
    for row in entries:
        record = _artifact_record(Path(row["path"]))
        if (row["unchanged"] is not True or row["sha256_before"] != row["sha256_after"]
                or record["sha256"] != row["sha256_after"] or type(row["size_bytes"]) is not int or record["size_bytes"] != row["size_bytes"]):
            raise ValueError("Sliced input bytes/hash verdict differs")
    scientific_identity = _canonical({r["role"]: {"path": r["path"], "sha256": r["sha256_before"], "size_bytes": r["size_bytes"]} for r in entries})
    if scientific_identity != saved["scientific_inputs_sha256"]:
        raise ValueError("Scientific source snapshot identity differs")
    # A self-consistent, resealed subset of the original input list must not
    # erase data, implementation or parent-chain bindings.
    _, _, required_sources, required_before, _, _ = _load_source(paths, protocol)
    required = {role: (r["path"], r["sha256"], r["size_bytes"]) for role,r in required_before.items()}
    observed_inputs = {r["role"]: (r["path"], r["sha256_before"], r["size_bytes"]) for r in entries}
    if observed_inputs != required:
        raise ValueError("Sliced physical input records differ from the required source chain")
    execution_source = _execution_source_sha256(required_before)
    if (type(saved.get("execution_io_version")) is not int or saved["execution_io_version"] != 2
            or evidence.get("execution_source_sha256") != execution_source):
        raise ValueError("Sliced version 2 execution implementation binding differs")
    checkpoints = _checkpoint_rows(directory, scientific_identity)
    observations = _rows(directory / FILES["observations"])
    if not _equal(checkpoints,observations):
        raise ValueError("Saved observations differ from the durable checkpoints")
    budget = _read(directory / FILES["budget"])
    _validate_budget(budget, protocol, observations)
    from .sliced_journal import load_journal
    request = _read(directory / FILES["worker_request"])
    replay = load_journal(directory, protocol, _journal_identity(request))
    if replay.status != "completed" or not _equal(budget, replay.budget) or not _equal(_read(directory / FILES["checkpoint_index"]), replay.checkpoint_index):
        raise ValueError("Sliced full budget/index are not the completed durable journal replay")
    environment = _read(directory / FILES["environment"])
    expected_options = {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
                        "rect": False, "augment": False, "agnostic_nms": False, "quantize": None, "nms": False}
    if (not _equal(environment["actual_predictor_options"], expected_options)
            or environment["actual_input_dtype"] != "torch.float32" or environment["model_parameters_dtype"] != "torch.float32"
            or environment["actual_input_device"] != "cuda:0" or environment["actual_predictor_device"] != "cuda:0"
            or environment["actual_predictor_fp16"] is not False or environment["tf32_matmul"] is not False
            or environment["tf32_cudnn"] is not False or not _equal(environment["actual_predictor_imgsz"], [640,640])):
        raise ValueError("Sealed environment changed the fixed FP32 inference controls")
    receipt=_read(directory/FILES["worker_receipt"])
    if (receipt.get("status") != "completed" or type(receipt.get("observations")) is not int
            or receipt["observations"] != len(observations)
            or any(receipt.get(key) != _sha256(directory/filename) for key,filename in (
                ("environment_sha256",FILES["environment"]),("budget_sha256",FILES["budget"]),
                ("checkpoint_index_sha256",FILES["checkpoint_index"]), ("journal_file_sha256",FILES["journal"])))
            or type(receipt.get("journal_version")) is not int or receipt["journal_version"] != 2
            or type(receipt.get("journal_events")) is not int or receipt["journal_events"] != replay.journal_events
            or receipt.get("journal_sha256") != replay.journal_sha256):
        raise ValueError("Sealed worker receipt budget/environment/checkpoint binding differs")
    bound_sources = {row["path"]: row for row in entries}
    for source_record in environment["callable_sources"].values():
        row = bound_sources.get(source_record["path"])
        if row is None or row["sha256_before"] != source_record["sha256"] or row["size_bytes"] != source_record["size_bytes"]:
            raise ValueError("Inference callable implementation not bound to the frozen input snapshot")
    for row in observations:
        if (not _equal(row["effective_options"], expected_options) or row["precision"] != "FP32" or row["device"] != "cuda:0"
                or row["actual_input_dtype"] != "torch.float32" or row["actual_input_device"] != "cuda:0"
                or row["model_parameters_dtype"] != "torch.float32"):
            raise ValueError("Observation effective FP32 controls differ")
    baseline = _rows(source / "predictions_640.jsonl")
    _population(baseline, protocol)
    request=_read(directory/FILES["worker_request"])
    if (not _equal(request["protocol"],protocol) or not _equal(request["records"],baseline)
            or type(request.get("execution_io_version")) is not int or request["execution_io_version"] != 2
            or request.get("execution_source_sha256") != execution_source
            or request["scientific_inputs_sha256"] != scientific_identity
            or request["protocol_sha256"] != evidence["protocol_sha256"]
            or Path(request["directory"]).resolve() != directory.resolve()
            or Path(request["weights_path"]).resolve() != paths["weights_path"].resolve()):
        raise ValueError("Sealed worker request source/configuration identity differs")
    import cv2
    import numpy as np
    from .sliced_worker import _pixels
    from .sliced_inference import tiles
    lookup={(r["image_id"],r["pass_id"]):r for r in observations}
    for image_index,record in enumerate(baseline):
        image=cv2.imread(record["image_path"],cv2.IMREAD_COLOR)
        if image is None or list(image.shape) != [record["height"],record["width"],3] or image.dtype != np.uint8:
            raise ValueError("Sealed observation source image cannot be decoded")
        image_hash=_sha256(Path(record["image_path"]))
        decoded_hash=_pixels(image)
        for tile in tiles(record["width"],record["height"]):
            row=lookup.get((record["image_id"],tile["pass_id"]))
            if row is None:
                raise ValueError("Missing source pixel observation")
            x0,y0,x1,y1=tile["crop"]
            if (type(row["image_index"]) is not int or row["image_index"] != image_index
                    or row["source_image_sha256"] != image_hash or row["decoded_image_sha256"] != decoded_hash
                    or row["input_pixels_sha256"] != _pixels(image[y0:y1,x0:x1])
                    or row["orig_shape"] != [y1-y0,x1-x0]):
                raise ValueError("Checkpoint decoded/cropped pixel identity differs from the original source")
    sliced, contexts, fusion = _assemble(baseline, observations, protocol)
    if not _equal(_rows(directory / FILES["predictions"]),sliced) or not _equal(_rows(directory / FILES["fusion"]),fusion):
        raise ValueError("Saved fusion differs from recomputed fixed mapping/NMS")
    reuse = _context_reuse(baseline, contexts, protocol, evidence["source_predictions_sha256"])
    if not _equal(_read(directory / FILES["context_reuse"]),reuse):
        raise ValueError("Saved reference reuse differs from recomputed gate")
    from .sliced_inference import analyze_comparison
    analysis = analyze_comparison(baseline, sliced, protocol)
    for key, analysis_key in (("metrics_baseline", "baseline_metrics"), ("metrics_sliced", "sliced_metrics"), ("comparison", None)):
        expected = analysis if analysis_key is None else analysis[analysis_key]
        if not _equal(_read(directory / FILES[key]),expected):
            raise ValueError("Saved sliced science differs from recomputed observations")
    decision = _read(directory / FILES["decision"])
    if not _equal(decision["scientific_decision"],analysis["scientific_decision"]) or decision["evidence_id"] != evidence["evidence_id"]:
        raise ValueError("Saved sliced decision source/science differs")
    summary = {k:v for k,v in report["summary"].items() if k not in ("total_task_wall_seconds","total_task_wall_seconds_recorded_at")}
    if not _equal(summary,_summary(analysis, budget, len(entries))):
        raise ValueError("Saved sliced summary differs from the sealed evidence")
    total = report["summary"]["total_task_wall_seconds"]
    if (isinstance(total,bool) or not isinstance(total,(int,float)) or not math.isfinite(total)
            or total < budget["task_wall_seconds"] or total > protocol["budgets"]["max_task_wall_seconds"]
            or report["summary"].get("total_task_wall_seconds_recorded_at") != "before_independent_review"):
        raise ValueError("Saved total task wall budget differs")
    if (directory / FILES["completion"]).is_file():
        review = _read(Path(evidence["independent_verification_path"]))
        bindings = _review_bindings(directory, report, FILES["completion"])
        if (not _review_passed(review,report["task_id"],bindings) or review.get("prepublication") is not True
                or review.get("task_completion_sha256") != _sha256(directory / FILES["completion"])
                or (directory / "completion_candidate.json").read_bytes() != (directory / FILES["completion"]).read_bytes()):
            raise ValueError("Final marker lacks its exact independent prepublication acceptance")


def run_sliced_comparison(configuration, task_id=None, *, resume_from=None):
    task_started = time.time()
    task_monotonic_started = time.perf_counter()
    task_id = task_id or f"sliced-{uuid.uuid4().hex}"
    result = {"task_id": task_id, "tool": TOOL, "status": "running", "started_at": _timestamp(), "finished_at": None,
              "configuration": {}, "summary": {}, "evidence": {}, "artifacts": {}, "errors": [], "limitations": list(LIMITATIONS)}
    directory, stage = None, "configuration"
    try:
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name")
        paths = _configured_paths(configuration)
        result["configuration"] = {k: str(v) for k,v in paths.items()}
        destination = paths["output_root"] / task_id
        destination.mkdir(parents=True, exist_ok=False)
        directory = destination
        protocol = _protocol()
        _event(directory, stage, "passed")
        stage = "source_evidence_validation"
        source, diagnosis, sources, before, baseline, source_environment = _load_source(paths, protocol)
        scientific_identity = _canonical({role: {"path": r["path"], "sha256": r["sha256"], "size_bytes": r["size_bytes"]} for role,r in before.items()})
        execution_source = _execution_source_sha256(before)
        result["evidence"] = {"source_task_id": protocol["source_task_id"], "diagnosis_task_id": protocol["diagnosis_task_id"],
                              "source_completion_sha256": _sha256(source / "completion.json"), "source_manifest_sha256": _sha256(source / "artifact_manifest.json"),
                              "source_predictions_sha256": _sha256(source / "predictions_640.jsonl"),
                              "diagnosis_completion_sha256": _sha256(diagnosis / "completion.json"),
                              "protocol_sha256": _sha256(PROTOCOL_PATH), "evidence_id": f"sliced:{task_id}:hybrid640",
                              "execution_source_sha256": execution_source,
                              "independent_verification_path": str(paths["output_root"] / "sliced-prepublication" / f"{task_id}.json")}
        # Parent evidence_id is preserved; this task's evidence gets a distinct
        # key so the frozen scientific protocol is still byte-verifiable.
        _write(directory / FILES["protocol"], {**protocol, **{k:v for k,v in result["evidence"].items() if k != "evidence_id"},
                                              "task_evidence_id": result["evidence"]["evidence_id"], "task_id": task_id,
                                              "execution_io_version": 2,
                                              "scientific_inputs_sha256": scientific_identity, "image_ids": [r["image_id"] for r in baseline]})
        _input_recheck(sources, before, directory, task_id, result["evidence"])
        resume_environment = None
        if resume_from is None:
            _write(directory / FILES["budget"], _new_budget(task_started))
            _write(directory / FILES["checkpoint_index"], {"schema_version": 1, "checkpoints": []})
        else:
            stage = "checkpoint_resume_validation"
            resume_environment = _resume(paths, resume_from, directory, protocol, before, scientific_identity)
        _event(directory, stage, "passed", input_files=len(before), resume_from=resume_from)
        stage = "frozen_nine_pass_inference"
        request = {"directory": str(directory), "protocol": protocol, "records": baseline, "weights_path": str(paths["weights_path"]),
                   "protocol_sha256": _sha256(PROTOCOL_PATH), "scientific_inputs_sha256": scientific_identity,
                   "execution_io_version": 2, "execution_source_sha256": execution_source,
                   "reference_environment": source_environment, "resume_environment": resume_environment,
                   "task_monotonic_elapsed_before_worker": _read(directory / FILES["budget"])["task_wall_seconds"]+time.perf_counter()-task_monotonic_started,
                   "image_sha256": {r["image_id"]: _sha256(Path(r["image_path"])) for r in baseline}}
        _run_worker(directory, request, protocol)
        worker_finished_monotonic = time.perf_counter()
        observations = _checkpoint_rows(directory, scientific_identity)
        budget = _read(directory / FILES["budget"])
        _validate_budget(budget, protocol, observations)
        _jsonl(directory / FILES["observations"], observations)
        _event(directory, stage, "passed", successful_observations=len(observations), formal_calls=budget["formal_calls"])
        stage = "context_reference_reuse"
        sliced, contexts, fusion = _assemble(baseline, observations, protocol)
        reuse = _context_reuse(baseline, contexts, protocol, result["evidence"]["source_predictions_sha256"])
        _write(directory / FILES["context_reuse"], reuse)
        _jsonl(directory / FILES["predictions"], sliced)
        _jsonl(directory / FILES["fusion"], fusion)
        _event(directory, stage, "passed", **{k:v for k,v in reuse.items() if k != "status"})
        stage = "independent_metrics"
        from .sliced_inference import analyze_comparison
        analysis = analyze_comparison(baseline, sliced, protocol)
        saved_metrics = _read(source / "metrics_640.json")
        if any(abs(saved_metrics[k]-analysis["baseline_metrics"][k]) > protocol["reference_tolerance"]["metric_abs"] for k in ("mAP50", "mAP50_95")):
            raise ValueError("reference_reuse_refused: independently rescored baseline AP differs")
        _write(directory / FILES["metrics_baseline"], analysis["baseline_metrics"])
        _write(directory / FILES["metrics_sliced"], analysis["sliced_metrics"])
        _write(directory / FILES["comparison"], analysis)
        _write(directory / FILES["decision"], {"evidence_id": result["evidence"]["evidence_id"], "parent_evidence_id": protocol["evidence_id"],
                                               "hypothesis": protocol["hypothesis"], "scientific_decision": analysis["scientific_decision"],
                                               "execution_and_evidence_gates_passed": True, "automatically_applied": False,
                                               "claim_scope": "frozen_validation_candidate_only"})
        _event(directory, stage, "passed", candidate_status=analysis["scientific_decision"]["status"])
        stage = "input_recheck"
        _input_recheck(sources, before, directory, task_id, result["evidence"])
        if max(time.time()-budget["task_started_epoch"], budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic) > protocol["budgets"]["max_task_wall_seconds"]:
            raise TimeoutError("Total task deadline exceeded before publication")
        result["summary"] = _summary(analysis, budget, len(before))
        result["summary"].update(total_task_wall_seconds=max(time.time()-budget["task_started_epoch"],
                                                            budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic),
                                 total_task_wall_seconds_recorded_at="before_independent_review")
        stage = "artifact_semantic_validation"
        verify_sliced_artifacts(directory, result)
        _event(directory, stage, "passed")
        stage = "artifact_publication"
        result["status"], result["finished_at"] = "completed", _timestamp()
        result["timing"] = {"publication_ready_total_task_wall_seconds": max(budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic,
                                                                            time.time()-budget["task_started_epoch"]),
                            "max_task_wall_seconds": protocol["budgets"]["max_task_wall_seconds"],
                            "inference_budget_is_closed_at_worker_finish": True}
        result["artifacts"] = {k: str(directory/name) for k,name in FILES.items()}
        _atomic_text(directory / FILES["report"], "# 固定全图与切片验证对照\n\n任务：`"+task_id+"`。\n\n执行已完成；候选状态：`"+result["summary"]["candidate_status"]+"`。\n\n```json\n"+json.dumps(result["summary"],ensure_ascii=False,indent=2)+"\n```\n\n## 使用限制\n\n"+"\n".join("- "+v for v in [*LIMITATIONS,*protocol["limitations"]])+"\n")
        _event(directory, stage, "ready", completion_published_last=True)
        _write(directory / FILES["result"], result)
        artifacts = [_artifact_record(directory/name) for k,name in FILES.items() if k not in ("manifest","completion")]
        manifest_path = directory / FILES["manifest"]
        _write(manifest_path, {"task_id": task_id, "tool": TOOL, "status": "completed", "files": artifacts, "input_evidence": result["evidence"]})
        for artifact in artifacts:
            if _artifact_record(Path(artifact["path"])) != artifact:
                raise ValueError("Artifact changed before publication")
        if max(time.time()-budget["task_started_epoch"], budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic) > protocol["budgets"]["max_task_wall_seconds"]:
            raise TimeoutError("Total task deadline exceeded during publication")
        candidate = {"task_id": task_id, "tool": TOOL, "status": "completed", "finished_at": result["finished_at"],
                                                "artifact_manifest": str(manifest_path), "artifact_manifest_sha256": _sha256(manifest_path),
                                                "artifacts_sha256": {r["name"]: r["sha256"] for r in artifacts}, **result["evidence"]}
        candidate_path = directory / "completion_candidate.json"
        _write(candidate_path,candidate)
        stage = "independent_prepublication_review"
        remaining = protocol["budgets"]["max_task_wall_seconds"]-max(time.time()-budget["task_started_epoch"],
                                                                   budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic)
        review=_independent_review(directory,result,Path(result["evidence"]["independent_verification_path"]),remaining)
        if max(time.time()-budget["task_started_epoch"], budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic) > protocol["budgets"]["max_task_wall_seconds"]:
            raise TimeoutError("Total task deadline exceeded after independent acceptance; completion forbidden")
        # Same bytes that the independent checker accepted; no post-review edit
        # to an input, artifact, event, budget or candidate is permitted.
        if (any(_artifact_record(Path(a["path"])) != a for a in artifacts)
                or _sha256(manifest_path) != candidate["artifact_manifest_sha256"]
                or _sha256(candidate_path) != review["task_completion_sha256"]):
            raise ValueError("Artifact changed after independent acceptance")
        if max(time.time()-budget["task_started_epoch"], budget["task_wall_seconds"]+time.perf_counter()-worker_finished_monotonic) > protocol["budgets"]["max_task_wall_seconds"]:
            raise TimeoutError("Final artifact hashing exceeded the total deadline; completion forbidden")
        _atomic_text(directory / FILES["completion"],candidate_path.read_text(encoding="utf-8"))
        return result
    except Exception as error:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"].append({"stage": stage, "type": type(error).__name__, "message": str(error)})
        if directory is not None:
            (directory / FILES["completion"]).unlink(missing_ok=True)
            _event(directory, stage, "failed", error_type=type(error).__name__, message=str(error))
            _write(directory / "failure.json", result)
        return result
