"""New full-validation resolution step recovery; original tasks remain immutable.

Registration starts the original clock before setup/audit. Production execution
uses only the real backend, shared ledger and separately implemented verifier.
Python fixture injection always prevents a real parent completion publication.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
import platform
from pathlib import Path
import re
import sys
import time
import uuid
from typing import Callable, Any

from .audit import _artifact_record, _configured_paths, audit_dataset
from .config import load_config
from .geometry_verifier import CATEGORIES, verify_label_geometry
from .resolution_comparison import _protocol, _prepare_inputs, _snapshot, _validate_predictions
from .resolution_recovery_backend_v1 import infer_group, CONTROL_KEYS
from .detection_metrics import score_detections, compare_scores

ROOT = Path(__file__).resolve().parents[1]
TOOL = "verify_full_resolution_step_recovery_v1"
PURPOSE = "full-val-known-cost-second-group-step-recovery-v1"
VERIFIER_PATH = ROOT / "tools" / "verify_resolution_recovery_v1.py"
BUDGETS = {"max_prediction_calls": 3205, "max_formal_calls": 3200,
           "max_warmup_calls": 5, "max_recovery_attempts": 1,
           "max_task_wall_seconds": 1800, "max_gpu_seconds": 300}
STEP_SIZES = {"reference_640": 640, "reference_960": 960, "fault_640": 640,
              "fault_960": 960, "resume_960": 960}
FAULT_RULE = {"step_id": "fault_960", "max_injections": 1,
              "boundary": "after_all_predictions_and_metrics_closed_before_step_completion"}
TOLERANCES = {"xyxy_absolute_pixels": 1e-4, "confidence_absolute": 1e-6,
              "metric_absolute": 1e-10, "relative": 0}
SOURCE_PATHS = (
    "defect_researcher/resolution_recovery_coordinator_v1.py",
    "defect_researcher/resolution_recovery_backend_v1.py",
    "defect_researcher/resolution_recovery_ledger_v1.py",
    "tools/verify_resolution_recovery_v1.py",
    "tools/verify_resolution_run.py", "config/local.json",
    "defect_researcher/resolution_comparison.py", "fixtures/resolution_protocol.json",
    "defect_researcher/detection_metrics.py", "defect_researcher/audit.py",
    "defect_researcher/config.py", "defect_researcher/geometry_verifier.py",
    "defect_researcher/independent_geometry.py",
    "defect_researcher/resolution_research_mcp_v1.py",
    "defect_researcher/resolution_research_mcp_server_v1.py", "run_resolution_research_mcp_v1.py",
    "fixtures/resolution_research_mcp_protocol_v1.json", "tools/resolution_research_scope_guard_v1.mjs",
)
GROUP_FILES = ("predictions.jsonl", "environment.json", "metrics.json", "step_verification.json")
COORDINATION_FILES = {"shared_prediction_writer.lock"}
CALLABLE_PATHS = {"YOLO.predict": "ultralytics/engine/model.py",
                  "BasePredictor.preprocess": "ultralytics/engine/predictor.py",
                  "BasePredictor.inference": "ultralytics/engine/predictor.py",
                  "BasePredictor.setup_source": "ultralytics/engine/predictor.py",
                  "DetectionPredictor.postprocess": "ultralytics/models/yolo/detect/predict.py",
                  "scale_boxes": "ultralytics/utils/ops.py", "NMS": "ultralytics/utils/nms.py"}
DEPENDENCY_SOURCES = {
    "torch": ("torch/__init__.py", "torch/version.py", "torch/_utils.py", "torch/serialization.py",
              "torch/cuda/__init__.py", "torch/nn/modules/module.py", "torch/backends/cuda/__init__.py",
              "torch/backends/cudnn/__init__.py"),
    "ultralytics": ("ultralytics/__init__.py", "ultralytics/cfg/__init__.py", "ultralytics/engine/model.py",
                    "ultralytics/engine/predictor.py", "ultralytics/models/yolo/detect/predict.py",
                    "ultralytics/nn/autobackend.py", "ultralytics/nn/tasks.py", "ultralytics/utils/__init__.py",
                    "ultralytics/utils/ops.py", "ultralytics/utils/nms.py", "ultralytics/data/loaders.py",
                    "ultralytics/data/augment.py"),
    "numpy": ("numpy/__init__.py",), "opencv": ("cv2/__init__.py",)}


@dataclass(frozen=True)
class TestDependencies:
    prepare_inputs: Callable
    audit: Callable
    geometry: Callable
    backend: Callable
    verifier: Callable
    clock: Any = time
    source_paths: Callable | None = None
    fixture_only: bool = True


class InjectedResolutionStepFault(RuntimeError):
    pass


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = item
        return result
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique,
                       parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    canonical(value)
    return value


def write_bytes(path, data):
    """Fully fsynced exclusive NTFS publication; never replace an old file."""
    path = Path(path)
    temporary = path.with_name(path.name + ".writing-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def write(path, value):
    write_bytes(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8") + b"\n")


def _fixture(deps):
    if deps is not None and (type(deps) is not TestDependencies or deps.fixture_only is not True):
        raise ValueError("Only an explicit Python fixture can inject dependencies")
    return deps is not None


def _fresh(rows):
    for row in rows:
        if _artifact_record(Path(row["path"])) != {key: row[key] for key in ("name", "path", "size_bytes", "sha256")}:
            raise ValueError(f"Frozen source/input bytes changed: {row['path']}")


def _dependencies():
    """Locate installed implementation bytes without importing torch or YOLO."""
    distributions = {name: importlib.metadata.distribution(name) for name in ("torch", "ultralytics", "numpy")}
    installed_opencv = []
    for name in ("opencv-python", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless"):
        try:
            installed_opencv.append((name, importlib.metadata.distribution(name)))
        except importlib.metadata.PackageNotFoundError:
            pass
    if len(installed_opencv) != 1:
        raise ValueError("Exactly one OpenCV distribution is required for a frozen runtime")
    opencv_name, distributions["opencv"] = installed_opencv[0]
    packages, files = {}, [Path(sys.executable).resolve(strict=True)]
    patterns = {"torch": r"torch/_C[^/]*\.pyd", "numpy": r"numpy/_core/_multiarray_umath[^/]*\.pyd",
                "opencv": r"cv2/(?:[^/]+/)*cv2[^/]*\.pyd"}
    for name, distribution in distributions.items():
        listed = [value.as_posix() for value in (distribution.files or [])]
        metadata = [value for value in listed if value.endswith((".dist-info/METADATA", ".dist-info/RECORD"))]
        if len(metadata) != 2:
            raise ValueError(f"Installed dependency metadata is incomplete: {name}")
        selected = [*DEPENDENCY_SOURCES[name], *metadata]
        if name in patterns:
            native = [value for value in listed if re.fullmatch(patterns[name], value)]
            if len(native) != 1:
                raise ValueError(f"Installed dependency native entry is ambiguous: {name}")
            selected.extend(native)
        located = [Path(distribution.locate_file(value)).resolve(strict=True) for value in selected]
        if any(not value.is_file() for value in located):
            raise ValueError(f"Installed dependency implementation is missing: {name}")
        files.extend(located)
        packages[name] = {"distribution": opencv_name if name == "opencv" else name,
                          "version": distribution.version,
                          "root": str(Path(distribution.locate_file("")).resolve(strict=True)),
                          "critical_files": [str(value) for value in located]}
    return {"python": platform.python_version(), "python_executable": str(files[0]),
            "packages": packages, "sys_path": list(sys.path)}, files


def _sources(paths, deps, dependency_files=()):
    files = ([Path(value).resolve() for value in deps.source_paths()] if deps and deps.source_paths else
             [ROOT / relative for relative in SOURCE_PATHS]
             + [paths["research_root"] / "cableinspect_geometry.py",
                paths["research_root"] / "数据处理" / "7检查YOLO标注数据.py"]
             + list(dependency_files))
    if len(set(files)) != len(files) or not files:
        raise ValueError("Execution source set is empty or duplicated")
    return [_artifact_record(path) for path in files]


def _root_artifacts(directory):
    # A Windows byte lock denies reads while held; it is coordination, not evidence.
    return [_artifact_record(path) for path in sorted(directory.iterdir())
            if path.is_file() and path.name not in COORDINATION_FILES]


def prepare_task(config, task_id, *, test_dependencies=None):
    """Register exclusively and freeze complete inputs; do not run model or audit."""
    fixture = _fixture(test_dependencies)
    clock = test_dependencies.clock if fixture else time
    started_epoch, started_monotonic = clock.time(), clock.monotonic()
    if type(task_id) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,95}", task_id) is None:
        raise ValueError("A safe new task ID is required")
    if type(config) is not dict or set(config) != set(load_config()):
        raise ValueError("Configuration must contain exactly six trusted paths")
    paths = _configured_paths(config)
    configuration = {key: str(value) for key, value in paths.items()}
    if not fixture and configuration != load_config():
        raise ValueError("Production configuration differs from local trusted configuration")
    directory = paths["output_root"] / task_id
    for key in ("research_root", "dataset_root", "raw_root", "split_dir", "weights_path"):
        protected = paths[key]
        if directory == protected or directory.is_relative_to(protected) or protected.is_relative_to(directory):
            raise ValueError("New recovery output overlaps a protected source")
    paths["output_root"].mkdir(parents=True, exist_ok=True)
    directory.mkdir(exist_ok=False)
    protocol = {**_protocol(), "nms": None, "quantize": None}
    registration = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE,
                    "task_id": task_id, "task_directory": str(directory), "configuration": configuration,
                    "started_epoch": started_epoch, "started_monotonic": started_monotonic,
                    "deadline_epoch": started_epoch + 1800, "deadline_monotonic": started_monotonic + 1800,
                    "budgets": BUDGETS, "protocol_sha256": digest(protocol),
                    "fault_rule": FAULT_RULE, "tolerances": TOLERANCES, "fixture_only": fixture}
    write(directory / "registration.json", registration)
    try:
        _deadline(registration, clock)
        write(directory / "protocol.json", protocol)
        runtime_identity, dependency_files = ({"fixture_only": True}, []) if fixture else _dependencies()
        sources = _sources(paths, test_dependencies, dependency_files)
        source_lock = {"schema_version": 1, "task_id": task_id, "files": sources,
                       "execution_source_sha256": digest(sources), "runtime_identity": runtime_identity,
                       "runtime_identity_sha256": digest(runtime_identity)}
        write(directory / "source_lock.json", source_lock)
        records, input_sources, provenance = (test_dependencies.prepare_inputs(paths, protocol)
                                             if fixture else _prepare_inputs(paths, protocol))
        if len(records) != 640 or len({row["image_id"] for row in records}) != 640:
            raise ValueError("Only complete 640-image input registration is supported")
        before = _snapshot(input_sources)
        identity = {"records": records, "source_files": before, "provenance": provenance}
        inputs = {"schema_version": 1, "task_id": task_id, **identity,
                  "input_identity_sha256": digest(identity)}
        write(directory / "input_manifest.json", inputs)
        ledger_registration = {"budgets": BUDGETS, "image_ids": [row["image_id"] for row in records],
                               "started_epoch": started_epoch, "started_monotonic": started_monotonic}
        write(directory / "ledger_registration.json", ledger_registration)
        _fresh(sources)
        _fresh(list(before.values()))
        _deadline(registration, clock)
        write(directory / "preparation_receipt.json", {
            "schema_version": 1, "task_id": task_id, "status": "prepared",
            "registration_sha256": sha(directory / "registration.json"),
            "protocol_file_sha256": sha(directory / "protocol.json"),
            "source_lock_sha256": sha(directory / "source_lock.json"),
            "input_manifest_sha256": sha(directory / "input_manifest.json"),
            "ledger_registration_sha256": sha(directory / "ledger_registration.json"),
            "fixture_only": fixture, "new_prediction_calls": 0})
        return registration
    except Exception as error:
        write(directory / "preparation_failure.json", {"status": "failed", "task_id": task_id,
                                                       "error_type": type(error).__name__, "error": str(error)})
        raise


def _deadline(registration, clock):
    epoch, mono = clock.time(), clock.monotonic()
    if (not all(type(v) in (int, float) and math.isfinite(v) and v >= 0
                for v in (epoch, mono, registration["started_epoch"], registration["started_monotonic"]))
            or epoch < registration["started_epoch"] or mono < registration["started_monotonic"]
            or epoch >= registration["deadline_epoch"] or mono >= registration["deadline_monotonic"]):
        raise RuntimeError("Original recovery task deadline expired or clock moved backwards")


def _chain(directory, expected_tool=None, binding=None):
    directory = Path(directory).resolve(strict=True)
    marker, manifest = read(directory / "completion.json"), read(directory / "artifact_manifest.json")
    if (marker.get("status") != "completed" or manifest.get("status") != "completed"
            or marker.get("task_id") != manifest.get("task_id")
            or marker.get("tool") != manifest.get("tool")
            or (expected_tool is not None and marker.get("tool") != expected_tool)
            or Path(marker.get("artifact_manifest", "")).resolve() != directory / "artifact_manifest.json"
            or marker.get("artifact_manifest_sha256") != sha(directory / "artifact_manifest.json")):
        raise ValueError("Completed step marker/manifest identity mismatch")
    if binding is not None and (marker.get("binding") != binding or manifest.get("binding") != binding):
        raise ValueError("Completed step input/protocol/source binding changed")
    rows = manifest.get("files")
    if type(rows) is not list or not rows or len({row.get("name") for row in rows}) != len(rows):
        raise ValueError("Completed step artifact set is empty or duplicated")
    for row in rows:
        path = Path(row["path"]).resolve(strict=True)
        if path.parent != directory or path.name != row.get("name") or _artifact_record(path) != row:
            raise ValueError("Completed step artifact path/hash changed")
    if marker.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
        raise ValueError("Completed step exact file set changed")
    last = (directory / "completion.json").stat().st_mtime_ns
    if any(last < (directory / name).stat().st_mtime_ns for name in
           ["artifact_manifest.json", *[row["name"] for row in rows]]):
        raise ValueError("Step completion was not published last")
    return {"completion": _artifact_record(directory / "completion.json"),
            "manifest": _artifact_record(directory / "artifact_manifest.json"), "files": rows}


def _snapshot_fault(directory):
    files = []
    for relative in ("fault", "groups/fault_640", "groups/fault_960"):
        root = directory / relative
        for path in sorted(root.rglob("*")):
            if path.is_file():
                if not path.resolve().is_relative_to(directory.resolve()):
                    raise ValueError("Fault evidence escaped the new task")
                files.append({"relative_path": path.relative_to(directory).as_posix(), **_artifact_record(path)})
    return {"schema_version": 1, "files": files, "tree_sha256": digest(files)}


def _environment(environment, imgsz, fixture):
    if type(environment) is not dict:
        raise ValueError("Backend environment must be a dictionary")
    if (environment.get("fixture_only") is not fixture
            or environment.get("real_detector_used") is not (not fixture)):
        raise ValueError("Fixture backend cannot be accepted as real detector execution")
    expected = {"imgsz": imgsz, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
                "rect": False, "augment": False, "agnostic_nms": False,
                "quantize": None, "nms": None, "device": "0"}
    actual = environment.get("actual_predictor_options")
    if type(actual) is not dict or set(actual) != set(CONTROL_KEYS):
        raise ValueError("Effective backend controls are missing or broadened")
    for key, value in expected.items():
        if type(actual[key]) is not type(value) or actual[key] != value:
            raise ValueError(f"Effective backend control changed: {key}")
    required = {"device": "0", "precision": "FP32", "actual_predictor_fp16": False,
                "actual_predictor_device": "cuda:0", "actual_input_device": "cuda:0",
                "actual_input_dtype": "torch.float32", "model_parameters_dtype": "torch.float32",
                "tf32_matmul": False, "tf32_cudnn": False, "cudnn_benchmark": False,
                "cudnn_deterministic": True, "prediction_entry_calls": 641, "formal_calls": 640,
                "warmup_calls": 1, "warmup_images": 1, "actual_current_cuda_device": 0,
                "prediction_entry": "YOLO.predict"}
    for key, value in required.items():
        if type(environment.get(key)) is not type(value) or environment[key] != value:
            raise ValueError(f"Actual backend evidence changed or missing: {key}")
    if environment.get("actual_predictor_imgsz") != [imgsz, imgsz]:
        raise ValueError("Actual square inference resolution changed")
    return environment


def _environment_sources(environment, lock, fixture):
    runtime = lock["runtime_identity"]
    if fixture:
        if runtime != {"fixture_only": True}:
            raise ValueError("Fixture runtime registration changed")
        return
    files = {row["path"]: row for row in lock["files"]}
    for key, expected in {"python": runtime["python"], "python_executable": runtime["python_executable"],
                          "torch": runtime["packages"]["torch"]["version"],
                          "ultralytics": runtime["packages"]["ultralytics"]["version"]}.items():
        if type(environment.get(key)) is not str or environment[key] != expected:
            raise ValueError(f"Actual runtime differs from preregistered dependency: {key}")
    backend_path = str(Path(__file__).with_name("resolution_recovery_backend_v1.py").resolve())
    if environment.get("backend_source") != files.get(backend_path):
        raise ValueError("Actual production backend differs from its frozen source")
    callables = environment.get("callable_sources")
    if type(callables) is not dict or set(callables) != set(CALLABLE_PATHS):
        raise ValueError("Actual Ultralytics callable source coverage differs")
    package_root = Path(runtime["packages"]["ultralytics"]["root"])
    for name, relative in CALLABLE_PATHS.items():
        expected = files.get(str((package_root / relative).resolve()))
        if expected is None or callables[name] != expected:
            raise ValueError(f"Actual inference callable source differs: {name}")


def _load_verifier():
    spec = importlib.util.spec_from_file_location("_resolution_recovery_independent_verifier", VERIFIER_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.verify


def _task_binding(directory, registration, inputs, lock):
    return {"task_id": registration["task_id"], "registration_sha256": sha(directory / "registration.json"),
            "input_identity_sha256": inputs["input_identity_sha256"],
            "protocol_sha256": registration["protocol_sha256"],
            "execution_source_sha256": lock["execution_source_sha256"]}


def _gate_chain(directory, tool, configuration, registration, fixture):
    result_name = "audit_result.json" if tool == "audit_dataset" else "verification_result.json"
    chain = _chain(directory, tool)
    result = read(Path(directory) / result_name)
    if result.get("task_id") != "task" or result.get("configuration") != configuration:
        raise ValueError("New audit/geometry gate belongs to a different task or configuration")
    if not fixture:
        expected_files = ({"dataset_check.json", "val_accessibility.json", "checker.log", "events.jsonl", "audit_result.json"}
                          if tool == "audit_dataset" else
                          {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"})
        if {row["name"] for row in chain["files"]} != expected_files:
            raise ValueError("New full audit/geometry gate detail file population differs")
        for key in ("started_at", "finished_at"):
            moment = datetime.fromisoformat(result[key].replace("Z", "+00:00"))
            if moment.tzinfo is None or not registration["started_epoch"] <= moment.timestamp() < registration["deadline_epoch"]:
                raise ValueError("New gate execution escaped the original task clock")
    if tool == "audit_dataset":
        if result.get("status") != "completed" or result.get("summary", {}).get("checker_status") != "passed":
            raise ValueError("New audit did not pass")
    elif (result.get("status") != "completed" or result.get("summary", {}).get("verification_status") != "passed"
          or result["summary"].get("independent_geometry_verification") is not True):
        raise ValueError("New independent geometry gate did not pass")
    return chain


def run_preflight(taskdir, *, test_dependencies=None):
    """Run new audit/geometry once, keeping the already registered task clock."""
    return _execute(taskdir, phase="preflight", test_dependencies=test_dependencies)


def run_until_fault(taskdir, *, test_dependencies=None):
    """Stop after the registered known-cost failure; leave recovery to the caller."""
    return _execute(taskdir, phase="until_fault", test_dependencies=test_dependencies)


def resume_task(taskdir, *, test_dependencies=None):
    """Consume the only recovery attempt, reopening the original shared ledger."""
    return _execute(taskdir, phase="resume", test_dependencies=test_dependencies)


def run_task(taskdir, *, test_dependencies=None):
    """Standalone controlled convenience run; it does not establish Agnes autonomy."""
    return _execute(taskdir, phase="all", test_dependencies=test_dependencies)


def _execute(taskdir, *, phase, test_dependencies=None):
    """Execute an exclusive stage of one owned task with no implicit retry."""
    fixture = _fixture(test_dependencies)
    clock = test_dependencies.clock if fixture else time
    directory = Path(taskdir).resolve(strict=True)
    registration, receipt = read(directory / "registration.json"), read(directory / "preparation_receipt.json")
    if (registration.get("schema_version") != 1 or registration.get("tool") != TOOL
            or registration.get("purpose") != PURPOSE or registration.get("fixture_only") is not fixture
            or Path(registration.get("task_directory", "")).resolve() != directory
            or registration.get("budgets") != BUDGETS or registration.get("fault_rule") != FAULT_RULE
            or registration.get("tolerances") != TOLERANCES
            or registration.get("deadline_epoch") != registration.get("started_epoch", -1) + 1800
            or registration.get("deadline_monotonic") != registration.get("started_monotonic", -1) + 1800):
        raise ValueError("Original owned registration/protocol/budget identity changed")
    for name in ("registration", "source_lock", "input_manifest", "ledger_registration"):
        if receipt.get(name + "_sha256") != sha(directory / (name + ".json")):
            raise ValueError("Prepared registration/source/input binding changed")
    if receipt.get("protocol_file_sha256") != sha(directory / "protocol.json"):
        raise ValueError("Prepared protocol bytes changed")
    if not fixture and registration["configuration"] != load_config():
        raise ValueError("Trusted production configuration changed")
    _deadline(registration, clock)
    claim = {"all": "execution_claim.json", "preflight": "preflight_claim.json",
             "until_fault": "fault_phase_claim.json", "resume": "resume_execution_claim.json"}[phase]
    if (phase != "all" and (directory / "execution_claim.json").exists()) or (
            phase == "all" and any((directory / name).exists() for name in
                                   ("preflight_claim.json", "fault_phase_claim.json", "resume_execution_claim.json"))):
        raise ValueError("Standalone and caller-driven staged execution cannot be mixed")
    if (directory / "failure.json").exists() or (directory / "completion.json").exists():
        raise ValueError("Terminal owned tasks cannot execute another stage")
    write(directory / claim, {"task_id": registration["task_id"], "pid": os.getpid(), "phase": phase,
                              "registered_sha256": sha(directory / "registration.json")})
    from .resolution_recovery_ledger_v1 import Ledger
    ledger = None
    stage = "source_input_recheck"
    try:
        protocol, lock, inputs = (read(directory / name) for name in
                                  ("protocol.json", "source_lock.json", "input_manifest.json"))
        if registration["protocol_sha256"] != digest(protocol) or lock["execution_source_sha256"] != digest(lock["files"]):
            raise ValueError("Protocol or execution source digest differs")
        if lock.get("runtime_identity_sha256") != digest(lock.get("runtime_identity")):
            raise ValueError("Preregistered runtime identity differs")
        identity = {key: inputs[key] for key in ("records", "source_files", "provenance")}
        if inputs.get("input_identity_sha256") != digest(identity):
            raise ValueError("Full validation input identity differs")
        _fresh(lock["files"])
        _fresh(list(inputs["source_files"].values()))
        config = registration["configuration"]
        paths = _configured_paths(config)
        prepare_inputs = test_dependencies.prepare_inputs if fixture else _prepare_inputs

        def fresh_inputs(*, rebuild=False):
            ledger.check()
            _fresh(lock["files"])
            if not fixture:
                runtime_now, _ = _dependencies()
                if canonical(runtime_now) != canonical(lock["runtime_identity"]) or load_config() != config:
                    raise ValueError("Preregistered runtime or trusted paths changed")
            if rebuild:
                records_now, sources_now, provenance_now = prepare_inputs(paths, protocol)
                if (canonical(records_now) != canonical(inputs["records"])
                        or {key: str(value) for key, value in sources_now.items()}
                        != {key: row["path"] for key, row in inputs["source_files"].items()}
                        or canonical(provenance_now) != canonical(inputs["provenance"])):
                    raise ValueError("Frozen input membership/GT/provenance changed")
            _fresh(list(inputs["source_files"].values()))
            ledger.check()

        ledger_reg = read(directory / "ledger_registration.json")
        expected_ledger = {"budgets": BUDGETS, "image_ids": [row["image_id"] for row in inputs["records"]],
                           "started_epoch": registration["started_epoch"],
                           "started_monotonic": registration["started_monotonic"]}
        if canonical(ledger_reg) != canonical(expected_ledger):
            raise ValueError("Original shared ledger anchor or input order changed")
        ledger = Ledger(directory, ledger_reg, create=phase in ("all", "preflight"), clock=clock)
        if phase in ("all", "preflight"):
            write(directory / "execution_events.json", {"scope": "single_owned_coordinator",
                                                         "execution_mode": "standalone_controlled" if phase == "all" else "explicit_staged_research",
                                                         "step_order": ["audit", "geometry_gate", *STEP_SIZES],
                                                         "fixture_only": fixture})
        fresh_inputs(rebuild=True)
        audit_fn = test_dependencies.audit if fixture else audit_dataset
        geometry_fn = test_dependencies.geometry if fixture else verify_label_geometry
        audit_config = {**config, "output_root": str(directory / "audit")}
        geometry_config = {**config, "output_root": str(directory / "geometry_gate")}
        task_binding = _task_binding(directory, registration, inputs, lock)
        if phase in ("all", "preflight"):
            stage = "audit"
            audit_fn(audit_config, "task")
            audit_chain = _gate_chain(directory / "audit" / "task", "audit_dataset", audit_config, registration, fixture)
            ledger.check()
            stage = "geometry_gate"
            geometry_fn(geometry_config, "task")
            geometry_chain = _gate_chain(directory / "geometry_gate" / "task", "verify_label_geometry", geometry_config, registration, fixture)
            fresh_inputs()
            preflight = {"schema_version": 1, "status": "preflight_passed", "tool": TOOL,
                         "task_id": registration["task_id"], "binding": task_binding,
                         "audit": audit_chain, "geometry_gate": geometry_chain,
                         "audit_configuration": audit_config, "geometry_configuration": geometry_config,
                         "ledger": ledger.summary(), "new_prediction_calls": 0, "fixture_only": fixture,
                         "original_deadline_epoch": registration["deadline_epoch"],
                         "original_deadline_monotonic": registration["deadline_monotonic"], "deadline_reset": False}
            write(directory / "staged_preflight_receipt.json", preflight)
            if phase == "preflight":
                ledger.check()
                return preflight
        else:
            stage = "preflight_reuse"
            preflight = read(directory / "staged_preflight_receipt.json")
            audit_chain = _gate_chain(directory / "audit" / "task", "audit_dataset", audit_config, registration, fixture)
            geometry_chain = _gate_chain(directory / "geometry_gate" / "task", "verify_label_geometry", geometry_config, registration, fixture)
            if (preflight.get("status") != "preflight_passed" or preflight.get("binding") != task_binding
                    or canonical(preflight.get("audit")) != canonical(audit_chain)
                    or canonical(preflight.get("geometry_gate")) != canonical(geometry_chain)
                    or preflight.get("fixture_only") is not fixture or preflight.get("new_prediction_calls") != 0
                    or preflight.get("original_deadline_epoch") != registration["deadline_epoch"]
                    or preflight.get("original_deadline_monotonic") != registration["deadline_monotonic"]
                    or preflight.get("deadline_reset") is not False):
                raise ValueError("Completed preflight provenance, clock or configuration changed")
            if phase == "until_fault" and ledger.summary()["prediction_calls"] != 0:
                raise ValueError("Fresh registered experiment already entered prediction")
        fresh_inputs()
        groups, bindings, environments = {}, {}, []
        backend = test_dependencies.backend if fixture else infer_group
        if phase != "resume":
            (directory / "groups").mkdir()
            (directory / "fault").mkdir()

        def group(step_id, inject=False):
            fresh_inputs()
            imgsz = STEP_SIZES[step_id]
            groupdir = directory / "groups" / step_id
            groupdir.mkdir(exist_ok=False)
            binding = {"task_id": registration["task_id"], "step_id": step_id,
                       "registration_sha256": sha(directory / "registration.json"),
                       "input_identity_sha256": inputs["input_identity_sha256"],
                       "protocol_sha256": registration["protocol_sha256"],
                       "execution_source_sha256": lock["execution_source_sha256"]}
            bindings[step_id] = binding
            budget_before = ledger.summary()
            predictions, environment = backend(inputs["records"], paths["weights_path"], imgsz,
                                               protocol, groupdir, ledger, step_id)
            _validate_predictions(predictions, inputs["records"], imgsz)
            _environment(environment, imgsz, fixture)
            _environment_sources(environment, lock, fixture)
            # Cross-resolution runtime identity excludes only explicit size,
            # wall/cost/memory/input timing fields; versions/FP32/device remain fixed.
            version_fields = ("python", "python_executable", "torch", "ultralytics", "cuda", "cudnn",
                              "gpu_name", "gpu_total_bytes", "backend_source", "callable_sources")
            version_identity = {key: environment[key] for key in version_fields}
            if environments and canonical(version_identity) != canonical(environments[0]):
                raise ValueError("Dependency/GPU identity changed between groups")
            environments.append(version_identity)
            summary = ledger.summary()
            if summary.get("cost_known") is not True or summary.get("open_call") is not None or summary.get("failed_detector_call") is not False:
                raise ValueError("Unknown/open/failed actual predictor cost cannot commit or recover")
            for key, ledger_key in (("closed_prediction_gpu_seconds", "gpu_seconds"),
                                    ("closed_prediction_elapsed_seconds", "elapsed_prediction_seconds")):
                cost = environment.get(key)
                delta = summary[ledger_key] - budget_before[ledger_key]
                if type(cost) not in (int, float) or not math.isfinite(cost) or abs(cost - delta) > 1e-9:
                    raise ValueError("Backend group cost differs from the shared actual receipts")
            ledger.check()
            metrics = score_detections(predictions, list(CATEGORIES.values()),
                                       conf_threshold=.25, match_iou=.5)
            write_bytes(groupdir / "predictions.jsonl", b"".join(canonical(row) + b"\n" for row in predictions))
            write(groupdir / "environment.json", environment)
            write(groupdir / "metrics.json", metrics)
            write(groupdir / "step_verification.json", {"status": "passed", "binding": binding,
                                                       "prediction_images": 640, "ledger": summary,
                                                       "fixture_only": fixture, "checks": {
                                                           "ordered_full_validation_identity": True,
                                                           "actual_frozen_inference_controls": True,
                                                           "closed_known_prediction_costs": True}})
            fresh_inputs()
            rows = [_artifact_record(groupdir / name) for name in GROUP_FILES]
            manifest = {"schema_version": 1, "task_id": registration["task_id"], "tool": TOOL,
                        "status": "completed", "binding": binding, "files": rows}
            write(groupdir / "artifact_manifest.json", manifest)
            if inject:
                if (directory / "fault" / "failure.json").exists():
                    raise ValueError("The fixed fault was already consumed")
                ledger.check()
                failure = {"schema_version": 1, "status": "failed", "task_id": registration["task_id"],
                           "step_id": step_id, "type": "InjectedResolutionStepFault", "fault_rule": FAULT_RULE,
                           "fault_rule_sha256": digest(FAULT_RULE), "binding": binding, "closed_cost": True,
                           "ledger": ledger.summary(), "temporary_artifacts": rows,
                           "original_deadline_epoch": registration["deadline_epoch"],
                           "original_deadline_monotonic": registration["deadline_monotonic"],
                           "step_completion_absent": not (groupdir / "completion.json").exists()}
                write(directory / "fault" / "failure.json", failure)
                raise InjectedResolutionStepFault("Fixed full 960 evaluation fault before step completion")
            ledger.check()
            write(groupdir / "completion.json", {"schema_version": 1, "task_id": registration["task_id"],
                                                  "tool": TOOL, "status": "completed", "binding": binding,
                                                  "artifact_manifest": str(groupdir / "artifact_manifest.json"),
                                                  "artifact_manifest_sha256": sha(groupdir / "artifact_manifest.json"),
                                                  "artifacts_sha256": {row["name"]: row["sha256"] for row in rows}})
            ledger.check()
            chain = _chain(groupdir, TOOL, binding)
            groups[step_id] = {"path": str(groupdir), "binding": binding, "chain": chain,
                               "metrics": metrics, "environment": environment}
            return groups[step_id]

        if phase != "resume":
            for step_id in ("reference_640", "reference_960", "fault_640"):
                stage = step_id
                group(step_id)
            stage = "fault_960"
            try:
                group("fault_960", inject=True)
            except InjectedResolutionStepFault:
                pass
            else:
                raise RuntimeError("The preregistered full second-group fault did not occur")
        else:
            stage = "pending_recovery_recheck"
            pending = read(directory / "pending_recovery_receipt.json")
            pending_marker = read(directory / "pending_recovery_marker.json")
            summary = ledger.summary()
            if (pending.get("status") != "recovery_pending" or pending.get("binding") != task_binding
                    or pending.get("fixture_only") is not fixture
                    or pending.get("original_deadline_epoch") != registration["deadline_epoch"]
                    or pending.get("original_deadline_monotonic") != registration["deadline_monotonic"]
                    or pending.get("deadline_reset") is not False
                    or pending_marker.get("status") != "recovery_pending"
                    or pending_marker.get("binding") != task_binding
                    or pending_marker.get("receipt_sha256") != sha(directory / "pending_recovery_receipt.json")
                    or pending_marker.get("original_fault_tree_sha256") != sha(directory / "fault_tree_before_resume.json")
                    or summary.get("prediction_calls") != 2564 or summary.get("cost_known") is not True
                    or summary.get("open_call") is not None or summary.get("failed_detector_call") is not False
                    or pending.get("ledger", {}).get("journal_head_sha256") != summary["journal_head_sha256"]
                    or pending.get("ledger", {}).get("journal_sha256") != summary["journal_sha256"]
                    or pending.get("ledger", {}).get("gpu_seconds") != summary["gpu_seconds"]
                    or pending.get("ledger", {}).get("elapsed_prediction_seconds") != summary["elapsed_prediction_seconds"]):
                raise ValueError("Original persisted pending failure, cost or clock changed")
            if set(pending.get("groups", {})) != {"reference_640", "reference_960", "fault_640"}:
                raise ValueError("Pending recovery does not contain exactly three completed groups")
            groups = pending["groups"]
            for step_id in groups:
                binding = {**task_binding, "step_id": step_id}
                existing = _chain(directory / "groups" / step_id, TOOL, binding)
                if (canonical(existing) != canonical(groups[step_id]["chain"])
                        or groups[step_id]["binding"] != binding
                        or Path(groups[step_id]["path"]).resolve() != directory / "groups" / step_id
                        or canonical(read(directory / "groups" / step_id / "metrics.json")) != canonical(groups[step_id]["metrics"])
                        or canonical(read(directory / "groups" / step_id / "environment.json")) != canonical(groups[step_id]["environment"])):
                    raise ValueError("Completed reference/first-step manifest changed before resume")
                bindings[step_id] = binding
            fault_binding = {**task_binding, "step_id": "fault_960"}
            bindings["fault_960"] = fault_binding
            fault_manifest = read(directory / "groups" / "fault_960" / "artifact_manifest.json")
            if (fault_manifest.get("binding") != fault_binding
                    or pending.get("fault_manifest_sha256") != sha(directory / "groups" / "fault_960" / "artifact_manifest.json")
                    or {row["name"] for row in fault_manifest.get("files", [])} != set(GROUP_FILES)):
                raise ValueError("Original incomplete second-step manifest changed")
            _fresh(fault_manifest["files"])
            all_environments = [groups[key]["environment"] for key in ("reference_640", "reference_960", "fault_640")]
            all_environments.append(read(directory / "groups" / "fault_960" / "environment.json"))
            version_fields = ("python", "python_executable", "torch", "ultralytics", "cuda", "cudnn",
                              "gpu_name", "gpu_total_bytes", "backend_source", "callable_sources")
            for step_id, environment in zip(list(STEP_SIZES)[:4], all_environments):
                _environment(environment, STEP_SIZES[step_id], fixture)
                _environment_sources(environment, lock, fixture)
                version_identity = {key: environment[key] for key in version_fields}
                if environments and canonical(version_identity) != canonical(environments[0]):
                    raise ValueError("Original group dependency identity changed before recovery")
                environments.append(version_identity)
        stage = "resume_validation"
        failure_path = directory / "fault" / "failure.json"
        failure = read(failure_path)
        if (failure.get("type") != "InjectedResolutionStepFault" or failure.get("closed_cost") is not True
                or failure.get("fault_rule") != FAULT_RULE
                or failure.get("binding") != bindings["fault_960"]
                or (directory / "groups" / "fault_960" / "completion.json").exists()):
            raise ValueError("Only the preregistered incomplete known-cost second group can resume")
        audit_reuse = _gate_chain(directory / "audit" / "task", "audit_dataset", audit_config, registration, fixture)
        geometry_reuse = _gate_chain(directory / "geometry_gate" / "task", "verify_label_geometry", geometry_config, registration, fixture)
        first_reuse = _chain(directory / "groups" / "fault_640", TOOL, bindings["fault_640"])
        if canonical(audit_reuse) != canonical(audit_chain) or canonical(geometry_reuse) != canonical(geometry_chain):
            raise ValueError("Completed audit/geometry evidence changed before recovery")
        before = _snapshot_fault(directory)
        if phase == "resume":
            if canonical(before) != canonical(read(directory / "fault_tree_before_resume.json")):
                raise ValueError("Original failure tree changed while awaiting the caller decision")
        else:
            write(directory / "fault_tree_before_resume.json", before)
        summary = ledger.summary()
        if (summary.get("prediction_calls") != 2564 or summary.get("cost_known") is not True
                or summary.get("open_call") is not None or summary.get("failed_detector_call") is not False):
            raise ValueError("Recovery does not have four complete known-cost groups")
        if phase != "resume":
            pending = {"schema_version": 1, "tool": TOOL, "status": "recovery_pending",
                       "task_id": registration["task_id"], "binding": task_binding, "fixture_only": fixture,
                       "groups": groups, "audit": audit_chain, "geometry_gate": geometry_chain,
                       "fault_failure": _artifact_record(failure_path), "ledger": summary,
                       "fault_manifest_sha256": sha(directory / "groups" / "fault_960" / "artifact_manifest.json"),
                       "fault_tree_sha256": before["tree_sha256"], "allowed_recovery": "resume_registered_failure",
                       "partial_960_reused": False, "automatic_recovery": phase == "all",
                       "original_deadline_epoch": registration["deadline_epoch"],
                       "original_deadline_monotonic": registration["deadline_monotonic"], "deadline_reset": False}
            write(directory / "pending_recovery_receipt.json", pending)
            write(directory / "pending_recovery_marker.json", {
                "schema_version": 1, "status": "recovery_pending", "binding": task_binding,
                "receipt_sha256": sha(directory / "pending_recovery_receipt.json"),
                "original_fault_tree_sha256": sha(directory / "fault_tree_before_resume.json"),
                "parent_completion_absent": True})
            ledger.check()
            if phase == "until_fault":
                return pending
        write(directory / "resume_receipt.json", {"schema_version": 1, "task_id": registration["task_id"],
                                                 "recovery_attempt": 1, "same_configuration": True,
                                                 "reuse": {"audit": audit_reuse, "geometry_gate": geometry_reuse,
                                                           "fault_640": first_reuse},
                                                 "rerun": ["resume_960"], "failed_step": "fault_960",
                                                 "partial_960_reused": False, "original_failure_sha256": sha(failure_path),
                                                 "journal_head_before_resume": summary["journal_head_sha256"],
                                                 "original_deadline_epoch": registration["deadline_epoch"],
                                                 "original_deadline_monotonic": registration["deadline_monotonic"],
                                                 "deadline_reset": False})
        fresh_inputs(rebuild=True)
        stage = "resume_960"
        group("resume_960")
        after = _snapshot_fault(directory)
        write(directory / "fault_tree_after_resume.json", after)
        if canonical(before) != canonical(after):
            raise ValueError("Original fault tree changed during the recovery")
        stage = "independent_review"
        fresh_inputs(rebuild=True)
        final_budget = ledger.summary()
        if (final_budget["prediction_calls"] != 3205 or final_budget["formal_calls"] != 3200
                or final_budget["warmup_calls"] != 5 or final_budget["cost_known"] is not True
                or final_budget["open_call"] is not None):
            raise ValueError("Five complete groups do not match the frozen shared population")
        write(directory / "budget_final.json", final_budget)
        result = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE, "task_id": registration["task_id"],
                  "status": "ready_for_independent_verification", "fixture_only": fixture,
                  "execution_mode": "standalone_controlled" if phase == "all" else "explicit_staged_research",
                  "real_detector_used": not fixture, "audit": audit_chain, "geometry_gate": geometry_chain,
                  "groups": groups, "fault_failure": _artifact_record(failure_path),
                  "fault_tree_preserved": True, "recovery_attempts": 1,
                  "reused_steps": ["audit", "geometry_gate", "fault_640"], "rerun_steps": ["resume_960"],
                  "partial_predictions_reused": False, "deadline_reset": False,
                  "input_identity_sha256": inputs["input_identity_sha256"],
                  "execution_source_sha256": lock["execution_source_sha256"], "final_budget": final_budget,
                  "comparison": compare_scores(groups["fault_640"]["metrics"], groups["resume_960"]["metrics"]),
                  "limitations": ["Known-cost injected step failure, not arbitrary CUDA crash recovery.",
                                  "Scoring reuses detection_metrics and is not a second independent AP implementation.",
                                  "Business recovery alone does not establish an integrated Agnes/AGH research loop."]}
        write(directory / "recovery_result.json", result)
        write(directory / "completion_candidate.json", {
            "schema_version": 1, "task_id": registration["task_id"], "tool": TOOL,
            "status": "candidate_only", "fixture_only": fixture,
            "root_artifacts": _root_artifacts(directory),
            "group_chains": {key: value["chain"] for key, value in groups.items()},
            "audit_chain": audit_chain, "geometry_chain": geometry_chain,
            "fault_tree_sha256": before["tree_sha256"], "original_failure_sha256": sha(failure_path),
            "registration_sha256": sha(directory / "registration.json")})
        ledger.check()
        verifier = test_dependencies.verifier if fixture else _load_verifier()
        verification = verifier(directory, prepublication=True)
        expected_status = "passed_fixture_only" if fixture else "passed"
        checks = verification.get("checks")
        if (verification.get("status") != expected_status or type(checks) is not dict or not checks
                or not all(value is True for value in checks.values())):
            write(directory / "independent_verification.json", verification)
            raise ValueError("Independent full-resolution recovery verifier did not pass")
        write(directory / "independent_verification.json", verification)
        ledger.check()
        _fresh(lock["files"])
        _fresh(list(inputs["source_files"].values()))
        if fixture:
            write(directory / "fixture_only_result.json", {"status": "passed_fixture_only", "task_id": registration["task_id"],
                                                          "real_recovery_accepted": False, "parent_completion_absent": True})
            return {**result, "status": "passed_fixture_only", "real_recovery_accepted": False}
        root_rows = _root_artifacts(directory)
        manifest = {"schema_version": 1, "task_id": registration["task_id"], "tool": TOOL,
                    "status": "completed", "files": root_rows,
                    "group_chains": {key: value["chain"] for key, value in groups.items()},
                    "audit_chain": audit_chain, "geometry_chain": geometry_chain, "fault_tree": after}
        write(directory / "artifact_manifest.json", manifest)
        ledger.check()
        write(directory / "completion.json", {"schema_version": 1, "task_id": registration["task_id"], "tool": TOOL,
                                              "status": "completed", "artifact_manifest": str(directory / "artifact_manifest.json"),
                                              "artifact_manifest_sha256": sha(directory / "artifact_manifest.json"),
                                              "artifacts_sha256": {row["name"]: row["sha256"] for row in root_rows},
                                              "independent_verification_sha256": sha(directory / "independent_verification.json"),
                                              "real_recovery_accepted": True})
        try:
            ledger.check()
        except Exception:
            (directory / "completion.json").rename(directory / "completion_late_rejected.json")
            raise
        return {**result, "status": "completed", "real_recovery_accepted": True}
    except Exception as error:
        if (directory / "completion.json").exists():
            (directory / "completion.json").rename(directory / "completion_rejected.json")
        failure = {"schema_version": 1, "status": "failed", "task_id": registration["task_id"],
                   "stage": stage, "error_type": type(error).__name__, "error": str(error),
                   "original_deadline_epoch": registration["deadline_epoch"], "deadline_reset": False,
                   "fixture_only": fixture}
        if ledger is not None:
            try:
                failure["ledger"] = ledger.summary()
            except Exception as cost_error:
                failure["ledger_error"] = str(cost_error)
        write(directory / "failure.json", failure)
        return failure
    finally:
        if ledger is not None:
            ledger.close()
