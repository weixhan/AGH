"""Tools for evidence-backed cable defect research."""

__version__ = "0.1.0"
