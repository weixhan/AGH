"""Frozen local workflow requests and a fail-closed cumulative budget ledger.

The ledger counts domain invocations, including repair's internal verification.
It creates exactly one journal and cannot reopen it, resume it, or add budget.
Reporting after the final domain invocation is allowed inside the same original
wall deadline; another domain invocation after exhaustion is not allowed.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
from typing import Callable


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PROTOCOL_PATH = PROJECT_ROOT / "fixtures" / "research_workflow_protocol_v1.json"
# The case specification is separately bound by its own frozen SHA rather than
# inferred from case names.
FROZEN_PROTOCOL_SHA256 = "64b29779c5245dd2a5fb5a4e3a3eded75d39bf920b9c942620faa69351b0b25f"
CASE_SPECIFICATION_SHA256 = "3dd74146b0ad7f481ca1d5d3adaa5353182ff999b66d0e9f7a32472c54fefa6b"
_REQUEST_KEYS = {"schema_version", "workflow_version", "request_id", "case_id", "budget"}
_BUDGET_KEYS = {"domain_invocations", "wall_seconds", "gpu_seconds", "model_requests"}
_IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}\Z")


class BudgetError(ValueError):
    """An expired, exhausted, open, altered, or over-budget ledger."""


def _canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _finite_number(value: object, name: str) -> float:
    try:
        finite = type(value) in (int, float) and math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite:
        raise ValueError(f"{name} must be a finite number; booleans are refused")
    return float(value)


def _typed_equal(left: object, right: object) -> bool:
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_typed_equal(left[k], right[k]) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_typed_equal(a, b) for a, b in zip(left, right))
    return left == right


def load_protocol() -> dict:
    """Return the byte-frozen protocol after checking the frozen 12-case source."""
    raw = PROTOCOL_PATH.read_bytes()
    if _sha(raw) != FROZEN_PROTOCOL_SHA256:
        raise ValueError("Research workflow protocol bytes changed")
    protocol = json.loads(raw)
    source = protocol["case_specification"]
    path = PROJECT_ROOT / source["relative_path"]
    if source["sha256"] != CASE_SPECIFICATION_SHA256 or _sha(path.read_bytes()) != CASE_SPECIFICATION_SHA256:
        raise ValueError("Frozen LabelGuard case specification bytes changed")
    specification = json.loads(path.read_bytes())
    ids = [case["id"] for case in specification["cases"]]
    if ids != source["case_ids"] or len(set(ids)) != 12:
        raise ValueError("Frozen LabelGuard case population changed")
    if specification.get("synthetic_only") is not True:
        raise ValueError("Only isolated synthetic LabelGuard inputs are authorized")
    return protocol


def validate_request(request: object, protocol: dict | None = None) -> dict:
    """Validate strict types and return a detached canonical local request."""
    frozen = load_protocol()
    if protocol is not None and not _typed_equal(protocol, frozen):
        raise ValueError("Provided protocol differs from the frozen protocol")
    if type(request) is not dict or set(request) != _REQUEST_KEYS:
        raise ValueError("Research request schema contains missing or unknown fields")
    if type(request["schema_version"]) is not int or request["schema_version"] != 1:
        raise ValueError("schema_version must be integer 1")
    if type(request["workflow_version"]) is not int or request["workflow_version"] != 1:
        raise ValueError("workflow_version must be integer 1")
    if type(request["request_id"]) is not str or not _IDENTIFIER.fullmatch(request["request_id"]):
        raise ValueError("request_id must be a safe 1-64 character identifier")
    if type(request["case_id"]) is not str or request["case_id"] not in frozen["case_specification"]["case_ids"]:
        raise ValueError("case_id is not in the frozen isolated case population")
    budget = request["budget"]
    if type(budget) is not dict or set(budget) != _BUDGET_KEYS:
        raise ValueError("budget schema contains missing or unknown fields")
    caps = frozen["budget_caps"]
    for field in ("domain_invocations", "model_requests"):
        value = budget[field]
        if type(value) is not int or not 0 <= value <= caps[field]:
            raise ValueError(f"{field} must be an integer within the frozen cap")
    for field in ("wall_seconds", "gpu_seconds"):
        value = _finite_number(budget[field], field)
        if not 0 <= value <= caps[field]:
            raise ValueError(f"{field} exceeds the frozen cap or is negative")
    if budget["wall_seconds"] <= 0:
        raise ValueError("wall_seconds must be greater than zero")
    normalized = copy.deepcopy(request)
    normalized["budget"]["wall_seconds"] = float(budget["wall_seconds"])
    normalized["budget"]["gpu_seconds"] = 0
    return normalized


class BudgetLedger:
    """Single-run durable reservation journal with monotonic and epoch deadlines.

    `check()` is the publication check. It rejects an open reservation and an
    elapsed wall deadline, while allowing publication when domain capacity is
    exactly consumed. `reserve()` additionally rejects exhausted capacity.
    A timed-out operation can still close known actual cost; close persists that
    receipt first, then raises BudgetError so its cost is not hidden.
    """

    def __init__(self, directory: str | Path, request: dict,
                 clock: Callable[[], float] = time.monotonic,
                 epoch_clock: Callable[[], float] = time.time):
        self.request = validate_request(request)
        self.protocol = load_protocol()
        self.clock = clock
        self.epoch_clock = epoch_clock
        self.directory = Path(directory).resolve()
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "budget.jsonl"
        self.started_monotonic = self._time(clock(), "monotonic clock")
        self.started_epoch = self._time(epoch_clock(), "epoch clock")
        self._last_monotonic = self.started_monotonic
        self._last_epoch = self.started_epoch
        seconds = self.request["budget"]["wall_seconds"]
        self.deadline_monotonic = self.started_monotonic + seconds
        self.deadline_epoch = self.started_epoch + seconds
        self.used_domain_invocations = 0
        self.reserved_domain_invocations = 0
        self.pending = None
        self._events = []
        self._persisted_bytes = b""
        # Exclusive creation is intentional even if an existing journal is empty.
        with self.path.open("xb"):
            pass
        self._append("ledger_opened", {
            "request": self.request,
            "protocol_sha256": FROZEN_PROTOCOL_SHA256,
            "case_specification_sha256": CASE_SPECIFICATION_SHA256,
            "started_monotonic": self.started_monotonic,
            "started_epoch": self.started_epoch,
            "deadline_monotonic": self.deadline_monotonic,
            "deadline_epoch": self.deadline_epoch,
        })

    @staticmethod
    def _time(value: object, name: str) -> float:
        result = _finite_number(value, name)
        if result < 0:
            raise BudgetError(f"{name} must not be negative")
        return result

    def _verify_journal(self) -> None:
        if self.path.read_bytes() != self._persisted_bytes:
            raise BudgetError("Budget journal was changed, truncated, or appended externally")

    def _append(self, event: str, record: dict) -> dict:
        self._verify_journal()
        row = {"schema_version": 1, "event_version": 1,
               "sequence": len(self._events), "event": event,
               "previous_sha256": self._events[-1]["sha256"] if self._events else "0" * 64,
               "record": record}
        row["sha256"] = _sha(_canonical(row))
        serialized = _canonical(row) + b"\n"
        with self.path.open("ab") as stream:
            stream.write(serialized)
            stream.flush()
            os.fsync(stream.fileno())
        self._persisted_bytes += serialized
        self._events.append(row)
        return copy.deepcopy(row)

    def _clock_state(self) -> dict:
        now = self._time(self.clock(), "monotonic clock")
        epoch = self._time(self.epoch_clock(), "epoch clock")
        if now < self._last_monotonic or epoch < self._last_epoch:
            raise BudgetError("Clock moved backwards during the original workflow")
        self._last_monotonic = now
        self._last_epoch = epoch
        return {"current_monotonic": now, "current_epoch": epoch,
                "elapsed_wall_seconds": now - self.started_monotonic,
                "expired": now >= self.deadline_monotonic or epoch >= self.deadline_epoch}

    def check(self) -> None:
        """Check closed known costs and the original publication wall deadline."""
        self._verify_journal()
        clock = self._clock_state()
        if clock["expired"]:
            raise BudgetError("Original workflow wall deadline expired")
        if self.pending is not None:
            raise BudgetError("Open reservation has unknown actual cost; continuation is refused")
        if self.used_domain_invocations > self.request["budget"]["domain_invocations"]:
            raise BudgetError("Domain invocation budget exceeded")

    def reserve(self, action: str, cost: int) -> str:
        """Durably reserve the frozen worst-case cost before a domain invocation."""
        self.check()
        expected = self.protocol["action_reservations"].get(action) if type(action) is str else None
        if expected is None or type(cost) is not int or cost != expected:
            raise BudgetError("Action or reservation cost differs from the frozen protocol")
        if self.used_domain_invocations + cost > self.request["budget"]["domain_invocations"]:
            raise BudgetError("Domain budget exhausted or insufficient for worst-case reservation")
        token = f"reservation-{len(self._events):04d}"
        clock = self._clock_state()
        if clock["expired"]:
            raise BudgetError("Original workflow wall deadline expired before reservation")
        self.pending = {"token": token, "action": action, "reserved_cost": cost}
        self.reserved_domain_invocations = cost
        try:
            self._append("action_reserved", {
                **self.pending,
                "used_domain_invocations": self.used_domain_invocations,
                "reserved_domain_invocations": cost,
                **clock,
            })
        except BaseException:
            # In-memory state remains open; a failed journal write is not reusable.
            raise
        return token

    def close(self, token: str, actual_cost: int | None = None) -> dict:
        """Persist known cost without resetting the original deadline."""
        self._verify_journal()
        if self.pending is None or type(token) is not str or token != self.pending["token"]:
            raise BudgetError("Reservation token is absent or differs from the open reservation")
        cost = self.pending["reserved_cost"] if actual_cost is None else actual_cost
        if type(cost) is not int or not 0 <= cost <= self.pending["reserved_cost"]:
            raise BudgetError("Known actual cost must be an integer within the reservation")
        clock = self._clock_state()
        receipt = {**self.pending, "actual_cost": cost,
                   "released_domain_invocations": self.pending["reserved_cost"] - cost,
                   "used_domain_invocations": self.used_domain_invocations + cost,
                   "reserved_domain_invocations": 0, **clock}
        event = self._append("action_closed", receipt)
        self.used_domain_invocations += cost
        self.reserved_domain_invocations = 0
        self.pending = None
        if clock["expired"]:
            raise BudgetError("Known actual cost closed, but original workflow wall deadline expired")
        # Include journal I/O in the same original deadline.
        self.check()
        return {**receipt, "event_sha256": event["sha256"]}

    def snapshot(self) -> dict:
        """Return budget evidence; does not authorize a new action or publication."""
        self._verify_journal()
        clock = self._clock_state()
        cap = self.request["budget"]["domain_invocations"]
        return {
            "schema_version": 1, "request_id": self.request["request_id"],
            "protocol_sha256": FROZEN_PROTOCOL_SHA256,
            "case_specification_sha256": CASE_SPECIFICATION_SHA256,
            "budget": copy.deepcopy(self.request["budget"]),
            "used_domain_invocations": self.used_domain_invocations,
            "reserved_domain_invocations": self.reserved_domain_invocations,
            "remaining_domain_invocations": cap - self.used_domain_invocations - self.reserved_domain_invocations,
            "gpu_seconds": 0, "model_requests": 0,
            "started_monotonic": self.started_monotonic,
            "started_epoch": self.started_epoch,
            "deadline_monotonic": self.deadline_monotonic,
            "deadline_epoch": self.deadline_epoch,
            "pending": copy.deepcopy(self.pending),
            "journal_file": self.path.name,
            "journal_sha256": _sha(self._persisted_bytes),
            "last_event_sha256": self._events[-1]["sha256"],
            "event_count": len(self._events),
            "can_start_domain_action": self.pending is None and not clock["expired"] and self.used_domain_invocations < cap,
            **clock,
        }
