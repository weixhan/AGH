"""Fixed scientific actions with model-owned recovery and original-clock workers.

The model never selects paths, commands, budgets, backends, or test injection.
Production activation needs a root-created deployment protocol and source lock.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

from .config import PROJECT_ROOT as ROOT, load_config

CONTRACT = ROOT / "fixtures/resolution_research_mcp_protocol_v1.json"
OWNER = "defect_researcher.resolution_research_mcp_v1"
PREFIX = "resolution-research-v1-"
ACTION_NAMES = {"audit_geometry", "register_hypothesis", "start_registered_experiment",
                "resume_registered_failure", "stop_insufficient_evidence", "decide_stop_resolution",
                "decide_retain_resolution", "decide_insufficient_evidence", "publish_report"}
READ_NAMES = {"status", "independent_review"}
REQUIRED_SOURCES = (
    "defect_researcher/resolution_research_mcp_v1.py", "defect_researcher/resolution_research_mcp_server_v1.py",
    "run_resolution_research_mcp_v1.py", "fixtures/resolution_research_mcp_protocol_v1.json",
    "tools/resolution_research_scope_guard_v1.mjs", "defect_researcher/resolution_recovery_coordinator_v1.py",
    "defect_researcher/resolution_recovery_backend_v1.py", "defect_researcher/resolution_recovery_ledger_v1.py",
    "tools/verify_resolution_recovery_v1.py", "config/local.json",
    "tools/run_resolution_research_model_v1.mjs",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def unique(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    json.dumps(value, allow_nan=False)
    return value


def write(path, value, *, replace=False):
    path = Path(path)
    temporary = path.with_name(path.name + ".writing-" + uuid.uuid4().hex)
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        if replace:
            os.replace(temporary, path)
        else:
            os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def artifact(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "sha256": sha(path), "size_bytes": path.stat().st_size}


@dataclass(frozen=True)
class TestDependencies:
    configuration: dict
    protocol: dict
    registry: Path
    coordinator: object
    verifier: object
    clock: object = time
    fixture_only: bool = True


class Runtime:
    def __init__(self, protocol_path=None, protocol_sha256=None, source_lock=None, source_lock_sha256=None,
                 *, test_dependencies=None):
        if test_dependencies is not None and (type(test_dependencies) is not TestDependencies or test_dependencies.fixture_only is not True):
            raise ValueError("Only explicit Python fixtures may replace dependencies")
        self.test = test_dependencies
        self.processes = {}
        self.clock = self.test.clock if self.test else time
        self.contract = read(CONTRACT)
        if self.test:
            self.protocol = dict(self.test.protocol)
            self.config = dict(self.test.configuration)
            self.registry = Path(self.test.registry).resolve()
            self.pin = None
        else:
            self.pin = {"protocol_path": str(Path(protocol_path).resolve(strict=True)), "protocol_sha256": protocol_sha256,
                        "source_lock": str(Path(source_lock).resolve(strict=True)), "source_lock_sha256": source_lock_sha256}
            self._sources()
            self.protocol = read(self.pin["protocol_path"])
            self.config = load_config()
            self.registry = Path(self.pin["protocol_path"]).parent / "mcp-owned"
        self._protocol()
        self.taskdir = Path(self.config["output_root"]).resolve() / self.protocol["task_id"]
        self.registry.mkdir(parents=True, exist_ok=True)
        self.state_path = self.registry / "state.json"
        owner_path = self.registry / "owner.json"
        identity = {"owner": OWNER, "request_id": self.protocol["request_id"], "task_id": self.protocol["task_id"],
                    "protocol_sha256": self.pin["protocol_sha256"] if self.pin else None,
                    "source_lock_sha256": self.pin["source_lock_sha256"] if self.pin else None, "fixture_only": bool(self.test)}
        if owner_path.exists():
            if read(owner_path) != identity:
                raise ValueError("Registry belongs to another deployment")
        else:
            write(owner_path, identity)
        if not self.state_path.exists():
            write(self.state_path, {"stage": "not_started", "used_actions": [], "worker": None,
                "running_reads": 0, "fault_reads": 0, "completed_reads": 0, "independent_reviews": 0,
                "last_epoch": self.protocol["started_epoch"], "last_monotonic": self.protocol["started_monotonic"]})

    def _protocol(self):
        expected = {"schema_version", "kind", "request_id", "task_id", "workspace_root", "started_epoch",
                    "started_monotonic", "deadline_epoch", "deadline_monotonic", "contract_sha256"}
        p = self.protocol
        if (set(p) != expected or p["schema_version"] != 1 or type(p["schema_version"]) is not int
                or p["kind"] != "resolution_research_mcp_deployment_v1"
                or type(p["request_id"]) is not str or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", p["request_id"])
                or p["task_id"] != PREFIX + p["request_id"] or p["contract_sha256"] != sha(CONTRACT)):
            raise ValueError("Fixed deployment identity or contract differs")
        for key in ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic"):
            if type(p[key]) not in (int, float) or not math.isfinite(p[key]) or p[key] < 0:
                raise ValueError("Trusted outer clock anchor is invalid")
        if p["deadline_epoch"] != p["started_epoch"] + 2400 or p["deadline_monotonic"] != p["started_monotonic"] + 2400:
            raise ValueError("Outer deadline must preserve the original 2400 seconds")
        if not self.test and not Path(p["workspace_root"]).resolve().is_relative_to(ROOT / "outputs"):
            raise ValueError("Deployment workspace must be project-owned")

    def _sources(self):
        if self.test:
            return
        for name, key in (("protocol_path", "protocol_sha256"), ("source_lock", "source_lock_sha256")):
            path = Path(self.pin[name])
            if not path.is_relative_to(ROOT) or not re.fullmatch(r"[0-9a-f]{64}", str(self.pin[key])) or sha(path) != self.pin[key]:
                raise ValueError("Deployment pin changed or escaped the project")
        lock = read(self.pin["source_lock"])
        if lock.get("kind") != "resolution_research_mcp_source_lock_v1" or lock.get("status") != "passed_engineering_only":
            raise ValueError("An accepted engineering source lock is required")
        files = lock.get("files", [])
        paths = set()
        for row in files:
            if type(row) is not dict or set(row) != {"path", "sha256", "size_bytes"}:
                raise ValueError("Source lock row differs")
            path = Path(row["path"]).resolve(strict=True)
            if str(path) in paths or artifact(path) != row:
                raise ValueError("Source lock bytes or unique membership changed")
            paths.add(str(path))
        if any(str((ROOT / relative).resolve()) not in paths for relative in REQUIRED_SOURCES):
            raise ValueError("Source lock omits a required runtime/control/verifier source")

    def _state(self):
        self._sources()
        state = read(self.state_path)
        epoch, mono = self.clock.time(), self.clock.monotonic()
        if (not all(type(v) in (int, float) and math.isfinite(v) for v in (epoch, mono))
                or epoch < state["last_epoch"] or mono < state["last_monotonic"]
                or epoch >= self.protocol["deadline_epoch"] or mono >= self.protocol["deadline_monotonic"]):
            raise RuntimeError("Original model/task handoff deadline expired or clock reversed")
        state.update(last_epoch=epoch, last_monotonic=mono)
        write(self.state_path, state, replace=True)
        return state

    def _save(self, state):
        write(self.state_path, state, replace=True)

    @contextmanager
    def _locked(self):
        path = self.registry / ".adapter-writer.lock"
        limit = time.monotonic() + 5
        while True:
            try:
                descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL)
                break
            except FileExistsError:
                if time.monotonic() >= limit:
                    raise RuntimeError("Owned adapter state has an active or preserved stale writer")
                time.sleep(.01)
        try:
            os.write(descriptor, str(os.getpid()).encode("ascii"))
            os.close(descriptor)
            yield
        finally:
            path.unlink(missing_ok=True)

    def _coordinator(self):
        if self.test:
            return self.test.coordinator
        from . import resolution_recovery_coordinator_v1
        return resolution_recovery_coordinator_v1

    def _verifier(self):
        if self.test:
            return self.test.verifier
        path = ROOT / "tools/verify_resolution_recovery_v1.py"
        spec = importlib.util.spec_from_file_location("_resolution_research_independent_verifier", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module.verify

    def _event(self, kind, **details):
        with (self.registry / "actions.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"at_epoch": self.clock.time(), "event": kind, **details}, ensure_ascii=False, allow_nan=False) + "\n")

    def _response(self, stage, **details):
        return {"request_id": self.protocol["request_id"], "task_id": self.protocol["task_id"], "status": stage,
                "fixture_only": bool(self.test), "science_accepted": False, **details}

    def _run_worker_phase(self, phase):
        coordinator = self._coordinator()
        if phase == "preflight":
            registration = coordinator.prepare_task(self.config, self.protocol["task_id"])
            if Path(registration["task_directory"]).resolve() != self.taskdir:
                raise ValueError("Owned preflight registered another task directory")
            return coordinator.run_preflight(self.taskdir)
        return getattr(coordinator, "run_until_fault" if phase == "initial" else "resume_task")(self.taskdir)

    def _worker_wrapper(self, phase, result):
        wrapper = {"phase": phase, "task_id": self.protocol["task_id"], "result": result, "fixture_only": bool(self.test)}
        if phase == "preflight":
            wrapper.update(request_id=self.protocol["request_id"],
                deployment={"path": self.pin["protocol_path"], "sha256": self.pin["protocol_sha256"]} if self.pin else None,
                source_lock={"path": self.pin["source_lock"], "sha256": self.pin["source_lock_sha256"]} if self.pin else None,
                outer_started_epoch=self.protocol["started_epoch"], outer_deadline_epoch=self.protocol["deadline_epoch"],
                outer_started_monotonic=self.protocol["started_monotonic"], outer_deadline_monotonic=self.protocol["deadline_monotonic"],
                deadline_reset=False)
            if result.get("status") == "preflight_passed":
                wrapper.update(preflight_receipt=artifact(self.taskdir / "staged_preflight_receipt.json"),
                               domain_registration=artifact(self.taskdir / "registration.json"))
        return wrapper

    def _check_preflight_wrapper(self, wrapper):
        expected = self._worker_wrapper("preflight", wrapper["result"])
        if wrapper != expected:
            raise ValueError("Owned preflight deployment, clock or artifact binding changed")
        result = wrapper["result"]
        if result.get("status") == "preflight_passed":
            if result != read(self.taskdir / "staged_preflight_receipt.json"):
                raise ValueError("Owned preflight receipt changed")
            registration = read(self.taskdir / "registration.json")
            if (registration.get("task_id") != self.protocol["task_id"]
                    or registration.get("deadline_epoch") != registration.get("started_epoch", -1) + 1800
                    or registration.get("deadline_monotonic") != registration.get("started_monotonic", -1) + 1800
                    or not self.protocol["started_epoch"] <= registration.get("started_epoch", -1) < self.protocol["deadline_epoch"]
                    or not self.protocol["started_monotonic"] <= registration.get("started_monotonic", -1) < self.protocol["deadline_monotonic"]
                    or result.get("original_deadline_epoch") != registration["deadline_epoch"]
                    or result.get("original_deadline_monotonic") != registration["deadline_monotonic"]
                    or result.get("deadline_reset") is not False or result.get("new_prediction_calls") != 0
                    or result.get("fixture_only") is not bool(self.test)):
                raise ValueError("Preflight did not preserve the original domain clock or zero-inference gate")

    def _worker(self, phase, state):
        result_path = self.registry / (phase + "-result.json")
        if result_path.exists():
            raise ValueError("Worker phase already has a result; no rerun")
        state.update(stage="running", worker=phase)
        self._save(state)
        try:
            if self.test:
                try:
                    result = self._run_worker_phase(phase)
                except Exception as error:
                    result = {"task_id": self.protocol["task_id"], "status": "failed", "error_type": type(error).__name__, "error": str(error)}
                write(result_path, self._worker_wrapper(phase, result))
            else:
                command = [sys.executable, "-B", "-m", OWNER, "--owned-worker", phase]
                for option, key in (("--protocol", "protocol_path"), ("--expected-protocol-sha256", "protocol_sha256"),
                                    ("--source-lock", "source_lock"), ("--expected-lock-sha256", "source_lock_sha256")):
                    command.extend([option, self.pin[key]])
                with (self.registry / (phase + "-worker.log")).open("xb") as stream:
                    process = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=stream, stderr=stream,
                                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                self.processes[phase] = process
                state["worker_pid"] = process.pid
                self._save(state)
        except Exception as error:
            failed_stage = "preflight_failed" if phase == "preflight" else "experiment_failed"
            state.update(stage=failed_stage, experiment_status="not_executed" if phase == "preflight" else "failed",
                         worker_failure={"type": type(error).__name__, "message": str(error)})
            self._save(state)
            return self._response(failed_stage, failure=state["worker_failure"], next_allowed_action="stop_insufficient_evidence")
        self._event("owned_worker_started", phase=phase)
        return self._response("running", phase=phase, host_wait_required=True,
                              continuation="Host waits for this owned worker, then follows up in the SAME AGH session; do not poll or open a new session.")

    def _refresh_worker(self, state):
        if state["stage"] != "running":
            return state
        path = self.registry / (state["worker"] + "-result.json")
        if not path.exists():
            process = self.processes.get(state["worker"])
            if process is not None and process.poll() is not None:
                state.update(stage="preflight_failed" if state["worker"] == "preflight" else "experiment_failed",
                             experiment_status="not_executed" if state["worker"] == "preflight" else "failed_unknown_worker_cost",
                             worker_failure={"exit_code": process.returncode, "result_absent": True,
                                             "resume_allowed": False, "unknown_cost_resumable": False})
                self._save(state)
            return state
        wrapper = read(path)
        if wrapper.get("phase") != state["worker"] or wrapper.get("task_id") != self.protocol["task_id"] or wrapper.get("fixture_only") is not bool(self.test):
            raise ValueError("Owned worker result identity changed")
        result = wrapper["result"]
        status = result.get("status")
        allowed = ({"preflight_passed", "failed"} if state["worker"] == "preflight" else
                   {"recovery_pending", "failed"} if state["worker"] == "initial" else {"completed", "passed_fixture_only", "failed"})
        if status not in allowed or result.get("task_id") != self.protocol["task_id"]:
            raise ValueError("Owned worker returned an invalid phase/status")
        if state["worker"] == "preflight":
            self._check_preflight_wrapper(wrapper)
            state.update(stage="preflight_passed" if status == "preflight_passed" else "preflight_failed",
                         preflight_worker_result=artifact(path))
            if status == "preflight_passed":
                state["preflight"] = wrapper["preflight_receipt"]
            else:
                state["failure"] = result
            self._save(state)
            return state
        state.update(stage="recovery_pending" if status == "recovery_pending" else "experiment_completed" if status in {"completed", "passed_fixture_only"} else "experiment_failed",
                     worker_result=artifact(path), experiment_status=status)
        self._save(state)
        return state

    def call(self, arguments, *, read_only=False):
        with self._locked():
            return self._call(arguments, read_only=read_only)

    def _call(self, arguments, *, read_only=False):
        if type(arguments) is not dict or set(arguments) != {"request_id", "action"} or arguments["request_id"] != self.protocol["request_id"]:
            raise ValueError("Only the one fixed request ID and an action enum are accepted")
        action = arguments["action"]
        if type(action) is not str or action not in (READ_NAMES if read_only else ACTION_NAMES):
            raise ValueError("Unknown action enum")
        state = self._refresh_worker(self._state())
        if read_only:
            return self._read_action(action, state)
        if action in state["used_actions"]:
            raise ValueError("An action cannot repeat or reset an original budget")
        required = {"audit_geometry": {"not_started"}, "register_hypothesis": {"preflight_passed"},
                    "start_registered_experiment": {"hypothesis_registered"}, "resume_registered_failure": {"recovery_pending"},
                    "stop_insufficient_evidence": {"preflight_failed", "preflight_passed", "hypothesis_registered", "recovery_pending", "experiment_failed"},
                    "decide_stop_resolution": {"reviewed"}, "decide_retain_resolution": {"reviewed"},
                    "decide_insufficient_evidence": {"reviewed"}, "publish_report": {"decided", "stopped"}}
        if state["stage"] not in required[action]:
            raise ValueError("Action is outside the evidence-bound stage")
        if action == "resume_registered_failure" and state["fault_reads"] != 1:
            raise ValueError("Model must first read the actual fault evidence")
        if action.startswith("decide_"):
            outcome, measured = self._criteria(state)
            expected = {"resolution_candidate_stopped": "decide_stop_resolution",
                        "resolution_candidate_accepted_for_this_validation_only": "decide_retain_resolution",
                        "insufficient_evidence_stop": "decide_insufficient_evidence"}[outcome]
            if action != expected:
                raise ValueError("Model decision is unsupported by the pre-registered metric criteria")
        state["used_actions"].append(action)
        self._save(state)
        self._event("model_action_admitted", action=action, original_stage=state["stage"])
        if action == "audit_geometry":
            return self._worker("preflight", state)
        if action == "register_hypothesis":
            preflight = self.taskdir / "staged_preflight_receipt.json"
            if artifact(preflight) != state["preflight"]:
                raise ValueError("Evidence changed before hypothesis registration")
            hypothesis = {"schema_version": 1, "request_id": self.protocol["request_id"],
                          "preflight": state["preflight"], "primary_hypothesis": self.contract["primary_hypothesis"],
                          "resolution_candidate": self.contract["resolution_candidate"], "contract_sha256": sha(CONTRACT),
                          "domain_registration": artifact(self.taskdir / "registration.json"), "deadline_reset": False,
                          "method_tuning_allowed": False, "next_experiment_registered": False}
            write(self.registry / "hypothesis.json", hypothesis)
            state.update(stage="hypothesis_registered", hypothesis=artifact(self.registry / "hypothesis.json"))
            self._save(state)
            return self._response("hypothesis_registered", hypothesis=hypothesis)
        if action in {"start_registered_experiment", "resume_registered_failure"}:
            if artifact(self.registry / "hypothesis.json") != state["hypothesis"]:
                raise ValueError("Registered hypothesis changed")
            if action == "resume_registered_failure":
                failure = read(self.taskdir / "fault/failure.json")
                ledger = failure.get("ledger", {})
                if failure.get("closed_cost") is not True or ledger.get("cost_known") is not True or ledger.get("open_call") is not None or ledger.get("failed_detector_call") is not False:
                    raise ValueError("Unknown/open/failed detector cost refuses resume; choose stop")
            return self._worker("initial" if action == "start_registered_experiment" else "resume", state)
        if action == "stop_insufficient_evidence":
            state.update(stage="stopped", stop_reason="Model selected stop from available failed/insufficient evidence; no experiment completion is claimed.")
            self._save(state)
            return self._response("stopped", experiment_status=state.get("experiment_status", "not_executed"), science_accepted=False,
                                  next_experiment_registered=False, original_failure_preserved=True)
        if action.startswith("decide_"):
            decision = {"model_selected_action": action, "resolution_decision": outcome,
                        "measured_frozen_fields": measured, "review": state["review"],
                        "criteria_contract_sha256": sha(CONTRACT), "next_experiment_registered": False}
            write(self.registry / "decision.json", decision)
            state.update(stage="decided", decision=artifact(self.registry / "decision.json"))
            self._save(state)
            return self._response("decided", decision=decision)
        return self._publish(state)

    def _read_action(self, action, state):
        if action == "status":
            if state.get("worker") == "preflight":
                raise ValueError("Preflight completion is host-observed; no model status call is registered")
            field = {"running": "running_reads", "recovery_pending": "fault_reads", "experiment_completed": "completed_reads", "experiment_failed": "completed_reads"}.get(state["stage"])
            if field is None or state[field] >= 1:
                raise ValueError("Status scope allows at most one running, one fault and one completed/failed read")
            state[field] += 1
            self._save(state)
            details = {}
            if state["stage"] == "recovery_pending":
                details["actual_failure"] = read(self.taskdir / "fault/failure.json")
                details["next_allowed_actions"] = ["resume_registered_failure", "stop_insufficient_evidence"]
            return self._response(state["stage"], experiment_status=state.get("experiment_status"), **details)
        if state["stage"] != "experiment_completed" or state["completed_reads"] != 1 or state["independent_reviews"] >= 1:
            raise ValueError("One independent review must follow actual completed experiment evidence")
        state["independent_reviews"] += 1
        self._save(state)
        report = self._verifier()(self.taskdir, prepublication=False)
        expected = "passed_fixture_only" if self.test else "passed"
        if report.get("status") != expected or (not self.test and report.get("real_recovery_accepted") is not True):
            state.update(stage="experiment_failed", independent_failure=report)
            self._save(state)
            return self._response("independent_review_failed", verification=report, next_allowed_action="stop_insufficient_evidence")
        write(self.registry / "independent_review.json", report)
        state.update(stage="reviewed", review=artifact(self.registry / "independent_review.json"))
        self._save(state)
        outcome, measured = self._criteria(state)
        expected = {"resolution_candidate_stopped": "decide_stop_resolution",
                    "resolution_candidate_accepted_for_this_validation_only": "decide_retain_resolution",
                    "insufficient_evidence_stop": "decide_insufficient_evidence"}[outcome]
        return self._response("reviewed", verification=report, science_accepted=not bool(self.test),
                              frozen_rule_outcome=outcome, measured_frozen_fields=measured,
                              only_supported_decision_action=expected)

    def _criteria(self, state):
        criteria = self.contract["resolution_candidate"]
        outcome = "insufficient_evidence_stop"
        measured = {}
        if state["stage"] in {"reviewed", "decided"}:
            if artifact(self.registry / "independent_review.json") != state["review"]:
                raise ValueError("Independent review changed before reporting")
            values = [read(self.taskdir / relative) for relative in (criteria["baseline"], criteria["candidate"])]
            def field(value, key):
                for component in key.split("."):
                    value = value[component]
                if type(value) not in (int, float) or not math.isfinite(value):
                    raise ValueError("Metric missing/nonfinite")
                return value
            try:
                if any(field(value, key) <= 0 for value in values for key in criteria["required_denominators"]):
                    raise ValueError("Normal-image denominator missing")
                passed = []
                for rule in criteria["criteria"]:
                    left, right = [field(value, rule["field"]) for value in values]
                    measured[rule["field"]] = {"640": left, "960": right}
                    passed.append(right >= left if rule["operator"] == "greater_or_equal_baseline" else right <= left)
                outcome = "resolution_candidate_accepted_for_this_validation_only" if all(passed) else "resolution_candidate_stopped"
            except (KeyError, TypeError, ValueError):
                outcome = "insufficient_evidence_stop"
        return outcome, measured

    def _publish(self, state):
        outcome, measured = self._criteria(state)
        if state["stage"] == "decided":
            if artifact(self.registry / "decision.json") != state["decision"]:
                raise ValueError("Model decision evidence changed")
            decision = read(self.registry / "decision.json")
            if decision["resolution_decision"] != outcome or decision["measured_frozen_fields"] != measured:
                raise ValueError("Metrics changed after model decision")
            fresh = self._verifier()(self.taskdir, prepublication=False)
            expected = "passed_fixture_only" if self.test else "passed"
            if fresh.get("status") != expected or (not self.test and fresh.get("real_recovery_accepted") is not True):
                raise ValueError("Current experiment artifacts failed independent pre-report reading")
            write(self.registry / "pre_report_independent_review.json", fresh)
            state["pre_report_review"] = artifact(self.registry / "pre_report_independent_review.json")
        registration = read(self.taskdir / "registration.json") if (self.taskdir / "registration.json").is_file() else {}
        completion = self.taskdir / "completion.json"
        budget_scope = {"domain_wall_seconds": 1800, "domain_started_epoch": registration.get("started_epoch"),
                        "domain_deadline_epoch": registration.get("deadline_epoch"),
                        "business_completion": artifact(completion) if completion.is_file() else None,
                        "business_completion_file_mtime_epoch": completion.stat().st_mtime if completion.is_file() else None,
                        "outer_wall_seconds": 2400, "outer_started_epoch": self.protocol["started_epoch"],
                        "outer_deadline_epoch": self.protocol["deadline_epoch"], "report_prepublication_epoch": self.clock.time(),
                        "boundary": "Domain covers prepare/audit/gate/five groups/business verifier/parent completion. Later read-only science/model report stays inside the original outer clock and does not extend domain execution."}
        report = {"schema_version": 1, "request_id": self.protocol["request_id"], "task_id": self.protocol["task_id"],
                  "research_status": "bounded_report_completed", "experiment_status": state.get("experiment_status", "not_executed"),
                  "recovery_accepted": state["stage"] == "decided" and not bool(self.test), "resolution_decision": outcome,
                  "measured_frozen_fields": measured, "preflight": state.get("preflight"), "hypothesis": state.get("hypothesis"),
                  "independent_review": state.get("review"), "worker_result": state.get("worker_result"), "model_decision": state.get("decision"),
                  "pre_report_review": state.get("pre_report_review"), "budget_scope": budget_scope,
                  "next_plan": {"action": "stop_and_report" if "accepted" not in outcome else "retain_bounded_validation_result",
                                "new_experiment_registered": False, "method_tuning": False},
                  "fixture_only": bool(self.test), "original_failure_preserved": True, "domain_deadline_reset": False,
                  "model_deadline_epoch": self.protocol["deadline_epoch"], "limitations": self.contract["limitations"]}
        write(self.registry / "research_report.json", report)
        state.update(stage="report_completed", report=artifact(self.registry / "research_report.json"))
        self._save(state)
        return self._response("report_completed", report=report, report_artifact=state["report"],
                              report_publication_file_mtime_epoch=(self.registry / "research_report.json").stat().st_mtime,
                              science_accepted=report["recovery_accepted"])

    def inspect_owned_worker(self):
        """Host-only continuation signal; it never debits/executes a model tool."""
        with self._locked():
            state = self._refresh_worker(self._state())
            details = {"phase": state.get("worker"), "host_notification_allowed": state["stage"] in
                       {"preflight_passed", "preflight_failed", "recovery_pending", "experiment_completed", "experiment_failed"}}
            if state.get("worker") == "preflight":
                details.update(preflight_worker_result=state.get("preflight_worker_result"), preflight_receipt=state.get("preflight"),
                               failure=state.get("failure", state.get("worker_failure")))
                result_path = self.registry / "preflight-result.json"
                if state.get("preflight_worker_result") is not None:
                    wrapper = read(result_path)
                    details.update(evidence=wrapper["result"], worker_status=wrapper["result"]["status"],
                                   known_cost=True, new_prediction_calls=0, deadline_reset=False)
            return self._response(state["stage"], **details)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", required=True, type=Path)
    parser.add_argument("--expected-protocol-sha256", required=True)
    parser.add_argument("--source-lock", required=True, type=Path)
    parser.add_argument("--expected-lock-sha256", required=True)
    parser.add_argument("--owned-worker", choices=["preflight", "initial", "resume"])
    parser.add_argument("--inspect", action="store_true")
    args = parser.parse_args()
    runtime = Runtime(args.protocol, args.expected_protocol_sha256, args.source_lock, args.expected_lock_sha256)
    if args.inspect:
        print(json.dumps(runtime.inspect_owned_worker(), ensure_ascii=True))
        return 0
    if args.owned_worker is None:
        parser.error("This module requires host --inspect or fixed --owned-worker")
    with runtime._locked():
        state = runtime._state()
    if state["stage"] != "running" or state["worker"] != args.owned_worker:
        raise ValueError("Worker phase is not owned by an admitted model action")
    try:
        result = runtime._run_worker_phase(args.owned_worker)
    except Exception as error:
        result = {"task_id": runtime.protocol["task_id"], "status": "failed", "error_type": type(error).__name__, "error": str(error)}
    with runtime._locked():
        runtime._state()  # Recheck the original outer clock and source pins before publication.
    write(runtime.registry / (args.owned_worker + "-result.json"), runtime._worker_wrapper(args.owned_worker, result))
    return 0 if result.get("status") in {"preflight_passed", "recovery_pending", "completed"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
