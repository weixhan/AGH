"""Strict two-tool stdio transport for explicitly staged scientific recovery."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

from .resolution_research_mcp_v1 import ACTION_NAMES, READ_NAMES, Runtime

ACTION_TOOL = "research_action_v1"
READ_TOOL = "research_read_v1"
PROTOCOL = "2025-03-26"


def _error(identifier, code, message):
    return {"jsonrpc": "2.0", "id": identifier, "error": {"code": code, "message": message}}


def _result(identifier, value):
    return {"jsonrpc": "2.0", "id": identifier, "result": value}


def _finite(value):
    if value is None or type(value) in (str, bool, int):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(_finite(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and _finite(item) for key, item in value.items())
    return False


def tools(request_id):
    return [{"name": name,
        "description": description,
        "inputSchema": {"type": "object", "properties": {
            "request_id": {"type": "string", "enum": [request_id]},
            "action": {"type": "string", "enum": sorted(actions)}},
            "required": ["request_id", "action"], "additionalProperties": False},
        "annotations": {"readOnlyHint": readonly, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False}}
        for name, actions, readonly, description in (
            (ACTION_TOOL, ACTION_NAMES, False,
             "Act on the single frozen research request. audit_geometry returns running/phase=preflight promptly and starts one owned CPU worker to prepare the original domain clock and run new gates. "
             "The host waits for the pinned preflight result and follows up in the SAME session; no model status call is registered for preflight. "
             "register_hypothesis freezes the evidence-bound hypothesis before inference. start_registered_experiment returns promptly and runs only until the actual registered fault. "
             "After reading actual known-cost fault evidence, choose resume_registered_failure ONCE or stop_insufficient_evidence. Resume preserves the same clock/ledger. "
             "publish_report follows independent review or an explicit stop; it does not claim an unsuccessful experiment passed. No caller paths, budgets, commands, method tuning or alternate backends."),
            (READ_TOOL, READ_NAMES, True,
             "Read the owned request only. status is limited to one running, one actual fault, and one completed/failed read; do not poll. "
             "After a background action returns running, the host waits and notifies the SAME AGH session. independent_review separately rechecks the finished experiment without inference. "
             "This tool cannot start, resume, modify the original data, reset deadlines, or increase any budget."))]


class ResolutionResearchMCPServer:
    def __init__(self, runtime):
        self.runtime = runtime
        self.initialized = False
        self.ready = False
        self.protocol = PROTOCOL

    def handle_message(self, message):
        if type(message) is list:
            if not message:
                return _error(None, -32600, "Empty batch")
            rows = [self.handle_message(row) for row in message]
            return [row for row in rows if row is not None] or None
        if type(message) is not dict:
            return _error(None, -32600, "Expected JSON-RPC object")
        identifier = message.get("id")
        if (set(message) - {"jsonrpc", "id", "method", "params"} or message.get("jsonrpc") != "2.0"
                or type(message.get("method")) is not str or ("id" in message and type(identifier) not in (str, int))):
            return _error(identifier if type(identifier) in (str, int) else None, -32600, "Invalid request")
        params = message.get("params", {})
        notification = "id" not in message
        if type(params) is not dict:
            return None if notification else _error(identifier, -32602, "Parameters must be an object")
        method = message["method"]
        if notification:
            if method == "notifications/initialized" and self.initialized and not params:
                self.ready = True
            return None  # Tool notifications never execute.
        if method == "ping":
            return _result(identifier, {}) if not params else _error(identifier, -32602, "Ping takes no arguments")
        if method == "initialize":
            client = params.get("clientInfo")
            if (self.initialized or set(params) - {"protocolVersion", "capabilities", "clientInfo", "_meta"}
                    or type(params.get("protocolVersion")) is not str or not params["protocolVersion"]
                    or type(params.get("capabilities")) is not dict or type(client) is not dict
                    or type(client.get("name")) is not str or not client["name"]
                    or type(client.get("version")) is not str or not client["version"]
                    or ("_meta" in params and type(params["_meta"]) is not dict)):
                return _error(identifier, -32602, "Invalid or repeated initialize")
            self.initialized = True
            self.protocol = params["protocolVersion"] if params["protocolVersion"] in {PROTOCOL, "2024-11-05"} else PROTOCOL
            return _result(identifier, {"protocolVersion": self.protocol, "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "defect-researcher-scientific-recovery-v1", "version": "1.0.0"}})
        if not self.ready:
            return _error(identifier, -32002, "Complete initialization before using tools")
        if method == "tools/list":
            if set(params) - {"cursor", "_meta"} or params.get("cursor") is not None or ("_meta" in params and type(params["_meta"]) is not dict):
                return _error(identifier, -32602, "No cursor or unknown list parameters")
            rows = tools(self.runtime.protocol["request_id"])
            if self.protocol == "2024-11-05":
                for row in rows:
                    row.pop("annotations")
            return _result(identifier, {"tools": rows})
        if method != "tools/call":
            return _error(identifier, -32601, "Method not found")
        if (set(params) - {"name", "arguments", "_meta"} or params.get("name") not in {ACTION_TOOL, READ_TOOL}
                or ("_meta" in params and type(params["_meta"]) is not dict)):
            return _error(identifier, -32602, "Unknown tool or call parameters")
        arguments = params.get("arguments")
        allowed = READ_NAMES if params["name"] == READ_TOOL else ACTION_NAMES
        if (type(arguments) is not dict or set(arguments) != {"request_id", "action"}
                or arguments["request_id"] != self.runtime.protocol["request_id"]
                or type(arguments["action"]) is not str or arguments["action"] not in allowed):
            return _error(identifier, -32602, "Only fixed request ID and action enum are supported")
        try:
            report = self.runtime.call(arguments, read_only=params["name"] == READ_TOOL)
            statuses = {"preflight_passed", "preflight_failed", "hypothesis_registered", "running", "recovery_pending",
                        "experiment_completed", "experiment_failed", "stopped", "reviewed", "independent_review_failed", "decided", "report_completed"}
            if (type(report) is not dict or not _finite(report) or report.get("request_id") != self.runtime.protocol["request_id"]
                    or report.get("task_id") != "resolution-research-v1-" + self.runtime.protocol["request_id"]
                    or report.get("status") not in statuses or type(report.get("fixture_only")) is not bool
                    or type(report.get("science_accepted")) is not bool
                    or (report["fixture_only"] and report["science_accepted"])):
                raise ValueError("Runtime returned invalid finite identity")
            value = {"content": [{"type": "text", "text": json.dumps(report, ensure_ascii=False, allow_nan=False)}], "isError": False}
        except Exception as error:
            value = {"content": [{"type": "text", "text": json.dumps({"request_id": self.runtime.protocol["request_id"],
                "task_id": "resolution-research-v1-" + self.runtime.protocol["request_id"],
                "status": "tool_refused", "error_type": type(error).__name__, "error": str(error)}, ensure_ascii=False)}], "isError": True}
        return _result(identifier, value)


def serve(runtime, *, stdin=None, stdout=None):
    incoming = sys.stdin.buffer if stdin is None else stdin
    outgoing = sys.stdout.buffer if stdout is None else stdout
    if stdout is None:
        sys.stdout = sys.stderr  # Worker/library prints cannot corrupt stdio frames.
    server = ResolutionResearchMCPServer(runtime)
    def unique(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    def numeric(value):
        parsed = float(value)
        if not math.isfinite(parsed):
            raise ValueError("Nonfinite number")
        return parsed
    for line in incoming:
        try:
            message = json.loads(line.decode("utf-8"), object_pairs_hook=unique, parse_float=numeric,
                                 parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite constant")))
            response = server.handle_message(message)
        except (ValueError, UnicodeDecodeError):
            response = _error(None, -32700, "Strict UTF-8 JSON parse failed")
        except Exception:
            response = _error(None, -32603, "Internal transport error")
        if response is not None:
            outgoing.write(json.dumps(response, ensure_ascii=True, allow_nan=False, separators=(",", ":")).encode("utf-8") + b"\n")
            outgoing.flush()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", required=True, type=Path)
    parser.add_argument("--expected-protocol-sha256", required=True)
    parser.add_argument("--source-lock", required=True, type=Path)
    parser.add_argument("--expected-lock-sha256", required=True)
    args = parser.parse_args()
    try:
        runtime = Runtime(args.protocol, args.expected_protocol_sha256, args.source_lock, args.expected_lock_sha256)
        serve(runtime)
        return 0
    except (KeyboardInterrupt, BrokenPipeError):
        return 0
    except Exception as error:
        print(f"Scientific MCP startup refused: {type(error).__name__}: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
