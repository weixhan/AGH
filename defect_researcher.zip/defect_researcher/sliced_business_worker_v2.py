"""Two-image, known-cost step recovery worker, business protocol version 1.

This dedicated worker shares the fixed V3 detector and journal implementations.
It never uses the full-population request validator. The only injected failure
is the preregistered return-before-commit boundary, with durable closed timing.
The coordinator owns the shared deadline and final experiment publication.
"""
from __future__ import annotations

from copy import deepcopy
import math
from pathlib import Path
import sys
import time

from .audit import _sha256, _timestamp
from .sliced_worker_v3 import (
    EXPECTED_PREDICTOR_OPTIONS, _canonical, _check_budget,
    _check_prediction_budget, _pixels, _read, _starting_environment,
    _validate_predictor_options, _validate_reference_options, _write,
)


from .sliced_business_backend_v2 import DetectorBackendV2 as DetectorBackend


FAULT_FILE = "fault.json"
FAULT_ERROR = "Fixed business fault after known-cost prediction, before observation commit"
TOOL = "verify_sliced_business_recovery_v2"
PURPOSE = "two-image-known-cost-step-recovery-v2"
FAULT_RULE = {"image_id": "C01_B01_frame_000030", "pass_index": 2,
              "max_injections": 1, "boundary": "after_predict_closed_cost_before_passed"}


class InjectedBusinessFault(RuntimeError):
    """Exactly one known-cost formal prediction returned without a checkpoint."""


def _known_timing(timing):
    if type(timing) is not dict or set(timing) != {"elapsed_seconds", "gpu_seconds"}:
        raise ValueError("Fixed fault requires an exact, closed timing record")
    for key in ("elapsed_seconds", "gpu_seconds"):
        value = timing[key]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("Fixed fault requires known elapsed/GPU timing")
    return deepcopy(timing)


def _strict_equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(_strict_equal(left[key], right[key]) for key in left)
    if type(left) is list:
        return len(left) == len(right) and all(_strict_equal(a, b) for a, b in zip(left, right))
    return left == right


def _fault_consumed(request, budget):
    """Consume the fixed saved failure evidence, never a request toggle."""
    if request.get("arm") not in ("control", "fault", "resume"):
        raise ValueError("Unknown business arm")
    if not _strict_equal(request["protocol"].get("fault"), FAULT_RULE):
        raise ValueError("The preregistered fault rule changed")
    path = Path(request["directory"]) / FAULT_FILE
    failures = [row for row in budget["formal_attempts"] if row.get("status") == "failed"]
    if request["arm"] != "resume":
        if path.exists() or failures:
            raise ValueError("Fresh arms cannot import or hide a prior fault")
        return False
    if len(failures) != 1 or not path.is_file():
        raise ValueError("Resume requires the one durable fixed fault")
    fault = _read(path)
    failed = failures[0]
    fixed = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE,
             "experiment_id": request["experiment_id"], "arm": "fault",
             "image_id": FAULT_RULE["image_id"], "pass_id": FAULT_RULE["pass_index"],
             "call_index": 3, "boundary": FAULT_RULE["boundary"],
             "fault_rule_sha256": _canonical(FAULT_RULE)}
    for key in ("protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256"):
        fixed[key] = request[key]
    if any(not _strict_equal(fault.get(key), value) for key, value in fixed.items()):
        raise ValueError("Saved fixed fault identity changed")
    if (failed.get("image_id") != FAULT_RULE["image_id"] or type(failed.get("pass_id")) is not int
            or failed["pass_id"] != 2 or type(failed.get("call_index")) is not int or failed["call_index"] != 3
            or failed.get("error") != {"type": "InjectedBusinessFault", "message": FAULT_ERROR}):
        raise ValueError("Saved failed call does not identify the fixed business fault")
    timing = _known_timing(fault.get("timing"))
    if any(not _strict_equal(timing[key], failed.get(key)) for key in timing):
        raise ValueError("Saved fixed fault timing differs from its closed call")
    if (type(fault.get("shared_call_index")) is not int or fault["shared_call_index"] < 1
            or not isinstance(fault.get("utc_triggered"), str) or not fault["utc_triggered"]
            or fault.get("output_sha256") != _canonical(fault.get("prediction_output"))):
        raise ValueError("Saved fault output or shared call identity changed")
    _validate_predictor_options(fault["prediction_output"].get("effective_options"), context="Saved fault")
    return True


def _inject_fixed_fault(request, value, attempt, timing, shared_call_index, *, actual_environment):
    from .sliced_journal import write_immutable_json
    from .sliced_task_v3 import validate_inference_controls
    timing = _known_timing(timing)
    _validate_predictor_options(value.get("effective_options"), context="Fixed fault")
    # The historical reference records predictor controls and dependencies;
    # actual input dtype/device are evidence captured by the current backend.
    _validate_reference_options(request["reference_environment"])
    validate_inference_controls(actual_environment, [value])
    fault = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE,
             "experiment_id": request["experiment_id"], "arm": "fault",
             "image_id": attempt["image_id"], "pass_id": attempt["pass_id"],
             "call_index": attempt["call_index"], "shared_call_index": shared_call_index,
             "boundary": FAULT_RULE["boundary"], "fault_rule_sha256": _canonical(FAULT_RULE),
             "utc_triggered": _timestamp(), "prediction_output": deepcopy(value),
             "output_sha256": _canonical(value), "timing": timing}
    for key in ("protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256"):
        fault[key] = request[key]
    write_immutable_json(Path(request["directory"]) / FAULT_FILE, fault)
    raise InjectedBusinessFault(FAULT_ERROR)


def _execute(request, backend_factory=DetectorBackend):
    """Run one arm; isolated tests alone supply a Python fake backend factory."""
    from .sliced_business_recovery_v2 import validate_worker_request, SharedExperimentLedger, recover_stopped_worker
    from .sliced_task_v3 import validate_inference_controls
    validate_worker_request(request)
    _validate_reference_options(request.get("reference_environment"))
    prior_environment = request.get("resume_environment")
    if prior_environment is not None:
        validate_inference_controls(prior_environment)
    import cv2
    import numpy as np
    from .sliced_inference import tiles, map_predictions
    from .sliced_journal import PassJournal, JOURNAL_FILE, write_immutable_json

    directory, protocol = Path(request["directory"]), request["protocol"]
    budget, index = _read(directory / "budget.json"), _read(directory / "checkpoint_index.json")
    consumed_fault = _fault_consumed(request, budget)
    if budget.get("resumable") is not True:
        raise ValueError("Unknown or unfinished device work cannot start a business worker")
    shared = SharedExperimentLedger(request)
    shared.check()
    checkpoint_dir = directory / "checkpoints"
    checkpoint_dir.mkdir(exist_ok=True)
    completed = {(row["image_id"], row["pass_id"]): row for row in index["checkpoints"]}
    backend, journal = None, None
    segment_started = time.perf_counter()
    task_before = max(budget["task_wall_seconds"], request.get("task_monotonic_elapsed_before_worker", 0))
    inference_before = budget["inference_wall_seconds"]
    inference_segment_started = segment_started if budget.get("inference_started_epoch") is not None else None
    segment = {"utc_started": _timestamp(), "utc_finished": None,
               "task_wall_seconds_before": task_before, "inference_wall_seconds_before": inference_before,
               "monotonic_task_seconds": 0., "monotonic_inference_seconds": 0.}
    budget.setdefault("wall_segments", []).append(segment)

    def save_budget():
        now = time.time()
        segment["monotonic_task_seconds"] = time.perf_counter() - segment_started
        segment["monotonic_inference_seconds"] = 0. if inference_segment_started is None else time.perf_counter() - inference_segment_started
        budget["inference_wall_seconds"] = 0. if budget.get("inference_started_epoch") is None else max(
            inference_before + segment["monotonic_inference_seconds"], now - budget["inference_started_epoch"])
        budget["task_wall_seconds"] = max(task_before + segment["monotonic_task_seconds"], now - budget["task_started_epoch"])
        budget["formal_calls"], budget["warmup_calls"] = len(budget["formal_attempts"]), len(budget["warmup_attempts"])
        budget["successful_observations"] = len(index["checkpoints"])

    def call(source, shape, image_id, pass_id, warmup=False):
        nonlocal inference_segment_started
        save_budget()
        _check_prediction_budget(budget, protocol)
        shared.check()
        collection = budget["warmup_attempts" if warmup else "formal_attempts"]
        if len(collection) >= protocol["budgets"]["max_warmup_calls" if warmup else "max_formal_calls"]:
            raise RuntimeError("Call budget exhausted before prediction")
        if budget.get("inference_started_epoch") is None:
            budget["inference_started_epoch"], budget["inference_started_at"] = time.time(), _timestamp()
            inference_segment_started = time.perf_counter()
        attempt = {"call_index": len(collection) + 1, "image_id": image_id, "pass_id": pass_id,
                   "status": "started", "utc_started": _timestamp(), "utc_finished": None,
                   "elapsed_seconds": None, "gpu_seconds": None}
        shared_call_index = shared.before_call("warmup" if warmup else "formal", image_id, pass_id, attempt["call_index"])
        collection.append(attempt)
        save_budget()
        journal.started(attempt, warmup=warmup)
        try:
            backend.last_timing = None
            value = backend.predict(source, shape)
            if (not warmup and request["arm"] == "fault" and not consumed_fault
                    and image_id == FAULT_RULE["image_id"] and pass_id == FAULT_RULE["pass_index"]):
                _inject_fixed_fault(request, value, attempt, backend.last_timing, shared_call_index,
                                    actual_environment=backend.environment())
            attempt["status"] = "passed"
            return value, attempt
        except Exception as error:
            attempt.update(status="failed", error={"type": type(error).__name__, "message": str(error)})
            raise
        finally:
            timing = backend.last_timing or {"elapsed_seconds": None, "gpu_seconds": None}
            attempt.update(timing, utc_finished=_timestamp())
            seconds, elapsed = timing.get("gpu_seconds"), timing.get("elapsed_seconds")
            if isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed < 0:
                budget["resumable"] = False
            if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds < 0:
                budget["resumable"] = False
            else:
                budget["gpu_seconds"] += seconds
            save_budget()
            try:
                journal.finished(attempt, warmup=warmup)
            finally:
                # A local journal IO error must not hide the already known
                # returned cost from the experiment's independent ledger.
                shared.finish_call(shared_call_index, attempt)

    try:
        identity = {"protocol_sha256": request["protocol_sha256"], "weight_sha256": protocol["weight_sha256"],
                    "scientific_inputs_sha256": request["scientific_inputs_sha256"],
                    "execution_source_sha256": request["execution_source_sha256"]}
        if type(request.get("execution_io_version")) is not int or request["execution_io_version"] != 2:
            raise ValueError("Only source-bound business execution version 2 may run")
        save_budget()
        journal = (PassJournal.resume(directory, protocol, budget, index, identity)
                   if (directory / JOURNAL_FILE).exists() else PassJournal(directory, protocol, budget, index, identity))
        _check_prediction_budget(budget, protocol)
        shared.check()
        backend = backend_factory(request)
        if not budget["warmup_attempts"]:
            first = request["records"][0]
            if _sha256(Path(first["image_path"])) != request["image_sha256"][first["image_id"]]:
                raise ValueError("Warmup source bytes changed; prediction refused")
            call(first["image_path"], (first["height"], first["width"]), first["image_id"], 0, warmup=True)
            _check_budget(budget, protocol)
        environment = _starting_environment(backend, prior_environment)
        environment_identity = _canonical({key: value for key, value in environment.items() if key != "peak_allocated_bytes"})
        _write(directory / "environment.json", environment)
        for image_index, record in enumerate(request["records"]):
            raw_hash = _sha256(Path(record["image_path"]))
            if raw_hash != request["image_sha256"][record["image_id"]]:
                raise ValueError("Image bytes changed before observation")
            image = cv2.imread(record["image_path"], cv2.IMREAD_COLOR)
            if image is None or list(image.shape) != [record["height"], record["width"], 3] or image.dtype != np.uint8:
                raise ValueError("BGR decoding differs from the fixed two-image population")
            decoded_hash = _pixels(image)
            for crop_record in tiles(record["width"], record["height"]):
                pass_id, crop = crop_record["pass_id"], crop_record["crop"]
                x0, y0, x1, y1 = crop
                array = np.ascontiguousarray(image[y0:y1, x0:x1])
                observation_identity = {"image_id": record["image_id"], "image_index": image_index, "pass_id": pass_id,
                                        "crop": crop, "source_image_sha256": raw_hash, "decoded_image_sha256": decoded_hash,
                                        "input_pixels_sha256": _pixels(array), "protocol_sha256": request["protocol_sha256"],
                                        "weight_sha256": protocol["weight_sha256"], "scientific_inputs_sha256": request["scientific_inputs_sha256"]}
                key = (record["image_id"], pass_id)
                if key in completed:
                    checkpoint = _read(directory / completed[key]["relative_path"])
                    if (not _strict_equal(checkpoint["identity"], observation_identity)
                            or checkpoint["environment_identity"] != environment_identity):
                        raise ValueError("Checkpoint pixel/protocol/environment identity differs; resume refused")
                    continue
                value, attempt = call(record["image_path"] if pass_id == 0 else array,
                                      (y1-y0, x1-x0), record["image_id"], pass_id)
                _validate_predictor_options(value.get("effective_options"), context="Observation")
                validate_inference_controls(environment, [value])
                predictions = value["local_predictions"]
                if len(predictions) > protocol["max_det"] or any(row["confidence"] < protocol["prediction_confidence"] for row in predictions):
                    raise ValueError("Per-pass predictions violate count/confidence floor")
                mapped = map_predictions(predictions, crop, record["width"], record["height"], pass_id)
                observation = {**observation_identity, **value, "global_predictions": mapped,
                               "elapsed_seconds": attempt["elapsed_seconds"], "gpu_seconds": attempt["gpu_seconds"],
                               "call_index": attempt["call_index"], "environment_identity": environment_identity}
                if not budget["resumable"]:
                    raise RuntimeError("Unknown GPU time forbids a successful observation")
                _check_budget(budget, protocol)
                shared.check()
                filename = f"checkpoints/{image_index:04d}-{pass_id}.json"
                metadata = write_immutable_json(directory / filename,
                    {"identity": observation_identity, "environment_identity": environment_identity,
                     "observation": observation, "observation_sha256": _canonical(observation)})
                entry = {"image_id": record["image_id"], "pass_id": pass_id, "relative_path": filename,
                         **metadata, "call_index": attempt["call_index"]}
                index["checkpoints"].append(entry)
                completed[key] = entry
                save_budget()
                journal.checkpoint(entry)
                if len(index["checkpoints"]) == 1:
                    journal.snapshot()
        _check_budget(budget, protocol)
        shared.check()
        if len(index["checkpoints"]) != 18:
            raise ValueError("Worker lacks the complete fixed two-image observation population")
        final_environment = backend.environment()
        validate_inference_controls(final_environment)
        environment = {**environment, **final_environment,
                       "peak_allocated_bytes": max(environment.get("peak_allocated_bytes", 0), final_environment.get("peak_allocated_bytes", 0))}
        _write(directory / "environment.json", environment)
        budget["inference_finished_at"], budget["inference_finished_epoch"] = _timestamp(), time.time()
        segment["utc_finished"] = _timestamp()
        save_budget()
        journal.snapshot()
        publication = journal.publish("completed")
        receipt = {"status": "completed", "arm": request["arm"], "observations": len(index["checkpoints"]),
                   "real_detector_used": backend_factory is DetectorBackend,
                   "fault_consumed": consumed_fault, "environment_sha256": _sha256(directory / "environment.json"),
                   **publication, "journal_version": 2, "journal_file_sha256": _sha256(directory / JOURNAL_FILE),
                   "journal_file_size_bytes": (directory / JOURNAL_FILE).stat().st_size, "durability_io": journal.stats}
        _write(directory / "worker_receipt.json", receipt)
        return receipt
    except Exception as error:
        segment["utc_finished"] = _timestamp()
        save_budget()
        publication_error = None
        try:
            if journal is not None:
                journal.snapshot()
                journal.publish("failed")
        except Exception as final_error:
            publication_error = {"type": type(final_error).__name__, "message": str(final_error)}
            journal.close()
            recover_stopped_worker(directory, request, protocol)
            budget = _read(directory / "budget.json")
        receipt = {"status": "failed", "arm": request["arm"], "real_detector_used": backend_factory is DetectorBackend,
                   "error": {"type": type(error).__name__, "message": str(error)},
                   "observations": budget["successful_observations"], "resumable": budget["resumable"]}
        if publication_error:
            receipt["publication_error"] = publication_error
        _write(directory / "worker_receipt.json", receipt)
        return receipt
    finally:
        if journal is not None:
            journal.close()
        if backend is not None:
            backend.close()


def main():
    receipt = _execute(_read(sys.argv[1]))
    return 0 if receipt["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
