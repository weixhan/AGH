"""Independent analytic geometry reference and a frozen golden fixture suite.

The reference computes the enclosing box from analytic rectangle extents. It
does not import the production conversion or dataset checking implementation.
"""
from __future__ import annotations

from collections.abc import Mapping, Set
import hashlib
import json
import math
from pathlib import Path
from typing import Any


FIXTURE_PATH = Path(__file__).resolve().parents[1] / "fixtures" / "geometry_cases.json"
EXPECTED_FIXTURE_SHA256 = "91a0b738eb0dde7a4da6c8f6febefa364a6e945bd61ba0df268e0f72d2b8bf67"
_CLIPPED_TOLERANCE_PX = 1e-8
_SPECIAL_VALUES = {"NaN": float("nan"), "Infinity": float("inf"), "-Infinity": -float("inf")}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _number(value: Any, name: str) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a finite number, not a boolean")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(f"{name} must be a finite number") from exc
    if not math.isfinite(result):
        raise ValueError(f"{name} must be finite")
    return result


def oracle_geometry(bbox, rotation, image_width, image_height) -> dict:
    """Return ordered rotated vertices, analytic HBB, clipping and YOLO box.

    COCO xywh is rotated clockwise in image coordinates around its centre.
    Vertices retain the original top-left, top-right, bottom-right, bottom-left
    order. Clipping follows rotation and enclosure. The clipping flag uses the
    hbb_v1 numerical tolerance of 1e-8 pixels for finite nonempty intersections.
    """
    if isinstance(bbox, (str, bytes, Mapping, Set)):
        raise ValueError("bbox must contain four xywh values")
    try:
        values = list(bbox)
    except TypeError as exc:
        raise ValueError("bbox must contain four xywh values") from exc
    if len(values) != 4:
        raise ValueError("bbox must contain four xywh values")
    x, y, width, height = [_number(value, f"bbox[{index}]") for index, value in enumerate(values)]
    angle = _number(rotation, "rotation")
    image_width = _number(image_width, "image_width")
    image_height = _number(image_height, "image_height")
    if width <= 0 or height <= 0 or image_width <= 0 or image_height <= 0:
        raise ValueError("Box and image dimensions must be positive")
    centre_x, centre_y = x + width / 2, y + height / 2
    radians = math.radians(angle % 360.0)
    cosine, sine = math.cos(radians), math.sin(radians)
    corners = [
        [centre_x + dx * cosine - dy * sine, centre_y + dx * sine + dy * cosine]
        for dx, dy in ((-width / 2, -height / 2), (width / 2, -height / 2),
                       (width / 2, height / 2), (-width / 2, height / 2))
    ]
    # The reference HBB is independent of extrema over the computed vertices.
    extent_x = (abs(width * cosine) + abs(height * sine)) / 2
    extent_y = (abs(width * sine) + abs(height * cosine)) / 2
    enclosing = [centre_x - extent_x, centre_y - extent_y,
                 centre_x + extent_x, centre_y + extent_y]
    if not all(math.isfinite(value) for value in enclosing + [v for p in corners for v in p]):
        raise ValueError("Geometry calculation overflowed finite coordinates")
    clipped_box = [max(0.0, min(image_width, enclosing[0])),
                   max(0.0, min(image_height, enclosing[1])),
                   max(0.0, min(image_width, enclosing[2])),
                   max(0.0, min(image_height, enclosing[3]))]
    clipped = any(abs(actual - reference) > _CLIPPED_TOLERANCE_PX
                  for actual, reference in zip(enclosing, clipped_box))
    left, top, right, bottom = clipped_box
    if right <= left or bottom <= top:
        hbb, yolo, clipped = None, None, True
    else:
        hbb = clipped_box
        yolo = [(left / image_width + right / image_width) / 2,
                (top / image_height + bottom / image_height) / 2,
                (right - left) / image_width, (bottom - top) / image_height]
    return {"corners": corners, "unclipped_hbb": enclosing,
            "hbb": hbb, "yolo": yolo, "clipped": clipped}


def _decode_input(value):
    if isinstance(value, str) and value in _SPECIAL_VALUES:
        return _SPECIAL_VALUES[value]
    if isinstance(value, list):
        return [_decode_input(item) for item in value]
    if isinstance(value, dict):
        return {key: _decode_input(item) for key, item in value.items()}
    return value


def _safe_value(value):
    if isinstance(value, float) and not math.isfinite(value):
        return "NaN" if math.isnan(value) else ("Infinity" if value > 0 else "-Infinity")
    if isinstance(value, (list, tuple)):
        return [_safe_value(item) for item in value]
    if isinstance(value, dict):
        return {key: _safe_value(item) for key, item in value.items()}
    return value


def _differences(actual, expected, tolerance: float, field: str) -> list[dict]:
    if isinstance(expected, list):
        if not isinstance(actual, (list, tuple)) or len(actual) != len(expected):
            return [{"field": field, "expected": expected, "actual": _safe_value(actual)}]
        return [difference for index, (a, e) in enumerate(zip(actual, expected))
                for difference in _differences(a, e, tolerance, f"{field}[{index}]")]
    if isinstance(expected, bool):
        equal = isinstance(actual, bool) and actual == expected
    elif isinstance(expected, (int, float)):
        equal = (not isinstance(actual, bool) and isinstance(actual, (int, float))
                 and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance))
    else:
        equal = actual == expected
    return [] if equal else [{"field": field, "expected": expected, "actual": _safe_value(actual)}]


def _run_fixture_case(case: dict) -> dict:
    result = {"id": case["id"], "kind": case["kind"], "source": case["source"],
              "status": "failed", "expected_error": case.get("expected_error"), "differences": []}
    try:
        actual = oracle_geometry(**_decode_input(case["input"]))
    except Exception as exc:
        if case.get("expected_error") == "ValueError" and isinstance(exc, ValueError):
            result["status"] = "passed"
        else:
            result["differences"] = [{"field": "exception", "expected": case.get("expected_error"),
                                       "actual": {"type": type(exc).__name__, "message": str(exc)}}]
        return result
    if case.get("expected_error"):
        result["differences"] = [{"field": "exception", "expected": case["expected_error"], "actual": None}]
        return result
    result["actual"] = _safe_value(actual)
    tolerances = case.get("tolerances", {})
    for field in ("corners", "unclipped_hbb", "hbb", "yolo", "clipped"):
        tolerance = float(tolerances.get("yolo_absolute" if field == "yolo" else "coordinate_absolute",
                                         1e-10 if field == "yolo" else 1e-8))
        result["differences"].extend(_differences(actual.get(field), case["expected"][field], tolerance, field))
    result["status"] = "failed" if result["differences"] else "passed"
    return result


def run_fixture_suite() -> dict:
    """Check frozen golden answers; missing/changed fixtures cannot pass."""
    result = {"status": "failed", "cases": [],
              "counts": {"total": 0, "passed": 0, "failed": 0, "synthetic": 0, "real": 0, "expected_errors": 0},
              "evidence": {"oracle": {"path": str(Path(__file__).resolve()), "sha256": _sha256(Path(__file__)),
                                        "implementation": "analytic_center_and_rectangle_extents"},
                           "fixtures": {"path": str(FIXTURE_PATH.resolve()), "sha256": None,
                                         "expected_sha256": EXPECTED_FIXTURE_SHA256, "hash_verified": False},
                           "independent_of_production_geometry": True}, "errors": []}
    try:
        digest = _sha256(FIXTURE_PATH)
        result["evidence"]["fixtures"]["sha256"] = digest
        if digest != EXPECTED_FIXTURE_SHA256:
            raise ValueError("Frozen geometry fixture SHA256 differs from the pinned reference")
        result["evidence"]["fixtures"]["hash_verified"] = True
        document = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))
        cases = document["cases"]
        if document.get("schema_version") != 1 or not isinstance(cases, list) or len(cases) < 12:
            raise ValueError("Geometry fixtures need schema_version=1 and at least 12 cases")
        if len({case["id"] for case in cases}) != len(cases):
            raise ValueError("Geometry fixture IDs must be unique")
        result["cases"] = [_run_fixture_case(case) for case in cases]
        result["counts"] = {
            "total": len(cases), "passed": sum(item["status"] == "passed" for item in result["cases"]),
            "failed": sum(item["status"] == "failed" for item in result["cases"]),
            "synthetic": sum(case["kind"] == "synthetic" for case in cases),
            "real": sum(case["kind"] == "real" for case in cases),
            "expected_errors": sum(case.get("expected_error") == "ValueError" for case in cases),
        }
        if _sha256(FIXTURE_PATH) != digest:
            raise ValueError("Frozen geometry fixtures changed during the suite")
        result["status"] = "passed" if result["counts"]["failed"] == 0 else "failed"
    except Exception as exc:
        result["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    return result
