"""Load path configuration without accepting paths from model tool arguments."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
PATH_KEYS = (
    "research_root", "dataset_root", "raw_root", "split_dir", "weights_path", "output_root"
)


def load_config(path: str | Path | None = None) -> dict[str, str]:
    config_path = Path(path or os.environ.get(
        "DEFECT_RESEARCHER_CONFIG", PROJECT_ROOT / "config" / "local.json"
    )).resolve()
    data: Any = json.loads(config_path.read_text(encoding="utf-8-sig"))
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        raise ValueError("Configuration must be an object with schema_version=1")
    unknown = set(data) - set(PATH_KEYS) - {"schema_version"}
    if unknown:
        raise ValueError(f"Unknown configuration fields: {', '.join(sorted(unknown))}")
    # The project directory is the base for the distributed config/ files.
    base = config_path.parent.parent if config_path.parent.name == "config" else config_path.parent
    resolved: dict[str, str] = {}
    for key in PATH_KEYS:
        value = data.get(key)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"Configuration field {key} must be a nonempty path")
        for reference, replacement in resolved.items():
            value = value.replace("${" + reference + "}", replacement)
        if "${" in value:
            raise ValueError(f"Unresolved path reference in {key}")
        candidate = Path(value).expanduser()
        resolved[key] = str((candidate if candidate.is_absolute() else base / candidate).resolve())
    output = Path(resolved["output_root"])
    for key in PATH_KEYS[:-1]:
        protected = Path(resolved[key])
        if output == protected or protected in output.parents or output in protected.parents:
            raise ValueError(f"output_root must be separate from {key}")
    return resolved

