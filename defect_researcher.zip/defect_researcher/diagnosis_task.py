"""Diagnose a sealed validation experiment without running a detector again."""
from __future__ import annotations

import json
from pathlib import Path
import re
import uuid

from .audit import _artifact_record, _atomic_text, _configured_paths, _sha256, _timestamp

TOOL = "diagnose_validation_errors"
PROTOCOL_PATH = Path(__file__).resolve().parents[1] / "fixtures" / "diagnosis_protocol.json"
FILES = {
    "protocol": "protocol.json", "inputs": "inputs.json", "events": "events.jsonl",
    "summary": "diagnosis_summary.json", "gt_details": "gt_details.jsonl",
    "fp_details": "fp_details.jsonl", "threshold_analysis": "threshold_analysis.json",
    "decision": "decision.json", "report": "diagnosis_report.md",
    "result": "diagnosis_result.json", "manifest": "artifact_manifest.json",
    "completion": "completion.json",
}
LIMITATIONS = [
    "Candidate categories describe saved post-NMS predictions, not proven causes of an error.",
    "Predictions below 0.001 or suppressed by NMS are unavailable; absent saved candidates do not prove absence before NMS.",
    "Threshold selection uses an already viewed validation set and is not an independent held-out improvement.",
    "Frames may be correlated; minimum counts are workflow gates, not statistical significance tests.",
    "The normal-image FP budget preserves the reference count, not an established deployment requirement; total false-positive boxes may increase.",
    "No new training, detector inference, test evaluation, threshold deployment or sliced inference is performed by this task.",
]


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def _write(path, value):
    _atomic_text(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _event(directory, stage, status, **details):
    with (directory / FILES["events"]).open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"at": _timestamp(), "stage": stage, "status": status, **details},
                                ensure_ascii=False, allow_nan=False) + "\n")


def _protocol():
    value = _read(PROTOCOL_PATH)
    required = {"schema_version": 1, "source_task_id": "8d1d6900c7d74c90a29824495684807d",
                "split": "val", "expected_images": 640, "expected_gt": 596,
                "reference_eval_imgsz": 640, "descriptive_eval_imgsz": 960,
                "confidence_threshold": .25, "iou_threshold": .5, "prediction_floor": .001,
                "threshold_grid": [.05, .10, .15, .20, .25, .30, .40, .50],
                "normal_fp_budget": 5 / 245, "max_normal_fp_images": 5,
                "min_tp_gain": 5, "min_gain_images": 5, "min_scale_gt": 20, "min_scale_fn": 10,
                "new_inference_budget": 0, "training_performed": False,
                "test_inference_performed": False, "automatically_apply_threshold": False}
    if not isinstance(value, dict):
        raise ValueError("Diagnostic protocol must be an object")
    for key, target in required.items():
        if value.get(key) != target or type(value.get(key)) is not type(target):
            raise ValueError(f"Frozen diagnostic protocol differs: {key}")
    return value


def _load_source(paths, protocol):
    from .task_runtime import _completed_report, COMPARISON_TOOL
    from .resolution_comparison import _prepare_inputs, _protocol as comparison_protocol

    source_dir = paths["output_root"] / protocol["source_task_id"]
    source_report = _completed_report(source_dir, protocol["source_task_id"], COMPARISON_TOOL)
    if source_report["configuration"] != {key: str(value) for key, value in paths.items()}:
        raise ValueError("Source comparison configuration differs")
    expected_records, current_sources, _ = _prepare_inputs(paths, comparison_protocol())
    old_inputs = _read(source_dir / "inputs.json")
    if old_inputs.get("all_unchanged") is not True:
        raise ValueError("Source comparison inputs were not unchanged")
    sources, expected_hashes = {}, {}
    approved_roots = tuple(path.resolve() for path in paths.values())
    project_root = Path(__file__).resolve().parents[1]
    for index, entry in enumerate(old_inputs["files"]):
        path = Path(entry["path"]).resolve()
        if not any(path == root or path.is_relative_to(root) for root in (*approved_roots, project_root)):
            raise ValueError("Source input outside configured roots")
        if entry.get("unchanged") is not True or entry.get("sha256_before") != entry.get("sha256_after"):
            raise ValueError("Source input has inconsistent hash evidence")
        key = f"source_input/{index}/{entry['role']}"
        sources[key], expected_hashes[key] = path, entry["sha256_after"]
    known_paths = {path.resolve() for path in sources.values()}
    for key, path in current_sources.items():
        if path.resolve() not in known_paths:
            sources[f"current/{key}"] = path
            known_paths.add(path.resolve())
    # Include the entire sealed parent contract, not just prediction files.
    manifest = _read(source_dir / "artifact_manifest.json")
    for name in ["completion.json", "artifact_manifest.json", *[r["name"] for r in manifest["files"]]]:
        path = (source_dir / name).resolve()
        if path.parent != source_dir.resolve():
            raise ValueError("Source artifact outside source task")
        sources[f"source_artifact/{name}"] = path
    sources.update({"diagnostic_protocol": PROTOCOL_PATH, "diagnostic_runner": Path(__file__).resolve(),
                    "diagnostic_core": Path(__file__).with_name("detection_diagnosis.py")})
    before = {role: {**_artifact_record(path), "role": role} for role, path in sorted(sources.items())}
    for role, expected_hash in expected_hashes.items():
        if before[role]["sha256"] != expected_hash:
            raise ValueError(f"Source input changed since comparison: {role}")
    arms = {}
    for size in (640, 960):
        records = [json.loads(line) for line in (source_dir / f"predictions_{size}.jsonl").read_text(encoding="utf-8").splitlines()]
        if len(records) != len(expected_records):
            raise ValueError("Prediction image membership count differs")
        expected_lookup = {r["image_id"]: r for r in expected_records}
        if len({r["image_id"] for r in records}) != len(records):
            raise ValueError("Duplicate prediction image ID")
        for record in records:
            expected = expected_lookup.get(record["image_id"])
            if expected is None or any(record.get(key) != value for key, value in expected.items()):
                raise ValueError(f"Saved GT, dimensions or source identity differs: {record['image_id']}")
            if record.get("eval_imgsz") != size or record.get("precision") != "FP32":
                raise ValueError("Saved prediction protocol differs")
            if any(pred.get("confidence", 0) < protocol["prediction_floor"] for pred in record["predictions"]):
                raise ValueError("Saved prediction below frozen confidence floor")
        arms[size] = records
    if len(expected_records) != protocol["expected_images"] or sum(len(r["ground_truth"]) for r in expected_records) != protocol["expected_gt"]:
        raise ValueError("Diagnostic population differs from frozen protocol")
    return source_dir, sources, before, arms


def _report(result, reference, descriptive):
    summary = reference["summary"]
    rows = ["# 验证集漏检与误报诊断", "", f"任务：`{result['task_id']}`。来源：`{result['evidence']['source_task_id']}`。",
            "", "复用已保存的同权重验证集预测；本轮没有运行新的检测推理、训练或测试集评估。",
            "", "## 参考结果与诊断", "", "```json", json.dumps(summary, ensure_ascii=False, indent=2), "```",
            "", "候选分类是几何与置信度证据，不能据此认定错误的真实原因。",
            "", "## 阈值分析与研究分支", "", "```json",
            json.dumps({"selection": reference["selection"], "recommendations": reference["recommendations"]}, ensure_ascii=False, indent=2),
            "```", "", "阈值候选已预先冻结；正常图误报预算保持参考的5/245，至少增加5个TP且涉及至少5张图。这个预算是本轮诊断约束，实际部署预算仍需确定。",
            "", "逐框证据见 gt_details.jsonl / fp_details.jsonl；阈值完整计数见 threshold_analysis.json。",
            "", "## 960描述性参照", "", "```json", json.dumps(descriptive["summary"], ensure_ascii=False, indent=2), "```",
            "", "## 使用限制", ""]
    rows.extend(f"- {line}" for line in result["limitations"])
    return "\n".join(rows) + "\n"


def run_diagnosis(configuration, task_id=None):
    task_id = task_id or f"diagnosis-{uuid.uuid4().hex}"
    result = {"task_id": task_id, "tool": TOOL, "status": "running", "started_at": _timestamp(), "finished_at": None,
              "configuration": {}, "summary": {}, "evidence": {}, "artifacts": {}, "errors": [], "limitations": list(LIMITATIONS)}
    directory, stage = None, "configuration"
    try:
        if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
            raise ValueError("task_id must be a safe single directory name")
        paths = _configured_paths(configuration)
        result["configuration"] = {key: str(value) for key, value in paths.items()}
        destination = paths["output_root"] / task_id
        destination.mkdir(parents=True, exist_ok=False)
        directory = destination
        protocol = _protocol()
        _event(directory, stage, "passed")
        stage = "source_evidence_validation"
        source_dir, sources, before, records = _load_source(paths, protocol)
        result["evidence"] = {"source_task_id": protocol["source_task_id"],
                              "source_completion_sha256": _sha256(source_dir / "completion.json"),
                              "source_manifest_sha256": _sha256(source_dir / "artifact_manifest.json"),
                              "predictions_640_sha256": _sha256(source_dir / "predictions_640.jsonl"),
                              "predictions_960_sha256": _sha256(source_dir / "predictions_960.jsonl"),
                              "protocol_sha256": _sha256(PROTOCOL_PATH), "evidence_id": f"diagnosis:{task_id}:640"}
        _write(directory / FILES["protocol"], {**protocol, "task_id": task_id, **result["evidence"]})
        _event(directory, stage, "passed", images=640, gt=596, source_files=len(sources))
        stage = "diagnosis"
        from .detection_diagnosis import diagnose_detections
        from .geometry_verifier import CATEGORIES
        options = {key: protocol[key] for key in ("prediction_floor", "normal_fp_budget", "max_normal_fp_images",
                                                  "min_tp_gain", "min_gain_images", "min_scale_gt", "min_scale_fn")}
        options["threshold_grid"] = tuple(protocol["threshold_grid"])
        names = {key - 1: value for key, value in CATEGORIES.items()}
        diagnostics = {size: diagnose_detections(arm, names, protocol["confidence_threshold"], protocol["iou_threshold"], **options)
                       for size, arm in records.items()}
        reference, descriptive = diagnostics[640], diagnostics[960]
        for diagnostic in diagnostics.values():
            diagnostic["summary"]["operating_point"] = diagnostic["operating_point"]
        # Persist aggregate summaries and the full 640 evidence without image pixels.
        _write(directory / FILES["summary"], {"reference": reference["summary"], "descriptive_960": descriptive["summary"],
                    **{key: reference[key] for key in ("per_class", "per_size", "per_region")}})
        for key in ("gt_details", "fp_details"):
            _atomic_text(directory / FILES[key], "".join(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n" for row in reference[key]))
        _write(directory / FILES["threshold_analysis"], {"protocol": reference["protocol"], "curve": reference["threshold_curve"], "selection": reference["selection"]})
        _write(directory / FILES["decision"], {"evidence_id": result["evidence"]["evidence_id"], "source_task_id": protocol["source_task_id"],
                    "predictions_sha256": result["evidence"]["predictions_640_sha256"], "selection": reference["selection"],
                    "recommendations": reference["recommendations"], "new_inference_budget": 0, "automatically_applied": False,
                    "claim_scope": protocol["claim_scope"]})
        _event(directory, stage, "passed", reference=reference["summary"])
        stage = "input_recheck"
        checked = []
        for role, entry in before.items():
            current = _artifact_record(sources[role])
            checked.append({"role": role, "path": entry["path"], "size_bytes": entry["size_bytes"],
                            "sha256_before": entry["sha256"], "sha256_after": current["sha256"],
                            "unchanged": current == {k: v for k, v in entry.items() if k != "role"}})
        unchanged = all(row["unchanged"] for row in checked)
        _write(directory / FILES["inputs"], {"task_id": task_id, "files": checked, "all_unchanged": unchanged,
                                            "source_task_id": protocol["source_task_id"], **result["evidence"]})
        if not unchanged:
            raise ValueError("Input changed during diagnosis")
        result["summary"] = {"diagnosis_status": "passed", "split": "val", "reference_eval_imgsz": 640,
                             "input_files": len(checked), "input_hashes_unchanged": True,
                             "new_inference_performed": False, "training_performed": False, "test_inference_performed": False,
                             "reference": reference["summary"], "descriptive_960": descriptive["summary"],
                             "threshold_selection": reference["selection"], "recommendations": reference["recommendations"]}
        _event(directory, stage, "passed", input_files=len(checked))
        stage = "artifact_publication"
        result["status"], result["finished_at"] = "completed", _timestamp()
        result["artifacts"] = {key: str(directory / name) for key, name in FILES.items()}
        _atomic_text(directory / FILES["report"], _report(result, reference, descriptive))
        _event(directory, stage, "ready", completion_published_last=True)
        _write(directory / FILES["result"], result)
        artifacts = [_artifact_record(directory / name) for key, name in FILES.items() if key not in ("manifest", "completion")]
        manifest_path = directory / FILES["manifest"]
        _write(manifest_path, {"task_id": task_id, "tool": TOOL, "status": "completed", "files": artifacts, "input_evidence": result["evidence"]})
        for artifact in artifacts:
            if _artifact_record(Path(artifact["path"])) != artifact:
                raise ValueError("Artifact changed before publication")
        _write(directory / FILES["completion"], {"task_id": task_id, "tool": TOOL, "status": "completed", "finished_at": result["finished_at"],
                   "artifact_manifest": str(manifest_path), "artifact_manifest_sha256": _sha256(manifest_path),
                   "artifacts_sha256": {a["name"]: a["sha256"] for a in artifacts}, **result["evidence"]})
        return result
    except Exception as error:
        result["status"], result["finished_at"] = "failed", _timestamp()
        result["errors"].append({"stage": stage, "type": type(error).__name__, "message": str(error)})
        if directory is not None and directory.exists():
            (directory / FILES["completion"]).unlink(missing_ok=True)
            _event(directory, stage, "failed", error_type=type(error).__name__, message=str(error))
            _write(directory / "failure.json", result)
        return result
