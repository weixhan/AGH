"""Read fixed, sealed validation evidence; no detector or production scorer."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTRATION = ROOT / "fixtures/research_science_sources_v1.json"
REGISTRATION_SHA256 = "64d0291afc70d683a5e0c0572a2fd5edcdb47b846d06b4e6516f13c4b814af1a"


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def unique(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f"Duplicate scientific evidence key: {key}")
        obj[key] = value
    return obj


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def file_record(path, role):
    path = Path(path).resolve()
    if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
        raise ValueError("Scientific evidence must not redirect through a link")
    return {"role": role, "path": str(path), "sha256": digest(path), "size_bytes": path.stat().st_size}


def _chain(registration):
    directory = (ROOT / registration["relative_directory"]).resolve()
    if not directory.is_relative_to(ROOT / "outputs"):
        raise ValueError("Scientific directory outside fixed outputs")
    marker_path, manifest_path = directory / "completion.json", directory / "artifact_manifest.json"
    if digest(marker_path) != registration["completion_sha256"] or digest(manifest_path) != registration["manifest_sha256"]:
        raise ValueError("Fixed scientific completion/manifest changed")
    marker, manifest = read(marker_path), read(manifest_path)
    if marker.get("status") not in ("passed", "completed") or marker.get("manifest_sha256", marker.get("artifact_manifest_sha256")) != registration["manifest_sha256"]:
        raise ValueError("Scientific completion does not bind manifest")
    entries = manifest.get("files", [])
    names = [entry.get("name") for entry in entries]
    if set(names) != set(registration["required_artifacts"]) or len(names) != len(set(names)):
        raise ValueError("Scientific artifact membership mismatch")
    files = [file_record(marker_path, registration["kind"] + "/completion"),
             file_record(manifest_path, registration["kind"] + "/manifest")]
    for item in entries:
        name = item["name"]
        if Path(name).name != name or "/" in name or "\\" in name:
            raise ValueError("Scientific artifact escapes directory")
        current = file_record(directory / name, registration["kind"] + "/" + name)
        if current["sha256"] != item["sha256"] or current["size_bytes"] != item["size_bytes"]:
            raise ValueError("Scientific artifact changed: " + name)
        if "path" in item and Path(item["path"]).resolve() != directory / name:
            raise ValueError("Scientific artifact path mismatch")
        if "artifacts_sha256" in marker and marker["artifacts_sha256"].get(name) != current["sha256"]:
            raise ValueError("Scientific marker artifact hash mismatch")
        files.append(current)
    return directory, files


def read_scientific_evidence():
    if digest(REGISTRATION) != REGISTRATION_SHA256:
        raise ValueError("Frozen scientific source registration changed")
    registration = read(REGISTRATION)
    if registration.get("new_inference_allowed") is not False or registration.get("selection_data") != "validation_only":
        raise ValueError("Scientific source scope changed")
    files = [file_record(REGISTRATION, "scientific_source_registration")]
    directories = {}
    for source in registration["sources"]:
        directory, records = _chain(source)
        directories[source["kind"]] = directory
        files.extend(records)
    reviewer = ROOT / registration["scale_reviewer"]["relative_path"]
    if digest(reviewer) != registration["scale_reviewer"]["sha256"]:
        raise ValueError("Independent scale reader changed")
    files.append(file_record(reviewer, "independent_scale_reader"))
    spec = importlib.util.spec_from_file_location("_research_independent_scale_reader_v1", reviewer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # Independently rederive saved-prediction matching. This does not invoke a model.
    current_scale = module.review(ROOT / "outputs" / module.TASK_ID)
    saved_scale = read(directories["scale"] / "scale_alignment.json")
    if current_scale["statistics"] != saved_scale["statistics"] or current_scale["source_chain"] != saved_scale["source_chain"]:
        raise ValueError("Saved scale appendix does not independently reproduce")
    for binding in current_scale["source_chain"]["bindings"]:
        files.append(file_record(binding["path"], "scale_source/" + binding["role"]))
    decision = read(directories["diagnosis"] / "decision.json")
    sliced = read(directories["slicing"] / "recovery_result.json")
    independent = read(directories["slicing"] / "independent_verification.json")
    if (independent.get("status") != "passed" or independent.get("passed_checks") != 99
            or independent.get("total_checks") != 99 or independent.get("scientific_status") != "stop"
            or independent.get("original_business_status") != "failed"
            or independent.get("original_pipeline_acceptance_passed") is not False):
        raise ValueError("Historical candidate lacks independent stopped evidence")
    old_failure = registration["original_failed_computation"]
    failed_dir = ROOT / old_failure["relative_directory"]
    if (failed_dir / "completion.json").exists() or digest(failed_dir / "failure.json") != old_failure["failure_sha256"]:
        raise ValueError("Original failed computation changed or was backfilled")
    files.append(file_record(failed_dir / "failure.json", "original_failed_computation"))
    point = read(ROOT / "outputs" / module.TASK_ID / "metrics_640.json")
    larger = read(ROOT / "outputs" / module.TASK_ID / "metrics_960.json")
    stats = current_scale["statistics"]["results"]
    def scale(key, identity):
        a, b = stats["640"]["scale_definitions"][key], stats["960"]["scale_definitions"][key]
        return {"definition_id": identity, "gt": a["gt"], "tp_640": a["tp"], "tp_960": b["tp"],
                "recall_640": a["recall"], "recall_960": b["recall"]}
    candidate = sliced["summary"]
    if candidate["candidate_status"] != "stop" or candidate["failed_gates"] != independent["failed_scientific_gates"]:
        raise ValueError("Candidate gate findings differ from independent evidence")
    summary = {
        "posthoc_no_new_inference": True, "analysis_executed_now": True,
        "original_all_inputs_rehashed": False, "scope": "sealed_validation_evidence_reuse",
        "relative_small": scale("plan_area_ratio_lt_0_005", "area_ratio_lt_0_005"),
        "tiny_small": scale("implemented_area_lt_1024_px2", "area_lt_1024_px2"),
        "resolution": {"map50_640": point["mAP50"], "map50_960": larger["mAP50"],
                       "fp_640": point["operating_point"]["fp"], "fp_960": larger["operating_point"]["fp"],
                       "normal_fp_640": point["operating_point"]["normal_images_with_false_positives"],
                       "normal_fp_960": larger["operating_point"]["normal_images_with_false_positives"],
                       "status": "local_gain_with_overall_cost"},
        "diagnosis": {"threshold_status": decision["selection"]["status"],
                      "next_branch": decision["recommendations"]["next_branch"]},
        "slicing": {"candidate_status": candidate["candidate_status"], "failed_gates": candidate["failed_gates"],
                    "map50_baseline": candidate["baseline"]["mAP50"], "map50_sliced": candidate["sliced"]["mAP50"],
                    "fp_baseline": candidate["baseline"]["fp"], "fp_sliced": candidate["sliced"]["fp"]},
    }
    if any(digest(row["path"]) != row["sha256"] for row in files):
        raise ValueError("Scientific source changed during bounded review")
    return {"kind": "science", "origin": "historical_reuse", "summary": summary, "files": files,
            "limitations": ["No fresh detector execution; independent recalculation of sealed predictions only.",
                            "Historical 99-check candidate review is source-bound, not rerun over all images here.",
                            "Synthetic input verification and real saved validation results are separate populations."]}
