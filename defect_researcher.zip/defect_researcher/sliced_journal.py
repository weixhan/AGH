"""Version 2 durability only; this module does not call a detector.

The worker keeps its existing in-memory budget and checkpoint index. Instead of
serializing their growing arrays on every prediction, call ``started`` before
``predict``, ``finished`` after recording its timing, and ``checkpoint`` after an
immutable checkpoint has been fsynced. ``snapshot`` writes only bounded scalar
progress; ``publish`` writes the legacy full budget/index once at worker exit.

The append-only journal is the recovery authority. A stale progress snapshot is
never used to reconstruct calls. Version 1 caches are deliberately not imported:
the journal binds both the caller's execution source and this module's bytes.
There is one writer per task; a live reader may observe an unfinished final line
and must retry reading later, never truncate it or rerun a prediction.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
import json
import math
import os
from pathlib import Path
import re
import time
import uuid


JOURNAL_VERSION = 2
JOURNAL_FILE = "checkpoint_journal.jsonl"
SNAPSHOT_FILE = "budget_snapshot.json"
MAX_SNAPSHOT_BYTES = 16_384
REPLACE_RETRY_SECONDS = .15
_WINDOWS_RETRY_ERRORS = frozenset((5, 32, 33))
_CAPS = {"successful_observations": 5760, "max_formal_calls": 5770,
         "max_failed_pass_retries": 10, "max_warmup_calls": 1,
         "max_gpu_seconds": 900, "max_inference_wall_seconds": 900,
         "max_task_wall_seconds": 1800}
_IDENTITY_KEYS = ("protocol_sha256", "weight_sha256", "scientific_inputs_sha256",
                  "execution_source_sha256")
_WALL_KEYS = ("task_started_epoch", "inference_started_epoch", "gpu_seconds",
              "task_wall_seconds", "inference_wall_seconds", "resumable")


class JournalError(ValueError):
    """A journal does not provide safe, canonical recovery evidence."""


def _bytes(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                       allow_nan=False) + "\n").encode("utf-8")


def _digest(value):
    return hashlib.sha256(_bytes(value)[:-1]).hexdigest()


def _file_sha256(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def _number(value, name, *, nullable=False):
    if nullable and value is None:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
        raise JournalError(f"Invalid nonnegative finite number: {name}")


def _integer(value, name, *, minimum=0):
    if type(value) is not int or value < minimum:
        raise JournalError(f"Invalid integer: {name}")


def _sha(value, name):
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None:
        raise JournalError(f"Invalid SHA256 identity: {name}")


def _limits(protocol):
    value = deepcopy(protocol["budgets"])
    if set(value) != set(_CAPS):
        raise JournalError("Budget fields differ from the fixed version 2 contract")
    for key, cap in _CAPS.items():
        _integer(value[key], key)
        if value[key] > cap:
            raise JournalError(f"The fixed scientific budget cannot be relaxed: {key}")
    if not value["successful_observations"] or value["max_formal_calls"] < value["successful_observations"]:
        raise JournalError("Invalid unique observation budget")
    return value


def execution_identity(identity):
    """Add the actual journal source hash to caller-supplied execution bindings."""
    result = deepcopy(identity)
    for key in _IDENTITY_KEYS:
        _sha(result.get(key), key)
    for key, value in result.items():
        _sha(value, key)
    current = _file_sha256(Path(__file__))
    if "journal_source_sha256" in result and result["journal_source_sha256"] != current:
        raise JournalError("Journal implementation changed; cached calls cannot be reused")
    result["journal_source_sha256"] = current
    return result


def _replace_bounded(source, destination):
    """Retry only the three Windows sharing/access errors, for at most 150 ms.

    This retries publication of the same already-fsynced bytes. It never invokes
    prediction, writes a different payload, or retries unrelated IO errors.
    """
    started, slept, delay = time.monotonic(), 0., .01
    while True:
        try:
            os.replace(source, destination)
            return
        except OSError as error:
            if getattr(error, "winerror", None) not in _WINDOWS_RETRY_ERRORS:
                raise
            remaining = REPLACE_RETRY_SECONDS - max(time.monotonic() - started, slept)
            if remaining <= 0:
                raise
            pause = min(delay, remaining)
            time.sleep(pause)
            slept += pause
            delay = min(delay * 2, .05)


def atomic_write_json(path, value):
    """Flush and fsync a unique sibling temporary file, then bounded replace."""
    path = Path(path)
    payload = _bytes(value)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        with temporary.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        _replace_bounded(temporary, path)
    finally:
        # The destination is never deleted to make a replace succeed.
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass  # Do not replace the original IO error with a cleanup error.
    return len(payload)


def write_immutable_json(path, value):
    """Create one checkpoint exclusively; an existing checkpoint is untouched."""
    path = Path(path)
    payload = _bytes(value)
    with path.open("xb") as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    return {"sha256": hashlib.sha256(payload).hexdigest(), "size_bytes": len(payload)}


def _wall(budget):
    result = {key: deepcopy(budget[key]) for key in _WALL_KEYS}
    for key in _WALL_KEYS[:-1]:
        _number(result[key], key, nullable=key == "inference_started_epoch")
    if type(result["resumable"]) is not bool:
        raise JournalError("resumable must be a boolean")
    return result


def _pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise JournalError(f"Duplicate JSON field: {key}")
        result[key] = value
    return result


def _read_json(data):
    def invalid(value):
        raise JournalError(f"Nonfinite JSON value: {value}")
    try:
        return json.loads(data, object_pairs_hook=_pairs, parse_constant=invalid)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise JournalError("Invalid or truncated JSON record") from error


def _checkpoint_path(directory, relative):
    if not isinstance(relative, str) or re.fullmatch(r"checkpoints/[A-Za-z0-9_-]+\.json", relative) is None:
        raise JournalError("Checkpoint path must be one safe file under checkpoints")
    root = (directory / "checkpoints").resolve()
    candidate = directory / relative
    if candidate.is_symlink() or candidate.resolve().parent != root:
        raise JournalError("Escaping or linked checkpoint path")
    return candidate


class _Ledger:
    def __init__(self, limits, identity, initial):
        self.limits, self.identity = limits, identity
        self.budget = deepcopy(initial)
        if (self.budget.get("formal_attempts") != [] or self.budget.get("warmup_attempts") != []
                or self.budget.get("formal_calls") != 0 or self.budget.get("warmup_calls") != 0
                or self.budget.get("successful_observations") != 0 or self.budget.get("gpu_seconds") != 0
                or self.budget.get("resumable") is not True):
            raise JournalError("A new version 2 journal must start empty; version 1 caches are not imported")
        _wall(self.budget)
        for key in ("schema_version", "formal_calls", "warmup_calls", "successful_observations"):
            _integer(self.budget.get(key), key)
        if self.budget["schema_version"] != 1:
            raise JournalError("Legacy budget fields must retain schema_version 1")
        self.index = {"schema_version": 1, "checkpoints": []}
        self.active = None
        self.checkpoint_keys, self.checkpoint_calls, self.checkpoint_paths = set(), set(), set()
        self.status, self.failed_calls, self.passed_calls, self.unknown_gpu = "running", 0, 0, False
        self.sequence, self.head, self.journal_bytes = 0, "0" * 64, 0
        self.file_digest = hashlib.sha256()
        self.uncertain_tail, self.tail_bytes = False, 0

    def check_limits(self, *, now_epoch=None):
        limits, budget = self.limits, self.budget
        for key, limit in (("formal_calls", "max_formal_calls"), ("warmup_calls", "max_warmup_calls"),
                           ("gpu_seconds", "max_gpu_seconds"), ("task_wall_seconds", "max_task_wall_seconds"),
                           ("inference_wall_seconds", "max_inference_wall_seconds")):
            if budget[key] > limits[limit]:
                raise JournalError(f"Recorded budget exceeded: {limit}")
        if self.failed_calls > limits["max_failed_pass_retries"]:
            raise JournalError("Failed pass retry budget exceeded")
        if now_epoch is not None:
            _number(now_epoch, "now_epoch")
            if now_epoch - budget["task_started_epoch"] > limits["max_task_wall_seconds"]:
                raise JournalError("Original absolute task deadline expired")
            inference = budget["inference_started_epoch"]
            if inference is not None and now_epoch - inference > limits["max_inference_wall_seconds"]:
                raise JournalError("Original absolute inference deadline expired")

    def update_wall(self, wall):
        for key in _WALL_KEYS:
            if key not in wall:
                raise JournalError("Missing budget clock field")
        _wall(wall)
        if wall["task_started_epoch"] != self.budget["task_started_epoch"]:
            raise JournalError("Absolute task start cannot change on recovery")
        prior = self.budget["inference_started_epoch"]
        if prior is not None and wall["inference_started_epoch"] != prior:
            raise JournalError("Absolute inference start cannot change on recovery")
        for key in ("task_wall_seconds", "inference_wall_seconds"):
            if wall[key] < self.budget[key]:
                raise JournalError("Cumulative wall-clock cost cannot decrease")
        if wall["gpu_seconds"] != self.budget["gpu_seconds"]:
            raise JournalError("GPU total differs from finished-call accounting")
        if wall["resumable"] and (self.unknown_gpu or self.budget["resumable"] is False):
            raise JournalError("Unknown GPU time must forbid recovery")
        self.budget.update(wall)

    def apply(self, event, payload):
        if self.status != "running" and event != "resumed":
            raise JournalError("A sealed journal cannot be appended")
        if event == "started":
            self.check_limits()
            if self.unknown_gpu or not self.budget["resumable"] or payload["wall"]["resumable"] is not True:
                raise JournalError("A nonresumable run cannot begin another prediction")
            kind, row = payload["kind"], deepcopy(payload["attempt"])
            if kind not in ("formal", "warmup") or self.active is not None:
                raise JournalError("Concurrent or unrecognized call")
            collection = self.budget[f"{kind}_attempts"]
            _integer(row.get("call_index"), "call_index", minimum=1)
            _integer(row.get("pass_id"), "pass_id")
            if row["pass_id"] > 8 or not isinstance(row.get("image_id"), str) or not row["image_id"]:
                raise JournalError("Invalid image/pass identity")
            if (row["call_index"] != len(collection) + 1 or row.get("status") != "started"
                    or not isinstance(row.get("utc_started"), str) or not row["utc_started"]
                    or any(row.get(key) is not None for key in ("utc_finished", "elapsed_seconds", "gpu_seconds"))):
                raise JournalError("Noncanonical, duplicate or completed started call")
            if len(collection) >= self.limits[f"max_{kind}_calls"]:
                raise JournalError("Call budget exhausted before prediction")
            if kind == "formal" and (row["image_id"], row["pass_id"]) in self.checkpoint_keys:
                raise JournalError("A durably cached pass cannot be predicted again")
            if payload["wall"]["inference_started_epoch"] is None:
                raise JournalError("Inference clock must start before prediction")
            self.update_wall(payload["wall"])
            self.check_limits()
            collection.append(row)
            self.budget[f"{kind}_calls"] = len(collection)
            self.active = (kind, row["call_index"])
        elif event == "finished":
            kind, row = payload["kind"], deepcopy(payload["attempt"])
            if self.active != (kind, row.get("call_index")):
                raise JournalError("Finish does not identify the one active call")
            prior = self.budget[f"{kind}_attempts"][-1]
            for key in ("call_index", "image_id", "pass_id", "utc_started"):
                if type(row.get(key)) is not type(prior[key]) or row[key] != prior[key]:
                    raise JournalError("Finished-call identity differs from its start")
            if row.get("status") not in ("passed", "failed") or not isinstance(row.get("utc_finished"), str) or not row["utc_finished"]:
                raise JournalError("Call finish lacks a terminal status/time")
            _number(row.get("elapsed_seconds"), "elapsed_seconds", nullable=True)
            _number(row.get("gpu_seconds"), "gpu_seconds", nullable=True)
            if row.get("elapsed_seconds") is None or row.get("gpu_seconds") is None:
                self.unknown_gpu = True
            if row.get("gpu_seconds") is not None:
                self.budget["gpu_seconds"] += row["gpu_seconds"]
            if kind == "formal" and row["status"] == "failed":
                self.failed_calls += 1
            elif kind == "formal":
                self.passed_calls += 1
            self.update_wall(payload["wall"])
            self.budget[f"{kind}_attempts"][-1] = row
            self.active = None
            # Over-limit finishes must still be durable; starting another call,
            # publishing success, or asking to resume will reject their cost.
        elif event == "checkpoint":
            self.check_limits()
            entry = deepcopy(payload["entry"])
            _integer(entry.get("call_index"), "checkpoint call_index", minimum=1)
            _integer(entry.get("pass_id"), "checkpoint pass_id")
            _integer(entry.get("size_bytes"), "checkpoint size_bytes", minimum=1)
            _sha(entry.get("sha256"), "checkpoint sha256")
            call = entry["call_index"]
            rows = self.budget["formal_attempts"]
            if call > len(rows) or self.active is not None or self.unknown_gpu:
                raise JournalError("Checkpoint lacks a closed known-cost formal call")
            row = rows[call - 1]
            key = (entry.get("image_id"), entry["pass_id"])
            if (row["status"] != "passed" or key != (row["image_id"], row["pass_id"])
                    or key in self.checkpoint_keys or call in self.checkpoint_calls
                    or entry.get("relative_path") in self.checkpoint_paths):
                raise JournalError("Duplicate checkpoint or checkpoint/call identity mismatch")
            if len(self.index["checkpoints"]) >= self.limits["successful_observations"]:
                raise JournalError("Unique checkpoint population exceeded")
            self.update_wall(payload["wall"])
            self.checkpoint_keys.add(key)
            self.checkpoint_calls.add(call)
            self.checkpoint_paths.add(entry["relative_path"])
            self.index["checkpoints"].append(entry)
            self.budget["successful_observations"] = len(self.index["checkpoints"])
        elif event in ("closed", "resumed"):
            if event == "resumed":
                if (self.status == "completed" or self.active is not None or self.unknown_gpu
                        or payload.get("prior_journal_sha256") != self.head
                        or type(payload.get("prior_journal_events")) is not int
                        or payload["prior_journal_events"] != self.sequence
                        or type(payload.get("prior_journal_bytes")) is not int
                        or payload["prior_journal_bytes"] != self.journal_bytes):
                    raise JournalError("Resume lacks the exact known-cost unfinished journal prefix")
                chain = payload["final_fields"].get("resume_chain")
                prior_chain = self.budget.get("resume_chain", [])
                if not isinstance(chain, list) or len(chain) != len(prior_chain) + 1 or chain[:-1] != prior_chain:
                    raise JournalError("Resume provenance must append exactly one record")
                binding = chain[-1]
                if not isinstance(binding.get("task_id"), str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", binding["task_id"]) is None:
                    raise JournalError("Unsafe prior resume task identity")
                for key in ("failure_sha256", "budget_sha256", "checkpoint_index_sha256",
                            "journal_head_sha256", "journal_file_sha256"):
                    _sha(binding.get(key), key)
                if (binding["journal_head_sha256"] != self.head
                        or binding["journal_file_sha256"] != self.file_digest.hexdigest()):
                    raise JournalError("Resume prefix hash differs")
                self.require_complete_cached_calls()
            status = payload.get("status")
            if event == "resumed":
                status = "running"
            elif status not in ("completed", "failed"):
                raise JournalError("Unknown publication status")
            self.update_wall(payload["wall"])
            final = payload["final_fields"]
            if any(key in final for key in ("formal_attempts", "warmup_attempts", *_WALL_KEYS)):
                raise JournalError("Closure cannot replace call arrays or budget totals")
            for key in ("formal_calls", "warmup_calls", "successful_observations"):
                _integer(final.get(key), key)
                if final[key] != self.budget[key]:
                    raise JournalError("Closed/resumed counters differ from the call ledger")
            self.budget.update(deepcopy(final))
            if status in ("completed", "running"):
                self.check_limits()
            if status == "completed":
                if self.active or self.unknown_gpu or not self.budget["resumable"] or len(self.index["checkpoints"]) != self.limits["successful_observations"]:
                    raise JournalError("Completion requires all known-cost unique checkpoints")
            self.status = status
        else:
            raise JournalError(f"Unknown journal event: {event}")

    def require_complete_cached_calls(self):
        if self.active is not None or self.unknown_gpu or self.budget["resumable"] is not True:
            raise JournalError("Unknown or unfinished device work cannot resume")
        if self.passed_calls != len(self.checkpoint_calls):
            raise JournalError("A passed call without a durable checkpoint cannot be repeated")

    def full_budget(self):
        result = deepcopy(self.budget)
        if self.active or self.unknown_gpu or self.uncertain_tail or self.passed_calls != len(self.checkpoint_calls):
            result["resumable"] = False
        if self.uncertain_tail:
            result.update(uncertain_journal_tail=True, unparsed_tail_bytes=self.tail_bytes)
        result.update(journal_version=JOURNAL_VERSION, journal_events=self.sequence,
                      journal_sha256=self.head, journal_bytes=self.journal_bytes)
        return result

    def full_index(self):
        return {**deepcopy(self.index), "journal_version": JOURNAL_VERSION,
                "journal_events": self.sequence, "journal_sha256": self.head}


class PassJournal:
    """Single-writer journal attached to the worker's existing budget/index.

    Update the worker's existing clock fields before each method. Append the
    started/finished row to its existing attempt collection as before. A journal
    IO failure is terminal for this writer, even if its last event is durable;
    callers must stop, inspect the journal, and never retry ``predict`` as part of
    an IO retry. Empty legacy seed files may already exist in the new task dir.
    """

    def __init__(self, directory, protocol, budget, index, identity):
        self.directory = Path(directory)
        if not self.directory.is_dir() or self.directory.is_symlink():
            raise JournalError("Use an existing, unlinked new task directory")
        self.protocol, self.identity = _limits(protocol), execution_identity(identity)
        if index.get("checkpoints") != []:
            raise JournalError("Version 1 checkpoint caches cannot seed a version 2 journal")
        self.budget, self.index = budget, index
        self._ledger = _Ledger(self.protocol, self.identity, budget)
        self._poisoned, self._published = False, False
        self.stats = {"journal_events": 0, "journal_bytes": 0, "snapshot_writes": 0,
                      "snapshot_bytes": 0, "max_snapshot_bytes": 0,
                      "full_budget_writes": 0, "full_index_writes": 0}
        self._stream = (self.directory / JOURNAL_FILE).open("xb")
        try:
            self._append("header", {"journal_version": JOURNAL_VERSION,
                                   "identity": self.identity, "limits": self.protocol,
                                   "initial_budget": deepcopy(budget)}, header=True)
            self.snapshot()
        except Exception:
            self._stream.close()
            raise

    def _usable(self):
        if self._poisoned or self._published or self._stream.closed:
            raise JournalError("Writer is closed/uncertain; prediction must not be retried")

    def _append(self, event, payload, *, header=False):
        self._usable()
        if not header:
            self._ledger.apply(event, payload)
        body = {"sequence": self._ledger.sequence + 1, "previous_sha256": self._ledger.head,
                "event": event, "payload": payload}
        record = {**body, "sha256": _digest(body)}
        data = _bytes(record)
        try:
            self._stream.write(data)
            self._stream.flush()
            os.fsync(self._stream.fileno())
        except Exception:
            self._poisoned = True
            raise
        self._ledger.sequence += 1
        self._ledger.head = record["sha256"]
        self._ledger.journal_bytes += len(data)
        self._ledger.file_digest.update(data)
        self.stats["journal_events"] += 1
        self.stats["journal_bytes"] += len(data)

    @classmethod
    def resume(cls, directory, protocol, budget, index, identity, *, now_epoch=None):
        """Append to an explicitly copied version 2 prefix in a NEW task dir.

        The parent must preserve the old directory, copy only verified immutable
        checkpoints plus its entire journal, and append one resume-chain binding.
        Execution bytes, absolute deadlines and all charged calls stay fixed.
        """
        directory = Path(directory)
        prior = _replay(directory, protocol, identity, verify_checkpoints=True, check_published=False)
        prior.require_complete_cached_calls()
        prior.check_limits(now_epoch=time.time() if now_epoch is None else now_epoch)
        if prior.status == "completed":
            raise JournalError("A completed journal cannot resume")
        if (budget["formal_attempts"] != prior.budget["formal_attempts"]
                or budget["warmup_attempts"] != prior.budget["warmup_attempts"]
                or index["checkpoints"] != prior.index["checkpoints"]):
            raise JournalError("Copied arrays differ from the original version 2 journal")
        if not budget.get("resume_chain") or budget["resume_chain"][-1].get("task_id") == directory.name:
            raise JournalError("Resume requires a distinct new task directory")
        _reject_orphan_checkpoints(directory, prior)
        self = cls.__new__(cls)
        self.directory, self.protocol, self.identity = directory, prior.limits, prior.identity
        self.budget, self.index, self._ledger = budget, index, prior
        self._poisoned, self._published = False, False
        self.stats = {"journal_events": 0, "journal_bytes": 0, "snapshot_writes": 0,
                      "snapshot_bytes": 0, "max_snapshot_bytes": 0,
                      "full_budget_writes": 0, "full_index_writes": 0}
        self._stream = (directory / JOURNAL_FILE).open("ab")
        final = {key: deepcopy(value) for key, value in budget.items()
                 if key not in ("formal_attempts", "warmup_attempts", *_WALL_KEYS)}
        try:
            self._append("resumed", {"prior_journal_sha256": prior.head,
                                     "prior_journal_events": prior.sequence,
                                     "prior_journal_bytes": prior.journal_bytes,
                                     "wall": _wall(budget), "final_fields": final})
            self.snapshot()
        except Exception:
            self._stream.close()
            raise
        return self

    def started(self, attempt, *, warmup=False):
        """Return only after the attempt is flushed/fsynced, before prediction."""
        self._append("started", {"kind": "warmup" if warmup else "formal",
                                 "attempt": deepcopy(attempt), "wall": _wall(self.budget)})

    def finished(self, attempt, *, warmup=False):
        """Durably close one call; unknown timing remains nonresumable."""
        self._append("finished", {"kind": "warmup" if warmup else "formal",
                                  "attempt": deepcopy(attempt), "wall": _wall(self.budget)})

    def checkpoint(self, entry):
        """Promote only a complete, fsynced immutable checkpoint into the ledger."""
        self._usable()
        _verify_checkpoint(self.directory, entry, self._ledger, self.identity)
        self._append("checkpoint", {"entry": deepcopy(entry), "wall": _wall(self.budget)})

    def snapshot(self):
        """Bounded scalar progress only; no growing arrays or checkpoint list."""
        self._usable()
        wall = _wall(self.budget)
        if wall["gpu_seconds"] != self._ledger.budget["gpu_seconds"]:
            raise JournalError("Snapshot GPU total differs from the durable call ledger")
        value = {"journal_version": JOURNAL_VERSION, "journal_events": self._ledger.sequence,
                 "journal_sha256": self._ledger.head, "journal_bytes": self._ledger.journal_bytes,
                 "identity_sha256": _digest(self.identity), **wall,
                 "formal_calls": len(self._ledger.budget["formal_attempts"]),
                 "warmup_calls": len(self._ledger.budget["warmup_attempts"]),
                 "successful_observations": len(self._ledger.index["checkpoints"]),
                 "failed_formal_calls": self._ledger.failed_calls,
                 "open_call": list(self._ledger.active) if self._ledger.active else None}
        value["resumable"] = (wall["resumable"] and self._ledger.active is None
                              and not self._ledger.unknown_gpu
                              and self._ledger.passed_calls == len(self._ledger.checkpoint_calls))
        size = len(_bytes(value))
        if size > MAX_SNAPSHOT_BYTES:
            raise JournalError("Progress snapshot exceeds its fixed byte bound")
        try:
            atomic_write_json(self.directory / SNAPSHOT_FILE, value)
        except Exception:
            self._poisoned = True
            raise
        self.stats["snapshot_writes"] += 1
        self.stats["snapshot_bytes"] += size
        self.stats["max_snapshot_bytes"] = max(self.stats["max_snapshot_bytes"], size)

    def publish(self, status):
        """Seal and publish the full legacy JSON documents once, on exit.

        This is worker evidence, never a task completion marker. The task parent
        must still enforce its independent deadline and scientific verification.
        A partial full-file publication is a failure and is not retried here.
        """
        self._usable()
        if self.budget["formal_attempts"] != self._ledger.budget["formal_attempts"] or self.budget["warmup_attempts"] != self._ledger.budget["warmup_attempts"]:
            raise JournalError("Worker attempt arrays differ from the append journal")
        if self.index["checkpoints"] != self._ledger.index["checkpoints"]:
            raise JournalError("Worker checkpoint index differs from the append journal")
        final = {key: deepcopy(value) for key, value in self.budget.items()
                 if key not in ("formal_attempts", "warmup_attempts", *_WALL_KEYS)}
        for key in ("formal_calls", "warmup_calls", "successful_observations"):
            if final[key] != self._ledger.budget[key]:
                raise JournalError("Worker counters differ from the append journal")
        self._append("closed", {"status": status, "wall": _wall(self.budget), "final_fields": final})
        self._published = True
        self._stream.close()
        atomic_write_json(self.directory / "budget.json", self._ledger.full_budget())
        self.stats["full_budget_writes"] += 1
        atomic_write_json(self.directory / "checkpoint_index.json", self._ledger.full_index())
        self.stats["full_index_writes"] += 1
        self.budget.update(self._ledger.full_budget())
        self.index.update(self._ledger.full_index())
        return {"status": status, "budget_sha256": _file_sha256(self.directory / "budget.json"),
                "checkpoint_index_sha256": _file_sha256(self.directory / "checkpoint_index.json"),
                "journal_sha256": self._ledger.head, "journal_events": self._ledger.sequence}

    def close(self):
        """Close without sealing after an IO failure; do not invent a finish."""
        self._stream.close()


def _verify_checkpoint(directory, entry, ledger, identity):
    path = _checkpoint_path(directory, entry.get("relative_path"))
    if not path.is_file() or path.stat().st_size != entry.get("size_bytes") or _file_sha256(path) != entry.get("sha256"):
        raise JournalError("Checkpoint bytes differ from their journal entry")
    checkpoint = _read_json(path.read_bytes())
    observation, inputs = checkpoint["observation"], checkpoint["identity"]
    canonical_observation = hashlib.sha256(json.dumps(observation, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()
    if canonical_observation != checkpoint.get("observation_sha256"):
        raise JournalError("Checkpoint observation canonical hash differs")
    call = entry.get("call_index")
    _integer(call, "checkpoint call_index", minimum=1)
    if call > len(ledger.budget["formal_attempts"]):
        raise JournalError("Checkpoint references an absent call")
    attempt = ledger.budget["formal_attempts"][call - 1]
    for key in ("image_id", "pass_id", "call_index", "elapsed_seconds", "gpu_seconds"):
        if type(observation.get(key)) is not type(attempt[key]) or observation[key] != attempt[key]:
            raise JournalError("Checkpoint observation/finished-call binding differs")
    for key in ("image_id", "pass_id"):
        if type(inputs.get(key)) is not type(entry[key]) or inputs[key] != entry[key]:
            raise JournalError("Checkpoint input identity differs from index")
    for key in ("protocol_sha256", "weight_sha256", "scientific_inputs_sha256"):
        if inputs.get(key) != identity[key] or observation.get(key) != identity[key]:
            raise JournalError("Checkpoint science/source identity differs")
    for key in ("source_image_sha256", "decoded_image_sha256", "input_pixels_sha256"):
        _sha(inputs.get(key), key)
        if inputs[key] != observation.get(key):
            raise JournalError("Checkpoint pixel identity differs from observation")
    for key, value in inputs.items():
        if type(observation.get(key)) is not type(value) or observation.get(key) != value:
            raise JournalError("Checkpoint inputs differ from the observed pass")
    _sha(checkpoint.get("environment_identity"), "environment_identity")
    if checkpoint["environment_identity"] != observation.get("environment_identity"):
        raise JournalError("Checkpoint environment identity differs")


@dataclass
class RecoveredJournal:
    budget: dict
    checkpoint_index: dict
    execution_identity: dict
    status: str
    journal_sha256: str
    journal_events: int
    journal_bytes: int
    uncertain_tail: bool = False
    unparsed_tail_bytes: int = 0


def _replay(directory, protocol, identity, *, verify_checkpoints, check_published,
            inspection_only_allow_truncated_tail=False):
    directory = Path(directory)
    limits, expected = _limits(protocol), execution_identity(identity)
    ledger = None
    with (directory / JOURNAL_FILE).open("rb") as stream:
        for number, line in enumerate(stream, 1):
            if not line.endswith(b"\n"):
                if inspection_only_allow_truncated_tail and ledger is not None:
                    ledger.uncertain_tail, ledger.tail_bytes = True, len(line)
                    break
                raise JournalError("Unfinished journal tail; do not truncate or resume")
            record = _read_json(line)
            if not isinstance(record, dict) or set(record) != {"sequence", "previous_sha256", "event", "payload", "sha256"}:
                raise JournalError("Noncanonical journal record fields")
            if type(record["sequence"]) is not int or record["sequence"] != number:
                raise JournalError("Missing or duplicated journal sequence")
            body = {key: value for key, value in record.items() if key != "sha256"}
            if record["sha256"] != _digest(body):
                raise JournalError("Journal record hash differs")
            if number == 1:
                payload = record["payload"]
                if (record["event"] != "header" or record["previous_sha256"] != "0" * 64
                        or payload.get("journal_version") != JOURNAL_VERSION
                        or payload.get("identity") != expected or payload.get("limits") != limits):
                    raise JournalError("Journal version, source identity or frozen budget differs")
                ledger = _Ledger(limits, expected, payload["initial_budget"])
            else:
                if record["previous_sha256"] != ledger.head:
                    raise JournalError("Journal hash chain is broken")
                ledger.apply(record["event"], record["payload"])
                if record["event"] == "checkpoint":
                    _checkpoint_path(directory, record["payload"]["entry"]["relative_path"])
                    if verify_checkpoints:
                        _verify_checkpoint(directory, record["payload"]["entry"], ledger, expected)
            ledger.sequence, ledger.head = number, record["sha256"]
            ledger.journal_bytes += len(line)
            ledger.file_digest.update(line)
    if ledger is None:
        raise JournalError("Empty journal")
    if check_published and ledger.status != "running":
        for filename, expected_value in (("budget.json", ledger.full_budget()), ("checkpoint_index.json", ledger.full_index())):
            if _read_json((directory / filename).read_bytes()) != expected_value:
                raise JournalError("Published full evidence differs from journal replay")
    return ledger


def _reject_orphan_checkpoints(directory, ledger):
    actual = {str(path.relative_to(directory)).replace("\\", "/")
              for path in (directory / "checkpoints").glob("*") if path.is_file()}
    if actual != ledger.checkpoint_paths:
        raise JournalError("Checkpoint directory contains unpromoted or absent pass files")


def load_journal(directory, protocol, identity, *, require_resumable=False,
                 now_epoch=None, verify_checkpoints=True, check_published=True,
                 inspection_only_allow_truncated_tail=False):
    """Replay once in O(events), validating every call, index, hash and budget.

    Snapshot files are intentionally ignored. Set ``require_resumable`` before
    reusing any pass. The loader never mutates an old task, imports version 1
    files, changes execution identity, reruns a call, or resets its deadlines.
    """
    directory = Path(directory)
    if inspection_only_allow_truncated_tail and (require_resumable or check_published):
        raise JournalError("Truncated-tail inspection is strictly nonresumable and nonpublication")
    ledger = _replay(directory, protocol, identity, verify_checkpoints=verify_checkpoints,
                     check_published=check_published,
                     inspection_only_allow_truncated_tail=inspection_only_allow_truncated_tail)
    if require_resumable:
        if ledger.status == "completed" or ledger.active is not None or ledger.unknown_gpu or not ledger.budget["resumable"]:
            raise JournalError("Completed, unfinished or unknown-device-cost journal cannot resume")
        ledger.require_complete_cached_calls()
        _reject_orphan_checkpoints(directory, ledger)
        ledger.check_limits(now_epoch=time.time() if now_epoch is None else now_epoch)
    return RecoveredJournal(ledger.full_budget(), ledger.full_index(), ledger.identity, ledger.status,
                            ledger.head, ledger.sequence, ledger.journal_bytes,
                            ledger.uncertain_tail, ledger.tail_bytes)
