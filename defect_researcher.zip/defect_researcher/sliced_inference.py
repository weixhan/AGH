"""Frozen nine-pass geometry, fusion and paired validation analysis.

This module performs no inference, training, file access or threshold search.
An accepted scientific decision remains subject to the runner's source, budget
and independently verified artifact gates.
"""
from __future__ import annotations

from collections import Counter
import math
import random
from statistics import fmean

from .detection_metrics import compare_scores, score_detections
from .stratified_statistics import stratified_statistics

SIZES = ("small", "medium", "large")
WIDTH, HEIGHT = 1920, 1080
PREDICTION_FLOOR = .001


def _number(value, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f"{label} must be a finite number")
    return float(value)


def _integer(value, label, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")
    return value


def _box(value, width, height):
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError("xyxy must contain four coordinates")
    x1, y1, x2, y2 = [_number(v, "coordinate") for v in value]
    if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
        raise ValueError("box must have positive area and lie inside its image")
    return [x1, y1, x2, y2]


def _gt_box(value):
    # Preserve the bound source GT exactly, like the existing scorer. YOLO label
    # decimal rounding can put a reconstructed edge microscopically outside the
    # image; clipping it would change the reused reference matching and AP.
    # The runner binds these GT to the already validated source geometry chain.
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError("GT xyxy must contain four coordinates")
    coordinates = [_number(v, "GT coordinate") for v in value]
    if coordinates[2] <= coordinates[0] or coordinates[3] <= coordinates[1]:
        raise ValueError("GT box must have positive width and height")
    if not math.isfinite((coordinates[2] - coordinates[0]) * (coordinates[3] - coordinates[1])):
        raise ValueError("GT area overflow")
    return coordinates


def _class(value):
    value = _integer(value, "class_id")
    if value >= 7:
        raise ValueError("class_id must be in the seven-class mapping [0,6]")
    return value


def _confidence(value):
    value = _number(value, "confidence")
    if not PREDICTION_FLOOR <= value <= 1:
        raise ValueError("confidence must be in [0.001,1]")
    return value


def tiles(width=WIDTH, height=HEIGHT):
    """Return the exact preregistered full image and eight original-pixel crops."""
    if _integer(width, "width", 1) != WIDTH or _integer(height, "height", 1) != HEIGHT:
        raise ValueError("the frozen tile grid requires 1920x1080 images")
    result = [{"pass_id": 0, "crop": [0, 0, width, height]}]
    for y in (0, 440):
        for x in (0, 512, 1024, 1280):
            result.append({"pass_id": len(result), "crop": [x, y, x + 640, y + 640]})
    return result


def map_predictions(local_predictions, crop, width, height, pass_id):
    """Validate every backend prediction, then add the fixed crop offset.

    prediction_index is the original post-NMS backend list index. No clipping,
    dropping, confidence filtering, class remapping or coordinate averaging is
    performed here; one invalid item rejects the entire pass.
    """
    grid = tiles(width, height)
    pass_id = _integer(pass_id, "pass_id")
    if pass_id >= len(grid) or not isinstance(crop, (list, tuple)) or list(crop) != grid[pass_id]["crop"]:
        raise ValueError("crop does not match the frozen pass_id")
    if any(isinstance(v, bool) or not isinstance(v, int) for v in crop):
        raise ValueError("crop coordinates must be integers")
    if not isinstance(local_predictions, list):
        raise ValueError("local_predictions must be a list")
    if len(local_predictions) > 300:
        raise ValueError("per-pass post-NMS predictions exceed max_det=300")
    x0, y0, x1, y1 = crop
    mapped = []
    for index, prediction in enumerate(local_predictions):
        if not isinstance(prediction, dict):
            raise ValueError("prediction must be a dictionary")
        local = _box(prediction.get("xyxy"), x1 - x0, y1 - y0)
        original = [local[0] + x0, local[1] + y0, local[2] + x0, local[3] + y0]
        _box(original, width, height)
        mapped.append({"pass_id": pass_id, "prediction_index": index,
                       "crop": list(crop), "local_xyxy": local, "xyxy": original,
                       "class_id": _class(prediction.get("class_id")),
                       "confidence": _confidence(prediction.get("confidence"))})
    return mapped


def _area(box):
    return (box[2] - box[0]) * (box[3] - box[1])


def _iou(left, right):
    intersection = max(0., min(left[2], right[2]) - max(left[0], right[0])) * max(
        0., min(left[3], right[3]) - max(left[1], right[1]))
    return intersection / (_area(left) + _area(right) - intersection)


def _source(candidate):
    return {"pass_id": candidate["pass_id"], "prediction_index": candidate["prediction_index"]}


def fuse_predictions(candidates, nms_iou=.7, max_det=300):
    """Greedy same-class NMS followed by global max_det, with every disposition.

    Exact IoU=0.7 is retained. Equal confidences prefer pass_id then the original
    prediction index. Suppression and global truncation are distinct trace rows.
    """
    if _number(nms_iou, "nms_iou") != .7 or _integer(max_det, "max_det", 1) != 300:
        raise ValueError("fusion controls are frozen at IoU=.7 and global max_det=300")
    if not isinstance(candidates, list):
        raise ValueError("candidates must be a list")
    prepared, seen, pass_counts = [], set(), Counter()
    grid = tiles()
    for candidate in candidates:
        if not isinstance(candidate, dict):
            raise ValueError("candidate must be a dictionary")
        pass_id = _integer(candidate.get("pass_id"), "pass_id")
        index = _integer(candidate.get("prediction_index"), "prediction_index")
        if pass_id >= 9 or index >= 300:
            raise ValueError("candidate source identity is outside the frozen pass limits")
        identity = (pass_id, index)
        if identity in seen:
            raise ValueError("duplicate candidate pass/index identity")
        seen.add(identity)
        pass_counts[pass_id] += 1
        crop = candidate.get("crop")
        if (not isinstance(crop, (list, tuple)) or list(crop) != grid[pass_id]["crop"]
                or any(isinstance(v, bool) or not isinstance(v, int) for v in crop)):
            raise ValueError("candidate crop differs from the frozen grid")
        x0, y0, x1, y1 = crop
        local = _box(candidate.get("local_xyxy"), x1 - x0, y1 - y0)
        original = _box(candidate.get("xyxy"), WIDTH, HEIGHT)
        expected = [local[0] + x0, local[1] + y0, local[2] + x0, local[3] + y0]
        if original != expected:
            raise ValueError("candidate global coordinates differ from its local offset")
        prepared.append({"pass_id": pass_id, "prediction_index": index,
                         "crop": list(crop), "local_xyxy": local, "xyxy": original,
                         "class_id": _class(candidate.get("class_id")),
                         "confidence": _confidence(candidate.get("confidence"))})
    # map_predictions emits contiguous original indices. A missing index may be
    # a silently dropped malformed prediction and must not be accepted.
    for pass_id, count in pass_counts.items():
        if {index for pid, index in seen if pid == pass_id} != set(range(count)):
            raise ValueError("candidate indices must form each complete backend list")
    prepared.sort(key=lambda c: (-c["confidence"], c["pass_id"], c["prediction_index"]))
    rows, selected, selected_by_class = [], [], {i: [] for i in range(7)}
    for rank, candidate in enumerate(prepared):
        row = {**candidate, "candidate_rank": rank, "status": None,
               "suppressed_by": None, "suppression_iou": None, "final_prediction_index": None}
        suppressor, overlap = None, None
        for kept in selected_by_class[candidate["class_id"]]:
            value = _iou(kept["xyxy"], candidate["xyxy"])
            if value > nms_iou:
                suppressor, overlap = kept, value
                break
        if suppressor is not None:
            row.update(status="suppressed_iou", suppressed_by=_source(suppressor), suppression_iou=overlap)
        else:
            selected_by_class[candidate["class_id"]].append(candidate)
            selected.append(row)
        rows.append(row)
    predictions = []
    for index, row in enumerate(selected):
        if index < max_det:
            row.update(status="kept", final_prediction_index=index)
            predictions.append({key: row[key] for key in ("class_id", "confidence", "xyxy")})
        else:
            row["status"] = "global_max_det"
    return predictions, {
        "schema_version": "fixed-nine-pass-fusion-trace-v1",
        "nms_iou": nms_iou, "suppression_comparator": ">", "global_max_det": max_det,
        "confidence_ties": "pass_id_then_original_prediction_index",
        "candidate_count": len(rows), "nms_survivor_count": len(selected),
        "suppressed_count": sum(r["status"] == "suppressed_iou" for r in rows),
        "global_max_det_discarded_count": max(0, len(selected) - max_det),
        "final_count": len(predictions), "rows": rows,
    }


def _size(box):
    area = _area(box)
    return "small" if area < 1024 else "medium" if area < 9216 else "large"


def _names(value):
    if isinstance(value, (list, tuple)):
        names = dict(enumerate(value))
    elif isinstance(value, dict):
        names = {}
        for key, name in value.items():
            if isinstance(key, bool) or not (isinstance(key, int) or isinstance(key, str) and key.isdecimal()):
                raise ValueError("class IDs must be integers")
            if int(key) in names:
                raise ValueError("duplicate numeric class ID")
            names[int(key)] = name
    else:
        raise ValueError("class_names must be a seven-element list or dictionary")
    if set(names) != set(range(7)) or any(not isinstance(v, str) or not v for v in names.values()):
        raise ValueError("class_names must map all seven classes [0,6]")
    return dict(sorted(names.items()))


def _records(records, names):
    if not isinstance(records, list):
        raise ValueError("records must be a list")
    normalized, seen = [], set()
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("record must be a dictionary")
        image_id = record.get("image_id")
        if not isinstance(image_id, str) or not image_id or image_id in seen:
            raise ValueError("image_id must be unique and nonempty")
        seen.add(image_id)
        width, height = record.get("width"), record.get("height")
        if _number(width, "width") != WIDTH or _number(height, "height") != HEIGHT:
            raise ValueError("the frozen experiment requires 1920x1080 images")
        row = {"image_id": image_id, "width": WIDTH, "height": HEIGHT}
        for kind in ("ground_truth", "predictions"):
            boxes = record.get(kind)
            if not isinstance(boxes, list):
                raise ValueError("each record needs GT and prediction lists")
            row[kind] = []
            for box in boxes:
                if not isinstance(box, dict):
                    raise ValueError("box must be a dictionary")
                class_id = _class(box.get("class_id"))
                if class_id not in names:
                    raise ValueError("box class_id absent from names")
                coordinates = (_gt_box(box.get("xyxy")) if kind == "ground_truth"
                               else _box(box.get("xyxy"), WIDTH, HEIGHT))
                item = {"class_id": class_id, "xyxy": coordinates}
                if kind == "predictions":
                    item["confidence"] = _confidence(box.get("confidence"))
                row[kind].append(item)
            if kind == "predictions" and len(row[kind]) > 300:
                raise ValueError("final predictions exceed max_det=300")
        normalized.append(row)
    return sorted(normalized, key=lambda r: r["image_id"])


def _details(records, confidence, match_iou):
    """Derive same-class confidence-ordered one-to-one matches and source rows."""
    gt_rows, fp_rows, matches = [], [], {}
    for record in records:
        truth, predictions = record["ground_truth"], record["predictions"]
        pred_to_gt, gt_to_pred = {}, {}
        for pred_index in sorted(range(len(predictions)), key=lambda i: (-predictions[i]["confidence"], i)):
            pred = predictions[pred_index]
            if pred["confidence"] < confidence:
                continue
            selected, maximum = None, -1.
            for gt_index, gt in enumerate(truth):
                if gt_index in gt_to_pred or gt["class_id"] != pred["class_id"]:
                    continue
                overlap = _iou(pred["xyxy"], gt["xyxy"])
                if overlap >= match_iou and overlap > maximum:
                    selected, maximum = gt_index, overlap
            pred_to_gt[pred_index] = selected
            if selected is not None:
                gt_to_pred[selected] = pred_index
            else:
                fp_rows.append({"image_id": record["image_id"], "prediction_index": pred_index,
                                "class_id": pred["class_id"], "xyxy": pred["xyxy"]})
        for gt_index, gt in enumerate(truth):
            gt_rows.append({"image_id": record["image_id"], "gt_index": gt_index,
                            "class_id": gt["class_id"], "xyxy": gt["xyxy"],
                            "status": "tp" if gt_index in gt_to_pred else "fn",
                            "matched_prediction_index": gt_to_pred.get(gt_index)})
        matches[record["image_id"]] = {"gt_to_pred": gt_to_pred, "pred_to_gt": pred_to_gt}
    return gt_rows, fp_rows, matches


def _paired_medium(rows):
    deltas = [row["medium_recall_delta"] for row in rows if row["medium_gt"]]
    rng = random.Random(42)
    samples = sorted(fmean(rng.choices(deltas, k=len(deltas))) for _ in range(2000)) if deltas else []
    def percentile(fraction):
        position = (len(samples) - 1) * fraction
        low, high = math.floor(position), math.ceil(position)
        return samples[low] + (samples[high] - samples[low]) * (position - low)
    return {"eligible_images": len(deltas), "mean_delta": fmean(deltas) if deltas else None,
            "ci95": [percentile(.025), percentile(.975)] if samples else None,
            "seed": 42, "resamples": 2000, "unit": "image_with_at_least_one_original_medium_gt",
            "note": "Descriptive paired image recall; frame correlation is not removed."}


def analyze_comparison(baseline_records, sliced_records, protocol):
    """Score both arms with the existing AP evaluator and freeze scientific gates.

    Identical original GT order is required because gt_index is the provenance
    identity. Full population and medium denominators are checked before any
    decision; missing or changed members cause an error, not a partial success.
    """
    if not isinstance(protocol, dict):
        raise ValueError("protocol must be a dictionary")
    for key, expected in (("prediction_confidence", .001), ("global_nms_iou", .7),
                          ("global_max_det", 300)):
        if key in protocol and (_number(protocol[key], key) != expected):
            raise ValueError(f"{key} differs from the frozen controls")
    if "bootstrap" in protocol:
        bootstrap = protocol["bootstrap"]
        if (not isinstance(bootstrap, dict) or _integer(bootstrap.get("seed"), "bootstrap.seed") != 42
                or _integer(bootstrap.get("resamples"), "bootstrap.resamples", 1) != 2000
                or bootstrap.get("unit") != "image_with_at_least_one_gt"):
            raise ValueError("bootstrap differs from the frozen protocol")
    names = _names(protocol.get("class_names"))
    point = protocol.get("operating_point")
    if (not isinstance(point, dict) or _number(point.get("confidence"), "confidence") != .25
            or _number(point.get("match_iou"), "match_iou") != .5):
        raise ValueError("operating point is frozen at confidence=.25 and matching IoU=.5")
    left, right = _records(baseline_records, names), _records(sliced_records, names)
    if [(r["image_id"], r["width"], r["height"], r["ground_truth"]) for r in left] != [
            (r["image_id"], r["width"], r["height"], r["ground_truth"]) for r in right]:
        raise ValueError("both arms require identical image population and ordered GT")
    observed = {"images": len(left), "gt": sum(len(r["ground_truth"]) for r in left),
                "normal_images": sum(not r["ground_truth"] for r in left),
                "medium_gt": sum(_size(g["xyxy"]) == "medium" for r in left for g in r["ground_truth"]),
                "medium_images": sum(any(_size(g["xyxy"]) == "medium" for g in r["ground_truth"]) for r in left)}
    population = protocol.get("population")
    if not isinstance(population, dict) or any(
            _integer(population.get(k), f"population.{k}") != value for k, value in observed.items()):
        raise ValueError("observed population differs from the frozen protocol")
    if "image_ids" in population and (not isinstance(population["image_ids"], list)
            or population["image_ids"] != sorted(r["image_id"] for r in left)):
        raise ValueError("image identities differ from the frozen protocol")
    baseline_score = score_detections(left, names, .25, .5)
    sliced_score = score_detections(right, names, .25, .5)
    existing = compare_scores(baseline_score, sliced_score)
    left_gt, left_fp, left_match = _details(left, .25, .5)
    right_gt, right_fp, right_match = _details(right, .25, .5)
    for score, details, fp in ((baseline_score, left_gt, left_fp), (sliced_score, right_gt, right_fp)):
        expected = {"tp": sum(row["status"] == "tp" for row in details), "fp": len(fp),
                    "fn": sum(row["status"] == "fn" for row in details)}
        if any(score["operating_point"][key] != value for key, value in expected.items()):
            raise ValueError("detail matching is inconsistent with the frozen AP scorer")
    strata = {"baseline": stratified_statistics(left, left_gt, left_fp),
              "sliced": stratified_statistics(right, right_gt, right_fp)}
    transitions, counts, per_image = [], {}, []
    for class_id in names:
        for size in SIZES:
            counts[(class_id, size)] = Counter()
    for record in left:
        image_id = record["image_id"]
        before, after = left_match[image_id]["gt_to_pred"], right_match[image_id]["gt_to_pred"]
        medium_ids = {i for i, gt in enumerate(record["ground_truth"]) if _size(gt["xyxy"]) == "medium"}
        left_medium, right_medium = len(set(before) & medium_ids), len(set(after) & medium_ids)
        left_fp_count = sum(gt is None for gt in left_match[image_id]["pred_to_gt"].values())
        right_fp_count = sum(gt is None for gt in right_match[image_id]["pred_to_gt"].values())
        per_image.append({"image_id": image_id, "gt": len(record["ground_truth"]),
                          "baseline_tp": len(before), "sliced_tp": len(after), "tp_delta": len(after) - len(before),
                          "baseline_fp": left_fp_count, "sliced_fp": right_fp_count,
                          "fp_delta": right_fp_count - left_fp_count,
                          "recovered_gt": len(set(after) - set(before)), "lost_gt": len(set(before) - set(after)),
                          "medium_gt": len(medium_ids), "baseline_medium_tp": left_medium,
                          "sliced_medium_tp": right_medium, "medium_tp_delta": right_medium - left_medium,
                          "medium_recall_delta": (right_medium - left_medium) / len(medium_ids) if medium_ids else None,
                          "medium_recovered_gt": len((set(after) - set(before)) & medium_ids),
                          "medium_lost_gt": len((set(before) - set(after)) & medium_ids)})
        for index, gt in enumerate(record["ground_truth"]):
            size = _size(gt["xyxy"])
            a, b = index in before, index in after
            transition = "retained_tp" if a and b else "recovered_fn" if b else "lost_tp" if a else "retained_fn"
            row = {"evidence_id": f"{image_id}:gt:{index}", "image_id": image_id,
                   "gt_index": index, "class_id": gt["class_id"], "class_name": names[gt["class_id"]],
                   "size_bucket": size, "xyxy": gt["xyxy"], "baseline_status": "tp" if a else "fn",
                   "sliced_status": "tp" if b else "fn", "baseline_prediction_index": before.get(index),
                   "sliced_prediction_index": after.get(index), "transition": transition}
            transitions.append(row)
            count = counts[(gt["class_id"], size)]
            count.update(gt=1, baseline_tp=int(a), sliced_tp=int(b), recovered_gt=int(b and not a), lost_gt=int(a and not b))
    class_size = []
    for (class_id, size), count in counts.items():
        gt_count = count["gt"]
        class_size.append({"class_id": class_id, "class_name": names[class_id], "size_bucket": size,
                           "gt": gt_count, "baseline_tp": count["baseline_tp"],
                           "baseline_fn": gt_count - count["baseline_tp"],
                           "baseline_recall_gt": count["baseline_tp"] / gt_count if gt_count else None,
                           "sliced_tp": count["sliced_tp"], "sliced_fn": gt_count - count["sliced_tp"],
                           "sliced_recall_gt": count["sliced_tp"] / gt_count if gt_count else None,
                           "tp_delta": count["sliced_tp"] - count["baseline_tp"],
                           "recovered_gt": count["recovered_gt"], "lost_gt": count["lost_gt"],
                           "support_status": "no_gt" if not gt_count else "insufficient_gt" if gt_count < 20 else "sufficient_for_description"})
    per_class_gt = []
    for class_id in names:
        cells = [row for row in class_size if row["class_id"] == class_id]
        summed = {key: sum(row[key] for row in cells) for key in (
            "gt", "baseline_tp", "baseline_fn", "sliced_tp", "sliced_fn", "tp_delta", "recovered_gt", "lost_gt")}
        per_class_gt.append({"class_id": class_id, "class_name": names[class_id], **summed,
                             "baseline_recall_gt": summed["baseline_tp"] / summed["gt"] if summed["gt"] else None,
                             "sliced_recall_gt": summed["sliced_tp"] / summed["gt"] if summed["gt"] else None})
    baseline_point, sliced_point = baseline_score["operating_point"], sliced_score["operating_point"]
    gains = {"tp_gain": sliced_point["tp"] - baseline_point["tp"],
             "gain_images": sum(row["tp_delta"] > 0 for row in per_image),
             "loss_images": sum(row["tp_delta"] < 0 for row in per_image),
             "medium_tp_gain": sum(row["medium_tp_delta"] for row in per_image),
             "medium_gain_images": sum(row["medium_tp_delta"] > 0 for row in per_image),
             "medium_loss_images": sum(row["medium_tp_delta"] < 0 for row in per_image),
             "recovered_gt": sum(row["transition"] == "recovered_fn" for row in transitions),
             "lost_gt": sum(row["transition"] == "lost_tp" for row in transitions),
             "medium_recovered_gt": sum(row["transition"] == "recovered_fn" and row["size_bucket"] == "medium" for row in transitions),
             "medium_lost_gt": sum(row["transition"] == "lost_tp" and row["size_bucket"] == "medium" for row in transitions)}
    rules = protocol.get("acceptance")
    required = ("min_tp_gain", "min_gain_images", "min_medium_tp_gain", "min_medium_gain_images",
                "max_normal_fp_images", "max_normal_fp_rate", "max_fp", "min_ap50", "min_ap50_95")
    if not isinstance(rules, dict) or any(key not in rules for key in required):
        raise ValueError("protocol must provide every frozen scientific acceptance gate")
    for key in required[:5] + ("max_fp",):
        _integer(rules[key], f"acceptance.{key}")
    for key in ("max_normal_fp_rate", "min_ap50", "min_ap50_95"):
        if not 0 <= _number(rules[key], f"acceptance.{key}") <= 1:
            raise ValueError("acceptance rates and AP must be in [0,1]")
    checks = [
        {"name": "overall_tp_gain", "passed": gains["tp_gain"] >= rules["min_tp_gain"], "actual": gains["tp_gain"], "required_min": rules["min_tp_gain"]},
        {"name": "overall_gain_images", "passed": gains["gain_images"] >= rules["min_gain_images"], "actual": gains["gain_images"], "required_min": rules["min_gain_images"]},
        {"name": "medium_tp_gain", "passed": gains["medium_tp_gain"] >= rules["min_medium_tp_gain"], "actual": gains["medium_tp_gain"], "required_min": rules["min_medium_tp_gain"]},
        {"name": "medium_gain_images", "passed": gains["medium_gain_images"] >= rules["min_medium_gain_images"], "actual": gains["medium_gain_images"], "required_min": rules["min_medium_gain_images"]},
        {"name": "normal_fp_images", "passed": sliced_point["normal_images_with_false_positives"] <= rules["max_normal_fp_images"], "actual": sliced_point["normal_images_with_false_positives"], "required_max": rules["max_normal_fp_images"]},
        {"name": "normal_fp_rate", "passed": sliced_point["normal_image_fp_rate"] is not None and sliced_point["normal_image_fp_rate"] <= rules["max_normal_fp_rate"], "actual": sliced_point["normal_image_fp_rate"], "required_max": rules["max_normal_fp_rate"]},
        {"name": "overall_fp", "passed": sliced_point["fp"] <= rules["max_fp"], "actual": sliced_point["fp"], "required_max": rules["max_fp"]},
        {"name": "ap50_non_degradation", "passed": sliced_score["mAP50"] >= rules["min_ap50"], "actual": sliced_score["mAP50"], "required_min": rules["min_ap50"]},
        {"name": "ap50_95_non_degradation", "passed": sliced_score["mAP50_95"] >= rules["min_ap50_95"], "actual": sliced_score["mAP50_95"], "required_min": rules["min_ap50_95"]},
    ]
    return {"schema_version": "fixed-nine-pass-validation-comparison-v1", "population": observed,
            "baseline_metrics": baseline_score, "sliced_metrics": sliced_score,
            "paired_comparison": {"schema_version": "sliced-paired-comparison-v1", "scope": "validation_only_same_weight",
                                  "delta_direction": "sliced_minus_baseline", "delta_sliced_minus_baseline": existing["delta_960_minus_640"],
                                  "paired_recall": existing["paired_recall"], "limitations": existing["limitations"]},
            "stratified_statistics": strata, "class_size": class_size, "per_class_gt": per_class_gt,
            "normal_false_positives": {
                "baseline": {"images": observed["normal_images"],
                             "fp_images": baseline_point["normal_images_with_false_positives"],
                             "fp_boxes": sum(row["baseline_fp"] for row in per_image if not row["gt"]),
                             "image_fp_rate": baseline_point["normal_image_fp_rate"]},
                "sliced": {"images": observed["normal_images"],
                           "fp_images": sliced_point["normal_images_with_false_positives"],
                           "fp_boxes": sum(row["sliced_fp"] for row in per_image if not row["gt"]),
                           "image_fp_rate": sliced_point["normal_image_fp_rate"]}}, "per_image": per_image,
            "gt_transitions": transitions, "gains": gains, "paired_medium_recall": _paired_medium(per_image),
            "scientific_decision": {"status": "accepted" if all(check["passed"] for check in checks) else "stop",
                                    "scope": "frozen_scientific_metric_gates_only", "checks": checks,
                                    "failed_gates": [check["name"] for check in checks if not check["passed"]],
                                    "execution_and_evidence_gates_required": True, "threshold_search_performed": False},
            "limitations": ["Combined context, fixed tiles and fusion are tested together; a gain does not identify a scale cause.",
                            "Medium size and difficult-class composition are confounded; report all class-by-size cells.",
                            "Small support is descriptive only; practical gain gates do not establish statistical significance.",
                            "Validation image bootstrap does not remove correlated physical defects or frames.",
                            "Acceptance here still requires runner source, runtime budget and independent artifact verification."]}
