"""Small, dependency-free MCP stdio adapter for configured verification tasks.

MCP 2025-03-26 and 2024-11-05 are supported. Tool annotations are returned
only for the newer version. Each UTF-8 input line is one JSON-RPC message
(or batch); stdout contains protocol responses exclusively.
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import sys
import uuid
from pathlib import Path
from typing import Any, BinaryIO


PROTOCOL_VERSION = "2025-03-26"
SUPPORTED_PROTOCOL_VERSIONS = {"2024-11-05", PROTOCOL_VERSION}
SERVER_NAME = "defect-researcher-audit"
TOOL_NAME = "audit_dataset"
GEOMETRY_TOOL_NAME = "verify_label_geometry"
REPAIR_TOOL_NAME = "repair_label_copy"
COMPARISON_TOOL_NAME = "compare_validation_resolutions"
DIAGNOSIS_TOOL_NAME = "diagnose_validation_errors"
SLICING_TOOL_NAME = "compare_validation_slices"
STATUS_TOOL_NAME = "get_task_status"
TASK_ID_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$"
AUDIT_TOOL = {
    "name": TOOL_NAME,
    "description": (
        "Start a background audit of the server-configured CableInspect-AD "
        "dataset without modifying source data. Returns promptly with status "
        "running and a task_id. Call get_task_status with that ID until completed "
        "or failed; a running response is not a completed audit. The server "
        "generates the ID; no paths or parameters are accepted."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {},
        "additionalProperties": False,
    },
    "annotations": {
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
}
GEOMETRY_TOOL = {
    "name": GEOMETRY_TOOL_NAME,
    "description": (
        "Start independent label-geometry verification of the server-configured "
        "CableInspect-AD dataset without modifying source data. Returns promptly "
        "with status running and a task_id. Poll get_task_status with that ID. "
        "Status completed means verification finished; inspect "
        "summary.verification_status (passed or failed) for the findings. "
        "The server generates the ID; no paths or parameters are accepted."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {},
        "additionalProperties": False,
    },
    "annotations": {
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
}
REPAIR_TOOL = {
    "name": REPAIR_TOOL_NAME,
    "description": "Start a trusted-source label/metadata copy repair using fixed server paths. Original inputs stay unchanged; images are hard-linked without pixel access. Poll get_task_status with the returned task_id. Completed is execution only: inspect summary.repair_status (passed/refused) and summary.verification_status. Zero changed_files means a clean copy, not repaired defects. No arguments or caller paths accepted.",
    "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
}
COMPARISON_TOOL = {
    "name": COMPARISON_TOOL_NAME,
    "description": "Start the frozen same-weight FP32 640/960 validation-only detection comparison. Fixed local weights and inputs, batch 1, confidence floor 0.001, NMS IoU 0.7; no training or test-set inference. Reads validation pixels and writes a new outputs task with predictions, independently computed metrics and evidence. Poll get_task_status with the returned task_id. Accept only completed with summary.comparison_status=passed; validation findings do not establish test performance or autonomous research. No arguments accepted.",
    "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
}
STATUS_TOOL = {
    "name": STATUS_TOOL_NAME,
    "description": (
        "Read progress for a task_id returned by audit_dataset or "
        "verify_label_geometry, repair_label_copy, compare_validation_resolutions, diagnose_validation_errors or compare_validation_slices. Completed results include findings and evidence "
        "paths after artifact hash verification. For geometry verification, "
        "completed means execution finished; summary.verification_status "
        "separately reports passed or failed findings. Status failed describes "
        "an execution error or interrupted task. "
        "Poll this tool while the status is running, without invoking a shell or waiting tool."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "task_id": {
                "type": "string",
                "pattern": TASK_ID_PATTERN,
                "maxLength": 128,
                "description": "The task_id previously returned by a task-starting tool",
            }
        },
        "required": ["task_id"],
        "additionalProperties": False,
    },
    "annotations": {
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
}
DIAGNOSIS_TOOL = {
    "name": DIAGNOSIS_TOOL_NAME,
    "description": "Diagnose the fixed, sealed validation experiment using saved 640/960 predictions. Independently match boxes, classify FN/FP candidate evidence and evaluate a pre-frozen confidence grid under the reference normal-image FP budget. No new model inference, training or test evaluation. Writes a new evidence directory; returns promptly with task_id. Call only get_task_status for that ID until completed, inspect summary.diagnosis_status and evidence-linked recommendations. A recommended candidate is not held-out improvement or a deployed threshold. No arguments accepted.",
    "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
}
SLICING_TOOL = {
    "name": SLICING_TOOL_NAME,
    "description": "Start the frozen same-weight FP32 validation comparison of full-image context plus eight fixed original-pixel tiles. All 640 validation images, batch 1, no training, test inference, threshold search or automatic fallback. Writes a new task containing all nine observations per image, coordinate mapping, global same-class NMS, fixed-budget records and independently checkable metrics. Call only get_task_status for the returned ID until terminal. Completed and summary.slicing_status=passed mean execution and artifact validation finished; summary.candidate_status separately reports whether the frozen research gates passed or stopped. No arguments, caller paths or recovery inputs accepted.",
    "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
    "annotations": {"readOnlyHint": False, "destructiveHint": False, "idempotentHint": False, "openWorldHint": False},
}


def _valid_id(value: Any) -> bool:
    return isinstance(value, str) or (
        isinstance(value, int) and not isinstance(value, bool)
    )


def _error(request_id: Any, code: int, message: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {
            "code": code,
            "message": message,
            "data": {"request_id": request_id},
        },
    }


def _result(request_id: Any, result: dict) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


class AuditMCPServer:
    """One stdio session with a configuration controlled by the local user."""

    def __init__(
        self, configuration: dict | None = None, config_path: str | Path | None = None
    ) -> None:
        self.configuration = copy.deepcopy(configuration)
        self.config_path = config_path
        self.initialized = False
        self.ready = False
        self.protocol_version = PROTOCOL_VERSION

    def handle_message(self, message: Any) -> dict | list | None:
        if isinstance(message, list):
            if not message:
                return _error(None, -32600, "Invalid request: empty batch")
            responses = []
            for item in message:
                # A nested batch is not a JSON-RPC request.
                response = self._handle_request(item)
                if response is not None:
                    responses.append(response)
            return responses or None
        return self._handle_request(message)

    def _handle_request(self, message: Any) -> dict | None:
        if not isinstance(message, dict):
            return _error(None, -32600, "Invalid request: expected an object")
        request_id = message.get("id")
        response_id = request_id if _valid_id(request_id) else None
        if message.get("jsonrpc") != "2.0" or not isinstance(
            message.get("method"), str
        ):
            return _error(response_id, -32600, "Invalid JSON-RPC request")
        if "id" in message and not _valid_id(request_id):
            return _error(None, -32600, "Request ID must be a string or integer")
        method = message["method"]
        params = message.get("params", {})
        is_notification = "id" not in message
        if not isinstance(params, dict):
            return None if is_notification else _error(
                request_id, -32602, "Parameters must be an object"
            )

        # Notifications never receive a response and cannot run the audit.
        if is_notification:
            if method == "notifications/initialized" and self.initialized:
                self.ready = True
            return None
        if method == "ping":
            return _result(request_id, {})
        if method == "initialize":
            if self.initialized:
                return _error(request_id, -32600, "Session is already initialized")
            client = params.get("clientInfo")
            if (
                not isinstance(params.get("protocolVersion"), str)
                or not params["protocolVersion"]
                or not isinstance(params.get("capabilities"), dict)
                or not isinstance(client, dict)
                or not isinstance(client.get("name"), str)
                or not isinstance(client.get("version"), str)
            ):
                return _error(request_id, -32602, "Invalid initialize parameters")
            self.initialized = True
            requested_version = params["protocolVersion"]
            self.protocol_version = (
                requested_version
                if requested_version in SUPPORTED_PROTOCOL_VERSIONS
                else PROTOCOL_VERSION
            )
            return _result(
                request_id,
                {
                    "protocolVersion": self.protocol_version,
                    "capabilities": {"tools": {"listChanged": False}},
                    "serverInfo": {"name": SERVER_NAME, "version": "0.2.0"},
                },
            )
        if not self.ready:
            return _error(
                request_id, -32002, "Complete initialize and notifications/initialized first"
            )
        if method == "tools/list":
            if params.get("cursor") is not None:
                return _error(request_id, -32602, "This tool directory has no cursor")
            tools = [copy.deepcopy(tool) for tool in (AUDIT_TOOL, GEOMETRY_TOOL, REPAIR_TOOL, COMPARISON_TOOL, DIAGNOSIS_TOOL, SLICING_TOOL, STATUS_TOOL)]
            if self.protocol_version == "2024-11-05":
                for tool in tools:
                    tool.pop("annotations", None)
            return _result(request_id, {"tools": tools})
        if method == "tools/call":
            name = params.get("name")
            if not isinstance(name, str) or name not in {TOOL_NAME, GEOMETRY_TOOL_NAME, REPAIR_TOOL_NAME, COMPARISON_TOOL_NAME, DIAGNOSIS_TOOL_NAME, SLICING_TOOL_NAME, STATUS_TOOL_NAME}:
                return _error(request_id, -32602, "Unknown tool")
            arguments = params.get("arguments", {})
            if not isinstance(arguments, dict):
                return _error(request_id, -32602, "Tool arguments must be an object")
            if name in {TOOL_NAME, GEOMETRY_TOOL_NAME, REPAIR_TOOL_NAME, COMPARISON_TOOL_NAME, DIAGNOSIS_TOOL_NAME, SLICING_TOOL_NAME} and arguments:
                return _error(
                    request_id,
                    -32602,
                    f"{name} accepts only an empty arguments object; paths are configured locally",
                )
            if name == STATUS_TOOL_NAME and (
                set(arguments) != {"task_id"}
                or not isinstance(arguments["task_id"], str)
                or not re.fullmatch(TASK_ID_PATTERN, arguments["task_id"])
            ):
                return _error(request_id, -32602, "get_task_status requires one safe task_id")
            return _result(request_id, self._run_tool(request_id, name, arguments))
        return _error(request_id, -32601, "Method not found")

    def _run_tool(self, request_id: str | int, name: str, arguments: dict) -> dict:
        task_id = arguments.get("task_id")
        call_id = uuid.uuid4().hex
        stage = "configuration"
        try:
            if self.configuration is None:
                from .config import load_config

                self.configuration = load_config(self.config_path)
            from .task_runtime import get_task_status, start_audit, start_geometry_verification, start_label_repair, start_resolution_comparison, start_diagnosis, start_sliced_comparison

            configuration = copy.deepcopy(self.configuration)
            if name == TOOL_NAME:
                stage = "audit_start"
                report = start_audit(configuration)
            elif name == GEOMETRY_TOOL_NAME:
                stage = "geometry_verification_start"
                report = start_geometry_verification(configuration)
            elif name == REPAIR_TOOL_NAME:
                stage = "label_repair_start"
                report = start_label_repair(configuration)
            elif name == COMPARISON_TOOL_NAME:
                stage = "resolution_comparison_start"
                report = start_resolution_comparison(configuration)
            elif name == DIAGNOSIS_TOOL_NAME:
                stage = "diagnosis_start"
                report = start_diagnosis(configuration)
            elif name == SLICING_TOOL_NAME:
                stage = "slicing_start"
                report = start_sliced_comparison(configuration)
            else:
                stage = "task_status"
                report = get_task_status(configuration, task_id)
            if not isinstance(report, dict):
                raise TypeError("Task runtime must return an object")
            report = dict(report)
            if report.get("status") not in {"running", "completed", "failed"}:
                raise ValueError("Task runtime returned an unknown status")
            returned_task_id = report.get("task_id", task_id)
            if name == STATUS_TOOL_NAME and returned_task_id != task_id:
                raise ValueError("Task status ID does not match the requested task")
            task_id = returned_task_id
            if report["status"] != "failed" and (
                not isinstance(task_id, str) or not re.fullmatch(TASK_ID_PATTERN, task_id)
            ):
                raise ValueError("Task runtime did not return a safe task_id")
            report.setdefault("task_id", task_id)
            report["request_id"] = request_id
            failed = report.get("status") == "failed"
            # Serialize inside this boundary so an invalid report becomes a
            # tool failure rather than corrupting or terminating stdio.
            content = json.dumps(report, ensure_ascii=False, allow_nan=False)
        except Exception as exc:
            failed = True
            content = json.dumps(
                {
                    "status": "failed",
                    "task_id": task_id,
                    "request_id": request_id,
                    "call_id": call_id,
                    "errors": [
                        {"stage": stage, "type": type(exc).__name__, "message": str(exc)}
                    ],
                },
                ensure_ascii=False,
                allow_nan=False,
            )
        return {"content": [{"type": "text", "text": content}], "isError": failed}


def _reject_constant(value: str) -> None:
    raise ValueError(f"Invalid JSON constant: {value}")


def _unique_object(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON object key")
        result[key] = value
    return result


def serve(
    configuration: dict | None = None,
    *,
    config_path: str | Path | None = None,
    stdin: BinaryIO | None = None,
    stdout: BinaryIO | None = None,
) -> None:
    """Serve UTF-8 JSON; production stdout stays isolated for background work."""
    source = sys.stdin.buffer if stdin is None else stdin
    destination = sys.stdout.buffer if stdout is None else stdout
    if stdout is None:
        # Keep this redirection for the process lifetime: an audit thread may
        # outlive stdin. Do not use per-request redirect contexts, which race
        # with the background checker's own capture of Python's global stdout.
        # Protocol output retains the original binary stream above.
        sys.stdout = sys.stderr
    server = AuditMCPServer(configuration, config_path)
    for line in source:
        try:
            message = json.loads(
                line.decode("utf-8"),
                parse_constant=_reject_constant,
                object_pairs_hook=_unique_object,
            )
            response = server.handle_message(message)
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
            response = _error(None, -32700, "Parse error: expected UTF-8 JSON")
        except Exception:
            response = _error(None, -32603, "Internal server error")
        if response is not None:
            encoded = json.dumps(
                response, ensure_ascii=True, separators=(",", ":"), allow_nan=False
            ).encode("utf-8")
            destination.write(encoded + b"\n")
            destination.flush()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="DefectResearcher audit MCP stdio server")
    parser.add_argument("--config", type=Path, help="Local configuration JSON path")
    args = parser.parse_args(argv)
    try:
        serve(config_path=args.config)
    except (BrokenPipeError, KeyboardInterrupt):
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
