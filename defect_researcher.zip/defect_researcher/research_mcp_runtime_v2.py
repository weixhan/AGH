"""Owned background entry point for the sealed, CPU-only research workflow.

Model arguments select a frozen artificial case and bounded budget. They never
select a path, command, backend, resume target, or scientific candidate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import uuid

from .config import PROJECT_ROOT, PATH_KEYS, load_config
from .research_protocol_v1 import validate_request

FREEZE = PROJECT_ROOT / "outputs/research-workflow-implementation-v1/freeze.json"
FREEZE_SHA256 = "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"
OWNER = "defect_researcher.research_mcp_runtime_v2"
PREFIX = "research-workflow-v1-"
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}\Z")
HEX_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
LOCK_PATH_ENV = "DEFECT_RESEARCH_MCP_SOURCE_LOCK_PATH"
LOCK_SHA_ENV = "DEFECT_RESEARCH_MCP_SOURCE_LOCK_SHA256"
REGISTRATION_FIELDS = {"schema_version", "owner", "workflow_id", "request", "configuration", "started_epoch",
                       "started_monotonic", "deadline_epoch", "deadline_monotonic", "source_state"}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _read(path):
    def pairs(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON value")))


def _write_exclusive(path, value):
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    path = Path(path)
    temporary = path.with_name(path.name + ".writing-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        # A hard link publishes the fully written record atomically and refuses
        # an existing target. Both paths are in the same owned NTFS directory.
        os.link(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def _verify_frozen_sources():
    if _sha(FREEZE) != FREEZE_SHA256:
        raise ValueError("Sealed workflow freeze changed")
    frozen = _read(FREEZE)
    if (frozen.get("status") != "passed" or frozen.get("execution_source_count") != 18
            or len(frozen.get("sources", [])) != 25 or len(frozen.get("archive", [])) != 25
            or len(frozen.get("preserved_files", [])) != 968):
        raise ValueError("Sealed workflow population changed")
    for group in ("sources", "archive", "preserved_files"):
        for record in frozen[group]:
            path = Path(record["path"])
            if not path.is_file() or path.stat().st_size != record["size_bytes"] or _sha(path) != record["sha256"]:
                raise ValueError("Sealed workflow source or preserved evidence changed")
    return {"freeze_sha256": FREEZE_SHA256, "execution_source_count": 18,
            "current_sources": 25, "archive_sources": 25, "preserved_files": 968,
            "runtime_sha256": _sha(__file__),
            "controller_sha256": _sha(PROJECT_ROOT / "defect_researcher/research_workflow_clock_v2.py")}


def _deployment_pin():
    path, sha = os.environ.get(LOCK_PATH_ENV), os.environ.get(LOCK_SHA_ENV)
    if path is None and sha is None:
        # Direct Runtime use is allowed for local adapter tests. The production
        # launcher requires a deployment pin before it can start the server.
        return None
    if not path or type(sha) is not str or not HEX_SHA256.fullmatch(sha):
        raise ValueError("A source lock needs both its path and SHA256")
    location = Path(path)
    if not location.is_absolute() or not location.resolve().is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError("Deployment source lock must be inside this project")
    return {"path": str(location.resolve()), "sha256": sha}


def _verify_source_lock(pin):
    path = Path(pin["path"])
    if not path.is_file() or _sha(path) != pin["sha256"]:
        raise ValueError("Deployment source lock changed")
    lock = _read(path)
    if (lock.get("schema_version") != 1 or lock.get("kind") != "research_mcp_implementation_v2"
            or lock.get("status") != "passed" or type(lock.get("files")) is not list
            or not lock["files"]):
        raise ValueError("Deployment source lock is not an accepted implementation")
    roles, paths = set(), set()
    for record in lock["files"]:
        if (type(record) is not dict or set(record) != {"role", "path", "sha256", "size_bytes"}
                or type(record["role"]) is not str or not record["role"]
                or record["role"] in roles or type(record["path"]) is not str
                or type(record["sha256"]) is not str or not HEX_SHA256.fullmatch(record["sha256"])
                or type(record["size_bytes"]) is not int or record["size_bytes"] < 0):
            raise ValueError("Deployment source record is invalid")
        source = Path(record["path"])
        if not source.is_absolute() or str(source.resolve()) in paths:
            raise ValueError("Deployment source record path is invalid")
        if not source.is_file() or source.stat().st_size != record["size_bytes"] or _sha(source) != record["sha256"]:
            raise ValueError("Deployment implementation source changed")
        roles.add(record["role"])
        paths.add(str(source.resolve()))
    required = (Path(__file__).resolve(), PROJECT_ROOT / "defect_researcher/research_mcp_server_v2.py",
                PROJECT_ROOT / "run_research_mcp_v2.py",
                PROJECT_ROOT / "defect_researcher/research_workflow_clock_v2.py",
                FREEZE.resolve(), PROJECT_ROOT / "config/local.json")
    if any(str(source.resolve()) not in paths for source in required):
        raise ValueError("Deployment source lock must bind runtime, sidecar, launcher, clock controller, sealed workflow freeze and local configuration")


def _source_state(pin):
    value = _verify_frozen_sources()
    if pin is not None:
        _verify_source_lock(pin)
        value["deployment_source_lock"] = pin
    return value


def _configuration(configuration=None, config_path=None):
    baseline = load_config(PROJECT_ROOT / "config/local.json")
    if configuration is not None and config_path is not None:
        raise ValueError("Choose server configuration or config_path")
    supplied = load_config(config_path) if config_path is not None else configuration
    result = dict(baseline) if supplied is None else dict(supplied)
    if set(result) != set(PATH_KEYS) or any(type(value) is not str for value in result.values()):
        raise ValueError("Server configuration must contain the fixed path fields")
    result = {key: str(Path(value).resolve()) for key, value in result.items()}
    for key in PATH_KEYS[:-1]:
        if result[key] != baseline[key]:
            raise ValueError("Only the server-owned output_root may differ from local configuration")
    output = Path(result["output_root"])
    if not output.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError("Server output_root must stay inside this project workspace")
    for key in PATH_KEYS[:-1]:
        protected = Path(result[key])
        if output == protected or output.is_relative_to(protected) or protected.is_relative_to(output):
            raise ValueError("Server output_root overlaps protected input")
    return result


def _registry_root(configuration):
    output = Path(configuration["output_root"])
    baseline = Path(load_config(PROJECT_ROOT / "config/local.json")["output_root"])
    base = PROJECT_ROOT if output == baseline else output.parent
    return (base / ".runtime/research-mcp-v2").resolve()


def _workflow_id(value):
    if type(value) is not str or not value.startswith(PREFIX) or not IDENTIFIER.fullmatch(value[len(PREFIX):]):
        raise ValueError("workflow_id must identify a server-owned V1 request")
    return value


def _registration(path):
    path = Path(path).resolve()
    if path.name != "registration.json" or _sha(path) != (path.parent / "registration.sha256").read_text().strip():
        raise ValueError("Owned registration changed")
    value = _read(path)
    if set(value) != REGISTRATION_FIELDS or value["schema_version"] != 1 or value["owner"] != OWNER:
        raise ValueError("Not an owned registration")
    request = validate_request(value["request"])
    configuration = _configuration(value["configuration"])
    identity = _workflow_id(value["workflow_id"])
    if identity != PREFIX + request["request_id"] or path.parent != _registry_root(configuration) / identity:
        raise ValueError("Registry identity or location mismatch")
    for key in ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic"):
        if not _finite(value[key]) or value[key] < 0:
            raise ValueError("Invalid original deadline")
    seconds = request["budget"]["wall_seconds"]
    if (value["deadline_epoch"] != value["started_epoch"] + seconds
            or value["deadline_monotonic"] != value["started_monotonic"] + seconds):
        raise ValueError("Original deadline was changed")
    return value


def _remaining(registration):
    epoch, monotonic = time.time(), time.monotonic()
    if epoch < registration["started_epoch"] or monotonic < registration["started_monotonic"]:
        raise ValueError("Clock moved backwards")
    return min(registration["deadline_epoch"] - epoch, registration["deadline_monotonic"] - monotonic)


def _clock_anchor(registration, registration_path):
    """Capture the origin once, before any subsequent anchor/request I/O."""
    epoch, monotonic = time.time(), time.monotonic()
    if epoch < registration["started_epoch"] or monotonic < registration["started_monotonic"]:
        raise ValueError("Clock moved backwards before owned handoff")
    remaining = min(registration["deadline_epoch"] - epoch,
                    registration["deadline_monotonic"] - monotonic)
    if remaining <= 0:
        raise ValueError("Original entry deadline expired during source verification")
    return {"schema_version": 1, "registration_sha256": _sha(registration_path),
            "started_epoch": epoch, "started_monotonic": monotonic,
            "original_deadline_epoch": registration["deadline_epoch"],
            "original_deadline_monotonic": registration["deadline_monotonic"],
            "remaining_wall_seconds": remaining}


def _verify_clock_handoff(registration, entry, directory):
    """Verify the recorded owned origin against the published ledger clocks."""
    anchor = _read(entry / "worker_clock_anchor.json")
    fields = {"schema_version", "registration_sha256", "started_epoch", "started_monotonic",
              "original_deadline_epoch", "original_deadline_monotonic", "remaining_wall_seconds"}
    if (type(anchor) is not dict or set(anchor) != fields or type(anchor["schema_version"]) is not int
            or anchor["schema_version"] != 1
            or anchor["registration_sha256"] != _sha(entry / "registration.json")):
        raise ValueError("Owned clock anchor schema or registration binding changed")
    for key in fields - {"schema_version", "registration_sha256"}:
        if not _finite(anchor[key]) or anchor[key] < 0:
            raise ValueError("Owned clock anchor contains an invalid clock")
    remaining = min(registration["deadline_epoch"] - anchor["started_epoch"],
                    registration["deadline_monotonic"] - anchor["started_monotonic"])
    if (remaining <= 0 or anchor["remaining_wall_seconds"] != remaining
            or anchor["original_deadline_epoch"] != registration["deadline_epoch"]
            or anchor["original_deadline_monotonic"] != registration["deadline_monotonic"]
            or anchor["started_epoch"] < registration["started_epoch"]
            or anchor["started_monotonic"] < registration["started_monotonic"]
            or anchor["started_epoch"] < _read(entry / "worker_started.json")["started_epoch"]):
        raise ValueError("Owned clock anchor differs from the original entry deadlines")
    expected = {**registration["request"], "budget": {**registration["request"]["budget"],
                                                    "wall_seconds": remaining}}
    if _read(entry / "worker_request.json") != expected or _read(directory / "request.json") != expected:
        raise ValueError("Owned clock anchor differs from the worker/controller request")
    clocks = _read(directory / "runtime.json")
    for suffix in ("epoch", "monotonic"):
        if (clocks["started_" + suffix] != anchor["started_" + suffix]
                or clocks["deadline_" + suffix] != anchor["started_" + suffix] + remaining
                or clocks["deadline_" + suffix] > registration["deadline_" + suffix]):
            raise ValueError("Owned clock handoff changed or extended a controller deadline")


def _failure(entry, code, detail=None):
    path = entry / "wrapper_failure.json"
    value = {"status": "failed", "error_code": code, "resumable": False, "recorded_epoch": time.time(),
             "unknown_business_cost": True}
    if detail is not None:
        value["local_error"] = detail
    try:
        _write_exclusive(path, value)
    except FileExistsError:
        value = _read(path)
    return value


def _quarantine_late(directory, deadline):
    marker = directory / "completion.json"
    if marker.is_file():
        value = _read(marker)
        completed = value.get("completed_epoch")
        if not _finite(completed) or completed > deadline or marker.stat().st_mtime > deadline:
            rejected = directory / "completion_rejected.json"
            if rejected.exists():
                raise ValueError("Both accepted and rejected completion markers exist")
            marker.replace(rejected)
            return True
    return False


def _pid_alive(pid):
    if type(pid) is not int or pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.restype = ctypes.c_void_p
        kernel.OpenProcess.argtypes = (ctypes.c_uint32, ctypes.c_int, ctypes.c_uint32)
        kernel.GetExitCodeProcess.argtypes = (ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32))
        kernel.CloseHandle.argtypes = (ctypes.c_void_p,)
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            return False
        code = ctypes.c_uint32()
        try:
            return bool(kernel.GetExitCodeProcess(handle, ctypes.byref(code))) and code.value == 259
        finally:
            kernel.CloseHandle(handle)
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _summary(registration, directory, result):
    claims = _read(directory / "claims.json")["claims"]
    evidence = _read(directory / "evidence.json")["entries"]
    by_id = {item["evidence_id"]: item for item in evidence}
    source_ids, sources, safe_claims = {}, [], []
    for claim in claims:
        entry = by_id[claim["evidence_id"]]
        value = entry
        for key in claim["field"].split("."):
            value = value[key]
        # The independently verified claim is still checked against current bytes.
        if type(value) is not type(claim["value"]) or value != claim["value"]:
            raise ValueError("Claim differs from independently verified evidence")
        members = []
        for record in entry["files"]:
            sha = record["sha256"]
            if sha not in source_ids:
                source_ids[sha] = "source-" + str(len(source_ids) + 1)
                sources.append({"source_id": source_ids[sha], "sha256": sha})
            members.append(source_ids[sha])
        safe_claims.append({**claim, "source_ids": list(dict.fromkeys(members)),
                            "scope": "sealed_validation_reuse" if entry["origin"] == "historical_reuse"
                            else "isolated_synthetic_case"})
    verification = result["verification"]
    budget = result["final_budget"]
    science = [entry for entry in evidence if entry["kind"] == "science"]
    if len(science) > 1:
        raise ValueError("A bounded workflow may reuse scientific evidence only once")
    return {"workflow_id": registration["workflow_id"], "status": "completed",
            "research_status": result["research_status"], "case_id": result["case_id"],
            "plan_status": result["plan_status"], "actual_tool_path": result["actual_tool_path"],
            "budget_summary": {"domain_invocations": result["domain_invocations"],
                               "gpu_seconds": 0, "model_requests": 0,
                               "original_wall_seconds": registration["request"]["budget"]["wall_seconds"],
                               "controller_wall_seconds": budget["budget"]["wall_seconds"],
                               "original_deadline_epoch": registration["deadline_epoch"],
                               "controller_elapsed_seconds": budget["elapsed_wall_seconds"]},
            "verification": {"status": "passed", "checks_total": verification["total_checks"],
                             "checks_passed": verification["passed_checks"],
                             "completion_sha256": _sha(directory / "completion.json")},
            "claims": safe_claims, "sources": sources, "report_path": str(directory / "report.md"),
            "scientific_summary": science[0]["summary"] if science else None,
            "domain_invocations": result["domain_invocations"], "next_action": result["plan_status"],
            "synthetic_only": True, "new_inference_calls": 0, "new_model_requests": 0,
            "evidence_ids": [entry["evidence_id"] for entry in evidence],
            "evidence": {"directory": str(directory), "completion_sha256": _sha(directory / "completion.json"),
                         "manifest_sha256": _sha(directory / "artifact_manifest.json"),
                         "independent_verification_sha256": _sha(directory / "independent_verification.json")},
            "source_scope": {"input": "isolated_synthetic_case", "science": "sealed_validation_reuse",
                             "fresh_detector_calls": 0, "fresh_model_requests": 0},
            "limitations": result["limitations"]}


class Runtime:
    """A process-independent registry; IDs remain owned after an MCP restart."""

    def __init__(self, configuration=None, config_path=None):
        self.configuration = _configuration(configuration, config_path)
        self.registry_root = _registry_root(self.configuration)
        self.source_lock = _deployment_pin()
        if self.source_lock is not None:
            _verify_source_lock(self.source_lock)
        self._processes = {}

    def start(self, arguments):
        started_epoch, started_monotonic = time.time(), time.monotonic()
        if type(arguments) is not dict or set(arguments) != {"request_id", "case_id", "budget"}:
            raise ValueError("start accepts only request_id, case_id and budget")
        request = validate_request({"schema_version": 1, "workflow_version": 1, **arguments})
        sources = _source_state(self.source_lock)
        identity = PREFIX + request["request_id"]
        directory = Path(self.configuration["output_root"]) / identity
        if directory.exists():
            raise FileExistsError("Existing workflow IDs cannot be imported, overwritten or resumed")
        self.registry_root.mkdir(parents=True, exist_ok=True)
        entry = self.registry_root / identity
        entry.mkdir(exist_ok=False)
        value = {"schema_version": 1, "owner": OWNER, "workflow_id": identity, "request": request,
                 "configuration": self.configuration, "started_epoch": started_epoch,
                 "started_monotonic": started_monotonic,
                 "deadline_epoch": started_epoch + request["budget"]["wall_seconds"],
                 "deadline_monotonic": started_monotonic + request["budget"]["wall_seconds"], "source_state": sources}
        registration_path = entry / "registration.json"
        _write_exclusive(registration_path, value)
        with (entry / "registration.sha256").open("x", encoding="ascii") as stream:
            stream.write(_sha(registration_path) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        if _remaining(value) <= 0:
            _failure(entry, "original_deadline_expired_before_launch")
            return self.get_status({"workflow_id": identity})
        environment = {name: os.environ[name] for name in ("SystemRoot", "WINDIR", "TEMP", "TMP", "PATH") if name in os.environ}
        environment.update({"PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})
        if self.source_lock is not None:
            environment[LOCK_PATH_ENV] = self.source_lock["path"]
            environment[LOCK_SHA_ENV] = self.source_lock["sha256"]
        try:
            with (entry / "worker_stdout.log").open("xb") as stdout, (entry / "worker_stderr.log").open("xb") as stderr:
                process = subprocess.Popen([sys.executable, "-B", "-m", OWNER, "--worker", str(registration_path)],
                                           cwd=str(PROJECT_ROOT), env=environment, stdin=subprocess.DEVNULL,
                                           stdout=stdout, stderr=stderr,
                                           creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            self._processes[identity] = process
            _write_exclusive(entry / "launch.json", {"pid": process.pid, "launched_epoch": time.time(),
                                                    "registration_sha256": _sha(registration_path)})
        except Exception as error:
            _failure(entry, "worker_launch_failed", str(error))
        return self.get_status({"workflow_id": identity})

    def get_status(self, arguments):
        if type(arguments) is not dict or set(arguments) != {"workflow_id"}:
            raise ValueError("get_status accepts only workflow_id")
        identity = _workflow_id(arguments["workflow_id"])
        entry = self.registry_root / identity
        if not entry.is_dir():
            raise ValueError("workflow_id is not registered by this server")
        registration = _registration(entry / "registration.json")
        if registration["configuration"] != self.configuration:
            raise ValueError("Owned workflow configuration differs from this server")
        directory = Path(self.configuration["output_root"]) / identity
        try:
            if _source_state(self.source_lock) != registration["source_state"]:
                raise ValueError("Runtime source changed after registration")
            if _quarantine_late(directory, registration["deadline_epoch"]):
                _failure(entry, "late_controller_completion_rejected")
            failure_path = entry / "wrapper_failure.json"
            if failure_path.is_file():
                # A timed-out worker can finish later. Never resurrect its marker.
                _quarantine_late(directory, registration["deadline_epoch"])
                return {"workflow_id": identity, **{key: _read(failure_path)[key] for key in
                        ("status", "error_code", "resumable", "unknown_business_cost")},
                        "original_deadline_epoch": registration["deadline_epoch"]}
            exited = _read(entry / "worker_exit.json") if (entry / "worker_exit.json").is_file() else None
            # Completion becomes visible to the adapter only after its own
            # worker has checked the earlier wrapper deadline and closed.
            if (directory / "completion.json").is_file() and exited is not None and exited.get("exit_code") == 0:
                _verify_clock_handoff(registration, entry, directory)
                from .research_workflow_v1 import read_workflow_status
                result = read_workflow_status(directory)
                if result.get("status") != "completed" or result.get("verification", {}).get("status") != "passed":
                    raise ValueError("Independent completed workflow verification failed")
                if _source_state(self.source_lock) != registration["source_state"]:
                    raise ValueError("Runtime source changed during verification")
                return _summary(registration, directory, result)
            if (directory / "failure.json").is_file():
                _failure(entry, "controller_failed")
            elif exited is not None:
                _failure(entry, "worker_exited_without_verified_completion")
            elif _remaining(registration) <= 0:
                _failure(entry, "original_deadline_expired")
            else:
                process = self._processes.get(identity)
                launch = _read(entry / "launch.json") if (entry / "launch.json").is_file() else None
                if process is not None and process.poll() is not None:
                    _failure(entry, "worker_exited_without_verified_completion")
                elif launch is not None and not _pid_alive(launch["pid"]):
                    _failure(entry, "worker_exited_without_verified_completion")
                else:
                    return {"workflow_id": identity, "status": "running",
                            "original_deadline_epoch": registration["deadline_epoch"], "resumable": False}
        except Exception as error:
            _failure(entry, "source_or_evidence_verification_failed", str(error))
        failure = _read(entry / "wrapper_failure.json")
        return {"workflow_id": identity, **{key: failure[key] for key in
                ("status", "error_code", "resumable", "unknown_business_cost")},
                "original_deadline_epoch": registration["deadline_epoch"]}


def worker(registration_path):
    """Run once from an owned registration, preserving its earlier deadline."""
    path = Path(registration_path).resolve()
    registration = _registration(path)
    entry = path.parent
    _write_exclusive(entry / "worker_started.json", {"pid": os.getpid(), "started_epoch": time.time()})
    code = 1
    try:
        if (entry / "wrapper_failure.json").exists() or _remaining(registration) <= 0:
            raise ValueError("Original entry deadline expired or entry already failed")
        pin = _deployment_pin()
        if pin != registration["source_state"].get("deployment_source_lock"):
            raise ValueError("Worker deployment source lock differs from registration")
        if _source_state(pin) != registration["source_state"]:
            raise ValueError("Runtime or frozen workflow source changed before worker")
        from .research_workflow_clock_v2 import run_workflow
        anchor = _clock_anchor(registration, path)
        request = {**registration["request"], "budget": {**registration["request"]["budget"],
                                                      "wall_seconds": anchor["remaining_wall_seconds"]}}
        _write_exclusive(entry / "worker_clock_anchor.json", anchor)
        _write_exclusive(entry / "worker_request.json", request)
        result = run_workflow(request, registration["configuration"], trusted_clock_anchor=anchor)
        directory = Path(registration["configuration"]["output_root"]) / registration["workflow_id"]
        if _quarantine_late(directory, registration["deadline_epoch"]):
            _failure(entry, "late_controller_completion_rejected")
        elif result.get("status") != "completed":
            _failure(entry, "controller_failed")
        else:
            code = 0
    except Exception as error:
        _failure(entry, "worker_failed", str(error))
    finally:
        _write_exclusive(entry / "worker_exit.json", {"exit_code": code, "finished_epoch": time.time()})
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", required=True, type=Path)
    return worker(parser.parse_args().worker)


if __name__ == "__main__":
    raise SystemExit(main())
