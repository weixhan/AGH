"""Shared CableInspect-AD rotated COCO box geometry for horizontal detection.

The rotation attribute turns the four xywh corners around the box centre.
Positive angles follow the official formula (clockwise in image coordinates).
Keep full precision until labels are serialized; clip only after rotation.
"""
from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

GEOMETRY_VERSION = "hbb_v1"


def rotated_bbox_corners(
    bbox: Sequence[float], rotation: float = 0.0
) -> tuple[tuple[float, float], ...]:
    if len(bbox) != 4:
        raise ValueError("COCO bbox must contain four xywh values")
    x, y, width, height = map(float, bbox)
    angle = float(rotation)
    if not all(math.isfinite(value) for value in (x, y, width, height, angle)):
        raise ValueError("Box coordinates and rotation must be finite")
    if width <= 0 or height <= 0:
        raise ValueError("Box width and height must be positive")
    cx, cy = x + width / 2.0, y + height / 2.0
    cosine, sine = math.cos(math.radians(angle)), math.sin(math.radians(angle))
    return tuple(
        (cx + cosine * dx - sine * dy, cy + sine * dx + cosine * dy)
        for dx, dy in (
            (-width / 2.0, -height / 2.0),
            (width / 2.0, -height / 2.0),
            (width / 2.0, height / 2.0),
            (-width / 2.0, height / 2.0),
        )
    )


coco_bbox_to_rotated_corners = rotated_bbox_corners


def coco_bbox_to_hbb(
    bbox: Sequence[float], img_w: float, img_h: float, rotation: float = 0.0
) -> tuple[tuple[float, float, float, float] | None, bool]:
    img_w, img_h = float(img_w), float(img_h)
    if not all(math.isfinite(v) and v > 0 for v in (img_w, img_h)):
        raise ValueError("Image dimensions must be finite and positive")
    corners = rotated_bbox_corners(bbox, rotation)
    raw = (
        min(point[0] for point in corners), min(point[1] for point in corners),
        max(point[0] for point in corners), max(point[1] for point in corners),
    )
    clipped = (
        max(0.0, min(img_w, raw[0])), max(0.0, min(img_h, raw[1])),
        max(0.0, min(img_w, raw[2])), max(0.0, min(img_h, raw[3])),
    )
    changed = any(abs(a - b) > 1e-8 for a, b in zip(raw, clipped))
    if clipped[2] <= clipped[0] or clipped[3] <= clipped[1]:
        return None, True
    return clipped, changed


def coco_bbox_to_yolo(
    bbox: Sequence[float], img_w: float, img_h: float, rotation: float = 0.0
) -> tuple[list[float] | None, bool]:
    hbb, clipped = coco_bbox_to_hbb(bbox, img_w, img_h, rotation)
    if hbb is None:
        return None, clipped
    x1, y1, x2, y2 = hbb
    return [
        (x1 + x2) / (2.0 * img_w), (y1 + y2) / (2.0 * img_h),
        (x2 - x1) / img_w, (y2 - y1) / img_h,
    ], clipped


def annotation_to_hbb(
    annotation: Mapping[str, Any], img_w: float, img_h: float
) -> tuple[tuple[float, float, float, float] | None, bool]:
    rotation = (annotation.get("attributes") or {}).get("rotation", 0.0)
    return coco_bbox_to_hbb(annotation["bbox"], img_w, img_h, rotation)
