// Authorized, reversible activation via the official local plugin-admin BFF.
import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-scoped-evidence');
const id = '@defect-researcher/evidence-scope-guard';
const origin = 'http://127.0.0.1:4177';
const retry = process.argv.includes('--retry');
const tracePath = join(output, retry ? 'activation-v2.json' : 'activation.json');
const trace = { schema_version: 1, interface: 'official plugin-admin BFF', origin,
  user_authorized: true, started_at: new Date().toISOString(), package_id: id,
  steps: [], complete: false, credentials_read: false, agh_core_modified: false };
await writeFile(tracePath, JSON.stringify(trace, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(tracePath, JSON.stringify(trace, null, 2) + '\n');
async function request(path, body) {
  const response = await fetch(`${origin}/admin/plugins/api/${path}`, { method: body ? 'POST' : 'GET',
    headers: { Origin: origin, Accept: 'application/json', 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(30_000) });
  const data = await response.json();
  if (!response.ok) throw new Error(`${path}: ${response.status}: ${JSON.stringify(data)}`);
  return data;
}
try {
  const context = await request('context');
  if (context.readOnly || context.profile !== 'local-dev') throw new Error('Expected writable local-dev plugin administration');
  const base = { profile: context.profile, clientId: context.clientId };
  const before = await request('list', { profile: base.profile });
  const existing = before.packages.find(row => row.id === id);
  if (existing && (!retry || existing.actual !== 'not-running' || existing.trusted))
    throw new Error('Scope plugin already exists outside the inspected failed-install state');
  trace.before = existing ?? null;
  async function effect(path, body) {
    const params = { ...base, commandId: `scope-${randomUUID()}`, ...body };
    const step = { path, params };
    trace.steps.push(step); await save();
    step.receipt = await request(path, params); await save();
    const deadline = Date.now() + 60_000;
    for (;;) {
      step.operation = await request('operation/get', { profile: base.profile, operationId: step.receipt.operationId });
      await save();
      if (['completed', 'failed', 'cancelled', 'rolled-back'].includes(step.operation.state)) break;
      if (Date.now() >= deadline) throw new Error(`${path} operation timeout`);
      await new Promise(resolveWait => setTimeout(resolveWait, 500));
    }
    if (step.operation.state !== 'completed') throw new Error(`${path} failed: ${JSON.stringify(step.operation)}`);
    console.log(JSON.stringify({ action: path, state: step.operation.state }));
    return step.operation;
  }
  const source = { type: 'file', ref: 'file:./outputs/agh-scoped-evidence/workspace/.agh/extensions/evidence-scope-guard' };
  const inspected = await effect('inspect', { source });
  const preview = inspected.preview ?? inspected.result?.preview;
  if (!preview || preview.id !== id || preview.blockers.length || preview.dependencies && Object.keys(preview.dependencies).length)
    throw new Error('Unexpected or blocked scope-plugin preview');
  trace.preview = preview; await save();
  await effect(existing ? 'update' : 'install', { ...(existing ? { id } : {}), source, expectedIntegrity: preview.integrity });
  await effect('trust', { id, expectedIntegrity: preview.integrity, capabilityHash: preview.capabilityHash });
  await effect('enable', { id, expectedInstalledIntegrity: preview.integrity, expectedActiveIntegrity: null });
  const listed = await request('list', { profile: base.profile });
  trace.after = listed.packages.find(row => row.id === id);
  trace.complete = trace.after?.trusted === true && trace.after?.actual === 'running' && trace.after?.actualIntegrity === preview.integrity;
  trace.withdrawal = { interface: 'official plugin-admin BFF', path: 'disable',
    params: { profile: base.profile, clientId: base.clientId, commandId: '<new unique command id>', id } };
  if (!trace.complete) throw new Error('Scope plugin did not reach trusted running state');
} catch (error) {
  trace.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  trace.finished_at = new Date().toISOString(); await save();
  console.log(JSON.stringify({ complete: trace.complete, path: tracePath, failure: trace.failure }));
}
