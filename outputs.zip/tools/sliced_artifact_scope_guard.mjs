// Completed artifact evidence may be read exactly once in a fresh pinned session.
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const normalizeScopePath = value => typeof value === 'string' ? value.replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase() : '';
export function createSlicedArtifactScopeGuard(policy) {
  if (!record(policy) || Object.keys(policy).sort().join(',') !==
      'max_status_calls,qualified_status_tool,schema_version,task_id,workspace_root' ||
      policy.schema_version !== 1 || !normalizeScopePath(policy.workspace_root) ||
      !/^[a-f0-9]{32}$/.test(policy.task_id) ||
      !/^mcp_[a-zA-Z0-9_]+_get_task_status$/.test(policy.qualified_status_tool) ||
      policy.max_status_calls !== 1) throw new Error('Invalid sliced artifact scope policy');
  const pinned = structuredClone(policy), sessions = new Map();
  const deny = reason => ({ allow: false, reason: `SLICED_ARTIFACT_SCOPE_DENIED: ${reason}` });
  return (payload, context) => {
    const session = context?.session;
    if (!record(session) || typeof session.key !== 'string' || !session.key ||
        normalizeScopePath(session.workspaceRoot) !== normalizeScopePath(pinned.workspace_root)) return deny('outside pinned workspace');
    if (context.replayed === true) return deny('replayed invocation');
    if (!record(payload) || payload.name !== pinned.qualified_status_tool) return deny('only pinned completed-task status is allowed');
    if (typeof payload.toolUseId !== 'string' || !payload.toolUseId) return deny('missing call identity');
    if (!record(payload.args) || Object.keys(payload.args).join(',') !== 'task_id' || payload.args.task_id !== pinned.task_id)
      return deny('arguments must identify the pinned completed task');
    const state = sessions.get(session.key) ?? { calls: 0, accepted: new Set() };
    if (state.accepted.has(payload.toolUseId)) return deny('duplicate call identity');
    if (state.calls >= pinned.max_status_calls) return deny('completed-task status may be read once');
    state.calls++; state.accepted.add(payload.toolUseId); sessions.set(session.key, state);
    return { allow: true };
  };
}
