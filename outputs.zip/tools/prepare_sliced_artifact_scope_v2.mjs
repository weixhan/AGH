import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-sliced-artifact-model-v2'), workspace = join(output, 'workspace');
const candidate = join(workspace, '.agh', 'extensions', 'sliced-artifact-scope-guard-v2');
const policy = { schema_version: 1, workspace_root: workspace, task_id: 'c6be75d9328844308bd7987dbf13faec',
  qualified_status_tool: 'mcp_defect_researcher_45e5cef9_get_task_status', max_status_calls: 1 };
await mkdir(candidate, { recursive: true });
const saveNew = (path, value) => writeFile(path, value, { flag: 'wx', mode: 0o600 });
await saveNew(join(candidate, 'policy.json'), JSON.stringify(policy, null, 2) + '\n');
await copyFile(join(root, 'tools', 'sliced_artifact_scope_guard.mjs'), join(candidate, 'guard.mjs'), 1);
const entry = `import { createSlicedArtifactScopeGuard, normalizeScopePath } from './guard.mjs';\n` +
 `export const slicedArtifactScopeGuard = { inject: ['extension'], apply(ctx) {\n` +
 `  const policy = ${JSON.stringify(policy)};\n` +
 `  const guard = createSlicedArtifactScopeGuard(policy), agnes = ctx.extension();\n` +
 `  const scoped = hctx => normalizeScopePath(hctx?.session?.workspaceRoot) === normalizeScopePath(policy.workspace_root);\n` +
 `  agnes.registerHook('session_start', async (_payload, hctx) => {\n` +
 `    if (scoped(hctx)) await agnes.events.append('scope-ready', { session_key: hctx.session.key, workspace_root: hctx.session.workspaceRoot, mode: 'artifact-recovery', policy });\n` +
 `  });\n` +
 `  agnes.registerHook('tool_call', async (payload, hctx) => {\n` +
 `    if (!scoped(hctx)) return { allow: true };\n` +
 `    const verdict = guard(payload, hctx);\n` +
 `    await agnes.events.append('scope-decision', { session_key: hctx.session.key, name: payload.name, tool_use_id: payload.toolUseId, allow: verdict.allow, reason: verdict.reason ?? null });\n` +
 `    return verdict;\n` +
 `  });\n` +
 `} };\n`;
await saveNew(join(candidate, 'index.mjs'), entry);
await saveNew(join(candidate, 'package.json'), JSON.stringify({ name: '@defect-researcher/sliced-artifact-scope-guard-v2',
 version: '0.1.0', private: true, license: 'Apache-2.0', type: 'module', exports: './index.mjs',
 agnes: { plugins: [{ export: 'slicedArtifactScopeGuard', id: 'ext:defect-researcher/sliced-artifact-scope-guard-v2', inject: ['extension'] }] }
}, null, 2) + '\n');
const candidate_sha256 = {};
for (const name of ['policy.json', 'guard.mjs', 'index.mjs', 'package.json'])
 candidate_sha256[name] = createHash('sha256').update(await readFile(join(candidate, name))).digest('hex');
await saveNew(join(output, 'scope_candidate.json'), JSON.stringify({ schema_version: 1, prepared_at: new Date().toISOString(),
 status: 'prepared_not_activated', candidate, workspace, policy, candidate_sha256, model_called: false,
 credentials_read: false, agh_core_modified: false, old_plugins_modified: false, new_detection_inference_performed: false }, null, 2) + '\n');
console.log(JSON.stringify({ status: 'prepared_not_activated', candidate, workspace }));
