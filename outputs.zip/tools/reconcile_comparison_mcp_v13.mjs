// Recover only the registered local service; preserve its first failed receipt.
import {readFile,writeFile} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),stage=process.argv[2];
if(!['diagnostic','pilot','formal'].includes(stage))throw new Error('Stage required');
const out=join(root,'outputs/comparison-suite-v13-'+stage),origin='http://127.0.0.1:4177';
const protocol=JSON.parse(await readFile(join(out,'model_protocol.json'),'utf8'));
const original=JSON.parse(await readFile(join(out,'mcp_activation.json'),'utf8'));
const stable=v=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const sha=v=>createHash('sha256').update(v).digest('hex');
const trace={schema_version:1,status:'running',original_activation_status:original.status,server_id:protocol.server_id,steps:[],model_requests:0};
const target=join(out,'mcp_reconciliation.json');await writeFile(target,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(target,JSON.stringify(trace,null,2)+'\n');
async function api(path,body){const response=await fetch(origin+'/admin/resources/api/'+path,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});const value=await response.json();if(!response.ok)throw new Error(path+' '+response.status+' '+JSON.stringify(value));return value;}
try{
 const context=await api('context');if(context.readOnly||context.profile!=='local-dev')throw new Error('Expected local administration');
 const base={profile:context.profile,clientId:context.clientId};
 trace.before=await api('mcp/get',{profile:base.profile,serverId:protocol.server_id});
 if(stable(trace.before.definition)!==stable(original.definition)||trace.before.trust!=='trusted')throw new Error('Original trusted service definition changed');
 for(const route of ['mcp/test','mcp/enable']){
  const current=await api('mcp/get',{profile:base.profile,serverId:protocol.server_id});
  const step={route,receipt:await api(route,{...base,commandId:'comparison-recovery-'+randomUUID(),serverId:protocol.server_id,expectedRevision:current.revision})};trace.steps.push(step);await save();
  const deadline=Date.now()+60000;
  for(;;){step.operation=await api('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();if(['succeeded','failed','cancelled'].includes(step.operation.state))break;if(Date.now()>=deadline)throw new Error('Original admin-operation deadline expired');await new Promise(r=>setTimeout(r,500));}
  console.log(JSON.stringify({route,state:step.operation.state,error:step.operation.lastSafeError}));
  if(step.operation.state!=='succeeded')throw new Error('Service operation failed safely');
 }
 trace.after=await api('mcp/get',{profile:base.profile,serverId:protocol.server_id});
 trace.tools=await api('mcp/tools',{profile:base.profile,serverId:protocol.server_id});
 const common=JSON.parse(await readFile(join(out,'protocol.json'),'utf8')).common.tool_catalog;
 if(trace.after.actual!=='ready'||trace.after.desired!=='enabled'||trace.after.trust!=='trusted'||stable(trace.tools.items)!==stable(common))throw new Error('Service or catalogue did not close');
 trace.status='passed';trace.definition_preserved=true;trace.original_receipt_preserved_sha256=sha(await readFile(join(out,'mcp_activation.json')));
}catch(error){trace.status='failed';trace.error={type:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,error:trace.error}));}
