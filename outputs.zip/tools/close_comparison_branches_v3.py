"""Freeze V9 diagnostic evidence and the local AGH patch, preserving all failures."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / 'outputs/comparison-pilot-v9'
OUT = ROOT / 'outputs/comparison-implementation-v9'


def read(path):
    return json.loads(Path(path).read_text('utf8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def check(rows):
    for row in rows:
        if sha(row['path']) != row['sha256']:
            raise ValueError('Protected bytes changed: ' + row['path'])


def main():
    acceptance = read(PILOT / 'verification.json')
    if acceptance['status'] not in {'passed_branch_diagnostic', 'failed'}:
        raise ValueError('Diagnostic has no terminal independent review')
    history = []
    inventories = [
        ('research-workflow-implementation-v1/freeze.json', ('sources', 'archive', 'preserved_files')),
        ('research-mcp-implementation-v2/freeze.json', ('sources', 'archive', 'proof_files')),
        *[(f'comparison-implementation-v{v}/freeze.json', ('sources', 'archive', 'proof_files')) for v in (6, 7, 8)],
        ('agh-research-workflow-model-v3/previous_state.json', ('files',)),
    ]
    for name, groups in inventories:
        path = ROOT / 'outputs' / name
        value = read(path)
        rows = [row for group in groups for row in value[group]]
        check(rows)
        if 'comparison-implementation-v7/' in name or 'comparison-implementation-v8/' in name:
            if value['status'] != 'failed_diagnostic_preserved':
                raise ValueError('Historical failure was reclassified')
        history.append({'inventory': record(path), 'checked_records': len(rows), 'unchanged': True,
                        'original_status': value.get('status'), 'overlap_not_added': True})
    pins = []
    for version in range(1, 9):
        path = ROOT / f'outputs/comparison-implementation-v{version}/source_lock.json'
        rows = read(path)['files']
        check(rows)
        pins.append({'source_lock': record(path), 'checked_records': len(rows), 'unchanged': True})
    with (PILOT / 'history_preservation.json').open('x', encoding='utf8') as stream:
        json.dump({'status': 'passed_preservation', 'protected_history': history,
                   'earlier_source_pins': pins, 'original_failures_and_deadlines_unchanged': True}, stream, indent=2)
    sources = read(OUT / 'source_lock.json')['files']
    check(sources)
    candidate = read(PILOT / 'scope_candidate.json')
    check(candidate['files'])
    archive_root = OUT / 'source'
    archive_root.mkdir()
    archive = []
    for index, source in enumerate(sources):
        target = archive_root / f'{index:03d}_{Path(source["path"]).name}'
        shutil.copyfile(source['path'], target)
        row = record(target)
        if row['sha256'] != source['sha256']:
            raise ValueError('Source archive differs')
        archive.append({**row, 'source_path': source['path']})
    proofs = set()
    for directory in (PILOT, ROOT / 'outputs/agh-title-repair-v1'):
        proofs.update(path.resolve() for path in directory.rglob('*') if path.is_file()
                      and 'workspace' not in path.relative_to(directory).parts and '__pycache__' not in path.parts)
    proofs.update(Path(row['path']).resolve() for row in candidate['files'])
    proofs.update(path.resolve() for path in OUT.glob('*.json'))
    frozen = {'schema_version': 1,
              'status': 'passed_branch_diagnostic_frozen' if acceptance['status'] == 'passed_branch_diagnostic' else 'failed_diagnostic_preserved',
              'checked_at': datetime.now(timezone.utc).isoformat(),
              'scope': 'Fresh one-case refusal diagnostic on modified AGH; legacy title usage remains unknown',
              'source_lock': record(OUT / 'source_lock.json'), 'sources': sources, 'archive': archive,
              'proof_files': [record(path) for path in sorted(proofs)],
              'protected_history': history, 'earlier_comparison_source_pins': pins,
              'models_this_closure': 0, 'new_detector_calls': 0, 'gpu_seconds': 0,
              'legacy_token_usage_closed': False, 'original_failures_and_deadlines_unchanged': True,
              'not_a_complete_nine_trial_pilot': True}
    with (OUT / 'freeze.json').open('x', encoding='utf8') as stream:
        json.dump(frozen, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': frozen['status'], 'sources': len(sources), 'archive': len(archive),
                      'proof_files': len(proofs), 'protected_history_checked': [r['checked_records'] for r in history]}))


if __name__ == '__main__':
    main()
