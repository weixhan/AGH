// One authorized real Agnes run, using the official SDK and unchanged single-call approval.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, origin, finishEventReading } from './agh_ws_client.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-label-repair');
const prompt = await readFile(join(root, 'agent', 'label_repair_task.md'), 'utf8');
await mkdir(output, { recursive: true });
const record = { schema_version: 1, interface: 'official AGH SDK over the existing loopback web endpoint',
  origin, model: 'agnes-3.0-flash', route: 'account-defect-researcher',
  prompt_sha256: createHash('sha256').update(prompt).digest('hex'),
  qualified_tool: 'mcp_defect_researcher_45e5cef9_repair_label_copy',
  user_authorized: true, started_at: new Date().toISOString(), permissions: [], calls: [], polls: [], status: 'starting' };
const recordPath = join(output, 'runner.json');
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { mode: 0o600 });
const client = await webClient();
let session;
let iterator;
let reading;
let approvalCount = 0;
let heartbeat;
const abort = new AbortController();
const deadline = setTimeout(() => abort.abort(), 20 * 60 * 1000);

async function officialExport(format, filename) {
  const reader = await webClient();
  try {
    await exportSession({ positional: [session.id], format, raw: false, out: join(output, filename) }, {
      cwd: root, io: { stdout: process.stdout, stderr: process.stderr },
      writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
    }, reader);
  } finally { await reader.close(); }
}

try {
  const registration = JSON.parse(await readFile(join(output, 'registration.json'), 'utf8'));
  if (!registration.complete || registration.status.toolCount !== 4) throw new Error('Approved MCP scope is not ready');
  session = await client.session.new({ cwd: root, sessionKey: randomUUID() });
  record.session_id = session.id;
  record.session_url = origin + '/?session=' + encodeURIComponent(session.id);
  await save();
  console.log(JSON.stringify({ session_id: session.id, url: record.session_url }), '\n');
  session.onPermissionRequest(async (request) => {
    const tool = request.toolCall?._meta?.['ai.agnes.harness']?.tool;
    const input = request.toolCall?.rawInput;
    const once = request.options.find(option => option.kind === 'allow_once');
    const authorized = request.sessionId === session.id && tool === record.qualified_tool
      && input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === 0
      && approvalCount === 0 && Boolean(once);
    record.permissions.push({ at: new Date().toISOString(), tool, input,
      tool_call_id: request.toolCall?.toolCallId, decision: authorized ? 'allowed-once' : 'rejected' });
    if (authorized) approvalCount++;
    await save();
    console.log(JSON.stringify({ approval: authorized ? 'allowed-once' : 'rejected', tool }));
    return authorized ? { optionId: once.optionId } : { verdict: 'rejected' };
  });
  await session.setModel({ slot: 'primary', route: record.route, model: record.model });
  iterator = session.events()[Symbol.asyncIterator]();
  reading = (async () => {
    while (true) {
      const next = await iterator.next();
      if (next.done) break;
      const event = next.value;
      if (event.type === 'tool/call') {
        record.calls.push({ seq: event.seq, origin: event.origin, name: event.data.name, args: event.data.args });
        await save();
        console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
      }
      if (event.type === 'tool/result') {
        const text = event.data.content?.find(block => block.type === 'text')?.text;
        if (text) {
          try {
            const result = JSON.parse(text);
            if (result.task_id) {
              record.task_id ??= result.task_id;
              record.polls.push({ seq: event.seq, task_id: result.task_id, status: result.status,
                stage: result.current_stage, summary: result.status === 'completed' ? result.summary : undefined });
              await save();
              console.log(JSON.stringify({ task_id: result.task_id, status: result.status, stage: result.current_stage }));
            }
          } catch { /* The official export retains the authoritative tool payload. */ }
        }
      }
      if (event.type === 'turn/end') break;
    }
  })();
  record.status = 'running';
  await save();
  heartbeat = setInterval(() => console.log(JSON.stringify({ running: true, task_id: record.task_id,
    last_status: record.polls.at(-1)?.status, elapsed_seconds: Math.round((Date.now() - Date.parse(record.started_at)) / 1000) })), 30_000);
  record.turn_result = await session.prompt(prompt, { signal: abort.signal, titleLocale: 'zh-CN' });
  await finishEventReading(reading);
  record.status = 'turn_finished';
  await save();
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  clearTimeout(deadline);
  clearInterval(heartbeat);
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  if (session) {
    try {
      await officialExport('agnes', 'session.jsonl');
      await officialExport('html', 'session.html');
      record.official_redacted_exports = ['session.jsonl', 'session.html'];
    } catch (error) {
      record.export_failure = { type: error.name, message: error.message };
      process.exitCode = 1;
    }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: record.session_id, task_id: record.task_id, output,
    failure: record.failure, export_failure: record.export_failure }));
}
