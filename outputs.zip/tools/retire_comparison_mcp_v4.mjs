import {writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
const origin='http://127.0.0.1:4177',serverId='dr-compare-v4',path='outputs/comparison-pilot-v4/retirement.json';
async function api(route,body){const r=await fetch(origin+'/admin/resources/api/'+route,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});if(!r.ok)throw new Error('Official admin request failed');return r.json();}
const context=await api('context');if(context.profile!=='local-dev'||context.readOnly)throw new Error('Wrong context');
const before=await api('mcp/get',{profile:context.profile,serverId});
if(before.desired!=='enabled')throw new Error('Unexpected original deployment');
const params={profile:context.profile,clientId:context.clientId,commandId:'retire-compare-'+randomUUID(),serverId,expectedRevision:before.revision};
const receipt=await api('mcp/disable',params),deadline=Date.now()+60000;let operation;
for(;;){operation=await api('operations/get',{profile:context.profile,operationId:receipt.operationId});if(['succeeded','failed','cancelled'].includes(operation.state))break;if(Date.now()>=deadline)throw new Error('Original admin deadline expired');await new Promise(y=>setTimeout(y,400));}
const after=await api('mcp/get',{profile:context.profile,serverId});
const status=operation.state==='succeeded'&&after.desired==='disabled'&&after.actual==='disabled'?'passed':'failed';
await writeFile(path,JSON.stringify({schema_version:1,status,reason:'Preserve Incomplete native title accounting deployment; replacement is separately registered V5',before,params,receipt,operation,after,model_requests_actual:5},null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status,actual:after.actual}));if(status!=='passed')process.exitCode=1;
