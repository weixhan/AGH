// Real local stdio calls, with the deployment pin; no Agnes or network model.
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const output=join(root,'outputs','research-mcp-local-acceptance-v2');
await mkdir(output,{recursive:false});
const lock=join(root,'outputs','research-mcp-implementation-v2','source_lock-model.json');
const sha=createHash('sha256').update(await readFile(lock)).digest('hex');
if(sha!=='2555fa18ec8ea33bee5744679b7d42b62725d990b8e87bda3a9fa88c5705fbb6')throw new Error('Deployment lock changed');
const modules=resolve(root,'..','agnes-harness','node_modules','.pnpm');
const sdkName=(await readdir(modules)).find(name=>name.startsWith('@modelcontextprotocol+sdk@1.25.2'));
if(!sdkName)throw new Error('Installed official MCP SDK absent');
const sdk=join(modules,sdkName,'node_modules','@modelcontextprotocol','sdk','dist','esm');
const {Client}=await import(pathToFileURL(join(sdk,'client/index.js')).href);
const {StdioClientTransport}=await import(pathToFileURL(join(sdk,'client/stdio.js')).href);
const client=new Client({name:'research-mcp-local-acceptance',version:'1'},{capabilities:{}});
const transport=new StdioClientTransport({command:'E:/Anaconda_envs/envs/MMIOC_env/python.exe',
 args:['-B',join(root,'run_research_mcp_v2.py'),'--config',join(root,'config/local.json'),
 '--source-lock',lock,'--expected-lock-sha256',sha],cwd:root,stderr:'pipe'});
const record={schema_version:1,status:'running',started_at:new Date().toISOString(),source_lock:{path:lock,sha256:sha},
 model_requests:0,new_inference_calls:0,calls:[],cases:[],checks:{}};
const recordPath=join(output,'acceptance.json');
await writeFile(recordPath,JSON.stringify(record,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(recordPath,JSON.stringify(record,null,2)+'\n');
async function call(name,args) {
 const started=Date.now(),result=await client.callTool({name,arguments:args});
 const blocks=result.content?.filter(row=>row.type==='text');
 const payload=blocks?.length===1?JSON.parse(blocks[0].text):null;
 record.calls.push({name,args,is_error:result.isError===true,payload,elapsed_ms:Date.now()-started});
 await save();return {payload,isError:result.isError===true};
}
try {
 await client.connect(transport);
 const tools=(await client.listTools()).tools;
 record.tool_catalog=tools;
 record.checks.exact_two_tool_catalog=JSON.stringify(tools.map(row=>row.name).sort())===JSON.stringify(['get_research_workflow_status_v1','run_bounded_research_workflow_v1']);
 for(const [suffix,case_id,cap,cost,outcome] of [['normal','normal_unrotated',6,2,'stopped'],
  ['repair','repair_coordinates',6,6,'stopped'],['refusal','refuse_source_hash',6,1,'refused'],
  ['budget-zero','normal_unrotated',0,0,'insufficient_evidence']]) {
  const args={request_id:`mcplocalv2-20261013-${suffix}`,case_id,
   budget:{domain_invocations:cap,wall_seconds:120,gpu_seconds:0,model_requests:0}};
  const started=await call('run_bounded_research_workflow_v1',args);
  let current=started,reads=0;
  const deadline=Date.now()+15000;
  while(!current.isError&&current.payload.status==='running'&&Date.now()<deadline) {
   await new Promise(done=>setTimeout(done,400));
   current=await call('get_research_workflow_status_v1',{workflow_id:started.payload.workflow_id});reads++;
  }
  const p=current.payload;
  const checks={execution_completed:!current.isError&&p.status==='completed',expected_outcome:p.research_status===outcome,
   expected_known_cost:p.domain_invocations===cost,fresh_independent_verification:p.verification?.status==='passed',
   no_new_inference:p.new_inference_calls===0,no_model_request:p.new_model_requests===0,
   owned_identity:p.workflow_id===`research-workflow-v1-${args.request_id}`};
  record.cases.push({case_id,arguments:args,reads,terminal:p,checks,passed:Object.values(checks).every(Boolean)});
  await save();console.log(JSON.stringify({case_id,passed:record.cases.at(-1).passed,reads,cost:p.domain_invocations}));
 }
 const duplicate=await call('run_bounded_research_workflow_v1',record.cases[0].arguments);
 record.checks.duplicate_start_rejected=duplicate.isError;
 const unknown=await call('get_research_workflow_status_v1',{workflow_id:'research-workflow-v1-unregistered'});
 record.checks.unknown_status_rejected=unknown.isError;
 let oldRejected=false;try{await client.callTool({name:'audit_dataset',arguments:{}});}catch(error){oldRejected=error.code===-32602;}
 record.checks.old_tool_rejected=oldRejected;
 record.checks.four_real_background_paths_passed=record.cases.length===4&&record.cases.every(row=>row.passed);
 record.checks.source_lock_unchanged=createHash('sha256').update(await readFile(lock)).digest('hex')===sha;
 record.status=Object.values(record.checks).every(Boolean)?'passed':'failed';
} catch(error) {record.status='failed';record.error={name:error.name,message:error.message};}
finally {await client.close();record.finished_at=new Date().toISOString();await save();}
console.log(JSON.stringify({status:record.status,checks:record.checks,error:record.error}));
if(record.status!=='passed')process.exitCode=1;
