// Continue the same real session to collect the terminal tool result, without launching a new repair.
import { readFile, writeFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, finishEventReading } from './agh_ws_client.mjs';

const output = 'outputs/agh-resolution-comparison';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
const previous = (await readFile(output + '/session-final.jsonl', 'utf8')).trim().split('\n').map(JSON.parse);
const afterSeq = previous.at(-1).seq;
if (!launch.task_id || launch.permissions.filter(row => row.decision === 'allowed-once').length !== 1) {
  throw new Error('Expected exactly one previously authorized repair');
}
const record = { started_at: new Date().toISOString(), session_id: launch.session_id, task_id: launch.task_id,
  existing_task_only: true, no_new_inference_task: true, calls: [], results: [], status: 'starting' };
const recordPath = output + '/finalization-v2.json';
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let iterator;
let reading;
try {
  const session = await client.session.load(launch.session_id, {
    cwd: process.cwd(), onPermissionRequest: async () => ({ verdict: 'rejected' }),
  });
  iterator = session.events()[Symbol.asyncIterator]();
  reading = (async () => {
    while (true) {
      const next = await iterator.next();
      if (next.done) break;
      const event = next.value;
      if (event.seq <= afterSeq) continue;
      if (event.type === 'tool/call') {
        record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
        await save();
        console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
      }
      if (event.type === 'tool/result') {
        const text = event.data.content?.find(block => block.type === 'text')?.text;
        if (text) {
          try {
            const result = JSON.parse(text);
            if (result.task_id) {
              record.results.push({ seq: event.seq, task_id: result.task_id, status: result.status, summary: result.summary });
              await save();
              console.log(JSON.stringify({ task_id: result.task_id, status: result.status, summary: result.summary }));
            }
          } catch { /* The final official export retains authoritative content. */ }
        }
      }
      if (event.type === 'turn/end') break;
    }
  })();
  record.status = 'running';
  await save();
  record.prompt = `先只调用一次get_task_status查询已完成任务 ${launch.task_id}，不要调用shell或其他工具、不重新启动推理。上一答复JSON缺少数组闭合，现仅输出一个有效JSON代码块，不要长分析。结构：{"status":"completed","task_id":"真实编号","train_imgsz":640,"eval_imgsz":[640,960],"weight_sha256":"真实hash","val_images":640,"val_boxes":596,"input_hashes_unchanged":true,"metrics":{"640":{"mAP50":真实值,"mAP50_95":真实值,"tp":真实值,"fp":真实值,"fn":真实值,"normal_image_fp_rate":真实值,"small_gt":真实值,"small_fn":真实值},"960":{同样八项}},"paired_recall":{"eligible_images":真实值,"mean_delta":真实值,"ci95":[真实两值]}}。所有数值原样复制，不四舍五入，闭合所有括号，不复制limitations字符串或environments。`;
  record.turn_result = await session.prompt(record.prompt, { titleLocale: 'zh-CN' });
  await finishEventReading(reading);
  record.status = 'turn_finished';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  for (const [format, filename] of [['agnes', 'session-final-v2.jsonl'], ['html', 'session-final-v2.html']]) {
    const reader = await webClient();
    try {
      await exportSession({ positional: [launch.session_id], format, raw: false, out: output + '/' + filename }, {
        cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
      }, reader);
    } finally { await reader.close(); }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: launch.session_id, task_id: launch.task_id }));
}
