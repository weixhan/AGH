"""Read-only aggregation of the preregistered V6 integration diagnostic."""
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / 'outputs/comparison-pilot-v6'


def read(path):
    return json.loads(Path(path).read_text('utf8'))


def save(path, value):
    with Path(path).open('x', encoding='utf8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    spec = importlib.util.spec_from_file_location('case_evaluator', ROOT/'tools/verify_comparison_case_v1.py')
    evaluator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evaluator)
    destination = PILOT/'business_verification'
    destination.mkdir(exist_ok=True)
    suite, protocol, public = (read(PILOT/name) for name in ['run_result.json', 'protocol.json', 'model_protocol.json'])
    results, model_runs = [], []
    for trial in suite['trials']:
        handle = trial['trial_handle']
        directory = PILOT/'runtime/trials'/handle
        business_path = destination/(handle+'.json')
        if business_path.exists():
            business = read(business_path)
        else:
            business = evaluator.verify(directory)
            save(business_path, business)
        engineering = read(trial['engineering_verification_path'])
        run = read(trial['record_path'])
        events = [json.loads(line) for line in (Path(trial['record_path']).parent/'session.jsonl').read_text('utf8').splitlines() if line.strip()] if trial['arm'] != 'C' else []
        primary = sum(event['type'] == 'request/sent' for event in events)
        native = sum(event['type'] == 'x/host/session-title' and event['data'].get('status') == 'requested' for event in events)
        if primary + native != trial['model_requests']:
            raise ValueError('Actual request ledger differs')
        registration, publication = read(directory/'registration.json'), read(directory/'publication.json')
        actions = [json.loads(line) for line in (directory/'actions.jsonl').read_text('utf8').splitlines() if line.strip()]
        results.append({
            'trial_id': trial['trial_id'], 'trial_handle': handle, 'case_id': registration['case_id'], 'arm': trial['arm'],
            'driver_status': trial['status'], 'engineering_status': engineering['status'],
            'engineering_checks_passed': engineering['checks_passed'], 'engineering_checks_total': engineering['checks_total'],
            'business_status': business['status'], 'business_checks_passed': business['passed_checks'], 'business_checks_total': business['total_checks'],
            'business_correct_completion': business['correct_completion'],
            'joint_correct_completion': trial['status'] == 'completed' and engineering['status'] == 'passed' and business['correct_completion'],
            'publication_accepted': business['group_publication_decision_accepted'],
            'invalid_artifact_accepted': business['invalid_artifact_accepted'], 'unsupported_atomic_claims': business['unsupported_atomic_claims'],
            'atomic_claims_total': business['atomic_claims_total'], 'main_model_requests': primary, 'native_title_requests': native,
            'actual_total_model_requests': primary+native, 'domain_invocations': business['used_domain_invocations'],
            'allow_once_count': len(run['permissions']) if trial['arm'] != 'C' else None,
            'actions': [row['record']['action'] for row in actions if row['event'] == 'action_finished'],
            'elapsed_seconds': (run['finished_epoch_ms']-run['started_epoch_ms'])/1000,
            'session_id': trial.get('session_id'), 'report_sha256': publication['candidate_sha256'],
            'business_verification_path': str(business_path), 'engineering_verification_path': trial['engineering_verification_path'],
            'record_path': trial['record_path']})
        if trial['arm'] != 'C':
            model_runs.append(run)
    unexecuted = [{**trial, 'status': 'not_selected_for_engineering_diagnostic',
                   'arm_file_absent': not (PILOT/'runtime/trials'/trial['trial_handle']/'arm.json').exists()}
                  for trial in protocol['trials'][public['engineering_diagnostic']['target_first_trials']:]]
    checks = {
        'diagnostic_first_three_exact_preregistered_trials': [row['trial_handle'] for row in results] == [row['trial_handle'] for row in protocol['trials'][:3]],
        'three_arms_same_normal_case': {row['arm'] for row in results} == {'C', 'U', 'F'} and {row['case_id'] for row in results} == {'normal_unrotated'},
        'joint_correct_all_three': all(row['joint_correct_completion'] for row in results),
        'all_published_reports_supported': all(row['unsupported_atomic_claims'] == 0 and not row['invalid_artifact_accepted'] for row in results),
        'diagnostic_requests_within_cap': sum(row['actual_total_model_requests'] for row in results) <= public['phase_model_budget']['this_pilot_cap'],
        'whole_phase_including_failures_within_original_cap': 17+sum(row['actual_total_model_requests'] for row in results) <= 48,
        'all_original_time_limits': all(row['elapsed_seconds'] < 120 for row in results),
        'engineering_source_inputs_and_approvals_passed': all(row['engineering_status'] == 'passed' for row in results),
        'agent_common_prompt_route_model_catalogue': all({key:run[key] for key in ['model', 'route', 'qualified_action_tool']} == {key:model_runs[0][key] for key in ['model', 'route', 'qualified_action_tool']} for run in model_runs) and all(run['request_events'][0]['data']['tool_schema_hash'] == model_runs[0]['request_events'][0]['data']['tool_schema_hash'] for run in model_runs),
        'six_remaining_trials_unarmed': len(unexecuted) == 6 and all(row['arm_file_absent'] for row in unexecuted)}
    summary = {
        'schema_version': 1, 'status': 'passed_engineering_diagnostic' if all(checks.values()) else 'failed',
        'checked_at': datetime.now(timezone.utc).isoformat(), 'scope': 'three arms on one normal synthetic case; not a complete pilot or formal benchmark',
        'checks': checks, 'executed_diagnostic_trials': 3, 'diagnostic_joint_correct': sum(row['joint_correct_completion'] for row in results),
        'planned_comparison_trials': 9, 'comparison_unexecuted_trials': 6, 'planned_comparison_per_arm': 3,
        'executed_per_arm': {'C': 1, 'U': 1, 'F': 1}, 'results': results, 'unexecuted': unexecuted,
        'model_requests_this_diagnostic': sum(row['actual_total_model_requests'] for row in results),
        'model_requests_prior_versions_including_failures_and_titles': 17, 'model_requests_phase_actual': 17+sum(row['actual_total_model_requests'] for row in results),
        'phase_cap': 48, 'domain_invocations_this_diagnostic': sum(row['domain_invocations'] for row in results),
        'recovery_time': 'not_measured', 'new_detector_calls': 0, 'new_training_runs': 0, 'gpu_seconds': 0,
        'conclusion': 'Normal-case turn/title integration accepted. No comparison superiority or recovery claim. Repair/refusal integration and a new full pilot remain pending.'}
    save(PILOT/'verification.json', summary)
    print(json.dumps({'status': summary['status'], 'checks': checks, 'results': [{key:row[key] for key in ['arm', 'engineering_checks_passed', 'engineering_checks_total', 'business_checks_passed', 'business_checks_total', 'actual_total_model_requests', 'domain_invocations', 'elapsed_seconds']} for row in results]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
