"""Fresh local acceptance over twelve cases and five budget boundaries; no model."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.labelguard_fixtures import load_case_spec
from defect_researcher import research_workflow_v1 as workflow
from defect_researcher.research_science_v1 import digest, file_record, read


def accept(output, prefix):
    output = Path(output).resolve()
    if not output.is_relative_to(ROOT / "outputs") or output.exists():
        raise ValueError("Acceptance requires a new directory beneath project outputs")
    configuration = load_config()
    output.mkdir(parents=True, exist_ok=False)
    before = workflow._sources(configuration["research_root"])
    cases = []
    clean_path = ["verify_label_geometry", "read_scientific_evidence"]
    repaired_path = ["verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence"]
    for case in load_case_spec()["cases"]:
        group = case["group"]
        cases.append({"id": case["id"], "case_id": case["id"], "group": group, "cap": 6, "wall": 120,
                      "expected_status": "completed", "expected_research": "refused" if group == "refused" else "stopped",
                      "expected_path": ["verify_label_geometry"] if group == "refused" else repaired_path if group == "repairable" else clean_path,
                      "expected_cost": 1 if group == "refused" else 6 if group == "repairable" else 2})
    for identity, case, cap, path, cost in (
        ("budget-zero", "normal_unrotated", 0, [], 0),
        ("budget-clean-one", "normal_unrotated", 1, clean_path[:1], 1),
        ("budget-repair-four", "repair_coordinates", 4, repaired_path[:2], 4),
        ("budget-repair-five", "repair_coordinates", 5, repaired_path[:3], 5),
    ):
        cases.append({"id": identity, "case_id": case, "group": "budget", "cap": cap, "wall": 120,
                      "expected_status": "completed", "expected_research": "insufficient_evidence",
                      "expected_path": path, "expected_cost": cost})
    cases.append({"id": "expired-original-deadline", "case_id": "normal_unrotated", "group": "deadline",
                  "cap": 6, "wall": 0.001, "expected_status": "failed", "expected_research": None,
                  "expected_path": [], "expected_cost": 0})
    rows = []
    for item in cases:
        request = {"schema_version": 1, "workflow_version": 1, "request_id": prefix + "-" + item["id"],
                   "case_id": item["case_id"], "budget": {"domain_invocations": item["cap"], "wall_seconds": item["wall"],
                   "gpu_seconds": 0, "model_requests": 0}}
        result = workflow.run_workflow(request, configuration)
        directory = Path(result["directory"])
        verification = workflow._checker(directory, prepublication=False) if result["status"] == "completed" else None
        observed_cost = result.get("domain_invocations", result.get("budget", {}).get("used_domain_invocations"))
        checks = {"expected_execution_status": result["status"] == item["expected_status"],
                  "expected_research_outcome": result.get("research_status") == item["expected_research"],
                  "actual_tool_path": result["actual_tool_path"] == item["expected_path"],
                  "closed_domain_cost": observed_cost == item["expected_cost"],
                  "no_new_inference": result["new_inference_calls"] == 0,
                  "no_model_requests": result["new_model_requests"] == 0}
        if verification is not None:
            checks.update({"fresh_independent_verification": verification["status"] == "passed",
                           "independent_prepublication_verification": read(directory / "independent_verification.json")["status"] == "passed",
                           "completion_last_exists": (directory / "completion.json").is_file(),
                           "original_inputs_unchanged": read(directory / "input_snapshots.json")["unchanged"] is True,
                           "within_original_deadline": read(directory / "completion.json")["completed_epoch"] < read(directory / "runtime.json")["deadline_epoch"]})
        else:
            checks.update({"failed_task_remains_markerless": not (directory / "completion.json").exists(),
                           "expired_original_deadline": result.get("budget", {}).get("expired") is True,
                           "failure_preserved": (directory / "failure.json").is_file()})
        row = {**item, "request": request, "directory": str(directory), "result": result,
               "fresh_verification": verification, "checks": checks, "passed": all(checks.values())}
        rows.append(row)
        workflow.write(output / "partial_acceptance.json", {"rows": rows})
        print(json.dumps({"case": item["id"], "status": result["status"], "research": result.get("research_status"),
                          "cost": observed_cost, "accepted": row["passed"], "error": result.get("error")}, ensure_ascii=False), flush=True)
    after = workflow._sources(configuration["research_root"])
    checks = {"seventeen_cases_accepted": len(rows) == 17 and all(row["passed"] for row in rows),
              "eighteen_execution_sources_unchanged": before == after,
              "four_input_groups_have_distinct_paths": len({tuple(row["result"]["actual_tool_path"]) for row in rows}) >= 4,
              "all_original_inputs_unchanged": all(read(Path(row["directory"]) / "input_snapshots.json")["unchanged"] is True
                                                   for row in rows if row["result"]["status"] == "completed")}
    report = {"schema_version": 1, "scope": "local_cpu_synthetic_inputs_and_sealed_validation_evidence",
              "status": "passed" if all(checks.values()) else "failed", "checked_at": datetime.now(timezone.utc).isoformat(),
              "cases": rows, "checks": checks, "passed_cases": sum(row["passed"] for row in rows), "total_cases": len(rows),
              "passed_checks": sum(sum(row["checks"].values()) for row in rows) + sum(checks.values()),
              "total_checks": sum(len(row["checks"]) for row in rows) + len(checks),
              "sources_before": before, "sources_after": after, "new_inference_calls": 0, "model_requests": 0,
              "runner": file_record(__file__, "acceptance_runner"),
              "limitations": ["A CPU controller acceptance, not an Agnes model conversation.",
                              "Artificial input and historical validation evidence are separate populations.",
                              "No fresh experiment, full 640/960 recovery, three-arm comparison or contest submission acceptance."]}
    workflow.write(output / "acceptance.json", report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--prefix", required=True)
    arguments = parser.parse_args()
    report = accept(arguments.output, arguments.prefix)
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
