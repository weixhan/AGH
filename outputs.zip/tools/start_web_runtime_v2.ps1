# Switch only this project's owned web process to the side-by-side event repair.
$ErrorActionPreference = 'Stop'
$taskProject = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskPython = 'E:\Anaconda_envs\envs\MMIOC_env\python.exe'
$taskNode = 'E:\nodejs24.15.0\node.exe'
$taskLauncher = Join-Path $taskProject 'run_agh.py'
$taskOld = [IO.Path]::GetFullPath((Join-Path $taskProject '..\agnes-harness\packages\cli\dist\local\agnes.mjs'))
$taskEntry = Join-Path $taskProject 'outputs\agh-title-repair-v2\runtime\packages\cli\dist\local\agnes.mjs'
$taskManifest = Get-Content -LiteralPath (Join-Path $taskProject 'outputs\agh-title-repair-v2\repair_verification.json') -Raw | ConvertFrom-Json
foreach ($taskPin in $taskManifest.runtime_files) {
  if ((Get-FileHash -LiteralPath $taskPin.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskPin.sha256) { throw 'Pinned V2 runtime changed' }
}
& $taskPython -X utf8 -B $taskLauncher --node $taskNode daemon stop --profile local-dev --workspace $taskProject --data-dir (Join-Path $taskProject '.runtime\agh\data')
if ($LASTEXITCODE -ne 0) { throw 'Official owned daemon stop failed' }
foreach ($taskListener in @(Get-NetTCPConnection -LocalPort 4177 -State Listen -ErrorAction SilentlyContinue)) {
  $taskOwner = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $taskListener.OwningProcess)
  $taskParent = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $taskOwner.ParentProcessId)
  if ($taskOwner.Name -ne 'node.exe' -or $taskOwner.ExecutablePath -ine $taskNode -or
      (-not $taskOwner.CommandLine.Contains($taskOld) -and -not $taskOwner.CommandLine.Contains($taskEntry)) -or
      -not $taskParent.CommandLine.Contains($taskLauncher)) { throw 'Port belongs to another process' }
  $taskHandle = Get-Process -Id $taskOwner.ProcessId
  $null = $taskHandle.Handle
  if ([Math]::Abs(($taskHandle.StartTime.ToUniversalTime() - $taskOwner.CreationDate.ToUniversalTime()).TotalMilliseconds) -ge 1) { throw 'Port process changed' }
  $taskHandle.Kill(); $null = $taskHandle.WaitForExit(10000)
  if (-not $taskHandle.HasExited) { throw 'Old web process did not exit' }
}
$taskStamp = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
$taskStdout = Join-Path $taskProject ('.runtime\web-v2-' + $taskStamp + '.stdout.log')
$taskStderr = Join-Path $taskProject ('.runtime\web-v2-' + $taskStamp + '.stderr.log')
$taskArgs = @('-B', ('"{0}"' -f $taskLauncher), '--node', ('"{0}"' -f $taskNode), '--entry', ('"{0}"' -f $taskEntry), 'serve')
$taskWeb = Start-Process -FilePath $taskPython -ArgumentList $taskArgs -WorkingDirectory $taskProject -WindowStyle Hidden -RedirectStandardOutput $taskStdout -RedirectStandardError $taskStderr -PassThru
[ordered]@{pid=$taskWeb.Id;started_at=$taskWeb.StartTime.ToUniversalTime().ToString('o');entry=$taskEntry;stdout=$taskStdout;stderr=$taskStderr;url='http://127.0.0.1:4177/'} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskProject '.runtime\web-process-v2.json') -Encoding UTF8
Write-Output ('V2 web launcher PID ' + $taskWeb.Id)
