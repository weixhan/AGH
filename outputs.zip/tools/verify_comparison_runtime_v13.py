"""Independent process, bundle, and native title acceptance for fresh V13 runs.

This adds runtime execution evidence to the separate model and business checks.
It never resumes a session or changes a historical acceptance result. The
runtime_binding receipt is an OS snapshot collected by the host, not model data.
"""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
AGH = ROOT.parent / "agnes-harness"
SAFE_INT = 9007199254740991
DIAGNOSTIC = "x/host/session-title/diagnostics"


def require(value, message):
    if not value:
        raise ValueError(message)


def decode(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def read(path):
    return decode(Path(path).read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stamp(value):
    require(type(value) is str, "Missing typed timestamp")
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(parsed.tzinfo is not None, "Timestamp requires explicit timezone")
    result = parsed.timestamp() * 1000
    require(math.isfinite(result), "Timestamp nonfinite")
    return result


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def integer(value, minimum=0):
    return type(value) is int and minimum <= value <= SAFE_INT


def norm(value):
    require(type(value) is str, "Path is not a string")
    return value.replace("\\", "/").rstrip("/").lower()


def pin(record):
    require(type(record) is dict and type(record.get("path")) is str
            and type(record.get("sha256")) is str
            and re.fullmatch(r"[0-9a-f]{64}", record["sha256"]), "Malformed file pin")
    return norm(record["path"]), record["sha256"]


def check_runtime(binding, manifest, run):
    """Check OS snapshots bracketing this exact original case execution."""
    require(binding.get("schema_version") == 1 and type(binding["schema_version"]) is int,
            "Runtime binding schema differs")
    require(manifest.get("status") == "passed_local_repair"
            and manifest.get("agh_core_modified") is True
            and type(manifest.get("local_runtime_build", {}).get("exit_code")) is int
            and manifest["local_runtime_build"]["exit_code"] == 0,
            "No successful tested modified runtime build")
    expected_directory = ROOT / "outputs/agh-title-repair-v2/runtime/packages/cli/dist/local"
    require(type(manifest.get("repair_version")) is int and manifest["repair_version"] == 2
            and manifest.get("new_event") == DIAGNOSTIC
            and manifest.get("original_v1_files_unchanged") is True
            and manifest.get("compiler_invoked") is False
            and norm(manifest.get("runtime_directory")) == norm(str(expected_directory)),
            "V13 requires the pinned side-by-side V2 runtime and protocol-valid diagnostics")
    begin, end = run.get("started_epoch_ms"), run.get("finished_epoch_ms")
    deadline = run.get("deadline_epoch_ms")
    require(all(number(v) for v in (begin, end, deadline)) and begin <= end < deadline,
            "Runtime execution interval is absent or escaped original deadline")
    completed = stamp(binding.get("build_completed_at"))
    require(completed < begin, "Build did not finish before this case was armed")
    files = manifest.get("runtime_files")
    require(type(files) is list and files, "No pinned runtime manifest members")
    expected = dict(pin(row) for row in files)
    require(len(expected) == len(files), "Duplicate runtime manifest path")
    role_bundles = {role: next((path for path in expected
                               if path.endswith("/packages/cli/dist/local/" + basename)), None)
                    for role, basename in (("web", "agnes.mjs"), ("daemon", "daemon.mjs"),
                                           ("worker", "worker.mjs"))}
    require(all(role_bundles.values()) and len(set(role_bundles.values())) == 3,
            "Web, daemon and worker bundles are not independently pinned")
    require(all(path.rsplit("/", 1)[0] == norm(manifest["runtime_directory"])
                for path in role_bundles.values()), "Role bundles differ from V2 runtime directory")
    snapshots = []
    for name in ("before", "after"):
        snapshot = binding.get(name)
        require(type(snapshot) is dict, "Missing runtime " + name + " snapshot")
        if "build_completed_at" in snapshot:
            require(stamp(snapshot["build_completed_at"]) == completed,
                    "Runtime snapshot build completion differs")
        captured = stamp(snapshot.get("captured_at"))
        require(completed <= captured <= begin if name == "before" else end <= captured,
                "Runtime snapshot does not bracket original execution")
        require(snapshot.get("web_port") == 4177 and type(snapshot["web_port"]) is int,
                "Unexpected local web port")
        members = snapshot.get("bundles")
        require(type(members) is list, "Missing snapshot bundle hashes")
        hashes = dict(pin(row) for row in members)
        require(len(hashes) == len(members)
                and all(hashes.get(path) == expected[path] for path in role_bundles.values())
                and all(path in expected and expected[path] == value for path, value in hashes.items()),
                "Runtime bundle hash differs before or after execution")
        processes = snapshot.get("processes")
        require(type(processes) is list and len(processes) == 3
                and {p.get("role") for p in processes} == {"web", "daemon", "worker"},
                "Exactly one web, daemon and worker process must be bound")
        roles = {p["role"]: p for p in processes}
        require(len({p.get("pid") for p in processes}) == 3
                and all(integer(p.get("pid"), 1) and integer(p.get("parent_pid"), 1)
                        for p in processes), "Invalid or overlapping process identity")
        require(roles["worker"]["parent_pid"] == roles["daemon"]["pid"]
                and roles["daemon"]["parent_pid"] == roles["web"]["pid"]
                and integer(snapshot.get("web_port_owner_pid"), 1)
                and snapshot["web_port_owner_pid"] == roles["web"]["pid"],
                "Connected web/daemon/worker ownership chain differs")
        for role, process in roles.items():
            started = stamp(process.get("started_at"))
            require(completed <= started <= captured and started <= begin,
                    "Old process or process started after original arm")
            command = norm(process.get("command_line"))
            require(role_bundles[role] in command
                    and norm(process.get("executable")).endswith("/node.exe"),
                    "Process does not execute its pinned Node bundle")
            if role == "web":
                require(re.search(r"\bserve\b", command), "Port owner is not web serve")
            if role == "daemon":
                require("--workspace" in command and norm(str(ROOT)) in command
                        and "--data-dir" in command and "/.runtime/agh/data" in command,
                        "Daemon is not scoped to this project runtime")
        require(stamp(roles["web"]["started_at"]) <= stamp(roles["daemon"]["started_at"])
                <= stamp(roles["worker"]["started_at"]), "Process startup order differs")
        snapshots.append(roles)
    for role in ("web", "daemon", "worker"):
        require(snapshots[0][role] == snapshots[1][role],
                "Process identity changed during case; runtime execution is ambiguous")
    return {"daemon_pid": snapshots[0]["daemon"]["pid"],
            "worker_pid": snapshots[0]["worker"]["pid"],
            "runtime_bundle_count": len(role_bundles), "processes_started_after_build": True}


def check_title(rows, run):
    """Require actual receipt plus the trusted diagnostics emitted by the patch."""
    require(type(rows) is list and rows, "Missing official session ledger")
    require([r.get("seq") for r in rows] == list(range(1, len(rows) + 1))
            and all(integer(r.get("seq"), 1) for r in rows), "Non-contiguous official ledger")
    require(rows[0].get("type") == "session/start"
            and rows[0].get("data", {}).get("key") == run.get("session_id")
            and run.get("session_id") == run.get("session_key"), "Not this fresh bound session")
    requested = [r for r in rows if r.get("type") == "x/host/session-title"
                 and r.get("data", {}).get("status") == "requested"]
    terminal = [r for r in rows if r.get("type") == "x/host/session-title"
                and r.get("data", {}).get("status") in {"generated", "failed"}]
    costs = [r for r in rows if r.get("type") == "cost/ledger"
             and r.get("data", {}).get("purpose") == "title"]
    diagnostics = [r for r in rows if r.get("type") == DIAGNOSTIC]
    ends = [r for r in rows if r.get("type") == "turn/end"]
    require(len(requested) == len(terminal) == len(costs) == len(diagnostics) == len(ends) == 1,
            "Missing or duplicate patched title diagnostics/request/cost/terminal/turn")
    request, finish, cost, diagnostic, turn = (x[0] for x in (requested, terminal, costs, diagnostics, ends))
    for row in (rows[0], request, finish, cost, diagnostic, turn):
        require(row.get("origin") == "system" and row.get("trust") == "trusted",
                "Title acceptance event is not native trusted system evidence")
    for row in (request, finish, cost, diagnostic, turn):
        require(run["started_epoch_ms"] <= stamp(row.get("ts")) <= run["finished_epoch_ms"]
                < run["deadline_epoch_ms"], "Title event escaped the original execution interval")
    require(turn.get("data", {}).get("reason") == "completed"
            and turn["seq"] < request["seq"] < cost["seq"]
            and diagnostic["seq"] == cost["seq"] + 1 and finish["seq"] == diagnostic["seq"] + 1
            and cost["ts"] == diagnostic["ts"] == finish["ts"],
            "Title diagnostic does not belong to the same atomic terminal append")
    data, spend, seed = diagnostic["data"], cost["data"], request["data"]
    require(integer(seed.get("turn"), 1) and integer(seed.get("startSeq"), 1)
            and seed["turn"] == turn["data"].get("turn") == finish["data"].get("turn")
            and seed["startSeq"] == finish["data"].get("startSeq")
            and seed.get("model") == finish["data"].get("model") == spend.get("model") == run.get("model")
            and seed.get("route") == finish["data"].get("route") == run.get("route"),
            "Title request model/route/turn differs")
    lane = request.get("lane")
    require(type(lane) is str and all(row.get("lane") == lane for row in (cost, diagnostic, finish)),
            "Native title lanes differ")
    effect = "title:" + hashlib.sha256(json.dumps(
        [run["session_id"], lane, seed["startSeq"]], separators=(",", ":"),
        ensure_ascii=False).encode("utf-8")).hexdigest()
    require(data.get("schemaVersion") == 1 and type(data["schemaVersion"]) is int
            and integer(data.get("sourceTurn"), 1) and integer(spend.get("sourceTurn"), 1)
            and data["sourceTurn"] == spend["sourceTurn"] == seed["turn"]
            and data.get("effectId") == spend.get("effectId") == effect
            and diagnostic.get("ignorable") is True, "Title diagnostics identity differs")
    mandatory = {"schemaVersion", "sourceTurn", "effectId", "timeoutMs", "durationMs", "providerSent",
                 "responseSeen", "usageObserved", "cancellationSettlementLimitMs", "settledUsage",
                 "duplicateUsage", "invalidUsage", "responseStatus", "usageAtMs"}
    optional = {"firstTextAtMs", "firstThinkingAtMs", "cancelledBy", "cancelledAtMs"}
    require(mandatory <= set(data) and set(data) <= mandatory | optional,
            "Missing diagnostic fields or undeclared diagnostic content")
    require(data["providerSent"] is True and data["responseSeen"] is True
            and data["usageObserved"] is True and data["settledUsage"] is False
            and data["duplicateUsage"] is False and data["invalidUsage"] is False
            and "cancelledBy" not in data and "cancelledAtMs" not in data
            and integer(data["responseStatus"], 200) and data["responseStatus"] < 300
            and data["timeoutMs"] == 30000 and type(data["timeoutMs"]) is int
            and data["cancellationSettlementLimitMs"] == 25
            and type(data["cancellationSettlementLimitMs"]) is int,
            "Title request was cancelled, invalid, duplicated, or had no actual response usage")
    require(integer(data["durationMs"]) and data["durationMs"] < data["timeoutMs"]
            and integer(data["usageAtMs"]) and data["usageAtMs"] <= data["durationMs"]
            and all(integer(data[k]) and data[k] <= data["durationMs"]
                    for k in ("firstTextAtMs", "firstThinkingAtMs") if k in data),
            "Title receipt timing is unknown or outside its native budget")
    tokens = spend.get("tokens")
    require(type(tokens) is dict and {"input", "output", "cacheRead", "cacheWrite"} <= set(tokens)
            and set(tokens) <= {"input", "output", "cacheRead", "cacheWrite", "reasoning"}
            and all(integer(v) for v in tokens.values())
            and sum(tokens[k] for k in ("input", "output", "cacheRead", "cacheWrite")) <= SAFE_INT
            and (tokens["input"] > 0 or tokens["output"] > 0)
            and spend.get("interrupted") is not True and finish["data"].get("status") == "generated",
            "Actual native title usage is unknown, default-zero, interrupted or ungenerated")
    require(run.get("title_request_event") == request and run.get("title_terminal_event") == finish,
            "SDK title receipts differ from the official ledger")
    sdk = [r for r in run.get("sdk_events", []) if r.get("type") == DIAGNOSTIC]
    require(len(sdk) == 1 and sdk[0] == diagnostic,
            "SDK and official patched title diagnostic differ")
    total = len([r for r in rows if r.get("type") == "request/sent"]) + 1
    require(integer(run.get("model_requests_including_title"), 1)
            and run["model_requests_including_title"] == total <= 7,
            "Combined model request cap or actual accounting differs")
    return {"native_title_diagnostics_seq": diagnostic["seq"], "native_title_effect_id": effect,
            "native_title_actual_tokens": tokens, "native_title_usage_closed": True,
            "actual_total_model_requests": total,
            "billing_boundary": "provider token receipt; estimated credits are not purchase price"}


def verify(binding, manifest, rows, run):
    checks, errors, facts = {}, [], {}
    for name, method, args in (("live_process_and_bundle_execution_binding", check_runtime,
                                (binding, manifest, run)),
                               ("trusted_patched_native_title_and_actual_usage", check_title, (rows, run))):
        try:
            facts.update(method(*args))
            checks[name] = True
        except Exception as error:
            checks[name] = False
            errors.append({"check": name, "type": type(error).__name__, "message": str(error)})
    return {"schema_version": 1, "status": "passed" if all(checks.values()) else "failed",
            "scope": "Runtime execution supplement; model engineering and business checks remain separate",
            "checks": checks, "errors": errors, **facts}


def bound_path(value, roots):
    path = Path(value)
    require(path.is_absolute(), "Evidence pin requires absolute path")
    for part in (path, *path.parents):
        require(not part.is_symlink() and not (hasattr(part, "is_junction") and part.is_junction()),
                "Linked runtime evidence path refused")
    path = path.resolve()
    require(any(path.is_relative_to(root.resolve()) for root in roots), "Runtime evidence outside scope")
    return path


def load(directory):
    directory = bound_path(directory, [ROOT])
    run = read(directory / "run_result.json")
    binding = read(directory / "runtime_binding.json")
    public_path = bound_path(run["model_protocol_path"], [ROOT])
    require(digest(public_path) == run.get("model_protocol_sha256"), "Model protocol bytes changed")
    public = read(public_path)
    require(binding.get("runtime_manifest") == public.get("runtime_version"), "Runtime manifest is not preregistered")
    manifest_pin = binding["runtime_manifest"]
    pin(manifest_pin)
    manifest_path = bound_path(manifest_pin["path"], [ROOT])
    require(digest(manifest_path) == manifest_pin["sha256"], "Runtime manifest bytes changed")
    manifest = read(manifest_path)
    build = manifest["local_runtime_build"]
    log = bound_path(build["path"], [ROOT])
    require(build["exit_code"] == 0 and digest(log) == build["sha256"]
            and abs(log.stat().st_mtime * 1000 - stamp(binding["build_completed_at"])) <= 1,
            "Successful build log hash or recorded completion timestamp differs")
    for item in manifest["runtime_files"]:
        for field in ("path", "archive"):
            path = bound_path(item[field], [ROOT, AGH])
            require(digest(path) == item["sha256"], "Current or archived runtime bytes changed")
    rows = [decode(line) for line in (directory / "session.jsonl").read_text(encoding="utf-8").splitlines()
            if line.strip()]
    return binding, manifest, rows, run


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = verify(*load(args.directory))
    except Exception as error:
        result = {"schema_version": 1, "status": "failed", "checks": {"source_and_receipt_binding": False},
                  "errors": [{"type": type(error).__name__, "message": str(error)}]}
    output = bound_path(args.output, [ROOT])
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "checks": result["checks"]}, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
