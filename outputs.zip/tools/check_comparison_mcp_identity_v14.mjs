// Official dynamic-manifest preflight only; no factory, connection or model call.
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tsImport} from '../../agnes-harness/node_modules/tsx/dist/esm/api/index.mjs';

export const STAGE_SERVERS=Object.freeze({diagnostic:'dr-cmp14-d',pilot:'dr-cmp14-p',formal:'dr-cmp14-f'});
export async function checkIdentity(serverId){
 const [{checkManifest},{mcpServerRowsFromDefinitions}]=await Promise.all([
  tsImport('../../agnes-harness/packages/extension-api/src/manifest.ts',import.meta.url),
  tsImport('../../agnes-harness/packages/worker-runtime/src/mcp-server-rows.ts',import.meta.url),
 ]);
 let connections=0;
 const definition={serverId,displayName:'DefectResearcher comparison identity preflight',
  transport:{kind:'stdio',executable:'python.exe',args:['run_comparison_mcp_v14.py']},
  secretBinding:{kind:'none'},toolPolicy:{allow:['execute_case_action_v1']}};
 const derived=mcpServerRowsFromDefinitions([{definition,revision:'preflight-v14',desired:'enabled',trust:'trusted'}],
  {connect:()=>{connections++;throw new Error('Identity preflight must never connect');}});
 if(derived.rows.length!==1||derived.skipped.length||connections)throw new Error('Native row derivation failed or connected');
 const manifest=derived.rows[0].manifest, checked=checkManifest(manifest);
 const prefix=manifest.capabilities.tools.prefix, qualified=prefix+'execute_case_action_v1';
 return {server_id:serverId,tools_prefix:prefix,qualified_action_tool:qualified,
  prefix_length:prefix.length,qualified_name_length:qualified.length,
  native_manifest_valid:checked.ok,native_manifest_problems:checked.ok?[]:checked.problems,
  connections,model_requests:0,new_detector_calls:0,gpu_seconds:0};
}
export async function checkStage(stage){
 if(!Object.hasOwn(STAGE_SERVERS,stage))throw new Error('Unknown V14 stage');
 const result=await checkIdentity(STAGE_SERVERS[stage]);
 const expected='mcp_'+result.server_id.replaceAll('-','_')+'_'+createHash('sha256').update(result.server_id).digest('hex').slice(0,8)+'_';
 if(!result.native_manifest_valid||result.tools_prefix!==expected||result.prefix_length>32||result.qualified_name_length>64||
  !/^mcp_dr_cmp14_[dpf]_[0-9a-f]{8}_execute_case_action_v1$/.test(result.qualified_action_tool))
  throw new Error('V14 native MCP identity rejected: '+JSON.stringify(result));
 return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const stage=process.argv[2];
 const results=await Promise.all((stage?[stage]:Object.keys(STAGE_SERVERS)).map(checkStage));
 console.log(JSON.stringify({status:'passed',results,connections:0,model_requests:0,new_detector_calls:0,gpu_seconds:0}));
}
