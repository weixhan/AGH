"""Reload the authorized seven-tool MCP service for read-only recovery status."""
from __future__ import annotations

import json
from pathlib import Path
import time
from uuid import uuid4

from enable_slices import request, ROOT, SERVER


def main():
    output = ROOT / "outputs" / "agh-sliced-artifact-reload"
    output.mkdir(exist_ok=True)
    path = output / "reload.json"
    if path.exists():
        raise FileExistsError("Inspect the existing recovery-status reload receipt before retrying")
    context = request("context")
    if context["profile"] != "local-dev" or context["readOnly"]:
        raise RuntimeError("Expected writable local-dev resource administration")
    profile = context["profile"]
    get = lambda: request("mcp/get", {"profile": profile, "serverId": SERVER})
    before = get()
    prior = json.loads((ROOT / "outputs/agh-sliced-registration/registration.json").read_text(encoding="utf-8"))
    if (not prior["complete"] or before["definition"] != prior["after"]["definition"]
            or before["trust"] != "trusted"):
        raise RuntimeError("The existing approved MCP scope changed")
    trace = {"schema_version": 1, "interface": "official ResourceAdmin BFF",
             "purpose": "Load read-only artifact-recovery status; preserve seven-tool definition and trust",
             "user_authorized": True, "before": before, "operations": [], "complete": False}
    save = lambda: path.write_text(json.dumps(trace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    save()
    try:
        for action in ("mcp/disable", "mcp/enable"):
            current = get()
            params = {"profile": profile, "clientId": context["clientId"],
                      "commandId": "sliced-artifact-status-" + uuid4().hex,
                      "serverId": SERVER, "expectedRevision": current["revision"]}
            entry = {"action": action, "params": params}
            trace["operations"].append(entry)
            save()
            entry["receipt"] = receipt = request(action, params)
            save()
            deadline = time.monotonic() + 60
            while True:
                entry["operation"] = operation = request("operations/get", {
                    "profile": profile, "operationId": receipt["operationId"]})
                save()
                if operation["state"] in {"succeeded", "failed", "cancelled"}:
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError("MCP reload operation timed out")
                time.sleep(.5)
            if operation["state"] != "succeeded":
                raise RuntimeError(f"MCP reload {action} failed")
            print(json.dumps({"action": action, "state": operation["state"]}), flush=True)
        trace["after"] = get()
        trace["status"] = request("mcp/status", {"profile": profile, "serverId": SERVER})
        trace["complete"] = (trace["after"]["actual"] == "ready"
                             and trace["after"]["trust"] == "trusted"
                             and trace["after"]["definition"] == before["definition"]
                             and trace["status"]["toolCount"] == 7)
        save()
        if not trace["complete"]:
            raise RuntimeError("Reloaded MCP did not become ready with the approved scope")
        print(json.dumps({"complete": True, "path": str(path)}))
    except Exception as error:
        trace["failure"] = {"type": type(error).__name__, "message": str(error)}
        save()
        raise


if __name__ == "__main__":
    main()
