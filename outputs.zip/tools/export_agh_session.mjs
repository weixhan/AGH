// The official redacted export implementation, using a fresh public WebSocket client each time.
import { writeFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient } from './agh_ws_client.mjs';

const [id, file, format = 'agnes'] = process.argv.slice(2);
if (!id || !file || !['agnes', 'html'].includes(format)) throw new Error('Expected session id, output path and format');
const client = await webClient();
try {
  await exportSession({ positional: [id], format, raw: false, out: file }, {
    cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
    writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
  }, client);
  console.log(JSON.stringify({ session_id: id, path: file, format, redacted: true }));
} finally { await client.close(); }
