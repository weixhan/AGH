"""Independently crosscheck a scoped Agnes diagnosis session and its artifacts.

Official exports can mask long decimal digits inside embedded tool JSON. Those
values are retained as unknown markers, never recovered from disk. Only the
fixed compact projection is compared to that export; exact detailed science is
separately bound to the public SDK result sequence and the independent review.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.task_runtime import get_task_status
from tools.verify_diagnosis_run import decode, read, lines, verify_run

START_TOOL = "mcp_defect_researcher_45e5cef9_diagnose_validation_errors"
STATUS_TOOL = "mcp_defect_researcher_45e5cef9_get_task_status"
TOOL = "diagnose_validation_errors"
UNKNOWN = "__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__"
FN_NAMES = {"matching_conflict", "localized_low_confidence", "wrong_class_candidate", "localization_candidate", "no_overlap_candidate"}
FP_NAMES = {"duplicates", "wrong_class", "localization", "background"}
COMPACT_KEYS = {"status", "task_id", "diagnosis_status", "images", "gt", "tp", "fp", "fn", "fn_categories", "fp_categories",
                "threshold_status", "selected_threshold", "next_branch"}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def normalize_path(value):
    return str(value).replace("\\", "/").rstrip("/").lower()


def exact(left, right):
    """JSON booleans never compare equal to scientific integer counts."""
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    # JavaScript serializes 0.0/1.0 as 0/1. They are the same JSON number;
    # unlike bool coercion, preserving exact numerical equality is legitimate.
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def official_payload(text):
    """Parse masked numeric tokens as unknown strings, without restoring numbers."""
    try:
        return decode(text), []
    except (json.JSONDecodeError, ValueError):
        pattern = r'([:,\[]\s*)-?(?:\d+\.)?\[REDACTED:id\](?=\s*[,}\]])'
        changed, count = re.subn(pattern, lambda match: match[1] + json.dumps(UNKNOWN), text)
        if not count:
            raise
        value = decode(changed)
        masked = []
        def visit(item, path):
            if isinstance(item, dict):
                for key, child in item.items():
                    visit(child, path + [key])
            elif isinstance(item, list):
                for index, child in enumerate(item):
                    visit(child, path + [index])
            elif item == UNKNOWN:
                masked.append(path)
        visit(value, [])
        return value, masked


def compact_target(disk):
    try:
        summary = disk["summary"]
        reference = summary["reference"]
        point = reference["operating_point"]
        selection = summary["threshold_selection"]
        value = {"status": disk["status"], "task_id": disk["task_id"], "diagnosis_status": summary["diagnosis_status"],
                 "images": reference["images"], "gt": reference["gt"],
                 **{key: point[key] for key in ("tp", "fp", "fn")},
                 "fn_categories": reference["fn_categories"], "fp_categories": reference["fp_categories"],
                 "threshold_status": selection["status"], "selected_threshold": selection["selected_threshold"],
                 "next_branch": summary["recommendations"]["next_branch"]}
        if not all(type(value[key]) is int for key in ("images", "gt", "tp", "fp", "fn")):
            return None
        if value["fn_categories"].keys() != FN_NAMES or value["fp_categories"].keys() != FP_NAMES:
            return None
        if not all(type(v) is int for row in (value["fn_categories"], value["fp_categories"]) for v in row.values()):
            return None
        return value
    except (KeyError, TypeError, AttributeError):
        return None


def final_compact(text):
    blocks = re.findall(r"```json\s*\n(.*?)\n```", text, flags=re.S)
    if len(blocks) != 1:
        return None
    try:
        value = decode(blocks[0])
    except (ValueError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or value.keys() != COMPACT_KEYS:
        return None
    if not all(type(value[key]) is int for key in ("images", "gt", "tp", "fp", "fn")):
        return None
    if not all(isinstance(value[key], dict) and all(type(number) is int for number in value[key].values()) for key in ("fn_categories", "fp_categories")):
        return None
    return value


def aligned_ready(event, workspace):
    value = copy.deepcopy(event)
    data = value["data"]
    if normalize_path(data.get("workspace_root")) == normalize_path(workspace):
        data["workspace_root"] = "<workspace>"
    if normalize_path(data.get("policy", {}).get("workspace_root")) == normalize_path(workspace):
        data["policy"]["workspace_root"] = "<workspace>"
    return value


def check_ledger(rows, runner, disk, *, expected_workspace=None):
    """Pure ledger verifier used by synthetic tamper tests and real review."""
    calls = [row for row in rows if row.get("type") == "tool/call"]
    result_rows = [row for row in rows if row.get("type") == "tool/result"]
    results = {row["data"]["toolUseId"]: row for row in result_rows}
    starts = [row for row in calls if row["data"].get("name") == START_TOOL]
    polls = [row for row in calls if row["data"].get("name") == STATUS_TOOL]
    ready = [row for row in rows if row.get("type", "").endswith("/scope-ready")]
    decisions = [row for row in rows if row.get("type", "").endswith("/scope-decision")]
    decisions_by_call = {row["data"].get("tool_use_id"): row for row in decisions}
    approvals = [row for row in rows if row.get("type") == "approval/decided"]
    ends = [row for row in rows if row.get("type") == "turn/end"]
    inference = [row for row in rows if row.get("type") == "cost/ledger" and row.get("data", {}).get("purpose") == "inference"]
    parsed, masked, parse_errors = {}, [], []
    for call in starts + polls:
        result = results.get(call["data"].get("toolUseId"), {})
        texts = [part.get("text") for part in result.get("data", {}).get("content", []) if part.get("type") == "text"]
        try:
            if len(texts) != 1:
                raise ValueError("Tool result has no unique text block")
            value, masks = official_payload(texts[0])
            parsed[call["seq"]] = value
            masked.extend({"result_seq": result.get("seq"), "path": path} for path in masks)
        except (json.JSONDecodeError, ValueError, TypeError) as error:
            parse_errors.append({"call_seq": call["seq"], "type": type(error).__name__})
    start = starts[0] if len(starts) == 1 else None
    launch = parsed.get(start["seq"], {}) if start else {}
    task_id = disk.get("task_id")
    completed = [call for call in polls if parsed.get(call["seq"], {}).get("status") == "completed"]
    terminal_call = completed[-1] if completed else None
    terminal_result = results.get(terminal_call["data"]["toolUseId"], {}) if terminal_call else {}
    terminal = parsed.get(terminal_call["seq"], {}) if terminal_call else {}
    target = compact_target(disk)
    messages = [row for row in rows if row.get("type") == "assistant/message"]
    final = next((row for row in reversed(messages) if ends and row["seq"] == ends[-1]["data"].get("lastAssistantSeq")), None)
    text = "\n".join(part["text"] for part in final["data"].get("content", []) if part.get("type") == "text") if final else ""
    final_value = final_compact(text)
    sdk_ready = runner.get("scope_ready", {})
    workspace = expected_workspace or runner.get("cwd")
    expected_policy = {"schema_version": 1, "workspace_root": "<workspace>", "qualified_start_tool": START_TOOL,
                       "qualified_status_tool": STATUS_TOOL, "max_status_calls": 20}
    first_ready = ready[0] if len(ready) == 1 else None
    extension_prefix = first_ready["type"].rsplit("/", 1)[0] if first_ready else None
    sdk_completed = [row for row in runner.get("polls", []) if row.get("status") == "completed"]
    sdk_terminal = next((row for row in sdk_completed if row.get("seq") == terminal_result.get("seq")), None)
    sdk_calls = {row["seq"]: row for row in runner.get("calls", [])}
    sdk_hook_events = {row["seq"]: row for row in runner.get("hook_events", []) if row.get("type", "").endswith("/scope-decision")}
    checks = {
        "continuous_official_ledger": [row.get("seq") for row in rows] == list(range(1, len(rows) + 1)),
        "fresh_session_identity": bool(rows and rows[0].get("type") == "session/start" and rows[0]["data"].get("key") == runner.get("session_id")),
        "one_empty_argument_model_diagnosis_start": bool(start and start.get("origin") == "model" and start["data"].get("args") == {}),
        "only_requested_model_tool_attempts": len(calls) == len(starts) + len(polls) and all(row.get("origin") == "model" for row in calls),
        "one_scope_ready_before_first_call": bool(first_ready and calls and first_ready["seq"] < min(row["seq"] for row in calls)),
        "scope_ready_mode_session_and_policy_bound": bool(first_ready and first_ready["data"].get("mode") == "diagnosis"
            and first_ready["data"].get("session_key") == runner.get("session_id")
            and first_ready["data"].get("workspace_root") == "<workspace>" and exact(first_ready["data"].get("policy"), expected_policy)),
        "public_sdk_readiness_exact_workspace_and_event": bool(first_ready and sdk_ready.get("seq") == first_ready["seq"] and sdk_ready.get("type") == first_ready["type"]
            and normalize_path(sdk_ready.get("data", {}).get("workspace_root")) == normalize_path(workspace)
            and exact(aligned_ready(sdk_ready, workspace).get("data"), first_ready["data"])),
        "each_attempt_has_one_paired_allowed_scope_decision": len(decisions) == len(calls) == len(decisions_by_call) and all(
            call["data"]["toolUseId"] in decisions_by_call
            and call["seq"] < decisions_by_call[call["data"]["toolUseId"]]["seq"] < results.get(call["data"]["toolUseId"], {}).get("seq", 0)
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("name") == call["data"].get("name")
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("session_key") == runner.get("session_id")
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("allow") is True
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("reason") is None for call in calls),
        "scope_events_from_same_registered_extension": bool(first_ready and all(row["type"].rsplit("/", 1)[0] == extension_prefix
            and row.get("origin") == first_ready.get("origin") and str(row.get("origin", "")).startswith("ext:plugin/") for row in ready + decisions)),
        "public_sdk_scope_decisions_equal_official": len(sdk_hook_events) == len(decisions) and all(
            row["seq"] in sdk_hook_events and sdk_hook_events[row["seq"]].get("type") == row["type"]
            and exact(sdk_hook_events[row["seq"]].get("data"), row["data"]) for row in decisions),
        "unique_call_result_ids_and_exact_pairing": len({row["data"]["toolUseId"] for row in calls}) == len(calls)
            and len(results) == len(result_rows) == len(calls) and all(row["data"]["toolUseId"] in results
            and results[row["data"]["toolUseId"]]["seq"] > row["seq"]
            and results[row["data"]["toolUseId"]].get("sourceEventSeqs") == [row["seq"]] for row in calls),
        "all_tool_results_successful_no_rejected_attempt": all(row["data"].get("isError") is False and row["data"].get("code") not in {"HOOK_DENIED", "APPROVAL_REJECTED"} for row in result_rows),
        "launch_returned_running_same_task": launch.get("status") == "running" and launch.get("task_id") == task_id == runner.get("task_id"),
        "status_polls_same_task_after_launch_within_budget": bool(start and polls and len(polls) <= 20 and all(
            row["data"].get("args") == {"task_id": task_id} and row["seq"] > results.get(start["data"]["toolUseId"], {}).get("seq", 0) for row in polls)),
        "one_allow_once_for_start_before_result": bool(start and len(approvals) == 1 and approvals[0]["data"].get("verdict") == "allowed-once"
            and approvals[0]["data"].get("scope") == f"tool:{START_TOOL}:execute"
            and start["seq"] < approvals[0]["seq"] < results.get(start["data"]["toolUseId"], {}).get("seq", 0)),
        "public_sdk_host_approval_budget_exact": len(runner.get("permissions", [])) == 1
            and runner["permissions"][0].get("tool") == START_TOOL and runner["permissions"][0].get("input") == {}
            and runner["permissions"][0].get("decision") == "allowed-once",
        "public_sdk_tool_calls_exact_official_calls": len(sdk_calls) == len(calls) and all(row["seq"] in sdk_calls
            and sdk_calls[row["seq"]].get("name") == row["data"].get("name") and sdk_calls[row["seq"]].get("args") == row["data"].get("args")
            and sdk_calls[row["seq"]].get("origin") == row.get("origin") for row in calls),
        "official_payloads_parse_without_numeric_recovery": not parse_errors and len(parsed) == len(starts) + len(polls),
        "all_official_payloads_same_task": bool(parsed and all(value.get("task_id") == task_id for value in parsed.values())),
        "terminal_official_compact_science_matches_disk": bool(target and terminal.get("tool") == TOOL and exact(compact_target(terminal), target)),
        "terminal_public_sdk_exact_summary_and_evidence_matches_disk": bool(sdk_terminal and sdk_terminal.get("task_id") == task_id
            and exact(sdk_terminal.get("summary"), disk.get("summary")) and exact(sdk_terminal.get("evidence"), disk.get("evidence"))),
        "model_requests_use_agnes_with_successful_response": bool(inference and any(row["data"].get("response", {}).get("status") == 200 for row in inference)
            and all(row["data"].get("model") == "agnes-3.0-flash" and (row["data"].get("response", {}).get("status") == 200 or row["data"].get("interrupted") is True) for row in inference)),
        "final_completed_turn_after_completed_tool": bool(final and ends and ends[-1]["data"].get("reason") == "completed"
            and final["seq"] > terminal_result.get("seq", float("inf")) and ends[-1]["seq"] > final["seq"]),
        "model_final_unique_compact_json_matches_disk": target is not None and exact(final_value, target),
        "host_runner_completed_without_export_failure": runner.get("status") == "completed" and not runner.get("failure") and not runner.get("export_failure"),
        "diagnosis_terminal_no_new_inference_training_test": disk.get("status") == "completed" and disk.get("tool") == TOOL
            and disk.get("summary", {}).get("diagnosis_status") == "passed" and disk.get("summary", {}).get("input_hashes_unchanged") is True
            and all(disk.get("summary", {}).get(key) is False for key in ("new_inference_performed", "training_performed", "test_inference_performed")),
    }
    scope_keys = {"only_requested_model_tool_attempts", "one_empty_argument_model_diagnosis_start", "one_scope_ready_before_first_call",
                  "scope_ready_mode_session_and_policy_bound", "public_sdk_readiness_exact_workspace_and_event",
                  "each_attempt_has_one_paired_allowed_scope_decision", "scope_events_from_same_registered_extension",
                  "public_sdk_scope_decisions_equal_official", "all_tool_results_successful_no_rejected_attempt",
                  "status_polls_same_task_after_launch_within_budget", "one_allow_once_for_start_before_result", "public_sdk_host_approval_budget_exact"}
    return {"checks": checks, "strict_tool_scope_passed": all(checks[key] for key in scope_keys),
            "official_compact_science_passed": checks["terminal_official_compact_science_matches_disk"] and checks["model_final_unique_compact_json_matches_disk"],
            "task_id": task_id, "session_id": runner.get("session_id"), "event_count": len(rows), "tool_call_count": len(calls),
            "poll_count": len(polls), "model_turn_count": len(ends), "masked_numeric_paths_not_recovered": masked,
            "parse_errors": parse_errors, "final_model_text": text,
            "unrequested_tool_attempts": [{"seq": row["seq"], "name": row["data"].get("name"),
                                           "result_code": results.get(row["data"]["toolUseId"], {}).get("data", {}).get("code")}
                                          for row in calls if row not in starts + polls]}


def review(directory, configuration=None):
    configuration = configuration or load_config()
    directory = Path(directory).resolve()
    output_root = Path(configuration["output_root"]).resolve()
    if not directory.is_relative_to(output_root):
        raise ValueError("Model run directory escapes configured output root")
    runner = read(directory / "runner.json")
    task_id = runner.get("task_id")
    if not isinstance(task_id, str) or not re.fullmatch(r"[a-f0-9]{32}", task_id):
        raise ValueError("Model-launched diagnosis task must have a safe opaque task identity")
    task_dir = output_root / task_id
    disk = get_task_status(configuration, task_id)
    rows = lines(directory / "session.jsonl")
    report = check_ledger(rows, runner, disk, expected_workspace=directory / "workspace")
    independent = verify_run(task_dir, configuration)
    report["checks"].update(
        runner_expected_project_workspace=normalize_path(runner.get("cwd")) == normalize_path(directory / "workspace"),
        runner_prompt_matches_frozen_diagnosis_instruction=runner.get("prompt_sha256") == digest(ROOT / "agent" / "diagnosis_task.md"),
        independent_scientific_artifact_review_passed=independent.get("status") == "passed" and independent.get("passed_checks") == independent.get("total_checks"),
        session_html_export_present=(directory / "session.html").is_file())
    paths = [directory / "runner.json", directory / "session.jsonl", directory / "session.html"] + sorted(path for path in task_dir.iterdir() if path.is_file())
    scan = [{"path": str(path), "candidate_count": len(re.findall(rb"\bsk-[A-Za-z0-9._-]{12,}", path.read_bytes()))} for path in paths]
    report["checks"]["no_credential_candidates_in_exports_and_task_artifacts"] = all(row["candidate_count"] == 0 for row in scan)
    report.update(schema_version=1, verification_kind="official_scoped_model_diagnosis_crosscheck",
                  status="passed" if all(report["checks"].values()) else "failed", model_used=True,
                  checks_passed=sum(report["checks"].values()), checks_total=len(report["checks"]),
                  reasons=[key for key, value in report["checks"].items() if not value],
                  scientific_artifact_checks_passed=independent.get("status") == "passed", independent_artifact_review=independent,
                  secret_scan=scan, evidence_sha256={path.name: digest(path) for path in paths[:3]},
                  numeric_redaction_rule="Masked numeric tokens remain unknown. Official compact integer/category/threshold/branch fields must remain directly verifiable. Detailed decimals are checked through public SDK terminal result sequence and the independent scientific artifact review, never restored into the official export.",
                  limitations=["This acceptance covers a fresh diagnosis session, not the previously failed resolution-comparison session.",
                               "The hook enforces execution scope but does not remove native tools from the model-visible catalog.",
                               "Host continuations, if present, are recorded; they do not demonstrate business-step recovery or autonomous scheduling.",
                               "Diagnosis categories and slicing recommendations remain descriptive. This task performs no new detector inference, training or test evaluation."])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=ROOT / "outputs" / "agh-diagnosis-model")
    parser.add_argument("--config")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = review(args.run_dir, load_config(args.config))
    except Exception as error:
        report = {"status": "failed", "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "checks_passed", "checks_total", "reasons", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
