// Prepare a new workspace-only guard package; this script does not activate it.
import { readFile, writeFile, mkdir, copyFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, resolve, join, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createResearchWorkflowScopeGuard } from './research_workflow_scope_guard_v1.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
if (args.length !== 2 || args[0] !== '--protocol')
  throw new Error('Usage: node tools/prepare_research_workflow_scope_v1.mjs --protocol <protocol.json>');
const protocolPath = resolve(args[1]), output = dirname(protocolPath);
const inside = path => { const value = relative(root, resolve(path)); return value && !value.startsWith('..') && !isAbsolute(value); };
if (!inside(protocolPath) || protocolPath !== join(output, 'protocol.json')) throw new Error('Protocol must be a project-owned protocol.json');
const rawProtocol = await readFile(protocolPath), protocol = JSON.parse(rawProtocol.toString('utf8'));
const workspace = resolve(protocol.workspace_root ?? '');
if (!inside(workspace) || workspace !== join(output, 'workspace')) throw new Error('Expected isolated protocol workspace');
const keys = ['schema_version','workspace_root','qualified_start_tool','qualified_status_tool','request_id',
  'workflow_id','case_id','budget','max_start_calls','max_status_calls','max_model_requests','max_wall_seconds'];
const policy = Object.fromEntries(keys.map(key => [key, protocol[key]]));
createResearchWorkflowScopeGuard(policy); // Validate the actual public guard contract before writing.
const stable = value => JSON.stringify(value, (_key, item) => item && typeof item === 'object' && !Array.isArray(item)
  ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
if (protocol.scope_policy && stable(protocol.scope_policy) !== stable(policy)) throw new Error('Protocol scope projection differs');
const sourcePath = join(root, 'tools/research_workflow_scope_guard_v1.mjs');
const sourceBytes = await readFile(sourcePath), hash = bytes => createHash('sha256').update(bytes).digest('hex');
if (protocol.scope_guard && (resolve(protocol.scope_guard.path) !== sourcePath || protocol.scope_guard.sha256 !== hash(sourceBytes)))
  throw new Error('Protocol guard source binding differs');

const candidate = join(workspace, '.agh/extensions/research-workflow-scope-guard-v1');
await mkdir(dirname(candidate), { recursive: true });
await mkdir(candidate, { recursive: false }); // Exclusive identity; preserve partial preparations instead of overwriting.
const saveNew = (path, value) => writeFile(path, value, { flag: 'wx', mode: 0o600 });
await saveNew(join(candidate, 'policy.json'), JSON.stringify(policy, null, 2) + '\n');
await copyFile(sourcePath, join(candidate, 'guard.mjs'), 1);
const entry = `import { createResearchWorkflowScopeGuard, normalizeResearchPath } from './guard.mjs';
export const researchWorkflowScopeGuard = { inject: ['extension'], apply(ctx) {
  const policy = ${JSON.stringify(policy)};
  const guard = createResearchWorkflowScopeGuard(policy), agnes = ctx.extension();
  const scoped = hctx => normalizeResearchPath(hctx?.session?.workspaceRoot) === normalizeResearchPath(policy.workspace_root);
  agnes.registerHook('session_start', async (_payload, hctx) => {
    if (scoped(hctx) && hctx.replayed !== true) await agnes.events.append('scope-ready', {
      session_key: hctx.session.key, workspace_root: hctx.session.workspaceRoot,
      mode: 'bounded-research-workflow-v1', policy });
  });
  agnes.registerHook('before_request', async (payload, hctx) => {
    if (!scoped(hctx)) return {};
    const verdict = guard.before_request(payload, hctx);
    await agnes.events.append('scope-request-decision', {
      session_key: hctx.session.key, allow: verdict.allow, reason: verdict.reason ?? null,
      request_index: verdict.request_index ?? null, started_epoch_ms: verdict.started_epoch_ms ?? null,
      deadline_epoch_ms: verdict.deadline_epoch_ms ?? null });
    // before_request is a transform hook: its only author result is {} or patch.
    // Throwing under its official failPolicy=closed blocks the model request.
    if (verdict.allow !== true) throw new Error(verdict.reason ?? 'RESEARCH_WORKFLOW_SCOPE_DENIED');
    return {};
  });
  agnes.registerHook('before_step', (payload, hctx) => scoped(hctx) ? guard.before_step(payload, hctx) : {});
  agnes.registerHook('tool_call', async (payload, hctx) => {
    if (!scoped(hctx)) return { allow: true };
    const verdict = guard.tool_call(payload, hctx);
    await agnes.events.append('scope-decision', {
      session_key: hctx.session.key, name: payload.name, tool_use_id: payload.toolUseId,
      allow: verdict.allow, reason: verdict.reason ?? null });
    return verdict;
  });
  agnes.registerHook('tool_result', (payload, hctx) => scoped(hctx) ? guard.tool_result(payload, hctx) : {});
} };
`;
await saveNew(join(candidate, 'index.mjs'), entry);
await saveNew(join(candidate, 'package.json'), JSON.stringify({
  name: '@defect-researcher/research-workflow-scope-guard-v1', version: '0.1.0', private: true,
  license: 'Apache-2.0', type: 'module', exports: './index.mjs',
  agnes: { plugins: [{ export: 'researchWorkflowScopeGuard', id: 'ext:defect-researcher/research-workflow-scope-guard-v1', inject: ['extension'] }] }
}, null, 2) + '\n');
const files = await Promise.all(['policy.json','guard.mjs','index.mjs','package.json'].map(async name => {
  const path = join(candidate, name), bytes = await readFile(path);
  return { name, path, sha256: hash(bytes), size_bytes: (await stat(path)).size };
}));
if (files.find(file => file.name === 'guard.mjs').sha256 !== hash(sourceBytes)) throw new Error('Copied guard bytes differ');
await saveNew(join(output, 'scope_candidate.json'), JSON.stringify({
  schema_version: 1, prepared_at: new Date().toISOString(), status: 'prepared_not_activated',
  candidate, workspace, policy, package_id: '@defect-researcher/research-workflow-scope-guard-v1',
  protocol_path: protocolPath, protocol_sha256: hash(rawProtocol), files,
  model_called: false, credentials_read: false, agh_core_modified: false, old_plugins_modified: false,
  new_detection_inference_performed: false,
  hook_contract: 'Official PluginExtensionAPI: observe session_start returns void; before_request returns {} and throws on denial; tool_call returns allow verdict; before_step returns block directive; tool_result binds the accepted ID without changing content.'
}, null, 2) + '\n');
console.log(JSON.stringify({ status: 'prepared_not_activated', candidate, workspace, output }));
