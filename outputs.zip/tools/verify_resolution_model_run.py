"""Crosscheck the official redacted model ledger and exact scientific summary."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.task_runtime import get_task_status

FIELDS = ("comparison_status", "split", "val_images", "val_boxes", "train_imgsz", "eval_imgsz",
          "weight_sha256", "same_weight", "device", "precision", "input_hashes_unchanged",
          "test_inference_performed", "training_performed", "metrics", "comparison")
TOOL = "compare_validation_resolutions"


def science(value):
    return {key: value[key] for key in FIELDS} if isinstance(value, dict) and all(key in value for key in FIELDS) else None


def compact_target(disk):
    summary = disk.get("summary", {})
    if science(summary) is None:
        return None
    result = {"status": disk["status"], "task_id": disk["task_id"],
              **{key: summary[key] for key in ("train_imgsz", "eval_imgsz", "weight_sha256", "val_images", "val_boxes", "input_hashes_unchanged")}}
    result["metrics"] = {size: {"mAP50": metric["mAP50"], "mAP50_95": metric["mAP50_95"],
        **{key: metric["operating_point"][key] for key in ("tp", "fp", "fn", "normal_image_fp_rate", "small_gt", "small_fn")}}
        for size, metric in summary["metrics"].items()}
    result["paired_recall"] = {key: summary["comparison"]["paired_recall"][key] for key in ("eligible_images", "mean_delta", "ci95")}
    return result


def repair_ci_export_mask(text: str, reference: dict | None) -> str:
    """Recover only ci95[1] from a separately observed public SDK value, never from disk metrics."""
    if "0.[REDACTED:id]" not in text:
        return text
    value = reference["comparison"]["paired_recall"]["ci95"][1] if reference else None
    if not isinstance(value, float) or not 0 <= value < 1 or not str(value).startswith("0."):
        raise ValueError("No bound public SDK decimal for the official export mask")
    pattern = r'("ci95"\s*:\s*\[\s*[-+\deE.]+\s*,\s*)0\.\[REDACTED:id\](\s*\])'
    repaired, count = re.subn(pattern, lambda match: match[1] + str(value) + match[2], text)
    if count != 1 or "[REDACTED:id]" in repaired:
        raise ValueError("Export mask is outside the single known CI decimal")
    return repaired


def review(directory: Path, configuration: dict) -> dict:
    runner = json.loads((directory / "runner.json").read_text(encoding="utf-8"))
    continuation_path = directory / "continuation.json"
    continuation = json.loads(continuation_path.read_text(encoding="utf-8")) if continuation_path.is_file() else None
    observation_path = directory / "finalization-v2.json"
    if not observation_path.is_file():
        observation_path = directory / "observation.json"
    observation = json.loads(observation_path.read_text(encoding="utf-8")) if observation_path.is_file() else None
    sdk_path = directory / ("sdk-science-v2.json" if (directory / "sdk-science-v2.json").is_file() else "sdk-science.json")
    sdk = json.loads(sdk_path.read_text(encoding="utf-8")) if sdk_path.is_file() else None
    sdk_tools = {row["toolUseId"]: row for row in sdk["tool_summaries"]} if sdk else {}
    ledger = directory / ("session-final-v2.jsonl" if (directory / "session-final-v2.jsonl").is_file() else "session-final.jsonl" if (directory / "session-final.jsonl").is_file() else "session.jsonl")
    html = directory / ("session-final-v2.html" if (directory / "session-final-v2.html").is_file() else "session-final.html" if (directory / "session-final.html").is_file() else "session.html")
    rows = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line.strip()]
    calls = [row for row in rows if row["type"] == "tool/call"]
    result_rows = [row for row in rows if row["type"] == "tool/result"]
    results = {row["data"]["toolUseId"]: row for row in result_rows}
    starts = [row for row in calls if row["data"]["name"] == runner["qualified_tool"]]
    polls = [row for row in calls if row["data"]["name"] == "mcp_defect_researcher_45e5cef9_get_task_status"]
    parsed = {}
    for call in starts + polls:
        result = results.get(call["data"]["toolUseId"])
        texts = [part["text"] for part in result["data"].get("content", []) if part.get("type") == "text"] if result else []
        if len(texts) == 1:
            reference = sdk_tools.get(call["data"]["toolUseId"], {}).get("summary")
            parsed[call["seq"]] = json.loads(repair_ci_export_mask(texts[0], reference))
    start = starts[0] if len(starts) == 1 else None
    launch = parsed.get(start["seq"], {}) if start else {}
    task_id = launch.get("task_id")
    safe_id = isinstance(task_id, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id)
    disk = get_task_status(configuration, task_id) if safe_id else {}
    completed = [row for row in polls if parsed.get(row["seq"], {}).get("status") == "completed"]
    terminal = parsed.get(completed[-1]["seq"], {}) if completed else {}
    approvals = [row for row in rows if row["type"] == "approval/decided" and row["data"].get("verdict") == "allowed-once"]
    inference = [row for row in rows if row["type"] == "cost/ledger" and row["data"].get("purpose") == "inference"]
    successful = [row for row in inference if row["data"].get("response", {}).get("status") == 200]
    interrupted = [row for row in inference if row["data"].get("interrupted") is True]
    ends = [row for row in rows if row["type"] == "turn/end"]
    messages = [row for row in rows if row["type"] == "assistant/message"]
    final = next((row for row in reversed(messages) if ends and row["seq"] == ends[-1]["data"].get("lastAssistantSeq")), None)
    final_text = "\n".join(part["text"] for part in final["data"].get("content", []) if part.get("type") == "text") if final else ""
    exact_model_text = sdk.get("final_model", {}).get("text") if sdk else None
    raw_blocks = re.findall(r"```json\s*\n(.*?)\n```", exact_model_text or "", flags=re.S)
    try:
        exact_model = json.loads(raw_blocks[0]) if len(raw_blocks) == 1 else None
    except json.JSONDecodeError:
        exact_model = None
    ci_reference = sdk["tool_summaries"][-1]["summary"] if sdk and sdk["tool_summaries"] else None
    final_text = repair_ci_export_mask(final_text, ci_reference)
    blocks = re.findall(r"```json\s*\n(.*?)\n```", final_text, flags=re.S)
    try:
        model_summary = json.loads(blocks[0]) if len(blocks) == 1 else {}
    except json.JSONDecodeError:
        model_summary = {}
    target = science(disk.get("summary"))
    checks = {
        "continuous_ledger": [row["seq"] for row in rows] == list(range(1, len(rows) + 1)),
        "fresh_session_identity": bool(rows and rows[0]["type"] == "session/start" and rows[0]["data"].get("key") == runner["session_id"]),
        "one_model_empty_argument_start": bool(start and start.get("origin") == "model" and start["data"].get("args") == {}),
        "launch_running": launch.get("status") == "running",
        "runner_and_ledger_task_match": bool(safe_id and task_id == runner.get("task_id")),
        "model_polls_same_task_only": bool(polls and all(row.get("origin") == "model" and row["data"].get("args") == {"task_id": task_id} for row in polls)),
        "only_requested_tools": len(calls) == len(starts) + len(polls),
        "unique_calls_and_results": len({row["data"]["toolUseId"] for row in calls}) == len(calls) and len(results) == len(result_rows),
        "paired_successful_results": bool(starts + polls and all(row["data"]["toolUseId"] in results and
            results[row["data"]["toolUseId"]]["seq"] > row["seq"] and
            results[row["data"]["toolUseId"]].get("sourceEventSeqs") == [row["seq"]] and
            not results[row["data"]["toolUseId"]]["data"].get("isError") for row in starts + polls)),
        "all_payloads_same_task": bool(safe_id and len(parsed) == len(starts) + len(polls) and all(value.get("task_id") == task_id for value in parsed.values())),
        "exactly_one_allow_once_before_execution": bool(start and len(approvals) == 1 and start["data"]["name"] in approvals[0]["data"].get("scope", "") and
            start["seq"] < approvals[0]["seq"] < results.get(start["data"]["toolUseId"], {}).get("seq", 0)),
        "host_approval_budget_unchanged": sum(item["decision"] == "allowed-once" for item in runner["permissions"]) == 1 and all(item["decision"] == "allowed-once" for item in runner["permissions"]),
        "terminal_comparison_completed": bool(completed and terminal.get("tool") == TOOL and terminal.get("task_id") == task_id),
        "saved_artifact_and_geometry_chain_valid": disk.get("status") == "completed" and disk.get("tool") == TOOL,
        "passed_scientific_verdict": bool(target and target["comparison_status"] == "passed" and target["input_hashes_unchanged"] is True),
        "official_tool_scientific_summary_equals_disk": target is not None and science(terminal.get("summary")) == target,
        "successful_agnes_requests_http200": bool(successful and all(row["data"].get("model") == "agnes-3.0-flash" for row in inference) and len(successful) + len(interrupted) == len(inference)),
        "final_model_turn_after_completed_tool": bool(final and completed and ends[-1]["data"].get("reason") == "completed" and
            final["seq"] > results[completed[-1]["data"]["toolUseId"]]["seq"]),
        "model_final_exact_scientific_summary": bool(target and len(blocks) == 1 and model_summary.get("status") == "completed" and
            model_summary.get("task_id") == task_id and (science(model_summary.get("summary")) == target or model_summary == compact_target(disk))),
        "host_run_terminal": (runner.get("status") == "completed" and not runner.get("failure") and not runner.get("export_failure")) or
            bool(continuation and continuation.get("status") == "completed" and continuation.get("existing_task_only") is True and
                 continuation.get("no_new_inference_task") is True and continuation.get("task_id") == task_id and
                 continuation.get("session_id") == runner["session_id"] and not continuation.get("failure") and not continuation.get("export_failure")),
    }
    if observation:
        checks["host_run_terminal"] = observation.get("status") in {"completed", "turn_finished"} and observation.get("existing_task_only") is True and observation.get("no_new_inference_task") is True and observation.get("task_id") == task_id and not observation.get("failure")
    checks["final_turn_only_status_query"] = bool(ends) and all(call["data"]["name"] == "mcp_defect_researcher_45e5cef9_get_task_status" for call in calls if call["seq"] > (ends[-2]["seq"] if len(ends) > 1 else 0))
    extra = [call for call in calls if call not in starts + polls]
    checks["unrequested_tool_attempts_rejected_before_execution"] = all(
        results.get(call["data"]["toolUseId"], {}).get("data", {}).get("isError") is True and
        results[call["data"]["toolUseId"]]["data"].get("code") == "APPROVAL_REJECTED" for call in extra)
    paths = [ledger, html, directory / "runner.json"]
    if observation:
        paths += [observation_path, directory / "finalization.json", directory / "collection-attempt-1-session.jsonl"]
    if sdk:
        paths.append(sdk_path)
        checks["public_sdk_snapshot_bound_to_session_task_and_final_event"] = sdk.get("session_id") == runner["session_id"] and sdk.get("task_id") == task_id and sdk.get("official_last_seq") == ends[-1]["seq"] and sdk["final_model"]["seq"] == final["seq"]
        checks["public_sdk_final_text_hash_valid"] = hashlib.sha256(exact_model_text.encode("utf-8")).hexdigest() == sdk["final_model"]["text_sha256"]
        expected_export = exact_model_text.replace(str(ROOT), "<workspace>").replace(ROOT.as_posix(), "<workspace>")
        checks["official_export_matches_sdk_after_bound_decimal_and_workspace_redaction"] = final_text == expected_export
        checks["public_sdk_tool_science_equals_official_and_disk"] = bool(sdk_tools) and all(
            row["seq"] == results[identifier]["seq"] and science(row["summary"]) == target
            for identifier, row in sdk_tools.items())
    if continuation:
        paths += [continuation_path, directory / "transport-attempt-1-session.jsonl", directory / "transport-attempt-1-session.html", directory / "transport-attempt-1-runner.json"]
        checks["transport_failure_evidence_preserved"] = all(path.is_file() for path in paths)
        checks["continuation_only_read_same_task"] = not continuation.get("permissions") and bool(continuation.get("calls")) and all(
            call["name"] == "mcp_defect_researcher_45e5cef9_get_task_status" and call["args"] == {"task_id": task_id}
            for call in continuation["calls"])
    if safe_id:
        task_dir = Path(configuration["output_root"]) / task_id
        paths += [path for path in task_dir.rglob("*") if path.is_file() and path.suffix in {".json", ".jsonl", ".md", ".txt", ".yaml"}]
    scans = [{"path": str(path), "candidate_count": len(re.findall(rb"\bsk-[A-Za-z0-9._-]{12,}", path.read_bytes()))} for path in paths]
    checks["no_credential_candidates_in_exports_or_task"] = all(row["candidate_count"] == 0 for row in scans)
    scope_checks = {"only_requested_tools", "continuation_only_read_same_task"}
    science_checks = {key: value for key, value in checks.items() if key not in scope_checks}
    return {"schema_version": 1, "kind": "official_model_resolution_comparison_crosscheck", "status": "passed" if all(checks.values()) else "failed",
            "scientific_artifact_checks_passed": all(science_checks.values()),
            "strict_tool_scope_passed": all(checks.get(key, True) for key in scope_checks),
            "task_id": task_id, "session_id": runner["session_id"], "model_used": True, "checks": checks,
            "reasons": [key for key, value in checks.items() if not value], "checks_passed": sum(checks.values()), "checks_total": len(checks),
            "event_count": len(rows), "model_request_count": len(inference), "successful_model_request_count": len(successful),
            "interrupted_model_request_count": len(interrupted), "model_turn_count": len(ends), "poll_count": len(polls),
            "summary": disk.get("summary"), "secret_scan": scans, "final_model_text": final_text,
            "unrequested_tool_attempts": [{"seq": call["seq"], "name": call["data"]["name"], "args": call["data"]["args"], "result_code": results.get(call["data"]["toolUseId"], {}).get("data", {}).get("code")} for call in extra],
            "export_numeric_redaction_rule": "Only paired_recall.ci95[1] masked as 0.[REDACTED:id] is recovered from the separately observed public SDK science event. Final text then equals SDK text with only the known workspace prefix aligned; original exports are preserved.",
            "limitations": ["Host bounded follow-up turns are explicitly recorded; this does not prove autonomous scheduling.",
                            "Exact structured science fields are verified; natural-language interpretation still needs review.",
                            "Validation-only, one frozen checkpoint. No training or test inference is claimed."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=ROOT / "outputs" / "agh-resolution-comparison")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config")
    args = parser.parse_args()
    try:
        result = review(args.run_dir.resolve(), load_config(args.config))
    except Exception as error:
        result = {"status": "failed", "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: result.get(key) for key in ("status", "task_id", "checks_passed", "checks_total", "reasons", "error")}, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
