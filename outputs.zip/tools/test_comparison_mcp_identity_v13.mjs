import assert from 'node:assert/strict';
import {test} from 'node:test';
import {checkIdentity,checkStage,STAGE_SERVERS} from './check_comparison_mcp_identity_v13.mjs';

test('all V13 native dynamic manifests fit prefix32 and full-name64 without connections',async()=>{
 const results=await Promise.all(Object.keys(STAGE_SERVERS).map(checkStage));
 assert.deepEqual(results.map(r=>r.server_id),['dr-cmp13-d','dr-cmp13-p','dr-cmp13-f']);
 assert.equal(new Set(results.map(r=>r.tools_prefix)).size,3);
 for(const row of results){assert.equal(row.native_manifest_valid,true);assert.ok(row.prefix_length<=32);assert.ok(row.qualified_name_length<=64);assert.equal(row.connections,0);assert.equal(row.model_requests,0);}
});
test('official native checker reproduces preserved V11 long-prefix failure without connection',async()=>{
 const result=await checkIdentity('dr-compare-v11-diagnostic');
 assert.equal(result.native_manifest_valid,false);assert.ok(result.prefix_length>33);
 assert.ok(result.native_manifest_problems.some(problem=>problem.includes('prefix')));assert.equal(result.connections,0);
});
test('foreign stage cannot create a V13 native preflight identity',async()=>{await assert.rejects(checkStage('v11'));});
