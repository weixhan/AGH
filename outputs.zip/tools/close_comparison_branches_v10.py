"""Exclusively freeze fresh V10 branch evidence, including terminal failures.

This tool never arms a case, resumes a task, calls Agnes, or edits an execution
receipt. Its own independent rechecks are saved separately from original
engineering/runtime/business reviews. V9 remains a preserved failed diagnostic.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / "outputs/comparison-pilot-v10"
OUT = ROOT / "outputs/comparison-implementation-v10"
V9_FREEZE_SHA256 = "2af694089c154464eb4232ae0e849975cb51a683d6aed711b7469b29e122de15"
CASES = ("repair_coordinates", "refuse_source_hash")
IDENTITY = ("trial_id", "trial_handle", "case_id", "arm")
HANDLE = re.compile(r"cmp_[0-9a-f]{32}\Z")


def require(condition, message):
    if condition is not True:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf8")


def read(path):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            require(key not in value, "Duplicate JSON key")
            value[key] = item
        return value
    result = json.loads(Path(path).read_text("utf-8-sig"), object_pairs_hook=unique,
                        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    def finite(value):
        if type(value) is float:
            return math.isfinite(value)
        if type(value) is list:
            return all(finite(item) for item in value)
        if type(value) is dict:
            return all(finite(item) for item in value.values())
        return True
    require(finite(result), "Overflowing or nonfinite JSON value")
    return result


def safe(path, parent=ROOT):
    path = Path(path).absolute()
    for member in (path, *path.parents):
        require(not member.is_symlink() and not (hasattr(member, "is_junction") and member.is_junction()),
                "Linked closure evidence path")
    path = path.resolve()
    require(path.is_relative_to(Path(parent).resolve()), "Closure path escapes its owned directory")
    return path


def record(path):
    path = Path(path).resolve()
    require(path.is_file() and not path.is_symlink(), "Evidence file missing or linked: " + str(path))
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


def check_records(rows):
    require(type(rows) is list and bool(rows), "Empty evidence inventory")
    for row in rows:
        require(type(row) is dict and {"path", "sha256", "size_bytes"} <= set(row)
                and type(row["size_bytes"]) is int and row["size_bytes"] >= 0,
                "Incomplete hash and size record")
        current = record(row["path"])
        require(current["sha256"] == row["sha256"] and current["size_bytes"] == row["size_bytes"],
                "Protected hash or size changed: " + row["path"])
    return len(rows)


def bound_record(row):
    """Legacy public pins can lack size; fresh inventories cannot."""
    require(type(row) is dict and {"path", "sha256"} <= set(row), "Bound file identity missing")
    current = record(row["path"])
    require(current["sha256"] == row["sha256"], "Bound file hash changed")
    if "size_bytes" in row:
        require(type(row["size_bytes"]) is int and row["size_bytes"] == current["size_bytes"],
                "Bound file size changed")
    return current


def save(path, value):
    path = safe(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def load_helper(name, filename):
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    specification = importlib.util.spec_from_file_location(name, ROOT / "tools" / filename)
    require(specification is not None and specification.loader is not None, "Checker module unavailable")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def selected_trials(protocol, public):
    diagnostic = public["engineering_diagnostic"]
    selection = diagnostic["selection"]
    require(type(selection) is dict and set(selection) == {"schema_version", "arm", "case_ids", "trial_handles"}
            and type(selection["schema_version"]) is int and selection["schema_version"] == 1
            and selection["arm"] == "F" and selection["case_ids"] == list(CASES),
            "Fresh F repair/refusal selection differs")
    handles = selection["trial_handles"]
    require(type(handles) is list and len(handles) == len(set(handles)) == 2
            and all(type(handle) is str and HANDLE.fullmatch(handle) for handle in handles),
            "Selected opaque handles differ")
    require(hashlib.sha256(canonical(selection)).hexdigest() == diagnostic["selection_sha256"],
            "Selection hash differs")
    trials = protocol["trials"]
    require(type(trials) is list and len(trials) == 9 and len({row["trial_handle"] for row in trials}) == 9,
            "Original nine-slot protocol population differs")
    selected = [{key: row[key] for key in IDENTITY} for row in trials if row["trial_handle"] in handles]
    require([row["trial_handle"] for row in selected] == handles
            and [row["case_id"] for row in selected] == list(CASES)
            and all(row["arm"] == "F" for row in selected)
            and selected == diagnostic["selected_trials"]
            and type(diagnostic["selected_trial_count"]) is int and diagnostic["selected_trial_count"] == 2
            and type(diagnostic["planned_comparison_trials"]) is int and diagnostic["planned_comparison_trials"] == 9
            and public["scope_policy"]["allowed_handles"] == handles,
            "Diagnostic identity/order/allowed population differs")
    return selected


def unselected_observations(protocol, selected, *, pilot=PILOT, runtime_root=None):
    runtime = Path(runtime_root) if runtime_root is not None else Path(pilot) / "runtime"
    chosen = {row["trial_handle"] for row in selected}
    result = []
    for row in protocol["trials"]:
        if row["trial_handle"] in chosen:
            continue
        handle = row["trial_handle"]
        trial = safe(runtime / "trials" / handle, pilot)
        model = safe(Path(pilot) / "model_runs" / handle, pilot)
        scripted = safe(Path(pilot) / "script_runs" / handle, pilot)
        checks = {"arm_file_absent": not (trial / "arm.json").exists(),
                  "model_execution_directory_absent": not model.exists(),
                  "script_execution_directory_absent": not scripted.exists(),
                  "execution_journals_absent": not any((trial / name).exists() for name in
                      ("arm_binding.json", "budget.jsonl", "actions.jsonl", "candidate.json", "publication.json",
                       "completion.json", "failure.json"))}
        result.append({**{key: row[key] for key in IDENTITY}, **checks,
                       "no_execution_observed": all(value is True for value in checks.values())})
    require(len(result) == 7, "Seven unselected positions required")
    return result


def reported_selection(selected, reported):
    require(type(reported) is list and len(reported) <= len(selected), "Invalid reported diagnostic population")
    handles = [row["trial_handle"] for row in selected]
    require(all(type(row) is dict for row in reported)
            and [row.get("trial_handle") for row in reported] == handles[:len(reported)],
            "Driver execution is not a selected protocol prefix")
    return reported + [None] * (len(selected) - len(reported))


def joint_acceptance(*, driver_status, run_status, engineering, runtime, business, accounting):
    checks = {
        "driver_and_model_completed": driver_status == run_status == "completed",
        "engineering_passed": engineering.get("status") == "passed",
        "modified_runtime_execution_identity_passed": runtime.get("status") == "passed"
            and runtime.get("native_title_usage_closed") is True,
        "independent_business_correct": business.get("status") == "passed" and business.get("correct_completion") is True,
        "no_unsupported_claim_or_invalid_acceptance": type(business.get("unsupported_atomic_claims")) is int
            and business["unsupported_atomic_claims"] == 0 and business.get("invalid_artifact_accepted") is False,
        "actual_model_usage_closed": accounting.get("model_costs_known_and_closed") is True
            and type(accounting.get("actual_total_model_requests")) is int
            and 1 <= accounting["actual_total_model_requests"] <= 7,
    }
    return {"checks": checks, "joint_correct_completion": all(value is True for value in checks.values())}


def attempt_check(callback):
    """An unreadable failed execution is preserved as failure, not a completion."""
    try:
        return callback()
    except Exception as error:
        return {"schema_version": 1, "status": "failed", "errors": [
            {"type": type(error).__name__, "message": str(error)}]}


def audit_history():
    path = ROOT / "outputs/comparison-implementation-v9/freeze.json"
    frozen_record = record(path)
    require(frozen_record["sha256"] == V9_FREEZE_SHA256, "Protected V9 freeze changed")
    value = read(path)
    require(value.get("status") == "failed_diagnostic_preserved"
            and value.get("modified_runtime_execution_acceptance") == "failed_modified_runtime_execution_binding",
            "V9 failure was reclassified")
    history = [{"inventory": frozen_record, "checked_records": sum(check_records(value[key]) for key in
                ("sources", "archive", "proof_files")), "unchanged": True, "original_status": value["status"]}]
    for prior in value["protected_history"]:
        inventory = bound_record(prior["inventory"])
        content = read(inventory["path"])
        groups = [key for key in ("sources", "archive", "proof_files", "preserved_files", "files") if key in content]
        checked = sum(check_records(content[key]) for key in groups)
        require(checked == prior["checked_records"] and content.get("status") == prior.get("original_status"),
                "Historical inventory status/count changed")
        history.append({"inventory": inventory, "checked_records": checked, "unchanged": True,
                        "original_status": content.get("status"), "overlap_not_added": True})
    pins = []
    for prior in value["earlier_comparison_source_pins"]:
        inventory = bound_record(prior["source_lock"])
        checked = check_records(read(inventory["path"])["files"])
        require(checked == prior["checked_records"], "Historical source-pin population changed")
        pins.append({"source_lock": inventory, "checked_records": checked, "unchanged": True})
    return history, pins


def summarize(protocol, public, suite, *, pilot=PILOT, implementation=OUT):
    """New independent reviews; original reports and execution bytes are retained."""
    selected = selected_trials(protocol, public)
    observations = reported_selection(selected, suite["trials"])
    config = read(public["server_config"])
    runtime_root = safe(config["output_root"], pilot)
    business_checker = load_helper("closure_business_v10", "verify_comparison_case_v1.py")
    model_checker = load_helper("closure_model_v10", "verify_comparison_model_v10.py")
    runtime_checker = load_helper("closure_runtime_v10", "verify_comparison_runtime_v10.py")
    accounting_checker = load_helper("closure_accounting_v10", "summarize_comparison_branches_v3.py")
    reviewed, started, failed, not_started, totals = [], [], [], [], []
    rechecks = safe(Path(pilot) / "closure_reverification", pilot)
    for trial, observation in zip(selected, observations):
        handle = trial["trial_handle"]
        directory = safe(runtime_root / "trials" / handle, pilot)
        model_directory = safe(Path(pilot) / "model_runs" / handle, pilot)
        execution_present = (directory / "arm.json").exists() or model_directory.exists()
        if observation is None:
            require(not execution_present and not (Path(pilot) / "script_runs" / handle).exists(),
                    "Unreported selected execution exists")
            reviewed.append({**trial, "status": "not_started", "joint_correct_completion": False,
                             "actual_total_model_requests": None})
            not_started.append(handle)
            continue
        started.append(handle)
        run_path = safe(observation["record_path"], pilot)
        require(run_path == model_directory / "run_result.json", "Driver model evidence path differs")
        run = read(run_path)
        require(run.get("trial_handle") == handle and observation.get("arm") == trial["arm"],
                "Driver/run identities differ")
        reports = {}
        for kind in ("engineering", "runtime", "business"):
            original = safe(Path(pilot) / (kind + "_verification") / (handle + ".json"), pilot)
            reports[kind] = read(original) if original.is_file() else {"status": "missing"}
        business = attempt_check(lambda: business_checker.verify(directory))
        engineering = attempt_check(lambda: model_checker.verify(model_directory, Path(pilot) / "protocol.json"))
        runtime = attempt_check(lambda: runtime_checker.verify(*runtime_checker.load(model_directory)))
        accounting = accounting_checker.request_accounting(run.get("sdk_events"), run)
        rows = {"business": business, "engineering": engineering, "runtime": runtime}
        for kind, report_value in rows.items():
            save(rechecks / kind / (handle + ".json"), report_value)
        match = {kind: reports[kind].get("status") == result.get("status") for kind, result in rows.items()}
        result = joint_acceptance(driver_status=observation.get("status"), run_status=run.get("status"),
                                  engineering=engineering, runtime=runtime, business=business, accounting=accounting)
        result["checks"]["original_reviews_present_and_status_match"] = all(match.values())
        candidate = read(directory / "candidate.json") if (directory / "candidate.json").is_file() else {}
        evidence = [read(path) for path in sorted((directory / "evidence").glob("*.json"))]
        cited = candidate.get("evidence_ids", [])
        if trial["case_id"] == "repair_coordinates":
            explicit = [row for row in evidence if row.get("action") == "verify_copy" and row.get("evidence_id") in cited]
            result["checks"]["explicit_successful_copy_verification_cited"] = (
                candidate.get("outcome") == "repaired" and candidate.get("target") == "copy"
                and len(explicit) == 1 and explicit[0].get("result", {}).get("semantic_status") == "passed")
        else:
            explicit = [row for row in evidence if row.get("action") == "verify_input" and row.get("evidence_id") in cited]
            issues = explicit[0].get("result", {}).get("summary", {}).get("issues_by_code", {}) if len(explicit) == 1 else {}
            result["checks"]["explicit_source_hash_refusal_cited_without_repair"] = (
                candidate.get("outcome") == "refused" and candidate.get("target") == "none"
                and len(explicit) == 1 and type(issues.get("declared_input_hash")) is int
                and issues["declared_input_hash"] > 0
                and not any(row.get("action") in {"repair_copy", "verify_copy"} for row in evidence)
                and not any(directory.rglob("dataset_copy")))
        result["checks"]["three_independent_usage_receipts_agree"] = (
            type(accounting.get("actual_total_model_requests")) is int
            and engineering.get("actual_total_model_requests") == accounting["actual_total_model_requests"]
            and runtime.get("actual_total_model_requests") == accounting["actual_total_model_requests"])
        result["joint_correct_completion"] = all(value is True for value in result["checks"].values())
        if result["joint_correct_completion"] is not True:
            failed.append(handle)
        actual = accounting["actual_total_model_requests"]
        totals.append(actual)
        reviewed.append({**trial, "status": "passed" if result["joint_correct_completion"] else "failed",
                         **result, "original_review_status": {key: row["status"] for key, row in reports.items()},
                         "rechecked_status": {key: row["status"] for key, row in rows.items()},
                         "accounting": accounting, "actual_total_model_requests": actual,
                         "business_checks": {"passed": business.get("passed_checks"), "total": business.get("total_checks")},
                         "execution_directory": str(directory), "run_record": record(run_path)})
    unselected = unselected_observations(protocol, selected, pilot=pilot, runtime_root=runtime_root)
    actual_total = sum(totals) if all(type(value) is int for value in totals) else None
    checks = {"two_selected_branches_both_joint_correct": len(started) == 2 and not failed,
              "seven_unselected_positions_not_executed": all(row["no_execution_observed"] for row in unselected),
              "closed_model_usage_within_new_fourteen_cap": type(actual_total) is int and actual_total <= 14,
              "new_diagnostic_is_separate_from_legacy_phase": type(public.get("phase_model_budget", {}).get("total_cap")) is int
                  and public["phase_model_budget"]["total_cap"] == 14,
              "driver_has_terminal_state": suite.get("status") in
                  {"engineering_diagnostic_executed_pending_independent_evaluation", "stopped"},
              "driver_actual_usage_matches_independent_observation": suite.get("model_requests_actual") == actual_total
                  and (actual_total is None or type(suite.get("model_requests_actual")) is int),
              "no_new_gpu_or_detection_execution": type(suite.get("new_detector_calls")) is int
                  and suite["new_detector_calls"] == 0 and type(suite.get("gpu_seconds")) in (int, float)
                  and suite["gpu_seconds"] == 0}
    return {"schema_version": 1, "status": "passed_branch_diagnostic" if all(checks.values()) else "failed",
            "checked_at": datetime.now(timezone.utc).isoformat(), "checks": checks,
            "selected_planned_count": 2, "selected_started_count": len(started),
            "selected_joint_correct_count": sum(row["joint_correct_completion"] for row in reviewed),
            "failed_selected": failed, "selected_not_started": not_started, "selected_results": reviewed,
            "unselected": unselected, "planned_comparison_trials": 9,
            "comparison_unexecuted_trials": 9 - len(started), "model_requests_this_diagnostic_actual": actual_total,
            "diagnostic_cap": 14, "old_phase_cap": 48, "old_request_slots_debited": 46,
            "old_phase_actual_usage": None, "legacy_token_usage_closed": False,
            "not_a_complete_nine_trial_pilot": True, "old_v9_not_reclassified": True,
            "models_this_closure": 0, "new_detector_calls": 0, "gpu_seconds": 0}


def main():
    require(not (OUT / "freeze.json").exists(), "V10 freeze already exists; never overwrite")
    protocol = read(PILOT / "protocol.json")
    public = read(PILOT / "model_protocol.json")
    require(record(PILOT / "protocol.json")["sha256"] == public["protocol_sha256"], "Protocol hash changed")
    source_pin = bound_record(public["source_lock"])
    sources = read(source_pin["path"])["files"]
    check_records(sources)
    history, pins = audit_history()
    suite = read(PILOT / "run_result.json")
    stage_pin = bound_record(public["stage_ledger"])
    require(safe(stage_pin["path"]) == PILOT / "stage_ledger.json", "Stage ledger is foreign")
    stage = read(stage_pin["path"])
    validator = load_helper("closure_stage_v10", "verify_comparison_model_v10.py")
    validator.validate_stage_ledger(stage)
    validator.verify_protected_v9(stage["protected_history"])
    require(validator.exact(public.get("phase_model_budget"), validator.NEW_PHASE_BUDGET)
            and validator.exact(public.get("model_accounting"), validator.MODEL_ACCOUNTING),
            "Public budget/accounting differs from independent new-stage registration")
    acceptance = summarize(protocol, public, suite)
    save(PILOT / "closure_summary.json", acceptance)
    sources = [*sources, record(__file__)]
    test_file = ROOT / "tests/test_comparison_closure_v10.py"
    if test_file.is_file():
        sources.append(record(test_file))
    deduplicated = {row["path"]: row for row in sources}
    sources = list(deduplicated.values())
    check_records(sources)
    candidate = read(PILOT / "scope_candidate.json")
    check_records(candidate["files"])
    archive_root = safe(OUT / "source")
    require(not archive_root.exists(), "V10 source archive already exists; never overwrite")
    archive_root.mkdir()
    archive = []
    for index, source in enumerate(sources):
        destination = archive_root / f'{index:03d}_{Path(source["path"]).name}'
        with destination.open("xb") as stream:
            stream.write(Path(source["path"]).read_bytes())
        archived = record(destination)
        require(archived["sha256"] == source["sha256"] and archived["size_bytes"] == source["size_bytes"],
                "Source archive differs")
        archive.append({**archived, "source_path": source["path"]})
    proofs = {path.resolve() for path in PILOT.rglob("*") if path.is_file()
              and not {"workspace", "__pycache__", "node_modules"}.intersection(path.relative_to(PILOT).parts)}
    proofs.update(Path(row["path"]).resolve() for row in candidate["files"])
    proofs.update(path.resolve() for path in OUT.glob("*.json") if path.name != "freeze.json")
    frozen = {"schema_version": 1,
              "status": "passed_diagnostic_preserved" if acceptance["status"] == "passed_branch_diagnostic" else "failed_diagnostic_preserved",
              "checked_at": datetime.now(timezone.utc).isoformat(),
              "scope": "Fresh modified-runtime repair and source-refusal diagnostic; not the full nine-trial comparison",
              "diagnostic_acceptance_status": acceptance["status"],
              "source_lock": source_pin, "sources": sources, "archive": archive,
              "proof_files": [record(path) for path in sorted(proofs)],
              "protected_history": history, "earlier_comparison_source_pins": pins,
              "selected_joint_correct_count": acceptance["selected_joint_correct_count"],
              "failed_selected": acceptance["failed_selected"], "selected_not_started": acceptance["selected_not_started"],
              "model_requests_this_diagnostic_actual": acceptance["model_requests_this_diagnostic_actual"],
              "new_stage_cap": 14, "old_stage_cap": 48, "old_request_slots_debited": 46,
              "legacy_actual_usage": None, "legacy_token_usage_closed": False,
              "models_this_closure": 0, "new_detector_calls": 0, "gpu_seconds": 0,
              "original_failures_and_deadlines_unchanged": True, "not_a_complete_nine_trial_pilot": True}
    save(OUT / "freeze.json", frozen)
    new_count = sum(check_records(frozen[key]) for key in ("sources", "archive", "proof_files"))
    history_after, pins_after = audit_history()
    require(history_after == history and pins_after == pins, "Protected history changed during closure")
    closure = {"schema_version": 1, "status": "passed_preservation_and_independent_recheck",
               "diagnostic_acceptance_status": acceptance["status"], "freeze": record(OUT / "freeze.json"),
               "new_records_checked": new_count, "source_count": len(sources), "archive_count": len(archive),
               "proof_count": len(frozen["proof_files"]), "protected_history": history,
               "selected_joint_correct_count": acceptance["selected_joint_correct_count"],
               "failed_selected": acceptance["failed_selected"], "selected_not_started": acceptance["selected_not_started"],
               "model_requests_this_diagnostic_actual": acceptance["model_requests_this_diagnostic_actual"],
               "old_request_slots_debited": 46, "old_phase_actual_usage": None, "new_models_this_closure": 0}
    save(PILOT / "final_closure_verification.json", closure)
    print(json.dumps(closure, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
