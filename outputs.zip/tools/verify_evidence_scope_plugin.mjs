// Inspect the actual immutable candidate's registered public hooks using synthetic inputs.
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, resolve, join } from 'node:path';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-scoped-evidence');
const dir = join(output, 'workspace/.agh/extensions/evidence-scope-guard');
const policy = JSON.parse(await readFile(join(dir, 'policy.json'), 'utf8'));
const { evidenceScopeGuard } = await import(pathToFileURL(join(dir, 'index.mjs')));
const hooks = new Map(), events = [];
evidenceScopeGuard.apply({ extension: () => ({ registerHook: (name, handler) => hooks.set(name, handler),
  events: { append: async (name, data) => { events.push({ name, data }); return events.length; } } }) });
const context = { session: { key: 'synthetic-scope', workspaceRoot: policy.workspace_root }, replayed: false };
const unrelated = { session: { key: 'ordinary-session', workspaceRoot: root }, replayed: false };
const call = { name: policy.qualified_status_tool, args: { task_id: policy.task_id }, toolUseId: 'status-1' };
const checks = {};
checks.registered_public_hooks = ['session_start', 'tool_call', 'tool_result'].every(name => hooks.has(name));
await hooks.get('session_start')({}, unrelated);
checks.unrelated_workspace_has_no_readiness_event = events.length === 0;
checks.unrelated_workspace_tool_noop = (await hooks.get('tool_call')({ name: 'shell' }, unrelated)).allow === true && events.length === 0;
await hooks.get('session_start')({}, context);
checks.pinned_workspace_attested = events.at(-1)?.name === 'scope-ready' && events.at(-1).data.policy.task_id === policy.task_id;
checks.synthetic_native_denied = (await hooks.get('tool_call')({ ...call, name: 'shell' }, context)).allow === false;
checks.synthetic_wrong_task_denied = (await hooks.get('tool_call')({ ...call, args: { task_id: 'f'.repeat(32) } }, context)).allow === false;
checks.exact_task_allowed = (await hooks.get('tool_call')(call, context)).allow === true;
checks.synthetic_duplicate_denied = (await hooks.get('tool_call')(call, context)).allow === false;
assert.ok(Object.values(checks).every(Boolean), JSON.stringify(checks));
const report = { schema_version: 1, observed_at: new Date().toISOString(), status: 'passed', checks,
  runtime: 'actual candidate plugin export with synthetic extension registration; separate Core tests verify pre-execution refusal',
  model_called: false, files_or_shell_tools_executed: false };
await writeFile(join(output, 'plugin_candidate_verification.json'), JSON.stringify(report, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
console.log(JSON.stringify({ status: report.status, checks_passed: Object.keys(checks).length }));
