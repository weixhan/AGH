"""Freeze artifact review v2; preserve original execution and failed v1 review."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "09c5ce4aceb7426e87af5334bdb03eb4"
FAILED_RECOVERY = "b15612da05084920a3ce70772291557a"
RECOVERY = "c6be75d9328844308bd7987dbf13faec"
ROLES = {"sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
         "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier"}
FILES = [
    "defect_researcher/sliced_artifact_recovery.py", "defect_researcher/task_runtime.py",
    "tools/run_sliced_artifact_recovery.py", "tools/verify_sliced_artifact_recovery.py",
    "tools/reload_sliced_artifact_status_v2.py", "tools/freeze_sliced_artifact_recovery_v2.py",
    "tools/execute_sliced_artifact_recovery_v2.py",
    "tools/sliced_artifact_scope_guard.mjs", "tools/prepare_sliced_artifact_scope_v2.mjs",
    "tools/enable_sliced_artifact_scope_v2.mjs", "tools/run_sliced_artifact_model_v2.mjs",
    "tools/verify_sliced_artifact_model_v2.py", "tests/test_sliced_artifact_runtime.py",
    "tests/test_sliced_artifact_recovery.py", "tests/test_sliced_artifact_recovery_evidence.py",
    "tests/test_sliced_artifact_model_v2.py", "tests/sliced_artifact_scope_guard_v2.test.mjs",
    "tests/sliced_artifact_scope_core_v2.test.mjs",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    output = ROOT / "outputs/sliced-artifact-implementation-v2"
    if output.exists():
        raise FileExistsError("Preserve existing v2 implementation archive")
    origin = ROOT / "outputs" / ORIGIN
    old_recovery = ROOT / "outputs" / FAILED_RECOVERY
    prior_freeze = ROOT / "outputs/sliced-artifact-implementation-v1/freeze.json"
    execution_receipt = ROOT / "outputs/sliced-artifact-execution.json"
    for directory in (origin, old_recovery):
        if (directory / "completion.json").exists():
            raise ValueError("Historical failed tasks must retain their failures")
        failure = json.loads((directory / "failure.json").read_text(encoding="utf-8"))
        if failure["status"] != "failed" or failure["task_id"] != directory.name:
            raise ValueError("Unexpected historical task state")
    prior = json.loads(prior_freeze.read_text(encoding="utf-8"))
    receipt = json.loads(execution_receipt.read_text(encoding="utf-8"))
    if sha(origin / "failure.json") != prior["source_failure_sha256"]:
        raise ValueError("Original failure changed since v1 freeze")
    if receipt.get("status") != "failed":
        raise ValueError("Expected failed first artifact review receipt")
    inputs = json.loads((origin / "inputs.json").read_text(encoding="utf-8"))["files"]
    execution = [row for row in inputs if row["role"] in ROLES]
    if {row["role"] for row in execution} != ROLES:
        raise ValueError("Complete seven-role original execution identity required")
    for row in execution:
        if sha(row["path"]) != row["sha256_before"]:
            raise ValueError("Original execution source changed: " + row["role"])
    regression = ROOT / "outputs/sliced-artifact-v2-tests.log"
    log = regression.read_text(encoding="utf-8")
    counts = re.findall(r"Ran (\d+) tests", log)
    if not counts or not re.search(r"\nOK\s*$", log) or int(counts[-1]) < 478:
        raise ValueError("Passing complete v2 regression log required")
    preflight = ROOT / "outputs/agh-sliced-artifact-model-v2/preflight-tests.json"
    prepared = json.loads(preflight.read_text(encoding="utf-8"))
    if (prepared.get("status") != "passed" or prepared.get("model_called") is not False
            or prepared.get("new_detection_inference_performed") is not False):
        raise ValueError("Passing synthetic model preflight required")
    for name, expected in prepared.get("source_sha256", {}).items():
        if sha(ROOT / name) != expected:
            raise ValueError("Model preflight source changed: " + name)
    for result in prepared.get("tests", {}).values():
        if (type(result.get("passed")) is not int or type(result.get("total")) is not int
                or result["passed"] != result["total"] or result["passed"] <= 0):
            raise ValueError("Model preflight tests must all pass")
    for name in FILES:
        if not (ROOT / name).is_file():
            raise FileNotFoundError(name)
    output.mkdir()
    records = []
    for name in FILES:
        source, target = ROOT / name, output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        if sha(source) != sha(target):
            raise ValueError("Archive byte comparison failed: " + name)
        records.append({"path": name, "sha256": sha(source), "size_bytes": source.stat().st_size})
    document = {"schema_version": 1, "artifact_review_implementation_version": 2,
        "frozen_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "Fresh separately budgeted zero-detector v2 review; same 99 scientific checks",
        "source_task_id": ORIGIN, "recovery_task_id": RECOVERY,
        "prior_failed_recovery_task_id": FAILED_RECOVERY,
        "prior_failed_recovery_sha256": sha(old_recovery / "failure.json"),
        "prior_implementation_freeze_sha256": sha(prior_freeze),
        "prior_failed_execution_receipt_sha256": sha(execution_receipt),
        "original_status": "failed", "original_completion_absent": True,
        "original_pipeline_acceptance_passed": False, "original_budget_reset": False,
        "new_predict_calls": 0, "new_gpu_calls": 0, "max_recovery_wall_seconds": 600,
        "source_failure_sha256": sha(origin / "failure.json"),
        "original_execution_source_files": execution, "files": records,
        "python_regression_tests_passed": int(counts[-1]), "regression_log_sha256": sha(regression),
        "model_preflight_sha256": sha(preflight), "model_preflight": prepared,
        "formal_artifact_review_started": False, "new_model_read_started": False,
        "source_scientific_protocol_sha256": sha(ROOT / "fixtures/sliced_protocol.json")}
    (output / "freeze.json").write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"frozen": True, "files": len(records), "python_tests": int(counts[-1]),
                      "freeze_sha256": sha(output / "freeze.json")}))


if __name__ == "__main__":
    main()
