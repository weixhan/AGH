import test from 'node:test';
import assert from 'node:assert/strict';
import {waitOriginalSettlement} from './comparison_settlement_v1.mjs';
test('failure cleanup still observes already pending terminal events',async()=>{
  const events=[];const reading=new Promise(resolve=>setTimeout(()=>{events.push('turn/end','title/failed');resolve(events);},10));
  const result=await waitOriginalSettlement(reading,Date.now()+100);
  assert.deepEqual(result,['turn/end','title/failed']);
});
test('expired original deadline is refused without a new window',async()=>{
  await assert.rejects(waitOriginalSettlement(Promise.resolve(),100,()=>100),/expired/);
});
test('event failures are retained',async()=>{
  await assert.rejects(waitOriginalSettlement(Promise.reject(new Error('event stream failed')),Date.now()+100),/event stream failed/);
});
test('unsettled event stream stops at the original deadline',async()=>{
  await assert.rejects(waitOriginalSettlement(new Promise(()=>{}),Date.now()+10),/during settlement/);
});
