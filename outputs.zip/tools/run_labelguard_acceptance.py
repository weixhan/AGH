"""Execute all twelve frozen synthetic repair cases and persist actual evidence."""
from __future__ import annotations

import json
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.labelguard_fixtures import build_case, load_case_spec, snapshot_inputs, sha256, EXPECTED_FIXTURE_SHA256
from defect_researcher.label_repair import repair_label_copy
from defect_researcher.geometry_verifier import _numeric
from defect_researcher.task_runtime import get_task_status


def golden_matches(actual, expected, key=None):
    if key in ("rotated_corners", "hbb_xyxy"):
        return _numeric(actual, expected, 1e-8)[0]
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(name in actual and golden_matches(actual[name], value, name) for name, value in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(golden_matches(a, b) for a, b in zip(actual, expected))
    return actual == expected


def run_acceptance(research_root: Path, base: Path | None = None) -> dict:
    spec = load_case_spec()
    base = (base or ROOT / "outputs" / ("labelguard-acceptance-" + uuid.uuid4().hex)).resolve()
    base.mkdir(parents=True, exist_ok=False)
    cases = []
    for case in spec["cases"]:
        identifier = case["id"]
        built, config, report, summary, checks = {}, {}, {}, {}, {}
        changes, acceptance_errors = [], []
        try:
            built = build_case(base / "inputs" / identifier, case, spec, research_root)
            config = {**built["configuration"], "output_root": str(base / "tasks" / identifier)}
            report = repair_label_copy(config, identifier)
            disk = get_task_status(config, identifier)
            summary = report.get("summary", {})
            task_dir = Path(config["output_root"]) / identifier
            changes = [json.loads(line) for line in (task_dir / "repair_changes.jsonl").read_text(encoding="utf-8").splitlines()] if (task_dir / "repair_changes.jsonl").exists() else []
            frozen, expected = built["frozen"], case["expected"]
            checks = {
                "execution_completed": report.get("status") == "completed",
                "expected_repair_decision": summary.get("repair_status") == expected["repair_status"],
                "expected_before_finding": summary.get("before_verification_status") == expected["before_verification_status"],
                "saved_task_chain_verified": disk.get("status") == "completed" and disk.get("summary") == summary,
                "original_input_bytes_unchanged": snapshot_inputs(config) == frozen["files"],
                "frozen_input_evidence_hash_unchanged": sha256(Path(built["snapshot_path"])) == built["snapshot_sha256"],
                "exact_expected_change_scope": sorted(row["relative_path"] for row in changes) == sorted(expected["changed_files"]),
                "reported_change_count_matches_records": summary.get("changed_files") == len(changes),
                "copy_presence_matches_rule": (task_dir / "dataset_copy").is_dir() == expected["copy_present"],
                "after_finding_matches_rule": summary.get("verification_status") == expected["after_verification_status"],
                "repair_actually_executed_when_required": case["group"] != "repairable" or len(changes) > 0,
            }
            if expected["copy_present"]:
                copied = task_dir / "dataset_copy"
                checks["copied_labels_equal_frozen_answers"] = all((copied / name).read_bytes() == value.encode("utf-8") for name, value in frozen["golden_labels"].items())
                checks["copied_metadata_equal_frozen_answers"] = all(golden_matches(json.loads((copied / name).read_text(encoding="utf-8")), value) for name, value in frozen["golden_metadata"].items())
                checks["normal_files_preserved_exactly"] = case["group"] != "normal" or all((copied / name).read_bytes() == (Path(config["dataset_root"]) / name).read_bytes() for name in (*frozen["golden_labels"], *frozen["golden_metadata"]))
                checks["independent_after_passed"] = summary.get("verification_status") == "passed"
            else:
                copied = json.loads((task_dir / "copy_manifest.json").read_text(encoding="utf-8")) if (task_dir / "copy_manifest.json").exists() else {}
                checks["refusal_has_no_copy_or_after"] = copied.get("copy_root") is None and copied.get("files") == [] and copied.get("images") == [] and copied.get("after_verification") is None
                checks["refusal_has_reason"] = bool(summary.get("refusal_reasons"))
            checks["case_evidence_available"] = True
        except Exception as error:
            checks["case_evidence_available"] = False
            acceptance_errors.append({"stage": "acceptance_check", "type": type(error).__name__, "message": str(error)})
        cases.append({"case_id": identifier, "group": case["group"], "synthetic_only": True,
                      "status": "passed" if all(checks.values()) else "failed", "checks": checks,
                      "configuration": config, "task_id": identifier,
                      "frozen_input": {"path": built.get("snapshot_path"), "sha256": built.get("snapshot_sha256")},
                      "summary": summary, "actual_changed_files": len(changes),
                      "artifacts": report.get("artifacts", {}), "errors": report.get("errors", []) + acceptance_errors})
    groups = {group: {"total": sum(row["group"] == group for row in cases),
                      "passed": sum(row["group"] == group and row["status"] == "passed" for row in cases)}
              for group in ("normal", "repairable", "refused")}
    repairs = [row for row in cases if row["group"] == "repairable" and row["actual_changed_files"] > 0]
    modification_checks = ("original_input_bytes_unchanged", "exact_expected_change_scope",
                           "normal_files_preserved_exactly", "copy_presence_matches_rule",
                           "copied_labels_equal_frozen_answers", "copied_metadata_equal_frozen_answers")
    confirmed_unintended = sum(any(row["checks"].get(name) is False for name in modification_checks) for row in cases)
    unverified = sum(row["status"] != "passed" for row in cases)
    unintended = confirmed_unintended if unverified == 0 else None
    result = {"schema_version": 1, "kind": "frozen_synthetic_labelguard_repair_acceptance", "status": "passed" if len(cases) == 12 and all(row["status"] == "passed" for row in cases) and unintended == 0 else "failed",
              "model_used": False, "synthetic_only": True, "spec_sha256": EXPECTED_FIXTURE_SHA256,
              "groups": groups, "actual_repair_cases": len(repairs), "correct_repair_cases": sum(row["status"] == "passed" for row in repairs),
              "unintended_modification_cases": unintended,
              "confirmed_unintended_modification_cases": confirmed_unintended,
              "unverified_cases": unverified, "cases": cases,
              "limitations": ["All twelve cases are fabricated controlled inputs, not production defects.",
                              "This acceptance executes real copy repairs and independent checks; it does not use Agnes or perform inference."]}
    destination = base / "acceptance.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    result["evidence"] = str(destination)
    return result


def main() -> int:
    report = run_acceptance(Path(load_config()["research_root"]))
    print(json.dumps({"status": report["status"], "groups": report["groups"], "actual_repair_cases": report["actual_repair_cases"],
                      "correct_repair_cases": report["correct_repair_cases"], "unintended_modification_cases": report["unintended_modification_cases"],
                      "failed_cases": [{"case_id": row["case_id"], "checks": [name for name, passed in row["checks"].items() if not passed], "errors": row["errors"]} for row in report["cases"] if row["status"] != "passed"], "evidence": report["evidence"]}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
