"""Freeze the MCP manifest admission failure before any registered case starts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
SUITE = ROOT / 'outputs/comparison-suite-v11-diagnostic'
OUT = ROOT / 'outputs/comparison-implementation-v11-diagnostic'


def read(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(Path(path).read_text('utf-8-sig'), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'size_bytes': path.stat().st_size}


def check(rows):
    for row in rows:
        current = record(row['path'])
        if any(current[key] != row[key] for key in ('sha256', 'size_bytes')):
            raise ValueError('Protected bytes changed: ' + row['path'])


def save(path, value):
    with Path(path).open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    from tools.verify_comparison_model_v11 import validate_stage_ledger, verify_prerequisites
    public = read(SUITE / 'model_protocol.json')
    stage = read(SUITE / 'stage_ledger.json')
    validate_stage_ledger(stage)
    verify_prerequisites(stage, expected_stage='diagnostic')
    lock = public['source_lock']
    if record(lock['path'])['sha256'] != lock['sha256']:
        raise ValueError('Source lock changed')
    sources = read(lock['path'])['files']
    check(sources)
    for history in stage['protected_history']:
        check([history['freeze']])
        frozen = read(history['freeze']['path'])
        for key in ('sources', 'archive', 'proof_files', 'preserved_files'):
            check(frozen.get(key, []))
    protocol = read(SUITE / 'protocol.json')
    config = read(SUITE / 'server-config.json')
    if len(protocol['trials']) != 9 or public['selection']['selected_trial_count'] != 2:
        raise ValueError('Unexpected diagnostic population')
    if (SUITE / 'run_result.json').exists():
        raise ValueError('Runner started; use the case closure instead')
    for trial in protocol['trials']:
        handle = trial['trial_handle']
        directory = Path(config['output_root']) / 'trials' / handle
        if any((directory / name).exists() for name in ('arm.json', 'actions.jsonl', 'budget.jsonl', 'completion.json')):
            raise ValueError('Registered case began')
        for kind in ('model_runs', 'script_runs'):
            execution = SUITE / kind / handle
            if execution.exists() and any(execution.rglob('*')):
                raise ValueError('Execution evidence must close separately')
    activation = read(SUITE / 'mcp_activation.json')
    operations = [item.get('operation', {}) for item in activation['steps']]
    if activation['status'] != 'failed' or not any(
            op.get('state') == 'failed' and op.get('lastSafeError', {}).get('code') == 'MCP_RECONCILE_FAILED'
            for op in operations):
        raise ValueError('Expected original MCP activation failure')
    disabled = read(SUITE / 'disable_failed_service.json')
    if disabled['operation']['state'] != 'succeeded' or disabled['after']['connectionState'] != 'disabled':
        raise ValueError('Failed service not safely retired')
    manifest = read(public['runtime_version']['path'])
    for member in manifest['runtime_files']:
        if record(member['path'])['sha256'] != member['sha256'] or record(member['archive'])['sha256'] != member['sha256']:
            raise ValueError('Original runtime bytes changed')
    summary = {
        'schema_version': 1, 'status': 'passed_preservation_only_not_acceptance',
        'checked_at': datetime.now(timezone.utc).isoformat(), 'stage': 'diagnostic',
        'original_driver_status': 'not_started', 'all_nine_unarmed': True,
        'no_session_or_model_request_started_by_registered_runner': True,
        'no_original_session_resume': True, 'model_requests_this_diagnostic_actual': 0,
        'selected_joint_correct_count': 0, 'diagnostic_acceptance_status': 'failed',
        'failure_boundary': 'MCP dynamic extension manifest admission before any case execution',
        'root_cause': 'generated tools prefix length 39 exceeds extension-manifest pattern maximum 33',
        'original_runtime_restored_unchanged': True, 'failed_service_disabled': True,
        'stage_model_cap': 14, 'new_detector_calls': 0, 'gpu_seconds': 0,
        'scope': 'Setup failure preservation only; no acceptance or original deadline reset',
    }
    save(SUITE / 'setup_failure_preservation.json', summary)
    sources = sources + [record(Path(__file__)), record(SUITE / 'setup_failure_preservation.json')]
    archive = []
    for source in sources:
        target = OUT / 'source' / Path(source['path']).relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            raise FileExistsError('Archive already exists')
        shutil.copyfile(source['path'], target)
        archive.append(record(target))
    proofs = [record(path) for path in sorted(SUITE.rglob('*')) if path.is_file()]
    frozen = {
        'schema_version': 1, 'status': 'failed_setup_preserved', 'source_lock': lock,
        'sources': sources, 'archive': archive, 'proof_files': proofs,
        'protected_history': stage['protected_history'], 'original_driver_status': 'not_started',
        'selected_joint_correct_count': 0, 'all_nine_unarmed': True,
        'model_requests_this_diagnostic_actual': 0, 'stage_model_cap': 14,
        'legacy_actual_usage': None, 'no_original_session_resume': True,
        'new_detector_calls': 0, 'gpu_seconds': 0,
    }
    save(OUT / 'freeze.json', frozen)
    check(sources + archive + proofs)
    closure = {**summary, 'freeze': record(OUT / 'freeze.json'),
               'new_records_checked': len(sources) + len(archive) + len(proofs)}
    save(SUITE / 'final_closure_verification.json', closure)
    print(json.dumps({'status': closure['status'], 'freeze': closure['freeze'], 'model_requests_actual': 0}))


if __name__ == '__main__':
    main()
