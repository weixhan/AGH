// Explicit official resources-admin registration. No model action is invoked.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {ROOT,readModelProtocol,adminClient,effect,saveNew,stable,cliArgs} from './resolution_research_deployment_v1.mjs';
import {checkIdentity} from './check_resolution_research_mcp_identity_v1.mjs';
import {ACTION_TOOL,READ_TOOL} from './resolution_research_scope_guard_v1.mjs';

export function serverDefinition(p){return{serverId:p.server_id,displayName:'DefectResearcher bounded scientific recovery',
 transport:{kind:'stdio',executable:p.python_executable,args:['-B',join(ROOT,'run_resolution_research_mcp_v1.py'),
  '--protocol',p.deployment.path,'--expected-protocol-sha256',p.deployment.sha256,
  '--source-lock',p.source_lock.path,'--expected-lock-sha256',p.source_lock.sha256]},secretBinding:{kind:'none'},
 toolPolicy:{allow:['research_action_v1','research_read_v1']}};}
export async function activateMCP(path,hash,dependencies={}){
 if(Object.keys(dependencies).length&&dependencies.fixture_only!==true)throw new Error('Explicit fixture brand required for injected admin dependencies');
 const loaded=await readModelProtocol(path,hash,dependencies),p=loaded.protocol;
 const identity=await(dependencies.checkIdentity??checkIdentity)();
 if(identity.status!=='passed'||identity.connections!==0||identity.qualified_action_tool!==ACTION_TOOL||identity.qualified_read_tool!==READ_TOOL)throw new Error('Official zero-connection identity preflight required');
 const activation=JSON.parse(await readFile(p.scope_activation_path,'utf8'));
 if(activation.status!=='passed'||activation.complete!==true||activation.model_protocol_sha256!==hash||
  activation.fixture_only===true&&dependencies.fixture_only!==true)throw new Error('Exact scope must be active before exposing scientific MCP');
 const definition=serverDefinition(p),api=dependencies.api??adminClient('resources');
 const trace={schema_version:1,status:'running',complete:false,interface:'official resources-admin BFF',server_id:p.server_id,definition,
  model_protocol_path:loaded.path,model_protocol_sha256:hash,identity,steps:[],model_requests:0,gpu_tasks:0,
  domain_clock_started:false,credentials_read:false,fixture_only:dependencies.fixture_only===true};
 await saveNew(p.mcp_activation_path,trace);const save=()=>writeFile(p.mcp_activation_path,JSON.stringify(trace,null,2)+'\n');
 const recheck=()=>readModelProtocol(path,hash,dependencies);
 try{
  const context=await api('context');if(context.readOnly||context.profile!=='local-dev'||!context.clientId)throw new Error('Writable local-dev official context required');
  const base={profile:context.profile,clientId:context.clientId};
  const before=await api('mcp/list',{profile:base.profile});if(!Array.isArray(before.items)||before.items.some(r=>r.serverId===p.server_id))throw new Error('Refuse replacement of existing scientific server');
  trace.existing_before=await Promise.all(before.items.map(row=>api('mcp/get',{profile:base.profile,serverId:row.serverId})));await save();
  const opts={operationRoute:'operations/get',success:'succeeded',...dependencies,recheck};
  await effect(api,'mcp/create',{definition},base,trace,save,opts);
  let row=await api('mcp/get',{profile:base.profile,serverId:p.server_id});await effect(api,'mcp/trust',{serverId:p.server_id,expectedRevision:row.revision,trust:'trusted'},base,trace,save,opts);
  row=await api('mcp/get',{profile:base.profile,serverId:p.server_id});await effect(api,'mcp/enable',{serverId:p.server_id,expectedRevision:row.revision},base,trace,save,opts);
  row=await api('mcp/get',{profile:base.profile,serverId:p.server_id});await effect(api,'mcp/test',{serverId:p.server_id,expectedRevision:row.revision},base,trace,save,opts);
  trace.after=await api('mcp/get',{profile:base.profile,serverId:p.server_id});trace.status_snapshot=await api('mcp/status',{profile:base.profile,serverId:p.server_id});
  trace.tools=await api('mcp/tools',{profile:base.profile,serverId:p.server_id});
  trace.existing_after=await Promise.all(trace.existing_before.map(row=>api('mcp/get',{profile:base.profile,serverId:row.definition.serverId})));await recheck();
  const requestId=p.scope_policy.request_id,names=['research_action_v1','research_read_v1'];
  const contract=JSON.parse(await readFile(join(ROOT,'fixtures/resolution_research_mcp_protocol_v1.json'),'utf8'));
  const schema=name=>({type:'object',properties:{request_id:{type:'string',enum:[requestId]},
   action:{type:'string',enum:[...(name==='research_action_v1'?contract.action_enums:contract.read_enums)].sort()}},
   required:['request_id','action'],additionalProperties:false});
  trace.checks={old_services_exactly_preserved:trace.existing_before.every((r,i)=>stable(r)===stable(trace.existing_after[i])),
   new_trusted_ready:trace.after.trust==='trusted'&&trace.after.desired==='enabled'&&trace.after.actual==='ready',
   exact_registered_definition:stable(trace.after.definition)===stable(definition),
   two_exact_tools:trace.status_snapshot.toolCount===2&&trace.tools.items?.length===2&&
    trace.tools.items.map(t=>t.name).sort().join(',')===names.sort().join(',')&&
    trace.tools.items.every(t=>stable(t.inputSchema)===stable(schema(t.name))),
   original_outer_not_reset:Date.now()<p.scope_policy.deadline_epoch_ms,
   official_operations_succeeded:trace.steps.every(s=>s.operation.state==='succeeded')};
  trace.status=Object.values(trace.checks).every(Boolean)?'passed':'failed_preserved';
 }catch(error){trace.status='failed_preserved';trace.failure={type:error.name,message:error.message};}
 finally{trace.complete=trace.status==='passed';trace.finished_at=new Date().toISOString();await save();}return trace;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const a=cliArgs(process.argv.slice(2)),r=await activateMCP(a.path,a.hash);console.log(JSON.stringify({status:r.status,checks:r.checks,failure:r.failure}));if(r.status!=='passed')process.exitCode=1;
}
