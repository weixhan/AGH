import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-sliced-model');
const workspace = join(output, 'workspace');
const candidate = join(workspace, '.agh', 'extensions', 'sliced-scope-guard');
const policy = { schema_version: 1, workspace_root: workspace,
  qualified_start_tool: 'mcp_defect_researcher_45e5cef9_compare_validation_slices',
  qualified_status_tool: 'mcp_defect_researcher_45e5cef9_get_task_status', max_status_calls: 120 };
await mkdir(candidate, { recursive: true });
const saveNew = (path, data) => writeFile(path, data, { flag: 'wx' });
await copyFile(join(root, 'tools', 'sliced_scope_guard.mjs'), join(candidate, 'guard.mjs'), 1);
const entry = `import { createSlicedScopeGuard, normalizePath } from './guard.mjs';
export const slicedScopeGuard = { inject:['extension'], apply(ctx) {
  const policy = ${JSON.stringify(policy)};
  const guard = createSlicedScopeGuard(policy), agnes = ctx.extension();
  const scoped = hctx => normalizePath(hctx?.session?.workspaceRoot) === normalizePath(policy.workspace_root);
  agnes.registerHook('session_start', async (_payload, hctx) => {
    if(scoped(hctx)) await agnes.events.append('scope-ready', {session_key:hctx.session.key,workspace_root:hctx.session.workspaceRoot,mode:'sliced',policy});
  });
  agnes.registerHook('tool_call', async (payload,hctx) => {
    if(!scoped(hctx)) return {allow:true};
    const verdict=guard.tool_call(payload,hctx);
    await agnes.events.append('scope-decision',{session_key:hctx.session.key,name:payload.name,tool_use_id:payload.toolUseId,allow:verdict.allow,reason:verdict.reason??null});
    return verdict;
  });
  agnes.registerHook('tool_result',(payload,hctx)=>scoped(hctx)?guard.tool_result(payload,hctx):{});
} };
`;
await saveNew(join(candidate, 'index.mjs'), entry);
await saveNew(join(candidate, 'policy.json'), JSON.stringify(policy, null, 2)+'\n');
await saveNew(join(candidate, 'package.json'), JSON.stringify({name:'@defect-researcher/sliced-scope-guard',
  version:'0.1.0',private:true,license:'Apache-2.0',type:'module',exports:'./index.mjs',
  agnes:{plugins:[{export:'slicedScopeGuard',id:'ext:defect-researcher/sliced-scope-guard',inject:['extension']}]}
},null,2)+'\n');
const hash = bytes=>createHash('sha256').update(bytes).digest('hex');
await saveNew(join(output,'scope_candidate.json'),JSON.stringify({status:'prepared_not_activated',candidate,workspace,policy,
  files:await Promise.all(['guard.mjs','index.mjs','package.json','policy.json'].map(async name=>({name,sha256:hash(await readFile(join(candidate,name)))}))),
  limitation:'Execution guard is scoped to this exact workspace; call counters live in Host memory and do not prove business recovery.'
},null,2)+'\n');
console.log(JSON.stringify({status:'prepared_not_activated',candidate,workspace}));
