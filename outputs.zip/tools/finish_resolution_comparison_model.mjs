// Continue the same real session to collect the terminal tool result, without launching a new repair.
import { readFile, writeFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, finishEventReading } from './agh_ws_client.mjs';

const output = 'outputs/agh-resolution-comparison';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
const previous = (await readFile(output + '/session.jsonl', 'utf8')).trim().split('\n').map(JSON.parse);
const afterSeq = previous.at(-1).seq;
if (!launch.task_id || launch.permissions.filter(row => row.decision === 'allowed-once').length !== 1) {
  throw new Error('Expected exactly one previously authorized repair');
}
const record = { started_at: new Date().toISOString(), session_id: launch.session_id, task_id: launch.task_id,
  existing_task_only: true, no_new_inference_task: true, calls: [], results: [], status: 'starting' };
const recordPath = output + '/finalization.json';
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let iterator;
let reading;
try {
  const session = await client.session.load(launch.session_id, {
    cwd: process.cwd(), onPermissionRequest: async () => ({ verdict: 'rejected' }),
  });
  iterator = session.events()[Symbol.asyncIterator]();
  reading = (async () => {
    while (true) {
      const next = await iterator.next();
      if (next.done) break;
      const event = next.value;
      if (event.seq <= afterSeq) continue;
      if (event.type === 'tool/call') {
        record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
        await save();
        console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
      }
      if (event.type === 'tool/result') {
        const text = event.data.content?.find(block => block.type === 'text')?.text;
        if (text) {
          try {
            const result = JSON.parse(text);
            if (result.task_id) {
              record.results.push({ seq: event.seq, task_id: result.task_id, status: result.status, summary: result.summary });
              await save();
              console.log(JSON.stringify({ task_id: result.task_id, status: result.status, summary: result.summary }));
            }
          } catch { /* The final official export retains authoritative content. */ }
        }
      }
      if (event.type === 'turn/end') break;
    }
  })();
  record.status = 'running';
  await save();
  record.prompt = `只查询既有已完成的对照任务 ${launch.task_id}：调用一次 get_task_status，严禁再次启动对照、严禁shell或等待命令。此前工具已完成而模型通信中断，请完成最终答复。中文分析最多200字，只描述本次同权重验证集结果和限制。最后追加唯一JSON代码块{status,task_id,summary}，summary精确复制终态的comparison_status,split,val_images,val_boxes,train_imgsz,eval_imgsz,weight_sha256,same_weight,device,precision,input_hashes_unchanged,test_inference_performed,training_performed,metrics,comparison。不要四舍五入，不复制environments；不能声称测试集表现或普遍优越。`;
  record.turn_result = await session.prompt(record.prompt, { titleLocale: 'zh-CN' });
  await finishEventReading(reading);
  record.status = 'turn_finished';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  for (const [format, filename] of [['agnes', 'session-final.jsonl'], ['html', 'session-final.html']]) {
    const reader = await webClient();
    try {
      await exportSession({ positional: [launch.session_id], format, raw: false, out: output + '/' + filename }, {
        cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
      }, reader);
    } finally { await reader.close(); }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: launch.session_id, task_id: launch.task_id }));
}
