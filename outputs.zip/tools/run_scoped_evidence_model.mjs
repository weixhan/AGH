// Fresh model evidence read with server-side scope interception already activated.
import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, origin, finishEventReading } from './agh_ws_client.mjs';
import { normalizeScopePath } from './evidence_scope_guard.mjs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-scoped-evidence'), workspace = join(output, 'workspace');
const policy = JSON.parse(await readFile(join(workspace, '.agh/extensions/evidence-scope-guard/policy.json'), 'utf8'));
const activation = JSON.parse(await readFile(join(output, 'activation-v2.json'), 'utf8'));
if (!activation.complete || !activation.after?.trusted || activation.after.actual !== 'running')
  throw new Error('Reviewed scope plugin not activated');
const record = { schema_version: 1, started_at: new Date().toISOString(), policy,
  model: 'agnes-3.0-flash', route: 'account-defect-researcher', status: 'starting',
  permissions: [], calls: [], results: [], scope_decisions: [], assistant_text: '',
  tool_catalog_narrowed: false, old_full_comparison_acceptance_repaired: false,
  training_or_inference_started: false };
const recordPath = join(output, 'runner.json');
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let session, iterator, reading, readyTimer, readyResolve, readyReject, approvals = 0;
const ready = new Promise((res, rej) => { readyResolve = res; readyReject = rej; });
const abort = new AbortController(), timer = setTimeout(() => abort.abort(), 5 * 60_000);
try {
  const response = await fetch(`${origin}/admin/plugins/api/list`, { method: 'POST',
    headers: { Origin: origin, 'Content-Type': 'application/json' }, body: JSON.stringify({ profile: 'local-dev' }) });
  const live = (await response.json()).packages?.find(row => row.id === activation.package_id);
  if (!response.ok || live?.actualIntegrity !== activation.after.actualIntegrity || !live.trusted || live.actual !== 'running')
    throw new Error('Live activation differs from the reviewed snapshot');
  await client.workspace.add(workspace);
  session = await client.session.new({ cwd: workspace, sessionKey: randomUUID() });
  record.session_id = session.id; record.session_url = `${origin}/?session=${encodeURIComponent(session.id)}`;
  await save();
  session.onPermissionRequest(async request => {
    const name = request.toolCall?._meta?.['ai.agnes.harness']?.tool, args = request.toolCall?.rawInput;
    const once = request.options.find(option => option.kind === 'allow_once');
    const allowed = request.sessionId === session.id && name === policy.qualified_status_tool &&
      args?.task_id === policy.task_id && Object.keys(args).join(',') === 'task_id' && approvals === 0 && Boolean(once);
    if (allowed) approvals++;
    record.permissions.push({ name, args, decision: allowed ? 'allowed-once' : 'rejected' }); await save();
    return allowed ? { optionId: once.optionId } : { verdict: 'rejected' };
  });
  iterator = session.events()[Symbol.asyncIterator]();
  readyTimer = setTimeout(() => readyReject(new Error('No server-side scope readiness before model turn')), 15_000);
  reading = (async () => {
    for (;;) {
      const next = await iterator.next(); if (next.done) break;
      const event = next.value;
      if (event.type.endsWith('/scope-ready')) {
        if (event.data.mode !== 'evidence' || normalizeScopePath(event.data.workspace_root) !== normalizeScopePath(workspace) ||
            JSON.stringify(event.data.policy) !== JSON.stringify(policy)) throw new Error('Scope readiness mismatch');
        record.scope_ready = { seq: event.seq, type: event.type, data: event.data }; readyResolve();
      } else if (event.type.endsWith('/scope-decision')) record.scope_decisions.push({ seq: event.seq, ...event.data });
      else if (event.type === 'tool/call') record.calls.push({ seq: event.seq, ...event.data });
      else if (event.type === 'tool/result') {
        const text = event.data.content?.find(block => block.type === 'text')?.text;
        let value; try { value = JSON.parse(text); } catch { /* safe error code retained */ }
        record.results.push({ seq: event.seq, code: event.data.code, is_error: event.data.isError,
          ...(value ? { task_id: value.task_id, status: value.status, summary: value.summary } : {}) });
      } else if (event.type === 'assistant/message') record.assistant_text +=
        (event.data.content ?? []).filter(block => block.type === 'text').map(block => block.text).join('\n');
      await save();
      if (event.type === 'turn/end') break;
    }
  })();
  reading.catch(readyReject);
  await ready; clearTimeout(readyTimer);
  await session.setModel({ slot: 'primary', route: record.route, model: record.model });
  record.status = 'running'; await save();
  console.log(JSON.stringify({ session_id: session.id, guard_ready: true, url: record.session_url }));
  const prompt = `读取已完成实验任务 ${policy.task_id}，直接调用get_task_status一次。依据返回结果用中文概括640/960验证集差异，说明结论仅限同一640训练权重。最终附唯一JSON代码块{status,task_id,val_images,val_boxes,metrics}，精确复制status、task_id与summary中的val_images、val_boxes、metrics原始数字。本会话服务端限定上述读取。`;
  record.turn_result = await session.prompt(prompt, { signal: abort.signal, titleLocale: 'zh-CN' });
  await finishEventReading(reading);
  const terminal = record.results.find(row => row.status === 'completed' && row.task_id === policy.task_id);
  const blocks = [...record.assistant_text.matchAll(/```(?:json)?\s*([\s\S]*?)```/g)];
  if (blocks.length !== 1) throw new Error('Expected one machine-readable evidence block');
  record.final_json = JSON.parse(blocks[0][1]);
  const expected = terminal ? { status: terminal.status, task_id: terminal.task_id,
    val_images: terminal.summary.val_images, val_boxes: terminal.summary.val_boxes, metrics: terminal.summary.metrics } : null;
  record.checks = { readiness_before_model: Boolean(record.scope_ready), exactly_one_status_call: record.calls.length === 1,
    only_pinned_tool_and_task: record.calls.every(call => call.name === policy.qualified_status_tool &&
      call.args?.task_id === policy.task_id && Object.keys(call.args).join(',') === 'task_id'),
    matching_server_gate: record.scope_decisions.length === 1 && record.scope_decisions[0].allow === true,
    completed_source_task: Boolean(terminal), terminal_summary_verified: terminal?.summary?.comparison_status === 'passed',
    no_extra_or_rejected_attempts: record.scope_decisions.every(row => row.allow) && record.results.every(row => !row.is_error),
    model_copies_exact_evidence: JSON.stringify(record.final_json) === JSON.stringify(expected),
    old_failure_preserved: JSON.parse(await readFile(join(root, 'outputs/agh-resolution-comparison/model_run_verification.json'), 'utf8')).strict_tool_scope_passed === false };
  record.status = Object.values(record.checks).every(Boolean) ? 'passed' : 'failed';
  if (record.status !== 'passed') process.exitCode = 1;
} catch (error) {
  record.status = 'failed'; record.failure = { type: error.name, message: error.message }; process.exitCode = 1;
} finally {
  clearTimeout(timer); clearTimeout(readyTimer);
  await client.close(); await iterator?.return?.(); await finishEventReading(reading).catch(() => undefined);
  if (session) for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
    let exporter;
    try {
      exporter = await webClient();
      await exportSession({ positional: [session.id], format, raw: false, out: join(output, filename) }, {
        cwd: workspace, io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }) }, exporter);
    } catch (error) { record.export_failure = { type: error.name, message: error.message }; process.exitCode = 1; }
    finally { await exporter?.close(); }
  }
  record.finished_at = new Date().toISOString(); await save();
  console.log(JSON.stringify({ status: record.status, session_id: record.session_id, output,
    checks: record.checks, failure: record.failure, export_failure: record.export_failure }));
}
