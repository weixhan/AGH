// Public pre-execution hook policy for one frozen sliced-comparison session.
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const normalizePath = value => typeof value === 'string' ? value.replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase() : '';
export function createSlicedScopeGuard(policy) {
  if (!record(policy) || Object.keys(policy).sort().join(',') !==
      'max_status_calls,qualified_start_tool,qualified_status_tool,schema_version,workspace_root' ||
      policy.schema_version !== 1 || !normalizePath(policy.workspace_root) ||
      !/^mcp_[a-zA-Z0-9_]+_compare_validation_slices$/.test(policy.qualified_start_tool) ||
      !/^mcp_[a-zA-Z0-9_]+_get_task_status$/.test(policy.qualified_status_tool) ||
      policy.max_status_calls !== 120) throw new Error('Invalid sliced-comparison scope policy');
  const pinned = structuredClone(policy), sessions = new Map();
  const deny = reason => ({ allow: false, reason: `SLICED_SCOPE_DENIED: ${reason}` });
  const stateFor = context => {
    const session = context?.session;
    if (!record(session) || typeof session.key !== 'string' || !session.key || context.replayed === true ||
        normalizePath(session.workspaceRoot) !== normalizePath(pinned.workspace_root)) return undefined;
    if (!sessions.has(session.key)) sessions.set(session.key, { start: null, task: null, polls: 0, accepted: new Set() });
    return sessions.get(session.key);
  };
  return {
    tool_call(payload, context) {
      const state = stateFor(context);
      if (!state || !record(payload) || typeof payload.toolUseId !== 'string' || !payload.toolUseId)
        return deny('invalid session or call identity');
      if (state.accepted.has(payload.toolUseId)) return deny('duplicate call identity');
      if (payload.name === pinned.qualified_start_tool) {
        if (state.start || !record(payload.args) || Object.keys(payload.args).length)
          return deny('start requires one empty-argument invocation');
        state.start = payload.toolUseId;
        state.accepted.add(payload.toolUseId);
        return { allow: true };
      }
      if (payload.name !== pinned.qualified_status_tool) return deny('tool outside frozen sliced scope');
      if (!state.task || !record(payload.args) || Object.keys(payload.args).join(',') !== 'task_id' ||
          payload.args.task_id !== state.task) return deny('status must identify the accepted start result');
      if (state.polls >= pinned.max_status_calls) return deny('status budget exhausted');
      state.polls++;
      state.accepted.add(payload.toolUseId);
      return { allow: true };
    },
    tool_result(payload, context) {
      const state = stateFor(context);
      if (!state || !state.start || payload?.toolUseId !== state.start || state.task !== null || payload.result?.isError === true) return {};
      let result;
      try { result = JSON.parse(payload.result?.content?.find(x => x.type === 'text')?.text); } catch { return {}; }
      if (record(result) && /^[a-f0-9]{32}$/.test(result.task_id) && ['running', 'completed'].includes(result.status))
        state.task = result.task_id;
      return {};
    },
  };
}
