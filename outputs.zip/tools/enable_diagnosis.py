"""Apply the authorized saved-prediction diagnostic scope through AGH's official loopback BFF."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen
from uuid import uuid4

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "http://127.0.0.1:4177"
API = ORIGIN + "/admin/resources/api/"
SERVER = "defect-researcher"
OUTPUT = ROOT / "outputs" / "agh-diagnosis"


def request(action: str, body: dict | None = None) -> dict:
    encoded = None if body is None else json.dumps(body).encode("utf-8")
    req = Request(API + action, data=encoded, headers={
        "Origin": ORIGIN, "Accept": "application/json", "Content-Type": "application/json"
    })
    with urlopen(req, timeout=30) as response:
        return json.load(response)


def main() -> None:
    proposal_path = ROOT / "config" / "mcp-diagnosis-proposal.json"
    proposal = json.loads(proposal_path.read_text(encoding="utf-8-sig"))
    context = request("context")
    if context["profile"] != "local-dev" or context["readOnly"]:
        raise RuntimeError("Expected writable local-dev resource administration")
    profile = context["profile"]
    get = lambda: request("mcp/get", {"profile": profile, "serverId": SERVER})
    before = get()
    definition = before["definition"]
    expected_transport = proposal["transport"]
    if definition["transport"] != expected_transport or definition["secretBinding"] != {"kind": "none"}:
        raise RuntimeError("The live definition differs from the approved transport")
    expected_tools = proposal["existing_allowed_tools"]
    target_tools = [*expected_tools, proposal["proposed_added_tool"]]
    live_tools = definition.get("toolPolicy", {}).get("allow")
    if live_tools not in (expected_tools, target_tools):
        raise RuntimeError("The live tool scope differs from the approved change")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    trace = {"schema_version": 1, "interface": "official ResourceAdmin BFF", "origin": ORIGIN,
             "user_authorized": True, "proposal_sha256": hashlib.sha256(proposal_path.read_bytes()).hexdigest(),
             "before": before, "operations": [], "complete": False}
    trace_path = OUTPUT / "registration.json"
    if trace_path.exists():
        raise FileExistsError("A registration trace already exists; inspect it before any retry")

    def save() -> None:
        trace_path.write_text(json.dumps(trace, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def effect(action: str, **extra: object) -> None:
        current = get()
        params = {"profile": profile, "clientId": context["clientId"],
                  "commandId": "diagnosis-" + uuid4().hex, "serverId": SERVER,
                  "expectedRevision": current["revision"], **extra}
        entry = {"action": action, "params": params}
        trace["operations"].append(entry)
        save()
        entry["receipt"] = receipt = request(action, params)
        save()
        deadline = time.monotonic() + 60
        while True:
            operation = request("operations/get", {"profile": profile, "operationId": receipt["operationId"]})
            entry["operation"] = operation
            save()
            if operation["state"] in {"succeeded", "failed", "cancelled"}:
                break
            if time.monotonic() >= deadline:
                raise TimeoutError("Resource operation did not complete in 60 seconds")
            time.sleep(0.5)
        if operation["state"] != "succeeded":
            raise RuntimeError(f"{action} did not succeed: {operation.get('lastSafeError')}")
        entry["after"] = get()
        save()
        print(json.dumps({"action": action, "state": operation["state"],
                          "revision": entry["after"]["revision"]}), flush=True)

    save()
    try:
        if live_tools == expected_tools:
            if before["desired"] == "enabled":
                effect("mcp/disable")
            updated = dict(definition)
            updated["toolPolicy"] = {"allow": target_tools}
            effect("mcp/update", definition=updated)
        current = get()
        if current["trust"] != "trusted":
            effect("mcp/trust", trust="trusted")
        if get()["desired"] != "enabled":
            effect("mcp/enable")
        trace["after"] = get()
        trace["status"] = request("mcp/status", {"profile": profile, "serverId": SERVER})
        trace["catalog"] = request("mcp/tools", {"profile": profile, "serverId": SERVER})
        trace["complete"] = (trace["after"]["actual"] == "ready"
                             and trace["after"]["trust"] == "trusted"
                             and trace["after"]["definition"]["toolPolicy"]["allow"] == target_tools)
        save()
        if not trace["complete"]:
            raise RuntimeError("Final scope is not ready and trusted")
        print(json.dumps({"complete": True, "path": str(trace_path),
                          "status": trace["status"], "catalog": trace["catalog"]}), flush=True)
    except Exception as error:
        trace["failure"] = {"type": type(error).__name__, "message": str(error)}
        save()
        raise


if __name__ == "__main__":
    main()
