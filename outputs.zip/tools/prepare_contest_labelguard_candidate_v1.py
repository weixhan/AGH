"""Prepare a reviewable candidate folder, never the user's final ZIP or video."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DESTINATION = ROOT / 'delivery/labelguard-contest-candidate-20261014-v1'
HANDLE = 'cmp_6b357026ab64462d9163524a96b4de2f'
SESSION = '92465fc1-8f69-4c7d-bcf8-4fd0c346f20e'
V13_FREEZE = 'b05f74c5cd4a88a06204844d38301ca67a38fc259845636e64502349cebcd51e'
CPU_ZIP = '7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61'

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text('utf8'))

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')

def copy(source, destination):
    source=Path(source); destination=Path(destination)
    if source.is_symlink() or (hasattr(source,'is_junction') and source.is_junction()):
        raise ValueError('Linked source refused')
    destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():raise FileExistsError(str(destination))
    shutil.copyfile(source,destination)
    if digest(source)!=digest(destination):raise ValueError('Copied evidence bytes differ')

def main():
    if DESTINATION.exists():raise FileExistsError('Candidate folder already exists')
    freeze_path=ROOT/'outputs/comparison-implementation-v13-diagnostic/freeze.json'
    if digest(freeze_path)!=V13_FREEZE:raise ValueError('Original V13 freeze changed')
    frozen=read(freeze_path); protected=0
    for group in ('sources','archive','proof_files'):
        for pin in frozen[group]:
            path=Path(pin['path'])
            if path.stat().st_size!=pin['size_bytes'] or digest(path)!=pin['sha256']:
                raise ValueError('Frozen V13 evidence changed')
            protected+=1
    from tools.verify_comparison_case_v13 import verify as business_verify
    from tools.verify_comparison_runtime_v14 import verify as runtime_verify,load
    model_dir=ROOT/'outputs/comparison-suite-v13-diagnostic/model_runs'/HANDLE
    trial_dir=ROOT/'outputs/comparison-suite-v13-diagnostic/runtime/trials'/HANDLE
    business=business_verify(trial_dir)
    runtime=runtime_verify(*load(model_dir))
    engineering=read(ROOT/'outputs/comparison-suite-v13-diagnostic/engineering_verification'/f'{HANDLE}.json')
    if business['status']!='passed' or runtime['status']!='passed' or engineering['status']!='passed':
        raise ValueError('Core evidence was not currently verified')
    if engineering['actual_total_model_requests']!=6 or engineering['turn_reason']!='completed':
        raise ValueError('Actual core session completion/cost differs')
    archive=ROOT/'outputs/submission-bundle-v1-r1-exclusive/DefectResearcher-CPU-v1.zip'
    if digest(archive)!=CPU_ZIP:raise ValueError('CPU ZIP changed')
    DESTINATION.mkdir(parents=True,exist_ok=False)
    code=DESTINATION/'code'
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            relative=Path(item.filename)
            if relative.is_absolute() or '..' in relative.parts or ((item.external_attr>>16)&0o170000)==0o120000:
                raise ValueError('Unsafe ZIP member')
            target=code/relative
            if not target.resolve().is_relative_to(code.resolve()):raise ValueError('ZIP escape')
            target.parent.mkdir(parents=True,exist_ok=True)
            if item.is_dir():target.mkdir(exist_ok=True)
            else:
                with target.open('xb') as stream:stream.write(z.read(item))
    e=DESTINATION/'evidence'
    for name in ('session.jsonl','session.html','runtime_binding.json'):
        copy(model_dir/name,e/'agh-session'/name)
    copy(ROOT/'outputs/comparison-suite-v13-diagnostic/engineering_verification'/f'{HANDLE}.json',e/'engineering_original.json')
    copy(ROOT/'outputs/comparison-suite-v13-diagnostic/runtime_verification'/f'{HANDLE}.json',e/'runtime_original_failed.json')
    copy(ROOT/'outputs/comparison-suite-v13-diagnostic/final_closure_verification.json',e/'v13_original_closure_failed.json')
    copy(freeze_path,e/'v13_freeze_original.json')
    for path in sorted(trial_dir.rglob('*')):
        if path.is_file():copy(path,e/'agh-domain-case'/path.relative_to(trial_dir))
    for name in ('model_protocol.json','protocol.json'):
        copy(ROOT/'outputs/comparison-suite-v13-diagnostic'/name,e/name)
    copy(ROOT/'outputs/submission-bundle-v1-r1-exclusive/migration-evidence/migration_acceptance.json',e/'cpu_migration_original.json')
    save(e/'business_current_readonly_review.json',business)
    save(e/'runtime_supplemental_readonly_review.json',{
        'schema_version':1,'status':'passed_supplemental_readonly_review',
        'checked_at':datetime.now(timezone.utc).isoformat(),
        'original_session':SESSION,'original_v13_joint_status':'failed',
        'new_model_calls':0,'new_detector_calls':0,'gpu_seconds':0,
        'acceptance_rules':'V14 preregistered turn/start and auxiliary-title accounting rules',
        'checker_sha256':digest(ROOT/'tools/verify_comparison_runtime_v14.py'),
        'original_result_not_rewritten':True,'result':runtime,
        'limitations':['Supplemental review of saved actual execution; not a new model run.',
            'Official inner tool JSON is partially masked; domain artifacts retain business values.']})
    source=DESTINATION/'source-for-audit'
    for name in ('tools/verify_comparison_runtime_v14.py','tools/verify_comparison_case_v13.py',
                 'tools/verify_comparison_model_v13.py','tools/prepare_contest_labelguard_candidate_v1.py',
                 'docs/comparison-runtime-acceptance-v14.md'):
        copy(ROOT/name,source/name)
    save(DESTINATION/'candidate_preparation_receipt.json',{
        'schema_version':1,'status':'prepared_technical_candidate_not_submitted',
        'prepared_at':datetime.now(timezone.utc).isoformat(),'directory':str(DESTINATION),
        'original_v13_frozen_records_checked':protected,'original_v13_joint_status':'failed',
        'business_current_checks':business['passed_checks'],'business_current_total':business['total_checks'],
        'runtime_supplemental_checks':runtime['checks'],'actual_core_session':SESSION,
        'final_zip_created':False,'final_video_created':False,'external_published':False,
        'submission_complete':False,'cpu_zip_source_sha256':CPU_ZIP,
        'cpu_fresh_execution_pending':True,'identity_and_publication_pending':True})
    print(json.dumps({'status':'prepared_technical_candidate_not_submitted',
        'directory':str(DESTINATION),'original_records_unchanged':protected,
        'business_checks':business['passed_checks'],'original_joint_status':'failed'},ensure_ascii=False))

if __name__=='__main__':main()
