"""Read-only independent evaluator and current-evidence publication gate.

The gate checks already executed evidence, never performs geometry or reads
literal case answers. The post-run evaluator additionally checks fixed literal
answers independently of the production verifier and preserves acceptance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
PRIOR_FREEZE = ROOT / "outputs/research-workflow-implementation-v1/freeze.json"
PRIOR_FREEZE_SHA256 = "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from defect_researcher.comparison_protocol_v1 import (
    ACTIONS, CASE_SHA256, canonical, digest, load_case_spec, strict_json, validate_report,
)


def _safe(path):
    candidate = Path(path).absolute()
    for part in (candidate, *candidate.parents):
        if part.is_symlink() or (hasattr(part, "is_junction") and part.is_junction()):
            raise ValueError("Linked evaluator paths are refused")
    return candidate.resolve()


def _record(path):
    path = _safe(path)
    return {"path": str(path), "sha256": digest(path), "size_bytes": path.stat().st_size}


def _fresh(record):
    if type(record) is not dict or not {"path", "sha256"} <= set(record):
        return False
    try:
        current = _record(record["path"])
        return current["sha256"] == record["sha256"] and (
            "size_bytes" not in record or current["size_bytes"] == record["size_bytes"])
    except (OSError, ValueError, TypeError):
        return False


def _source_inventory(binding):
    files = binding.get("files", [])
    if (type(files) is not list or not files or not all(_fresh(record) for record in files)
            or len({_safe(record["path"]) for record in files}) != len(files)
            or binding.get("prior_freeze_sha256") != PRIOR_FREEZE_SHA256
            or digest(PRIOR_FREEZE) != PRIOR_FREEZE_SHA256
            or PRIOR_FREEZE.resolve() not in {_safe(record["path"]) for record in files}):
        return False
    frozen = strict_json(PRIOR_FREEZE)
    if frozen.get("status") != "passed":
        return False
    for group, count in (("sources", 25), ("archive", 25), ("preserved_files", 968)):
        if len(frozen.get(group, [])) != count or not all(_fresh(record) for record in frozen[group]):
            return False
    deployment = binding.get("deployment_lock")
    if deployment is not None:
        if not _fresh(deployment):
            return False
        lock = strict_json(deployment["path"])
        members = lock.get("files", [])
        if (lock.get("schema_version") != 1 or lock.get("kind") != "comparison_case_implementation_v1"
                or lock.get("status") != "passed" or not members or not all(_fresh(record) for record in members)
                or len({_safe(record["path"]) for record in members}) != len(members)):
            return False
        required = {ROOT / name for name in ("defect_researcher/comparison_case_runtime_v1.py",
                    "defect_researcher/comparison_protocol_v1.py", "defect_researcher/comparison_mcp_server_v1.py",
                    "run_comparison_mcp_v1.py", "tools/verify_comparison_case_v1.py", "config/local.json")}
        required.add(PRIOR_FREEZE)
        if not {path.resolve() for path in required} <= {_safe(record["path"]) for record in members}:
            return False
    return True


def _same(actual, expected):
    if type(actual) is bool or type(expected) is bool:
        return type(actual) is type(expected) and actual == expected
    if type(actual) in (int, float) and type(expected) in (int, float):
        return math.isfinite(actual) and math.isfinite(expected) and actual == expected
    if type(actual) is not type(expected):
        return False
    if type(actual) is dict:
        return actual.keys() == expected.keys() and all(_same(actual[key], expected[key]) for key in actual)
    if type(actual) is list:
        return len(actual) == len(expected) and all(_same(a, b) for a, b in zip(actual, expected))
    return actual == expected


def _field(result, field):
    value = result
    for part in field.split("."):
        if type(value) is not dict or part not in value:
            raise ValueError("Claim field does not exist in the cited evidence")
        value = value[part]
    return value


def _evidence_files(evidence):
    """Only known record collections count as source bindings; no arbitrary scan."""
    records = []
    manifest = evidence.get("task_manifest")
    if manifest is not None:
        records.append(manifest)
    result = evidence.get("result", {})
    records.extend(result.get("task_files", []))
    records.extend(result.get("files", []))
    records.extend(result.get("artifacts", {}).values())
    records.extend(result.get("source_dependencies", {}).values())
    if result.get("source_snapshot") is not None:
        records.append(result["source_snapshot"])
    repair_source = result.get("repair_source", {})
    if repair_source.get("completion") is not None:
        records.append(repair_source["completion"])
    return records


def _domain_chain(evidence):
    """Bind semantic summaries to the saved task, rather than trusting wrappers."""
    try:
        result = evidence["result"]
        directory = _safe(result["task_dir"])
        name = "repair_result.json" if evidence["action"] == "repair_copy" else "verification_result.json"
        saved = strict_json(directory / name) if result.get("execution_status") == "completed" else strict_json(directory / "failure.json")
        if (saved.get("tool") != result.get("tool") or saved.get("task_id") != result.get("task_id")
                or saved.get("status") != result.get("execution_status")
                or not _same(saved.get("summary", {}), result.get("summary", {}))
                or not _same(saved.get("configuration"), result.get("configuration"))
                or not _same(saved.get("errors", []), result.get("errors", []))):
            return False
        manifest_path = directory / ("artifact_manifest.json" if saved["status"] == "completed" else "failure.json")
        manifest = evidence.get("task_manifest", {})
        if _safe(manifest.get("path", "")) != manifest_path or not _fresh(manifest):
            return False
        if saved["status"] == "completed":
            completion = strict_json(directory / "completion.json")
            artifact = strict_json(manifest_path)
            if completion.get("artifact_manifest_sha256") != digest(manifest_path):
                return False
            if artifact.get("task_id") != saved["task_id"] or artifact.get("tool") != saved["tool"]:
                return False
            if not all(_fresh(record) for record in artifact.get("files", [])):
                return False
            input_manifest = strict_json(directory / "input_manifest.json")
            if input_manifest.get("all_unchanged") is not True or not input_manifest.get("files"):
                return False
            for record in input_manifest["files"]:
                if record.get("exists_before") is False:
                    if record.get("exists_after") is not False or Path(record["path"]).exists() or record.get("unchanged") is not True:
                        return False
                    continue
                if (record.get("unchanged") is not True
                        or record.get("sha256_before") != record.get("sha256_after")
                        or not _fresh({"path": record.get("path"), "sha256": record.get("sha256_after"),
                                       "size_bytes": record.get("size_bytes")})):
                    return False
            if evidence["action"] != "repair_copy":
                dataset = _safe(result["configuration"]["dataset_root"])
                declared_members = {_safe(record["path"]) for record in input_manifest["files"]
                                    if record.get("role", "").startswith(("labels/", "metadata/"))}
                current_members = {_safe(path) for kind in ("labels", "metadata")
                                   for path in (dataset / kind).rglob("*") if path.is_file()}
                if current_members != declared_members:
                    return False
            if evidence["action"] == "verify_copy" and not _repair_copy_chain(result):
                return False
            key = "repair_status" if evidence["action"] == "repair_copy" else "verification_status"
            return saved.get("summary", {}).get(key) == result.get("semantic_status")
        return result.get("semantic_status") == "execution_failed" and bool(saved.get("errors"))
    except (OSError, ValueError, TypeError, KeyError):
        return False


def _repair_copy_chain(result):
    """Recheck the already counted repair's whole copy from sealed receipts."""
    try:
        source = result["repair_source"]
        completion_record = source["completion"]
        if not _fresh(completion_record):
            return False
        directory = _safe(completion_record["path"]).parent
        completion = strict_json(directory / "completion.json")
        manifest_path = directory / "artifact_manifest.json"
        if completion.get("artifact_manifest_sha256") != digest(manifest_path):
            return False
        manifest = strict_json(manifest_path)
        if not all(_fresh(record) for record in manifest.get("files", [])):
            return False
        copy_manifest = strict_json(directory / "copy_manifest.json")
        copy_root = _safe(source["copy_root"])
        if copy_manifest.get("copy_root") != str(copy_root) or _safe(result["configuration"]["dataset_root"]) != copy_root:
            return False
        records = copy_manifest["files"]
        if not records or not all(_fresh(record) for record in records):
            return False
        declared = {record["relative_path"] for record in records}
        actual = {path.relative_to(copy_root).as_posix() for path in copy_root.rglob("*")
                  if path.is_file() and not path.relative_to(copy_root).as_posix().startswith("images/")}
        if len(declared) != len(records) or declared != actual:
            return False
        for record in records:
            if _safe(record["path"]) != _safe(copy_root / record["relative_path"]):
                return False
        images = copy_manifest["images"]
        declared_images = {record["relative_path"] for record in images}
        actual_images = {path.relative_to(copy_root).as_posix() for path in (copy_root / "images").rglob("*") if path.is_file()}
        if len(declared_images) != len(images) or declared_images != actual_images:
            return False
        for record in images:
            target = _safe(copy_root / record["relative_path"])
            if _safe(record["path"]) != target or not os.path.samefile(target, _safe(record["source_path"])):
                return False
        return True
    except (OSError, KeyError, ValueError, TypeError):
        return False


def _verifier_valid(evidence, outcome):
    result = evidence["result"]
    if outcome == "repaired":
        try:
            repair_completion = result.get("repair_source", {}).get("completion", {})
            repair_result = strict_json(_safe(repair_completion["path"]).parent / "repair_result.json")
            changed = repair_result.get("summary", {}).get("changed_files")
            positive_repair = type(changed) is int and changed > 0 and repair_result.get("summary", {}).get("repair_status") == "passed"
        except (OSError, ValueError, KeyError, TypeError):
            positive_repair = False
        return (positive_repair and evidence["action"] == "verify_copy" and result.get("semantic_status") == "passed"
                and result.get("execution_status") == "completed" and result.get("task_chain_verified") is True
                and result.get("summary", {}).get("independent_geometry_verification") is True
                and type(result.get("repair_source")) is dict
                and _fresh(result["repair_source"].get("completion")))
    if evidence["action"] != "verify_input":
        return False
    if outcome == "clean":
        return (result.get("semantic_status") == "passed" and result.get("execution_status") == "completed"
                and result.get("task_chain_verified") is True
                and result.get("summary", {}).get("independent_geometry_verification") is True)
    # A geometry finding limited to known label/metadata differences is not a
    # source refusal. Failed source checks and saved source-identity failures
    # are evidence for refusing a copy, without running another verification.
    repairable_codes = {"declared_label_tree_hash", "yolo_geometry", "label_class", "metadata_geometry"}
    summary = result.get("summary", {})
    issues = summary.get("issues_by_code", {})
    if result.get("execution_status") == "completed":
        return (result.get("task_chain_verified") is True and result.get("semantic_status") == "failed"
                and summary.get("independent_geometry_verification") is True
                and type(issues) is dict and bool(issues) and not set(issues) <= repairable_codes)
    guard = result.get("source_guard", {}) or {}
    return (result.get("execution_status") == "failed" and result.get("semantic_status") == "execution_failed"
            and guard.get("status") != "passed" and bool(result.get("errors")))


def evaluate_candidate(report, evidence, *, trial_handle, require_verified=False, check_claims=True):
    """Evaluate a candidate using current owned evidence, never expected answers.

    C/U publication sets check_claims=False: source integrity and schema are
    shared, while erroneous report values remain observable accepted artifacts.
    F publication sets require_verified=True and retains check_claims=True.
    The after-run evaluator always uses check_claims=True for every arm.
    """
    checks, errors, claims = [], [], []
    def check(name, passed, detail=None):
        passed = passed is True
        checks.append({"name": name, "passed": passed})
        if not passed:
            errors.append({"check": name, "detail": detail})
        return passed
    try:
        report = validate_report(report, trial_handle)
        check("common_report_schema_and_scope", True)
    except (ValueError, TypeError, KeyError) as error:
        check("common_report_schema_and_scope", False, str(error))
        return {"schema_version": 1, "status": "failed", "checks": checks, "errors": errors,
                "atomic_claims_total": 0, "atomic_claims_supported": 0, "claims": claims,
                "geometry_calls_performed": 0, "literal_answers_consulted": False}
    bindings = {}
    if type(evidence) is not list:
        evidence = []
    for item in evidence:
        identity = item.get("evidence_id") if type(item) is dict else None
        if (type(identity) is not str or identity in bindings or item.get("trial_handle") != trial_handle
                or item.get("action") not in ACTIONS or type(item.get("result")) is not dict):
            check("evidence_identity_unique_and_owned", False, identity)
            continue
        bindings[identity] = item
    check("cited_evidence_owned_and_present", all(identity in bindings for identity in report["evidence_ids"]))
    cited = [bindings[identity] for identity in report["evidence_ids"] if identity in bindings]
    for item in cited:
        records = _evidence_files(item)
        check("fresh_evidence_files:" + item["evidence_id"], all(_fresh(record) for record in records))
        if item["action"] in ("verify_input", "repair_copy", "verify_copy"):
            check("explicit_task_manifest:" + item["evidence_id"], item.get("task_manifest") is not None)
            check("saved_domain_semantics_bound:" + item["evidence_id"], _domain_chain(item))
            result = item["result"]
            check("domain_scope_and_original_bytes:" + item["evidence_id"],
                  result.get("synthetic_only") is True and result.get("inference_performed") is False
                  and result.get("model_used") is False and result.get("input_before_after", {}).get("unchanged") is True)
    for claim in report["claims"]:
        supported = False
        try:
            item = bindings[claim["evidence_id"]]
            supported = _same(_field(item["result"], claim["field"]), claim["value"])
        except (KeyError, ValueError, TypeError):
            pass
        claims.append({"name": claim["name"], "evidence_id": claim["evidence_id"],
                       "field": claim["field"], "supported": supported})
        if check_claims:
            check("atomic_claim:" + claim["name"], supported)
    history = any(item["action"] == "read_science" for item in cited)
    if check_claims:
        check("historical_scope_matches_citations", report["scope"]["historical_evidence_reused"] is history)
    if require_verified:
        check("mandatory_current_explicit_verification", any(_verifier_valid(item, report["outcome"]) for item in cited))
    return {"schema_version": 1, "status": "passed" if not errors else "failed",
            "checks": checks, "errors": errors, "atomic_claims_total": len(claims),
            "atomic_claims_supported": sum(item["supported"] for item in claims), "claims": claims,
            "geometry_calls_performed": 0, "literal_answers_consulted": False}


def _snapshot(configuration):
    result = {}
    for key in ("research_root", "dataset_root", "raw_root", "split_dir"):
        root = _safe(configuration[key])
        for path in sorted(root.rglob("*")):
            _safe(path)
            if path.is_file():
                result[key + "/" + path.relative_to(root).as_posix()] = _record(path)
    return result


def _chain(path):
    rows = []
    previous = "0" * 64
    raw = Path(path).read_bytes()
    if not raw.endswith(b"\n"):
        raise ValueError("Journal has an unfinished write")
    for number, line in enumerate(raw.decode("utf-8").splitlines()):
        def unique(pairs):
            obj = {}
            for key, value in pairs:
                if key in obj:
                    raise ValueError("Repeated journal JSON key")
                obj[key] = value
            return obj
        row = json.loads(line, object_pairs_hook=unique,
                         parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        if (type(row) is not dict or set(row) != {"schema_version", "sequence", "event", "previous_sha256", "record", "sha256"}
                or type(row["schema_version"]) is not int or row["schema_version"] != 1
                or type(row["sequence"]) is not int or row["sequence"] != number
                or row["previous_sha256"] != previous or type(row["record"]) is not dict):
            raise ValueError("Journal sequence, schema or hash-chain replay")
        bound = {key: value for key, value in row.items() if key != "sha256"}
        if row["sha256"] != hashlib.sha256(canonical(bound)).hexdigest():
            raise ValueError("Journal row hash differs")
        previous = row["sha256"]
        rows.append(row)
    if not rows:
        raise ValueError("Journal has no original opening record")
    return rows


def _budget(rows, arm, publication):
    used = 0
    pending = None
    reservations = {"inspect_input": 0, "verify_input": 1, "repair_copy": 3,
                    "verify_copy": 1, "read_science": 1, "publish_report": 0}
    previous_epoch, previous_mono = arm["started_epoch"], arm["started_monotonic"]
    if rows[0]["event"] != "ledger_opened" or any(rows[0]["record"].get(key) != value for key, value in arm.items()):
        raise ValueError("Budget opening differs from the exact original arm")
    for row in rows:
        record, event = row["record"], row["event"]
        clock = record.get("clock", record)
        for key, original, deadline in (("current_epoch", previous_epoch, arm["deadline_epoch"]),
                                        ("current_monotonic", previous_mono, arm["deadline_monotonic"])):
            if key in clock:
                value = clock[key]
                if type(value) not in (int, float) or not math.isfinite(value) or value < original or value >= deadline:
                    raise ValueError("Budget clock moved backwards or original deadline expired")
        previous_epoch = clock.get("current_epoch", previous_epoch)
        previous_mono = clock.get("current_monotonic", previous_mono)
        if event == "action_reserved":
            cost = record.get("reserved_cost")
            if pending is not None or type(cost) is not int or reservations.get(record.get("action")) != cost or used + cost > 6:
                raise ValueError("Unknown, repeated or over-budget reservation")
            pending = record
        elif event == "action_closed":
            cost = record.get("actual_cost")
            if pending is None or record.get("action") != pending["action"] or type(cost) is not int or not 0 <= cost <= pending["reserved_cost"]:
                raise ValueError("Closed cost has no matching known reservation")
            if "token" in pending and record.get("token") != pending["token"]:
                raise ValueError("Reservation token replayed")
            used += cost
            if record.get("used_domain_invocations") != used:
                raise ValueError("Cumulative cost does not equal actual receipts")
            pending = None
        elif event not in ("ledger_opened", "publishcheck", "model_request"):
            raise ValueError("Unknown budget event")
        elif event == "ledger_opened" and row["sequence"] != 0:
            raise ValueError("Budget original opening was replayed")
    snapshot = publication["budget"]
    if pending is not None or snapshot.get("pending") is not None or snapshot.get("domain_invocations_reserved", 0) != 0:
        raise ValueError("Publication has an open unknown-cost reservation")
    if snapshot.get("domain_invocations_used") != used or used > 6:
        raise ValueError("Publication cost differs from closed journal")
    for key, start, deadline in (("current_epoch", arm["started_epoch"], arm["deadline_epoch"]),
                                  ("current_monotonic", arm["started_monotonic"], arm["deadline_monotonic"])):
        if key in snapshot:
            value = snapshot[key]
            if type(value) not in (int, float) or not math.isfinite(value) or not start <= value < deadline:
                raise ValueError("Publication occurred outside its original wall deadline")
    return used


def _golden_dataset(spec, case):
    labels, metadata = {}, {}
    source, golden = case["source"], case["golden"]
    for index, image in enumerate(spec["base"]["images"], 1):
        split, filename = image["split"], image["file_name"]
        annotations = []
        if split == source["annotation_split"]:
            annotations.append({"annotation_id": source["annotation_id"], "image_id": image["image_id"],
                                "category_id": source["category_id"],
                                "class": spec["base"]["categories"][str(source["category_id"])],
                                "source_json": f"cable_{index}.json", "original_bbox": source["bbox"],
                                "rotation": source["rotation"], "rotated_corners": golden["rotated_corners"],
                                "hbb_xyxy": golden["hbb_xyxy"], "bbox_clipped": golden["bbox_clipped"],
                                "geometry_version": "hbb_v1", "gradation": source["gradation"], "anomaly_id": source["anomaly_id"]})
        stem = Path(filename).stem
        labels[f"labels/{split}/{stem}.txt"] = golden["label"] if annotations else ""
        metadata[f"metadata/{split}/{stem}.json"] = {"image": filename, "source_json": f"cable_{index}.json",
                                                   "image_id": image["image_id"], "width": source["dimensions"][0],
                                                   "height": source["dimensions"][1], "geometry_version": "hbb_v1", "annotations": annotations}
    return labels, metadata


def _golden_equal(actual, expected, field=None):
    if field in ("hbb_xyxy", "rotated_corners"):
        if type(expected) is list:
            return type(actual) is list and len(actual) == len(expected) and all(_golden_equal(a, b, field) for a, b in zip(actual, expected))
        return type(actual) in (int, float) and math.isfinite(actual) and abs(actual - expected) <= 1e-8
    if type(expected) is dict:
        return type(actual) is dict and actual.keys() == expected.keys() and all(_golden_equal(actual[key], value, key) for key, value in expected.items())
    if type(expected) is list:
        return type(actual) is list and len(actual) == len(expected) and all(_golden_equal(a, b) for a, b in zip(actual, expected))
    return _same(actual, expected)


def verify(directory):
    """Independently classify one terminal trial without modifying its files."""
    directory = _safe(directory)
    checks, errors = [], []
    def check(name, passed, detail=None):
        passed = passed is True
        checks.append({"name": name, "passed": passed})
        if not passed:
            errors.append({"check": name, "detail": detail})
        return passed
    accepted, candidate_result, used, case_group, outcome = None, None, None, None, None
    decision_supported = None
    try:
        registration = strict_json(directory / "registration.json")
        arm = strict_json(directory / "arm.json")
        publication = strict_json(directory / "publication.json")
        candidate = strict_json(directory / "candidate.json")
        accepted = publication["accepted"]
        check("publication_boolean_preserved", type(accepted) is bool)
        handle = registration["trial_handle"]
        check("owned_terminal_identity", registration.get("schema_version") == 1
              and registration.get("kind") == "comparison_case_trial_v1"
              and registration.get("owner") == "defect_researcher.comparison_case_runtime_v1"
              and registration.get("arm") in ("C", "U", "F")
              and arm.get("trial_handle") == handle and publication.get("trial_handle") == handle)
        check("immutable_registration_and_arm_receipts", strict_json(directory / "registration_binding.json") == _record(directory / "registration.json")
              and strict_json(directory / "arm_binding.json") == _record(directory / "arm.json"))
        check("registration_hash_and_original_clock_bound", arm.get("registration_sha256") == digest(directory / "registration.json")
              and arm["deadline_epoch"] == arm["started_epoch"] + 120
              and arm["deadline_monotonic"] == arm["started_monotonic"] + 120
              and arm.get("budget") == {"domain_invocations": 6, "model_requests": 8, "wall_seconds": 120, "gpu_seconds": 0})
        check("source_inventory_current_and_nonempty", _source_inventory(registration.get("source_binding", {})))
        prepared = registration.get("prepared_case", {})
        registered_root = _safe(registration["configuration"]["output_root"])
        check("shared_private_case_input_and_owned_output_paths", directory == registered_root / "trials" / handle
              and _safe(prepared["case_root"]) == registered_root / "inputs" / registration["case_id"])
        current_inputs = _snapshot(prepared["configuration"])
        check("original_input_exact_membership_and_bytes", current_inputs == registration["input_snapshot"])
        spec = load_case_spec()
        case = next(item for item in spec["cases"] if item["id"] == registration["case_id"])
        case_group = case["group"]
        frozen = strict_json(Path(prepared["case_root"]) / "frozen_inputs.json")
        check("literal_case_spec_and_snapshot_identity", frozen.get("spec_sha256") == CASE_SHA256
              and frozen.get("case_id") == case["id"] and frozen.get("files") == current_inputs
              and prepared.get("source_snapshot", {}).get("sha256") == digest(Path(prepared["case_root"]) / "frozen_inputs.json"))
        evidence = [strict_json(path) for path in sorted((directory / "evidence").glob("*.json"))]
        candidate_result = evaluate_candidate(candidate, evidence, trial_handle=handle)
        check("candidate_evidence_and_atomic_claim_truth", candidate_result["status"] == "passed", candidate_result["errors"])
        check("candidate_and_gate_hashes_bound", publication.get("candidate_sha256") == digest(directory / "candidate.json")
              and publication.get("gate_sha256") == digest(directory / "gate.json"))
        check("registered_group_gate_treatment", publication.get("gate_enforced") is (registration["arm"] == "F"))
        gate = strict_json(directory / "gate.json")
        replay_gate = evaluate_candidate(candidate, evidence, trial_handle=handle,
                                         require_verified=registration["arm"] == "F",
                                         check_claims=registration["arm"] == "F")
        check("publication_gate_independently_replays", gate.get("status") == replay_gate["status"]
              and accepted is (replay_gate["status"] == "passed"))
        if accepted:
            marker = strict_json(directory / "completion.json")
            check("accepted_completion_without_failure", not (directory / "failure.json").exists()
                  and marker.get("publication_sha256") == digest(directory / "publication.json"))
        else:
            check("rejected_failure_without_backfilled_completion", (directory / "failure.json").is_file()
                  and not (directory / "completion.json").exists())
        budget_rows = _chain(directory / "budget.jsonl")
        action_rows = _chain(directory / "actions.jsonl")
        used = _budget(budget_rows, arm, publication)
        check("closed_original_budget", True)
        snapshot = publication["budget"]
        check("publication_budget_binds_journal", snapshot.get("journal_sha256") == digest(directory / "budget.jsonl"))
        check("publication_deadline_unchanged", all(snapshot.get(key) == arm[key] for key in
              ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic")))
        action_pending, seen_ids, completed_actions = None, set(), []
        for row in action_rows:
            record = row["record"]
            if row["event"] == "action_started":
                if action_pending is not None or record.get("action") not in ACTIONS:
                    raise ValueError("Overlapping or unknown case action")
                action_pending = record["action"]
            elif row["event"] == "action_finished":
                if action_pending != record.get("action"):
                    raise ValueError("Action completion lacks matching start")
                identity = record.get("evidence_id")
                if identity is not None:
                    if identity in seen_ids:
                        raise ValueError("Action evidence ID replayed")
                    seen_ids.add(identity)
                completed_actions.append(record)
                action_pending = None
            else:
                raise ValueError("Unknown action journal event")
        check("action_trace_closed_and_evidence_membership", action_pending is None
              and seen_ids == {item["evidence_id"] for item in evidence})
        costs = [item.get("result", {}).get("cost", {}).get("domain_tool_calls", 0)
                 if item["action"] != "read_science" else 1 for item in evidence]
        domain_cost = sum(item.get("result", {}).get("cost", {}).get("domain_tool_calls", 0)
                          if item["action"] != "read_science" else 1 for item in evidence)
        check("actual_domain_cost_matches_evidence", all(type(cost) is int and cost >= 0 for cost in costs)
              and type(domain_cost) is int and domain_cost == used)
        outcome = candidate["outcome"]
        repairs = [item for item in evidence if item["action"] == "repair_copy"]
        copy_roots = [Path(item["result"]["summary"]["copy_root"]) for item in repairs
                      if item["result"].get("summary", {}).get("copy_root")]
        labels, metadata = _golden_dataset(spec, case)
        input_dataset = Path(prepared["configuration"]["dataset_root"])
        label_metadata_changes = []
        golden_ok = True
        for copy_root in copy_roots:
            copy_root = _safe(copy_root)
            if not copy_root.is_relative_to(directory):
                golden_ok = False
            expected_members = set(labels) | set(metadata)
            actual_members = {path.relative_to(copy_root).as_posix() for kind in ("labels", "metadata")
                              for path in (copy_root / kind).rglob("*") if path.is_file()}
            golden_ok &= actual_members == expected_members
            for name, expected in labels.items():
                path = copy_root / name
                golden_ok &= path.is_file() and path.read_bytes() == expected.encode("utf-8")
            for name, expected in metadata.items():
                path = copy_root / name
                golden_ok &= path.is_file() and _golden_equal(strict_json(path), expected)
            for name in expected_members:
                original, output = input_dataset / name, copy_root / name
                if not original.exists() or not output.exists() or original.read_bytes() != output.read_bytes():
                    label_metadata_changes.append(name)
            original_images = {path.relative_to(input_dataset / "images").as_posix(): _record(path)
                               for path in (input_dataset / "images").rglob("*") if path.is_file()}
            copied_images = {path.relative_to(copy_root / "images").as_posix(): _record(path)
                             for path in (copy_root / "images").rglob("*") if path.is_file()}
            golden_ok &= set(original_images) == set(copied_images) and all(
                original_images[key]["sha256"] == copied_images[key]["sha256"] for key in original_images if key in copied_images)
        if case_group == "normal":
            target = input_dataset
            if not copy_roots:
                golden_ok &= all((target / name).read_bytes() == value.encode("utf-8") for name, value in labels.items())
                golden_ok &= all(_golden_equal(strict_json(target / name), value) for name, value in metadata.items())
            decision_supported = outcome == "clean" and golden_ok and not label_metadata_changes
            check("normal_correct_without_label_metadata_change", decision_supported)
        elif case_group == "repairable":
            decision_supported = outcome == "repaired" and len(copy_roots) == 1 and golden_ok and sorted(label_metadata_changes) == sorted(case["expected"]["changed_files"])
            check("actual_repair_matches_literal_goldens_and_scope", decision_supported)
        else:
            decision_supported = outcome == "refused" and not copy_roots and not list(directory.rglob("dataset_copy"))
            check("source_refusal_without_any_copy", decision_supported)
    except (OSError, ValueError, KeyError, TypeError, StopIteration) as error:
        check("independent_reader_completed", False, {"type": type(error).__name__, "message": str(error)})
    return {"schema_version": 1, "kind": "independent_comparison_case_evaluation_v1",
            "status": "passed" if not errors else "failed", "directory": str(directory),
            "checks": checks, "passed_checks": sum(row["passed"] for row in checks), "total_checks": len(checks),
            "errors": errors, "group_accepted_candidate": accepted,
            "group_publication_decision_accepted": accepted,
            "group_terminal_published": accepted is True and (directory / "completion.json").is_file()
                                        and not (directory / "failure.json").exists(),
            "invalid_artifact_accepted": accepted is True and bool(errors),
            "correct_completion": accepted is True and not errors,
            "case_group": case_group, "reported_outcome": outcome,
            "atomic_claims_total": candidate_result["atomic_claims_total"] + int(decision_supported is not None) if candidate_result else 0,
            "unsupported_atomic_claims": (candidate_result["atomic_claims_total"] - candidate_result["atomic_claims_supported"] + int(decision_supported is False)) if candidate_result else None,
            "reported_decision_supported": decision_supported,
            "atomic_claim_definition": "structured evidence claims plus one independently evaluable outcome decision",
            "used_domain_invocations": used, "recovery_time": "not_measured",
            "model_requests": None, "model_budget_verified": False,
            "model_request_accounting": "separate independent official SDK receipt verification required",
            "new_detector_calls": 0, "gpu_seconds": 0, "evaluation_modified_execution": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    directory, output = _safe(args.directory), _safe(args.output)
    if output.is_relative_to(directory):
        parser.error("Independent evaluation must be saved outside execution evidence")
    result = verify(directory)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "passed_checks": result["passed_checks"],
                      "total_checks": result["total_checks"], "output": str(output)}, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
