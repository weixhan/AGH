"""Read preserved or V3 task status without launching a detector or MCP worker."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from defect_researcher.config import load_config
from defect_researcher.sliced_runtime_v3 import get_task_status


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--config")
    args = parser.parse_args()
    result = get_task_status(load_config(args.config), args.task_id)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result.get("status") in {"completed", "failed"} and not any(
        row.get("stage") == "v3_task_status" for row in result.get("errors", [])) else 1


if __name__ == "__main__":
    raise SystemExit(main())
