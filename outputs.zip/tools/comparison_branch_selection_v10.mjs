import {createHash} from 'node:crypto';
const stable=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
export function selectBranchDiagnostic(protocol,publicProtocol){
 const diagnostic=publicProtocol.engineering_diagnostic,selection=diagnostic?.selection;
 const budget=publicProtocol.phase_model_budget;
 if(!budget||budget.total_cap!==14||budget.prior_closed_request_slots!==0||budget.request_slots_debited!==0||budget.this_pilot_cap!==14||budget.phase_remaining_before_diagnostic!==14||budget.legacy_token_usage_closed!==true)throw new Error('Fresh stage budget differs');
 if(!selection||selection.schema_version!==1||selection.arm!=='F'||stable(selection.case_ids)!==stable(['repair_coordinates','refuse_source_hash'])||selection.trial_handles?.length!==2||diagnostic.selected_trial_count!==2||protocol.trials?.length!==9||new Set(protocol.trials.map(row=>row.trial_handle)).size!==9||diagnostic.selection_sha256!==createHash('sha256').update(stable(selection)).digest('hex'))throw new Error('Fresh two-branch selection differs');
 const selected=protocol.trials.filter(row=>selection.trial_handles.includes(row.trial_handle));
 if(selected.length!==2||selected.some(row=>row.arm!=='F')||stable(selected.map(row=>row.case_id))!==stable(selection.case_ids)||stable(selected.map(row=>row.trial_handle))!==stable(selection.trial_handles)||stable(publicProtocol.scope_policy.allowed_handles)!==stable(selection.trial_handles))throw new Error('Selected task identity differs');
 return selected;
}
