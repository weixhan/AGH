import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {join,resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {createResolutionResearchScopeGuard,applyResolutionResearchScope,readOwnedPreflightCompletion,ACTION_TOOL,READ_TOOL,TOOLS_PREFIX} from './resolution_research_scope_guard_v1.mjs';
const policy={schema_version:1,workspace_root:'E:/project/science-workspace',request_id:'fixed',task_id:'resolution-research-v1-fixed',
 started_epoch_ms:1000,deadline_epoch_ms:2401000,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,
 max_model_requests:14,max_primary_requests:13,max_native_title_requests:1};
const context={session:{key:'original',workspaceRoot:policy.workspace_root}};
const model={slot:'primary',model:'agnes-3.0-flash'};
function fixture(owned=null){let clock=1000;const guard=createResolutionResearchScopeGuard(policy,()=>clock,owned);guard.before_request(model,context);return{guard,setClock:x=>clock=x};}
const testRoot=resolve(dirname(fileURLToPath(import.meta.url)),'../.runtime/test-tmp');
const save=(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n');
const pin=async path=>({path,sha256:createHash('sha256').update(await readFile(path)).digest('hex')});
const record=async path=>({...await pin(path),size_bytes:(await readFile(path)).length});
// Production-shaped bytes are isolated disposable CPU test fixtures, never
// evidence from a scientific task or deployment registration.
async function withOwnedFixture(fn){
 await mkdir(testRoot,{recursive:true});const root=await mkdtemp(join(testRoot,'preflight-observer-'));
 try{
  const registry=join(root,'mcp-owned'),domain=join(root,'domain');await mkdir(registry);await mkdir(domain);
  const source=join(root,'test-source.txt');await writeFile(source,'isolated structural fixture');
  const deployment=join(root,'deployment_protocol.json'),lock=join(root,'source_lock.json');
  await save(deployment,{schema_version:1,kind:'resolution_research_mcp_deployment_v1',request_id:'fixed',task_id:policy.task_id,
   workspace_root:policy.workspace_root,started_epoch:1,deadline_epoch:2401,started_monotonic:2,deadline_monotonic:2402});
  await save(lock,{kind:'resolution_research_mcp_source_lock_v1',status:'passed_engineering_only',fixture_only:false,files:[await record(source)]});
  const owned={deployment:await pin(deployment),source_lock:await pin(lock),domain_task_directory:domain};
  await save(join(registry,'owner.json'),{owner:'defect_researcher.resolution_research_mcp_v1',request_id:'fixed',task_id:policy.task_id,
   protocol_sha256:owned.deployment.sha256,source_lock_sha256:owned.source_lock.sha256,fixture_only:false});
  const registration={task_id:policy.task_id,task_directory:domain,fixture_only:false,started_epoch:1,deadline_epoch:1801,started_monotonic:2,deadline_monotonic:1802};
  const receipt={task_id:policy.task_id,status:'preflight_passed',fixture_only:false,new_prediction_calls:0,deadline_reset:false,
   original_deadline_epoch:1801,original_deadline_monotonic:1802};
  await save(join(domain,'registration.json'),registration);await save(join(domain,'staged_preflight_receipt.json'),receipt);
  const wrapper={phase:'preflight',task_id:policy.task_id,result:receipt,fixture_only:false,request_id:'fixed',deployment:owned.deployment,source_lock:owned.source_lock,
   outer_started_epoch:1,outer_deadline_epoch:2401,outer_started_monotonic:2,outer_deadline_monotonic:2402,deadline_reset:false,
   preflight_receipt:await record(join(domain,'staged_preflight_receipt.json')),domain_registration:await record(join(domain,'registration.json'))};
  const resultPath=join(registry,'preflight-result.json');await save(resultPath,wrapper);
  return await fn({...fixture(owned),owned,root,registry,domain,source,wrapper,resultPath});
 }finally{await rm(root,{recursive:true,force:true});}
}
function call(guard,action,id=action,readonly=false){return guard.tool_call({name:readonly?READ_TOOL:ACTION_TOOL,toolUseId:id,args:{request_id:'fixed',action}},context);}
function result(guard,id,status,extra={}){return guard.tool_result({toolUseId:id,result:{isError:false,content:[{type:'text',text:JSON.stringify({request_id:'fixed',task_id:policy.task_id,fixture_only:false,status,...extra})}]}},context);}
async function pending(guard){assert.equal(call(guard,'audit_geometry').allow,true);result(guard,'audit_geometry','running',{phase:'preflight'});
 assert.equal(guard.snapshot().phase,'preflight_pending');assert.equal((await guard.observe_preflight_completion(context)).observed,true);
 assert.equal(call(guard,'register_hypothesis').allow,true);result(guard,'register_hypothesis','hypothesis_registered');
 assert.equal(call(guard,'start_registered_experiment').allow,true);result(guard,'start_registered_experiment','running');}

test('explicit actual fault observation precedes model-owned resume and report decision',()=>withOwnedFixture(async({guard})=>{
 await pending(guard);
 assert.equal(call(guard,'resume_registered_failure').allow,false);
 assert.equal(call(guard,'status','fault',true).allow,true);result(guard,'fault','recovery_pending',{actual_failure:{closed_cost:true}});
 assert.equal(call(guard,'resume_registered_failure').allow,true);result(guard,'resume_registered_failure','running');
 assert.equal(call(guard,'status','complete',true).allow,true);result(guard,'complete','experiment_completed');
 assert.equal(call(guard,'independent_review','review',true).allow,true);result(guard,'review','reviewed',{verification:{status:'passed',real_recovery_accepted:true},only_supported_decision_action:'decide_stop_resolution'});
 assert.equal(call(guard,'decide_retain_resolution').allow,false);assert.equal(call(guard,'decide_stop_resolution').allow,true);result(guard,'decide_stop_resolution','decided');
 assert.equal(call(guard,'publish_report').allow,true);result(guard,'publish_report','report_completed');assert.equal(guard.snapshot().phase,'reported');
}));
test('one running plus fault plus complete reads; no fourth status',()=>withOwnedFixture(async({guard})=>{
 await pending(guard);assert.equal(call(guard,'status','running',true).allow,true);result(guard,'running','running');
 assert.equal(call(guard,'status','fault',true).allow,true);result(guard,'fault','recovery_pending',{actual_failure:{closed_cost:true}});
 call(guard,'resume_registered_failure');result(guard,'resume_registered_failure','running');
 assert.equal(call(guard,'status','complete',true).allow,true);result(guard,'complete','experiment_completed');
 assert.equal(call(guard,'status','fourth',true).allow,false);assert.equal(guard.snapshot().status_calls,3);
}));
test('thirteen primary requests plus separate native title accounting, never fourteen primary',()=>{
 const {guard}=fixture();for(let i=2;i<=13;i++)assert.equal(guard.before_request(model,context).request_index,i);
 assert.equal(guard.before_request(model,context).allow,false);assert.equal(guard.snapshot().primary_requests,13);
});
test('a new same-workspace session cannot reset original counters or clock',()=>{
 const {guard}=fixture();assert.equal(guard.before_request(model,{session:{...context.session,key:'replacement'}}).allow,false);
 assert.equal(guard.snapshot().session_key,'original');
});
test('outer deadline exact and reversed clocks deny actions without reset',()=>{
 const {guard,setClock}=fixture();setClock(2401000);assert.equal(guard.before_request(model,context).allow,false);assert.equal(call(guard,'audit_geometry').allow,false);
 const other=fixture();other.setClock(999);assert.equal(other.guard.before_step({},context).block,true);
});
test('wrong IDs, paths, budgets, commands, other tools and repeated identities are denied',()=>{
 const {guard}=fixture();for(const args of [{request_id:'other',action:'audit_geometry'}, {request_id:'fixed',action:'audit_geometry',path:'x'},
  {request_id:'fixed',action:'audit_geometry',budget:1801},{request_id:'fixed',action:'audit_geometry',command:'python'}])
  assert.equal(guard.tool_call({name:ACTION_TOOL,toolUseId:'bad',args},context).allow,false);
 assert.equal(guard.tool_call({name:'exec',toolUseId:'shell',args:{request_id:'fixed',action:'audit_geometry'}},context).allow,false);
 assert.equal(call(guard,'audit_geometry','once').allow,true);assert.equal(call(guard,'audit_geometry','once').allow,false);
});
test('fixture or wrong-result identity cannot advance production scope',()=>{
 const {guard}=fixture();call(guard,'audit_geometry');result(guard,'audit_geometry','preflight_passed',{fixture_only:true});
 assert.equal(call(guard,'register_hypothesis').allow,false);
});
test('failed preflight permits explicit stop and honest report, not an experiment start',()=>{
 const {guard}=fixture();call(guard,'audit_geometry');result(guard,'audit_geometry','preflight_failed');
 assert.equal(call(guard,'start_registered_experiment').allow,false);assert.equal(call(guard,'stop_insufficient_evidence').allow,true);
 result(guard,'stop_insufficient_evidence','stopped');assert.equal(call(guard,'publish_report').allow,true);
});
test('concurrent speculative action does not consume the later valid action',()=>withOwnedFixture(async({guard})=>{
 call(guard,'audit_geometry');assert.equal(call(guard,'register_hypothesis','early').allow,false);
 result(guard,'audit_geometry','running',{phase:'preflight'});assert.equal(call(guard,'register_hypothesis','unobserved').allow,false);
 await guard.observe_preflight_completion(context);assert.equal(call(guard,'register_hypothesis','later').allow,true);
}));
test('only fixed source-pinned preflight observation can gate; it never consumes requests or status reads',()=>withOwnedFixture(async({guard})=>{
 call(guard,'audit_geometry');result(guard,'audit_geometry','running',{phase:'preflight'});
 assert.equal(call(guard,'status','preflight-status',true).allow,false);
 const before=guard.snapshot();const observed=await guard.observe_preflight_completion(context);assert.equal(observed.observed,true);
 assert.equal(guard.snapshot().phase,'gated');assert.equal(guard.snapshot().primary_requests,before.primary_requests);
 assert.equal(guard.snapshot().status_calls,0);assert.equal((await guard.observe_preflight_completion(context)).observed,false);
 assert.equal(observed.evidence.new_prediction_calls,0);assert.equal(observed.deadline_reset,false);
}));
test('notification strings and synchronous passed tool text cannot replace an asynchronous owned result',()=>{
 const {guard}=fixture();call(guard,'audit_geometry');result(guard,'audit_geometry','preflight_passed');
 assert.equal(guard.snapshot().phase,'new');assert.equal(call(guard,'register_hypothesis').allow,false);
});
test('missing preflight result remains pending with original session and clock',()=>withOwnedFixture(async({guard,resultPath,setClock})=>{
 await rm(resultPath);call(guard,'audit_geometry');result(guard,'audit_geometry','running',{phase:'preflight'});
 assert.equal((await guard.observe_preflight_completion(context)).observed,false);assert.equal(guard.snapshot().phase,'preflight_pending');
 setClock(policy.deadline_epoch_ms);assert.equal((await guard.observe_preflight_completion(context)).observed,false);
 assert.equal(call(guard,'register_hypothesis').allow,false);
}));
test('preflight result identity, fixture, deployment clock or receipt tampering never advances scope',async()=>{
 for(const change of [{request_id:'other'},{fixture_only:true},{outer_deadline_epoch:9999},{deadline_reset:true}])
  await withOwnedFixture(async({guard,wrapper,resultPath})=>{
   call(guard,'audit_geometry');result(guard,'audit_geometry','running',{phase:'preflight'});await save(resultPath,{...wrapper,...change});
   await assert.rejects(()=>guard.observe_preflight_completion(context));assert.equal(guard.snapshot().phase,'preflight_pending');
  });
 await withOwnedFixture(async({owned,domain})=>{
  await save(join(domain,'staged_preflight_receipt.json'),{});await assert.rejects(()=>readOwnedPreflightCompletion(policy,owned),/artifact/);
 });
});
test('preflight deployment/source/registry drift and fixture source lock refuse production observation',async()=>{
 for(const target of ['deployment','source_lock','source','owner'])await withOwnedFixture(async f=>{
  const path=target==='source'?f.source:target==='owner'?join(f.registry,'owner.json'):f.owned[target].path;
  await writeFile(path,'changed');await assert.rejects(()=>readOwnedPreflightCompletion(policy,f.owned));
 });
});
test('a verified real preflight failure supports stop, preserves pending action and cannot register inference',()=>withOwnedFixture(async({guard,wrapper,resultPath})=>{
 const failed={...wrapper,result:{task_id:policy.task_id,status:'failed',error_type:'ValueError',error:'CPU geometry refused'}};
 delete failed.preflight_receipt;delete failed.domain_registration;await save(resultPath,failed);
 call(guard,'audit_geometry');result(guard,'audit_geometry','running',{phase:'preflight'});await guard.observe_preflight_completion(context);
 assert.equal(guard.snapshot().phase,'gate_failed');assert.equal(call(guard,'register_hypothesis').allow,false);
 assert.equal(call(guard,'stop_insufficient_evidence').allow,true);
}));
test('foreign workspaces, replay, auxiliary slots and other model routes cannot act',()=>{
 for(const bad of [{session:{key:'x',workspaceRoot:'E:/other'}},{...context,replayed:true}]){
  const {guard}=fixture();assert.equal(guard.before_request(model,bad).allow,false);
 }
 const {guard}=fixture();for(const bad of [{slot:'auxiliary',model:'agnes-3.0-flash'},{slot:'primary',model:'other'}])assert.equal(guard.before_request(bad,context).allow,false);
});
test('policy budgets, deadlines and official qualified names cannot widen',()=>{
 for(const changed of [{max_primary_requests:14},{max_model_requests:15},{max_native_title_requests:2},{deadline_epoch_ms:2401001},
  {qualified_action_tool:'mcp_overlong_fake_tool'},{unexpected:true}])assert.throws(()=>createResolutionResearchScopeGuard({...policy,...changed}));
 assert.ok(TOOLS_PREFIX.length<=32);assert.ok(ACTION_TOOL.length<=64);assert.ok(READ_TOOL.length<=64);
});
test('public hooks use transform {}, throwing denial, observe void and actual allow verdict',async()=>{
 const hooks=new Map(),events=[];
 const started=Date.now();
 applyResolutionResearchScope({extension:()=>({registerHook:(name,callback)=>hooks.set(name,callback),
  events:{append:async(kind,payload)=>{events.push({kind,payload});}}})},{...policy,started_epoch_ms:started,deadline_epoch_ms:started+2400000});
 assert.deepEqual([...hooks.keys()].sort(),['before_request','before_step','session_start','tool_call','tool_result']);
 assert.equal(await hooks.get('session_start')({},context),undefined);
 assert.deepEqual(await hooks.get('before_request')(model,context),{});
 const verdict=await hooks.get('tool_call')({name:ACTION_TOOL,toolUseId:'audit',args:{request_id:'fixed',action:'audit_geometry'}},context);
 assert.equal(verdict.allow,true);
 await assert.rejects(()=>hooks.get('before_request')({slot:'auxiliary',model:'agnes-3.0-flash'},context));
 assert.ok(events.some(x=>x.kind==='resolution-scope-ready'));
});
