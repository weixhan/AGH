import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID,createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177',stage=process.argv[2];
if(!['diagnostic','pilot','formal'].includes(stage))throw new Error('Stage argument required');
const out=join(root,'outputs/comparison-suite-v11-'+stage);
const protocol=JSON.parse(await readFile(join(out,'model_protocol.json'),'utf8')),serverId=protocol.server_id;
const sha=b=>createHash('sha256').update(b).digest('hex'),stable=x=>JSON.stringify(x,(_k,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
if(sha(await readFile(protocol.source_lock.path))!==protocol.source_lock.sha256)throw new Error('Deployment lock changed');
for(const item of JSON.parse(await readFile(protocol.source_lock.path,'utf8')).files)if(sha(await readFile(item.path))!==item.sha256)throw new Error('Pinned source changed');
const definition={serverId,displayName:'DefectResearcher three-arm case comparison V1',transport:{kind:'stdio',executable:'E:/Anaconda_envs/envs/MMIOC_env/python.exe',args:['-B',join(root,'run_comparison_mcp_v11.py'),'--config',protocol.server_config,'--source-lock',protocol.source_lock.path,'--expected-lock-sha256',protocol.source_lock.sha256]},secretBinding:{kind:'none'},toolPolicy:{allow:['execute_case_action_v1']}};
const trace={schema_version:1,status:'running',definition,server_id:serverId,steps:[],model_requests:0,credentials_read:false,agh_core_modified:true};
const path=join(out,'mcp_activation.json');await writeFile(path,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});const save=()=>writeFile(path,JSON.stringify(trace,null,2)+'\n');
async function api(route,body){const r=await fetch(origin+'/admin/resources/api/'+route,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});const value=await r.json();if(!r.ok)throw new Error(`${route}: ${r.status} ${JSON.stringify(value)}`);return value;}
let base;
async function effect(route,params){const step={route,params:{...base,commandId:'comparison-v1-'+randomUUID(),...params}};trace.steps.push(step);await save();step.receipt=await api(route,step.params);await save();const deadline=Date.now()+60000;
 for(;;){step.operation=await api('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();if(['succeeded','failed','cancelled'].includes(step.operation.state))break;if(Date.now()>=deadline)throw new Error('Original admin-operation deadline expired');await new Promise(done=>setTimeout(done,400));}
 console.log(JSON.stringify({route,state:step.operation.state,error:step.operation.lastSafeError}));if(step.operation.state!=='succeeded')throw new Error(`${route} failed`);}
try{
 const context=await api('context');if(context.readOnly||context.profile!=='local-dev')throw new Error('Wrong official admin context');base={profile:context.profile,clientId:context.clientId};
 trace.existing_before=await Promise.all(['defect-researcher','dr-workflow-v1'].map(id=>api('mcp/get',{profile:base.profile,serverId:id})));
 if((await api('mcp/list',{profile:base.profile})).items.some(row=>row.serverId===serverId))throw new Error('New comparison server already exists; refusing replacement');
 await effect('mcp/create',{definition});let row=await api('mcp/get',{profile:base.profile,serverId});await effect('mcp/trust',{serverId,expectedRevision:row.revision,trust:'trusted'});
 row=await api('mcp/get',{profile:base.profile,serverId});await effect('mcp/enable',{serverId,expectedRevision:row.revision});await effect('mcp/test',{serverId,expectedRevision:row.revision});
 trace.after=await api('mcp/get',{profile:base.profile,serverId});trace.status_snapshot=await api('mcp/status',{profile:base.profile,serverId});trace.tools=await api('mcp/tools',{profile:base.profile,serverId});
 trace.existing_after=await Promise.all(['defect-researcher','dr-workflow-v1'].map(id=>api('mcp/get',{profile:base.profile,serverId:id})));
 const common=JSON.parse(await readFile(join(out,'protocol.json'),'utf8')).common.tool_catalog;
 const qualified='mcp_'+serverId.replaceAll('-','_')+'_'+sha(Buffer.from(serverId)).slice(0,8)+'_execute_case_action_v1';
 trace.checks={existing_services_preserved:trace.existing_before.every((before,i)=>before.revision===trace.existing_after[i].revision&&stable(before.definition)===stable(trace.existing_after[i].definition)&&trace.existing_after[i].actual==='ready'),new_trusted_ready:trace.after.trust==='trusted'&&trace.after.desired==='enabled'&&trace.after.actual==='ready',exact_one_tool:trace.status_snapshot.toolCount===1&&trace.tools.items.length===1,identical_native_catalog:stable(trace.tools.items)===stable(common),qualified_tool_contract:qualified===protocol.scope_policy.qualified_action_tool,official_operations_succeeded:trace.steps.every(step=>step.operation.state==='succeeded')};
 trace.status=Object.values(trace.checks).every(Boolean)?'passed':'failed';
}catch(error){trace.status='failed';trace.error={type:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,checks:trace.checks,error:trace.error}));}
if(trace.status!=='passed')process.exitCode=1;
