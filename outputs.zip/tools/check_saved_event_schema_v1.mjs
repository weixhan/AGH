import {readFile} from 'node:fs/promises';
import {validateEvent} from '../../agnes-harness/packages/protocol/src/validate.ts';
const record=JSON.parse(await readFile(process.argv[2],'utf8'));
const rejected=(record.sdk_events??[]).flatMap(e=>{const v=validateEvent(e);return v.ok?[]:[{seq:e.seq,type:e.type,errors:v.errors}];});
console.log(JSON.stringify({events:record.sdk_events?.length,rejected}));
