import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {selectBranchDiagnostic} from './comparison_branch_selection_v1.mjs';
function fixture(){
 const trials=Array.from({length:9},(_value,index)=>({trial_handle:'cmp_'+String(index).padStart(32,'0'),arm:'C',case_id:'normal_unrotated'}));
 trials[4]={...trials[4],arm:'F',case_id:'repair_coordinates'};trials[6]={...trials[6],arm:'F',case_id:'refuse_source_hash'};
 const selection={arm:'F',case_ids:['repair_coordinates','refuse_source_hash'],schema_version:1,trial_handles:[trials[4].trial_handle,trials[6].trial_handle]};
 const selection_sha256=createHash('sha256').update(JSON.stringify(selection)).digest('hex');
 return [{trials},{engineering_diagnostic:{selection,selection_sha256,selected_trial_count:2,planned_comparison_trials:9},scope_policy:{allowed_handles:[...selection.trial_handles]},phase_model_budget:{total_cap:48,prior_versions_actual_requests:27,this_pilot_cap:16,phase_remaining_before_diagnostic:21}}];
}
test('only two preregistered F branch positions execute',()=>{const [p,q]=fixture();assert.deepEqual(selectBranchDiagnostic(p,q),[p.trials[4],p.trials[6]]);});
test('unselected or swapped case and arm cannot borrow selection',()=>{for(const key of ['case_id','arm']){const [p,q]=fixture();p.trials[4][key]='U';assert.throws(()=>selectBranchDiagnostic(p,q));}});
test('mutated handles or selection hash are rejected',()=>{const [p,q]=fixture();q.engineering_diagnostic.selection.trial_handles.reverse();assert.throws(()=>selectBranchDiagnostic(p,q));});
test('extra allowed handle is rejected',()=>{const [p,q]=fixture();q.scope_policy.allowed_handles.push(p.trials[0].trial_handle);assert.throws(()=>selectBranchDiagnostic(p,q));});
test('old accounting or enlarged budget is rejected',()=>{for(const key of ['prior_versions_actual_requests','this_pilot_cap','total_cap']){const [p,q]=fixture();q.phase_model_budget[key]++;assert.throws(()=>selectBranchDiagnostic(p,q));}});
