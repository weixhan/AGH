"""Publish a hash-bound interpretation correction without rewriting old evidence."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.audit import _artifact_record, _sha256, _timestamp
from defect_researcher.config import load_config
from defect_researcher.task_runtime import get_task_status
from defect_researcher.stratified_statistics import stratified_statistics


def main():
    config = load_config()
    task = "4b1fa9d234ba4033ba29223c6e5e632e"
    report = get_task_status(config, task)
    if report["status"] != "completed":
        raise ValueError("Source diagnosis is not verified completed")
    task_dir = Path(config["output_root"]) / task
    predictions = Path(config["output_root"]) / report["evidence"]["source_task_id"] / "predictions_640.jsonl"
    sources = [predictions, task_dir / "gt_details.jsonl", task_dir / "fp_details.jsonl",
               task_dir / "diagnosis_summary.json", task_dir / "completion.json", task_dir / "artifact_manifest.json",
               Path(__file__).resolve(), ROOT / "defect_researcher" / "stratified_statistics.py"]
    before = [_artifact_record(p) for p in sources]
    records, gt, fp = [[json.loads(line) for line in p.read_text(encoding="utf-8").splitlines()] for p in sources[:3]]
    corrected = stratified_statistics(records, gt, fp)
    reference = report["summary"]["reference"]["operating_point"]
    for field in ("size_bucket", "region"):
        rows = corrected[field]
        if (sum(r["tp_gt"] for r in rows), sum(r["tp_predictions"] for r in rows), sum(r["fp_predictions"] for r in rows), sum(r["fn_gt"] for r in rows)) != (reference["tp"], reference["tp"], reference["fp"], reference["fn"]):
            raise ValueError("Corrected strata do not preserve the aggregate experiment")
    if [_artifact_record(p) for p in sources] != before:
        raise ValueError("Input changed during interpretation correction")
    output = Path(config["output_root"]) / "diagnosis-stratified-correction"
    output.mkdir(exist_ok=False)
    result = {"status": "completed", "source_diagnosis_task": task, "created_at": _timestamp(),
              "source_evidence": before, "input_hashes_unchanged": True,
              "superseded_fields": ["diagnosis_summary.json/per_size/precision", "diagnosis_summary.json/per_region/precision"],
              "reason": "Legacy TP counts were grouped by GT boxes while FP counts were grouped by prediction boxes; this mixed denominator is not stratum precision.",
              "aggregate_and_branch_unchanged": True, "statistics": corrected}
    path = output / "stratified_statistics.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    artifact = _artifact_record(path)
    (output / "completion.json").write_text(json.dumps({"status": "completed", "source_task_id": task,
        "artifact": artifact, "source_completion_sha256": _sha256(task_dir / "completion.json")}, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "completed", "output": str(path), "aggregate": reference}, ensure_ascii=True))


if __name__ == "__main__":
    main()
