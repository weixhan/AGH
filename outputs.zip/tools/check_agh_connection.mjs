// Query public configuration DTOs and let AGH test its existing account; no key is returned.
import { writeFile } from 'node:fs/promises';
import { webClient } from './agh_ws_client.mjs';

const client = await webClient();
const record = { checked_at: new Date().toISOString(), credential_read: false, config_changed: false };
try {
  const snapshot = await client.config.get();
  const account = snapshot.accounts?.find(row => row.route === 'account-defect-researcher');
  if (!account) throw new Error('The existing Agnes account route was not found');
  record.account = { accountId: account.accountId, providerId: account.providerId, route: account.route,
    baseUrl: account.baseUrl, model: account.model, enabled: account.enabled, credentialConfigured: account.credentialConfigured };
  console.log(JSON.stringify({ account: record.account }));
  const result = await client.config.test({ providerId: account.providerId, accountId: account.accountId,
    baseUrl: account.baseUrl, model: account.model });
  record.test = { verified: result.verified, models: result.models.map(row => row.id) };
  console.log(JSON.stringify(record.test));
} catch (error) {
  record.failure = { type: error.name, code: error.code, reason: error.data?.reason, message: error.message };
  console.log(JSON.stringify({ failure: record.failure }));
  process.exitCode = 1;
} finally {
  await client.close();
  await writeFile('outputs/agh-label-repair/connection-check.json', JSON.stringify(record, null, 2) + '\n');
}
