"""Create fresh stage adapters while preserving all V9 sources and evidence."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def new(name, text):
    with (ROOT / 'tools' / name).open('x', encoding='utf8', newline='\n') as stream:
        stream.write(text)


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Expected one source fragment: ' + before[:80])
    return text.replace(before, after)


def main():
    for name in ('comparison_scope_guard', 'prepare_comparison_scope', 'enable_comparison_scope',
                 'activate_comparison_mcp', 'test_comparison_scope_guard'):
        text = (ROOT / 'tools' / (name + '_v9.mjs')).read_text('utf8')
        text = text.replace('_v9', '_v10').replace('-v9', '-v10')
        if name == 'activate_comparison_mcp':
            text = text.replace('run_comparison_mcp_v10.py', 'run_comparison_mcp_v9.py')
        new(name + '_v10.mjs', text)
    text = (ROOT / 'tools/run_comparison_pilot_v9.mjs').read_text('utf8')
    text = text.replace('_v9', '_v10').replace('-v9', '-v10')
    text = text.replace('run_comparison_mcp_v10.py', 'run_comparison_mcp_v9.py')
    text = text.replace("import {selectBranchDiagnostic} from './comparison_branch_selection_v3.mjs';",
                        "import {selectBranchDiagnostic} from './comparison_branch_selection_v10.mjs';")
    text = replace_once(text, 'const runtimeBefore=await checkRuntime();', '''const runtimeBefore=await checkRuntime();
async function captureRuntime(){
 const result=await run('powershell.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'tools/capture_comparison_runtime_v10.ps1'),'-Manifest',publicProtocol.runtime_version.path],{cwd:root,windowsHide:true,timeout:25000});
 return JSON.parse(result.stdout.replace(/^\\uFEFF/,''));
}''')
    text = replace_once(text, 'model_requests_cap_total:7,phase_model_requests_cap_total:48,prior_closed_request_slots:34,request_slots_debited_before:41',
                        'model_requests_cap_total:14,phase_model_requests_cap_total:14,prior_closed_request_slots:0,request_slots_debited_before:0,historical_prior_slots_debited:46,historical_prior_phase_cap:48')
    text = text.replace('legacy_token_usage_closed:false', 'legacy_token_usage_closed:true,historical_token_usage_closed:false')
    text = replace_once(text, "async function modeled(trial){\n const directory=join(out,'model_runs',trial.trial_handle);await mkdir(directory,{recursive:true});",
                        "async function modeled(trial){\n const directory=join(out,'model_runs',trial.trial_handle);await mkdir(directory,{recursive:true});\n const processBefore=await captureRuntime();")
    text = replace_once(text, " return {trial_id:trial.trial_id,trial_handle:trial.trial_handle,arm:trial.arm,status:record.status,model_requests:record.model_requests_including_title??record.model_request_count+Number(Boolean(record.title_request_event)),record_path:path,session_id:record.session_id};",
                        """ const processAfter=await captureRuntime();
 await writeFile(join(directory,'runtime_binding.json'),JSON.stringify({schema_version:1,runtime_manifest:publicProtocol.runtime_version,build_completed_at:processBefore.build_completed_at,before:processBefore,after:processAfter},null,2)+'\\n',{flag:'wx'});
 return {trial_id:trial.trial_id,trial_handle:trial.trial_handle,arm:trial.arm,status:record.status,model_requests:record.model_requests_including_title??record.model_request_count+Number(Boolean(record.title_request_event)),record_path:path,session_id:record.session_id};""")
    text = replace_once(text, "suite.model_requests_actual+7>7||41+suite.model_requests_actual+7>48",
                        "suite.model_requests_observed+7>14")
    text = replace_once(text, 'suite.model_requests_observed>7', 'suite.model_requests_observed>14')
    text = replace_once(text, "if(verification.status==='passed'&&verification.native_title_cost_known===true&&verification.actual_total_model_requests===suite.model_requests_observed)suite.model_requests_actual=suite.model_requests_observed;",
                        "if(verification.status==='passed'&&verification.native_title_cost_known===true&&verification.actual_total_model_requests===result.model_requests)suite.model_requests_actual=suite.model_requests_observed;")
    text = replace_once(text, "await saveSuite();if(verification.status!=='passed')throw new Error('Independent engineering checks failed');",
                        """await saveSuite();if(verification.status!=='passed')throw new Error('Independent engineering checks failed');
  const runtimeCheck=join(out,'runtime_verification',trial.trial_handle+'.json');
  await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_runtime_v10.py'),dirname(result.record_path),'--output',runtimeCheck],{cwd:root,windowsHide:true,timeout:45000});
  result.runtime_verification_path=runtimeCheck;
  const businessCheck=join(out,'business_verification',trial.trial_handle+'.json');
  await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_case_v1.py'),directory,'--output',businessCheck],{cwd:root,windowsHide:true,timeout:45000});
  result.business_verification_path=businessCheck;await saveSuite();""")
    text = text.replace('suite.unexecuted_comparison_trials=8', 'suite.unexecuted_comparison_trials=7')
    new('run_comparison_pilot_v10.mjs', text)


if __name__ == '__main__':
    main()
