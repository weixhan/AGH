"""Preserve a fresh diagnostic, pilot or formal suite and independently review it.

Engineering validity and business correctness have different denominators. A
business error remains an observed result in a valid comparison. No tool here
arms a trial, resumes a session, requests inference or replaces an old report.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
IDENTITY = ("trial_id", "trial_handle", "case_id", "arm")
STAGES = {"diagnostic": (9, 2, 14), "pilot": (9, 9, 42), "formal": (36, 36, 168)}
BUDGET = {"domain_invocations": 6, "model_requests": 7, "wall_seconds": 120,
          "gpu_seconds": 0, "detector_calls": 0}
V10_FREEZE_SHA256 = "f64917fa17b3411917e73d6409008c6db2c91c7d440811715c9d8cd632e30190"
V12_FAILED_FREEZE_SHA256 = "bba925698631ed07fbb589fff40aaf35bb6dd612745179861242a7e7b3512f15"


def require(condition, message):
    if condition is not True:
        raise ValueError(message)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf8")


def read(path):
    def unique(items):
        value = {}
        for key, item in items:
            require(key not in value, "Duplicate JSON key")
            value[key] = item
        return value
    value = json.loads(Path(path).read_text("utf-8-sig"), object_pairs_hook=unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    def finite(item):
        if type(item) is float:
            return math.isfinite(item)
        if type(item) is dict:
            return all(finite(child) for child in item.values())
        if type(item) is list:
            return all(finite(child) for child in item)
        return True
    require(finite(value), "Overflowing JSON receipt")
    return value


def safe(path, parent=ROOT):
    value = Path(path).absolute()
    for item in (value, *value.parents):
        require(not item.is_symlink() and not (hasattr(item, "is_junction") and item.is_junction()), "Linked evidence path")
    value = value.resolve()
    require(value.is_relative_to(Path(parent).resolve()), "Evidence escaped the owned directory")
    return value


def record(path):
    value = Path(path).resolve()
    require(value.is_file() and not value.is_symlink(), "Evidence file absent or linked")
    raw = value.read_bytes()
    return {"path": str(value), "sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


def bound(pin, *, require_size=True):
    require(type(pin) is dict and {"path", "sha256"} <= set(pin), "Evidence identity missing")
    current = record(pin["path"])
    require(current["sha256"] == pin["sha256"], "Pinned hash changed: " + str(pin["path"]))
    if require_size or "size_bytes" in pin:
        require(type(pin.get("size_bytes")) is int and pin["size_bytes"] == current["size_bytes"],
                "Pinned byte size changed: " + str(pin["path"]))
    return current


def save(path, value):
    destination = safe(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def helper(name, filename):
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / filename)
    require(spec is not None and spec.loader is not None, "Independent checker absent")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def attempt(callback):
    try:
        return callback()
    except Exception as error:
        return {"schema_version": 1, "status": "failed", "errors": [{"type": type(error).__name__, "message": str(error)}]}


def check_history(stage):
    """Fresh hashes and byte sizes over every inventory, including nested freezes."""
    seen, results = set(), []
    def visit(pin, expected_count=None, expected_status=None):
        current = bound(pin)
        if current["path"] in seen:
            return
        seen.add(current["path"])
        value = read(current["path"])
        groups = [name for name in ("sources", "archive", "proof_files", "preserved_files", "files") if name in value]
        count = 0
        for name in groups:
            require(type(value[name]) is list, "Historical inventory population malformed")
            for member in value[name]:
                bound(member)
                count += 1
        if expected_count is not None:
            require(type(expected_count) is int and count == expected_count, "Historical inventory count changed")
        if expected_status is not None:
            require(value.get("status") == expected_status, "Historical outcome changed")
        results.append({"freeze": current, "checked_records": count, "unchanged": True,
                        "original_status_preserved": value.get("status"), "overlap_not_added": True})
        for prior in value.get("protected_history", []):
            pin_value = prior.get("freeze", prior.get("inventory"))
            require(type(pin_value) is dict, "Nested historical pin missing")
            visit(pin_value, prior.get("checked_records"), prior.get("original_status_preserved", prior.get("original_status")))
        for prior in value.get("earlier_comparison_source_pins", []):
            visit(prior["source_lock"], prior.get("checked_records"))
    require(type(stage.get("protected_history")) is list and bool(stage["protected_history"]), "Protected history absent")
    for prior in stage["protected_history"]:
        require(prior.get("unchanged") is True, "Historical preservation receipt failed")
        visit(prior["freeze"], prior.get("checked_records"), prior.get("original_status_preserved"))
    prerequisites = stage.get("prerequisites", {})
    from tools.verify_comparison_model_v14 import check_v13_failed_prerequisite
    check_v13_failed_prerequisite(prerequisites)
    require(type(prerequisites) is dict and "v10_freeze" in prerequisites and "v10_closure" in prerequisites,
            "V10 failed setup prerequisite missing")
    v10 = bound(prerequisites["v10_freeze"])
    require(v10["sha256"] == V10_FREEZE_SHA256, "V10 setup failure pin changed")
    value = read(v10["path"])
    require(value.get("status") == "failed_setup_preserved" and value.get("all_nine_unarmed") is True
            and type(value.get("model_requests_this_diagnostic_actual")) is int
            and value["model_requests_this_diagnostic_actual"] == 0, "V10 setup failure was reclassified")
    visit(prerequisites["v10_freeze"])
    closure = read(bound(prerequisites["v10_closure"])["path"])
    require(closure.get("status") == "passed_preservation_only_not_acceptance", "V10 preservation was changed to acceptance")
    require("v11_setup_freeze" in prerequisites and "v11_setup_closure" in prerequisites,
            "V11 failed setup prerequisite missing")
    v11 = bound(prerequisites["v11_setup_freeze"])
    require(Path(v11["path"]) == ROOT / "outputs/comparison-implementation-v11-diagnostic/freeze.json",
            "V11 setup freeze path differs")
    value = read(v11["path"])
    require(value.get("status") == "failed_setup_preserved" and value.get("all_nine_unarmed") is True
            and type(value.get("model_requests_this_diagnostic_actual")) is int
            and value["model_requests_this_diagnostic_actual"] == 0
            and type(value.get("selected_joint_correct_count")) is int
            and value["selected_joint_correct_count"] == 0
            and value.get("no_original_session_resume") is True, "V11 setup failure was reclassified")
    visit(prerequisites["v11_setup_freeze"])
    v11_closure = bound(prerequisites["v11_setup_closure"])
    require(Path(v11_closure["path"]) == ROOT / "outputs/comparison-suite-v11-diagnostic/final_closure_verification.json",
            "V11 setup closure path differs")
    closure = read(v11_closure["path"])
    require(closure.get("status") == "passed_preservation_only_not_acceptance"
            and closure.get("freeze") == prerequisites["v11_setup_freeze"],
            "V11 preservation was changed to acceptance")
    require("v12_failed_freeze" in prerequisites and "v12_failed_closure" in prerequisites,
            "V12 failed execution prerequisite missing")
    v12 = bound(prerequisites["v12_failed_freeze"])
    require(Path(v12["path"]) == ROOT / "outputs/comparison-implementation-v12-diagnostic/freeze.json"
            and v12["sha256"] == V12_FAILED_FREEZE_SHA256, "V12 failed freeze was replaced")
    value = read(v12["path"])
    require(value.get("status") == "failed_comparison_suite_preserved"
            and value.get("stage") == "diagnostic" and value.get("model_requests_actual") is None
            and type(value.get("selected_joint_correct_count")) is int and value["selected_joint_correct_count"] == 0
            and value.get("no_original_session_resume") is True, "V12 failed execution was reclassified")
    visit(prerequisites["v12_failed_freeze"])
    v12_closure = bound(prerequisites["v12_failed_closure"])
    require(Path(v12_closure["path"]) == ROOT / "outputs/comparison-suite-v12-diagnostic/final_closure_verification.json",
            "V12 failed closure path differs")
    closure = read(v12_closure["path"])
    require(closure.get("status") == "failed" and closure.get("model_costs_closed") is False
            and "model_requests_actual" in closure and closure["model_requests_actual"] is None
            and closure.get("freeze") == prerequisites["v12_failed_freeze"],
            "V12 failure or unknown usage was changed to acceptance")
    for name, pin in prerequisites.items():
        bound(pin)
        if name.endswith("_freeze"):
            visit(pin)
    return results


def selection(protocol, public):
    stage = public.get("stage")
    require(stage in STAGES, "Unknown closure stage")
    population, selected_count, cap = STAGES[stage]
    trials = protocol.get("trials")
    require(type(trials) is list and len(trials) == population
            and len({row["trial_handle"] for row in trials}) == population
            and len({row["trial_id"] for row in trials}) == population,
            "Registered comparison population differs")
    cases = protocol.get("case_ids")
    require(type(cases) is list and len(cases) == population // 3, "Fixed case denominator differs")
    arms = ("C", "U", "F")
    for index, row in enumerate(trials):
        case_index = index // 3
        order = arms[case_index % 3:] + arms[:case_index % 3]
        require(row.get("case_id") == cases[case_index] and row.get("arm") == order[index % 3]
                and row.get("forced_publication_gate") is (row["arm"] == "F"), "Registered rotation/treatment differs")
    expected = [row for row in trials if stage != "diagnostic" or
                (row["arm"] == "F" and row["case_id"] in {"repair_coordinates", "refuse_source_hash"})]
    require(len(expected) == selected_count, "Selected diagnostic/comparison population differs")
    choice = public.get("selection")
    handles = [row["trial_handle"] for row in expected]
    require(choice == {"schema_version": 1, "stage": stage, "trial_handles": handles,
                       "planned_trial_count": population, "selected_trial_count": selected_count}
            and type(choice["schema_version"]) is int
            and type(choice["planned_trial_count"]) is int and type(choice["selected_trial_count"]) is int
            and hashlib.sha256(canonical(choice)).hexdigest() == public.get("selection_sha256"),
            "Public selection differs from registered protocol order")
    require(public["scope_policy"]["allowed_handles"] == [row["trial_handle"] for row in expected if row["arm"] != "C"],
            "Model scope must contain selected U/F only")
    require(protocol["common"]["budget"] == BUDGET
            and all(type(value) is int for value in protocol["common"]["budget"].values())
            and type(public["phase_model_budget"].get("total_cap")) is int
            and public["phase_model_budget"]["total_cap"] == cap, "Common budget is not domain6/model7/120sec")
    return expected


def observed_prefix(selected, reported):
    require(type(reported) is list and len(reported) <= len(selected)
            and all(type(row) is dict for row in reported)
            and [row.get("trial_handle") for row in reported] == [row["trial_handle"] for row in selected[:len(reported)]],
            "Reported executions are not an exact registered prefix")
    return reported + [None] * (len(selected) - len(reported))


def business_reader_valid(business):
    checks = business.get("checks")
    return (business.get("kind") == "independent_comparison_case_evaluation_v1"
            and type(checks) is list and bool(checks)
            and all(type(row) is dict and type(row.get("passed")) is bool for row in checks)
            and not any(row.get("name") == "independent_reader_completed" and row.get("passed") is not True for row in checks)
            and type(business.get("atomic_claims_total")) is int
            and type(business.get("unsupported_atomic_claims")) is int
            and type(business.get("correct_completion")) is bool)


def trial_acceptance(arm, engineering, runtime, business, *, record_status, actual_calls):
    valid = (engineering.get("status") == "passed" and record_status in {"completed", "rejected"}
             and type(actual_calls) is int and 0 <= actual_calls <= (0 if arm == "C" else 7)
             and business_reader_valid(business)
             and (arm == "C" or (runtime.get("status") == "passed" and runtime.get("native_title_usage_closed") is True
                 and runtime.get("actual_total_model_requests") == actual_calls)))
    correct = (valid and business.get("status") == "passed" and business.get("correct_completion") is True
               and business.get("unsupported_atomic_claims") == 0 and business.get("invalid_artifact_accepted") is False)
    return {"execution_valid": valid is True, "joint_correct_completion": correct is True}


def unexecuted(row, pilot, runtime, *, selected):
    handle = row["trial_handle"]
    trial = safe(runtime / "trials" / handle, pilot)
    model = safe(pilot / "model_runs" / handle, pilot)
    scripted = safe(pilot / "script_runs" / handle, pilot)
    artifacts = [name for name in ("arm.json", "arm_binding.json", "actions.jsonl", "budget.jsonl", "publication.json", "completion.json")
                 if (trial / name).exists()]
    dirs = [str(path) for path in (model, scripted) if path.exists()]
    empty = all(path.is_dir() and not any(path.iterdir()) for path in (model, scripted) if path.exists())
    return {**{key: row[key] for key in IDENTITY}, "selected": selected,
            "status": "preexecution_attempt_failed" if selected and dirs and not artifacts and empty else "not_started",
            "execution_artifacts": artifacts, "driver_directories": dirs,
            "no_execution_observed": not artifacts and (not dirs or (selected and empty)),
            "model_requests_actual": None, "joint_correct_completion": False}


def arm_summary(rows, protocol):
    result = {}
    for arm in ("C", "U", "F"):
        group = [row for row in rows if row["arm"] == arm]
        evaluated = [row for row in group if "business" in row]
        counts = [row["business"].get("atomic_claims_total") for row in evaluated]
        unsupported = [row["business"].get("unsupported_atomic_claims") for row in evaluated]
        accepted = [row for row in evaluated if row["business"].get("group_accepted_candidate") is True]
        result[arm] = {"planned_denominator": sum(row["arm"] == arm for row in protocol["trials"]),
            "selected": len(group), "armed": sum(row.get("armed") is True for row in group),
            "valid_executions": sum(row.get("execution_valid") is True for row in group),
            "joint_correct_completion": sum(row.get("joint_correct_completion") is True for row in group),
            "business_incorrect_or_rejected": sum(row["business"].get("correct_completion") is not True for row in evaluated),
            "unsupported_atomic_claims": sum(unsupported) if all(type(value) is int for value in unsupported) else None,
            "atomic_claims_total": sum(counts) if all(type(value) is int for value in counts) else None,
            "accepted_candidate_denominator": len(accepted),
            "invalid_artifact_accepted": sum(row["business"].get("invalid_artifact_accepted") is True for row in accepted),
            "model_requests_actual": sum(row["model_requests_actual"] for row in group)
                if all(type(row.get("model_requests_actual")) is int for row in group) else None}
    return result


def summarize(pilot, protocol, public, suite):
    selected = selection(protocol, public)
    reports = observed_prefix(selected, suite.get("trials"))
    runtime = safe(read(public["server_config"])["output_root"], pilot)
    model_checker = helper("suite_model_closure_v14", "verify_comparison_model_v14.py")
    business_checker = helper("suite_business_closure_v14", "verify_comparison_case_v14.py")
    runtime_checker = helper("suite_runtime_closure_v14", "verify_comparison_runtime_v14.py")
    rows = []
    for trial, reported in zip(selected, reports):
        handle = trial["trial_handle"]
        trial_directory = safe(runtime / "trials" / handle, pilot)
        if reported is None:
            rows.append(unexecuted(trial, pilot, runtime, selected=True))
            continue
        run_directory = safe(pilot / ("script_runs" if trial["arm"] == "C" else "model_runs") / handle, pilot)
        require(safe(reported["record_path"], pilot) == run_directory / "run_result.json", "Reported evidence path differs")
        run = read(run_directory / "run_result.json")
        require(run.get("trial_handle") == handle and reported.get("arm") == trial["arm"], "Reported/run identity differs")
        engineering = attempt(lambda: (model_checker.verify_scripted if trial["arm"] == "C" else model_checker.verify)(run_directory, pilot / "protocol.json"))
        business = attempt(lambda: business_checker.verify(trial_directory))
        runtime_report = {"status": "not_applicable", "reason": "C_has_no_model_session"} if trial["arm"] == "C" else attempt(lambda: runtime_checker.verify(*runtime_checker.load(run_directory)))
        reviews = {"engineering": engineering, "business": business, "runtime": runtime_report}
        match = True
        for kind, review in reviews.items():
            if kind == "runtime" and trial["arm"] == "C":
                continue
            original = pilot / (kind + "_verification") / (handle + ".json")
            original_value = read(original) if original.is_file() else {"status": "missing"}
            match = match and original_value == review
            save(pilot / "closure_reverification" / kind / (handle + ".json"), review)
        actual = 0 if trial["arm"] == "C" and engineering.get("status") == "passed" and engineering.get("model_request_count") == 0 else engineering.get("actual_total_model_requests")
        if trial["arm"] != "C" and engineering.get("native_title_cost_known") is not True:
            actual = None
        accepted = trial_acceptance(trial["arm"], engineering, runtime_report, business, record_status=run.get("status"), actual_calls=actual)
        record_matches = reported.get("status") == run.get("status")
        accepted["execution_valid"] = accepted["execution_valid"] and match and record_matches
        accepted["joint_correct_completion"] = accepted["joint_correct_completion"] and match and record_matches
        rows.append({**{key: trial[key] for key in IDENTITY}, "armed": (trial_directory / "arm.json").is_file(),
            "status": run.get("status"), "driver_status": reported.get("status"), **accepted,
            "original_reviews_replay_exactly": match, "engineering": engineering, "business": business,
            "runtime": runtime_report, "model_requests_actual": actual, "elapsed_seconds": engineering.get("elapsed_seconds"),
            "domain_invocations": engineering.get("domain_invocations"), "run_record": record(run_directory / "run_result.json")})
    chosen = {row["trial_handle"] for row in selected}
    untouched = [unexecuted(trial, pilot, runtime, selected=False) for trial in protocol["trials"] if trial["trial_handle"] not in chosen]
    fairness = all(row["no_execution_observed"] for row in untouched)
    registrations = [read(runtime / "trials" / row["trial_handle"] / "registration.json") for row in protocol["trials"]]
    for case in protocol["case_ids"]:
        group = [row for row in registrations if row["case_id"] == case]
        fairness = fairness and len(group) == 3 and all(row["input_snapshot"] == group[0]["input_snapshot"]
            and row["prepared_case"]["case_root"] == group[0]["prepared_case"]["case_root"] for row in group)
    executed = [row for row in rows if row.get("armed") is True]
    known = bool(executed) and all(type(row.get("model_requests_actual")) is int for row in executed)
    total = sum(row["model_requests_actual"] for row in executed) if known else None
    all_engineering = len(executed) == len(selected) and all(row.get("execution_valid") is True for row in rows)
    all_runtime = len(executed) == len(selected) and all(row["arm"] == "C" or row.get("runtime", {}).get("status") == "passed" for row in rows)
    fair = fairness and all(row.get("no_execution_observed", True) for row in rows if row.get("armed") is not True)
    closed = type(total) is int and total <= STAGES[public["stage"]][2] and type(suite.get("model_requests_actual")) is int and suite["model_requests_actual"] == total
    correct = sum(row.get("joint_correct_completion") is True for row in rows)
    valid = all_engineering and all_runtime and fair and closed
    if public["stage"] == "diagnostic":
        valid = valid and correct == 2
    status = ("passed_branch_diagnostic" if public["stage"] == "diagnostic" else "passed_comparison_suite") if valid else "failed"
    return {"schema_version": 1, "stage": public["stage"], "status": status,
        "planned_trials": len(protocol["trials"]), "selected_trial_count": len(selected),
        "executed_trials": len(executed), "attempted_trials": sum(row.get("armed") is True or row["status"] == "preexecution_attempt_failed" for row in rows),
        "selected_joint_correct_count": correct, "all_trial_engineering_closed": all_engineering,
        "all_model_runtime_verified": all_runtime, "fair_conditions_verified": fair,
        "model_costs_closed": closed, "model_requests_actual": total,
        "selected_results": rows, "unselected": untouched,
        "selected_not_started": [row["trial_handle"] for row in rows if row.get("armed") is not True],
        "failed_or_invalid_executions": [row["trial_handle"] for row in rows if row.get("armed") is True and not row.get("execution_valid")],
        "per_arm": arm_summary(rows, protocol), "business_errors_are_observed_results": True,
        "comparison_complete": public["stage"] != "diagnostic" and len(executed) == len(protocol["trials"]),
        "old_phase_cap": 48, "old_request_slots_debited": 46, "old_phase_actual_usage": None,
        "new_models_this_closure": 0, "new_detector_calls": 0, "gpu_seconds": 0, "recovery_time": "not_measured"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=tuple(STAGES), required=True)
    arguments = parser.parse_args(argv)
    pilot = safe(ROOT / ("outputs/comparison-suite-v14-" + arguments.stage))
    output = safe(ROOT / ("outputs/comparison-implementation-v14-" + arguments.stage))
    require(not (output / "freeze.json").exists(), "Suite already frozen; never overwrite")
    public = read(pilot / "model_protocol.json")
    protocol = read(pilot / "protocol.json")
    require(public.get("stage") == arguments.stage and record(pilot / "protocol.json")["sha256"] == public.get("protocol_sha256"), "Registered stage/protocol changed")
    stage = read(bound(public["stage_ledger"])["path"])
    model_checker = helper("suite_stage_closure_v14", "verify_comparison_model_v14.py")
    model_checker.validate_stage_ledger(stage)
    model_checker.verify_prerequisites(stage, expected_stage=arguments.stage)
    history = check_history(stage)
    source_pin = bound(public["source_lock"], require_size=False)
    sources = read(source_pin["path"])["files"]
    for item in sources:
        bound(item)
    suite = read(pilot / "run_result.json")
    require(suite.get("status") in {"engineering_diagnostic_executed_pending_independent_evaluation", "stopped"},
            "Suite has no terminal driver state")
    acceptance = summarize(pilot, protocol, public, suite)
    save(pilot / "closure_summary.json", acceptance)
    archive_root = safe(output / "source")
    require(not archive_root.exists(), "Source archive already exists")
    archive_root.mkdir()
    archive = []
    for index, item in enumerate(sources):
        path = archive_root / f'{index:03d}_{Path(item["path"]).name}'
        with path.open("xb") as stream:
            stream.write(Path(item["path"]).read_bytes())
        copied = record(path)
        require(copied["sha256"] == item["sha256"] and copied["size_bytes"] == item["size_bytes"], "Source archive differs")
        archive.append({**copied, "source_path": item["path"]})
    candidate = read(pilot / "scope_candidate.json")
    for item in candidate["files"]:
        bound(item)
    proofs = {path.resolve() for path in pilot.rglob("*") if path.is_file()
              and not {"workspace", "__pycache__", "node_modules"}.intersection(path.relative_to(pilot).parts)}
    proofs.update(Path(item["path"]).resolve() for item in candidate["files"])
    proofs.update(path.resolve() for path in output.glob("*.json") if path.name != "freeze.json")
    passed = acceptance["status"] != "failed"
    frozen = {"schema_version": 1,
        "status": ("passed_diagnostic_preserved" if arguments.stage == "diagnostic" else "passed_comparison_suite_preserved") if passed else "failed_comparison_suite_preserved",
        "stage": arguments.stage, "checked_at": datetime.now(timezone.utc).isoformat(),
        "acceptance_status": acceptance["status"], "sources": sources, "archive": archive,
        "source_lock": source_pin, "proof_files": [record(path) for path in sorted(proofs)],
        "protected_history": history, "planned_trials": acceptance["planned_trials"],
        "executed_trials": acceptance["executed_trials"], "selected_joint_correct_count": acceptance["selected_joint_correct_count"],
        "model_requests_actual": acceptance["model_requests_actual"],
        "no_original_session_resume": True, "old_request_slots_debited": 46, "old_actual_usage": None,
        "new_models_this_closure": 0, "new_detector_calls": 0, "gpu_seconds": 0}
    save(output / "freeze.json", frozen)
    checked = 0
    for group in ("sources", "archive", "proof_files"):
        for item in frozen[group]:
            bound(item)
            checked += 1
    require(check_history(stage) == history, "History changed during closure")
    closure = {key: value for key, value in acceptance.items() if key not in {"selected_results", "unselected"}}
    closure.update(freeze=record(output / "freeze.json"), preservation_verified=True,
                   new_records_checked=checked, source_count=len(sources), archive_count=len(archive),
                   proof_count=len(frozen["proof_files"]), protected_history=history)
    save(pilot / "final_closure_verification.json", closure)
    print(json.dumps({key: closure[key] for key in ("status", "stage", "executed_trials", "selected_joint_correct_count", "model_requests_actual", "freeze")}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
