// Record real interaction with the loopback CPU evidence panel; no simulated data.
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';

const argv = process.argv.slice(2);
const option = (key, fallback) => { const i = argv.indexOf(key); return i < 0 ? fallback : argv[i + 1]; };
const output = path.resolve(option('--output', 'outputs/actual-demo-v1/media'));
const address = option('--url', 'http://127.0.0.1:8766');
if (!['127.0.0.1', 'localhost'].includes(new URL(address).hostname)) throw new Error('Only the local evidence panel can be recorded');
const preflight = argv.includes('--preflight');
const require = createRequire(import.meta.url);
const { chromium } = require(option('--playwright-path', 'playwright'));
await fs.mkdir(output, { recursive: false });
const browser = await chromium.launch({
  executablePath: option('--edge', 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'),
  headless: true,
  chromiumSandbox: true,
  args: ['--disable-background-networking', '--disable-component-update', '--disable-default-apps', '--no-first-run'],
});
const context = await browser.newContext({ viewport: { width: 1280, height: 720 }, locale: 'zh-CN',
  ...(preflight ? {} : { recordVideo: { dir: output, size: { width: 1280, height: 720 } } }),
});
await context.route('**/*', route => ['127.0.0.1', 'localhost'].includes(new URL(route.request().url()).hostname) ? route.continue() : route.abort());
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(String(error)));
const events = [];
const started = Date.now();
const log = (event, details = {}) => events.push({ elapsed_seconds: (Date.now() - started) / 1000, event, ...details });
const hash = async file => createHash('sha256').update(await fs.readFile(file)).digest('hex');
async function scene(name) { await page.locator(`[data-scene="${name}"]`).click(); log('actual_scene_click', { scene: name }); }
async function caseView(name) { await page.locator(`[data-case="${name}"]`).click(); await page.waitForFunction(id => document.getElementById('case-title').textContent === id, name); log('actual_case_click', { case_id: name }); }
async function until(seconds) { const remaining = seconds * 1000 - (Date.now() - started); if (remaining > 0) await page.waitForTimeout(remaining); }
await page.goto(address, { waitUntil: 'networkidle' });
await page.screenshot({ path: path.join(output, '01-introduction.png') });
if (preflight) {
  const overview = await page.locator('body').innerText();
  const duplicateIds = await page.evaluate(() => { const ids = [...document.querySelectorAll('[id]')].map(x => x.id); return ids.filter((x, i) => ids.indexOf(x) !== i); });
  if (duplicateIds.length) throw new Error('Duplicate DOM IDs: ' + duplicateIds.join(','));
  await scene('run');
  const bound = await page.locator('#zip-hash').innerText();
  if (!bound.includes('7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61')) throw new Error('Displayed ZIP source does not match');
  await page.screenshot({ path: path.join(output, '02-bound-source.png') });
  if (argv.includes('--check-cases')) {
    await scene('cases');
    if (await page.locator('[data-case]').count() !== 12) throw new Error('Completed real cases not available');
    for (const id of await page.locator('[data-case]').evaluateAll(buttons => buttons.map(x => x.dataset.case))) {
      await caseView(id);
      if (!(await page.locator('#case-checks').innerText()).includes('原输入不变 true')) throw new Error('Original input check not displayed for ' + id);
      await page.screenshot({ path: path.join(output, id + '.png') });
    }
    await scene('verify');
    await page.screenshot({ path: path.join(output, '03-verifier.png') });
    await scene('scope');
    await page.screenshot({ path: path.join(output, '04-scope.png') });
  }
  await context.close(); await browser.close();
  await fs.writeFile(path.join(output, 'preflight.json'), JSON.stringify({ status: errors.length ? 'failed' : 'passed', errors, overview, bound, events }, null, 2));
  console.log(JSON.stringify({ status: errors.length ? 'failed' : 'passed', preflight: output }));
  process.exit(errors.length ? 1 : 0);
}
log('real_browser_recording_started', { url: address, dimensions: '1280x720', audio: false });
await until(30);
await scene('run');
await until(45);
await page.locator('#run-button').click(); log('actual_run_button_click');
await page.waitForFunction(() => document.getElementById('phase').textContent === '实际验收通过', undefined, { timeout: 60000 });
const actual = await page.evaluate(async () => (await fetch('/api/status')).json());
if (actual.phase !== 'passed' || actual.case_outcomes.length !== 12 || actual.actual_repair_cases !== 4 || actual.unintended_modification_cases !== 0) throw new Error('Real CPU run did not meet the frozen criteria');
log('real_cpu_run_passed', { run_id: actual.run_id, actual_elapsed_seconds: actual.elapsed_seconds });
await page.screenshot({ path: path.join(output, '03-actual-result.png') });
await until(85);
await scene('cases'); await caseView('normal_unrotated');
await until(100); await caseView('repair_coordinates');
await page.screenshot({ path: path.join(output, '04-real-coordinate-repair.png') });
await until(120); await caseView('repair_metadata_rotation');
await until(140); await caseView('refuse_source_hash');
await page.screenshot({ path: path.join(output, '05-real-refusal.png') });
await until(155); await caseView('refuse_missing_source');
await until(170); await scene('verify');
await page.screenshot({ path: path.join(output, '06-independent-verification.png') });
await until(185); await page.locator('#checks').scrollIntoViewIfNeeded(); log('actual_evidence_checklist_scroll');
await page.screenshot({ path: path.join(output, '06b-complete-checklist.png') });
await until(205); await scene('scope');
await page.screenshot({ path: path.join(output, '07-scope-and-pending.png') });
await until(240);
const video = page.video();
await context.close();
const videoPath = await video.path();
await browser.close();
const finalPath = path.join(output, 'DefectResearcher-CPU-actual-demo-v1.webm');
await fs.rename(videoPath, finalPath);
await fs.writeFile(path.join(output, 'recording_receipt.json'), JSON.stringify({
  schema_version: 1, kind: 'real_browser_cpu_tool_demonstration_v1', status: errors.length ? 'failed_page_errors' : 'recorded_pending_media_decode_qa',
  video: { path: finalPath, sha256: await hash(finalPath), size_bytes: (await fs.stat(finalPath)).size },
  captured_real_run: actual, events, page_errors: errors, requested_duration_seconds: 240,
  edits: 'No splicing, speed changes, synthetic screenshots, or result substitution; one continuous browser recording.',
  limitations: ['Silent video with readable Chinese UI; no spoken narration.', 'Local CPU panel is a real tool interface, not the AGH UI.',
    'All 12 LabelGuard inputs are fabricated controlled cases; no new model/GPU calls.', 'V12, AGH/GPU/other-computer acceptance, publication and external submission remain pending.'],
}, null, 2));
console.log(JSON.stringify({ status: 'recorded_pending_media_decode_qa', video: finalPath, bytes: (await fs.stat(finalPath)).size, sha256: await hash(finalPath), run_id: actual.run_id }));
