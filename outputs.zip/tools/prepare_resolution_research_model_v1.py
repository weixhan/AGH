"""Prepare a fresh source-pinned model deployment without starting its domain.

Production only reads installed dependency metadata and bytes. It does not call
prepare_task, run an audit, import a detector, contact AGH, or start a worker.
The outer clock is sampled once before preparation; the domain clock belongs to
the later explicit audit_geometry action. Old output directories are refused.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from defect_researcher.config import load_config
from defect_researcher.resolution_recovery_coordinator_v1 import _dependencies, _sources
from defect_researcher.resolution_research_mcp_v1 import REQUIRED_SOURCES

CONTROL_SOURCES = (
    "tools/prepare_resolution_research_model_v1.py",
    "tools/prepare_resolution_research_scope_v1.mjs",
    "tools/enable_resolution_research_scope_v1.mjs",
    "tools/activate_resolution_research_mcp_v1.mjs",
    "tools/resolution_research_deployment_v1.mjs",
    "tools/run_resolution_research_model_v1.mjs",
    "agent/resolution_research_task_v1.md",
    "tests/test_resolution_research_deployment_v1.py",
    "tools/test_resolution_research_deployment_v1.mjs",
    "tools/test_resolution_research_model_v1.mjs",
    "tools/verify_resolution_research_model_v1.py",
    "tools/check_resolution_research_mcp_identity_v1.mjs",
    "tools/agh_ws_client.mjs",
    "tools/agh_ts_loader.mjs",
    "tools/test_resolution_research_scope_guard_v1.mjs",
    "tests/test_resolution_research_mcp_v1.py",
)
PREFIX = "mcp_dr_science_v1_4414bba3_"


def read(path):
    def unique(rows):
        value = {}
        for key, item in rows:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def pin(path):
    path = Path(path).resolve(strict=True)
    if not path.is_file():
        raise ValueError("A regular source file is required")
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": str(path), "sha256": digest.hexdigest(), "size_bytes": path.stat().st_size}


def short_pin(path):
    value = pin(path)
    return {key: value[key] for key in ("path", "sha256")}


def save(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


@dataclass(frozen=True)
class TestDependencies:
    """Explicit local fixtures never produce a production-accepted source lock."""
    root: Path
    configuration: dict
    worker_sources: tuple
    runtime_identity: dict
    clock: object
    fixture_only: bool = True


def prepare(output, request_id, engineering_receipt, runtime_version, *, powershell_executable=None,
            test_dependencies=None):
    fixture = test_dependencies is not None
    if fixture and (type(test_dependencies) is not TestDependencies or test_dependencies.fixture_only is not True):
        raise ValueError("Only explicit fixture dependencies may replace preparation sources")
    root = test_dependencies.root.resolve() if fixture else ROOT
    clock = test_dependencies.clock if fixture else time
    # Round down to millisecond precision: this never grants extra outer time.
    sampled_epoch, sampled_monotonic = clock.time(), clock.monotonic()
    if any(type(x) not in (int, float) or not math.isfinite(x) or x < 0
           for x in (sampled_epoch, sampled_monotonic)):
        raise ValueError("Actual preparation clock is invalid")
    started_ms = math.floor(sampled_epoch * 1000)
    started_epoch, started_monotonic = started_ms / 1000, math.floor(sampled_monotonic * 1000) / 1000
    if type(request_id) is not str or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", request_id) is None:
        raise ValueError("One safe fixed request ID is required")
    output = Path(output).absolute()
    if output.is_symlink() or output.exists():
        raise FileExistsError("Fresh deployment directory required; old records are never replaced")
    parent = output.parent.resolve(strict=True)
    output = parent / output.name
    if not output.is_relative_to(root / "outputs"):
        raise ValueError("Deployment must remain within project outputs")
    receipt_path, runtime_path = Path(engineering_receipt).resolve(strict=True), Path(runtime_version).resolve(strict=True)
    if not receipt_path.is_relative_to(root) or not runtime_path.is_relative_to(root):
        raise ValueError("Project-owned engineering and runtime receipts required")
    engineering, runtime = read(receipt_path), read(runtime_path)
    if (engineering.get("status") != "passed" or type(engineering.get("model_requests")) is not int
            or engineering["model_requests"] != 0 or type(engineering.get("gpu_tasks")) is not int
            or engineering["gpu_tasks"] != 0 or type(engineering.get("tests")) is not list or not engineering["tests"]
            or any(type(row) is not dict or type(row.get("exit_code")) is not int or row["exit_code"] != 0
                   for row in engineering["tests"]) or not fixture and engineering.get("fixture_only") is True):
        raise ValueError("Passed zero-model/zero-GPU engineering test receipt required")
    if runtime.get("status") != "passed_local_repair" or runtime.get("repair_version") != 2:
        raise ValueError("Accepted side-by-side V2 runtime receipt required")
    runtime_files = runtime.get("runtime_files", [])
    if not runtime_files:
        raise ValueError("Runtime source and bundle pins required")
    for row in runtime_files:
        actual = pin(row["path"])
        if any(actual[k] != row[k] for k in ("sha256", "size_bytes")):
            raise ValueError("Tested runtime bytes changed")
        if row.get("archive") and pin(row["archive"])["sha256"] != row["sha256"]:
            raise ValueError("Tested runtime archive changed")
    config = dict(test_dependencies.configuration) if fixture else load_config()
    task_id = "resolution-research-v1-" + request_id
    taskdir = Path(config["output_root"]).resolve() / task_id
    if taskdir.exists():
        raise FileExistsError("Domain task already exists; no new deadline or task replacement")
    if fixture:
        identity = dict(test_dependencies.runtime_identity)
        worker_files = [Path(x) for x in test_dependencies.worker_sources]
    else:
        identity, dependencies = _dependencies()  # metadata/bytes only, no torch import
        worker_files = [Path(row["path"]) for row in _sources(
            {key: Path(value) for key, value in config.items()}, None, dependencies)]
    control_files = [root / relative for relative in (*REQUIRED_SOURCES, *CONTROL_SOURCES)]
    source_files = sorted(set(path.resolve(strict=True) for path in
        [*worker_files, *control_files, receipt_path, runtime_path,
         *(Path(row["path"]) for row in runtime_files)]), key=str)
    source_rows = [pin(path) for path in source_files]
    shell = Path(powershell_executable or shutil.which("pwsh") or "").resolve(strict=True)
    if not shell.is_file():
        raise ValueError("Pinned PowerShell executable required")
    if clock.time() >= started_epoch + 2400 or clock.monotonic() >= started_monotonic + 2400:
        raise RuntimeError("Original preparation deadline expired before publication")
    # All prerequisite/source checks happen before creating any deployment files.
    output.mkdir(exist_ok=False)
    (output / "workspace").mkdir()
    (output / "source").mkdir()
    archives = []
    try:
        for index, row in enumerate(source_rows):
            destination = output / "source" / (str(index).zfill(3) + "_" + Path(row["path"]).name)
            with destination.open("xb") as target, Path(row["path"]).open("rb") as original:
                shutil.copyfileobj(original, target)
            if pin(destination)["sha256"] != row["sha256"] or pin(row["path"]) != row:
                raise ValueError("Source changed during snapshot")
            archives.append({"source": row, "archive": pin(destination)})
        lock_path = output / "source_lock.json"
        save(lock_path, {"schema_version": 1, "kind": "resolution_research_mcp_source_lock_v1",
            "status": "fixture_only" if fixture else "passed_engineering_only", "files": source_rows,
            "engineering_receipt": short_pin(receipt_path), "worker_source_count": len(worker_files),
            "runtime_identity_for_source_discovery": identity,
            "runtime_identity_is_domain_registration": False, "fixture_only": fixture})
        deployment_path = output / "deployment_protocol.json"
        deployment = {"schema_version": 1, "kind": "resolution_research_mcp_deployment_v1",
            "request_id": request_id, "task_id": task_id, "workspace_root": str(output / "workspace"),
            "started_epoch": started_epoch, "started_monotonic": started_monotonic,
            "deadline_epoch": started_epoch + 2400, "deadline_monotonic": started_monotonic + 2400,
            "contract_sha256": pin(root / "fixtures/resolution_research_mcp_protocol_v1.json")["sha256"]}
        save(deployment_path, deployment)
        policy = {"schema_version": 1, "workspace_root": deployment["workspace_root"],
            "request_id": request_id, "task_id": task_id, "started_epoch_ms": started_ms,
            "deadline_epoch_ms": started_ms + 2400000, "qualified_action_tool": PREFIX + "research_action_v1",
            "qualified_read_tool": PREFIX + "research_read_v1", "max_model_requests": 14,
            "max_primary_requests": 13, "max_native_title_requests": 1}
        model_path = output / "model_protocol.json"
        save(model_path, {"schema_version": 1, "kind": "resolution_research_model_protocol_v1",
            "deployment": short_pin(deployment_path), "source_lock": short_pin(lock_path),
            "runtime_version": short_pin(runtime_path),
            "runner_source": short_pin(root / "tools/run_resolution_research_model_v1.mjs"),
            "task_prompt": short_pin(root / "agent/resolution_research_task_v1.md"),
            "scope_policy": policy, "scope_candidate_path": str(output / "scope_candidate.json"),
            "scope_activation_path": str(output / "scope_activation.json"),
            "mcp_activation_path": str(output / "mcp_activation.json"),
            "python_executable": str(Path(sys.executable).resolve()), "powershell_executable": str(shell),
            "model": "agnes-3.0-flash", "route": "account-defect-researcher", "server_id": "dr-science-v1",
            "domain_task_directory": str(taskdir), "output_directory": str(output)})
        if clock.time() >= started_epoch + 2400 or clock.monotonic() >= started_monotonic + 2400:
            raise RuntimeError("Original preparation deadline expired during source snapshot")
        result = {"schema_version": 1, "status": "fixture_only" if fixture else "prepared_not_activated",
            "fixture_only": fixture, "model_protocol": short_pin(model_path), "deployment": short_pin(deployment_path),
            "source_lock": short_pin(lock_path), "sources": archives, "worker_source_count": len(worker_files),
            "sampled_actual_epoch": sampled_epoch, "sampled_actual_monotonic": sampled_monotonic,
            "outer_started_epoch": started_epoch, "outer_deadline_epoch": started_epoch + 2400,
            "domain_clock_started": False, "domain_task_created": taskdir.exists(),
            "prepared_at": datetime.fromtimestamp(clock.time(), timezone.utc).isoformat(),
            "model_requests": 0, "gpu_tasks": 0, "mcp_activated": False, "scope_activated": False}
        save(output / "preparation_receipt.json", result)
        return result
    except Exception as error:
        save(output / "preparation_failure.json", {"status": "failed_preserved", "error_type": type(error).__name__,
             "error": str(error), "domain_clock_started": False, "model_requests": 0, "gpu_tasks": 0})
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--request-id", required=True)
    parser.add_argument("--engineering-receipt", required=True, type=Path)
    parser.add_argument("--runtime-version", type=Path, default=ROOT / "outputs/agh-title-repair-v2/repair_verification.json")
    parser.add_argument("--powershell-executable", type=Path)
    args = parser.parse_args(argv)
    result = prepare(args.output, args.request_id, args.engineering_receipt, args.runtime_version,
                     powershell_executable=args.powershell_executable)
    print(json.dumps({key: result[key] for key in ("status", "model_protocol", "source_lock", "worker_source_count", "domain_clock_started")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
