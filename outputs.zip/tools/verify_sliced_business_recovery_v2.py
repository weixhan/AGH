"""Independent, read-only verification of the two-image recovery experiment.

This module never imports the coordinator, worker, detector, production fusion,
or a scientific scorer. It derives pixel identities, coordinate transforms and
greedy NMS from saved evidence and uses the fixed independent journal reader.
This is a business durability test, with no AP or detection gain calculation.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
TOOL = "verify_sliced_business_recovery_v2"
PURPOSE = "two-image-known-cost-step-recovery-v2"
WEIGHT_SHA = "57d430496f764593b49547897161fbafa93afaca83cc9942a3cc8c2e282d0d75"
IMAGES = ("C01_B01_frame_000030", "C01_B01_frame_000066")
OPTIONS = {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7,
           "max_det": 300, "rect": False, "augment": False,
           "agnostic_nms": False, "quantize": None, "nms": None}
RULES = {"successful_observations": 18, "max_formal_calls": 19,
         "max_failed_pass_retries": 1, "max_warmup_calls": 1,
         "max_gpu_seconds": 60, "max_inference_wall_seconds": 300,
         "max_task_wall_seconds": 300}
FROZEN_PROTOCOL_SHA = "4d6600c3cd5e31a1ce63081c49d6981e8ebc6a0d303c84070943a07279001079"
SOURCE_PATHS = {"defect_researcher/sliced_business_backend_v2.py", "tests/test_sliced_business_backend_v2.py", "defect_researcher/sliced_business_recovery_v2.py", "defect_researcher/sliced_business_worker_v2.py",
    "fixtures/sliced_business_protocol_v2.json", "tools/prepare_sliced_business_protocol_v2.py",
    "tools/verify_sliced_business_recovery_v2.py", "defect_researcher/sliced_worker_v3.py",
    "defect_researcher/sliced_task_v3.py", "defect_researcher/sliced_journal.py",
    "defect_researcher/sliced_inference.py", "defect_researcher/audit.py", "tools/verify_sliced_journal.py",
    "tests/test_sliced_business_protocol_v2.py", "tests/test_sliced_business_worker_v2.py",
    "tests/test_sliced_business_verifier_v2.py", "tests/test_sliced_business_recovery_v2.py"}


class BusinessVerificationError(ValueError):
    """Evidence failed a business recovery check."""


def require(condition, message):
    if not condition:
        raise BusinessVerificationError(message)


def canonical(value, *, legacy=False):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=legacy, allow_nan=False).encode("utf-8")


def sha_object(value, *, legacy=False):
    return hashlib.sha256(canonical(value, legacy=legacy)).hexdigest()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def decode(raw):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    def invalid(value):
        raise BusinessVerificationError("Nonfinite JSON constant")
    try:
        value = json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)
        canonical(value)
        return value
    except (UnicodeError, json.JSONDecodeError, ValueError) as error:
        raise BusinessVerificationError("Invalid, nonfinite or duplicate-key JSON") from error


def read(path):
    return decode(Path(path).read_bytes())


def lines(path):
    result = []
    with Path(path).open("rb") as stream:
        for row in stream:
            require(row.endswith(b"\n") and row.strip(), "Unfinished or empty JSONL row")
            result.append(decode(row))
    return result


def same(left, right, tolerance=0.):
    """Strict types by default; numeric float comparison never uses rtol."""
    if type(left) is not type(right):
        return False
    if type(left) in (int, float):
        return math.isfinite(left) and math.isfinite(right) and abs(left-right) <= tolerance
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(same(left[k], right[k], tolerance) for k in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(same(a, b, tolerance) for a, b in zip(left, right))
    return left == right


def number(value, *, positive=False):
    return (type(value) in (int, float) and math.isfinite(value)
            and (value > 0 if positive else value >= 0))


def options_valid(value):
    return same(value, OPTIONS)


def crops():
    return [[0, 0, 1920, 1080]] + [[x, y, x+640, y+640]
        for y in (0, 440) for x in (0, 512, 1024, 1280)]


def prediction_valid(prediction, width, height):
    require(isinstance(prediction, dict), "Prediction is not an object")
    box = prediction.get("xyxy")
    require(type(prediction.get("class_id")) is int and 0 <= prediction["class_id"] < 7,
            "Prediction class differs from seven-class mapping")
    require(number(prediction.get("confidence"), positive=True)
            and .001 <= prediction["confidence"] <= 1, "Prediction confidence is invalid")
    require(isinstance(box, list) and len(box) == 4 and all(number(v) for v in box)
            and 0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height,
            "Prediction box has invalid area or bounds")


def map_predictions(local, crop, pass_id):
    require(type(pass_id) is int and 0 <= pass_id < 9 and same(crop, crops()[pass_id]),
            "Crop or pass identity differs from fixed grid")
    require(isinstance(local, list) and len(local) <= 300, "Per-pass predictions exceed max_det")
    x, y, right, bottom = crop
    result = []
    for index, prediction in enumerate(local):
        prediction_valid(prediction, right-x, bottom-y)
        box = prediction["xyxy"]
        # The production contract stores coordinates as floats, without rounding.
        local_box = list(map(float, box))
        result.append({"pass_id": pass_id, "prediction_index": index, "crop": crop,
            "local_xyxy": local_box, "xyxy": [local_box[0]+x, local_box[1]+y,
                local_box[2]+x, local_box[3]+y], "class_id": prediction["class_id"],
            "confidence": float(prediction["confidence"])})
    return result


def iou(left, right):
    intersection = max(0., min(left[2], right[2])-max(left[0], right[0])) * max(
        0., min(left[3], right[3])-max(left[1], right[1]))
    union = (left[2]-left[0])*(left[3]-left[1]) + (right[2]-right[0])*(right[3]-right[1])-intersection
    require(number(union, positive=True), "Nonpositive or nonfinite IoU union")
    return intersection/union


def fusion_trace(observations):
    """Full same-class greedy NMS before max_det, including every disposition."""
    candidates, seen = [], set()
    for observed in observations:
        expected = map_predictions(observed["local_predictions"], observed["crop"], observed["pass_id"])
        require(same(observed.get("global_predictions"), expected), "Local/global mapping differs")
        for candidate in expected:
            key = candidate["pass_id"], candidate["prediction_index"]
            require(key not in seen, "Duplicate candidate identity")
            seen.add(key)
            candidates.append(candidate)
    candidates.sort(key=lambda p: (-p["confidence"], p["pass_id"], p["prediction_index"]))
    survivors, rows = [], []
    for rank, candidate in enumerate(candidates):
        suppressor, overlap = None, None
        for prior in survivors:
            if prior["class_id"] == candidate["class_id"]:
                value = iou(prior["xyxy"], candidate["xyxy"])
                if value > .7:
                    suppressor, overlap = prior, value
                    break
        row = {**candidate, "candidate_rank": rank, "status": "suppressed_iou",
            "suppressed_by": None, "suppression_iou": overlap, "final_prediction_index": None}
        if suppressor is not None:
            row["suppressed_by"] = {"pass_id": suppressor["pass_id"],
                                    "prediction_index": suppressor["prediction_index"]}
        else:
            row["status"] = "kept" if len(survivors) < 300 else "global_max_det"
            if len(survivors) < 300:
                row["final_prediction_index"] = len(survivors)
            survivors.append(candidate)
        rows.append(row)
    predictions = [{key: row[key] for key in ("class_id", "confidence", "xyxy")}
                   for row in survivors[:300]]
    return predictions, {"schema_version": "fixed-nine-pass-fusion-trace-v1",
        "nms_iou": .7, "suppression_comparator": ">", "global_max_det": 300,
        "confidence_ties": "pass_id_then_original_prediction_index",
        "candidate_count": len(candidates), "nms_survivor_count": len(survivors),
        "suppressed_count": len(candidates)-len(survivors),
        "global_max_det_discarded_count": max(0, len(survivors)-300),
        "final_count": len(predictions), "rows": rows}


def predictions_equal(left, right):
    """Preserve count/order/classes; absolute conf 1e-6/coords 1e-4 only."""
    if not isinstance(left, list) or not isinstance(right, list) or len(left) != len(right):
        return False
    for a, b in zip(left, right):
        if (type(a.get("class_id")) is not int or type(b.get("class_id")) is not int
                or a["class_id"] != b["class_id"] or not number(a.get("confidence"))
                or not number(b.get("confidence")) or abs(a["confidence"]-b["confidence"]) > 1e-6):
            return False
        boxes = a.get("xyxy"), b.get("xyxy")
        if (not all(isinstance(box, list) and len(box) == 4 for box in boxes)
                or not all(number(x) and number(y) and abs(x-y) <= 1e-4 for x, y in zip(*boxes))):
            return False
    return True


def safe_file(path, roots):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), "Evidence file absent or linked")
    resolved = path.resolve()
    require(any(resolved.is_relative_to(Path(root).resolve()) for root in roots), "Evidence escaped approved roots")
    return resolved


def fresh_files(rows, roots):
    require(isinstance(rows, list) and bool(rows), "Empty frozen file population")
    result = {}
    for row in rows:
        require(isinstance(row, dict) and isinstance(row.get("path"), str)
                and re.fullmatch(r"[0-9a-f]{64}", row.get("sha256", ""))
                and type(row.get("size_bytes")) is int and row["size_bytes"] >= 0,
                "Invalid frozen file record")
        # Empty normal labels are valid preregistered bytes.
        path = safe_file(row["path"], roots)
        observed = (digest(path), path.stat().st_size)
        require(observed == (row["sha256"], row["size_bytes"]), f"Frozen file bytes changed: {path.name}")
        if str(path) in result:
            require(result[str(path)] == observed, "Duplicate file identity disagrees")
        result[str(path)] = observed
    return result


def source_identity(rows):
    require(isinstance(rows, list) and bool(rows), "Execution source list is absent")
    mapped = []
    seen = set()
    for row in rows:
        path = safe_file(row["path"], [ROOT])
        relative = path.relative_to(ROOT).as_posix()
        require(relative not in seen and not relative.startswith("outputs/"), "Duplicate or saved-path execution source")
        seen.add(relative)
        mapped.append({"path": relative, "sha256": row["sha256"]})
    require(seen == SOURCE_PATHS, "Fixed source population differs or untrusted source was added")
    return sha_object(sorted(mapped, key=lambda row: row["path"]))


def decoded_pixels(registration):
    """Derive all eighteen original BGR crop identities from current bytes."""
    import cv2
    import numpy as np
    records = registration.get("records")
    require(isinstance(records, list) and [row.get("image_id") for row in records] == list(IMAGES),
            "Preregistered two-image ordering differs")
    result = []
    for record in records:
        require(record.get("width") == 1920 and record.get("height") == 1080
                and record.get("split") == "val", "Image dimensions or split differ")
        path = safe_file(record["image_path"], [registration["configuration"]["dataset_root"]])
        source = digest(path)
        array = cv2.imread(str(path), cv2.IMREAD_COLOR)
        require(array is not None and array.dtype == np.uint8 and list(array.shape) == [1080, 1920, 3],
                "Decoded BGR image shape/dtype differs")
        whole = hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()
        for pass_id, crop in enumerate(crops()):
            x, y, right, bottom = crop
            tile = hashlib.sha256(np.ascontiguousarray(array[y:bottom, x:right]).tobytes()).hexdigest()
            result.append({"image_id": record["image_id"], "pass_id": pass_id, "crop": crop,
                "source_image_sha256": source, "decoded_image_sha256": whole, "input_pixels_sha256": tile})
    require(same(result, registration.get("pixel_inputs")), "Registered source or crop pixels differ")
    return result


def selection_bound(registration, protocol):
    files = registration["input_files"]
    by_sha = {}
    for row in files:
        by_sha.setdefault(row["sha256"], []).append(Path(row["path"]))
    expected = protocol["preregistered_inputs"]
    require(all(value in by_sha for value in expected.values()) and WEIGHT_SHA in by_sha,
            "Preregistered inputs or fixed weight is missing")
    source = lines(by_sha[expected["source_predictions"]][0])
    members = [row["image_id"] for row in source]
    require(len(members) == len(set(members)) == 640, "Frozen validation membership is not unique640")
    normal = sorted(row["image_id"] for row in source if not row["ground_truth"])
    anomalous = sorted(row["image_id"] for row in source if row["ground_truth"])
    require(normal and anomalous and sorted([normal[0], anomalous[0]]) == list(IMAGES),
            "Samples do not follow preregistered lexical GT-only selection")
    val = [line.strip() for line in by_sha[expected["val_members"]][0].read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    require(len(val) == 640 and len({Path(path).stem for path in val}) == 640
            and {Path(path).stem for path in val} == set(members), "Validation member evidence differs")
    selected = {row["image_id"]: row for row in source if row["image_id"] in IMAGES}
    for record in registration["records"]:
        require(same(record, selected[record["image_id"]]), "Selected baseline record has changed")
        for suffix, field in (("image", "image_path"), ("label", "label_path"), ("metadata", "metadata_path")):
            require(digest(record[field]) == expected[f'{record["image_id"]}/{suffix}'], "Selected input hash differs")
    return True


def environment_valid(environment, reference):
    required = {"device": "0", "precision": "FP32", "actual_input_dtype": "torch.float32",
        "actual_input_device": "cuda:0", "model_parameters_dtype": "torch.float32",
        "tf32_matmul": False, "tf32_cudnn": False, "cudnn_benchmark": False,
        "cudnn_deterministic": True, "actual_predictor_fp16": False,
        "actual_predictor_imgsz": [640, 640], "actual_predictor_device": "cuda:0"}
    require(all(same(environment.get(k), v) for k, v in required.items()), "Actual FP32/CUDA controls differ")
    require(options_valid(environment.get("actual_predictor_options"))
            and options_valid(reference.get("actual_predictor_options")), "Explicit null external NMS options differ")
    for key in ("python", "python_executable", "torch", "ultralytics", "cuda", "cudnn", "gpu_name", "gpu_total_bytes"):
        require(key in environment and same(environment[key], reference.get(key)), "Sealed dependency/backend differs")
    return sha_object({k: v for k, v in environment.items() if k != "peak_allocated_bytes"}, legacy=True)


def callable_sources_valid(environment, input_files):
    expected = {"YOLO.predict": "engine/model.py", "BasePredictor.pre_transform": "engine/predictor.py",
        "BasePredictor.preprocess": "engine/predictor.py", "BasePredictor.setup_source": "engine/predictor.py",
        "BasePredictor.inference": "engine/predictor.py", "DetectionPredictor.postprocess": "models/yolo/detect/predict.py",
        "scale_boxes": "utils/ops.py", "NMS": "utils/nms.py"}
    sources = environment.get("callable_sources")
    require(isinstance(sources, dict) and sources.keys() == expected.keys(), "Real predictor callable source population differs")
    registered = {str(Path(row["path"]).resolve()): row for row in input_files}
    for name, suffix in expected.items():
        row = sources[name]
        path = Path(row.get("path", "")).resolve()
        require(path.as_posix().endswith("/ultralytics/"+suffix) and str(path) in registered,
                "Actual predictor callable source is not registered")
        require(row.get("sha256") == registered[str(path)]["sha256"] == digest(path)
                and row.get("size_bytes") == registered[str(path)]["size_bytes"] == path.stat().st_size,
                "Actual predictor callable source bytes differ")
    return True


def monotonic_segments_valid(budget, expected_count):
    segments = budget.get("wall_segments")
    require(isinstance(segments, list) and len(segments) == expected_count, "Monotonic clock segment population differs")
    last_task, last_inference, last_finished = 0., 0., None
    for row in segments:
        require(isinstance(row, dict) and row.keys() == {"utc_started", "utc_finished", "task_wall_seconds_before",
            "inference_wall_seconds_before", "monotonic_task_seconds", "monotonic_inference_seconds"},
            "Monotonic clock segment fields differ")
        require(all(number(row.get(key)) for key in ("task_wall_seconds_before", "inference_wall_seconds_before",
            "monotonic_task_seconds", "monotonic_inference_seconds")), "Monotonic segment cost is unknown")
        started, finished = datetime.fromisoformat(row["utc_started"]), datetime.fromisoformat(row["utc_finished"])
        require(started.tzinfo is not None and finished.tzinfo is not None and finished >= started
                and (last_finished is None or started >= last_finished), "Unclosed or overlapping monotonic segment")
        require(row["task_wall_seconds_before"]+.05 >= last_task
                and row["inference_wall_seconds_before"]+.05 >= last_inference
                and row["monotonic_inference_seconds"] <= row["monotonic_task_seconds"]+.05,
                "Prior monotonic costs were reset or inference exceeds task time")
        last_task = row["task_wall_seconds_before"]+row["monotonic_task_seconds"]
        last_inference = row["inference_wall_seconds_before"]+row["monotonic_inference_seconds"]
        last_finished = finished
    require(budget["task_wall_seconds"]+.05 >= last_task
            and budget["inference_wall_seconds"]+.05 >= last_inference, "Final cumulative clock hides monotonic segment cost")
    return True


def observation_controls(value):
    require(options_valid(value.get("effective_options")), "Observation effective options differ")
    for key, expected in {"device": "cuda:0", "precision": "FP32", "actual_input_dtype": "torch.float32",
        "actual_input_device": "cuda:0", "model_parameters_dtype": "torch.float32"}.items():
        require(same(value.get(key), expected), "Observation actual tensor/device controls differ")
    speed = value.get("ultralytics_speed_ms")
    require(isinstance(speed, dict) and speed.keys() == {"preprocess", "inference", "postprocess"}
            and all(number(v) for v in speed.values()), "Per-stage speed evidence is absent")


def observations_valid(observations, pixels, identity, environment_id, *, count=18):
    require(isinstance(observations, list) and len(observations) == count,
            "Observation population is incomplete or excessive")
    expected = pixels[:count]
    for row, fixed in zip(observations, expected):
        require(all(same(row.get(key), value) for key, value in fixed.items()), "Observation input/pixel identity differs")
        require(row.get("environment_identity") == environment_id
                and all(row.get(key) == identity[key] for key in ("protocol_sha256", "weight_sha256", "scientific_inputs_sha256")),
                "Observation environment/source identity differs")
        require(type(row.get("image_index")) is int and row["image_index"] == IMAGES.index(row["image_id"]),
                "Observation image index differs from preregistered order")
        observation_controls(row)
        x, y, right, bottom = fixed["crop"]
        require(same(row.get("orig_shape"), [bottom-y, right-x]), "Observation original shape differs")
        require(number(row.get("elapsed_seconds"), positive=True) and number(row.get("gpu_seconds"))
                and row["gpu_seconds"] <= row["elapsed_seconds"]+.05, "Observation cost is unknown or invalid")
        require(same(row.get("global_predictions"), map_predictions(row.get("local_predictions"), fixed["crop"], fixed["pass_id"])),
                "Observation mapping is incomplete or changed")
    return True


def journal_reader():
    path = ROOT / "tools" / "verify_sliced_journal.py"
    spec = importlib.util.spec_from_file_location("independent_business_durability", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def arm_fusion(directory, observations, registration):
    predicted, details = lines(directory / "predictions_sliced.jsonl"), lines(directory / "fusion_details.jsonl")
    require([row.get("image_id") for row in predicted] == list(IMAGES)
            and [row.get("image_id") for row in details] == list(IMAGES), "Fusion image order or population differs")
    for index, image in enumerate(IMAGES):
        rows = [row for row in observations if row["image_id"] == image]
        predictions, trace = fusion_trace(rows)
        require(same(predicted[index].get("predictions"), predictions), "Saved fusion predictions differ")
        require(same(details[index].get("trace"), trace, 1e-12)
                and details[index].get("candidate_count") == trace["candidate_count"]
                and details[index].get("final_count") == trace["final_count"], "Full fusion disposition trace differs")
        for key, value in registration["records"][index].items():
            if key != "predictions":
                require(same(predicted[index].get(key), value), "Fused record changed original input/GT")
    return predicted


def tree_snapshot(directory):
    require(directory.is_dir() and not directory.is_symlink(), "Closed fault directory is absent or linked")
    result = []
    for path in sorted(directory.rglob("*")):
        require(not path.is_symlink(), "Closed fault tree contains linked evidence")
        if path.is_file():
            result.append({"path": path.relative_to(directory).as_posix(), "sha256": digest(path), "size_bytes": path.stat().st_size})
    return result


def verify_shared(directory, coordinator, budgets, identity):
    """Replay independent cross-arm accounting with a single hard budget."""
    events = lines(directory / "shared_journal.jsonl")
    require(len(events) == 78, "Expected exactly39 paired outer predict events")
    expected_calls = [("control", "warmup", IMAGES[0], 0, 1)]
    expected_calls += [("control", "formal", image, pass_id, i+1)
        for i, (image, pass_id) in enumerate((image, pass_id) for image in IMAGES for pass_id in range(9))]
    expected_calls += [("fault", "warmup", IMAGES[0], 0, 1)]
    expected_calls += [("fault", "formal", IMAGES[0], pass_id, pass_id+1) for pass_id in range(3)]
    missing = [(image, pass_id) for image in IMAGES for pass_id in range(9)][2:]
    expected_calls += [("resume", "formal", image, pass_id, i+4)
                      for i, (image, pass_id) in enumerate(missing)]
    head, prior_epoch, prior_elapsed, gpu, active = "0"*64, coordinator["start_epoch"], 0., 0., None
    completed = []
    for event_seq, row in enumerate(events, 1):
        require(isinstance(row, dict) and row.keys() == {"schema_version", "event_seq", "event_type",
            "previous_event_sha256", "event_sha256", "payload"}, "Shared journal fields differ")
        require(type(row["schema_version"]) is int and row["schema_version"] == 1
                and type(row["event_seq"]) is int and row["event_seq"] == event_seq
                and row["previous_event_sha256"] == head
                and row["event_sha256"] == sha_object({k: v for k, v in row.items() if k != "event_sha256"}),
                "Shared journal sequence or hash chain differs")
        payload = row["payload"]
        require(isinstance(payload, dict), "Shared journal payload is absent")
        call_id = (event_seq+1)//2
        expected = expected_calls[call_id-1]
        require(type(payload.get("shared_call_index")) is int and payload["shared_call_index"] == call_id
                and (payload.get("arm"), payload.get("kind"), payload.get("image_id"), payload.get("pass_id"),
                     payload.get("local_call_index")) == expected
                and type(payload.get("pass_id")) is int and type(payload.get("local_call_index")) is int,
                "Shared outer call population, ordering or cache reuse differs")
        require(all(payload.get(key) == value for key, value in identity.items()), "Shared experiment/source identity differs")
        epoch, elapsed = payload.get("utc_epoch"), payload.get("elapsed_seconds")
        require(number(epoch) and number(elapsed) and epoch >= prior_epoch and elapsed >= prior_elapsed
                and coordinator["start_epoch"] <= epoch <= coordinator["deadline_epoch"]
                and elapsed <= 300 and elapsed+.05 >= epoch-coordinator["start_epoch"],
                "Shared wall cost decreased or exceeded hard deadline")
        if event_seq % 2:
            require(row["event_type"] == "started" and active is None and gpu < 60
                    and elapsed < 300 and call_id <= 40, "Call started with open/expired shared budget")
            active = payload
        else:
            require(row["event_type"] == "finished" and active is not None,
                    "Shared finish lacks start")
            attempt = payload.get("attempt")
            arm, kind, image, pass_id, local_index = expected
            actual = budgets[arm][f"{kind}_attempts"][local_index-1]
            require(same(attempt, actual), "Shared closed cost/call differs from independently replayed arm")
            require(number(attempt.get("elapsed_seconds"), positive=True) and number(attempt.get("gpu_seconds"))
                    and attempt["gpu_seconds"] <= attempt["elapsed_seconds"]+.05,
                    "Shared GPU/elapsed cost is unknown")
            gpu += attempt["gpu_seconds"]
            require(gpu <= 60, "Shared cumulative GPU cost exceeded")
            started = datetime.fromisoformat(attempt["utc_started"]).timestamp()
            finished = datetime.fromisoformat(attempt["utc_finished"]).timestamp()
            # The local wrapper timestamp is captured immediately before the
            # shared reservation. The durable reservation and local started row
            # both precede predict, as established by their source-bound writer.
            require(coordinator["start_epoch"] <= started <= active["utc_epoch"]+.05
                    and epoch+.05 >= finished and finished <= coordinator["deadline_epoch"],
                    "Actual call is outside original shared recorded interval")
            completed.append({"shared_call_index": call_id, "arm": arm, "kind": kind,
                "image_id": image, "pass_id": pass_id, "local_call_index": local_index,
                "gpu_seconds": attempt["gpu_seconds"], "elapsed_seconds": attempt["elapsed_seconds"],
                "status": attempt["status"]})
            active = None
        head, prior_epoch, prior_elapsed = row["event_sha256"], epoch, elapsed
    require(active is None and len(completed) == 39, "Shared call remains open")
    combined = budgets["control"]["gpu_seconds"] + budgets["resume"]["gpu_seconds"]
    require(math.isclose(gpu, combined, rel_tol=0, abs_tol=1e-10), "Shared cost differs from both cumulative arm costs")
    return {"detector_calls": 39, "formal_calls": 37, "warmup_calls": 2,
            "gpu_seconds": gpu, "last_elapsed_seconds": prior_elapsed,
            "last_event_epoch": prior_epoch, "journal_sha256": head,
            "callmap": completed}


def fault_valid(directory, protocol, identity, experiment_id, fault_budget):
    row = read(directory / "fault.json")
    expected = {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE,
        "experiment_id": experiment_id, "arm": "fault", "image_id": IMAGES[0],
        "pass_id": 2, "call_index": 3, "shared_call_index": 23,
        "boundary": "after_predict_closed_cost_before_passed",
        "fault_rule_sha256": sha_object(protocol["fault"]), **identity}
    require(all(same(row.get(key), value) for key, value in expected.items()), "Frozen fault rule, position or source differs")
    predicted = row.get("prediction_output")
    require(isinstance(predicted, dict) and row.get("output_sha256") == sha_object(predicted),
            "Returned real prediction evidence hash differs")
    observation_controls(predicted)
    require(same(predicted.get("orig_shape"), [640, 640]), "Injected output shape differs")
    map_predictions(predicted.get("local_predictions"), crops()[2], 2)
    failed = fault_budget["formal_attempts"][-1]
    require(same(row.get("timing"), {k: failed[k] for k in ("elapsed_seconds", "gpu_seconds")})
            and number(failed.get("elapsed_seconds"), positive=True) and number(failed.get("gpu_seconds")),
            "Injected predict cost was not fully closed")
    require(same(failed.get("error"), {"type": "InjectedBusinessFault",
        "message": "Fixed business fault after known-cost prediction, before observation commit"}),
        "Fault closure lacks fixed injected-failure reason")
    stamp = datetime.fromisoformat(row["utc_triggered"])
    require(stamp.tzinfo is not None and datetime.fromisoformat(failed["utc_started"]) <= stamp
            <= datetime.fromisoformat(failed["utc_finished"]), "Fault did not occur within predict wrapper")
    return row


def publication_valid(directory):
    require(not (directory / "failure.json").exists()
            and not (directory / "completion_rejected.json").exists(),
            "Passed root has a failure or rejected marker")
    marker = read(directory / "completion.json")
    manifest = read(directory / "artifact_manifest.json")
    coordinator = read(directory / "coordinator.json")
    require(marker.get("status") == "passed" and marker.get("tool") == TOOL
            and marker.get("purpose") == PURPOSE and manifest.get("schema_version") == 1,
            "Publication tool/status differs")
    require(marker.get("artifact_manifest_sha256") == digest(directory / "artifact_manifest.json"),
            "Completion manifest binding differs")
    files = manifest.get("files")
    require(isinstance(files, list) and bool(files), "Completion artifact inventory absent")
    names = set()
    hashes = {}
    for row in files:
        name = row.get("path")
        require(isinstance(name, str) and name not in names and not Path(name).is_absolute()
                and ".." not in Path(name).parts, "Unsafe or duplicate publication file")
        names.add(name)
        path = safe_file(directory / name, [directory])
        require(path == (directory/name).resolve() and row.get("sha256") == digest(path)
                and row.get("size_bytes") == path.stat().st_size, "Published artifact bytes differ")
        hashes[name] = row["sha256"]
    required = {"protocol.json", "input_manifest.json", "implementation_freeze.json", "coordinator.json",
                "shared_journal.jsonl", "business_result.json", "independent_verification.json", "completion_candidate.json"}
    require(required <= names, "Completion inventory is incomplete")
    candidate = read(directory / "completion_candidate.json")
    require(candidate.get("tool") == TOOL and candidate.get("status") == "passed"
            and candidate.get("purpose") == PURPOSE, "Completion candidate differs")
    independent = read(directory / "independent_verification.json")
    require(independent.get("status") == "passed" and isinstance(independent.get("checks"), dict)
            and bool(independent["checks"]) and all(v is True for v in independent["checks"].values()),
            "Published independent verification failed")
    require(marker.get("completion_candidate_sha256") == digest(directory / "completion_candidate.json")
            and marker.get("business_result_sha256") == candidate.get("business_result_sha256") == digest(directory / "business_result.json")
            and marker.get("independent_verification_sha256") == candidate.get("independent_verification_sha256") == digest(directory / "independent_verification.json")
            and marker.get("experiment_id") == manifest.get("experiment_id") == candidate.get("experiment_id") == directory.name,
            "Completion candidate/result/review or experiment binding differs")
    result = read(directory / "business_result.json")
    require(marker.get("detector_calls") == candidate.get("detector_calls") == result.get("detector_calls") == 39
            and same(marker.get("gpu_seconds"), candidate.get("gpu_seconds"))
            and same(marker.get("gpu_seconds"), result.get("gpu_seconds"))
            and marker.get("real_detector_used") is candidate.get("real_detector_used") is result.get("real_detector_used")
            and number(candidate.get("elapsed_seconds")) and number(marker.get("elapsed_seconds"))
            and result["elapsed_seconds_at_review"] <= candidate["elapsed_seconds"] <= marker["elapsed_seconds"] <= 300,
            "Completion/candidate reviewed counts, costs, mode or cumulative time differ")
    actual_names = {row["path"] for row in tree_snapshot(directory)} - {"completion.json", "artifact_manifest.json", "coordinator.log"}
    require(actual_names == names, "Publication inventory omits or adds artifact files")
    marker_ns = (directory / "completion.json").stat().st_mtime_ns
    require(all(marker_ns >= (directory/name).stat().st_mtime_ns for name in names | {"artifact_manifest.json"}),
            "Completion marker was not published last")
    require(number(coordinator.get("deadline_epoch")) and marker_ns/1e9 <= coordinator["deadline_epoch"],
            "Actual completion file publication exceeded original shared deadline")
    return True


def preserved_rows(protocol):
    before = read(ROOT / "outputs/sliced-runner-v3-fix/preservation_before.json")
    frozen = read(ROOT / "outputs/sliced-runner-implementation-v3/freeze.json")
    result = {}
    for row in before["files"] + frozen["files"]:
        path = Path(row["path"])
        if not path.is_absolute():
            path = ROOT / path
        value = {"path": str(path.resolve()), "sha256": row["sha256"], "size_bytes": row["size_bytes"]}
        if value["path"] in result:
            require(same(result[value["path"]], value), "Protected history identities conflict")
        result[value["path"]] = value
    require(len(result) == 39, "Protected historical file population differs")
    for relative, expected in protocol["additional_preserved_sha256"].items():
        path = safe_file(ROOT / relative, [ROOT])
        require(digest(path) == expected, "V1 failed trial or source bytes changed")
        value = {"path": str(path), "sha256": expected, "size_bytes": path.stat().st_size}
        if value["path"] in result:
            require(same(result[value["path"]], value), "V1 preservation identity conflicts")
        result[value["path"]] = value
    prior = ROOT / "outputs" / protocol["prior_trial"]["experiment_id"]
    require(read(prior / "failure.json").get("status") == "failed" and not (prior / "completion.json").exists(),
            "V1 real failure was retroactively completed")
    return sorted(result.values(), key=lambda row: row["path"])


def review(directory, *, prepublication=True, now_epoch=None):
    """Read current bytes, replay both arms, and return typed independent gates.

    No files are written by this function. The caller writes its report and can
    publish a success marker only after this review and its remaining deadline.
    """
    started = time.perf_counter()
    directory = Path(directory).resolve()
    checks, evidence, failure = {}, {}, None
    def checked(name, value=True):
        checks[name] = value is True
        require(checks[name], name)
    try:
        require(directory.parent == (ROOT / "outputs").resolve() and directory.is_dir()
                and not directory.is_symlink(), "Experiment directory is outside trusted outputs")
        checked("trusted_distinct_experiment_directory")
        protocol_path = safe_file(directory / "protocol.json", [directory])
        fixed_path = safe_file(ROOT / "fixtures/sliced_business_protocol_v2.json", [ROOT])
        checked("original_fixed_purpose_recipe_bytes", digest(protocol_path) == digest(fixed_path) == FROZEN_PROTOCOL_SHA)
        protocol = read(protocol_path)
        checked("strict_typed_business_protocol_and_external_nms_null",
            same(protocol.get("budgets"), RULES) and protocol.get("nms") is None and "nms" in protocol
            and type(protocol.get("schema_version")) is int and protocol["schema_version"] == 1
            and type(protocol.get("execution_version")) is int and protocol["execution_version"] == 2
            and protocol.get("purpose") == PURPOSE and protocol.get("tool") == TOOL)
        registration = read(directory / "input_manifest.json")
        freeze, coordinator = read(directory / "implementation_freeze.json"), read(directory / "coordinator.json")
        checked("registration_purpose_and_zero_preparation_detector_claims",
            registration.get("tool") == TOOL and registration.get("purpose") == PURPOSE
            and registration.get("protocol_sha256") == FROZEN_PROTOCOL_SHA
            and all(type(registration.get(k)) is int and registration[k] == 0 for k in ("new_detector_calls", "new_gpu_calls", "new_model_requests")))
        checked("immutable_coordinator_start_and_exact_shared_limits",
            coordinator.get("tool") == TOOL and coordinator.get("purpose") == PURPOSE
            and type(coordinator.get("schema_version")) is int and coordinator["schema_version"] == 1
            and coordinator.get("experiment_id") == directory.name
            and type(coordinator.get("real_detector_used")) is bool
            and number(coordinator.get("start_epoch"), positive=True)
            and number(coordinator.get("start_monotonic"), positive=True)
            and coordinator.get("deadline_epoch") == coordinator["start_epoch"]+300
            and same(coordinator.get("limits"), protocol["shared_budgets"]))
        checked("coordinator_protocol_registration_and_freeze_byte_bindings",
            coordinator.get("protocol_sha256") == digest(protocol_path)
            and coordinator.get("input_manifest_sha256") == digest(directory / "input_manifest.json")
            and coordinator.get("implementation_freeze_sha256") == digest(directory / "implementation_freeze.json"))
        require(type(prepublication) is bool, "Invalid review mode")
        if prepublication:
            checked("prepublication_has_no_success_marker", not (directory / "completion.json").exists())
        configuration = registration.get("configuration")
        require(isinstance(configuration, dict) and configuration.keys() == {
            "research_root", "dataset_root", "raw_root", "split_dir", "weights_path", "output_root"}, "Configuration fields differ")
        roots = [ROOT, Path(sys.executable).parent] + [Path(value) for key, value in configuration.items() if key != "weights_path"]
        roots.append(Path(configuration["weights_path"]).parent)
        checked("current_configuration_uses_trusted_output_root", Path(configuration["output_root"]).resolve() == ROOT / "outputs")
        fresh_input_before = fresh_files(registration["input_files"], roots)
        checked("fresh_input_weight_dependency_and_upstream_bytes_before_review")
        import importlib.metadata
        versions = {key: importlib.metadata.version(distribution) for key, distribution in
                    (("torch", "torch"), ("ultralytics", "ultralytics"), ("numpy", "numpy"), ("cv2", "opencv-python"))}
        checked("installed_dependency_versions_match_registered_sources", same(registration.get("dependency_versions"), versions))
        for relative, sha in protocol["upstream_sha256"].items():
            require(digest(ROOT / relative) == sha, "Accepted upstream prerequisite bytes changed")
        checked("fixed_accepted_upstream_receipts_are_current")
        review99 = read(ROOT / f'outputs/{protocol["artifact_review_task_id"]}/independent_verification.json')
        model54 = read(ROOT / "outputs/agh-sliced-artifact-model-v3/model_run_verification.json")
        checked("accepted_99_independent_and_54_model_prerequisites",
            review99.get("status") == model54.get("status") == "passed"
            and len(review99.get("checks", {})) == 99 and all(v is True for v in review99["checks"].values())
            and len(model54.get("checks", {})) == 54 and all(v is True for v in model54["checks"].values())
            and model54.get("strict_tool_scope_passed") is True)
        expected_preserved = preserved_rows(protocol)
        checked("complete_protected_39_file_registry", same(registration.get("preserved_files"), expected_preserved))
        preserved_before = fresh_files(expected_preserved, [ROOT])
        checked("fresh_protected_historical_bytes_before_review")
        source_before = fresh_files(freeze.get("sources"), [ROOT])
        execution_sha = source_identity(freeze["sources"])
        checked("fixed_17_execution_sources_and_digest",
            freeze.get("schema_version") == 1 and freeze.get("tool") == TOOL and freeze.get("purpose") == PURPOSE
            and freeze.get("execution_source_sha256") == coordinator.get("execution_source_sha256") == execution_sha)
        selection_bound(registration, protocol)
        checked("two_samples_selected_by_frozen_validation_gt_membership_only")
        pixels = decoded_pixels(registration)
        checked("all_18_original_bgr_and_crop_pixel_identities_rederived")
        original = ROOT / f'outputs/{protocol["source_failed_task_id"]}'
        checked("original_full_task_failure_and_absent_completion_preserved",
            read(original / "failure.json").get("status") == "failed"
            and not any((original/name).exists() for name in ("completion.json", "completion_candidate.json", "artifact_manifest.json", "sliced_result.json")))
        checked("no_two_image_scientific_gain_or_all640_claim",
            protocol.get("scientific_metrics_computed") is False
            and protocol.get("training_performed") is False and protocol.get("test_inference_performed") is False)
        verifier = journal_reader()
        arm_data, arm_budgets = {}, {}
        for arm, count in (("control", 18), ("fault", 2), ("resume", 18)):
            arm_dir = directory / arm
            require(arm_dir.is_dir() and not arm_dir.is_symlink(), "Arm directory is absent or linked")
            request = read(arm_dir / "worker_request.json")
            science_sha = sha_object({"input_manifest_sha256": coordinator["input_manifest_sha256"],
                "protocol_sha256": coordinator["protocol_sha256"], "arm_group": "control" if arm == "control" else "fault"})
            identity = {"protocol_sha256": coordinator["protocol_sha256"], "weight_sha256": WEIGHT_SHA,
                "scientific_inputs_sha256": science_sha, "execution_source_sha256": execution_sha,
                "journal_source_sha256": digest(ROOT / "defect_researcher/sliced_journal.py")}
            checked(f"{arm}_purpose_version_path_and_source_bound_request",
                request.get("tool") == TOOL and type(request.get("execution_io_version")) is int and request["execution_io_version"] == 2
                and request.get("arm") == arm and Path(request.get("directory", "")).resolve() == arm_dir
                and Path(request.get("experiment_directory", "")).resolve() == directory
                and request.get("experiment_id") == coordinator["experiment_id"]
                and same(request.get("protocol"), protocol) and same(request.get("records"), registration["records"])
                and same(request.get("reference_environment"), registration["reference_environment"])
                and request.get("scientific_inputs_sha256") == science_sha
                and all(request.get(k) == coordinator[k] for k in ("protocol_sha256", "input_manifest_sha256", "execution_source_sha256", "implementation_freeze_sha256")))
            observed = lines(arm_dir / "pass_observations.jsonl")
            environment = read(arm_dir / "environment.json")
            environment_id = environment_valid(environment, registration["reference_environment"])
            checked(f"{arm}_actual_fp32_cuda_null_nms_environment")
            if coordinator["real_detector_used"]:
                callable_sources_valid(environment, registration["input_files"])
                checked(f"{arm}_real_predictor_callable_sources_registered_and_fresh")
            observations_valid(observed, pixels, identity, environment_id, count=count)
            checked(f"{arm}_complete_observations_mapping_controls_and_closed_cost")
            replay = verifier.verify_journal(arm_dir, protocol, identity,
                require_completed=arm != "fault", observations=observed)
            checked(f"{arm}_independent_durable_journal_and_checkpoint_replay", replay["status"] == "passed")
            budget = replay["replayed_budget"]
            arm_budgets[arm], arm_data[arm] = budget, {"observations": observed, "identity": identity,
                "environment": environment, "request": request, "replay": replay}
            receipt = read(arm_dir / "worker_receipt.json")
            checked(f"{arm}_worker_receipt_detector_mode_and_population",
                receipt.get("status") == ("failed" if arm == "fault" else "completed")
                and receipt.get("observations") == count and receipt.get("real_detector_used") is coordinator["real_detector_used"])
            checked(f"{arm}_original_absolute_shared_task_clock",
                budget.get("task_started_epoch") == coordinator["start_epoch"]
                and number(budget.get("task_wall_seconds")) and budget["task_wall_seconds"] <= 300
                and budget.get("resumable") is True)
            monotonic_segments_valid(budget, 2 if arm == "resume" else 1)
            checked(f"{arm}_closed_monotonic_clock_segments_and_cumulative_cost")
        control, fault, resume = (arm_budgets[key] for key in ("control", "fault", "resume"))
        checked("exact_control_fault_and_cumulative_resume_call_counts",
            (control["formal_calls"], control["warmup_calls"], control["successful_observations"]) == (18, 1, 18)
            and (fault["formal_calls"], fault["warmup_calls"], fault["successful_observations"]) == (3, 1, 2)
            and (resume["formal_calls"], resume["warmup_calls"], resume["successful_observations"]) == (19, 1, 18))
        checked("exact_once_known_cost_injected_failure_is_only_failure",
            all(row["status"] == "passed" for row in control["formal_attempts"]+control["warmup_attempts"])
            and [row["status"] for row in fault["formal_attempts"]] == ["passed", "passed", "failed"]
            and all(row["status"] == "passed" for row in resume["formal_attempts"][3:]+resume["warmup_attempts"])
            and same(resume["formal_attempts"][:3], fault["formal_attempts"])
            and same(resume["warmup_attempts"], fault["warmup_attempts"]))
        fault_identity = {k: arm_data["fault"]["identity"][k] for k in ("protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256")}
        fault_valid(directory / "fault", protocol, fault_identity, coordinator["experiment_id"], fault)
        checked("injected_actual_return_before_passed_with_closed_cuda_cost")
        checked("resumed_fault_rule_consumed_once_and_unchanged",
            digest(directory / "fault/fault.json") == digest(directory / "resume/fault.json")
            and read(directory / "resume/worker_receipt.json").get("fault_consumed") is True)
        prefix = (directory / "fault/checkpoint_journal.jsonl").read_bytes()
        checked("resume_binds_exact_closed_failure_journal_prefix",
            (directory / "resume/checkpoint_journal.jsonl").read_bytes().startswith(prefix)
            and resume["inference_started_epoch"] == fault["inference_started_epoch"]
            and resume["task_started_epoch"] == fault["task_started_epoch"]
            and resume["gpu_seconds"] >= fault["gpu_seconds"])
        checked("resume_preserves_original_closed_monotonic_segment", same(resume["wall_segments"][:1], fault["wall_segments"]))
        checked("two_committed_checkpoints_reused_without_prediction",
            same(arm_data["resume"]["observations"][:2], arm_data["fault"]["observations"])
            and [(row["image_id"], row["pass_id"]) for row in resume["formal_attempts"][3:]]
                == [(image, pass_id) for image in IMAGES for pass_id in range(9)][2:])
        checked("original_fault_status_stays_failed_and_has_no_success_marker",
            read(directory / "fault/failure.json").get("status") == "failed"
            and arm_data["fault"]["replay"]["business_status"] == "failed"
            and not (directory / "fault/completion.json").exists())
        source_identity_fields = {k: coordinator[k] for k in ("experiment_id", "protocol_sha256", "input_manifest_sha256", "execution_source_sha256")}
        shared = verify_shared(directory, coordinator, arm_budgets, source_identity_fields)
        checked("all_39_outer_calls_shared_hashchain_and_closed_cost_aggregation")
        checked("all_39_calls_within_single_40_call_60_gpu_300_wall_budget", shared["gpu_seconds"] <= 60 and shared["last_elapsed_seconds"] <= 300)
        for a, b in zip(arm_data["control"]["observations"], arm_data["resume"]["observations"]):
            require(predictions_equal(a["local_predictions"], b["local_predictions"])
                    and predictions_equal(a["global_predictions"], b["global_predictions"]), "Control/resume per-observation tolerance exceeded")
        checked("control_and_resume_all18_ordered_local_global_lists_within_frozen_abs_tolerance")
        final = {}
        for arm in ("control", "resume"):
            final[arm] = arm_fusion(directory / arm, arm_data[arm]["observations"], registration)
            checked(f"{arm}_independent_full_sameclass_nms_trace_and_global_maxdet")
        checked("control_resume_final_fused_prediction_classes_order_abs_tolerance",
            all(predictions_equal(a["predictions"], b["predictions"]) for a, b in zip(final["control"], final["resume"])))
        result = read(directory / "business_result.json")
        checked("reviewed_result_purpose_counts_mode_and_scientific_boundaries",
            result.get("schema_version") == 1 and result.get("tool") == TOOL and result.get("purpose") == PURPOSE
            and result.get("experiment_id") == coordinator["experiment_id"]
            and result.get("real_detector_used") is coordinator["real_detector_used"]
            and same(result.get("expected_counts"), protocol["expected_counts"])
            and result.get("detector_calls") == 39 and result.get("all_640_recovery_verified") is False
            and result.get("scientific_performance_claim") is False and result.get("model_requests") == 0)
        checked("reviewed_result_closed_shared_gpu_and_call_totals",
            same(result.get("shared_totals"), {k: shared[k] for k in ("detector_calls", "formal_calls", "warmup_calls", "gpu_seconds")})
            and number(result.get("gpu_seconds")) and abs(result["gpu_seconds"]-shared["gpu_seconds"]) <= 1e-10)
        fault_snapshot_before = tree_snapshot(directory / "fault")
        checked("full_fault_tree_fresh_bytes_match_closed_before_after_receipts",
            same(result.get("fault_tree_before_resume"), fault_snapshot_before)
            and same(result.get("fault_tree_after_resume"), fault_snapshot_before))
        expected_after = [{**row, "sha256_after": row["sha256"], "unchanged": True} for row in expected_preserved]
        checked("reported_history_preservation_matches_independent_registry", same(result.get("preservation_after"), expected_after))
        checked("reviewed_shared_wall_cost_includes_prior_preparation_and_all_calls",
            number(result.get("elapsed_seconds_at_review")) and shared["last_elapsed_seconds"] <= result["elapsed_seconds_at_review"] <= 300)
        require(prepublication or (directory / "completion.json").is_file(), "Postpublication review requires completion")
        if not prepublication:
            publication_valid(directory)
            checked("completion_candidate_manifest_all_bytes_and_marker_last")
            marker = read(directory / "completion.json")
            checked("completion_within_original_shared_deadline_after_independent_review",
                number(marker.get("elapsed_seconds")) and result["elapsed_seconds_at_review"] <= marker["elapsed_seconds"] <= 300
                and number(marker.get("completed_epoch")) and marker["completed_epoch"] <= coordinator["deadline_epoch"]
                and marker.get("detector_calls") == 39 and abs(marker.get("gpu_seconds", -1)-shared["gpu_seconds"]) <= 1e-10)
        checked("fresh_all_input_bytes_unchanged_during_independent_review",
            same(fresh_files(registration["input_files"], roots), fresh_input_before))
        checked("fresh_all17_source_bytes_unchanged_during_independent_review", same(fresh_files(freeze["sources"], [ROOT]), source_before))
        checked("fresh_all_preserved_protected_history_bytes_unchanged_during_independent_review", same(fresh_files(expected_preserved, [ROOT]), preserved_before))
        checked("fresh_full_closed_fault_tree_unchanged_during_independent_review", same(tree_snapshot(directory / "fault"), fault_snapshot_before))
        end_epoch = time.time() if now_epoch is None else now_epoch
        if prepublication:
            checked("independent_review_itself_finishes_within_shared_deadline",
                number(end_epoch) and end_epoch <= coordinator["deadline_epoch"]
                and end_epoch-coordinator["start_epoch"] <= 300)
        evidence = {"experiment_id": coordinator["experiment_id"], "real_detector_used": coordinator["real_detector_used"],
            "protocol_sha256": coordinator["protocol_sha256"], "input_manifest_sha256": coordinator["input_manifest_sha256"],
            "execution_source_sha256": execution_sha, "detector_calls": 39, "formal_calls": 37,
            "explicit_warmup_calls": 2, "gpu_seconds": shared["gpu_seconds"],
            "control_observations": 18, "resume_observations": 18, "reused_observations": 2,
            "new_resume_formal_calls": 16, "injected_failed_calls": 1, "source_files": len(source_before),
            "protected_files": len(preserved_before), "input_roles": len(registration["input_files"]),
            "shared_journal_sha256": shared["journal_sha256"], "new_detector_calls_during_review": 0,
            "shared_elapsed_at_review_start": result["elapsed_seconds_at_review"],
            "independent_review_seconds": time.perf_counter()-started}
    except Exception as error:
        failure = {"type": type(error).__name__, "message": str(error)}
        checks["all_required_independent_evidence_checks_completed"] = False
    status = "passed" if checks and all(value is True for value in checks.values()) and failure is None else "failed"
    return {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE, "status": status,
        "prepublication": prepublication, "checks_total": len(checks), "checks_passed": sum(value is True for value in checks.values()),
        "checks": checks, "evidence": evidence, "error": failure,
        "limitations": ["Fixed two validation images and one closed-cost injected failure only.",
            "No detection accuracy, held-out gain, all640 recovery, forced shutdown or unknown-cost recovery claim.",
            "Independent pixel/mapping/fusion and fixed independent journal replay; no second detector inference."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory")
    parser.add_argument("--prepublication", action="store_true")
    args = parser.parse_args()
    result = review(args.directory, prepublication=args.prepublication)
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
