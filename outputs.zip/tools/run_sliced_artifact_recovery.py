"""Run one separately budgeted, zero-prediction review of saved artifacts."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from defect_researcher.config import load_config
from defect_researcher.sliced_artifact_recovery import run_sliced_artifact_recovery, DEFAULT_TASK_ID, DEFAULT_SOURCE_ID


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT/"config"/"local.json")
    parser.add_argument("--task-id", default=DEFAULT_TASK_ID)
    parser.add_argument("--source-id", default=DEFAULT_SOURCE_ID)
    args = parser.parse_args()
    result = run_sliced_artifact_recovery(load_config(args.config), args.task_id, source_id=args.source_id)
    print(json.dumps({"task_id": result["task_id"], "status": result["status"], "summary": result["summary"],
                      "errors": result["errors"]}, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
