// A single official SESSION, four bounded turns, and model-owned recovery.
// Importing this module is inert. Only the explicit CLI opens AGH or runs workers.
import {readFile,writeFile,rename,unlink,open} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {execFile} from 'node:child_process';
import {watch as watchDirectory} from 'node:fs';
import {promisify} from 'node:util';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {ACTION_TOOL,READ_TOOL,SERVER_ID,createResolutionResearchScopeGuard,normalizePath} from './resolution_research_scope_guard_v1.mjs';
import {readModelProtocol,readCandidate} from './resolution_research_deployment_v1.mjs';

export const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export const PROTOCOL_KEYS=['schema_version','kind','deployment','source_lock','runtime_version','runner_source','task_prompt',
 'scope_policy','scope_candidate_path','scope_activation_path','mcp_activation_path','python_executable','powershell_executable',
 'model','route','server_id','domain_task_directory','output_directory'];
const productionBrand=Symbol('owned production dependencies');
const obj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const exact=(v,keys)=>obj(v)&&Object.keys(v).sort().join(',')===[...keys].sort().join(',');
const integer=v=>Number.isSafeInteger(v)&&v>=0;
export const stable=v=>JSON.stringify(v,(_k,x)=>obj(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
export const sha=v=>createHash('sha256').update(v).digest('hex');
const require=(condition,message)=>{if(condition!==true)throw new Error(message);};
const decode=v=>JSON.parse(v,(_k,x)=>{if(typeof x==='number'&&!Number.isFinite(x))throw new Error('Nonfinite JSON');return x;});
const trusted=e=>e?.origin==='system'&&e?.trust==='trusted';
const eventMs=e=>{const x=Date.parse(e?.ts);require(Number.isFinite(x),'Missing event UTC timestamp');return x;};
const titleEvent='x/host/session-title',diagnosticEvent=titleEvent+'/diagnostics';
const decisions=['decide_stop_resolution','decide_retain_resolution','decide_insufficient_evidence'];
const serverDefinition=p=>({serverId:p.server_id,displayName:'DefectResearcher bounded scientific recovery',
 transport:{kind:'stdio',executable:p.python_executable,args:['-B',join(ROOT,'run_resolution_research_mcp_v1.py'),
  '--protocol',p.deployment.path,'--expected-protocol-sha256',p.deployment.sha256,
  '--source-lock',p.source_lock.path,'--expected-lock-sha256',p.source_lock.sha256]},secretBinding:{kind:'none'},
 toolPolicy:{allow:['research_action_v1','research_read_v1']}});

export function validateProtocol(p){
 require(exact(p,PROTOCOL_KEYS)&&p.schema_version===1&&p.kind==='resolution_research_model_protocol_v1','Host protocol schema differs');
 for(const key of ['deployment','source_lock','runtime_version','runner_source','task_prompt'])
  require(exact(p[key],['path','sha256'])&&typeof p[key].path==='string'&&/^[0-9a-f]{64}$/.test(p[key].sha256),'Malformed host pin '+key);
 require(p.model==='agnes-3.0-flash'&&p.route==='account-defect-researcher'&&p.server_id===SERVER_ID,'Fixed model/server differs');
 createResolutionResearchScopeGuard(p.scope_policy);
 require(p.scope_policy.qualified_action_tool===ACTION_TOOL&&p.scope_policy.qualified_read_tool===READ_TOOL,'Qualified tools differ');
 require(normalizePath(p.runner_source.path)===normalizePath(fileURLToPath(import.meta.url)),'Runner source pin is not this module');
 for(const key of ['scope_candidate_path','scope_activation_path','mcp_activation_path','python_executable','powershell_executable','domain_task_directory','output_directory'])
  require(typeof p[key]==='string'&&p[key].length>0,'Missing fixed host path '+key);
 return p;
}

export class OriginalClock{
 constructor(policy,clock){this.policy=policy;this.clock=clock;this.last=clock.now();this.origin=clock.monotonic();
  this.initialElapsed=this.last-policy.started_epoch_ms;require(this.initialElapsed>=0,'Outer clock moved backwards');this.check();}
 check(domainDeadline=null){const current=this.clock.now(),mono=this.clock.monotonic();
  require(Number.isFinite(current)&&Number.isFinite(mono)&&current>=this.last&&mono>=this.origin,'Original clock moved backwards');
  const elapsed=Math.max(current-this.policy.started_epoch_ms,this.initialElapsed+mono-this.origin);this.last=current;
  require(elapsed<2400000&&current<this.policy.deadline_epoch_ms,'Original outer deadline expired');
  if(domainDeadline!==null)require(current<domainDeadline,'Original domain deadline expired while its worker was pending');return current;}
}

export function actualTokens(tokens){
 const required=['input','output','cacheRead','cacheWrite'];
 require(obj(tokens)&&required.every(k=>Object.hasOwn(tokens,k))&&Object.keys(tokens).every(k=>[...required,'reasoning'].includes(k))
  &&Object.values(tokens).every(integer)&&required.reduce((n,k)=>n+tokens[k],0)<=Number.MAX_SAFE_INTEGER
  &&(tokens.input>0||tokens.output>0),'Unknown/default-zero/invalid actual token receipt');return tokens;
}

export function inspectPrimaryCosts(events,model,route,{closed=true}={}){
 const requests=events.filter(e=>e.type==='request/sent'),costs=events.filter(e=>e.type==='cost/ledger'&&e.data?.purpose==='inference');
 require(requests.length<=13&&costs.length<=requests.length,'Primary request cap or cost population differs');
 const hashes=new Set(requests.map(e=>e.data?.tool_schema_hash));
 require(requests.length===0||(hashes.size===1&&[...hashes].every(x=>typeof x==='string'&&/^[0-9a-f]{64}$/.test(x))),'Actual tool schema changed');
 if(closed)require(costs.length===requests.length,'Actual primary cost is still open');
 for(let n=0;n<costs.length;n++){
  const request=requests[n],cost=costs[n];require(trusted(request)&&trusted(cost)&&request.data.model?.id===model
   &&request.data.model?.route===route&&cost.data.model===model&&request.seq<cost.seq
   &&(!requests[n+1]||cost.seq<requests[n+1].seq),'Primary cost is not bound to its actual request');
  actualTokens(cost.data.tokens);require((!Object.hasOwn(cost.data,'interrupted')||cost.data.interrupted===false)
   &&Number.isInteger(cost.data.response?.status)&&cost.data.response.status>=200&&cost.data.response.status<300,
   'Interrupted/error/unknown primary provider response');
 }
 return{primary_requests:requests.length,primary_costs:costs.length,primary_usage_closed:costs.length===requests.length};
}

export function inspectNativeTitle(events,sessionId,model,route,{closed=true}={}){
 const requested=events.filter(e=>e.type===titleEvent&&e.data?.status==='requested');
 const terminal=events.filter(e=>e.type===titleEvent&&['generated','failed'].includes(e.data?.status));
 const costs=events.filter(e=>e.type==='cost/ledger'&&e.data?.purpose==='title'),diagnostics=events.filter(e=>e.type===diagnosticEvent);
 require(requested.length<=1&&terminal.length<=1&&costs.length<=1&&diagnostics.length<=1,'Multiple native titles are forbidden, including after title failure');
 if(!closed&&terminal.length===0)return{native_title_requests:requested.length,native_title_usage_closed:false};
 require(requested.length===1&&terminal.length===1&&costs.length===1&&diagnostics.length===1,'Native title actual receipt is missing/open; zero is not a default cost');
 const [request,finish,cost,diagnostic]=[requested[0],terminal[0],costs[0],diagnostics[0]],seed=request.data,d=diagnostic.data;
 const start=events.find(e=>e.seq===seed.startSeq),ends=events.filter(e=>e.type==='turn/end'&&e.seq>seed.startSeq&&e.seq<request.seq);
 require(start?.type==='turn/start'&&start.data?.trigger==='prompt'&&integer(seed.turn)&&seed.turn>0&&integer(seed.startSeq)&&seed.startSeq>0
  &&integer(start.data.turn)&&seed.turn===start.data.turn&&integer(finish.data.turn)&&finish.data.turn===seed.turn
  &&integer(finish.data.startSeq)&&finish.data.startSeq===start.seq&&ends.length===1&&ends[0].data?.reason==='completed',
  'Title seed is not the original trusted prompt turn');
 require([start,ends[0],request,finish,cost,diagnostic].every(e=>trusted(e)&&e.lane===request.lane)
  &&seed.model===model&&finish.data.model===model&&cost.data.model===model&&seed.route===route&&finish.data.route===route,
  'Native title model/lane/trust differs');
 const effect='title:'+sha(JSON.stringify([sessionId,request.lane,start.seq]));
 require(cost.seq>request.seq&&diagnostic.seq===cost.seq+1&&finish.seq===diagnostic.seq+1&&cost.ts===diagnostic.ts&&cost.ts===finish.ts
  &&d.schemaVersion===1&&d.sourceTurn===seed.turn&&cost.data.sourceTurn===seed.turn&&d.effectId===effect&&cost.data.effectId===effect
  &&diagnostic.ignorable===true,'Title cost/diagnostic/terminal is not an atomic bound append');
 const mandatory=['schemaVersion','sourceTurn','effectId','timeoutMs','durationMs','providerSent','responseSeen','usageObserved',
  'cancellationSettlementLimitMs','settledUsage','duplicateUsage','invalidUsage','responseStatus','usageAtMs'];
 require(mandatory.every(k=>Object.hasOwn(d,k))&&Object.keys(d).every(k=>[...mandatory,'firstTextAtMs','firstThinkingAtMs'].includes(k))
  &&d.providerSent===true&&d.responseSeen===true&&d.usageObserved===true&&d.settledUsage===false&&d.duplicateUsage===false&&d.invalidUsage===false
  &&integer(d.responseStatus)&&d.responseStatus>=200&&d.responseStatus<300&&d.timeoutMs===30000&&d.cancellationSettlementLimitMs===25
  &&integer(d.durationMs)&&d.durationMs<30000&&integer(d.usageAtMs)&&d.usageAtMs<=d.durationMs
  &&['firstTextAtMs','firstThinkingAtMs'].every(k=>!Object.hasOwn(d,k)||(integer(d[k])&&d[k]<=d.durationMs)),'Native title response/cancellation/usage is not known and closed');
 actualTokens(cost.data.tokens);require(!Object.hasOwn(cost.data,'interrupted')||cost.data.interrupted===false,'Interrupted native title cost');
 require(finish.data.status==='generated'||(finish.data.status==='failed'&&finish.data.reason==='invalid-title'),'Native title failure is not a cost-closed format outcome');
 return{native_title_requests:1,native_title_usage_closed:true,title_generated:finish.data.status==='generated',
  native_title_status:finish.data.status,native_title_reason:finish.data.reason??null,native_title_effect_id:effect,native_title_tokens:cost.data.tokens};
}

export class ResearchTrace{
 constructor(protocol,sessionId,clock){this.protocol=protocol;this.sessionId=sessionId;this.clock=clock;this.phase='new';this.events=[];
  this.calls=new Map();this.results=new Set();this.used=new Set();this.permissions=[];this.statusApprovals=0;this.runningReads=0;
  this.faultReads=0;this.completedReads=0;this.reviewCount=0;this.supportedDecision=null;this.domainDeadline=null;this.fatal=null;}
 observePreflight(notification){
  require(this.phase==='preflight_running'&&notification.phase==='preflight'&&notification.known_cost===true
   &&notification.new_prediction_calls===0&&notification.deadline_reset===false,'Preflight notification is not a closed zero-inference result');
  if(notification.status==='preflight_passed'){
   const e=notification.evidence;require(e?.status==='preflight_passed'&&e.task_id===this.protocol.scope_policy.task_id
    &&e.new_prediction_calls===0&&e.fixture_only===false&&e.deadline_reset===false
    &&Number.isFinite(e.original_deadline_epoch)&&Number.isFinite(e.original_deadline_monotonic)
    &&e.ledger?.prediction_calls===0&&e.ledger.cost_known===true&&e.ledger.open_call===null&&e.ledger.failed_detector_call===false,
    'Actual original-domain preflight evidence is not bound');
   this.domainDeadline=e.original_deadline_epoch*1000;this.clock.check(this.domainDeadline);this.phase='gated';
  }else{require(notification.status==='preflight_failed','Unexpected preflight terminal');this.phase='gate_failed';}
 }
 authorize(request){let allowed=false;const tool=request.toolCall?._meta?.['ai.agnes.harness']?.tool,args=request.toolCall?.rawInput;
  const once=request.options?.find(x=>x.kind==='allow_once'),id=request.toolCall?.toolCallId??request.toolCall?.id;
  try{this.clock.check(this.phase==='initial_running'||this.phase==='resume_running'?this.domainDeadline:null);
   require(request.sessionId===this.sessionId&&once&&typeof id==='string'&&!this.permissions.some(x=>x.tool_call_id===id),'Permission is unowned/duplicate');
   require(exact(args,['request_id','action'])&&args.request_id===this.protocol.scope_policy.request_id,'Broadened permission arguments');
   const required={audit_geometry:['new'],register_hypothesis:['gated'],start_registered_experiment:['registered'],resume_registered_failure:['fault_observed'],
    stop_insufficient_evidence:['gate_failed','gated','registered','fault_observed','failed'],publish_report:['decided','stopped']};
   if(tool===ACTION_TOOL){
    if(decisions.includes(args.action))require(this.phase==='reviewed'&&args.action===this.supportedDecision,'Unsupported model decision');
    else require(required[args.action]?.includes(this.phase)===true,'Action outside observed stage');
    require(!this.used.has(args.action),'Model action already authorized once');this.used.add(args.action);
   }else{require(tool===READ_TOOL,'Foreign tool');
    if(args.action==='status'){require(['initial_running','resume_running'].includes(this.phase)&&this.statusApprovals<3,'Status polling denied');this.statusApprovals++;}
    else{require(args.action==='independent_review'&&this.phase==='completed_observed'&&this.reviewCount===0,'Review must follow completed observation once');this.reviewCount++;}
   }allowed=true;
  }catch{allowed=false;}
  this.permissions.push({tool,input:args,tool_call_id:id,decision:allowed?'allowed-once':'rejected',at_epoch_ms:this.clock.clock.now()});
  return allowed?{optionId:once.optionId}:{verdict:'rejected'};
 }
 consume(event){
  this.clock.check();require(integer(event.seq)&&event.seq>0&&event.seq===this.events.length+1,'Official session sequence is not contiguous');
  require(eventMs(event)>=this.protocol.scope_policy.started_epoch_ms&&eventMs(event)<this.protocol.scope_policy.deadline_epoch_ms,'Event escaped original outer clock');
  this.events.push(event);
  if(event.type==='session/start')require(event.data?.key===this.sessionId&&trusted(event),'Not this fresh official SESSION');
  if(event.type==='tool/call'){
   require(event.origin==='model'&&event.trust==='trusted'&&[ACTION_TOOL,READ_TOOL].includes(event.data?.name)
    &&exact(event.data.args,['request_id','action'])&&event.data.args.request_id===this.protocol.scope_policy.request_id
    &&typeof event.data.toolUseId==='string'&&!this.calls.has(event.data.toolUseId),'Foreign/duplicate actual tool call');
   require(this.permissions.some(p=>p.decision==='allowed-once'&&p.tool_call_id===event.data.toolUseId
    &&p.tool===event.data.name&&stable(p.input)===stable(event.data.args)),'Actual tool lacks its exact Allow once approval');
   this.calls.set(event.data.toolUseId,event);
  }
  if(event.type==='tool/result'){
   const call=this.calls.get(event.data?.toolUseId);require(call&&!this.results.has(event.data.toolUseId),'Unpaired/duplicate tool result');
   this.results.add(event.data.toolUseId);require(event.data.isError!==true,'Actual scientific tool failed');
   const blocks=event.data.content?.filter(x=>x.type==='text');require(blocks?.length===1,'Expected one structured scientific result');
   const payload=decode(blocks[0].text),action=call.data.args.action;
   require(obj(payload)&&payload.request_id===this.protocol.scope_policy.request_id&&payload.task_id===this.protocol.scope_policy.task_id
    &&payload.fixture_only===false,'Scientific result identity/real fixture flag differs');
   if(action==='audit_geometry'){
    if(payload.status==='running'){require(payload.phase==='preflight'&&payload.host_wait_required===true,'Preflight did not return the bounded asynchronous running boundary');this.phase='preflight_running';}
    else{require(payload.status==='preflight_failed','Unexpected audit status');this.phase='gate_failed';}
   }else if(action==='register_hypothesis'){require(payload.status==='hypothesis_registered','Hypothesis was not registered');this.phase='registered';}
   else if(['start_registered_experiment','resume_registered_failure'].includes(action)){
    require(payload.status==='running'&&payload.host_wait_required===true,'Worker did not return the explicit running boundary');
    this.phase=action==='start_registered_experiment'?'initial_running':'resume_running';
   }else if(action==='status'){
    if(payload.status==='running'){require(this.runningReads++===0,'Repeated running status poll');}
    else if(payload.status==='recovery_pending'){
     const f=payload.actual_failure;require(this.phase==='initial_running'&&this.faultReads++===0&&f?.closed_cost===true
      &&f.type==='InjectedResolutionStepFault'&&f.ledger?.prediction_calls===2564&&f.ledger.cost_known===true&&f.ledger.open_call===null
      &&f.ledger.failed_detector_call===false&&f.original_deadline_epoch*1000===this.domainDeadline,'Actual fault cost is unknown or not the fixed original failure');this.phase='fault_observed';
    }else if(payload.status==='experiment_completed'){require(this.phase==='resume_running'&&this.completedReads++===0,'Completed read is unowned/repeated');this.phase='completed_observed';}
    else{require(payload.status==='experiment_failed','Unknown status');this.phase='failed';}
   }else if(action==='independent_review'){
    if(payload.status==='reviewed'){require(payload.verification?.status==='passed'&&payload.verification.real_recovery_accepted===true
     &&decisions.includes(payload.only_supported_decision_action),'Independent scientific review did not pass');this.supportedDecision=payload.only_supported_decision_action;this.phase='reviewed';}
    else{require(payload.status==='independent_review_failed','Unknown independent review status');this.phase='failed';}
   }else if(decisions.includes(action)){require(payload.status==='decided','Model decision did not commit');this.phase='decided';}
   else if(action==='stop_insufficient_evidence'){require(payload.status==='stopped','Model stop did not commit');this.phase='stopped';}
   else if(action==='publish_report'){require(payload.status==='report_completed','Model report did not publish');this.publication=payload;this.phase='reported';}
  }
  if(event.type==='turn/end')require(trusted(event)&&event.data?.reason==='completed','Primary turn failed/interrupted');
  if(event.type==='error'||event.type.endsWith('/error'))throw new Error('Actual AGH error event');
  inspectPrimaryCosts(this.events,this.protocol.model,this.protocol.route,{closed:false});
  inspectNativeTitle(this.events,this.sessionId,this.protocol.model,this.protocol.route,{closed:false});
 }
 settlement(){const p=inspectPrimaryCosts(this.events,this.protocol.model,this.protocol.route),t=inspectNativeTitle(this.events,this.sessionId,this.protocol.model,this.protocol.route);
  require(p.primary_requests+t.native_title_requests<=14,'Combined native request budget exceeded');return{...p,...t,actual_total_model_requests:p.primary_requests+t.native_title_requests};}
}

const failure=e=>({type:e?.name??'Error',message:String(e?.message??e)});
export async function runResearchSession(protocol,deps){
 validateProtocol(protocol);require(deps?.fixtureOnly===true||deps?.[productionBrand]===true,'Only explicit fixture dependencies or the owned CLI are accepted');
 const clock=new OriginalClock(protocol.scope_policy,deps.clock),record={schema_version:1,kind:'resolution_research_model_run_v1',
  status:'starting',fixture_only:deps.fixtureOnly===true,science_accepted:false,model:protocol.model,route:protocol.route,
  workspace_root:protocol.scope_policy.workspace_root,protocol_path:deps.protocolPath,protocol_sha256:deps.protocolHash,
  deployment:protocol.deployment,source_lock:protocol.source_lock,runtime_version:protocol.runtime_version,
  runner_source:protocol.runner_source,task_prompt:protocol.task_prompt,scope_policy:protocol.scope_policy,
  started_epoch_ms:protocol.scope_policy.started_epoch_ms,deadline_epoch_ms:protocol.scope_policy.deadline_epoch_ms,
  domain_task_directory:protocol.domain_task_directory,sdk_events:[],request_events:[],cost_events:[],turn_starts:[],turn_ends:[],
  permissions:[],calls:[],results:[],title_diagnostics:[],prompt_receipts:[],host_waits:[],final_texts:[],exports:[],checks:{}};
 let client,session,iterator,reader,trace,ready=false,readerStopped=false,readerError=null,finished=false;
 const abort=new AbortController(),listeners=new Set();let saveTail=Promise.resolve();
 const deadlineTimer=setTimeout(()=>{abort.abort(new Error('Original outer deadline expired'));void session?.cancel?.().catch(()=>undefined);pulse();},
  Math.max(1,protocol.scope_policy.deadline_epoch_ms-deps.clock.now()));
 const save=()=>{const snapshot=decode(JSON.stringify(record));saveTail=saveTail.then(()=>deps.save(snapshot));return saveTail;};
 const pulse=()=>{for(const callback of [...listeners])callback();};
 const bounded=promise=>new Promise((yes,no)=>{const cancelled=()=>no(abort.signal.reason??new Error('Official session execution aborted'));
  if(abort.signal.aborted)return cancelled();abort.signal.addEventListener('abort',cancelled,{once:true});
  Promise.resolve(promise).then(yes,no).finally(()=>abort.signal.removeEventListener('abort',cancelled));});
 async function until(test){
  for(;;){clock.check();if(readerError)throw readerError;if(test())return;if(readerStopped)throw new Error('Official stream ended before this stage');
   await new Promise((yes,no)=>{const done=()=>{clearTimeout(timer);listeners.delete(done);yes();};
    const timer=setTimeout(()=>{listeners.delete(done);no(new Error('Original outer deadline expired during event settlement'));},Math.max(1,protocol.scope_policy.deadline_epoch_ms-deps.clock.now()));
    listeners.add(done);if(test()||readerError||readerStopped)done();});
  }
 }
 function mirror(){const events=trace.events;record.sdk_events=events;record.permissions=trace.permissions;
  record.request_events=events.filter(e=>e.type==='request/sent');record.cost_events=events.filter(e=>e.type==='cost/ledger');
  record.turn_starts=events.filter(e=>e.type==='turn/start');record.turn_ends=events.filter(e=>e.type==='turn/end');
  record.calls=[...trace.calls.values()];record.results=events.filter(e=>e.type==='tool/result').map(e=>{
   const blocks=e.data.content?.filter(x=>x.type==='text');let payload;try{if(blocks?.length===1)payload=decode(blocks[0].text);}catch{}
   return{seq:e.seq,tool_use_id:e.data.toolUseId,raw_data:e.data,...(payload?{payload}:{})};});
  record.title_diagnostics=events.filter(e=>e.type===diagnosticEvent);
  record.title_request_event=events.find(e=>e.type===titleEvent&&e.data?.status==='requested')??null;
  record.title_terminal_event=events.find(e=>e.type===titleEvent&&['generated','failed'].includes(e.data?.status))??null;
  record.final_texts=events.filter(e=>e.type==='assistant/message');record.observed_phase=trace.phase;
  record.primary_requests=record.request_events.length;
  record.native_title_requests=events.filter(e=>e.type===titleEvent&&e.data?.status==='requested').length;
  record.native_title_costs=events.filter(e=>e.type==='cost/ledger'&&e.data?.purpose==='title').length;
  record.actual_total_model_requests=record.primary_requests+record.native_title_requests;
 }
 async function follow(phase,turnCount){
  await deps.checkPins();clock.check(trace.domainDeadline);
  const begin=clock.check(trace.domainDeadline),notification=await bounded(deps.waitWorker(phase,{signal:abort.signal,
   outerDeadline:protocol.scope_policy.deadline_epoch_ms,domainDeadline:trace.domainDeadline}));
  const end=clock.check(trace.domainDeadline);
  require(notification.request_id===protocol.scope_policy.request_id&&notification.task_id===protocol.scope_policy.task_id
   &&notification.host_notification_allowed===true&&['preflight_passed','preflight_failed','recovery_pending','experiment_completed','experiment_failed'].includes(notification.status),
   'Host notification is not an owned terminal worker result');
  require((phase==='preflight'?['preflight_passed','preflight_failed']:phase==='initial'?['recovery_pending','experiment_failed']:['experiment_completed','experiment_failed']).includes(notification.status),
   'Worker terminal belongs to a different execution phase');
  require(notification.known_cost===true,'Unknown cost cannot trigger a continuation or recovery');
  if(phase==='preflight')trace.observePreflight(notification);
  record.host_waits.push({phase,started_epoch_ms:begin,finished_epoch_ms:end,original_domain_deadline_epoch_ms:trace.domainDeadline,notification});
  await save();await deps.checkPins();clock.check();
  const text=phase==='preflight'
   ?'同一会话通知：audit_geometry 的原 preflight worker 已终态。以下是 host 从固定独占结果文件和只读 --inspect 获得的新审计/几何证据；scope 会独立核验同一文件。预检通过时直接显式 register_hypothesis，然后 start_registered_experiment；不额外调用 status。未通过则 stop_insufficient_evidence 并 publish_report。不得新任务、改配置、重开时钟。start 返回 running 后结束 turn，等 host 下一通知。\n'+JSON.stringify(notification)
   :phase==='initial'
   ?'同一会话通知：已登记 initial worker 已终态。请用唯一 read 工具 action=status 读取原始实际故障及账本。只有 closed_cost=true、无开放/失败预测、原期限仍有效时，你才可显式选择 action=resume_registered_failure 一次；否则 action=stop_insufficient_evidence 并发布诚实报告。不要重登记、改配置、重设预算或轮询。执行动作返回 running 后暂停，等待 host 再通知。'
   :'同一会话通知：已登记 resume worker 已终态。请用 read action=status 获取实际终态；完成后调用 independent_review，依据返回的唯一支持决策和真实字段显式选择对应 decide_*，然后 publish_report 并作最终回答。失败则 stop_insufficient_evidence 并发布诚实报告。不得新实验、重试或调参。';
  const receipt={kind:'followUp',session_id:session.id,text,text_sha256:sha(text),sent_epoch_ms:clock.check(),
   preceding_turn_end_seq:record.turn_ends.at(-1).seq,worker_notification:notification};
  record.prompt_receipts.push(receipt);await save();receipt.command_seq=await bounded(session.followUp(text,{commandId:randomUUID()}));await save();
  await until(()=>record.turn_ends.length>=turnCount);require(record.turn_ends.length===turnCount,'Unexpected additional official turn');
  Object.assign(record,trace.settlement());record.actual_costs_known=true;await save();
 }
 try{
  await deps.checkPins();record.activation_receipts=await deps.liveCheck();clock.check();
  client=await deps.clientFactory();await client.workspace.add(protocol.scope_policy.workspace_root);
  const key=randomUUID();session=await client.session.new({cwd:protocol.scope_policy.workspace_root,sessionKey:key});
  record.session_id=session.id;record.session_key=session.id;record.client_request_key=key;
  trace=new ResearchTrace(protocol,session.id,clock);await save();
  session.onPermissionRequest(async request=>{const decision=trace.authorize(request);await save();return decision;});
  iterator=session.events()[Symbol.asyncIterator]();
  reader=(async()=>{try{for(;;){const next=await iterator.next();if(next.done)break;const {_meta,...event}=next.value;
   trace.consume(event);mirror();
   if(event.type.endsWith('/resolution-scope-ready')){
    require(event.data.session_key===session.id&&stable(event.data.policy)===stable(protocol.scope_policy),'Official scope readiness differs');ready=true;record.scope_ready=event;
   }
   await save();pulse();if(finished)break;
  }}catch(error){readerError=error;abort.abort();await session.cancel?.().catch(()=>undefined);}
  finally{readerStopped=true;pulse();}})();
  await until(()=>ready);await session.setModel({slot:'primary',route:protocol.route,model:protocol.model});
  record.runtime_before=await deps.captureRuntime();clock.check();
  const prompt=deps.prompt+'\n\n本次固定工具及身份（不可读文件或改变参数）：\n'+JSON.stringify({
   request_id:protocol.scope_policy.request_id,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,
   primary_cap:13,native_title_cap:1,total_cap:14,outer_started_epoch_ms:record.started_epoch_ms,
   outer_deadline_epoch_ms:record.deadline_epoch_ms,domain_wall_seconds:1800},null,2);
  record.model_started_epoch_ms=clock.check();record.status='running';
  record.prompt_receipts.push({kind:'prompt',session_id:session.id,text:prompt,text_sha256:sha(prompt),sent_epoch_ms:record.model_started_epoch_ms});
  await save();record.first_turn_result=await bounded(session.prompt(prompt,{signal:abort.signal,titleLocale:'zh-CN'}));
  await until(()=>record.turn_ends.length>=1&&record.title_terminal_event!==null);
  Object.assign(record,trace.settlement());record.actual_costs_known=true;require(record.turn_ends.length===1,'Initial request created extra turns');await save();
  if(trace.phase==='preflight_running')await follow('preflight',2);
  if(trace.phase==='initial_running'){
   await follow('initial',3);
   if(trace.phase==='resume_running')await follow('resume',4);
  }
  require(trace.phase==='reported','Model did not publish a terminal evidence-bound report');
  require(record.primary_requests<=13&&record.actual_total_model_requests<=14&&trace.calls.size===trace.results.size,'Actual requests/tools are not closed');
  require(trace.permissions.length===trace.calls.size&&trace.permissions.every(p=>p.decision==='allowed-once')
   &&[...trace.calls.values()].every(c=>trace.permissions.some(p=>p.tool_call_id===c.data.toolUseId&&p.tool===c.data.name&&stable(p.input)===stable(c.data.args))),
   'Every actual tool needs its own exact Allow once receipt');
  record.publication=trace.publication;record.science_accepted=record.fixture_only?false:trace.publication.science_accepted===true;
  if(trace.publication.science_accepted===true){
   require(record.turn_starts.length===4&&record.turn_ends.length===4&&record.prompt_receipts.length===4&&record.host_waits.length===3
    &&trace.faultReads===1&&trace.completedReads===1&&trace.used.has('resume_registered_failure')&&trace.reviewCount===1,
    'Scientific acceptance lacks the four-turn explicit preflight and recovery chain');
  }
  record.checks={one_official_session:true,original_outer_clock:true,model_owned_recovery_no_host_resume:true,
   actual_primary_and_native_title_cost_closed:true,all_tools_allow_once:true,report_published:true};
  record.status=record.fixture_only?'passed_fixture_only':record.science_accepted?'completed':'stopped_with_evidence';
 }catch(error){record.status='failed';record.science_accepted=false;record.failure=failure(error);abort.abort();
  await session?.cancel?.().catch(()=>undefined);
 }finally{
  finished=true;
  // Export remains inside the original clock; it does not grant new research time.
  if(session)for(const format of ['agnes','html'])try{clock.check();record.exports.push(await deps.exportSession(session.id,format));}
   catch(error){record.status='failed';record.science_accepted=false;(record.export_failures??=[]).push(failure(error));}
  record.runtime_execution_finished_epoch_ms=deps.clock.now();
  try{record.runtime_after=await deps.captureRuntime();clock.check();}catch(error){record.status='failed';record.science_accepted=false;record.runtime_failure=failure(error);}
  await client?.close?.();await iterator?.return?.().catch(()=>undefined);
  if(reader)await Promise.race([reader,new Promise(yes=>setTimeout(yes,100))]);
  if(readerError){record.status='failed';record.science_accepted=false;record.stream_failure=failure(readerError);}
  if(trace){mirror();try{Object.assign(record,trace.settlement());record.actual_costs_known=true;}
   catch(error){record.status='failed';record.science_accepted=false;record.actual_costs_known=false;record.primary_usage_closed=false;
    try{Object.assign(record,inspectNativeTitle(trace.events,session.id,protocol.model,protocol.route));}catch{record.native_title_usage_closed=false;}
    record.cost_failure=failure(error);}}
  record.finished_epoch_ms=deps.clock.now();record.finished_at=new Date(record.finished_epoch_ms).toISOString();
  try{await save();await saveTail;}finally{clearTimeout(deadlineTimer);}
 }
 return record;
}

const spawn=promisify(execFile);
async function filePin(path){const bytes=await readFile(path);return{path:resolve(path),sha256:sha(bytes),size_bytes:bytes.length};}
async function checkedPin(pin,{json=true}={}){require(exact(pin,['path','sha256']),'Pin schema differs');const actual=await filePin(pin.path);
 require(actual.sha256===pin.sha256,'Source/deployment bytes changed: '+pin.path);return json?decode(await readFile(pin.path,'utf8')):actual;}
async function atomicRecord(path,value,{exclusive=false}={}){
 const bytes=JSON.stringify(value,null,2)+'\n';if(exclusive){const stream=await open(path,'wx');try{await stream.writeFile(bytes);await stream.sync();}finally{await stream.close();}return;}
 const tmp=path+'.writing-'+randomUUID(),stream=await open(tmp,'wx');try{await stream.writeFile(bytes);await stream.sync();}finally{await stream.close();}
 try{await rename(tmp,path);}finally{await unlink(tmp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
}
function scopedPath(path,root){const actual=resolve(path),relative=actual.slice(resolve(root).length);
 require(normalizePath(actual).startsWith(normalizePath(resolve(root))+'/'),'Host path escaped its owned root');return actual;}

export async function waitForOwnedFile(path,{deadline,now=Date.now,signal}={}){
 require(Number.isFinite(deadline)&&deadline>now(),'Original deadline expired before host wait');
 return new Promise((yes,no)=>{
  let settled=false,busy=false;const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timer);watcher.close();signal?.removeEventListener('abort',cancel);
   error?no(error):yes(value);};
  const check=async()=>{if(busy||settled)return;busy=true;try{const bytes=await readFile(path);require(now()<deadline,'Original deadline expired at worker publication');finish(null,bytes);}
   catch(error){if(error.code!=='ENOENT')finish(error);}finally{busy=false;}};
  const watcher=watchDirectory(dirname(path),(_event,name)=>{if(String(name)===path.split(/[\\/]/).at(-1))void check();});
  watcher.on('error',error=>finish(error));
  const timer=setTimeout(()=>finish(new Error('Owned worker did not close a result before the original deadline')),Math.max(1,deadline-now()));
  const cancel=()=>finish(new Error('Host wait aborted; original worker evidence is preserved'));
  signal?.addEventListener('abort',cancel,{once:true});if(signal?.aborted)cancel();else void check();
 });
}

// Source-pinned, read-only OS capture; no service launch/restart/kill is involved.
export function runtimeCaptureScript(manifestPath,sessionWorkspace){
 const quote=v=>"'"+String(v).replaceAll("'","''")+"'";
 return `$ErrorActionPreference='Stop'
$taskManifestPath=${quote(resolve(manifestPath))}
$taskWorkspace=${quote(resolve(sessionWorkspace).replaceAll('\\','/').toLowerCase())}
$taskDaemonWorkspace=${quote(ROOT.replaceAll('\\','/').toLowerCase())}
$taskManifest=Get-Content -LiteralPath $taskManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if($taskManifest.status -ne 'passed_local_repair' -or $taskManifest.repair_version -ne 2 -or $taskManifest.new_event -ne 'x/host/session-title/diagnostics' -or $taskManifest.local_runtime_build.exit_code -ne 0){throw 'Pinned runtime repair differs'}
$taskAll=@(Get-CimInstance Win32_Process | Where-Object {$_.Name -eq 'node.exe'})
$taskDirectory=[IO.Path]::GetFullPath($taskManifest.runtime_directory)
$taskWeb=@($taskAll | Where-Object {$_.CommandLine -like ('*'+(Join-Path $taskDirectory 'agnes.mjs')+'*') -and $_.CommandLine -match '\\bserve\\b'})
$taskWorkspacePattern='(?:^|\\s)"?--workspace"?\\s+"?'+[regex]::Escape($taskDaemonWorkspace)+'"?(?:\\s|$)'
$taskDaemon=@($taskAll | Where-Object {$_.CommandLine -like ('*'+(Join-Path $taskDirectory 'daemon.mjs')+'*') -and $_.CommandLine.Replace('\\','/').ToLowerInvariant() -match $taskWorkspacePattern})
if($taskWeb.Count -ne 1 -or $taskDaemon.Count -ne 1 -or $taskDaemon[0].ParentProcessId -ne $taskWeb[0].ProcessId){throw 'Owned web/daemon chain differs'}
$taskWorker=@($taskAll | Where-Object {$_.CommandLine -like ('*'+(Join-Path $taskDirectory 'worker.mjs')+'*') -and $_.ParentProcessId -eq $taskDaemon[0].ProcessId})
if($taskWorker.Count -ne 1){throw 'Owned worker differs'}
$taskListeners=@(Get-NetTCPConnection -LocalPort 4177 -State Listen)
if($taskListeners.Count -lt 1 -or @($taskListeners | Where-Object {$_.OwningProcess -ne $taskWeb[0].ProcessId}).Count){throw 'Web listener owner differs'}
$taskRows=@();$taskBundles=@()
foreach($taskRole in @('web','daemon','worker')){
 $taskProcess=if($taskRole -eq 'web'){$taskWeb[0]}elseif($taskRole -eq 'daemon'){$taskDaemon[0]}else{$taskWorker[0]}
 $taskRows += [ordered]@{role=$taskRole;pid=[int]$taskProcess.ProcessId;parent_pid=[int]$taskProcess.ParentProcessId;executable=$taskProcess.ExecutablePath;command_line=$taskProcess.CommandLine;started_at=$taskProcess.CreationDate.ToUniversalTime().ToString('o')}
 $taskName=if($taskRole -eq 'web'){'agnes.mjs'}else{$taskRole+'.mjs'}
 $taskPath=Join-Path $taskDirectory $taskName;$taskHash=(Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()
 $taskPin=@($taskManifest.runtime_files | Where-Object {$_.path -eq $taskPath})
 if($taskPin.Count -ne 1 -or $taskPin[0].sha256 -ne $taskHash){throw 'Actual loaded bundle hash changed'}
 $taskBundles += [ordered]@{path=$taskPath;sha256=$taskHash}
}
$taskBuild=Get-Item -LiteralPath $taskManifest.local_runtime_build.path
if((Get-FileHash -LiteralPath $taskBuild.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskManifest.local_runtime_build.sha256){throw 'Build receipt changed'}
[ordered]@{captured_at=[DateTime]::UtcNow.ToString('o');workspace_root=$taskWorkspace;daemon_workspace_root=$taskDaemonWorkspace;web_port=4177;web_port_owner_pid=[int]$taskWeb[0].ProcessId;processes=$taskRows;bundles=$taskBundles;build_completed_at=$taskBuild.LastWriteTimeUtc.ToString('o')} | ConvertTo-Json -Depth 6 -Compress`;
}

async function productionDependencies(protocol,protocolPath,protocolHash){
 const loaded=await readModelProtocol(protocolPath,protocolHash);
 const deployment=await checkedPin(protocol.deployment),recordPath=join(protocol.output_directory,'run_result.json');
 require(deployment.kind==='resolution_research_mcp_deployment_v1'&&deployment.workspace_root===protocol.scope_policy.workspace_root
  &&deployment.task_id===protocol.scope_policy.task_id&&deployment.request_id===protocol.scope_policy.request_id
  &&Math.round(deployment.started_epoch*1000)===protocol.scope_policy.started_epoch_ms&&Math.round(deployment.deadline_epoch*1000)===protocol.scope_policy.deadline_epoch_ms
  &&deployment.deadline_epoch===deployment.started_epoch+2400&&deployment.deadline_monotonic===deployment.started_monotonic+2400,
  'Host and MCP original clocks/identity differ');
 for(const path of [protocolPath,protocol.output_directory,protocol.domain_task_directory,protocol.scope_policy.workspace_root,
  protocol.scope_candidate_path,protocol.scope_activation_path,protocol.mcp_activation_path])scopedPath(path,ROOT);
 require(resolve(dirname(protocolPath))===resolve(protocol.output_directory),'Host protocol and output ownership differ');
 const pins=async()=>{
  for(const name of ['deployment','source_lock','runtime_version','runner_source','task_prompt'])await checkedPin(protocol[name],{json:false});
  require(sha(await readFile(protocolPath))===protocolHash,'Original host protocol bytes changed');
  const lock=await checkedPin(protocol.source_lock);require(lock.kind==='resolution_research_mcp_source_lock_v1'&&lock.status==='passed_engineering_only'&&lock.fixture_only===false,'Engineering source lock is not accepted');
  require(Array.isArray(lock.files)&&lock.files.length>0,'Source inventory absent');const seen=new Set();
  for(const row of lock.files){require(exact(row,['path','sha256','size_bytes'])&&!seen.has(normalizePath(row.path)),'Malformed/duplicate source row');
   seen.add(normalizePath(row.path));require(stable(await filePin(row.path))===stable(row),'Frozen source bytes changed');}
  for(const member of [protocol.runner_source.path,protocol.task_prompt.path,join(ROOT,'tools/verify_resolution_research_model_v1.py'),
   join(ROOT,'tools/agh_ws_client.mjs'),join(ROOT,'tools/agh_ts_loader.mjs'),join(ROOT,'tools/test_resolution_research_model_v1.mjs')])
   require(seen.has(normalizePath(member)),'Host source inventory omits '+member);
  const runtime=await checkedPin(protocol.runtime_version);require(runtime.status==='passed_local_repair'&&runtime.repair_version===2,'Runtime version differs');
  for(const member of runtime.runtime_files){require(sha(await readFile(member.path))===member.sha256&&sha(await readFile(member.archive))===member.sha256,'Original runtime/archive changed');}
 };
 await pins();let saved=false;
 const registry=join(dirname(protocol.deployment.path),'mcp-owned');
 const workerArgs=['-X','utf8','-B','-m','defect_researcher.resolution_research_mcp_v1','--inspect',
  '--protocol',protocol.deployment.path,'--expected-protocol-sha256',protocol.deployment.sha256,
  '--source-lock',protocol.source_lock.path,'--expected-lock-sha256',protocol.source_lock.sha256];
 const [{webClient,origin},{exportSession}]=await Promise.all([import('./agh_ws_client.mjs'),import('../../agnes-harness/packages/cli/src/commands/export.ts')]);
 const clock={now:()=>Date.now(),monotonic:()=>Number(process.hrtime.bigint()/1000000n)};
 return{[productionBrand]:true,fixtureOnly:false,protocolPath,protocolHash,clock,prompt:await readFile(protocol.task_prompt.path,'utf8'),
  checkPins:pins,clientFactory:webClient,
  async liveCheck(){const candidate=await readCandidate(loaded),
   activation=decode(await readFile(protocol.scope_activation_path,'utf8')),mcp=decode(await readFile(protocol.mcp_activation_path,'utf8'));
   require(candidate.model_protocol_sha256===protocolHash&&candidate.fixture_only===false
    &&activation.model_protocol_sha256===protocolHash&&activation.complete===true&&activation.fixture_only===false&&activation.after?.trusted===true&&activation.after?.actual==='running'
    &&mcp.model_protocol_sha256===protocolHash&&mcp.status==='passed'&&mcp.fixture_only===false&&obj(mcp.checks)&&Object.values(mcp.checks).every(v=>v===true)
    &&stable(mcp.after?.definition)===stable(serverDefinition(protocol)),'Scope/MCP activation receipt differs');
   for(const member of candidate.files)require(sha(await readFile(member.path))===member.sha256,'Generated scope source changed');
   const request=async(path,body)=>{const r=await fetch(origin+path,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},
    body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});require(r.ok,'Official admin status unavailable');return r.json();};
   const live=(await request('/admin/plugins/api/list',{profile:'local-dev'})).packages?.find(x=>x.id===activation.package_id);
   require(live?.trusted===true&&live.actual==='running'&&live.actualIntegrity===activation.after.actualIntegrity,'Live scope plugin changed');
   const status=await request('/admin/resources/api/mcp/status',{profile:'local-dev',serverId:SERVER_ID});
   require(status.connectionState==='ready'&&status.toolCount===2,'Scientific MCP is not ready with exactly two tools');
   return{scope_candidate:await filePin(protocol.scope_candidate_path),scope_activation:await filePin(protocol.scope_activation_path),
    mcp_activation:await filePin(protocol.mcp_activation_path),live_plugin:live,live_mcp:status};
  },
  async captureRuntime(){const result=await spawn(protocol.powershell_executable,['-NoProfile','-NonInteractive','-Command',runtimeCaptureScript(protocol.runtime_version.path,protocol.scope_policy.workspace_root)],
   {cwd:ROOT,windowsHide:true,timeout:25000,maxBuffer:1024*1024});return decode(result.stdout.replace(/^\uFEFF/,''));},
  async waitWorker(phase,{signal,outerDeadline,domainDeadline}){
   const path=join(registry,phase+'-result.json');await waitForOwnedFile(path,{signal,deadline:domainDeadline===null?outerDeadline:Math.min(outerDeadline,domainDeadline)});
   await pins();const result=await spawn(protocol.python_executable,workerArgs,{cwd:ROOT,windowsHide:true,timeout:15000,maxBuffer:1024*1024});
   const notification=decode(result.stdout.replace(/^\uFEFF/,'')),wrapper=decode(await readFile(path,'utf8'));
   require(wrapper.phase===phase&&wrapper.task_id===deployment.task_id&&wrapper.fixture_only===false&&wrapper.result?.task_id===deployment.task_id,'Owned worker wrapper differs');
   const science=wrapper.result,summary=science.ledger??science.final_budget;
   if(phase==='preflight'){
    const actual=await filePin(path);require(stable(notification.preflight_worker_result)===stable(actual)
     &&notification.phase==='preflight'&&notification.known_cost===true&&notification.new_prediction_calls===0&&notification.deadline_reset===false
     &&stable(notification.evidence)===stable(science)&&notification.worker_status===science.status
     &&wrapper.request_id===deployment.request_id&&stable(wrapper.deployment)===stable(protocol.deployment)
     &&stable(wrapper.source_lock)===stable(protocol.source_lock)&&wrapper.outer_started_epoch===deployment.started_epoch
     &&wrapper.outer_deadline_epoch===deployment.deadline_epoch&&wrapper.outer_started_monotonic===deployment.started_monotonic
     &&wrapper.outer_deadline_monotonic===deployment.deadline_monotonic&&wrapper.deadline_reset===false,'Preflight wrapper/inspect/source/outer clock binding differs');
    if(science.status==='preflight_passed'){
     const receipt=await filePin(join(protocol.domain_task_directory,'staged_preflight_receipt.json'));
     require(stable(notification.preflight_receipt)===stable(receipt)&&stable(wrapper.preflight_receipt)===stable(receipt)
      &&stable(decode(await readFile(receipt.path,'utf8')))===stable(science),'Preflight staged receipt changed');
    }else require(notification.status==='preflight_failed'&&science.status==='failed','Preflight terminal failed shape differs');
    return{...notification,worker_result:actual};
   }
   const known=summary?.cost_known===true&&summary.open_call===null&&summary.failed_detector_call===false;
   if(science.status==='recovery_pending')require(known&&summary.prediction_calls===2564&&science.deadline_reset===false,'Unknown/unclosed initial cost cannot continue');
   if(science.status==='completed')require(known&&summary.prediction_calls===3205&&science.real_recovery_accepted===true,'Actual completed recovery budget differs');
   return{...notification,worker_result:await filePin(path),known_cost:known,worker_status:science.status};
  },
  async exportSession(sessionId,format){const path=join(protocol.output_directory,format==='agnes'?'session.jsonl':'session.html'),client=await webClient();
   try{await exportSession({positional:[sessionId],format,raw:false,out:path},{cwd:protocol.scope_policy.workspace_root,
    io:{stdout:process.stdout,stderr:process.stderr},writeFile:(p,b)=>writeFile(p,b,{flag:'wx'})},client);
    return{format,raw:false,...await filePin(path),mask_boundary:'Official masked export may change inner JSON numeric text; exact domain/SDK artifacts remain separately pinned.'};
   }finally{await client.close();}},
  async save(record){await atomicRecord(recordPath,record,{exclusive:!saved});saved=true;}
 };
}

async function main(){
 const args=process.argv.slice(2);require(args.length===4&&args[0]==='--protocol'&&args[2]==='--expected-sha256','Use --protocol <frozen path> --expected-sha256 <hash>');
 const protocolPath=resolve(args[1]),protocolHash=args[3];require(/^[0-9a-f]{64}$/.test(protocolHash)&&sha(await readFile(protocolPath))===protocolHash,'Original host protocol pin differs');
 const protocol=validateProtocol(decode(await readFile(protocolPath,'utf8')));const deps=await productionDependencies(protocol,protocolPath,protocolHash);
 const record=await runResearchSession(protocol,deps);
 if(record.runtime_before&&record.runtime_after)await atomicRecord(join(protocol.output_directory,'runtime_binding.json'),{
  schema_version:1,session_id:record.session_id,workspace_root:record.workspace_root,runtime_manifest:protocol.runtime_version,
  build_completed_at:record.runtime_before.build_completed_at,
  before:record.runtime_before,after:record.runtime_after,started_epoch_ms:record.started_epoch_ms,
  model_started_epoch_ms:record.model_started_epoch_ms,finished_epoch_ms:record.runtime_execution_finished_epoch_ms},{exclusive:true});
 if(record.runtime_before&&record.runtime_after)record.runtime_binding=await filePin(join(protocol.output_directory,'runtime_binding.json'));
 record.finished_epoch_ms=Date.now();record.finished_at=new Date(record.finished_epoch_ms).toISOString();
 if(record.finished_epoch_ms>=record.deadline_epoch_ms){record.status='failed';record.science_accepted=false;
  record.failure??={type:'DeadlineError',message:'Original outer deadline expired during runtime binding publication'};}
 await deps.save(record);
 console.log(JSON.stringify({status:record.status,session_id:record.session_id,actual_total_model_requests:record.actual_total_model_requests,
  science_accepted:record.science_accepted,failure:record.failure,cost_failure:record.cost_failure}));
 if(record.status!=='completed')process.exitCode=1;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(error=>{console.error(JSON.stringify(failure(error)));process.exitCode=1;});
