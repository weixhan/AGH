"""Exclusively copy V13 into a fresh V14; original failed evidence stays frozen.

The new acceptance rules are applied before any V14 registration. This generator
is inert on import and verifies every original V13 member before copying.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
BASELINE_SHA256 = 'b05f74c5cd4a88a06204844d38301ca67a38fc259845636e64502349cebcd51e'
MEMBERS = ('comparison_scope_guard', 'test_comparison_scope_guard',
           'prepare_comparison_scope', 'enable_comparison_scope',
           'activate_comparison_mcp', 'diagnose_comparison_mcp',
           'reconcile_comparison_mcp', 'run_comparison_suite')

def convert(value):
    return value.replace('v13', 'v14').replace('V13', 'V14').replace('cmp13', 'cmp14')

def source(name):
    if name not in MEMBERS:
        raise ValueError('Unknown V14 adapter member')
    return convert((ROOT / 'tools' / (name + '_v13.mjs')).read_text('utf8'))

def main():
    frozen_path = ROOT / 'outputs/comparison-implementation-v13-diagnostic/freeze.json'
    data = frozen_path.read_bytes()
    if hashlib.sha256(data).hexdigest() != BASELINE_SHA256:
        raise ValueError('Original V13 failed freeze changed')
    frozen = json.loads(data)
    for group in ('sources', 'archive', 'proof_files'):
        for record in frozen[group]:
            payload = Path(record['path']).read_bytes()
            if len(payload) != record['size_bytes'] or hashlib.sha256(payload).hexdigest() != record['sha256']:
                raise ValueError('Original V13 member changed: ' + record['path'])
    from tools.verify_comparison_model_v13 import SOURCE_MEMBERS
    selected = [name for name in SOURCE_MEMBERS if '_v13' in name]
    selected.remove('tools/generate_comparison_suite_v13.py')
    destinations = {name: ROOT / convert(name) for name in selected}
    if any(path.exists() for path in destinations.values()):
        raise FileExistsError('Fresh V14 destination exists; refusing replacement')
    for name, path in destinations.items():
        with path.open('x', encoding='utf8', newline='\n') as stream:
            stream.write(convert((ROOT / name).read_text('utf8')))
    print(json.dumps({'status':'copied_not_registered', 'members':len(destinations),
                      'v13_baseline_sha256':BASELINE_SHA256}))

if __name__ == '__main__':
    main()
