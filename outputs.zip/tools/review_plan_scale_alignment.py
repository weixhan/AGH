"""Post-hoc, read-only scale review of sealed 640/960 validation predictions.

No detector, production scorer, or production matching function is imported.
This review does not rewrite preregistration, a scientific gate, or old evidence.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re


TASK_ID = "8d1d6900c7d74c90a29824495684807d"
TOOL = "compare_validation_resolutions"
COMPLETION_SHA = "2f39a8dd65f0459d98471d0c85fcee4ebe4992ff99fa7c43ba7ab49bc49d6d2d"
MANIFEST_SHA = "8ddcd950dffc70d9431d0a235ff3910cf099c95294b3756b9a8654708c401501"
ARTIFACT_NAMES = {
    "protocol.json", "inputs.json", "events.jsonl", "predictions_640.jsonl",
    "predictions_960.jsonl", "metrics_640.json", "metrics_960.json",
    "comparison.json", "comparison_report.md", "comparison_result.json",
}
SOURCE_ROLES = {
    "comparison_protocol", "comparison_runner", "dataset/data.yaml",
    "dataset/manifest.json", "detection_metrics", "training_manifest", "weights",
}
CONFIDENCE = .25
MATCHING_IOU = .5


class ScaleReviewError(ValueError):
    """Saved evidence is incomplete, changed, or incompatible with this review."""


def require(condition, message):
    if not condition:
        raise ScaleReviewError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _unique_object(items):
    result = {}
    for key, value in items:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _invalid_constant(value):
    raise ScaleReviewError(f"Non-finite JSON number: {value}")


def loads(text):
    try:
        return json.loads(text, object_pairs_hook=_unique_object,
                          parse_constant=_invalid_constant)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ScaleReviewError(f"Invalid JSON: {exc}") from exc


def read_json(path):
    require(Path(path).is_file(), f"Missing file: {path}")
    return loads(Path(path).read_text(encoding="utf-8"))


def _hash_string(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def verify_artifact_chain(task_directory, *, completion_sha=COMPLETION_SHA,
                          manifest_sha=MANIFEST_SHA):
    """Bind the sealed marker, ten artifacts, and seven declared source roles.

    Hash overrides exist for isolated checker tests. The CLI has no override.
    The historical 10256-file input scan is sealed, not repeated here.
    """
    directory = Path(task_directory).resolve()
    completion_path = directory / "completion.json"
    require(completion_path.is_file(), "Missing original completion marker")
    require(_hash_string(completion_sha) and sha(completion_path) == completion_sha,
            "Original completion hash mismatch")
    completion = read_json(completion_path)
    require(completion.get("task_id") == TASK_ID and completion.get("tool") == TOOL
            and completion.get("status") == "completed", "Original task identity/status mismatch")
    manifest_path = directory / "artifact_manifest.json"
    require(Path(completion.get("artifact_manifest", "")).resolve() == manifest_path,
            "Original manifest path mismatch")
    require(completion.get("artifact_manifest_sha256") == manifest_sha
            and manifest_path.is_file() and sha(manifest_path) == manifest_sha,
            "Original manifest hash mismatch")
    manifest = read_json(manifest_path)
    require(manifest.get("task_id") == TASK_ID and manifest.get("tool") == TOOL
            and manifest.get("status") == "completed", "Manifest identity/status mismatch")
    files = manifest.get("files")
    require(isinstance(files, list) and len(files) == len(ARTIFACT_NAMES),
            "Manifest must bind exactly ten artifacts")
    require(isinstance(completion.get("artifacts_sha256"), dict)
            and set(completion["artifacts_sha256"]) == ARTIFACT_NAMES,
            "Completion artifact set mismatch")
    checked = []
    seen = set()
    for entry in files:
        require(isinstance(entry, dict), "Invalid manifest entry")
        name = entry.get("name")
        require(name in ARTIFACT_NAMES and name not in seen, "Manifest artifact membership mismatch")
        seen.add(name)
        path = directory / name
        require(Path(entry.get("path", "")).resolve() == path,
                f"Artifact path mismatch: {name}")
        require(path.is_file(), f"Missing artifact: {name}")
        require(type(entry.get("size_bytes")) is int
                and path.stat().st_size == entry["size_bytes"], f"Artifact size mismatch: {name}")
        expected = entry.get("sha256")
        require(_hash_string(expected) and expected == completion["artifacts_sha256"][name]
                and sha(path) == expected, f"Artifact hash mismatch: {name}")
        checked.append({"role": name, "path": str(path), "sha256": expected})
    require(seen == ARTIFACT_NAMES, "Missing manifest artifact")
    source = manifest.get("input_evidence")
    require(isinstance(source, dict) and set(source) == SOURCE_ROLES,
            "Declared source set mismatch")
    inputs = read_json(directory / "inputs.json")
    require(inputs.get("task_id") == TASK_ID and inputs.get("all_unchanged") is True,
            "Stored input evidence identity/status mismatch")
    input_files = inputs.get("files")
    require(isinstance(input_files, list), "Stored input list missing")
    bound_roles = {}
    for entry in input_files:
        require(isinstance(entry, dict) and entry.get("unchanged") is True
                and _hash_string(entry.get("sha256_before"))
                and entry.get("sha256_before") == entry.get("sha256_after"),
                "Stored input chain contains changed or unbound source")
        role = entry.get("role")
        if role in SOURCE_ROLES:
            require(role not in bound_roles, f"Duplicate declared source role: {role}")
            bound_roles[role] = entry
    require(set(bound_roles) == SOURCE_ROLES, "Stored declared source bindings missing")
    for role, entry in source.items():
        require(isinstance(entry, dict), f"Invalid source binding: {role}")
        path = Path(entry.get("path", "")).resolve()
        bound = bound_roles[role]
        require(path == Path(bound.get("path", "")).resolve()
                and entry.get("sha256") == bound["sha256_before"],
                f"Declared source binding mismatch: {role}")
        require(path.is_file() and path.stat().st_size == bound.get("size_bytes")
                and sha(path) == entry["sha256"], f"Current declared source hash mismatch: {role}")
        checked.append({"role": role, "path": str(path), "sha256": entry["sha256"]})
    checked.extend([
        {"role": "original_completion", "path": str(completion_path), "sha256": completion_sha},
        {"role": "original_manifest", "path": str(manifest_path), "sha256": manifest_sha},
    ])
    return {"task_id": TASK_ID, "original_completion_sha256": completion_sha,
            "original_manifest_sha256": manifest_sha, "sealed_artifact_count": 10,
            "current_declared_source_hashes_verified": len(SOURCE_ROLES),
            "stored_input_count": len(input_files), "original_all_inputs_rehashed": False,
            "bindings": checked}


def _number(value):
    return type(value) in (int, float) and math.isfinite(value)


def _validate_box(box, width, height, *, prediction):
    require(isinstance(box, dict), "Invalid box record")
    require(type(box.get("class_id")) is int and 0 <= box["class_id"] <= 6,
            "Invalid class identifier")
    xyxy = box.get("xyxy")
    require(isinstance(xyxy, list) and len(xyxy) == 4 and all(_number(x) for x in xyxy),
            "Invalid box coordinates")
    x1, y1, x2, y2 = xyxy
    require(x1 < x2 and y1 < y2, "Degenerate or reversed box")
    # Eight-decimal YOLO labels can reconstruct an edge a few 1e-5 px outside.
    # Preserve sealed coordinates; no clipping/reprojection is performed.
    tolerance = 0 if prediction else 1e-4
    require(x1 >= -tolerance and y1 >= -tolerance and x2 <= width + tolerance
            and y2 <= height + tolerance, "Box outside original dimensions")
    if prediction:
        require(_number(box.get("confidence")) and 0 <= box["confidence"] <= 1,
                "Invalid confidence")


def validate_records(records, image_ids, size):
    require(isinstance(records, list) and isinstance(image_ids, list)
            and len(set(image_ids)) == len(image_ids), "Invalid expected image membership")
    require(len(records) == len(image_ids), "Incomplete prediction members")
    require(all(isinstance(record, dict) for record in records), "Invalid prediction record")
    ids = [record.get("image_id") for record in records]
    require(all(isinstance(identifier, str) and identifier for identifier in ids)
            and len(set(ids)) == len(ids) and set(ids) == set(image_ids),
            "Prediction image membership mismatch")
    result = {}
    for record in records:
        require(type(record.get("width")) is int and record["width"] > 0
                and type(record.get("height")) is int and record["height"] > 0,
                "Invalid original dimensions")
        require(record.get("split") == "val" and type(record.get("eval_imgsz")) is int
                and record["eval_imgsz"] == size and record.get("precision") == "FP32"
                and record.get("device") == "0", "Saved prediction controls mismatch")
        for key in ("ground_truth", "predictions"):
            require(isinstance(record.get(key), list), f"Missing box list: {key}")
            for box in record[key]:
                _validate_box(box, record["width"], record["height"], prediction=key == "predictions")
        result[record["image_id"]] = record
    return result


def _overlap(a, b):
    intersection = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(
        0, min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    return intersection / union


def match_image(record):
    """Confidence descending, saved-index tie break, same-class greedy matching.

    Choose highest IoU among unmatched eligible GT; exact IoU ties choose the
    earlier saved GT index. Match all GT before counting scale subsets.
    """
    truth = record["ground_truth"]
    matched = set()
    kept = [(index, box) for index, box in enumerate(record["predictions"])
            if box["confidence"] >= CONFIDENCE]
    kept.sort(key=lambda pair: (-pair[1]["confidence"], pair[0]))
    for _, prediction in kept:
        eligible = [(index, _overlap(prediction["xyxy"], box["xyxy"]))
                    for index, box in enumerate(truth)
                    if index not in matched and box["class_id"] == prediction["class_id"]]
        eligible = [(index, overlap) for index, overlap in eligible if overlap >= MATCHING_IOU]
        if eligible:
            index, _ = min(eligible, key=lambda pair: (-pair[1], pair[0]))
            matched.add(index)
    return matched, len(kept) - len(matched)


def analyse_records(groups, image_ids):
    validated = {size: validate_records(groups[size], image_ids, size) for size in (640, 960)}
    identity_keys = ("width", "height", "ground_truth", "split", "image_path",
                     "source_path", "label_path", "metadata_path")
    for identifier in image_ids:
        first, second = validated[640][identifier], validated[960][identifier]
        require(all(first.get(key) == second.get(key) for key in identity_keys),
                f"Paired original dimensions/GT/source identity mismatch: {identifier}")
    definitions = {
        "plan_area_ratio_lt_0_005": "original HBB area / (original width * original height) < 0.005",
        "implemented_area_lt_1024_px2": "original HBB area < 32 * 32 pixels squared",
    }
    summaries = {}
    details = []
    dimensions = Counter()
    for identifier in image_ids:
        record = validated[640][identifier]
        dimensions[f"{record['width']}x{record['height']}"] += 1
    for size in (640, 960):
        totals = {name: {"gt": 0, "tp": 0, "fn": 0} for name in definitions}
        overall = {"gt": 0, "tp": 0, "fp": 0, "fn": 0}
        for identifier in image_ids:
            record = validated[size][identifier]
            matched, fp = match_image(record)
            overall["gt"] += len(record["ground_truth"])
            overall["tp"] += len(matched)
            overall["fp"] += fp
            overall["fn"] += len(record["ground_truth"]) - len(matched)
            for index, box in enumerate(record["ground_truth"]):
                x1, y1, x2, y2 = box["xyxy"]
                area = (x2 - x1) * (y2 - y1)
                ratio = area / (record["width"] * record["height"])
                selected = {"plan_area_ratio_lt_0_005": ratio < .005,
                            "implemented_area_lt_1024_px2": area < 1024}
                for name, included in selected.items():
                    if included:
                        totals[name]["gt"] += 1
                        totals[name]["tp"] += int(index in matched)
                        totals[name]["fn"] += int(index not in matched)
                if any(selected.values()):
                    details.append({"eval_imgsz": size, "image_id": identifier,
                                    "gt_index": index, "class_id": box["class_id"],
                                    "original_hbb_area_px2": area, "original_hbb_area_ratio": ratio,
                                    "scale_membership": selected, "matched": index in matched})
        for value in [overall, *totals.values()]:
            value["recall"] = value["tp"] / value["gt"] if value["gt"] else None
        summaries[str(size)] = {"overall": overall, "scale_definitions": totals}
    return {"definitions": definitions, "original_dimensions": dict(dimensions),
            "images": len(image_ids), "operating_confidence": CONFIDENCE,
            "matching_iou": MATCHING_IOU,
            "matching_rule": "same-class confidence-descending one-to-one greedy; saved prediction index and GT index break exact ties",
            "results": summaries, "selected_gt_details": details}


def review(task_directory):
    directory = Path(task_directory).resolve()
    chain = verify_artifact_chain(directory)
    protocol = read_json(directory / "protocol.json")
    require(protocol.get("task_id") == TASK_ID and protocol.get("protocol_id") == "same-weight-val-resolution-v1"
            and protocol.get("split") == "val" and protocol.get("expected_images") == 640
            and protocol.get("train_imgsz") == 640 and protocol.get("eval_imgsz") == [640, 960]
            and protocol.get("operating_confidence") == CONFIDENCE
            and protocol.get("matching_iou") == MATCHING_IOU
            and protocol.get("selection_data") == "validation_only"
            and protocol.get("test_inference") is False
            and protocol.get("training_performed") is False
            and protocol.get("weight_change") is False, "Frozen comparison protocol mismatch")
    image_ids = protocol.get("image_ids")
    inputs = read_json(directory / "inputs.json")
    require(isinstance(image_ids, list) and len(image_ids) == 640
            and image_ids == inputs.get("validation_image_ids"), "Stored/protocol image membership mismatch")
    groups = {}
    for size in (640, 960):
        lines = (directory / f"predictions_{size}.jsonl").read_text(encoding="utf-8").splitlines()
        require(all(line.strip() for line in lines), "Empty prediction record")
        groups[size] = [loads(line) for line in lines]
    statistics = analyse_records(groups, image_ids)
    require(statistics["results"]["640"]["overall"]["gt"] == 596, "Original validation GT count mismatch")
    for size in (640, 960):
        saved = read_json(directory / f"metrics_{size}.json")
        point = saved.get("operating_point", {})
        fresh = statistics["results"][str(size)]
        require(all(point.get(key) == fresh["overall"][key] for key in ("tp", "fp", "fn")),
                f"Independent operating-point reproduction mismatch: {size}")
        tiny = fresh["scale_definitions"]["implemented_area_lt_1024_px2"]
        require(point.get("small_gt") == tiny["gt"] and point.get("small_fn") == tiny["fn"],
                f"Independent old scale reproduction mismatch: {size}")
    require(all(Path(entry["path"]).is_file() and sha(entry["path"]) == entry["sha256"]
                for entry in chain["bindings"]), "Source changed during review")
    return {"schema_version": 1, "purpose": "posthoc_plan_scale_alignment_review",
            "review_date": "2026-10-12", "reviewed_at": datetime.now(timezone.utc).isoformat(),
            "status": "passed", "source_task_id": TASK_ID, "posthoc_no_new_inference": True,
            "new_model_requests": 0, "new_detector_predictions": 0,
            "preregistration_modified": False, "old_scientific_gate_modified": False,
            "old_completion_modified": False, "same_weight_evaluation_size_comparison": True,
            "training_resolution_effect_established": False, "source_chain": chain,
            "statistics": statistics,
            "limitations": [
                "Supplemental descriptive calculation dated 2026-10-12; not a replacement preregistration or acceptance gate.",
                "The old area<1024 px2 result remains valid only for that definition; it cannot be relabelled as the plan's area ratio<0.005 result.",
                "Sealed saved validation predictions were used; seven declared source hashes were checked, but the historical 10256-file scan was not repeated.",
                "No new inference, training or test-set evaluation; results do not establish training-size effects, test performance or stable superiority.",
            ]}


def write_review(report, output_directory):
    output = Path(output_directory).resolve()
    source = Path(report["source_chain"]["bindings"][-2]["path"]).parent
    require(source != output and source not in output.parents, "Refusing output inside original task")
    require(not output.exists(), "Review output must be a new directory")
    output.mkdir(parents=True)
    (output / "scale_alignment.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    stats = report["statistics"]
    lines = ["# 原方案与实际小缺陷口径补统计", "", "2026-10-12 事后只读说明；使用封存的同权重 640/960 验证集预测，无新增推理。", "",
             "| 口径 | GT | 640 TP / FN / 召回 | 960 TP / FN / 召回 |", "| --- | ---: | --- | --- |"]
    for name, label in (("plan_area_ratio_lt_0_005", "原方案：原图 HBB 面积比 < 0.5%"),
                        ("implemented_area_lt_1024_px2", "旧实现：原图 HBB 面积 < 32² 像素")):
        a, b = [stats["results"][str(size)]["scale_definitions"][name] for size in (640, 960)]
        lines.append(f"| {label} | {a['gt']} | {a['tp']} / {a['fn']} / {a['recall']:.6%} | {b['tp']} / {b['fn']} / {b['recall']:.6%} |")
    a, b = [stats["results"][str(size)]["overall"] for size in (640, 960)]
    lines.extend(["", f"总体固定 conf=0.25、同类 IoU≥0.5：640 TP={a['tp']}、FP={a['fp']}、FN={a['fn']}；960 TP={b['tp']}、FP={b['fp']}、FN={b['fn']}。",
                  "", "原方案口径存在描述性小缺陷召回改善，同时总体召回下降、误报增多。AP 请引用原任务已封存结果，本补统计未重新计算 AP。",
                  "", "不能把旧 32² 口径的结论追认为 0.5% 口径；不能修改原预登记标准、科学判定、completion 或解释为 960 训练效果。",
                  "", "核验范围：原 completion→manifest→10 个产物，以及 manifest 声明的 7 项当前源哈希；未重做原 10256 项全数据输入扫描。",
                  "", f"源任务：`{TASK_ID}`；completion SHA256：`{COMPLETION_SHA}`；manifest SHA256：`{MANIFEST_SHA}`。",
                  "", "逐 GT 子集成员、原像素面积/面积比和匹配结果见 [scale_alignment.json](scale_alignment.json)。"])
    (output / "补统计说明.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    manifest = {"purpose": report["purpose"], "files": [
        {"name": name, "sha256": sha(output / name), "size_bytes": (output / name).stat().st_size}
        for name in ("scale_alignment.json", "补统计说明.md")],
        "reviewer_source": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))}}
    manifest_path = output / "artifact_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output / "completion.json").write_text(json.dumps({"status": "passed", "purpose": report["purpose"],
        "manifest_sha256": sha(manifest_path), "source_task_id": TASK_ID,
        "posthoc_no_new_inference": True}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task-dir", type=Path, default=Path(__file__).resolve().parents[1] / "outputs" / TASK_ID)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = review(args.task_dir)
    write_review(report, args.output)
    print(json.dumps({"status": report["status"], "output": str(args.output.resolve()),
                      "results": report["statistics"]["results"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
