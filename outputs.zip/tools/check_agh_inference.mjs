// Separate minimal inference diagnosis; this is never counted as LabelGuard acceptance.
import { writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { webClient } from './agh_ws_client.mjs';

const client = await webClient();
const record = { checked_at: new Date().toISOString(), diagnostic_only: true, tool_execution_authorized: false,
  credential_read: false, config_changed: false };
let session;
try {
  session = await client.session.new({ cwd: process.cwd(), sessionKey: randomUUID() });
  record.session_id = session.id;
  session.onPermissionRequest(async () => ({ verdict: 'rejected' }));
  await session.setModel({ slot: 'primary', route: 'account-defect-researcher', model: 'agnes-3.0-flash' });
  record.result = await session.prompt('这是连接测试，请仅回复“连接正常”，不要调用任何工具。');
  record.passed = record.result.stopReason === 'end_turn' && record.result.reason === 'completed';
} catch (error) {
  record.passed = false;
  record.failure = { type: error.name, code: error.code, reason: error.data?.reason, message: error.message };
} finally {
  await client.close();
  await writeFile('outputs/agh-label-repair/inference-check.json', JSON.stringify(record, null, 2) + '\n');
  console.log(JSON.stringify(record));
  if (!record.passed) process.exitCode = 1;
}
