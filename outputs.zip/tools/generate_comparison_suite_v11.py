"""Generate fixed stage adapters; only new V11 sources are written."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def source(name):
    return (ROOT / 'tools' / (name + '_v10.mjs')).read_text('utf8').replace('_v10', '_v11').replace('-v10', '-v11')


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Expected one fragment: ' + before[:90])
    return text.replace(before, after)


def save(name, text):
    with (ROOT / 'tools' / (name + '_v11.mjs')).open('x', encoding='utf8', newline='\n') as stream:
        stream.write(text)


def main():
    guard = source('comparison_scope_guard').replace('mcp_dr_compare_v11_[0-9a-f]', 'mcp_dr_compare_v11_(diagnostic|pilot|formal)_[0-9a-f]')
    save('comparison_scope_guard', guard)
    tests = source('test_comparison_scope_guard').replace('mcp_dr_compare_v11_12345678', 'mcp_dr_compare_v11_diagnostic_12345678')
    save('test_comparison_scope_guard', tests)
    text = source('prepare_comparison_scope')
    text = once(text, "const candidate=join(policy.workspace_root,'.agh/extensions/comparison-scope-guard-v11');", "if(!['diagnostic','pilot','formal'].includes(protocol.stage))throw new Error('Invalid frozen stage');\nconst scopeName='comparison-scope-guard-v11-'+protocol.stage;\nconst candidate=join(policy.workspace_root,'.agh/extensions/'+scopeName);")
    text = text.replace("name:'@defect-researcher/comparison-scope-guard-v11'", "name:'@defect-researcher/'+scopeName")
    text = text.replace("id:'ext:defect-researcher/comparison-scope-guard-v11'", "id:'ext:defect-researcher/'+scopeName")
    text = text.replace("package_id:'@defect-researcher/comparison-scope-guard-v11'", "package_id:'@defect-researcher/'+scopeName")
    save('prepare_comparison_scope', text)
    text = source('enable_comparison_scope')
    text = text.replace("'.agh/extensions/comparison-scope-guard-v11'", "'.agh/extensions/comparison-scope-guard-v11-'+protocol.stage")
    text = text.replace("const id = '@defect-researcher/comparison-scope-guard-v11',", "if(!['diagnostic','pilot','formal'].includes(protocol.stage))throw new Error('Invalid frozen stage');\nconst id = '@defect-researcher/comparison-scope-guard-v11-'+protocol.stage,")
    save('enable_comparison_scope', text)
    text = source('activate_comparison_mcp')
    text = once(text, "const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177',out=join(root,'outputs/comparison-pilot-v11');", "const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177',stage=process.argv[2];\nif(!['diagnostic','pilot','formal'].includes(stage))throw new Error('Stage argument required');\nconst out=join(root,'outputs/comparison-suite-v11-'+stage);")
    text = text.replace("serverId='dr-compare-v11'", 'serverId=protocol.server_id')
    text = text.replace('run_comparison_mcp_v9.py', 'run_comparison_mcp_v11.py')
    text = text.replace("qualified='mcp_dr_compare_v11_'+sha", "qualified='mcp_'+serverId.replaceAll('-','_')+'_'+sha")
    save('activate_comparison_mcp', text)
    text = source('run_comparison_pilot')
    text = once(text, "import {selectBranchDiagnostic} from './comparison_branch_selection_v11.mjs';", '')
    text = once(text, "const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),out=join(root,'outputs/comparison-pilot-v11');", "const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),stage=process.argv[2];\nif(!['diagnostic','pilot','formal'].includes(stage))throw new Error('Stage argument required');\nconst out=join(root,'outputs/comparison-suite-v11-'+stage);")
    text = text.replace('run_comparison_mcp_v9.py', 'run_comparison_mcp_v11.py')
    text = text.replace('defect_researcher.comparison_case_runtime_v1', 'defect_researcher.comparison_case_runtime_v11')
    text = text.replace("run('powershell.exe'", "run('C:/Users/han/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'")
    text = text.replace('tools/verify_comparison_runtime_v11.py', 'tools/verify_comparison_runtime_v10.py')
    text = text.replace('tools/capture_comparison_runtime_v11.ps1', 'tools/capture_comparison_runtime_v10.ps1')
    text = text.replace('tools/verify_comparison_case_v1.py', 'tools/verify_comparison_case_v11.py')
    text = once(text, "const suite={schema_version:1,status:'running',agh_core_modified:true,runtime_before:runtimeBefore,protocol_sha256:publicProtocol.protocol_sha256,model_requests_cap_total:14,phase_model_requests_cap_total:14,prior_closed_request_slots:0,request_slots_debited_before:0,historical_prior_slots_debited:46,historical_prior_phase_cap:48,legacy_token_usage_closed:true,historical_token_usage_closed:false,model_requests_observed:0,model_requests_actual:0,planned_trials:9,trials:[],new_detector_calls:0,gpu_seconds:0};", "const cap={diagnostic:14,pilot:42,formal:168}[stage];\nif(publicProtocol.stage!==stage||publicProtocol.phase_model_budget.total_cap!==cap||publicProtocol.selection_sha256!==sha(stable(publicProtocol.selection)))throw new Error('Frozen stage allocation differs');\nconst selected=protocol.trials.filter(t=>publicProtocol.selection.trial_handles.includes(t.trial_handle));\nif(selected.length!==publicProtocol.selection.selected_trial_count||stable(selected.map(t=>t.trial_handle))!==stable(publicProtocol.selection.trial_handles))throw new Error('Frozen full selection differs');\nconst suite={schema_version:1,status:'running',stage,agh_core_modified:true,runtime_before:runtimeBefore,protocol_sha256:publicProtocol.protocol_sha256,model_requests_cap_total:cap,phase_model_requests_cap_total:cap,prior_closed_request_slots:0,request_slots_debited_before:0,historical_prior_slots_debited:46,historical_prior_phase_cap:48,legacy_token_usage_closed:true,historical_token_usage_closed:false,model_requests_observed:0,model_requests_actual:0,planned_trials:protocol.trials.length,selected_trials:selected.length,trials:[],new_detector_calls:0,gpu_seconds:0};")
    text = text.replace('for(const trial of selectBranchDiagnostic(protocol,publicProtocol))', 'for(const trial of selected)')
    text = text.replace('suite.model_requests_observed+7>14', 'suite.model_requests_observed+7>cap')
    text = text.replace('suite.model_requests_observed>14', 'suite.model_requests_observed>cap')
    text = once(text, "if(verification.status==='passed'&&verification.native_title_cost_known===true&&verification.actual_total_model_requests===result.model_requests)suite.model_requests_actual=suite.model_requests_observed;", "if(verification.status==='passed'&&(trial.arm==='C'?verification.model_request_count===0:verification.native_title_cost_known===true&&verification.actual_total_model_requests===result.model_requests))suite.model_requests_actual=suite.model_requests_observed;")
    text = once(text, "  const runtimeCheck=join(out,'runtime_verification',trial.trial_handle+'.json');", "  if(trial.arm!=='C'){\n  const runtimeCheck=join(out,'runtime_verification',trial.trial_handle+'.json');")
    text = once(text, '  result.runtime_verification_path=runtimeCheck;', '  result.runtime_verification_path=runtimeCheck;\n  }')
    text = once(text, "  await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_case_v11.py'),directory,'--output',businessCheck],{cwd:root,windowsHide:true,timeout:45000});", "  try{await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_case_v11.py'),directory,'--output',businessCheck],{cwd:root,windowsHide:true,timeout:45000});}catch(error){if(stage==='diagnostic'||!error.stdout||!error.stdout.includes('failed'))throw error;}\n  const business=JSON.parse(await readFile(businessCheck,'utf8'));\n  if(!['passed','failed'].includes(business.status))throw new Error('Business observation unknown');")
    text = text.replace('suite.unexecuted_comparison_trials=7', 'suite.unexecuted_comparison_trials=protocol.trials.length-suite.trials.length')
    save('run_comparison_suite', text)


if __name__ == '__main__':
    main()
