"""Independent stdlib replay of version 2 prediction durability evidence.

This reader does not import the worker, journal writer, inference, or metric
implementation. It reconstructs calls and checkpoint publication from the
saved append-only evidence. Journal order proves recorded start-before-finish;
the bound writer and its tests supply the fsync-before-predict implementation.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import time

JOURNAL_FILE = "checkpoint_journal.jsonl"
CAPS = {"successful_observations": 5760, "max_formal_calls": 5770,
        "max_failed_pass_retries": 10, "max_warmup_calls": 1,
        "max_gpu_seconds": 900, "max_inference_wall_seconds": 900,
        "max_task_wall_seconds": 1800}
WALL = ("task_started_epoch", "inference_started_epoch", "gpu_seconds",
        "task_wall_seconds", "inference_wall_seconds", "resumable")
IDENTITY = {"protocol_sha256", "weight_sha256", "scientific_inputs_sha256",
            "execution_source_sha256", "journal_source_sha256"}


class JournalVerificationError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def sha_object(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha_file(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def decode(value):
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise JournalVerificationError("Duplicate JSON key")
            result[key] = item
        return result

    def invalid(value):
        raise JournalVerificationError("Nonfinite JSON value")

    try:
        result = json.loads(value, object_pairs_hook=unique, parse_constant=invalid)
        canonical(result)
        return result
    except (UnicodeError, json.JSONDecodeError, ValueError) as error:
        raise JournalVerificationError("Invalid, nonfinite or duplicate-key JSON") from error


def require(condition, message):
    if not condition:
        raise JournalVerificationError(message)


def number(value, *, nullable=False):
    return (nullable and value is None) or (type(value) in (int, float)
        and math.isfinite(value) and value >= 0)


def timestamp(value):
    require(isinstance(value, str), "Call timestamp is absent")
    try:
        result = datetime.fromisoformat(value)
    except ValueError as error:
        raise JournalVerificationError("Invalid call timestamp") from error
    require(result.tzinfo is not None and result.utcoffset() is not None, "Call timestamp lacks timezone")
    return result


def limits(protocol):
    result = protocol.get("budgets")
    require(isinstance(result, dict) and result.keys() == CAPS.keys(), "Budget contract fields differ")
    require(all(type(result[k]) is int and 0 <= result[k] <= cap for k, cap in CAPS.items()),
            "Scientific budget is invalid or relaxed")
    require(result["successful_observations"] > 0 and result["max_formal_calls"] >= result["successful_observations"],
            "Invalid successful observation budget")
    return deepcopy(result)


def wall_update(current, saved, unknown_gpu):
    require(isinstance(saved, dict) and saved.keys() == set(WALL), "Wall record fields differ")
    require(all(number(saved[k], nullable=k == "inference_started_epoch") for k in WALL[:-1])
        and type(saved["resumable"]) is bool, "Invalid recorded wall cost")
    require(saved["task_started_epoch"] == current["task_started_epoch"], "Absolute task start changed")
    previous = current["inference_started_epoch"]
    require(previous is None or saved["inference_started_epoch"] == previous, "Absolute inference start changed")
    inference = saved["inference_started_epoch"]
    require(inference is None or inference >= saved["task_started_epoch"], "Inference precedes task start")
    require(saved["gpu_seconds"] == current["gpu_seconds"], "GPU total differs from finished calls")
    require((not unknown_gpu or saved["resumable"] is False)
        and (current["resumable"] is not False or saved["resumable"] is False),
        "Unknown or conservatively nonresumable device cost cannot reopen resume")
    require(saved["task_wall_seconds"] >= current["task_wall_seconds"]
        and saved["inference_wall_seconds"] >= current["inference_wall_seconds"]
        and saved["task_wall_seconds"] >= saved["inference_wall_seconds"], "Cumulative wall cost decreased or is inconsistent")
    current.update(deepcopy(saved))


def within_budget(budget, rules, failed):
    return (budget["formal_calls"] <= rules["max_formal_calls"]
        and budget["warmup_calls"] <= rules["max_warmup_calls"]
        and budget["gpu_seconds"] <= rules["max_gpu_seconds"]
        and budget["inference_wall_seconds"] <= rules["max_inference_wall_seconds"]
        and budget["task_wall_seconds"] <= rules["max_task_wall_seconds"]
        and failed <= rules["max_failed_pass_retries"])


def checkpoint(directory, entry, attempt, identity):
    require(set(entry) == {"image_id", "pass_id", "relative_path", "sha256", "size_bytes", "call_index"},
            "Checkpoint entry fields differ")
    relative = entry.get("relative_path")
    require(isinstance(relative, str) and re.fullmatch(r"checkpoints/[A-Za-z0-9_-]+\.json", relative),
            "Unsafe checkpoint path")
    path = directory / relative
    require(not path.is_symlink() and path.resolve().parent == (directory / "checkpoints").resolve()
        and path.is_file(), "Missing, escaping or linked checkpoint")
    require(type(entry["size_bytes"]) is int and entry["size_bytes"] > 0
        and path.stat().st_size == entry["size_bytes"] and sha_file(path) == entry["sha256"], "Checkpoint bytes differ")
    record = decode(path.read_bytes())
    observed, inputs = record.get("observation"), record.get("identity")
    require(isinstance(observed, dict) and isinstance(inputs, dict), "Checkpoint identity/observation absent")
    # Legacy observation hashes use ensure_ascii=True. The new journal hash
    # spelling is separate; the legacy checkpoint identity remains unchanged.
    legacy = hashlib.sha256(json.dumps(observed, sort_keys=True, separators=(",", ":"),
                                      allow_nan=False).encode()).hexdigest()
    require(record.get("observation_sha256") == legacy, "Observation canonical hash differs")
    require(all(type(observed.get(k)) is type(attempt[k]) and observed[k] == attempt[k]
        for k in ("call_index", "image_id", "pass_id", "elapsed_seconds", "gpu_seconds")),
        "Observation/finished-call binding differs")
    require(inputs.get("image_id") == entry["image_id"] and inputs.get("pass_id") == entry["pass_id"],
        "Checkpoint input/index identity differs")
    require(all(type(observed.get(k)) is type(v) and observed[k] == v for k, v in inputs.items()),
        "Checkpoint input identity differs from observation")
    require(all(inputs.get(k) == observed.get(k) == identity[k]
        for k in ("protocol_sha256", "weight_sha256", "scientific_inputs_sha256")),
        "Checkpoint scientific source binding differs")
    require(all(isinstance(inputs.get(k), str) and re.fullmatch(r"[0-9a-f]{64}", inputs[k])
        for k in ("source_image_sha256", "decoded_image_sha256", "input_pixels_sha256")), "Checkpoint pixel hash absent")
    require(isinstance(record.get("environment_identity"), str)
        and re.fullmatch(r"[0-9a-f]{64}", record["environment_identity"])
        and record["environment_identity"] == observed.get("environment_identity"), "Checkpoint environment differs")
    return observed


def verify_journal(directory, protocol, expected_identity, *, require_completed=True,
                   require_resumable=False, now_epoch=None, observations=None,
                   check_published=True):
    """Replay and bind durable evidence; malformed or unsafe evidence raises.

    Read a closed task, never rolling budget/index files during prediction.
    Failed evidence may be audited with require_completed=False. A cost-overrun
    remains a failed gate and cannot authorize a resume or successful result.
    """
    directory = Path(directory).resolve()
    rules = limits(protocol)
    require(isinstance(expected_identity, dict) and expected_identity.keys() == IDENTITY
        and all(isinstance(v, str) and re.fullmatch(r"[0-9a-f]{64}", v) for v in expected_identity.values()),
        "Execution/source identity fields differ")
    path = directory / JOURNAL_FILE
    require(path.is_file() and not path.is_symlink(), "Version 2 journal is absent or linked")
    budget, index = None, {"schema_version": 1, "checkpoints": []}
    active, unknown, failed, closed = None, False, 0, None
    checkpoint_keys, checkpoint_calls, checkpoint_paths = set(), set(), set()
    formal_passed_keys, observed_rows = set(), []
    head, count, byte_count = "0" * 64, 0, 0
    previous_finish, prefix_digest = None, hashlib.sha256()
    with path.open("rb") as stream:
        for count, raw in enumerate(stream, 1):
            require(raw.endswith(b"\n"), "Unfinished journal tail cannot be resumed")
            record = decode(raw)
            require(isinstance(record, dict) and record.keys() == {"sequence", "previous_sha256", "event", "payload", "sha256"},
                    "Journal record fields differ")
            require(type(record["sequence"]) is int and record["sequence"] == count, "Journal sequence missing or duplicated")
            require(record["previous_sha256"] == head, "Journal hash chain is broken")
            body = {k: v for k, v in record.items() if k != "sha256"}
            require(record["sha256"] == sha_object(body), "Journal record hash differs")
            event, payload = record["event"], record["payload"]
            require(isinstance(payload, dict), "Journal payload is not an object")
            require(closed is None or event == "resumed", "Journal records follow closure")
            if count == 1:
                require(event == "header" and payload.keys() == {"journal_version", "identity", "limits", "initial_budget"}
                    and type(payload["journal_version"]) is int and payload["journal_version"] == 2
                    and payload["identity"] == expected_identity and payload["limits"] == rules,
                    "Journal header version, source or limits differ")
                budget = deepcopy(payload["initial_budget"])
                require(isinstance(budget, dict) and budget.get("schema_version") == 1
                    and budget.get("formal_attempts") == [] and budget.get("warmup_attempts") == []
                    and all(type(budget.get(k)) is int and budget[k] == 0
                        for k in ("formal_calls", "warmup_calls", "successful_observations"))
                    and budget.get("gpu_seconds") == 0 and budget.get("resumable") is True,
                    "Fresh version 2 header cannot import previous calls")
                initial_wall = {k: budget.get(k) for k in WALL}
                wall_update(budget, initial_wall, False)
            elif event in ("started", "finished"):
                require(payload.keys() == {"kind", "attempt", "wall"}, "Call payload fields differ")
                kind, row = payload["kind"], deepcopy(payload["attempt"])
                require(kind in ("formal", "warmup") and isinstance(row, dict), "Unknown call kind")
                collection = budget[f"{kind}_attempts"]
                require(type(row.get("call_index")) is int and row["call_index"] > 0
                    and type(row.get("pass_id")) is int and 0 <= row["pass_id"] < 9
                    and isinstance(row.get("image_id"), str) and row["image_id"], "Invalid call identity")
                if event == "started":
                    require(active is None and not unknown and budget["resumable"],
                        "Concurrent, nonresumable or unknown-cost call cannot start")
                    require(row["call_index"] == len(collection) + 1 and row.get("status") == "started"
                        and all(row.get(k) is None for k in ("utc_finished", "elapsed_seconds", "gpu_seconds")),
                        "Start is duplicated or already completed")
                    require(len(collection) < rules[f"max_{kind}_calls"], "Call budget exhausted before prediction")
                    require(kind != "formal" or (row["image_id"], row["pass_id"]) not in formal_passed_keys,
                        "A successful pass was predicted again")
                    started = timestamp(row.get("utc_started"))
                    require(previous_finish is None or started >= previous_finish, "Call clocks overlap or decrease")
                    wall_update(budget, payload["wall"], unknown)
                    require(budget["inference_started_epoch"] is not None and within_budget(budget, rules, failed),
                        "Inference clock absent or cumulative budget exhausted")
                    require(started.timestamp() + .05 >= budget["inference_started_epoch"]
                        and started.timestamp() - budget["task_started_epoch"] <= rules["max_task_wall_seconds"] + .05
                        and started.timestamp() - budget["inference_started_epoch"] <= rules["max_inference_wall_seconds"] + .05,
                        "Actual call starts outside original absolute deadlines")
                    collection.append(row)
                    budget[f"{kind}_calls"] = len(collection)
                    active = (kind, row["call_index"])
                else:
                    require(active == (kind, row["call_index"]), "Finish has no matching active start")
                    prior = collection[-1]
                    require(all(type(row.get(k)) is type(prior[k]) and row[k] == prior[k]
                        for k in ("call_index", "image_id", "pass_id", "utc_started")), "Finish/start identity differs")
                    require(row.get("status") in ("passed", "failed"), "Call finish is not terminal")
                    started, finished = timestamp(row["utc_started"]), timestamp(row.get("utc_finished"))
                    require(finished >= started and number(row.get("elapsed_seconds"), nullable=True)
                        and number(row.get("gpu_seconds"), nullable=True), "Call timing invalid")
                    if row.get("elapsed_seconds") is None or row.get("gpu_seconds") is None:
                        unknown = True
                    if row.get("gpu_seconds") is not None:
                        budget["gpu_seconds"] += row["gpu_seconds"]
                    if row.get("elapsed_seconds") is not None and row.get("gpu_seconds") is not None:
                        require(row["elapsed_seconds"] > 0 and row["gpu_seconds"] <= row["elapsed_seconds"] + .05,
                            "Recorded GPU duration exceeds predict elapsed duration")
                    if row["status"] == "failed":
                        require(isinstance(row.get("error"), dict), "Failed call has no error evidence")
                        failed += kind == "formal"
                    elif kind == "formal":
                        formal_passed_keys.add((row["image_id"], row["pass_id"]))
                    wall_update(budget, payload["wall"], unknown)
                    collection[-1] = row
                    active, previous_finish = None, finished
            elif event == "checkpoint":
                require(payload.keys() == {"entry", "wall"} and active is None and not unknown,
                    "Checkpoint is not preceded by a closed known-cost call")
                entry = deepcopy(payload["entry"])
                require(isinstance(entry, dict) and type(entry.get("call_index")) is int
                    and 1 <= entry["call_index"] <= len(budget["formal_attempts"]), "Checkpoint call is absent")
                row = budget["formal_attempts"][entry["call_index"] - 1]
                key = (entry.get("image_id"), entry.get("pass_id"))
                require(row["status"] == "passed" and key == (row["image_id"], row["pass_id"])
                    and key not in checkpoint_keys and entry["call_index"] not in checkpoint_calls
                    and entry.get("relative_path") not in checkpoint_paths, "Duplicate or mismatched checkpoint")
                wall_update(budget, payload["wall"], unknown)
                require(within_budget(budget, rules, failed), "Over-budget prediction cannot become a successful checkpoint")
                observed_rows.append(checkpoint(directory, entry, row, expected_identity))
                checkpoint_keys.add(key)
                checkpoint_calls.add(entry["call_index"])
                checkpoint_paths.add(entry["relative_path"])
                index["checkpoints"].append(entry)
                budget["successful_observations"] = len(index["checkpoints"])
                require(len(index["checkpoints"]) <= rules["successful_observations"], "Successful population exceeded")
            elif event in ("closed", "resumed"):
                if event == "resumed":
                    require(payload.keys() == {"prior_journal_sha256", "prior_journal_events", "prior_journal_bytes", "wall", "final_fields"}
                        and closed != "completed" and active is None and not unknown
                        and payload.get("prior_journal_sha256") == head
                        and type(payload.get("prior_journal_events")) is int and payload["prior_journal_events"] == count - 1
                        and type(payload.get("prior_journal_bytes")) is int and payload["prior_journal_bytes"] == byte_count,
                        "Resume does not bind the exact known-cost unfinished prefix")
                    require(all(row["status"] != "passed" or row["call_index"] in checkpoint_calls
                        for row in budget["formal_attempts"]), "Successful uncheckpointed prediction cannot be retried")
                    chain, prior_chain = payload["final_fields"].get("resume_chain"), budget.get("resume_chain", [])
                    require(isinstance(chain, list) and len(chain) == len(prior_chain) + 1 and chain[:-1] == prior_chain,
                        "Resume provenance must append exactly one entry")
                    binding = chain[-1]
                    require(isinstance(binding, dict) and isinstance(binding.get("task_id"), str)
                        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", binding["task_id"])
                        and binding["task_id"] != directory.name, "Resume must use a distinct safe prior task")
                    require(all(isinstance(binding.get(k), str) and re.fullmatch(r"[0-9a-f]{64}", binding[k])
                        for k in ("failure_sha256", "budget_sha256", "checkpoint_index_sha256", "journal_head_sha256", "journal_file_sha256")),
                        "Resume source receipts are absent")
                    require(binding["journal_head_sha256"] == head and binding["journal_file_sha256"] == prefix_digest.hexdigest(),
                        "Resume file-prefix identity differs")
                    prior_dir = directory.parent / binding["task_id"]
                    require(prior_dir.resolve().parent == directory.parent and not prior_dir.is_symlink(), "Unsafe prior task directory")
                    require(all(sha_file(prior_dir / filename) == binding[key] for filename, key in (
                        ("failure.json", "failure_sha256"), ("budget.json", "budget_sha256"),
                        ("checkpoint_index.json", "checkpoint_index_sha256"), (JOURNAL_FILE, "journal_file_sha256"))),
                        "Resume prior failure evidence bytes differ")
                else:
                    require(payload.keys() == {"status", "wall", "final_fields"} and payload.get("status") in ("completed", "failed"),
                        "Unknown closure status or fields")
                wall_update(budget, payload["wall"], unknown)
                final = payload["final_fields"]
                require(isinstance(final, dict) and not set(final) & {"formal_attempts", "warmup_attempts", *WALL},
                    "Closure rewrites calls or costs")
                require(all(type(final.get(k)) is int and final[k] == budget[k]
                    for k in ("formal_calls", "warmup_calls", "successful_observations")), "Closure rewrites aggregate counters")
                budget.update(deepcopy(final))
                closed = None if event == "resumed" else payload["status"]
                if event == "resumed":
                    require(within_budget(budget, rules, failed), "Resume starts after original cumulative budget expired")
                if closed == "completed":
                    require(active is None and not unknown and budget["resumable"] and within_budget(budget, rules, failed)
                        and len(checkpoint_keys) == rules["successful_observations"], "Completion lacks full known-cost population within budget")
            else:
                raise JournalVerificationError("Unexpected journal event")
            head = record["sha256"]
            byte_count += len(raw)
            prefix_digest.update(raw)
    require(budget is not None, "Empty journal")
    if active is not None or unknown or len(formal_passed_keys) != len(checkpoint_calls):
        budget["resumable"] = False
    budget.update(journal_version=2, journal_events=count, journal_sha256=head, journal_bytes=byte_count)
    index.update(journal_version=2, journal_events=count, journal_sha256=head)
    if check_published and closed is not None:
        require(canonical(decode((directory / "budget.json").read_bytes())) == canonical(budget),
            "Published budget differs from independent journal replay")
        require(canonical(decode((directory / "checkpoint_index.json").read_bytes())) == canonical(index),
            "Published index differs from independent journal replay")
    if observations is not None:
        require(canonical(observed_rows) == canonical(observations), "Journal checkpoints differ from published observation population")
    if require_completed or require_resumable:
        checkpoint_root = directory / "checkpoints"
        require(checkpoint_root.is_dir() and not checkpoint_root.is_symlink()
            and {file.relative_to(directory).as_posix() for file in checkpoint_root.iterdir()} == checkpoint_paths,
            "Unjournaled or absent checkpoint files cannot complete or resume")
    cost_ok = within_budget(budget, rules, failed)
    if require_completed:
        require(closed == "completed" and active is None and not unknown and budget["resumable"] and cost_ok,
            "A failed, incomplete or unknown-cost journal is not completed evidence")
        require(len(budget["warmup_attempts"]) == 1 and budget["warmup_attempts"][0]["status"] == "passed",
            "Completion requires exactly one successful warmup")
    if require_resumable:
        require(closed != "completed" and active is None and not unknown and budget["resumable"] and cost_ok,
            "This journal cannot safely resume")
        require(all(row["status"] != "passed" or row["call_index"] in checkpoint_calls
            for row in budget["formal_attempts"]), "Successful uncheckpointed prediction cannot be retried")
        now = time.time() if now_epoch is None else now_epoch
        require(number(now) and now - budget["task_started_epoch"] <= rules["max_task_wall_seconds"]
            and (budget["inference_started_epoch"] is None
                 or now - budget["inference_started_epoch"] <= rules["max_inference_wall_seconds"]),
            "Original absolute recovery deadline expired")
    checks = {
        "journal_v2_exact_sequence_and_sha256_chain": True,
        "journal_fresh_source_and_fixed_budget_identity": True,
        "journal_recorded_start_before_matching_call_finish": True,
        "journal_closed_call_costs_and_gpu_aggregation": True,
        "journal_monotonic_original_absolute_start_and_wall_cost": True,
        "journal_unique_checkpoint_bytes_observation_and_call_bindings": True,
        "journal_published_full_budget_and_index_match_independent_replay": not check_published or closed is not None,
        "journal_unknown_gpu_or_open_call_forbids_completion_or_resume": active is None and not unknown,
        "journal_cumulative_cost_stays_within_original_frozen_limits": cost_ok,
        "journal_terminal_status_matches_required_completion": not require_completed or closed == "completed",
    }
    return {"status": "passed" if all(checks.values()) else "failed", "checks": checks,
            "journal_events": count, "journal_sha256": head, "journal_bytes": byte_count,
            "journal_file_sha256": sha_file(path), "business_status": closed or "running",
            "replayed_budget": budget, "replayed_index": index}
