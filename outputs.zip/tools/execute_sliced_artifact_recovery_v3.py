"""Record a single frozen v3 saved-artifact review; no detector work is started."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
TASK = "1c68e87faed946d490a5ad802186146a"
SOURCE = "09c5ce4aceb7426e87af5334bdb03eb4"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    receipt_path = ROOT / "outputs/sliced-artifact-execution-v3.json"
    log_path = ROOT / "outputs/sliced-artifact-execution-v3.log"
    target, source = ROOT / "outputs" / TASK, ROOT / "outputs" / SOURCE
    freeze_path = ROOT / "outputs/sliced-artifact-implementation-v3/freeze.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    if (receipt_path.exists() or log_path.exists() or target.exists()
            or freeze["recovery_task_id"] != TASK
            or freeze["artifact_review_implementation_version"] != 3
            or (source / "completion.json").exists()):
        raise ValueError("Preserve existing records; require fresh frozen v3 review")
    for row in freeze["files"]:
        if sha(ROOT / row["path"]) != row["sha256"]:
            raise ValueError("Frozen review implementation changed: " + row["path"])
    for row in freeze["original_execution_source_files"]:
        if sha(row["path"]) != row["sha256_before"]:
            raise ValueError("Original execution source changed: " + row["role"])
    original_sha = sha(source / "failure.json")
    if original_sha != freeze["source_failure_sha256"]:
        raise ValueError("Original failure differs from freeze")
    receipt = {"schema_version": 1, "task_id": TASK, "source_task_id": SOURCE,
        "artifact_review_implementation_version": 3, "started_at": now(),
        "status": "running", "max_recovery_wall_seconds": 600,
        "new_detection_inference_performed": False,
        "source_failure_sha256_before": original_sha,
        "freeze_sha256": sha(freeze_path), "execution_wrapper_sha256": sha(__file__)}
    with receipt_path.open("x", encoding="utf-8") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    started = time.perf_counter()
    with log_path.open("x", encoding="utf-8") as log:
        process = subprocess.run([sys.executable, "-B", str(ROOT / "tools/run_sliced_artifact_recovery.py"),
            "--config", str(ROOT / "config/local.json"), "--task-id", TASK, "--source-id", SOURCE],
            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=False)
    result_path = target / ("recovery_result.json" if (target / "completion.json").exists() else "failure.json")
    result = json.loads(result_path.read_text(encoding="utf-8"))
    receipt.update(finished_at=now(), external_execution_wall_seconds=time.perf_counter() - started,
        exit_code=process.returncode, status=result["status"], result_sha256=sha(result_path),
        source_failure_sha256_after=sha(source / "failure.json"),
        original_completion_absent=not (source / "completion.json").exists())
    if (receipt["source_failure_sha256_after"] != original_sha or not receipt["original_completion_absent"]):
        raise ValueError("Historical failure must remain unchanged")
    if (target / "completion.json").exists():
        receipt["completion_sha256"] = sha(target / "completion.json")
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, ensure_ascii=False), flush=True)
    return process.returncode


if __name__ == "__main__":
    raise SystemExit(main())
