import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {selectBranchDiagnostic} from './comparison_branch_selection_v3.mjs';
function fixture(){
 const trials=Array.from({length:9},(_value,index)=>({trial_handle:'cmp_'+String(index).padStart(32,'0'),arm:'C',case_id:'normal_unrotated'}));
 trials[4]={...trials[4],arm:'F',case_id:'repair_coordinates'};trials[6]={...trials[6],arm:'F',case_id:'refuse_source_hash'};
 const selection={arm:'F',case_ids:['refuse_source_hash'],schema_version:1,trial_handles:[trials[6].trial_handle]};
 const selection_sha256=createHash('sha256').update(JSON.stringify(selection)).digest('hex');
 return [{trials},{engineering_diagnostic:{selection,selection_sha256,selected_trial_count:1,planned_comparison_trials:9},scope_policy:{allowed_handles:[...selection.trial_handles]},phase_model_budget:{total_cap:48,prior_closed_request_slots:34,request_slots_debited:41,this_pilot_cap:7,phase_remaining_before_diagnostic:7,legacy_token_usage_closed:false}}];
}
test('exactly one preregistered F refusal position executes',()=>{const [p,q]=fixture();assert.deepEqual(selectBranchDiagnostic(p,q),[p.trials[6]]);});
test('repair or alternate arm cannot borrow the refusal selection',()=>{for(const key of ['case_id','arm']){const [p,q]=fixture();p.trials[6][key]='U';assert.throws(()=>selectBranchDiagnostic(p,q));}});
test('mutated selected handle or selection hash is rejected',()=>{const [p,q]=fixture();q.engineering_diagnostic.selection.trial_handles[0]=p.trials[4].trial_handle;assert.throws(()=>selectBranchDiagnostic(p,q));});
test('eight unselected handles stay outside allowed scope',()=>{const [p,q]=fixture();q.scope_policy.allowed_handles.push(p.trials[0].trial_handle);assert.throws(()=>selectBranchDiagnostic(p,q));});
test('capacity cannot expand or undercharge the interrupted historical trial',()=>{for(const key of ['prior_closed_request_slots','request_slots_debited','this_pilot_cap','total_cap','phase_remaining_before_diagnostic']){const [p,q]=fixture();q.phase_model_budget[key]++;assert.throws(()=>selectBranchDiagnostic(p,q));}});
test('unknown historical token usage cannot become closed or actual41',()=>{for(const mutation of [q=>q.phase_model_budget.legacy_token_usage_closed=true,q=>q.phase_model_budget.prior_versions_actual_requests=41]){const [p,q]=fixture();mutation(q);assert.throws(()=>selectBranchDiagnostic(p,q));}});
test('duplicate population handles or additional selected slot is rejected',()=>{const [p,q]=fixture();p.trials[0].trial_handle=p.trials[1].trial_handle;assert.throws(()=>selectBranchDiagnostic(p,q));const [p2,q2]=fixture();q2.engineering_diagnostic.selected_trial_count=2;assert.throws(()=>selectBranchDiagnostic(p2,q2));});
