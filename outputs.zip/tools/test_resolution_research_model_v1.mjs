import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,writeFile,rm} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {randomUUID} from 'node:crypto';
import {ROOT,OriginalClock,ResearchTrace,runResearchSession,inspectNativeTitle,inspectPrimaryCosts,
 validateProtocol,PROTOCOL_KEYS,sha,waitForOwnedFile,runtimeCaptureScript} from './run_resolution_research_model_v1.mjs';
import {ACTION_TOOL,READ_TOOL,SERVER_ID} from './resolution_research_scope_guard_v1.mjs';

export function protocol(){const pin=name=>({path:join(ROOT,name),sha256:'a'.repeat(64)});
 return{schema_version:1,kind:'resolution_research_model_protocol_v1',deployment:pin('outputs/fixture/deployment.json'),
  source_lock:pin('outputs/fixture/source_lock.json'),runtime_version:pin('outputs/fixture/runtime.json'),
  runner_source:pin('tools/run_resolution_research_model_v1.mjs'),task_prompt:pin('agent/resolution_research_task_v1.md'),
  scope_candidate_path:join(ROOT,'outputs/fixture/scope_candidate.json'),scope_activation_path:join(ROOT,'outputs/fixture/scope_activation.json'),
  mcp_activation_path:join(ROOT,'outputs/fixture/mcp_activation.json'),python_executable:'E:/fixture/python.exe',powershell_executable:'E:/fixture/pwsh.exe',
  model:'agnes-3.0-flash',route:'account-defect-researcher',server_id:SERVER_ID,domain_task_directory:join(ROOT,'outputs/resolution-research-v1-fixture'),
  output_directory:join(ROOT,'outputs/fixture'),scope_policy:{schema_version:1,workspace_root:join(ROOT,'outputs/fixture/workspace'),
   request_id:'fixture',task_id:'resolution-research-v1-fixture',started_epoch_ms:1000000,deadline_epoch_ms:3400000,
   qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,max_model_requests:14,max_primary_requests:13,max_native_title_requests:1}};
}

class Queue{
 constructor(){this.rows=[];this.pending=[];this.closed=false;}
 push(row){const next=this.pending.shift();next?next({value:row,done:false}):this.rows.push(row);}
 async next(){if(this.rows.length)return{value:this.rows.shift(),done:false};if(this.closed)return{done:true};return new Promise(yes=>this.pending.push(yes));}
 async return(){this.closed=true;for(const yes of this.pending.splice(0))yes({done:true});return{done:true};}
 [Symbol.asyncIterator](){return this;}
}

export class Fixture{
 constructor(mode='valid'){
  this.mode=mode;this.p=protocol();this.now=1000000;this.mono=500;this.seq=0;this.saves=[];this.waits=[];this.follows=[];this.pendingSave=[];
  this.queue=new Queue();this.id='one-official-fixture-session';this.cancelled=false;this.approvals=[];this.calls=[];this.nativeStart=0;
  this.session={id:this.id,onPermissionRequest:fn=>{this.permission=fn;},events:()=>this.queue,setModel:async()=>{},
   prompt:async()=>this.turn(1),followUp:async(text,opts)=>{this.follows.push({id:this.id,text,opts});
    void this.turn(this.follows.length+1);return this.seq+1;},cancel:async()=>this.cancel(),};
  const raw=e=>({...e,_meta:{fixture_delivery_only:true}});
  this.client={workspace:{add:async()=>{}},session:{new:async()=>{
   this.queue.push(raw(this.row('session/start',{key:this.id})));
   this.queue.push(raw(this.row('x/ext:plugin/fixture/resolution-scope-ready',{session_key:this.id,policy:this.p.scope_policy})));return this.session;
  }},close:async()=>this.queue.return()};
 }
 row(type,data,extra={}){this.now+=10;this.mono+=10;return{seq:++this.seq,ts:new Date(this.now).toISOString(),lane:'main',type,
  origin:'system',trust:'trusted',data,...extra};}
 async emit(type,data,extra={}){if(this.cancelled)return null;const row=this.row(type,data,extra);this.queue.push({...row,_meta:{fixture_delivery_only:true}});
  await new Promise(yes=>this.pendingSave.push({seq:row.seq,yes}));return row;}
 cancel(){this.cancelled=true;for(const item of this.pendingSave.splice(0))item.yes();void this.queue.return();}
 async saved(record){this.saves.push(record);const seq=record.sdk_events.at(-1)?.seq??0;
  const ready=this.pendingSave.filter(x=>x.seq<=seq);this.pendingSave=this.pendingSave.filter(x=>x.seq>seq);for(const item of ready)item.yes();}
 async request(){return this.emit('request/sent',{model:{id:this.p.model,route:this.p.route},tool_schema_hash:'b'.repeat(64)});}
 async cost(){return this.emit('cost/ledger',{purpose:'inference',model:this.p.model,response:{status:200},
  tokens:this.mode==='unknown_primary'?{input:0,output:0,cacheRead:0,cacheWrite:0}:{input:20,output:5,cacheRead:0,cacheWrite:0},
  ...(this.mode==='unknown_primary'?{interrupted:true}:{})});}
 payload(status,extra={}){return{request_id:'fixture',task_id:this.p.scope_policy.task_id,status,fixture_only:false,science_accepted:false,...extra};}
 async action(action,payload,read=false){if(this.cancelled)return;await this.request();if(this.cancelled)return;
  const id='tool-'+this.calls.length,name=read?READ_TOOL:ACTION_TOOL,args={request_id:'fixture',action};
  const verdict=await this.permission({sessionId:this.id,toolCall:{toolCallId:id,rawInput:args,_meta:{'ai.agnes.harness':{tool:name}}},
   options:[{kind:'allow_once',optionId:'once-'+id}]});this.approvals.push(verdict);assert.equal(verdict.optionId,'once-'+id);
  this.calls.push(action);await this.emit('tool/call',{name,args,toolUseId:id},{origin:'model'});await this.cost();if(this.cancelled)return;
  await this.emit('tool/result',{toolUseId:id,isError:false,content:[{type:'text',text:JSON.stringify(payload)}]},{origin:'tool:'+name,trust:'untrusted'});
 }
 async end(){if(this.cancelled)return;await this.request();await this.cost();if(this.cancelled)return;
  const answer=await this.emit('assistant/message',{content:[{type:'text',text:'Fixture model pause/final'}]},{origin:'model'});
  await this.emit('turn/end',{reason:'completed',lastAssistantSeq:answer.seq});}
 async title(){if(this.cancelled)return;
  const seed={status:'requested',turn:1,startSeq:this.nativeStart,model:this.p.model,route:this.p.route};
  await this.emit('x/host/session-title',seed,{ignorable:true});const effect='title:'+sha(JSON.stringify([this.id,'main',this.nativeStart]));
  const cost=await this.emit('cost/ledger',{purpose:'title',sourceTurn:1,effectId:effect,model:this.p.model,
   tokens:{input:20,output:5,cacheRead:0,cacheWrite:0}});if(this.cancelled)return;
  await this.emit('x/host/session-title/diagnostics',{schemaVersion:1,sourceTurn:1,effectId:effect,
   timeoutMs:30000,durationMs:10,providerSent:true,responseSeen:true,usageObserved:this.mode!=='unknown_title',responseStatus:200,
   cancellationSettlementLimitMs:25,settledUsage:false,duplicateUsage:false,invalidUsage:false,usageAtMs:10},{ignorable:true,ts:cost.ts});
  // Atomic append has exactly one native UTC for the three records.
  const finishRow=this.row('x/host/session-title',{...seed,status:'failed',reason:'invalid-title'},{ignorable:true});finishRow.ts=cost.ts;
  this.queue.push({...finishRow,_meta:{fixture_delivery_only:true}});await new Promise(yes=>this.pendingSave.push({seq:finishRow.seq,yes}));
 }
 async turn(number){try{
  const start=await this.emit('turn/start',{turn:number,trigger:number===1?'prompt':'followUp'});if(number===1)this.nativeStart=start.seq;
  if(number===1){await this.action('audit_geometry',this.payload('running',{phase:'preflight',host_wait_required:true}));await this.end();await this.title();
  }else if(number===2){
   await this.action('register_hypothesis',this.payload('hypothesis_registered'));
   await this.action('start_registered_experiment',this.payload('running',{host_wait_required:true,phase:'initial'}));await this.end();
   if(this.mode==='second_title')await this.title();
  }else if(number===3){await this.action('status',this.payload('recovery_pending',{actual_failure:{type:'InjectedResolutionStepFault',closed_cost:true,
   ledger:{prediction_calls:2564,cost_known:true,open_call:null,failed_detector_call:false},original_deadline_epoch:2800}}),true);
   await this.action('resume_registered_failure',this.payload('running',{host_wait_required:true,phase:'resume'}));await this.end();
  }else{await this.action('status',this.payload('experiment_completed'),true);
   await this.action('independent_review',this.payload('reviewed',{verification:{status:'passed',real_recovery_accepted:true},only_supported_decision_action:'decide_stop_resolution'}),true);
   await this.action('decide_stop_resolution',this.payload('decided'));
   await this.action('publish_report',this.payload('report_completed',{science_accepted:true,report:{recovery_accepted:true}}));await this.end();}
  return{reason:this.cancelled?'error':'completed'};
 }catch(error){this.actorError=error;this.cancel();return{reason:'error'};}}
 dependencies(){return{fixtureOnly:true,protocolPath:'fixture-model-protocol',protocolHash:'a'.repeat(64),prompt:'Fixture task',
  clock:{now:()=>this.now,monotonic:()=>this.mono},clientFactory:async()=>this.client,checkPins:async()=>{},liveCheck:async()=>({fixture_only:true}),
  captureRuntime:async()=>({fixture_only:true,captured_at:new Date(this.now).toISOString(),build_completed_at:new Date(0).toISOString()}),
  exportSession:async(id,format)=>({format,path:'fixture-'+format,session_id:id,sha256:'c'.repeat(64),size_bytes:1}),save:r=>this.saved(r),
  waitWorker:async phase=>{this.waits.push(phase);if(phase==='preflight')return{request_id:'fixture',task_id:this.p.scope_policy.task_id,
   host_notification_allowed:true,phase,status:'preflight_passed',known_cost:true,worker_status:'preflight_passed',new_prediction_calls:0,deadline_reset:false,
   evidence:{status:'preflight_passed',task_id:this.p.scope_policy.task_id,new_prediction_calls:0,fixture_only:false,deadline_reset:false,
    original_deadline_epoch:2800,original_deadline_monotonic:2300,ledger:{prediction_calls:0,cost_known:true,open_call:null,failed_detector_call:false}}};
   return{request_id:'fixture',task_id:this.p.scope_policy.task_id,host_notification_allowed:true,status:phase==='initial'?'recovery_pending':'experiment_completed',
    known_cost:this.mode!=='unknown_worker',worker_status:phase==='initial'?'recovery_pending':'completed'};}};}
}

test('one official fixture session uses four turns and model-owned explicit resume, including failed title',async()=>{
 const f=new Fixture(),r=await runResearchSession(f.p,f.dependencies());assert.equal(r.status,'passed_fixture_only',JSON.stringify(r.failure??r.cost_failure));
 assert.equal(f.actorError,undefined);assert.deepEqual(f.waits,['preflight','initial','resume']);assert.equal(f.follows.length,3);
 assert.equal(r.turn_starts.length,4);assert.equal(r.turn_ends.length,4);assert.equal(r.prompt_receipts.length,4);
 assert(r.prompt_receipts.every(x=>x.session_id===r.session_id));assert.equal(r.actual_total_model_requests,14);
 assert.equal(r.native_title_requests,1);assert.equal(r.title_generated,false);assert.equal(r.native_title_usage_closed,true);
 assert.equal(r.science_accepted,false);assert(r.sdk_events.every(x=>!Object.hasOwn(x,'_meta')));
 assert.deepEqual(f.calls,['audit_geometry','register_hypothesis','start_registered_experiment','status','resume_registered_failure',
  'status','independent_review','decide_stop_resolution','publish_report']);assert.equal(r.permissions.length,9);
 assert.equal(r.started_epoch_ms,1000000);assert.equal(r.deadline_epoch_ms,3400000);assert.equal(r.exports.length,2);
});

test('unknown primary receipt stops without host followUp or resume',async()=>{
 const f=new Fixture('unknown_primary'),r=await runResearchSession(f.p,f.dependencies());assert.equal(r.status,'failed');
 assert.equal(f.waits.length,0);assert.equal(f.follows.length,0);assert.equal(r.actual_costs_known,false);assert(!f.calls.includes('resume_registered_failure'));
});
test('unknown title receipt cannot quietly become zero cost or pass',async()=>{
 const f=new Fixture('unknown_title'),r=await runResearchSession(f.p,f.dependencies());assert.equal(r.status,'failed');
 assert.equal(f.follows.length,0);assert.equal(r.native_title_usage_closed,false);assert.equal(r.native_title_requests,1);
});
test('failed title cannot be retried on the second turn without joint failure',async()=>{
 const f=new Fixture('second_title'),r=await runResearchSession(f.p,f.dependencies());assert.equal(r.status,'failed');
 assert.equal(f.follows.length,1);assert.equal(r.native_title_requests,2);assert.equal(r.native_title_usage_closed,false);
});
test('outer deadline and monotonic elapsed preserve the preregistered clock',()=>{
 const p=protocol(),c={value:1000100,mono:2,now(){return this.value;},monotonic(){return this.mono;}};
 const clock=new OriginalClock(p.scope_policy,c);c.value=1000099;assert.throws(()=>clock.check(),/backwards/);
 c.value=1000100;c.mono=2400002;assert.throws(()=>clock.check(),/deadline/);
});
test('fixture injection cannot claim production dependencies',async()=>{
 const f=new Fixture(),deps=f.dependencies();delete deps.fixtureOnly;await assert.rejects(runResearchSession(f.p,deps),/explicit fixture/);
});
test('fixed protocol rejects model, budgets, paths and broadened tools',()=>{
 const p=protocol();assert.equal(Object.keys(p).length,PROTOCOL_KEYS.length);validateProtocol(p);
 for(const mutate of [p=>p.model='other',p=>p.scope_policy.max_model_requests=15,p=>p.scope_policy.deadline_epoch_ms++,
  p=>p.scope_policy.qualified_action_tool='arbitrary',p=>p.extra=true]){const c=structuredClone(p);mutate(c);assert.throws(()=>validateProtocol(c));}
});
test('permission guards reject foreign sessions, tools, repeats and allow-always',()=>{
 const p=protocol(),c=new OriginalClock(p.scope_policy,{now:()=>1000100,monotonic:()=>1}),trace=new ResearchTrace(p,'session',c);
 const request={sessionId:'session',toolCall:{toolCallId:'one',rawInput:{request_id:'fixture',action:'audit_geometry'},_meta:{'ai.agnes.harness':{tool:ACTION_TOOL}}},
  options:[{kind:'allow_once',optionId:'yes'}]};assert.equal(trace.authorize(request).optionId,'yes');assert.equal(trace.authorize(request).verdict,'rejected');
 for(const mutate of [r=>r.sessionId='other',r=>r.toolCall._meta['ai.agnes.harness'].tool='read_file',r=>r.toolCall.rawInput.extra='path',
  r=>r.options=[{kind:'allow_always',optionId:'forever'}]]){const r=structuredClone(request);r.toolCall.toolCallId=randomUUID();mutate(r);assert.equal(trace.authorize(r).verdict,'rejected');}
});
test('OS capture is source-pinned read-only and owns daemon/worker rather than guessing',()=>{
 const script=runtimeCaptureScript(join(ROOT,'outputs/runtime.json'),join(ROOT,'outputs/ws'));
 assert(script.includes('"?--workspace"?\\s+'));assert(script.includes('[regex]::Escape($taskDaemonWorkspace)'));assert(script.includes('ParentProcessId'));
 assert(script.includes("$taskDaemonWorkspace='"+ROOT.replaceAll('\\','/').toLowerCase()+"'"));
 assert(script.includes('Get-FileHash -LiteralPath'));assert(!/Start-Process|Stop-Process|Remove-Item/.test(script));
});
test('host filesystem wait accepts only exclusive result publication, not a model status poll',async()=>{
 const dir=join(ROOT,'.runtime/test-tmp','runner-wait-'+randomUUID());await mkdir(dir,{recursive:true});
 try{const path=join(dir,'initial-result.json'),wait=waitForOwnedFile(path,{deadline:Date.now()+1000});
  setTimeout(()=>writeFile(path,'{"status":"closed"}',{flag:'wx'}),20);assert.equal((await wait).toString(),'{"status":"closed"}');
  await assert.rejects(waitForOwnedFile(join(dir,'missing.json'),{deadline:Date.now()+30}),/original deadline/);
 }finally{assert(resolve(dir).startsWith(resolve(ROOT,'.runtime/test-tmp')+'\\')||resolve(dir).startsWith(resolve(ROOT,'.runtime/test-tmp')+'/'));
  await rm(dir,{recursive:true,force:true});}
});
