"""Prepare the plan §10.2 full-resolution recovery experiment, without inference.

The default command only prints JSON. This module is not an experiment worker,
MCP tool, detector backend or a claim that recovery has actually occurred.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import math
from pathlib import Path
import shutil
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

REFERENCE_ID = "resolution-c39c94bc8d0a4095bf92b86db4f293f9"
SOURCE_PATHS = (
    "tools/prepare_resolution_recovery_v1.py", "docs/resolution-recovery-design-v1.md",
    "defect_researcher/resolution_comparison.py", "fixtures/resolution_protocol.json",
    "tools/verify_resolution_run.py", "defect_researcher/detection_metrics.py",
    "defect_researcher/audit.py", "defect_researcher/config.py",
    "defect_researcher/geometry_verifier.py", "defect_researcher/independent_geometry.py",
    "defect_researcher/task_runtime.py", "defect_researcher/sliced_journal.py",
    "defect_researcher/sliced_business_recovery_v2.py",
    "defect_researcher/sliced_business_worker_v2.py",
    "defect_researcher/research_mcp_runtime_v2.py",
    "defect_researcher/research_mcp_server_v2.py",
    "defect_researcher/research_workflow_clock_v2.py",
)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def sha(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def read(path):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("Duplicate JSON key")
            value[key] = item
        return value
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"),
                       object_pairs_hook=unique,
                       parse_constant=lambda token: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    canonical(value)  # Reject numeric overflow too.
    return value


def identity(path):
    path = Path(path).resolve(strict=True)
    return {"path": str(path), "sha256": sha(path), "size_bytes": path.stat().st_size}


def publication(directory, context=None):
    """Read-only byte/manifest check; this does not independently validate AP."""
    directory = Path(directory).resolve(strict=True)
    marker_path, manifest_path = directory / "completion.json", directory / "artifact_manifest.json"
    marker, manifest = read(marker_path), read(manifest_path)
    if (marker.get("status") != "completed" or manifest.get("status") != "completed"
            or marker.get("task_id") != manifest.get("task_id")
            or marker.get("tool") != manifest.get("tool")
            or Path(marker.get("artifact_manifest", "")).resolve() != manifest_path
            or marker.get("artifact_manifest_sha256") != sha(manifest_path)):
        raise ValueError("Completion/manifest identity mismatch")
    if context is not None and (marker.get("context") != context or manifest.get("context") != context):
        raise ValueError("Completed step belongs to another input/configuration/source identity")
    rows, names = manifest.get("files"), set()
    if type(rows) is not list or not rows:
        raise ValueError("Empty or malformed artifact manifest")
    for row in rows:
        path = Path(row["path"]).resolve(strict=True)
        if (path.parent != directory or path.name != row.get("name")
                or path.name in names or path.name in {"completion.json", "artifact_manifest.json"}
                or identity(path) != {key: row[key] for key in ("path", "sha256", "size_bytes")}):
            raise ValueError("Artifact is duplicate, outside the step, or corrupt")
        names.add(path.name)
    if marker.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
        raise ValueError("Completion artifact set differs from manifest")
    if marker_path.stat().st_mtime_ns < max(path.stat().st_mtime_ns for path in
                                            [manifest_path, *[directory / name for name in names]]):
        raise ValueError("Completion was not published after its artifacts")
    return {"completion": identity(marker_path), "manifest": identity(manifest_path),
            "files": rows, "scope": "artifact_bytes_only_not_new_scientific_verification"}


def recipe(base_protocol, wall_seconds=None, gpu_seconds=None):
    if (wall_seconds is None) != (gpu_seconds is None):
        raise ValueError("Wall and GPU limits must be supplied together")
    for value in (wall_seconds, gpu_seconds):
        if value is not None and (type(value) not in (int, float) or not math.isfinite(value) or value <= 0):
            raise ValueError("Shared clock/cost limits must be finite and positive")
    return {
        "schema_version": 1, "recipe_id": "full-val-resolution-step-recovery-v1",
        "scope": "plan_section_10_2_full_second_group_same_configuration_rerun",
        "execution_status": "not_implemented_or_executed",
        "inference_protocol": {**base_protocol, "nms": None, "quantize": None},
        "steps": ["audit", "geometry_gate", "reference/eval_640", "reference/eval_960",
                  "fault/eval_640", "fault/eval_960", "resume/eval_960", "independent_review"],
        "fault": {"step": "fault/eval_960", "max_injections": 1,
                  "boundary": "after_all_predictions_and_metrics_closed_before_step_completion",
                  "prediction_calls_closed": True, "keep_original_failure": True},
        "resume": {"max_retries": 1, "reuse": ["audit", "geometry_gate", "fault/eval_640"],
                   "rerun": ["eval_960"], "unit": "entire_640_image_evaluation_group",
                   "partial_predictions_reusable": False, "deadline_reset": False,
                   "unknown_cost_resumable": False},
        "shared_budget": {"max_prediction_entry_calls": 3205, "formal_calls": 3200,
                          "warmup_calls": 5, "max_wall_seconds": wall_seconds,
                          "max_gpu_seconds": gpu_seconds,
                          "clock_origin": "before_new_audit_and_all_arms",
                          "all_setup_review_and_publication_count_toward_wall": True,
                          "limits_need_registration": True},
        "comparison": {"ordered_membership_and_gt": "exact", "class_ids_and_counts": "exact",
                       "xyxy_absolute_tolerance_pixels": 1e-4,
                       "confidence_absolute_tolerance": 1e-6, "relative_tolerance": 0,
                       "recomputed_metric_absolute_tolerance": 1e-10,
                       "reference_and_resume_each_rescored": True,
                       "timing_and_peak_memory": "reported_not_required_equal",
                       "tolerances_are_proposed_until_execution_source_freeze": True},
    }


def validate_resume_contract(fault_root, saved_context, current_context, ledger):
    """Fixture-tested step reuse contract, not a runtime or a budget ledger."""
    if current_context != saved_context:
        raise ValueError("Input/configuration/execution source identity changed")
    required = {"original_deadline_epoch", "now_epoch", "pending_call", "retry_count",
                "calls_used", "max_calls", "gpu_used", "max_gpu"}
    if type(ledger) is not dict or ledger.keys() != required:
        raise ValueError("Invalid closed-cost resume contract")
    for key in required - {"pending_call"}:
        if type(ledger[key]) not in (int, float) or not math.isfinite(ledger[key]) or ledger[key] < 0:
            raise ValueError("Invalid budget/deadline number")
    if any(type(ledger[key]) is not int for key in ("retry_count", "calls_used", "max_calls")):
        raise ValueError("Call/retry counters must be integers")
    if (ledger["pending_call"] is not None or type(ledger["retry_count"]) is not int
            or ledger["retry_count"] != 0 or ledger["now_epoch"] >= ledger["original_deadline_epoch"]
            or ledger["calls_used"] + 641 > ledger["max_calls"]
            or ledger["gpu_used"] >= ledger["max_gpu"]):
        raise ValueError("Unknown cost, exhausted original budget, or prior retry")
    root = Path(fault_root).resolve(strict=True)
    for step in ("audit", "geometry_gate", "eval_640"):
        publication(root / step, saved_context)
    if (root / "eval_960" / "completion.json").exists() or (root / "completion.json").exists():
        raise ValueError("Faulted step/task cannot carry a completion marker")
    failure = read(root / "failure.json")
    if (failure.get("status") != "failed" or failure.get("step") != "eval_960"
            or failure.get("closed_cost") is not True or failure.get("context") != saved_context):
        raise ValueError("Failure is not the preregistered known-cost second-group fault")
    return {"reuse": ["audit", "geometry_gate", "eval_640"], "rerun": ["eval_960"],
            "partial_960_reused": False, "deadline_reset": False, "new_retry_count": 1}


@contextmanager
def fixture_workspace():
    # Match the existing tests' workspace: Windows tempfile(mode=0700) can
    # create directories whose ACL prevents nested writes by sandbox users.
    base = (ROOT / ".runtime" / "test-tmp").resolve()
    directory = (base / ("resolution-recovery-contract-" + uuid.uuid4().hex)).resolve()
    directory.mkdir(parents=True)
    try:
        yield directory
    finally:
        if directory.parent != base or not directory.is_relative_to(ROOT.resolve()):
            raise RuntimeError("Refusing fixture cleanup outside the project test workspace")
        shutil.rmtree(directory)


def fixture_validation():
    """Only small JSON fixture files in the project test directory are written."""
    checks = {}
    with fixture_workspace() as temp:
        root = Path(temp)
        context = {key: digest(key) for key in ("inputs", "protocol", "execution_sources")}
        fault = root / "fault"
        fault.mkdir()
        for step in ("audit", "geometry_gate", "eval_640"):
            directory = fault / step
            directory.mkdir()
            payload = directory / "fixture.json"
            payload.write_bytes(canonical({"fixture": step}))
            manifest = {"task_id": step, "tool": "engineering_fixture", "status": "completed",
                        "context": context, "files": [{**identity(payload), "name": payload.name}]}
            manifest_path = directory / "artifact_manifest.json"
            manifest_path.write_bytes(canonical(manifest))
            marker = {"task_id": step, "tool": "engineering_fixture", "status": "completed",
                      "context": context, "artifact_manifest": str(manifest_path),
                      "artifact_manifest_sha256": sha(manifest_path),
                      "artifacts_sha256": {payload.name: sha(payload)}}
            (directory / "completion.json").write_bytes(canonical(marker))
        (fault / "eval_960").mkdir()
        (fault / "eval_960" / "partial.json").write_bytes(canonical({"fixture": "partial_never_reused"}))
        (fault / "failure.json").write_bytes(canonical({"status": "failed", "step": "eval_960",
                                                       "closed_cost": True, "context": context}))
        ledger = {"original_deadline_epoch": 3000, "now_epoch": 2000, "pending_call": None,
                  "retry_count": 0, "calls_used": 2564, "max_calls": 3205,
                  "gpu_used": 10.0, "max_gpu": 60.0}
        tree = lambda: {str(path.relative_to(fault)): sha(path) for path in fault.rglob("*") if path.is_file()}
        before = tree()
        plan = validate_resume_contract(fault, context, context, ledger)
        checks["only_entire_second_group_scheduled"] = plan["rerun"] == ["eval_960"]
        checks["audit_geometry_and_640_reused"] = plan["reuse"] == ["audit", "geometry_gate", "eval_640"]
        checks["failed_tree_preserved_by_resume_planning"] = tree() == before
        checks["partial_960_never_accepted"] = plan["partial_960_reused"] is False
        negative = {
            "input_source_change_rejected": (dict(context, inputs=digest("changed")), ledger),
            "open_prediction_call_rejected": (context, dict(ledger, pending_call=17)),
            "expired_original_deadline_rejected": (context, dict(ledger, now_epoch=3000)),
            "insufficient_call_budget_rejected": (context, dict(ledger, max_calls=3204)),
            "second_retry_rejected": (context, dict(ledger, retry_count=1)),
            "exhausted_gpu_budget_rejected": (context, dict(ledger, gpu_used=60.0)),
        }
        for name, (current, budget) in negative.items():
            try:
                validate_resume_contract(fault, context, current, budget)
            except ValueError:
                checks[name] = True
            else:
                checks[name] = False
        payload = fault / "eval_640" / "fixture.json"
        payload.write_bytes(b"corrupt completed first group")
        try:
            validate_resume_contract(fault, context, context, ledger)
        except ValueError:
            checks["corrupt_completed_640_rejected"] = True
        else:
            checks["corrupt_completed_640_rejected"] = False
    if not all(checks.values()):
        raise AssertionError(checks)
    return {"status": "passed", "scope": "engineering_contract_fixture_only",
            "checks": checks, "checks_passed": len(checks), "checks_total": len(checks),
            "real_detector_used": False, "new_detector_calls": 0, "new_gpu_calls": 0,
            "new_model_requests": 0, "real_recovery_accepted": False}


def prepare(*, config_path=None, full_input_snapshot=False, wall_seconds=None, gpu_seconds=None):
    from defect_researcher.config import load_config
    from defect_researcher.audit import _configured_paths
    from defect_researcher import resolution_comparison
    configuration = load_config(config_path)
    paths = _configured_paths(configuration)
    base = resolution_comparison._protocol()
    upstream_root = ROOT / "outputs" / REFERENCE_ID
    upstream = publication(upstream_root)
    result = read(upstream_root / "comparison_result.json")
    if (result.get("status") != "completed" or result.get("task_id") != REFERENCE_ID
            or result.get("summary", {}).get("val_images") != 640
            or result["summary"].get("train_imgsz") != 640
            or result["summary"].get("eval_imgsz") != [640, 960]):
        raise ValueError("Historical same-weight reference identity/scope differs")
    locks = [identity(ROOT / relative) for relative in SOURCE_PATHS]
    locks += [identity(paths["research_root"] / "cableinspect_geometry.py")]
    inputs = [identity(paths["weights_path"]), identity(paths["dataset_root"] / "manifest.json"),
              identity(paths["dataset_root"] / "data.yaml"),
              identity(paths["weights_path"].parent.parent / "experiment_manifest.json")]
    if inputs[0]["sha256"] != result["summary"]["weight_sha256"]:
        raise ValueError("Current configured checkpoint differs from the historical reference")
    snapshot = None
    if full_input_snapshot:
        records, sources, provenance = resolution_comparison._prepare_inputs(paths, base)
        snapshot = {"records": records, "source_files": resolution_comparison._snapshot(sources),
                    "provenance": provenance, "val_images": len(records)}
    protocol = recipe(base, wall_seconds, gpu_seconds)
    return {"schema_version": 1, "purpose": "resolution_recovery_preparation_only",
            "status": "prepared_execution_pending", "configuration": configuration,
            "recipe": protocol, "recipe_sha256": digest(protocol),
            "source_lock": locks, "source_lock_sha256": digest(locks),
            "core_input_lock": inputs, "full_input_snapshot": snapshot,
            "full_inputs_rehashed": full_input_snapshot,
            "upstream_historical_artifact_chain": upstream,
            "historical_reference_is_new_control_arm": False,
            "readiness": {"worker_implemented": False, "independent_recovery_verifier_implemented": False,
                          "scientific_mcp_scope_registered": False,
                          "wall_gpu_budget_values_proposed": wall_seconds is not None,
                          "execution_budget_registered": False, "integrated_agh_loop_accepted": False},
            "new_detector_calls": 0, "new_gpu_calls": 0, "new_model_requests": 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture-check", action="store_true", help="Validate tiny engineering contracts only")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--full-input-snapshot", action="store_true", help="Read/hash the complete frozen input set")
    parser.add_argument("--wall-seconds", type=float, help="Proposed original shared wall budget; no execution")
    parser.add_argument("--gpu-seconds", type=float, help="Proposed shared GPU budget; no execution")
    args = parser.parse_args()
    if args.fixture_check and (args.config is not None or args.full_input_snapshot
                               or args.wall_seconds is not None or args.gpu_seconds is not None):
        parser.error("Fixture checking does not accept real-input or execution-budget options")
    value = (fixture_validation() if args.fixture_check else
             prepare(config_path=args.config, full_input_snapshot=args.full_input_snapshot,
                     wall_seconds=args.wall_seconds, gpu_seconds=args.gpu_seconds))
    print(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
