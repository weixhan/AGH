import {createHash} from 'node:crypto';
const stable=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
const phaseBudget={total_cap:48,prior_closed_request_slots:34,request_slots_debited:41,this_pilot_cap:7,phase_remaining_before_diagnostic:7,legacy_token_usage_closed:false};
export function selectBranchDiagnostic(protocol,publicProtocol){
 const diagnostic=publicProtocol.engineering_diagnostic,selection=diagnostic?.selection;
 const hash=createHash('sha256').update(stable(selection)).digest('hex');
 if(!selection||Object.keys(selection).sort().join(',')!=='arm,case_ids,schema_version,trial_handles'||selection.schema_version!==1||selection.arm!=='F'||
  stable(selection.case_ids)!==stable(['refuse_source_hash'])||!Array.isArray(selection.trial_handles)||selection.trial_handles.length!==1||
  !/^cmp_[0-9a-f]{32}$/.test(selection.trial_handles[0])||hash!==diagnostic.selection_sha256||diagnostic.selected_trial_count!==1||
  diagnostic.planned_comparison_trials!==9||protocol.trials?.length!==9||new Set(protocol.trials.map(row=>row.trial_handle)).size!==9)
  throw new Error('Refusal diagnostic selection differs');
 const selected=protocol.trials.filter(row=>selection.trial_handles.includes(row.trial_handle));
 if(selected.length!==1||selected[0].arm!=='F'||selected[0].case_id!=='refuse_source_hash'||selected[0].trial_handle!==selection.trial_handles[0]||
  stable(publicProtocol.scope_policy.allowed_handles)!==stable(selection.trial_handles)||stable(publicProtocol.phase_model_budget)!==stable(phaseBudget))
  throw new Error('Selected refusal task or conservative phase capacity differs');
 return selected;
}
