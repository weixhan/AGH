"""Independently reserve request capacity without closing V8's unknown usage.

The unit is an application Provider invocation, not an HTTP transmission or a
token/financial cost. This tool never changes a historical task or ledger.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATUS = "capacity_verified_with_legacy_usage_unknown"
FREEZE_SHA256 = "c20e7bba9805d986e4193407414bd6f7d18385b61903c591af76aeaf99a22a2a"
TITLE_SOURCE_SHA256 = "8f47696aa075db52623db777d3948a2eadbb807d8bf93d3019a51a0eb765806d"
REPAIR = "cmp_2f3288cb60e04be4a1fe2bdc8341d4b0"
REFUSAL = "cmp_6a3b4ba30a4d401a84e0dc275e5a4496"
SESSION = "8582e2bb-b147-45a6-b3d8-868b44d3b3bf"
BUDGET = {"total_cap": 48, "prior_closed_request_slots": 34,
          "request_slots_debited": 41, "this_pilot_cap": 7,
          "phase_remaining_before_diagnostic": 7, "legacy_token_usage_closed": False}


def require(condition, message):
    if condition is not True:
        raise ValueError(message)


def exact(left, right):
    return json.dumps(left, sort_keys=True, ensure_ascii=False, allow_nan=False) == json.dumps(
        right, sort_keys=True, ensure_ascii=False, allow_nan=False)


def _pairs(rows):
    result = {}
    for key, value in rows:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def decode(data):
    return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def verify_file_bytes(data, binding):
    """Pure byte binding, including size; booleans are not numeric sizes."""
    require(type(binding.get("size_bytes")) is int and binding["size_bytes"] == len(data)
            and hashlib.sha256(data).hexdigest() == binding.get("sha256"), "Source hash or size differs")


def validate_budget(value):
    require(type(value) is dict and exact(value, BUDGET), "Request capacity allocation differs")
    require(value["request_slots_debited"] + value["this_pilot_cap"] <= value["total_cap"],
            "Request reservation crosses original phase cap")


def derive_capacity_facts(bundle):
    """Pure semantic audit; source bytes must separately pass their frozen pins."""
    freeze, suite, run = (bundle[key] for key in ("freeze", "suite", "run"))
    acceptance, diagnosis = (bundle[key] for key in ("verification", "diagnosis"))
    protocol, public = (bundle[key] for key in ("protocol", "public_protocol"))
    prior = bundle["prior_reconciliation"]
    v6, v6_suite, v7, v7_suite = (bundle[key] for key in
                               ("prior_v6_acceptance", "prior_v6_suite", "prior_v7_acceptance", "prior_v7_suite"))
    require(prior.get("status") == "passed_observed_cost_accounting"
            and type(prior.get("actual_requests_observed")) is int and prior["actual_requests_observed"] == 17
            and all(row.get("all_observed_request_usage_closed") is True for row in prior.get("sessions", []))
            and v6.get("status") == "passed_engineering_diagnostic"
            and v6.get("model_requests_this_diagnostic") == v6_suite.get("model_requests_actual") == 10
            and v6.get("model_requests_phase_actual") == 27
            and v7.get("status") == "failed" and v7_suite.get("status") == "stopped"
            and v7.get("model_requests_this_diagnostic") == v7_suite.get("model_requests_actual") == 7
            and v7.get("model_requests_phase_actual") == 34, "Prior closed 17+10+7 request chain differs")
    require(exact(public.get("phase_model_budget"), {"total_cap": 48, "prior_versions_actual_requests": 34,
                "this_pilot_cap": 14, "phase_remaining_before_diagnostic": 14,
                "reconciliation": public.get("phase_model_budget", {}).get("reconciliation")})
            and suite.get("phase_model_requests_cap_total") == 48
            and suite.get("prior_versions_model_requests_actual") == 34, "Original phase allocation differs")
    require(freeze.get("status") == "failed_diagnostic_preserved"
            and freeze.get("original_driver_status") == "stopped"
            and freeze.get("original_engineering_status") == "failed"
            and freeze.get("refusal_selected_not_started") is True
            and freeze.get("model_requests_actual_closed") is None
            and freeze.get("model_requests_phase_actual_closed") is None
            and freeze.get("title_usage_known") is False
            and freeze.get("model_requests_observed_this_diagnostic") == 7
            and freeze.get("prior_closed_model_requests") == 34
            and freeze.get("model_requests_phase_observed") == 41,
            "V8 frozen failure or unknown usage was changed")
    require(suite.get("status") == "stopped" and suite.get("model_requests_actual") == 7
            and len(suite.get("trials", [])) == 1
            and suite["trials"][0].get("trial_handle") == REPAIR
            and suite["trials"][0].get("arm") == "F"
            and run.get("status") == "completed" and run.get("trial_handle") == REPAIR
            and run.get("session_id") == run.get("session_key") == SESSION
            and run.get("model_request_count") == 6 and run.get("model_requests_including_title") == 7,
            "Original V8 execution or request count differs")
    require(acceptance.get("status") == "failed" and acceptance.get("suite_status") == "stopped"
            and acceptance.get("model_requests_this_diagnostic") is None
            and acceptance.get("model_requests_phase_actual") is None
            and acceptance.get("unknown_model_cost_trials") == [REPAIR]
            and acceptance.get("selected_started_count") == 1
            and acceptance.get("selected_joint_correct_count") == 0
            and acceptance.get("selected_not_started") == [REFUSAL]
            and acceptance.get("comparison_unexecuted_trials") == 8, "V8 acceptance was retroactively closed")
    population = protocol.get("trials", [])
    require(len(population) == 9 and len({row.get("trial_handle") for row in population}) == 9,
            "Original nine positions differ")
    selected = public.get("engineering_diagnostic", {}).get("selected_trials", [])
    require([(row.get("trial_handle"), row.get("case_id"), row.get("arm")) for row in selected]
            == [(REPAIR, "repair_coordinates", "F"), (REFUSAL, "refuse_source_hash", "F")],
            "Original selected branches differ")
    unstarted = [row["trial_handle"] for row in population if row["trial_handle"] != REPAIR]
    require(REFUSAL in unstarted and len(unstarted) == 8
            and len(acceptance.get("unselected", [])) == 7
            and {row.get("trial_handle") for row in acceptance["unselected"]} == set(unstarted) - {REFUSAL}
            and all(row.get("arm_file_absent") is True and row.get("driver_record_absent") is True
                    for row in acceptance["unselected"]), "Old unstarted population differs")
    refused = [row for row in acceptance.get("results", []) if row.get("trial_handle") == REFUSAL]
    require(len(refused) == 1 and refused[0].get("started") is False
            and refused[0].get("execution_status") == "selected_not_started"
            and refused[0].get("proven_no_execution_artifacts") is True, "Old refusal was started")

    events = bundle["events"]
    require(type(events) is list and [row.get("seq") for row in events] == list(range(1, len(events) + 1)),
            "Official event sequence is incomplete or duplicated")
    starts = [row for row in events if row.get("type") == "session/start"]
    require(len(starts) == 1 and starts[0].get("data", {}).get("key") == SESSION,
            "Official session identity differs")
    requests = [row for row in events if row.get("type") == "request/sent"]
    costs = [row for row in events if row.get("type") == "cost/ledger"]
    main_costs = [row for row in costs if row.get("data", {}).get("purpose") == "inference"]
    title_costs = [row for row in costs if row.get("data", {}).get("purpose") == "title"]
    titles = [row for row in events if row.get("type") == "x/host/session-title"]
    requested = [row for row in titles if row.get("data", {}).get("status") == "requested"]
    terminal = [row for row in titles if row.get("data", {}).get("status") in {"failed", "generated"}]
    require(len(requests) == len(main_costs) == 6 and len(costs) == 7
            and len(title_costs) == len(requested) == len(terminal) == 1, "Observed V8 invocations differ")
    counted = starts + requests + costs + titles
    require(all(row.get("origin") == "system" and row.get("trust") == "trusted"
                and row.get("lane", "main") == "main" for row in counted), "Official invocation origin differs")
    require(all(row.get("data", {}).get("model") == {"route": "account-defect-researcher", "id": "agnes-3.0-flash"}
                for row in requests), "Primary model route differs")
    require(all(row.get("data", {}).get("model") == "agnes-3.0-flash"
                and row.get("data", {}).get("interrupted") is not True
                and all(type(row["data"].get("tokens", {}).get(key)) is int
                        and row["data"]["tokens"][key] >= 0
                        for key in ("input", "output", "cacheRead", "cacheWrite")) for row in main_costs),
            "Main invocation usage receipts are not closed")
    title, ended = title_costs[0], terminal[0]
    require(requested[0]["seq"] == 131 and title["seq"] == 132 and ended["seq"] == 133
            and title["data"].get("interrupted") is True
            and title["data"].get("creditSource") == "estimated"
            and exact(title["data"].get("tokens"), {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0})
            and ended["data"].get("status") == "failed" and ended["data"].get("reason") == "incomplete"
            and title["data"].get("sourceTurn") == requested[0]["data"].get("turn") == ended["data"].get("turn") == 1
            and all(row["data"].get("model") == "agnes-3.0-flash" for row in [title, requested[0], ended]),
            "V8 missing title usage was reinterpreted as actual zero or completion")
    require(diagnosis.get("title_usage_known") is False and diagnosis.get("title_interrupted") is True
            and diagnosis.get("zero_tokens_not_treated_as_actual_zero") is True
            and diagnosis.get("model_requests_actual_closed") is None
            and diagnosis.get("phase_actual_closed") is None
            and diagnosis.get("main_requests_observed") == 6
            and diagnosis.get("native_title_requests_observed") == 1
            and diagnosis.get("model_requests_observed_this_diagnostic") == 7
            and diagnosis.get("prior_closed_model_requests") == 34
            and diagnosis.get("whole_phase_observed_requests") == 41
            and diagnosis.get("phase_request_cap") == 48
            and diagnosis.get("next_model_execution_allowed_under_current_protocol") is False,
            "Original interruption diagnosis differs")
    return {"v8_unstarted_trial_handles": unstarted, "title_effect_id": title["data"]["effectId"],
            "title_requested_seq": 131, "title_cost_seq": 132, "title_terminal_seq": 133}


def _receipt(facts, sources, checked_at):
    return {"schema_version": 1, "kind": "comparison_provider_invocation_capacity_debit_v1",
            "status": STATUS, "checked_at": checked_at,
            "counting_unit": "application_provider_invocation_not_HTTP_transmission",
            "phase_model_budget": dict(BUDGET), "v8_request_slots_debited": 7,
            "phase_actual_usage_closed": None, "source_files": sources,
            "legacy_title_usage_unknown": [{"session_id": SESSION, "trial_handle": REPAIR,
                "provider_invocations_debited": 1, "effect_id": facts["title_effect_id"],
                "requested_seq": facts["title_requested_seq"], "cost_seq": facts["title_cost_seq"],
                "terminal_seq": facts["title_terminal_seq"], "token_usage": None, "financial_cost": None,
                "original_status": "failed", "original_reason": "incomplete", "interrupted": True}],
            "v8_preservation": {"driver_status": "stopped", "engineering_status": "failed",
                "joint_correct_count": 0, "actual_requests_closed": None, "phase_actual_requests_closed": None,
                "refusal_selected_not_started": True, "unstarted_trial_handles": facts["v8_unstarted_trial_handles"],
                "old_deadlines_unchanged": True, "old_tasks_resumable": False},
            "new_diagnostic_scope": {"selected_case": "refuse_source_hash", "arm": "F",
                "maximum_selected_trials": 1, "fresh_registration_required": True,
                "primary_cap": 6, "native_title_reserved_calls": 1, "combined_per_trial_cap": 7,
                "primary_wall_seconds": 85, "title_and_export_reserve_seconds": 35,
                "original_wall_seconds": 120, "new_usage_must_be_closed": True},
            "new_model_requests_this_review": 0, "new_detector_calls": 0, "gpu_seconds": 0}


def _load_evidence(root):
    root = Path(root).resolve()
    freeze_path = root / "outputs/comparison-implementation-v8/freeze.json"
    data = freeze_path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == FREEZE_SHA256, "Trusted V8 freeze hash differs")
    freeze = decode(data)
    sources = [{"role": "freeze", "path": str(freeze_path), "sha256": FREEZE_SHA256, "size_bytes": len(data)}]
    lock = freeze["source_lock"]
    verify_file_bytes(Path(lock["path"]).read_bytes(), lock)
    sources.append({"role": "v8_source_lock", **lock})
    inventory = {}
    for group in ("sources", "archive", "proof_files"):
        for row in freeze[group]:
            path = Path(row["path"]).resolve()
            verify_file_bytes(path.read_bytes(), row)
            key = str(path).casefold()
            if key in inventory:
                require(exact(inventory[key], row), "Conflicting frozen source binding")
            inventory[key] = row
    base = root / "outputs/comparison-pilot-v8"
    targets = {
        "suite": base / "run_result.json", "run": base / f"model_runs/{REPAIR}/run_result.json",
        "verification": base / "verification.json", "diagnosis": base / "title_interruption_diagnosis.json",
        "protocol": base / "protocol.json", "public_protocol": base / "model_protocol.json",
        "events": base / f"model_runs/{REPAIR}/session.jsonl",
        "title_source": base / "official_title_source/1_session-title.ts",
        "prior_reconciliation": root / "outputs/comparison-native-title-reconciliation-v2/reconciliation.json",
        "prior_v6_acceptance": root / "outputs/comparison-pilot-v6/verification.json",
        "prior_v6_suite": root / "outputs/comparison-pilot-v6/run_result.json",
        "prior_v7_acceptance": root / "outputs/comparison-pilot-v7/verification.json",
        "prior_v7_suite": root / "outputs/comparison-pilot-v7/run_result.json"}
    bundle = {"freeze": freeze}
    for role, path in targets.items():
        binding = inventory.get(str(path.resolve()).casefold())
        require(binding is not None, "Required source is absent from frozen inventory")
        contents = path.read_bytes()
        verify_file_bytes(contents, binding)
        sources.append({"role": role, **binding})
        if role == "title_source":
            require(binding["sha256"] == TITLE_SOURCE_SHA256, "Official single title invocation source differs")
        elif role == "events":
            bundle[role] = [decode(line) for line in contents.splitlines() if line.strip()]
        else:
            bundle[role] = decode(contents)
    facts = derive_capacity_facts(bundle)
    for handle in facts["v8_unstarted_trial_handles"]:
        require(not (base / f"runtime/trials/{handle}/arm.json").exists()
                and not (base / f"model_runs/{handle}").exists()
                and not (base / f"script_runs/{handle}").exists(),
                "An original unstarted task now has execution artifacts")
    return facts, sources


def make_receipt(root=ROOT):
    """Return new receipt contents, without any filesystem write or model call."""
    facts, sources = _load_evidence(root)
    return _receipt(facts, sources, datetime.now(timezone.utc).isoformat())


def validate_receipt(value_or_path, *, root=ROOT):
    """Freshly verify all old source pins and every receipt field; return dict."""
    value = decode(Path(value_or_path).read_bytes()) if isinstance(value_or_path, (str, Path)) else value_or_path
    require(type(value) is dict, "Capacity receipt is not an object")
    validate_budget(value.get("phase_model_budget"))
    checked_at = value.get("checked_at")
    require(type(checked_at) is str, "Capacity receipt timestamp is absent")
    stamp = datetime.fromisoformat(checked_at)
    require(stamp.tzinfo is not None, "Capacity receipt timestamp lacks timezone")
    facts, sources = _load_evidence(root)
    require(exact(value, _receipt(facts, sources, checked_at)), "Capacity receipt or legacy uncertainty differs")
    return value


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--output", type=Path, help="New receipt path; exclusive creation only")
    action.add_argument("--verify", type=Path, help="Freshly verify an existing receipt, read only")
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args(argv)
    if args.verify:
        value = validate_receipt(args.verify, root=args.root)
    else:
        value = make_receipt(args.root)
        target = args.output.resolve()
        require(target.is_relative_to(args.root.resolve() / "outputs"), "Receipt output must stay within project outputs")
        old_outputs = {"comparison-pilot-v" + str(version) for version in range(1, 9)}
        old_outputs.update("comparison-implementation-v" + str(version) for version in range(1, 9))
        require(not old_outputs.intersection(target.parts)
                and not any((parent / "freeze.json").is_file() for parent in target.parents),
                "Original comparison or frozen directories cannot receive new receipts")
        with target.open("x", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
    print(json.dumps({"status": value["status"], "phase_model_budget": value["phase_model_budget"],
                      "phase_actual_usage_closed": value["phase_actual_usage_closed"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
