// One frozen validation experiment through the public SDK; bounded host follow-ups are recorded.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, origin, finishEventReading } from './agh_ws_client.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-resolution-comparison');
const prompt = await readFile(join(root, 'agent', 'resolution_comparison_task.md'), 'utf8');
await mkdir(output, { recursive: true });
const record = { schema_version: 1, interface: 'official SDK over local AGH websocket', origin,
  model: 'agnes-3.0-flash', route: 'account-defect-researcher', user_authorized: true,
  qualified_tool: 'mcp_defect_researcher_45e5cef9_compare_validation_resolutions',
  prompt_sha256: createHash('sha256').update(prompt).digest('hex'),
  started_at: new Date().toISOString(), status: 'starting', permissions: [], calls: [], polls: [], turns: [],
  limitations: ['Host may send bounded same-task follow-ups when a model turn ends while running. This is not autonomous long-task scheduling.'] };
const recordPath = join(output, 'runner.json');
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let session, iterator, reading, heartbeat;
let approvals = 0, afterSeq = 0;
const abort = new AbortController();
const timer = setTimeout(() => abort.abort(), 20 * 60 * 1000);

try {
  const registration = JSON.parse(await readFile(join(output, 'registration.json'), 'utf8'));
  if (!registration.complete || registration.status.toolCount !== 5) throw new Error('Expected five ready tools');
  session = await client.session.new({ cwd: root, sessionKey: randomUUID() });
  record.session_id = session.id;
  record.session_url = `${origin}/?session=${encodeURIComponent(session.id)}`;
  await save();
  console.log(JSON.stringify({ session_id: session.id, url: record.session_url }));
  session.onPermissionRequest(async request => {
    const tool = request.toolCall?._meta?.['ai.agnes.harness']?.tool;
    const input = request.toolCall?.rawInput;
    const once = request.options.find(option => option.kind === 'allow_once');
    const allowed = request.sessionId === session.id && tool === record.qualified_tool &&
      input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === 0 &&
      approvals === 0 && Boolean(once);
    if (allowed) approvals++;
    record.permissions.push({ at: new Date().toISOString(), tool, input,
      tool_call_id: request.toolCall?.toolCallId, decision: allowed ? 'allowed-once' : 'rejected' });
    await save();
    console.log(JSON.stringify({ approval: allowed ? 'allowed-once' : 'rejected', tool }));
    return allowed ? { optionId: once.optionId } : { verdict: 'rejected' };
  });
  await session.setModel({ slot: 'primary', route: record.route, model: record.model });
  record.status = 'running';
  heartbeat = setInterval(() => console.log(JSON.stringify({ running: true, task_id: record.task_id,
    last_status: record.polls.at(-1)?.status,
    elapsed_seconds: Math.round((Date.now() - Date.parse(record.started_at)) / 1000) })), 30_000);
  for (let turn = 0; turn < 4; turn++) {
    iterator = session.events()[Symbol.asyncIterator]();
    reading = (async () => {
      for (;;) {
        const next = await iterator.next();
        if (next.done) break;
        const event = next.value;
        if (event.seq <= afterSeq) continue;
        if (event.type === 'tool/call') {
          record.calls.push({ seq: event.seq, origin: event.origin, name: event.data.name, args: event.data.args });
          await save();
          console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
        }
        if (event.type === 'tool/result') {
          const payload = event.data.content?.find(block => block.type === 'text')?.text;
          if (payload) {
            let result;
            try { result = JSON.parse(payload); } catch { /* authoritative export retains the event */ }
            if (result?.task_id) {
              record.task_id ??= result.task_id;
              if (record.task_id !== result.task_id) throw new Error('Model queried another task');
              record.polls.push({ seq: event.seq, task_id: result.task_id, status: result.status,
                stage: result.current_stage, summary: result.status === 'completed' ? result.summary : undefined });
              await save();
              console.log(JSON.stringify({ task_id: result.task_id, status: result.status, stage: result.current_stage }));
            }
          }
        }
        if (event.type === 'turn/end') break;
      }
    })();
    const message = turn === 0 ? prompt : `继续查询既有任务 ${record.task_id} 直到终态。只调用 get_task_status，不再次启动 compare_validation_resolutions。不把 running 当完成。完成后依据本次 summary 和证据更新验证集假设，并说明限制。最终追加唯一JSON代码块{status,task_id,summary}，summary精确复制comparison_status,split,val_images,val_boxes,train_imgsz,eval_imgsz,weight_sha256,same_weight,device,precision,input_hashes_unchanged,test_inference_performed,training_performed,metrics,comparison。保留原始数字，不省略或舍入。`;
    const result = await session.prompt(message, { signal: abort.signal, titleLocale: 'zh-CN' });
    await finishEventReading(reading);
    await iterator.return?.();
    record.turns.push({ turn, message_sha256: createHash('sha256').update(message).digest('hex'), result });
    afterSeq = result.lastSeq;
    await save();
    if (['completed', 'failed'].includes(record.polls.at(-1)?.status)) break;
    if (!record.task_id) throw new Error('No comparison task was launched');
  }
  const terminal = record.polls.at(-1);
  if (terminal?.status !== 'completed' || terminal.summary?.comparison_status !== 'passed' ||
      terminal.summary?.input_hashes_unchanged !== true) throw new Error('No verified terminal comparison result');
  record.status = 'completed';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  clearTimeout(timer);
  clearInterval(heartbeat);
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  if (session) {
    for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
      let reader;
      try {
        reader = await webClient();
        await exportSession({ positional: [session.id], format, raw: false, out: join(output, filename) }, {
          cwd: root, io: { stdout: process.stdout, stderr: process.stderr },
          writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
        }, reader);
      } catch (error) {
        record.export_failure = { type: error.name, message: error.message };
        process.exitCode = 1;
      } finally { await reader?.close(); }
    }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: record.session_id,
    task_id: record.task_id, output, failure: record.failure, export_failure: record.export_failure }));
}
