"""Run the bundled CPU cases and saved-task crosschecks in a fresh directory."""
from __future__ import annotations

import argparse
import hashlib
import importlib.abc
import json
from pathlib import Path
import platform
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / "tools")]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def verify_manifest(root: Path) -> dict:
    """Check every immutable bundle member before creating smoke outputs."""
    manifest_path = root / "HASHES.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    rows = manifest["files"]
    names = {row["path"] for row in rows}
    if len(names) != len(rows) or manifest.get("excluded") != ["HASHES.json"]:
        raise ValueError("Bundle hash manifest membership or exclusion differs")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file()}
    if actual != names | {"HASHES.json"}:
        raise ValueError("Bundle files differ from the complete hash manifest")
    for row in rows:
        path = root / row["path"]
        if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
            raise ValueError("Bundle manifest path escapes its root")
        if path.stat().st_size != row["size_bytes"] or digest(path) != row["sha256"]:
            raise ValueError("Bundle hash/size mismatch: " + row["path"])
    return {"status": "passed", "files_checked": len(rows), "manifest_sha256": digest(manifest_path),
            "self_hash_recorded_in_external_build_receipt": True}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True,
                        help="New evidence directory outside the extracted bundle")
    args = parser.parse_args()
    destination = args.output.resolve()
    if destination == ROOT or destination.is_relative_to(ROOT) or ROOT.is_relative_to(destination):
        raise ValueError("Smoke output must be separate from the immutable bundle")
    if destination.exists():
        raise FileExistsError("Smoke output already exists; choose a new directory")
    integrity = verify_manifest(ROOT)
    destination.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    prohibited = {"torch", "ultralytics", "tensorflow", "cupy", "jax", "transformers"}
    attempts = {"prohibited_imports": [], "network": [], "process": []}

    class CpuOnlyImports(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if fullname.split(".")[0] in prohibited:
                attempts["prohibited_imports"].append(fullname)
                raise ImportError("CPU fixture smoke prohibits model/GPU libraries: " + fullname)
            return None

    def audit(event, arguments):
        if event in {"socket.connect", "socket.connect_ex", "socket.getaddrinfo", "socket.bind"}:
            attempts["network"].append(event)
            raise RuntimeError("CPU fixture smoke prohibits network access")
        if event in {"subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp"}:
            attempts["process"].append(event)
            raise RuntimeError("CPU fixture smoke prohibits child processes")

    sys.meta_path.insert(0, CpuOnlyImports())
    sys.addaudithook(audit)
    result = {"schema_version": 1, "kind": "extracted_bundle_cpu_migration_acceptance_v1",
              "status": "failed", "bundle_root": str(ROOT), "output_root": str(destination),
              "python": {"version": platform.python_version(), "executable": sys.executable,
                         "isolated": bool(sys.flags.isolated), "no_site": bool(sys.flags.no_site)},
              "platform": {"sys_platform": sys.platform,
                           "windows_version": list(sys.getwindowsversion()) if hasattr(sys, "getwindowsversion") else None},
              "integrity": integrity, "errors": []}
    try:
        from defect_researcher.independent_geometry import run_fixture_suite
        from run_labelguard_acceptance import run_acceptance
        from verify_labelguard_run import review

        geometry = run_fixture_suite()
        write_json(destination / "independent_geometry.json", geometry)
        acceptance = run_acceptance(ROOT / "research", destination / "labelguard")
        reviews = []
        for case in acceptance["cases"]:
            report = review(case["configuration"], case["task_id"])
            write_json(destination / (case["case_id"] + "-independent.json"), report)
            reviews.append({"case_id": case["case_id"], "status": report["status"],
                            "checks_passed": sum(value is True for value in report.get("checks", {}).values()),
                            "checks_total": len(report.get("checks", {})),
                            "evidence": str(destination / (case["case_id"] + "-independent.json"))})
        origins = {name: str(Path(module.__file__).resolve()) for name, module in sys.modules.items()
                   if (name.startswith("defect_researcher") or name in {"run_labelguard_acceptance", "verify_labelguard_run"})
                   and getattr(module, "__file__", None)}
        input_paths = [Path(value).resolve() for case in acceptance["cases"]
                       for value in case["configuration"].values()]
        checks = {
            "isolated_python_without_site_packages": bool(sys.flags.isolated and sys.flags.no_site),
            "labelguard_twelve_cases_passed": acceptance.get("status") == "passed" and len(acceptance["cases"]) == 12,
            "fixed_groups_all_four_passed": acceptance.get("groups") == {
                name: {"total": 4, "passed": 4} for name in ("normal", "repairable", "refused")},
            "four_actual_correct_repairs": acceptance.get("actual_repair_cases") == acceptance.get("correct_repair_cases") == 4,
            "no_unintended_modifications": acceptance.get("unintended_modification_cases") == 0,
            "independent_saved_task_reviews_all_passed": len(reviews) == 12 and all(row["status"] == "passed" for row in reviews),
            "independent_geometry_thirty_cases_passed": geometry.get("status") == "passed" and geometry.get("counts", {}).get("total") == geometry.get("counts", {}).get("passed") == 30,
            "independent_geometry_reference_is_separate": geometry.get("evidence", {}).get("independent_of_production_geometry") is True,
            "all_project_imports_from_extracted_bundle": bool(origins) and all(Path(value).is_relative_to(ROOT) for value in origins.values()),
            "all_case_paths_from_new_evidence_directory": bool(input_paths) and all(path.is_relative_to(destination) for path in input_paths),
            "bundled_production_geometry_used": all(
                digest(Path(case["configuration"]["research_root"]) / "cableinspect_geometry.py") == digest(ROOT / "research" / "cableinspect_geometry.py")
                for case in acceptance["cases"]),
            "no_prohibited_imports_or_gpu_libraries": not attempts["prohibited_imports"] and not any(name.split(".")[0] in prohibited for name in sys.modules),
            "no_network_or_child_process_attempts": not attempts["network"] and not attempts["process"],
            "bundle_immutable_after_execution": verify_manifest(ROOT) == integrity,
        }
        result.update({"checks": checks, "groups": acceptance["groups"],
                       "actual_repair_cases": acceptance["actual_repair_cases"],
                       "correct_repair_cases": acceptance["correct_repair_cases"],
                       "unintended_modification_cases": acceptance["unintended_modification_cases"],
                       "case_outcomes": [{"case_id": row["case_id"], "group": row["group"],
                                          "status": row["status"], "actual_changed_files": row["actual_changed_files"],
                                          "repair_status": row["summary"].get("repair_status")}
                                         for row in acceptance["cases"]],
                       "independent_case_reviews": reviews, "geometry_counts": geometry["counts"],
                       "project_module_origins": origins,
                       "status": "passed" if all(checks.values()) else "failed"})
    except Exception as error:
        result["errors"].append({"type": type(error).__name__, "message": str(error)})
    result.update({"elapsed_seconds": time.monotonic() - started, "guard_attempts": attempts,
                   "model_calls": 0, "detection_inference_calls": 0, "gpu_tasks": 0,
                   "limitations": ["This is an actual extraction/new-path CPU fixture execution on the same computer.",
                                   "The twelve LabelGuard inputs are fabricated isolated cases; real image pixels are not decoded.",
                                   "AGH, Provider setup, GPU inference, full data/weights and other-computer acceptance remain pending."]})
    write_json(destination / "migration_acceptance.json", result)
    print(json.dumps({"status": result["status"], "groups": result.get("groups"),
                      "geometry_counts": result.get("geometry_counts"), "errors": result["errors"],
                      "evidence": str(destination / "migration_acceptance.json")}, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
