// A fresh Agnes read of a completed artifact recovery; no detector start is permitted.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, origin, finishEventReading } from './agh_ws_client.mjs';
import { normalizeScopePath } from './sliced_artifact_scope_guard.mjs';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-sliced-artifact-model-v2'), workspace = join(output, 'workspace');
const policy = JSON.parse(await readFile(join(workspace, '.agh/extensions/sliced-artifact-scope-guard-v2/policy.json'), 'utf8'));
const activation = JSON.parse(await readFile(join(output, process.argv.includes('--retry-activation') ? 'activation-retry.json' : 'activation.json'), 'utf8'));
if (!activation.complete || !activation.after?.trusted || activation.after.actual !== 'running') throw new Error('Artifact scope not activated');
const compactKeys = ['slicing_status','candidate_status','source_original_status','source_computation_task_id','operation_kind',
 'artifact_recovery_status','original_final_review_completed_within_1800_seconds','original_completion_absent',
 'new_detection_inference_performed','reference_reused','input_hashes_unchanged','training_performed',
 'test_inference_performed','baseline','sliced','medium','failed_gates'];
const compact = value => ({ status: value.status, task_id: value.task_id, ...Object.fromEntries(compactKeys.map(key => [key, value.summary[key]])) });
const record = { schema_version: 1, started_at: new Date().toISOString(), policy, cwd: workspace,
 model: 'agnes-3.0-flash', route: 'account-defect-researcher', status: 'starting', task_id: policy.task_id,
 permissions: [], calls: [], results: [], hook_events: [], final_texts: [],
 tool_catalog_narrowed: false, source_original_status: 'failed', source_execution_reclassified: false,
 new_detection_inference_performed: false, new_model_inference_performed: null, model_prompt_sent: false };
const recordPath = join(output, 'runner.json');
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let session, iterator, reading, readyTimer, readyResolve, readyReject, approvals = 0;
const ready = new Promise((yes, no) => { readyResolve = yes; readyReject = no; });
const abort = new AbortController(), timer = setTimeout(() => abort.abort(), 5 * 60_000);
try {
 const response = await fetch(`${origin}/admin/plugins/api/list`, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' },
  body: JSON.stringify({ profile: 'local-dev' }) });
 const live = (await response.json()).packages?.find(row => row.id === activation.package_id);
 if (!response.ok || live?.actualIntegrity !== activation.after.actualIntegrity || !live.trusted || live.actual !== 'running')
  throw new Error('Artifact scope live state differs from activation');
 // Completion and science must exist before creating a session or sending a model request.
 const source = JSON.parse(await readFile(join(root, 'outputs', policy.task_id, 'completion.json'), 'utf8'));
 if (source.status !== 'completed' || source.tool !== 'verify_sliced_artifact_recovery' || source.task_id !== policy.task_id)
  throw new Error('Artifact recovery completion is not published');
 record.task_completion_sha256 = createHash('sha256').update(await readFile(join(root, 'outputs', policy.task_id, 'completion.json'))).digest('hex');
 await client.workspace.add(workspace);
 session = await client.session.new({ cwd: workspace, sessionKey: randomUUID() });
 record.session_id = session.id; record.session_url = `${origin}/?session=${encodeURIComponent(session.id)}`; await save();
 session.onPermissionRequest(async request => {
  const tool = request.toolCall?._meta?.['ai.agnes.harness']?.tool, input = request.toolCall?.rawInput;
  const once = request.options.find(option => option.kind === 'allow_once');
  const allowed = request.sessionId === session.id && tool === policy.qualified_status_tool &&
   input?.task_id === policy.task_id && Object.keys(input).join(',') === 'task_id' && approvals === 0 && Boolean(once);
  if (allowed) approvals++;
  record.permissions.push({ tool, input, tool_call_id: request.toolCall?.toolCallId ?? request.toolCall?.id,
   decision: allowed ? 'allowed-once' : 'rejected' }); await save();
  return allowed ? { optionId: once.optionId } : { verdict: 'rejected' };
 });
 iterator = session.events()[Symbol.asyncIterator]();
 readyTimer = setTimeout(() => readyReject(new Error('No artifact scope readiness before model turn')), 15_000);
 reading = (async () => {
  for (;;) {
   const next = await iterator.next(); if (next.done) break;
   const event = next.value;
   if (event.type.endsWith('/scope-ready')) {
    if (event.data.mode !== 'artifact-recovery' || normalizeScopePath(event.data.workspace_root) !== normalizeScopePath(workspace) ||
        JSON.stringify(event.data.policy) !== JSON.stringify(policy)) throw new Error('Artifact scope readiness mismatch');
    record.scope_ready = { seq: event.seq, type: event.type, origin: event.origin, data: event.data }; readyResolve();
   } else if (event.type.endsWith('/scope-decision')) record.hook_events.push(event);
   else if (event.type === 'tool/call') record.calls.push({ seq: event.seq, origin: event.origin, ...event.data });
   else if (event.type === 'tool/result') {
    const texts = event.data.content?.filter(block => block.type === 'text').map(block => block.text) ?? [];
    let value; if (texts.length === 1) try { value = JSON.parse(texts[0]); } catch { /* keep result error */ }
    record.results.push({ seq: event.seq, tool_use_id: event.data.toolUseId, code: event.data.code, is_error: event.data.isError,
     ...(value ? { payload: value } : {}) });
   } else if (event.type === 'cost/ledger' && event.data.purpose === 'inference') record.new_model_inference_performed = true;
   else if (event.type === 'assistant/message') record.final_texts.push(event);
   else if (event.type === 'turn/end') record.turn_end = event;
   await save(); if (event.type === 'turn/end') break;
  }
 })();
 reading.catch(readyReject);
 await ready; clearTimeout(readyTimer);
 await session.setModel({ slot: 'primary', route: record.route, model: record.model });
 record.status = 'running'; await save();
 const prompt = `调用 get_task_status 一次读取已完成恢复任务 ${policy.task_id}。这是对已保存5760次检测观察的报告恢复，原计算任务状态仍为failed；原任务最终独立验收未能在1800秒内完成，原completion仍不存在，不能追认原任务成功。此次报告恢复采用单独600秒的审核预算，本会话不得启动或重复检测。用中文说明同一640训练权重的验证集切片结果、误报代价和candidate_status，区分artifact_recovery_status与原任务执行状态。最终仅附一个json代码块，键严格为${JSON.stringify(['status','task_id',...compactKeys])}，精确复制工具返回status、task_id以及summary对应字段。不要把科学stop写成执行失败，不要把报告恢复写成原模型任务成功或自主研究。`;
 record.prompt = prompt; record.prompt_sha256 = createHash('sha256').update(prompt).digest('hex'); await save();
 console.log(JSON.stringify({ session_id: session.id, guard_ready: true, url: record.session_url }));
 record.model_prompt_sent = true; await save();
 record.turn_result = await session.prompt(prompt, { signal: abort.signal, titleLocale: 'zh-CN' });
 await finishEventReading(reading);
 const terminal = record.results.find(row => row.payload?.task_id === policy.task_id && row.payload?.status === 'completed');
 const final = record.final_texts.find(row => row.seq === record.turn_end?.data?.lastAssistantSeq);
 const text = (final?.data?.content ?? []).filter(block => block.type === 'text').map(block => block.text).join('\n');
 const blocks = [...text.matchAll(/```json\s*\n([\s\S]*?)\n```/g)];
 if (blocks.length !== 1) throw new Error('Expected one unique final compact JSON block');
 record.final_json = JSON.parse(blocks[0][1]);
 const expected = terminal ? compact(terminal.payload) : null;
 const stable = value => JSON.stringify(value, (key, item) => item && typeof item === 'object' && !Array.isArray(item)
  ? Object.fromEntries(Object.keys(item).sort().map(name => [name, item[name]])) : item);
 record.checks = { readiness_before_model: Boolean(record.scope_ready), exactly_one_status_call: record.calls.length === 1,
  only_pinned_task_and_tool: record.calls.every(row => row.name === policy.qualified_status_tool &&
   row.args?.task_id === policy.task_id && Object.keys(row.args).join(',') === 'task_id'),
  paired_allowed_gate: record.hook_events.length === 1 && record.hook_events[0].data.allow === true,
  successful_completed_artifact_result: Boolean(terminal && terminal.is_error === false && terminal.payload.tool === 'verify_sliced_artifact_recovery'),
  original_failure_preserved_in_returned_evidence: terminal?.payload?.summary?.source_original_status === 'failed',
  no_new_detector_inference: terminal?.payload?.summary?.new_detection_inference_performed === false,
  exact_final_compact_evidence: expected !== null && stable(record.final_json) === stable(expected) };
 record.status = Object.values(record.checks).every(Boolean) ? 'completed' : 'failed';
 if (record.status !== 'completed') process.exitCode = 1;
} catch (error) { record.status = 'failed'; record.failure = { type: error.name, message: error.message }; process.exitCode = 1; }
finally {
 clearTimeout(timer); clearTimeout(readyTimer); await client.close(); await iterator?.return?.();
 await finishEventReading(reading).catch(() => undefined);
 if (session) for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
  let exporter;
  try {
   exporter = await webClient();
   await exportSession({ positional: [session.id], format, raw: false, out: join(output, filename) },
    { cwd: workspace, io: { stdout: process.stdout, stderr: process.stderr },
     writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }) }, exporter);
  } catch (error) { record.export_failure = { type: error.name, message: error.message }; process.exitCode = 1; }
  finally { await exporter?.close(); }
 }
 record.finished_at = new Date().toISOString(); await save();
 console.log(JSON.stringify({ status: record.status, session_id: record.session_id, checks: record.checks, failure: record.failure, export_failure: record.export_failure }));
}
