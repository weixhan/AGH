# Restart both the official background runtime and the browser entry process.
# start_web.ps1 verifies its listening process identity before replacing it.
$ErrorActionPreference = 'Stop'
$taskProjectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskPython = 'E:\Anaconda_envs\envs\MMIOC_env\python.exe'
$taskNode = 'E:\nodejs24.15.0\node.exe'
$taskLauncher = Join-Path $taskProjectRoot 'run_agh.py'
$taskData = Join-Path $taskProjectRoot '.runtime\agh\data'

& $taskPython -X utf8 -B $taskLauncher --node $taskNode daemon stop --profile local-dev --workspace $taskProjectRoot --data-dir $taskData
if ($LASTEXITCODE -ne 0) { throw 'Official daemon ownership/stop check failed; preserve the running service.' }
& (Join-Path $taskProjectRoot 'start_web.ps1') -Restart
