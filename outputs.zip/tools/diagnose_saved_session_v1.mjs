// Read-only public SDK diagnosis of a preserved session; no prompt or tool call.
import {webClient} from './agh_ws_client.mjs';
import {readLedger} from '../../agnes-harness/packages/cli/src/commands/export.ts';
const id=process.argv[2];
if(!/^[a-f0-9-]{36}$/.test(id??''))throw new Error('Session ID required');
const client=await webClient();
try {
  const ledger=await readLedger(client,id);
  console.log(JSON.stringify({status:'passed',events:ledger.events.length,lastSeq:ledger.lastSeq}));
} catch(error) {
  console.log(JSON.stringify({status:'failed',type:error.name,message:error.message,code:error.code,data:error.data,stack:error.stack}));
  process.exitCode=1;
} finally {await client.close();}
