import {writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
const origin='http://127.0.0.1:4177';
const target=process.argv[2];
if(!target?.startsWith('outputs/comparison-suite-v14-diagnostic/'))throw new Error('Diagnostic output path required');
const trace={started_at:new Date().toISOString(),model_requests:0};
async function api(path,body){
 const response=await fetch(origin+'/admin/resources/api/'+path,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json'},signal:AbortSignal.timeout(15000),...(body?{body:JSON.stringify(body)}:{})});
 const data=await response.json();if(!response.ok)throw new Error(path+' '+response.status+' '+JSON.stringify(data));return data;
}
try{
 const context=await api('context');if(context.profile!=='local-dev'||context.readOnly)throw new Error('Expected local administration');
 const base={profile:context.profile,clientId:context.clientId},serverId='dr-cmp14-d';
 trace.before=await api('mcp/get',{profile:base.profile,serverId});
 trace.receipt=await api('mcp/reconnect',{...base,commandId:'v11-service-diagnostic-'+randomUUID(),serverId,expectedRevision:trace.before.revision});
 const deadline=Date.now()+40000;
 do{trace.operation=await api('operations/get',{profile:base.profile,operationId:trace.receipt.operationId});if(['succeeded','failed','cancelled'].includes(trace.operation.state))break;await new Promise(r=>setTimeout(r,500));}while(Date.now()<deadline);
 trace.after=await api('mcp/status',{profile:base.profile,serverId});
}catch(error){trace.error={type:error.name,message:error.message};process.exitCode=1;}
trace.finished_at=new Date().toISOString();
await writeFile(target,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({operation:trace.operation,after:trace.after,error:trace.error}));
