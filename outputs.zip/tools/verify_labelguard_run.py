"""Independently recheck a saved label-copy task and its unchanged sources."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.task_runtime import get_task_status


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def review(configuration: dict, task_id: str) -> dict:
    directory = Path(configuration["output_root"]).resolve() / task_id
    if directory.resolve().parent != Path(configuration["output_root"]).resolve():
        raise ValueError("Task directory escapes output root")
    report = get_task_status(configuration, task_id)
    if report.get("status") != "completed" or report.get("tool") != "repair_label_copy":
        return {"status": "failed", "task_id": task_id, "errors": report.get("errors", [])}
    inputs = json.loads((directory / "input_manifest.json").read_text(encoding="utf-8"))
    copied = json.loads((directory / "copy_manifest.json").read_text(encoding="utf-8"))
    changes = [json.loads(line) for line in (directory / "repair_changes.jsonl").read_text(encoding="utf-8").splitlines()]
    allowed = [Path(configuration[key]).resolve() for key in ("dataset_root", "raw_root", "split_dir", "research_root")] + [ROOT]
    current_inputs = []
    for row in inputs["files"]:
        path = Path(row["path"]).resolve()
        if not any(path.is_relative_to(root) for root in allowed):
            raise ValueError("Source evidence points outside the configured input/code scope")
        present = path.is_file()
        current = digest(path) if present else None
        current_inputs.append({"role": row["role"], "current_matches": present == row["exists_before"] == row["exists_after"]
                               and current == row["sha256_before"] == row["sha256_after"] and row["unchanged"] is True})
    summary = report["summary"]
    checks = {"saved_task_and_artifact_chain_valid": True,
              "original_text_sources_current_hash_matches_before_and_after": all(row["current_matches"] for row in current_inputs),
              "input_manifest_declares_unchanged": inputs.get("all_unchanged") is True,
              "no_image_pixel_hash_claim": inputs.get("image_pixels_hashed") is False,
              "change_count_matches_real_records": len(changes) == summary.get("changed_files"),
              "change_paths_unique": len({row["relative_path"] for row in changes}) == len(changes)}
    if summary.get("repair_status") == "refused":
        checks["refusal_publishes_no_copy"] = copied.get("copy_root") is None and copied["files"] == copied["images"] == [] and copied.get("after_verification") is None and not (directory / "dataset_copy").exists()
        checks["refusal_has_zero_modifications"] = not changes and summary.get("verification_status") is None
    else:
        root = Path(copied["copy_root"])
        independent = get_task_status({**configuration, "dataset_root": str(root), "output_root": copied["after_verification"]["output_root"]}, "after")
        checks["independent_after_completed_passed"] = independent.get("status") == "completed" and independent.get("summary", {}).get("verification_status") == "passed"
        details = [json.loads(line) for line in Path(independent["artifacts"]["geometry_details"]).read_text(encoding="utf-8").splitlines()]
        images = [row for row in details if row["record_type"] == "image"]
        annotations = [row for row in details if row["record_type"] == "annotation"]
        checks["full_image_details_match_declared_totals"] = len(images) == summary["totals"]["images"] and all(not row["differences"] for row in images)
        checks["full_annotation_details_match_declared_totals"] = len(annotations) == summary["totals"]["annotations"] and all(row["status"] == "passed" and not row["differences"] for row in annotations)
        changed = {row["relative_path"]: row for row in changes}
        consistent = True
        preserved = True
        for item in copied["files"]:
            relative = item["relative_path"]
            if not relative.startswith(("labels/", "metadata/")):
                continue
            original, target = Path(configuration["dataset_root"]) / relative, root / relative
            if relative in changed:
                record = changed[relative]
                consistent &= record["before_sha256"] == (digest(original) if original.exists() else None) and record["after_sha256"] == digest(target)
                consistent &= (record["before"].encode("utf-8") if record["before"] is not None else None) == (original.read_bytes() if original.exists() else None)
                consistent &= record["after"].encode("utf-8") == target.read_bytes()
                consistent &= record["source_sha256"] == digest(Path(configuration["raw_root"]) / record["source_json"])
            else:
                preserved &= original.is_file() and original.read_bytes() == target.read_bytes()
        checks["changed_file_records_match_actual_bytes_and_source"] = consistent
        checks["all_unmodified_labels_and_metadata_preserve_original_bytes"] = preserved
        path_line = next(line for line in (root / "data.yaml").read_text(encoding="utf-8").splitlines() if line.startswith("path:"))
        checks["copy_yaml_targets_actual_copy"] = json.loads(path_line.split(":", 1)[1].strip()) == root.as_posix()
        checks["frozen_source_hashes_not_rewritten"] = json.loads((root / "manifest.json").read_text(encoding="utf-8"))["source_sha256"] == json.loads((Path(configuration["dataset_root"]) / "manifest.json").read_text(encoding="utf-8"))["source_sha256"]
        checks["zero_change_not_counted_as_repair"] = summary.get("decision") == ("repaired_copy" if changes else "normal_no_change")
    return {"schema_version": 1, "kind": "independent_saved_label_copy_crosscheck", "status": "passed" if all(checks.values()) else "failed",
            "task_id": task_id, "model_used": False, "checks": checks, "summary": summary,
            "source_files_checked": len(current_inputs), "source_mismatches": [row for row in current_inputs if not row["current_matches"]],
            "limitations": report.get("limitations", [])}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--config")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = review(load_config(args.config), args.task_id)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "task_id": args.task_id, "checks": report.get("checks"), "evidence": str(args.output)}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
