"""Read-only crosscheck of a saved controlled resolution comparison.

Source membership, exact bytes, GT decoding and publication checks are separate
from the runner. Metric recomputation deliberately reuses detection_metrics; it
is an artifact consistency check, not a second independently implemented AP.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.detection_metrics import compare_scores, score_detections

TOOL = "compare_validation_resolutions"
ARTIFACTS = {
    "protocol.json", "inputs.json", "events.jsonl", "predictions_640.jsonl",
    "predictions_960.jsonl", "metrics_640.json", "metrics_960.json", "comparison.json",
    "comparison_report.md", "comparison_result.json",
}
CLASSES = ["broken_strand", "welded_strand", "bent_strand", "long_scratch",
           "crushed", "spaced_strand", "deposit"]
FROZEN = {
    "schema_version": 1, "split": "val", "expected_images": 640, "train_imgsz": 640,
    "eval_imgsz": [640, 960], "device": "0", "precision": "FP32", "batch": 1,
    "prediction_confidence": 0.001, "nms_iou": 0.7, "max_det": 300, "rect": False,
    "augment": False, "agnostic_nms": False, "operating_confidence": 0.25,
    "matching_iou": 0.5, "allow_tf32": False, "test_inference": False,
    "weight_change": False, "training_performed": False, "selection_data": "validation_only",
    "fallback": "fail_without_changing_protocol",
}


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def decode(text: str):
    def unique(pairs):
        output = {}
        for key, value in pairs:
            if key in output:
                raise ValueError(f"Duplicate JSON key: {key}")
            output[key] = value
        return output
    def invalid(value):
        raise ValueError(f"Nonfinite JSON constant: {value}")
    value = json.loads(text, object_pairs_hook=unique, parse_constant=invalid)
    json.dumps(value, allow_nan=False)  # Also reject numeric overflow, e.g. 1e400.
    return value


def read(path: Path):
    return decode(path.read_text(encoding="utf-8-sig"))


def lines(path: Path) -> list[dict]:
    return [decode(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def inside(path, roots: list[Path]) -> Path:
    value = Path(path).resolve()
    if not any(value.is_relative_to(root.resolve()) for root in roots):
        raise ValueError(f"Evidence path escapes configured scope: {value}")
    if not value.is_file():
        raise ValueError(f"Evidence file missing: {value}")
    return value


def record_valid(row: dict, root: Path) -> bool:
    path = inside(row["path"], [root])
    return (row.get("name") == path.name and row.get("size_bytes") == path.stat().st_size
            and row.get("sha256") == digest(path))


def chain(directory: Path, task: str, tool: str, required: set[str]) -> bool:
    completion, manifest = read(directory / "completion.json"), read(directory / "artifact_manifest.json")
    for artifact in (completion, manifest):
        if artifact.get("task_id") != task or artifact.get("tool") != tool or artifact.get("status") != "completed":
            return False
    if Path(completion.get("artifact_manifest", "")).resolve() != (directory / "artifact_manifest.json").resolve():
        return False
    if completion.get("artifact_manifest_sha256") != digest(directory / "artifact_manifest.json"):
        return False
    rows = manifest.get("files", [])
    if len(rows) != len(required) or {row.get("name") for row in rows} != required:
        return False
    if len({Path(row["path"]).resolve() for row in rows}) != len(rows):
        return False
    if not all(record_valid(row, directory) and Path(row["path"]).resolve().parent == directory for row in rows):
        return False
    if completion.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
        return False
    # Current mtime order is supporting evidence; copied files can alter it.
    marker_time = (directory / "completion.json").stat().st_mtime_ns
    return all(marker_time >= (directory / name).stat().st_mtime_ns
               for name in required | {"artifact_manifest.json"})


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError(f"Invalid PNG header: {path}")
    return struct.unpack(">II", header[16:24])


def ground_truth(label: Path, width: int, height: int) -> list[dict]:
    output = []
    for row in label.read_text(encoding="utf-8-sig").splitlines():
        if not row.strip():
            continue
        parts = row.split()
        if len(parts) != 5 or not re.fullmatch(r"[0-6]", parts[0]):
            raise ValueError(f"Invalid frozen GT label: {label}")
        x, y, w, h = map(float, parts[1:])
        if not all(math.isfinite(value) and 0 <= value <= 1 for value in (x, y, w, h)) or min(w, h) <= 0:
            raise ValueError(f"Invalid normalized GT: {label}")
        output.append({"class_id": int(parts[0]),
                       "xyxy": [(x - w / 2) * width, (y - h / 2) * height,
                                (x + w / 2) * width, (y + h / 2) * height], "source_label": row})
    return output


def positive(value) -> bool:
    return not isinstance(value, bool) and isinstance(value, (float, int)) and math.isfinite(value) and value > 0


def review(configuration: dict, task_id: str) -> dict:
    import yaml
    if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
        raise ValueError("Task ID must be a safe single directory name")
    paths = {key: Path(value).resolve() for key, value in configuration.items()}
    directory = paths["output_root"] / task_id
    result, inputs, protocol = (read(directory / name) for name in
                                ("comparison_result.json", "inputs.json", "protocol.json"))
    checks = {"comparison_publication_chain_valid": chain(directory, task_id, TOOL, ARTIFACTS),
              "result_completed_and_same_task": result.get("status") == "completed" and result.get("task_id") == task_id and result.get("tool") == TOOL,
              "frozen_protocol_values_and_types": all(protocol.get(key) == value and type(protocol.get(key)) is type(value)
                                                       for key, value in FROZEN.items()),
              "frozen_protocol_fixture_matches": all(protocol.get(key) == value for key, value in read(ROOT / "fixtures" / "resolution_protocol.json").items())}
    summary = result["summary"]
    manifest = read(directory / "artifact_manifest.json")
    gate = directory / "geometry_gate" / "gate"
    gate_files = {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"}
    checks["independent_geometry_nested_chain_valid"] = chain(gate, "gate", "verify_label_geometry", gate_files)
    checks["geometry_gate_manifest_records_valid"] = all(record_valid(row, gate) for row in manifest["geometry_gate"].values())
    checks["geometry_gate_has_required_manifest_links"] = set(manifest["geometry_gate"]) == {"completion", "manifest"}
    gate_result = read(gate / "verification_result.json")
    checks["independent_geometry_gate_passed"] = gate_result.get("status") == "completed" and gate_result.get("summary", {}).get("verification_status") == "passed"
    details, fixtures = lines(gate / "geometry_details.jsonl"), read(gate / "fixture_results.json")
    images = [row for row in details if row.get("record_type") == "image"]
    annotations = [row for row in details if row.get("record_type") == "annotation"]
    checks["geometry_gate_full_details_and_30_fixtures_passed"] = (
        len(images) == 4479 and len(annotations) == 3864 and len(details) == len(images) + len(annotations)
        and all(row.get("differences") == [] for row in details)
        and all(row.get("status") == "passed" for row in annotations)
        and fixtures.get("status") == "passed" and len(fixtures.get("cases", [])) == 30
        and all(row.get("status") == "passed" for row in fixtures["cases"]))
    completion = read(directory / "completion.json")
    checks["geometry_completion_hash_link_valid"] = completion.get("geometry_completion_sha256") == digest(gate / "completion.json")

    allowed = [paths[key] for key in ("dataset_root", "raw_root", "split_dir", "research_root")] + [ROOT]
    source_rows, mismatches = inputs["files"], []
    roles = {row["role"]: row for row in source_rows}
    checks["input_roles_unique"] = len(roles) == len(source_rows)
    source_paths = []
    for row in source_rows:
        path = inside(row["path"], allowed)
        source_paths.append(path)
        actual = digest(path)
        if not (actual == row.get("sha256_before") == row.get("sha256_after")
                and row.get("unchanged") is True and row.get("size_bytes") == path.stat().st_size):
            mismatches.append(row["role"])
    checks["inputs_current_hashes_match_before_and_after"] = not mismatches and inputs.get("all_unchanged") is True
    checks["input_files_count_matches_summary"] = len(source_rows) == summary.get("input_files_hashed")
    required_inputs = {"weights", "training_manifest", "dataset/manifest.json", "dataset/data.yaml", "splits/val.txt",
                       "comparison_runner", "comparison_protocol", "detection_metrics", "config_loader", "verifier", "oracle", "fixtures"}
    checks["required_frozen_input_roles_present"] = required_inputs <= roles.keys()
    expected_paths = {
        "weights": paths["weights_path"], "training_manifest": paths["weights_path"].parent.parent / "experiment_manifest.json",
        "dataset/manifest.json": paths["dataset_root"] / "manifest.json", "dataset/data.yaml": paths["dataset_root"] / "data.yaml",
        "comparison_runner": ROOT / "defect_researcher" / "resolution_comparison.py",
        "comparison_protocol": ROOT / "fixtures" / "resolution_protocol.json",
        "detection_metrics": ROOT / "defect_researcher" / "detection_metrics.py",
        "config_loader": ROOT / "defect_researcher" / "config.py", "verifier": ROOT / "defect_researcher" / "geometry_verifier.py",
        "oracle": ROOT / "defect_researcher" / "independent_geometry.py", "fixtures": ROOT / "fixtures" / "geometry_cases.json",
    }
    for cable in ("cable_1", "cable_2", "cable_3"):
        expected_paths[f"raw/{cable}.json"] = paths["raw_root"] / f"{cable}.json"
    for split in ("train", "val", "test", "excluded_buffer"):
        expected_paths[f"splits/{split}.txt"] = paths["split_dir"] / f"{split}.txt"
        if split == "excluded_buffer":
            continue
        for kind in ("labels", "metadata"):
            for file in (paths["dataset_root"] / kind / split).iterdir():
                if not file.is_file():
                    raise ValueError(f"Unexpected non-file in dataset input tree: {file}")
                expected_paths[f"{kind}/{split}/{file.name}"] = file.resolve()
    checks["frozen_runner_and_metrics_paths_match_current_modules"] = (
        Path(roles["comparison_runner"]["path"]).resolve() == ROOT / "defect_researcher" / "resolution_comparison.py"
        and Path(roles["detection_metrics"]["path"]).resolve() == ROOT / "defect_researcher" / "detection_metrics.py")
    training = read(paths["weights_path"].parent.parent / "experiment_manifest.json")
    dataset = read(paths["dataset_root"] / "manifest.json")
    checks["checkpoint_and_training_provenance_frozen"] = (
        training.get("status") == "completed" and training["training_args"]["imgsz"] == 640
        and training["actual_training_args"]["imgsz"] == 640
        and training["best_weights_sha256"] == digest(paths["weights_path"]) == protocol["weight_sha256"] == summary["weight_sha256"]
        and training["dataset_manifest_sha256"] == digest(paths["dataset_root"] / "manifest.json") == protocol["dataset_manifest_sha256"]
        and training["data_yaml_sha256"] == digest(paths["dataset_root"] / "data.yaml") == protocol["data_yaml_sha256"]
        and training["dataset_manifest"] == dataset)
    data = yaml.safe_load((paths["dataset_root"] / "data.yaml").read_text(encoding="utf-8-sig"))
    checks["dataset_yaml_classes_and_validation_root_correct"] = (
        Path(data.get("path", "")).resolve() == paths["dataset_root"] and data.get("val") == "images/val"
        and data.get("names") == dict(enumerate(CLASSES)))

    raw_members = [Path(line.strip()).resolve() for line in (paths["split_dir"] / "val.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    member_ids = sorted(path.stem for path in raw_members)
    checks["validation_has_640_unique_images_same_frozen_list"] = (
        len(raw_members) == len(set(raw_members)) == len(set(member_ids)) == 640
        and member_ids == protocol["image_ids"] == inputs["validation_image_ids"])
    disjoint = True
    for split in ("train", "test", "excluded_buffer"):
        other = {Path(line.strip()).resolve() for line in (paths["split_dir"] / f"{split}.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()}
        disjoint &= not set(raw_members) & other
    checks["validation_membership_disjoint_from_train_test_buffer"] = disjoint
    for split, expected in dataset["split_sha256"].items():
        if digest(paths["split_dir"] / split) != expected:
            checks["all_frozen_split_hashes_match_dataset_manifest"] = False
            break
    else:
        checks["all_frozen_split_hashes_match_dataset_manifest"] = True
    expected = {}
    coverage = True
    for raw in raw_members:
        raw = inside(raw, [paths["raw_root"]])
        image = inside(paths["dataset_root"] / "images" / "val" / raw.name, [paths["dataset_root"]])
        label = inside(paths["dataset_root"] / "labels" / "val" / f"{raw.stem}.txt", [paths["dataset_root"]])
        metadata = inside(paths["dataset_root"] / "metadata" / "val" / f"{raw.stem}.json", [paths["dataset_root"]])
        width, height = png_dimensions(image)
        meta = read(metadata)
        if (png_dimensions(raw) != (width, height) or (meta["width"], meta["height"]) != (width, height)
                or meta["image"] != raw.relative_to(paths["raw_root"]).as_posix() or digest(raw) != digest(image)):
            coverage = False
        coverage &= {image, raw, label, metadata} <= set(source_paths)
        expected_paths[f"images/val/{image.name}"] = image
        expected_paths[f"raw_images/val/{raw.relative_to(paths['raw_root']).as_posix()}"] = raw
        expected[raw.stem] = {"image_id": raw.stem, "width": width, "height": height, "split": "val",
                              "image_path": str(image), "source_path": str(raw), "label_path": str(label),
                              "metadata_path": str(metadata), "ground_truth": ground_truth(label, width, height)}
    checks["validation_source_pixels_identity_and_input_coverage"] = coverage
    checks["all_input_roles_paths_and_current_tree_membership_exact"] = (
        roles.keys() == expected_paths.keys() and all(Path(roles[key]["path"]).resolve() == path.resolve()
                                                     for key, path in expected_paths.items()))
    checks["validation_label_counts_match_frozen_dataset"] = (sum(len(row["ground_truth"]) for row in expected.values())
                                                              == summary["val_boxes"] == dataset["counts"]["val"]["annotations"] == 596)
    metrics, records_by_size = {}, {}
    for size in (640, 960):
        records = lines(directory / f"predictions_{size}.jsonl")
        records_by_size[size] = records
        checks[f"prediction_{size}_same_ordered_validation_images"] = [row["image_id"] for row in records] == member_ids
        checks[f"prediction_{size}_identical_ground_truth_and_paths"] = all(
            all(row.get(key) == value for key, value in expected[row["image_id"]].items()) for row in records)
        valid, timed = True, True
        for row in records:
            valid &= row.get("eval_imgsz") == size and row.get("device") == "0" and row.get("precision") == "FP32"
            predictions = row["predictions"]
            valid &= len(predictions) <= 300
            for pred in predictions:
                box = pred["xyxy"]
                valid &= (type(pred["class_id"]) is int and pred["class_id"] in range(7)
                          and positive(pred["confidence"]) and .001 <= pred["confidence"] <= 1
                          and len(box) == 4 and all(type(x) in (int, float) and math.isfinite(x) for x in box)
                          and 0 <= box[0] < box[2] <= row["width"] and 0 <= box[1] < box[3] <= row["height"])
            timed &= positive(row.get("elapsed_seconds")) and all(type(value) in (int, float) and math.isfinite(value) and value >= 0
                                                                   for value in row.get("ultralytics_speed_ms", {}).values())
            timed &= set(row.get("ultralytics_speed_ms", {})) == {"preprocess", "inference", "postprocess"}
        checks[f"prediction_{size}_frozen_protocol_and_valid_boxes"] = valid
        environment = summary["environments"][str(size)]
        timed &= (positive(environment.get("warmup_seconds")) and environment.get("warmup_images") == 1
                  and positive(environment.get("group_elapsed_seconds"))
                  and environment["group_elapsed_seconds"] >= sum(row["elapsed_seconds"] for row in records)
                  and positive(environment.get("peak_allocated_bytes")))
        checks[f"prediction_{size}_actual_positive_timing_recorded"] = timed
        checks[f"prediction_{size}_actual_fp32_gpu_settings"] = (
            environment.get("device") == "0" and environment.get("precision") == "FP32"
            and environment.get("model_parameters_dtype") == "torch.float32"
            and environment.get("tf32_matmul") is False and environment.get("tf32_cudnn") is False
            and environment.get("actual_predictor_fp16") is False
            and environment.get("actual_predictor_imgsz") == [size, size]
            and environment.get("actual_predictor_device") == "cuda:0")
        actual = environment.get("actual_predictor_options", {})
        controls = {"imgsz": size, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
                    "rect": False, "augment": False, "agnostic_nms": False, "quantize": None}
        checks[f"prediction_{size}_actual_predictor_options_frozen"] = all(key in actual and actual[key] == value for key, value in controls.items())
        metrics[size] = score_detections(records, CLASSES, .25, .5)
        checks[f"metrics_{size}_recomputed_saved_predictions_match"] = metrics[size] == read(directory / f"metrics_{size}.json")
        checks[f"metrics_{size}_summary_agrees"] = summary["metrics"][str(size)] == {key: metrics[size][key] for key in ("mAP50", "mAP50_95", "operating_point")}
        checks[f"metrics_{size}_small_area_definition_and_null_if_absent"] = (
            metrics[size]["protocol"]["small_object_area_lt"] == 32 ** 2
            and (metrics[size]["operating_point"]["small_gt"] != 0 or metrics[size]["operating_point"]["small_recall"] is None))
    comparison = compare_scores(metrics[640], metrics[960])
    checks["paired_comparison_recomputed_matches_saved_and_summary"] = comparison == read(directory / "comparison.json") == summary["comparison"]
    events = lines(directory / "events.jsonl")
    stamps = [datetime.fromisoformat(row["at"]) for row in events]
    checks["events_ordered_without_failed_stage"] = bool(stamps) and stamps == sorted(stamps) and all(row.get("status") != "failed" for row in events)
    checks["inference_events_reached_640_images_in_each_arm"] = all(any(row.get("stage") == f"inference_{size}" and row.get("completed_images") == 640 for row in events) for size in (640, 960))
    checks["completion_last_publication_declared"] = bool(events) and events[-1].get("stage") == "artifact_publication" and events[-1].get("completion_published_last") is True
    checks["summary_declares_correct_scope"] = (
        summary.get("split") == "val" and summary.get("val_images") == 640 and summary.get("train_imgsz") == 640
        and summary.get("eval_imgsz") == [640, 960] and summary.get("same_weight") is True
        and summary.get("inputs_unchanged") is True and summary.get("test_inference_performed") is False
        and summary.get("training_performed") is False)
    return {"schema_version": 1, "kind": "saved_resolution_comparison_crosscheck", "status": "passed" if all(checks.values()) else "failed",
            "task_id": task_id, "reviewed_at": datetime.now(timezone.utc).isoformat(), "model_used": False,
            "gpu_inference_performed_by_reviewer": False, "checks": checks,
            "passed_checks": sum(checks.values()), "total_checks": len(checks), "source_files_checked": len(source_rows),
            "source_mismatches": mismatches, "comparison": comparison,
            "limitations": [
                "GT decoding, membership, source-byte checks and artifact-chain review are separate from the runner.",
                "Metric recomputation reuses detection_metrics; this is not a second independently implemented AP evaluator.",
                "Saved precision/timing options are crosschecked; no second detector inference or hardware benchmark is run.",
                "Completion mtime order is supporting local evidence and is not cryptographic proof of execution order.",
                "Image bootstrap does not handle correlated physical anomaly or cable-position groups.",
                "Single sequential 640-then-960 timing can be affected by warmup, order, temperature and concurrent GPU work.",
                "This validation-only same-weight comparison does not measure training-resolution effects or test generalization.",
            ]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--config")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = review(load_config(args.config), args.task_id)
    except Exception as error:
        report = {"status": "failed", "task_id": args.task_id, "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "passed_checks", "total_checks", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
