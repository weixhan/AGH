"""Freeze one pilot before arming any trial or requesting model inference."""
from pathlib import Path
import hashlib
import json
import os
from defect_researcher.comparison_protocol_v1 import make_protocol
from defect_researcher.comparison_mcp_server_v9 import _tools
from defect_researcher.comparison_case_runtime_v1 import Runtime

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs/comparison-pilot-v9'
IMPLEMENTATION = ROOT / 'outputs/comparison-implementation-v9'


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def record(path):
    p = Path(path).resolve()
    return {'path': str(p), 'sha256': sha(p), 'size_bytes': p.stat().st_size}
def save(path, value):
    with Path(path).open('x', encoding='utf8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False); f.write('\n')


def main():
    paths = [
        'defect_researcher/comparison_case_runtime_v1.py', 'defect_researcher/comparison_protocol_v1.py',
        'defect_researcher/comparison_mcp_server_v1.py', 'run_comparison_mcp_v1.py',
        'tools/verify_comparison_case_v1.py', 'tools/verify_comparison_model_v1.py',
        'tools/comparison_scope_guard_v1.mjs', 'tools/prepare_comparison_scope_v1.mjs',
        'tools/enable_comparison_scope_v1.mjs', 'tools/activate_comparison_mcp_v1.mjs',
        'tools/run_comparison_pilot_v1.mjs', 'tools/prepare_comparison_pilot_v1.py', 'tools/agh_ws_client.mjs',
        'agent/comparison_case_task_v4.md','agent/拒绝分支诊断协议V9.md', 'config/local.json', 'fixtures/labelguard_cases.json',
        'outputs/research-workflow-implementation-v1/freeze.json',
        'outputs/research-mcp-implementation-v2/freeze.json', 'outputs/comparison-pilot-v9/server-config.json',
        'tests/test_comparison_case_runtime_v1.py', 'tests/test_comparison_protocol_v1.py',
        'tests/test_comparison_evaluator_v1.py', 'tests/test_comparison_mcp_server_v1.py',
        'tests/test_comparison_model_verifier_v1.py', 'tools/test_comparison_scope_guard_v1.mjs',
        'defect_researcher/comparison_mcp_server_v9.py',
        'run_comparison_mcp_v9.py',
        'tools/comparison_scope_guard_v9.mjs',
        'tools/test_comparison_scope_guard_v9.mjs',
        'tools/prepare_comparison_scope_v9.mjs',
        'tools/enable_comparison_scope_v9.mjs',
        'tools/activate_comparison_mcp_v9.mjs',
        'tools/run_comparison_pilot_v9.mjs',
        'tools/comparison_branch_selection_v3.mjs','tools/test_comparison_branch_selection_v3.mjs',
        'tools/summarize_comparison_branches_v3.py','tests/test_comparison_branch_acceptance_v3.py',
        'outputs/comparison-implementation-v6/freeze.json',
        'outputs/comparison-pilot-v6/verification.json','outputs/comparison-pilot-v6/run_result.json',
        'outputs/comparison-pilot-v6/final_closure_verification.json',
        'outputs/comparison-implementation-v7/freeze.json',
        'outputs/comparison-pilot-v7/verification.json','outputs/comparison-pilot-v7/run_result.json',
        'tools/comparison_settlement_v1.mjs','tools/test_comparison_settlement_v1.mjs',
        'tools/verify_comparison_model_v9.py',
        'tests/test_comparison_model_verifier_v9.py',
        'tests/test_comparison_mcp_server_v9.py',
        'tools/prepare_comparison_pilot_v9.py',
        'outputs/comparison-native-title-reconciliation-v2/reconciliation.json',
        'outputs/comparison-native-title-reconciliation-v2/v3.jsonl',
        'outputs/comparison-native-title-reconciliation-v2/v4.jsonl',
        'outputs/comparison-native-title-reconciliation-v2/v5.jsonl',
        'tools/comparison_request_debit_v1.py','tests/test_comparison_request_debit_v1.py',
        'tools/close_comparison_branches_v3.py',
        'outputs/comparison-implementation-v8/freeze.json',
        'outputs/comparison-pilot-v9/request_capacity_ledger.json',
        'outputs/agh-title-repair-v1/repair_verification.json']
    for name in ['local-tests-final.json']:
        if json.loads((IMPLEMENTATION/name).read_text('utf8'))['status'] != 'passed':
            raise ValueError('Local source tests not passed')
    if json.loads((ROOT/'outputs/comparison-runtime-local-acceptance-v1/runtime-tests.json').read_text('utf8'))['status'] != 'passed':
        raise ValueError('Runtime source tests not passed')
    history = []
    for name, groups in [('research-workflow-implementation-v1/freeze.json', ('sources','archive','preserved_files')),
                         ('research-mcp-implementation-v2/freeze.json', ('sources','archive','proof_files'))]:
        value = json.loads((ROOT/'outputs'/name).read_text('utf8'))
        rows = [r for group in groups for r in value[group]]
        if any(sha(r['path']) != r['sha256'] for r in rows): raise ValueError('Protected history changed')
        history.append({'freeze': record(ROOT/'outputs'/name), 'checked_records': len(rows), 'unchanged': True})
    prior= json.loads((ROOT/'outputs/comparison-pilot-v6/verification.json').read_text('utf8'))
    if prior['status'] != 'passed_engineering_diagnostic' or prior['model_requests_phase_actual'] != 27:
        raise ValueError('Previous actual phase accounting differs')
    old_freeze= json.loads((ROOT/'outputs/comparison-implementation-v6/freeze.json').read_text('utf8'))
    old_members=[r for group in ('sources','archive','proof_files') for r in old_freeze[group]]
    if any(sha(r['path']) != r['sha256'] for r in old_members): raise ValueError('Frozen V6 evidence changed')
    history.append({'freeze':record(ROOT/'outputs/comparison-implementation-v6/freeze.json'),'checked_records':len(old_members),'unchanged':True})
    failed_freeze = json.loads((ROOT/'outputs/comparison-implementation-v7/freeze.json').read_text('utf8'))
    failed_members = [r for group in ('sources','archive','proof_files') for r in failed_freeze[group]]
    if failed_freeze['status'] != 'failed_diagnostic_preserved' or any(sha(r['path']) != r['sha256'] for r in failed_members):
        raise ValueError('Preserved V7 failure changed')
    failed_acceptance = json.loads((ROOT/'outputs/comparison-pilot-v7/verification.json').read_text('utf8'))
    failed_suite = json.loads((ROOT/'outputs/comparison-pilot-v7/run_result.json').read_text('utf8'))
    if failed_acceptance['status'] != 'failed' or failed_suite['status'] != 'stopped' or failed_acceptance['model_requests_this_diagnostic'] != failed_suite['model_requests_actual'] or failed_suite['model_requests_actual'] != 7 or prior['model_requests_phase_actual'] + failed_suite['model_requests_actual'] != 34:
        raise ValueError('Failed V7 actual cost does not close phase accounting')
    history.append({'freeze':record(ROOT/'outputs/comparison-implementation-v7/freeze.json'),'checked_records':len(failed_members),'unchanged':True,'original_status_preserved':'failed_diagnostic_preserved'})
    from tools.comparison_request_debit_v1 import validate_receipt
    capacity_path = OUT/'request_capacity_ledger.json'
    capacity = validate_receipt(capacity_path, root=ROOT)
    repaired = json.loads((ROOT/'outputs/agh-title-repair-v1/repair_verification.json').read_text('utf8'))
    if repaired['status'] != 'passed_local_repair' or repaired['agh_core_modified'] is not True:
        raise ValueError('Modified AGH repair has not passed local verification')
    for row in repaired['runtime_files']:
        if sha(row['path']) != row['sha256']: raise ValueError('Runtime differs from tested modified AGH')
    paths.extend(str(Path(row['archive']).relative_to(ROOT)) for row in repaired['runtime_files'])
    members = [record(ROOT/p) for p in paths]
    lock = IMPLEMENTATION/'source_lock.json'
    save(lock, {'schema_version':1,'kind':'comparison_case_implementation_v1','status':'passed',
                'scope':'Local tested implementation; actual pilot not yet run', 'files':members})
    catalogue = [{k:r[k] for k in ('name','description','inputSchema')} for r in _tools()]
    protocol = make_protocol('cmp-pilot-20261013-09', model={'slot':'primary','model':'agnes-3.0-flash','route':'account-defect-researcher'},
        task_prompt=(ROOT/'agent/comparison_case_task_v4.md').read_text('utf8'), tool_catalog=catalogue,
        source_paths={p:ROOT/p for p in paths}, generation_settings={'explicit_overrides':{},'runtime_defaults_shared':True}, stage='pilot')
    save(OUT/'protocol.json', protocol)
    selected=[r for r in protocol['trials'] if r['arm']=='F' and r['case_id'] == 'refuse_source_hash']
    if [r['case_id'] for r in selected] != ['refuse_source_hash']:raise ValueError('Exact diagnostic targets missing')
    selection={'schema_version':1,'arm':'F','case_ids':[r['case_id'] for r in selected],'trial_handles':[r['trial_handle'] for r in selected]}
    selection_hash=hashlib.sha256(json.dumps(selection,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf8')).hexdigest()
    suffix = hashlib.sha256(b'dr-compare-v9').hexdigest()[:8]
    public = {'schema_version':1, 'protocol_path':str(OUT/'protocol.json'),'protocol_sha256':sha(OUT/'protocol.json'),
        'source_lock':{'path':str(lock),'sha256':sha(lock)},'server_config':str(OUT/'server-config.json'), 'server_id':'dr-compare-v9',
        'scope_policy':{'schema_version':1,'workspace_root':str(OUT/'workspace'),
            'qualified_action_tool':'mcp_dr_compare_v9_'+suffix+'_execute_case_action_v1',
            'allowed_handles':selection['trial_handles'],
            'max_model_requests':6,'max_wall_seconds':120,'max_action_calls':8},
        'capacity_ledger':record(capacity_path),
        'runtime_version':record(ROOT/'outputs/agh-title-repair-v1/repair_verification.json'),
        'phase_model_budget':capacity['phase_model_budget'],
        'engineering_diagnostic':{'selected_trial_count':1,'selected_trials':[{k:r[k] for k in ('trial_id','trial_handle','case_id','arm')} for r in selected],'selection':selection,'selection_sha256':selection_hash,'planned_comparison_trials':9,'purpose':'Fresh F source-refusal diagnostic on modified AGH; legacy title usage remains unknown; not a complete comparison'},
        'model_accounting':{'primary_cap':6,'native_title_reserved_calls':1,'combined_per_trial_cap':7,'primary_wall_seconds':85,'native_title_and_export_reserve_seconds':35,'all_within_original_wall_seconds':120},
        'route_limitations':['C uses actual official MCP SDK stdio and host authorization; U/F use actual AGH SDK and Allow once',
                            'AGH native admin catalogue omits SDK annotations; action name, description and JSON schema are common',
                            'Post-execution independent evaluation does not reset or resume trial budgets',
                            'Uses modified local AGH with pinned title cancellation usage repair; historical V8 failure remains frozen']}
    save(OUT/'model_protocol.json',public)
    os.environ['DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH']=str(lock)
    os.environ['DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256']=sha(lock)
    runtime=Runtime(config_path=OUT/'server-config.json')
    registrations=[]
    for trial in protocol['trials']:
        runtime.prepare(trial['trial_id'],trial['case_id'],trial['arm'],trial_handle=trial['trial_handle'])
        registrations.append(json.loads((runtime.root/'trials'/trial['trial_handle']/'registration.json').read_text('utf8')))
    same=all(all(r['input_snapshot']==group[0]['input_snapshot'] and r['prepared_case']['case_root']==group[0]['prepared_case']['case_root']
                 for r in group) for case in protocol['case_ids'] for group in [[r for r in registrations if r['case_id']==case]])
    if not same: raise ValueError('Input paths or bytes differ by treatment')
    save(OUT/'preflight.json',{'schema_version':1,'status':'passed','planned_trials':9,'planned_per_arm':3,
        'same_input_paths_and_bytes':same,'registered_handles':[r['trial_handle'] for r in registrations],
        'all_trials_unarmed':not list(runtime.root.rglob('arm.json')),'model_calls_actual':0,'new_detector_calls':0,'gpu_seconds':0,
        'source_lock':public['source_lock'],'protocol_sha256':sha(OUT/'protocol.json'),'protected_history':history,
        'route_limitations':public['route_limitations']})
    print(json.dumps({'status':'preregistered_not_executed','planned_trials':9,'model_calls_actual':0,'same_input_paths_and_bytes':same}))


if __name__=='__main__': main()
