// Authorised activation only through the official loopback plugin-admin BFF.
import { readFile, writeFile, stat } from 'node:fs/promises';
import { randomUUID, createHash } from 'node:crypto';
import { dirname, resolve, join, relative, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
if (![2,4].includes(args.length) || args[0] !== '--protocol' || args.length === 4 && args[2] !== '--trace')
  throw new Error('Usage: node tools/enable_comparison_scope_v6.mjs --protocol <model_protocol.json> [--trace <fresh receipt.json>]');
const protocolPath = resolve(args[1]), output = dirname(protocolPath);
const inside = path => { const value = relative(root, resolve(path)); return value && !value.startsWith('..') && !isAbsolute(value); };
if (!inside(protocolPath) || protocolPath !== join(output, 'model_protocol.json')) throw new Error('Expected project-owned model_protocol.json');
const tracePath = args.length === 4 ? resolve(args[3]) : join(output, 'scope_activation.json');
if (dirname(tracePath) !== output || tracePath === protocolPath || !tracePath.endsWith('.json')) throw new Error('Receipt must be a fresh JSON file beside the protocol');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const protocolBytes = await readFile(protocolPath), protocol = JSON.parse(protocolBytes.toString('utf8'));
const candidateRecord = JSON.parse(await readFile(join(output, 'scope_candidate.json'), 'utf8'));
const candidate = join(resolve(protocol.scope_policy.workspace_root), '.agh/extensions/comparison-scope-guard-v6');
const id = '@defect-researcher/comparison-scope-guard-v6', origin = 'http://127.0.0.1:4177';
if (candidateRecord.status !== 'prepared_not_activated' || candidateRecord.package_id !== id ||
    resolve(candidateRecord.candidate) !== candidate || candidateRecord.protocol_sha256 !== hash(protocolBytes) ||
    !inside(candidate) || candidateRecord.files?.length !== 4 ||
    [...candidateRecord.files.map(row => row.name)].sort().join(',') !== 'guard.mjs,index.mjs,package.json,policy.json')
  throw new Error('Candidate is not the exact freshly prepared protocol package');
async function freshCandidate() {
  if (hash(await readFile(protocolPath)) !== candidateRecord.protocol_sha256) throw new Error('Protocol changed before activation');
  for (const record of candidateRecord.files) {
    const path = join(candidate, record.name);
    if (resolve(record.path) !== path || hash(await readFile(path)) !== record.sha256 || (await stat(path)).size !== record.size_bytes)
      throw new Error('Prepared candidate changed before activation');
  }
}
await freshCandidate();
const trace = { schema_version: 1, interface: 'official plugin-admin BFF', origin, user_authorized: true,
  started_at: new Date().toISOString(), package_id: id, protocol_path: protocolPath,
  protocol_sha256: candidateRecord.protocol_sha256, candidate, steps: [], complete: false,
  credentials_read: false, agh_core_modified: false, old_plugins_modified: false, new_detection_inference_performed: false };
await writeFile(tracePath, JSON.stringify(trace, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
const save = () => writeFile(tracePath, JSON.stringify(trace, null, 2) + '\n');
async function request(path, body) {
  const response = await fetch(`${origin}/admin/plugins/api/${path}`, {
    method: body ? 'POST' : 'GET', headers: { Origin: origin, Accept: 'application/json', 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}), signal: AbortSignal.timeout(30_000) });
  const data = await response.json();
  if (!response.ok) throw new Error(`${path}: ${response.status}: ${JSON.stringify(data)}`);
  return data;
}
try {
  const context = await request('context');
  if (context.readOnly || context.profile !== 'local-dev' || typeof context.clientId !== 'string' || !context.clientId)
    throw new Error('Expected writable local-dev official plugin administration');
  const base = { profile: context.profile, clientId: context.clientId };
  const before = await request('list', { profile: base.profile });
  if (!Array.isArray(before.packages)) throw new Error('Invalid official package inventory');
  trace.before = before.packages.find(row => row.id === id) ?? null;
  if (trace.before) throw new Error('Package already exists; preserve its state and receipt instead of blind overwrite');
  await save();
  async function effect(path, body) {
    await freshCandidate();
    const params = { ...base, commandId: `research-workflow-scope-${randomUUID()}`, ...body };
    const step = { path, params }; trace.steps.push(step); await save();
    step.receipt = await request(path, params); await save();
    if (typeof step.receipt.operationId !== 'string' || !step.receipt.operationId) throw new Error(`${path} did not return an official operation receipt`);
    const deadline = Date.now() + 60_000;
    for (;;) {
      step.operation = await request('operation/get', { profile: base.profile, operationId: step.receipt.operationId }); await save();
      if (['completed','failed','cancelled','rolled-back'].includes(step.operation.state)) break;
      if (Date.now() >= deadline) throw new Error(`${path} operation timeout; preserve receipt and inspect state before retry`);
      await new Promise(wait => setTimeout(wait, 500));
    }
    if (step.operation.state !== 'completed') throw new Error(`${path} failed: ${JSON.stringify(step.operation)}`);
    console.log(JSON.stringify({ action: path, state: step.operation.state }));
    return step.operation;
  }
  const source = { type: 'file', ref: 'file:./' + relative(root, candidate).replaceAll('\\', '/') };
  const inspected = await effect('inspect', { source });
  const preview = inspected.preview ?? inspected.result?.preview;
  if (!preview || preview.id !== id || !Array.isArray(preview.blockers) || preview.blockers.length ||
      preview.dependencies && Object.keys(preview.dependencies).length || typeof preview.integrity !== 'string' ||
      typeof preview.capabilityHash !== 'string') throw new Error('Unexpected, externally dependent or blocked scope preview');
  trace.preview = preview; await save();
  await effect('install', { source, expectedIntegrity: preview.integrity });
  await effect('trust', { id, expectedIntegrity: preview.integrity, capabilityHash: preview.capabilityHash });
  await effect('enable', { id, expectedInstalledIntegrity: preview.integrity, expectedActiveIntegrity: null });
  await freshCandidate();
  trace.after = (await request('list', { profile: base.profile })).packages.find(row => row.id === id);
  trace.complete = trace.after?.trusted === true && trace.after?.actual === 'running' && trace.after?.actualIntegrity === preview.integrity;
  trace.withdrawal = { interface: 'official plugin-admin BFF', path: 'disable',
    params: { ...base, commandId: '<new unique command id>', id } };
  if (!trace.complete) throw new Error('Scope did not reach its inspected trusted running state');
} catch (error) {
  trace.failure = { type: error.name, message: error.message }; process.exitCode = 1;
} finally {
  trace.finished_at = new Date().toISOString(); await save();
  console.log(JSON.stringify({ complete: trace.complete, path: tracePath, failure: trace.failure }));
}
