"""Independently verify one guarded Agnes read of completed artifact recovery.

Masked official decimals remain unknown. Exact scientific values are checked
against the unmasked public SDK observation and the sealed scientific review.
This verifier does not perform detection inference or repeat scientific scoring.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.verify_sliced_model_run import official_payload, UNKNOWN, exact, normalize_path
from tools.verify_diagnosis_run import decode, read, lines
from tools.verify_sliced_artifact_recovery import REQUIRED_CHECKS, PRIMARY_SHA256

STATUS_TOOL = "mcp_defect_researcher_45e5cef9_get_task_status"
TOOL = "verify_sliced_artifact_recovery"
SOURCE_TASK = "09c5ce4aceb7426e87af5334bdb03eb4"
COMPACT_KEYS = {"status", "task_id", "slicing_status", "candidate_status", "source_original_status",
 "source_computation_task_id", "operation_kind", "artifact_recovery_status", "new_detection_inference_performed",
 "original_final_review_completed_within_1800_seconds", "original_completion_absent",
 "reference_reused", "input_hashes_unchanged", "training_performed", "test_inference_performed",
 "baseline", "sliced", "medium", "failed_gates"}
COUNTS = {"tp", "fp", "fn", "normal_fp_images", "normal_fp_boxes"}
DECIMALS = {"mAP50", "mAP50_95", "precision", "recall", "normal_image_fp_rate"}
MEDIUM = {"gt", "images", "medium_tp_gain", "medium_gain_images", "medium_recovered_gt", "medium_lost_gt"}
MASKABLE = {(arm, key) for arm in ("baseline", "sliced") for key in DECIMALS}

def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def valid(value, masks=()):
    if not isinstance(value, dict) or value.keys() != COMPACT_KEYS:
        return False
    if (value["status"] != "completed" or not isinstance(value["task_id"], str)
        or re.fullmatch(r"[a-f0-9]{32}", value["task_id"]) is None or value["slicing_status"] != "passed"
        or value["candidate_status"] not in {"accepted", "stop"} or value["source_original_status"] != "failed"
        or value["source_computation_task_id"] != SOURCE_TASK or value["artifact_recovery_status"] != "passed"
        or value["operation_kind"] != "artifact_only_recovery"):
        return False
    for key in ("new_detection_inference_performed", "training_performed", "test_inference_performed", "original_final_review_completed_within_1800_seconds"):
        if value[key] is not False:
            return False
    for key in ("reference_reused", "input_hashes_unchanged", "original_completion_absent"):
        if value[key] is not True:
            return False
    allowed = {tuple(path) for path in masks}
    for arm in ("baseline", "sliced"):
        row = value[arm]
        if not isinstance(row, dict) or row.keys() != COUNTS | DECIMALS:
            return False
        if any(type(row[key]) is not int or row[key] < 0 for key in COUNTS):
            return False
        for key in DECIMALS:
            n = row[key]
            if n == UNKNOWN and (arm, key) in allowed and (arm, key) in MASKABLE:
                continue
            if isinstance(n, bool) or not isinstance(n, (int, float)) or not math.isfinite(n) or not 0 <= n <= 1:
                return False
    medium = value["medium"]
    if not isinstance(medium, dict) or medium.keys() != MEDIUM:
        return False
    if any(type(medium[key]) is not int or (key != "medium_tp_gain" and medium[key] < 0) for key in MEDIUM):
        return False
    return isinstance(value["failed_gates"], list) and all(isinstance(x, str) and x for x in value["failed_gates"]) and len(set(value["failed_gates"])) == len(value["failed_gates"])

def compact(report, masks=()):
    try:
        value = {"status": report["status"], "task_id": report["task_id"],
                 **{key: report["summary"][key] for key in COMPACT_KEYS - {"status", "task_id"}}}
        paths = [path[1:] for path in masks if path and path[0] == "summary"]
        return value if valid(value, paths) else None
    except (KeyError, TypeError):
        return None

def final_value(text, *, official=False):
    blocks = re.findall(r"```json\s*\n(.*?)\n```", text, re.S)
    if len(blocks) != 1:
        return None, []
    try:
        value, masks = official_payload(blocks[0]) if official else (decode(blocks[0]), [])
    except (ValueError, json.JSONDecodeError):
        return None, []
    return (value, masks) if valid(value, masks) else (None, masks)

def projected(observed, expected, masks=()):
    if not valid(observed, masks) or not valid(expected):
        return False
    target = copy.deepcopy(expected)
    for path in masks:
        if tuple(path) not in MASKABLE or observed[path[0]][path[1]] != UNKNOWN:
            return False
        target[path[0]][path[1]] = UNKNOWN
    return exact(observed, target)

def aligned_ready(row, workspace):
    out = copy.deepcopy(row)
    for target in (out.get("data", {}), out.get("data", {}).get("policy", {})):
        if normalize_path(target.get("workspace_root")) == normalize_path(workspace):
            target["workspace_root"] = "<workspace>"
    return out

def check_ledger(rows, runner, disk, workspace):
    calls = [x for x in rows if x.get("type") == "tool/call"]
    results = [x for x in rows if x.get("type") == "tool/result"]
    ready = [x for x in rows if x.get("type", "").endswith("/scope-ready")]
    gates = [x for x in rows if x.get("type", "").endswith("/scope-decision")]
    approvals = [x for x in rows if x.get("type") == "approval/decided"]
    requests = [x for x in rows if x.get("type") == "request/sent"]
    costs = [x for x in rows if x.get("type") == "cost/ledger" and x.get("data", {}).get("purpose") == "inference"]
    ends = [x for x in rows if x.get("type") == "turn/end"]
    call = calls[0] if len(calls) == 1 else {}
    result = results[0] if len(results) == 1 else {}
    gate = gates[0] if len(gates) == 1 else {}
    rdy = ready[0] if len(ready) == 1 else {}
    texts = [x.get("text") for x in result.get("data", {}).get("content", []) if x.get("type") == "text"]
    observed, masks, parse_error = {}, [], None
    try:
        if len(texts) != 1:
            raise ValueError("Result must have one text block")
        observed, masks = official_payload(texts[0])
    except (ValueError, TypeError, json.JSONDecodeError) as error:
        parse_error = type(error).__name__
    target = compact(disk)
    official_compact = compact(observed, masks)
    compact_masks = [path[1:] for path in masks if path and path[0] == "summary" and tuple(path[1:]) in MASKABLE]
    final = next((x for x in rows if x.get("type") == "assistant/message" and ends and x.get("seq") == ends[-1]["data"].get("lastAssistantSeq")), {})
    final_text = "\n".join(x["text"] for x in final.get("data", {}).get("content", []) if x.get("type") == "text")
    fv, fm = final_value(final_text, official=True)
    sdk_final = next((x for x in runner.get("final_texts", []) if x.get("seq") == final.get("seq") and x.get("type") == "assistant/message"), {})
    sdk_text = "\n".join(x["text"] for x in sdk_final.get("data", {}).get("content", []) if x.get("type") == "text")
    sdk_fv = final_value(sdk_text)[0]
    sdk_result = next((x for x in runner.get("results", []) if x.get("seq") == result.get("seq")), {})
    sdk_call = runner.get("calls", [])
    sdk_gate = runner.get("hook_events", [])
    policy = {"schema_version": 1, "workspace_root": "<workspace>", "task_id": disk.get("task_id"),
              "qualified_status_tool": STATUS_TOOL, "max_status_calls": 1}
    permitted_approval = (len(approvals) == len(runner.get("permissions", [])) == 0 or
        len(approvals) == len(runner.get("permissions", [])) == 1
        and approvals[0]["data"].get("verdict") == "allowed-once"
        and approvals[0]["data"].get("scope") == f"tool:{STATUS_TOOL}:execute"
        and call.get("seq", 0) < approvals[0].get("seq", 0) < result.get("seq", 0)
        and runner["permissions"][0].get("tool") == STATUS_TOOL
        and runner["permissions"][0].get("input") == {"task_id": disk.get("task_id")}
        and runner["permissions"][0].get("decision") == "allowed-once"
        and runner["permissions"][0].get("tool_call_id") == call.get("data", {}).get("toolUseId"))
    checks = {
      "official_ledger_contiguous": [x.get("seq") for x in rows] == list(range(1, len(rows) + 1)),
      "fresh_session_identity": bool(rows and rows[0].get("type") == "session/start" and rows[0]["data"].get("key") == runner.get("session_id")),
      "exactly_one_model_status_read": len(calls) == len(results) == 1 and call.get("origin") == "model" and call.get("data", {}).get("name") == STATUS_TOOL,
      "only_fixed_recovered_task_argument": call.get("data", {}).get("args") == {"task_id": disk.get("task_id")},
      "single_result_paired_after_call": bool(result and result.get("data", {}).get("toolUseId") == call.get("data", {}).get("toolUseId") and result.get("seq", 0) > call.get("seq", 0) and result.get("sourceEventSeqs") == [call.get("seq")]),
      "successful_status_result_without_refusal": result.get("data", {}).get("isError") is False and result.get("data", {}).get("code") not in {"HOOK_DENIED", "APPROVAL_REJECTED"},
      "scope_ready_before_first_model_request": bool(rdy and requests and rdy["seq"] < requests[0]["seq"] < call.get("seq", 0)),
      "exact_pinned_scope_ready_policy": rdy.get("data", {}).get("mode") == "artifact-recovery" and exact(rdy.get("data", {}).get("policy"), policy) and rdy.get("data", {}).get("session_key") == runner.get("session_id") and rdy.get("data", {}).get("workspace_root") == "<workspace>",
      "public_sdk_ready_exact_event_and_workspace": bool(rdy and runner.get("scope_ready", {}).get("seq") == rdy["seq"] and runner["scope_ready"].get("type") == rdy["type"] and normalize_path(runner["scope_ready"].get("data", {}).get("workspace_root")) == normalize_path(workspace) and exact(aligned_ready(runner["scope_ready"], workspace).get("data"), rdy.get("data"))),
      "paired_gate_allowed_between_call_and_result": len(gates) == 1 and call.get("seq", 0) < gate.get("seq", 0) < result.get("seq", 0) and gate.get("data", {}).get("allow") is True and gate.get("data", {}).get("reason") is None and gate.get("data", {}).get("tool_use_id") == call.get("data", {}).get("toolUseId") and gate.get("data", {}).get("name") == STATUS_TOOL and gate.get("data", {}).get("session_key") == runner.get("session_id"),
      "ready_and_gate_same_registered_extension": bool(rdy and gate and rdy.get("origin") == gate.get("origin") and str(rdy.get("origin", "")).startswith("ext:plugin/") and rdy["type"].rsplit("/", 1)[0] == gate["type"].rsplit("/", 1)[0]),
      "public_sdk_calls_exact_official": len(sdk_call) == 1 and sdk_call[0].get("seq") == call.get("seq") and sdk_call[0].get("name") == call.get("data", {}).get("name") and exact(sdk_call[0].get("args"), call.get("data", {}).get("args")) and sdk_call[0].get("origin") == call.get("origin"),
      "public_sdk_gate_exact_official": len(sdk_gate) == 1 and sdk_gate[0].get("seq") == gate.get("seq") and sdk_gate[0].get("type") == gate.get("type") and exact(sdk_gate[0].get("data"), gate.get("data")),
      "optional_status_allow_once_exact_budget": bool(permitted_approval),
      "official_result_parsed_without_restoring_masked_numbers": parse_error is None,
      "official_known_counts_and_categories_match_disk": observed.get("tool") == TOOL and projected(official_compact, target, compact_masks),
      "public_sdk_exact_full_summary_and_evidence": sdk_result.get("payload", {}).get("task_id") == disk.get("task_id") and sdk_result.get("is_error") is False and exact(sdk_result.get("payload", {}).get("summary"), disk.get("summary")) and exact(sdk_result.get("payload", {}).get("evidence"), disk.get("evidence")),
      "model_request_real_agnes_success": bool(costs and any(x["data"].get("response", {}).get("status") == 200 for x in costs) and all(x["data"].get("model") == "agnes-3.0-flash" and x["data"].get("response", {}).get("status") == 200 for x in costs)),
      "one_completed_turn_after_tool_result": len(ends) == 1 and ends[0]["data"].get("reason") == "completed" and final.get("seq", 0) > result.get("seq", 0) and ends[0]["seq"] > final.get("seq", 0),
      "official_final_compact_known_evidence_exact": projected(fv, target, fm),
      "public_sdk_final_compact_exact_unmasked": target is not None and exact(sdk_fv, target) and exact(runner.get("final_json"), target),
      "host_runner_completed_without_export_failure": runner.get("status") == "completed" and not runner.get("failure") and not runner.get("export_failure"),
      "completed_artifact_recovery_preserves_source_failure": disk.get("status") == "completed" and disk.get("tool") == TOOL and disk.get("summary", {}).get("source_original_status") == "failed" and runner.get("source_execution_reclassified") is False,
      "no_detector_inference_or_training_in_model_read": disk.get("summary", {}).get("new_detection_inference_performed") is False and runner.get("new_detection_inference_performed") is False and disk.get("summary", {}).get("training_performed") is False and disk.get("summary", {}).get("test_inference_performed") is False,
      "model_inference_and_catalog_boundaries_recorded": runner.get("new_model_inference_performed") is True and runner.get("tool_catalog_narrowed") is False,
    }
    return {"checks": checks, "task_id": disk.get("task_id"), "session_id": runner.get("session_id"),
        "event_count": len(rows), "tool_call_count": len(calls), "approval_count": len(approvals),
        "masked_numeric_paths_not_recovered": masks, "masked_final_numeric_paths_not_recovered": fm, "parse_error": parse_error,
        "final_model_text": final_text}

def check_binding(independent, task_dir, output_root, task_id, disk):
    """Bind a previously completed full review without rereading images or predicting."""
    checks = {
      "full_scientific_review_passed_typed_nonzero_counts": isinstance(independent, dict) and independent.get("status") == "passed"
       and type(independent.get("passed_checks")) is int and type(independent.get("total_checks")) is int
       and independent["passed_checks"] == independent["total_checks"] > 0,
      "full_scientific_review_all_checks_true": isinstance(independent.get("checks"), dict) and bool(independent["checks"])
       and set(independent["checks"]) == set(REQUIRED_CHECKS) and all(value is True for value in independent["checks"].values())
       and independent.get("total_checks") == len(independent["checks"]),
      "full_review_same_recovery_and_original_computation": independent.get("task_id") == task_id and independent.get("computation_task_id") == SOURCE_TASK,
      "full_review_original_pipeline_failure_preserved": independent.get("original_business_status") == "failed"
       and independent.get("original_completion_absent") is True and independent.get("original_pipeline_acceptance_passed") is False,
      "full_review_exact_kind_and_zero_new_computation_contract": all(exact(independent.get(key), value) for key, value in {
       "kind":"saved_sliced_artifact_recovery_review", "schema_version":1, "prepublication":True, "model_used":False,
       "gpu_inference_performed_by_reviewer":False, "new_predict_calls":0, "new_gpu_calls":0, "new_gpu_seconds":0}.items()),
    }
    try:
        task_dir, output_root = Path(task_dir).resolve(), Path(output_root).resolve()
        if not re.fullmatch(r"[a-f0-9]{32}", task_id) or task_dir.name != task_id or task_dir.parent != output_root:
            raise ValueError("Unsafe recovery directory or task identity")
        completion_path, manifest_path = task_dir / "completion.json", task_dir / "artifact_manifest.json"
        completion, manifest = read(completion_path), read(manifest_path)
        checks["completion_and_manifest_same_recovery_task"] = (completion.get("task_id") == manifest.get("task_id") == task_id
          and completion.get("status") == manifest.get("status") == "completed" and completion.get("tool") == manifest.get("tool") == TOOL
          and completion.get("artifact_manifest_sha256") == digest(manifest_path))
        files = manifest.get("files")
        if not isinstance(files, list) or not files:
            raise ValueError("Missing sealed recovery files")
        seen, sealed = set(), True
        for row in files:
            name = row.get("name")
            if (not isinstance(name, str) or Path(name).name != name or name in seen
               or name in {"completion.json", "artifact_manifest.json"}):
                raise ValueError("Unsafe or duplicate sealed file")
            seen.add(name); path = (task_dir / name).resolve()
            if path.parent != task_dir:
                raise ValueError("Sealed file escapes recovery directory")
            sealed = sealed and normalize_path(row.get("path")) == normalize_path(path) and type(row.get("size_bytes")) is int
            sealed = sealed and row["size_bytes"] == path.stat().st_size and row.get("sha256") == digest(path)
            sealed = sealed and completion.get("artifacts_sha256", {}).get(name) == row.get("sha256")
        checks["all_sealed_artifacts_current_bytes_unchanged"] = (sealed and {"recovery_result.json", "independent_verification.json", "recovery_source_manifest.json"} <= seen
          and set(completion.get("artifacts_sha256", {})) == seen)
        source = output_root / SOURCE_TASK
        failure_path = source / "failure.json"
        original = read(failure_path)
        checks["original_actual_failure_remains_failed_without_completion"] = original.get("status") == "failed" and original.get("task_id") == SOURCE_TASK and not (source / "completion.json").exists()
        checks["independent_review_source_failure_hash_matches_current_bytes"] = independent.get("source_failure_sha256") == digest(failure_path)
        checks["independent_review_source_snapshot_hash_matches_current_bytes"] = independent.get("source_manifest_sha256") == digest(task_dir / "recovery_source_manifest.json")
        checks["independent_review_protocol_hash_matches_sealed_recovery_protocol"] = independent.get("task_protocol_sha256") == digest(task_dir / "recovery_protocol.json")
        recovery_protocol = read(task_dir / "recovery_protocol.json")
        checks["recovery_protocol_separately_frozen_engineering_version_three"] = recovery_protocol.get("artifact_review_implementation_version") == 3 and type(recovery_protocol.get("artifact_review_implementation_version")) is int
        checks["independent_review_reviewer_source_hash_matches_current_code"] = independent.get("independent_reviewer_sha256") == digest(ROOT / "tools" / "verify_sliced_artifact_recovery.py")
        checks["independent_review_primary_oracle_source_hash_matches_fixed_code"] = independent.get("primary_scientific_verifier_sha256") == PRIMARY_SHA256 == digest(ROOT / "tools" / "verify_sliced_run.py")
        checks["independent_review_verified_complete_source_summary_exact"] = exact(independent.get("verified_source_summary"), original.get("summary"))
        summary_sha = hashlib.sha256(json.dumps(original.get("summary"), sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
        checks["independent_review_canonical_source_summary_hash_exact"] = independent.get("verified_source_summary_sha256") == summary_sha
        checks["recovered_science_exact_original_saved_complete_cohort_summary"] = all(exact(disk.get("summary", {}).get(key), original.get("summary", {}).get(key))
          for key in ("baseline", "sliced", "medium", "failed_gates", "candidate_status", "slicing_status", "reference_reused", "input_hashes_unchanged"))
        evidence = disk.get("evidence", {})
        checks["result_source_failure_hash_matches_current_original"] = evidence.get("source_failure_sha256") == digest(failure_path)
        checks["result_source_snapshot_hash_matches_sealed_snapshot"] = evidence.get("source_manifest_sha256") == digest(task_dir / "recovery_source_manifest.json")
        checks["result_independent_science_hash_matches_sealed_review"] = evidence.get("independent_verification_sha256") == digest(task_dir / "independent_verification.json")
        checks["new_artifact_operation_gpu_and_call_budgets_are_zero"] = (disk.get("summary", {}).get("new_formal_calls") == 0
          and type(disk["summary"].get("new_formal_calls")) is int and disk["summary"].get("new_warmup_calls") == 0
          and type(disk["summary"].get("new_warmup_calls")) is int and disk["summary"].get("new_gpu_seconds") == 0
          and type(disk["summary"].get("new_gpu_seconds")) in (int, float))
        checks["old_final_review_deadline_not_reclassified"] = disk.get("summary", {}).get("original_final_review_completed_within_1800_seconds") is False
        checks["binding_files_readable_and_safe"] = True
        return {"checks": checks, "passed": all(checks.values()), "task_completion_sha256": digest(completion_path),
          "task_manifest_sha256": digest(manifest_path), "independent_verification_sha256": digest(task_dir / "independent_verification.json"),
          "source_failure_sha256": digest(failure_path), "source_manifest_sha256": digest(task_dir / "recovery_source_manifest.json"),
          "scope": "completed_full_scientific_review_binding_without_detection_or_science_recomputation"}
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        checks["binding_files_readable_and_safe"] = False
        return {"checks": checks, "passed": False, "error": {"type": type(error).__name__, "message": str(error)}}

def review(directory):
    directory = Path(directory).resolve()
    output_root = ROOT / "outputs"
    if directory != output_root / "agh-sliced-artifact-model-v3":
        raise ValueError("Only the fixed artifact-only model workspace is accepted")
    runner = read(directory / "runner.json")
    task_id = runner.get("task_id")
    if not isinstance(task_id, str) or re.fullmatch(r"[a-f0-9]{32}", task_id) is None:
        raise ValueError("Unsafe recovery task identity")
    task_dir = output_root / task_id
    disk = read(task_dir / "recovery_result.json")
    independent = read(task_dir / "independent_verification.json")
    rows = lines(directory / "session.jsonl")
    workspace = directory / "workspace"
    report = check_ledger(rows, runner, disk, workspace)
    binding = check_binding(independent, task_dir, output_root, task_id, disk)
    report["checks"].update(binding["checks"])
    activation = read(directory / "activation.json")
    policy = read(workspace / ".agh/extensions/sliced-artifact-scope-guard-v3/policy.json")
    report["checks"].update({
      "runner_bound_to_fixed_guard_workspace_and_policy": normalize_path(runner.get("cwd")) == normalize_path(workspace) and exact(runner.get("policy"), policy)
       and policy.get("task_id") == task_id and policy.get("max_status_calls") == 1,
      "scope_activation_official_trusted_running": activation.get("complete") is True and activation.get("after", {}).get("trusted") is True
       and activation["after"].get("actual") == "running" and activation.get("package_id") == "@defect-researcher/sliced-artifact-scope-guard-v3",
      "collector_completion_hash_bound": runner.get("task_completion_sha256") == digest(task_dir / "completion.json"),
      "scientific_binding_passed": binding["passed"],
      "html_session_export_present": (directory / "session.html").is_file(),
    })
    paths = [directory / "runner.json", directory / "session.jsonl", directory / "session.html"] + sorted(path for path in task_dir.iterdir() if path.is_file())
    scan = [{"path": str(path), "candidate_count": len(re.findall(rb"\bsk-[A-Za-z0-9._-]{12,}", path.read_bytes()))} for path in paths]
    report["checks"]["no_credential_candidates_in_exports_or_recovery_artifacts"] = all(x["candidate_count"] == 0 for x in scan)
    report.update(schema_version=1, verification_kind="official_scoped_artifact_only_recovery_model_read",
      status="passed" if all(report["checks"].values()) else "failed", checks_passed=sum(report["checks"].values()),
      checks_total=len(report["checks"]), reasons=[key for key, value in report["checks"].items() if not value],
      model_used=True, new_model_inference_performed=True, new_detection_inference_performed=False,
      source_original_status="failed", source_execution_reclassified=False, scientific_binding=binding,
      evidence_sha256={path.name: digest(path) for path in paths[:3]}, secret_scan=scan,
      numeric_redaction_rule="Official masked decimal values remain unknown. Integer counts and categories must remain directly verifiable; exact full numbers are bound through public SDK and the sealed independent scientific review.",
      limitations=["This is a fresh model read of an artifact-only recovery, not a rerun or success reclassification of the original model business task.",
       "The detector performs no new calls; Agnes still performs model inference to read and explain the completed report.",
       "The execution guard restricts tool calls but does not narrow the model-visible tool catalog.",
       "The one-call budget is held in memory and does not survive a Host reload.",
       "The saved scientific conclusion is restricted to the same-weight validation comparison; it does not prove autonomous research or test generalization."])
    scope_keys = {"exactly_one_model_status_read", "only_fixed_recovered_task_argument", "single_result_paired_after_call",
      "successful_status_result_without_refusal", "scope_ready_before_first_model_request", "exact_pinned_scope_ready_policy",
      "public_sdk_ready_exact_event_and_workspace", "paired_gate_allowed_between_call_and_result", "ready_and_gate_same_registered_extension",
      "public_sdk_calls_exact_official", "public_sdk_gate_exact_official", "optional_status_allow_once_exact_budget",
      "runner_bound_to_fixed_guard_workspace_and_policy", "scope_activation_official_trusted_running"}
    report["strict_tool_scope_passed"] = all(report["checks"][key] for key in scope_keys)
    return report

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=ROOT / "outputs" / "agh-sliced-artifact-model-v3")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = review(args.run_dir)
    except Exception as error:
        report = {"status": "failed", "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "checks_passed", "checks_total", "reasons", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())
