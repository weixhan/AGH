// Resolve the checkout's emitted .js import specifiers to their TypeScript sources.
// Node's built-in TypeScript transform handles the source without a helper process.
import { registerHooks } from 'node:module';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

registerHooks({
  resolve(specifier, context, nextResolve) {
    try { return nextResolve(specifier, context); }
    catch (error) {
      if (context.parentURL?.includes('/agnes-harness/') && /^\.\.?\//.test(specifier) && specifier.endsWith('.js')) {
        const source = new URL(specifier.slice(0, -3) + '.ts', context.parentURL);
        if (existsSync(fileURLToPath(source))) return nextResolve(source.href, context);
      }
      throw error;
    }
  },
});
