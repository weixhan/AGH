// Official dynamic manifest check; it never connects or registers the sidecar.
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {tsImport} from '../../agnes-harness/node_modules/tsx/dist/esm/api/index.mjs';
import {SERVER_ID,TOOLS_PREFIX,ACTION_TOOL,READ_TOOL} from './resolution_research_scope_guard_v1.mjs';

export async function checkIdentity(){
 const [{checkManifest},{mcpServerRowsFromDefinitions}]=await Promise.all([
  tsImport('../../agnes-harness/packages/extension-api/src/manifest.ts',import.meta.url),
  tsImport('../../agnes-harness/packages/worker-runtime/src/mcp-server-rows.ts',import.meta.url),
 ]);
 let connections=0;
 const definition={serverId:SERVER_ID,displayName:'DefectResearcher bounded scientific recovery',
  transport:{kind:'stdio',executable:'python.exe',args:['run_resolution_research_mcp_v1.py']},secretBinding:{kind:'none'},
  toolPolicy:{allow:['research_action_v1','research_read_v1']}};
 const derived=mcpServerRowsFromDefinitions([{definition,revision:'engineering-only',desired:'enabled',trust:'trusted'}],
  {connect:()=>{connections++;throw new Error('Identity preflight must not connect');}});
 if(derived.rows.length!==1||derived.skipped.length||connections)throw new Error('Official row derivation failed or connected');
 const manifest=derived.rows[0].manifest,checked=checkManifest(manifest);
 if(!checked.ok||manifest.capabilities.tools.prefix!==TOOLS_PREFIX||TOOLS_PREFIX.length>32||ACTION_TOOL.length>64||READ_TOOL.length>64)
  throw new Error('Official scientific identity rejected: '+JSON.stringify(checked));
 return{status:'passed',server_id:SERVER_ID,prefix:TOOLS_PREFIX,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,
  native_manifest_valid:true,connections,model_requests:0,gpu_tasks:0};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await checkIdentity()));
