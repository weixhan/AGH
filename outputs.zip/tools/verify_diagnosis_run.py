"""Read-only diagnosis review with separately implemented matching and IoU.

The reviewer never imports the diagnosis scorer or detection_metrics. It binds
the new report to the published comparison and rereads validation source labels.
It checks artifact consistency, not causal explanations or generalization.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

TOOL = "diagnose_validation_errors"
SOURCE_TOOL = "compare_validation_resolutions"
SOURCE_TASK = "8d1d6900c7d74c90a29824495684807d"
CLASSES = ["broken_strand", "welded_strand", "bent_strand", "long_scratch",
           "crushed", "spaced_strand", "deposit"]
GRID = [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5]
FN_CATEGORIES = {"matching_conflict", "localized_low_confidence", "wrong_class_candidate",
                 "localization_candidate", "no_overlap_candidate"}
FP_CATEGORIES = {"duplicates", "wrong_class", "localization", "background"}
ARTIFACTS = {"inputs.json", "protocol.json", "diagnosis_result.json", "diagnosis_summary.json",
             "gt_details.jsonl", "fp_details.jsonl", "threshold_analysis.json", "decision.json",
             "diagnosis_report.md", "events.jsonl"}
SOURCE_ARTIFACTS = {"protocol.json", "inputs.json", "events.jsonl", "predictions_640.jsonl",
                    "predictions_960.jsonl", "metrics_640.json", "metrics_960.json", "comparison.json",
                    "comparison_report.md", "comparison_result.json"}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def decode(text):
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError(f"Duplicate JSON key: {key}")
            value[key] = item
        return value
    def invalid(value):
        raise ValueError(f"Nonfinite JSON constant: {value}")
    value = json.loads(text, object_pairs_hook=unique, parse_constant=invalid)
    json.dumps(value, allow_nan=False)
    return value


def read(path):
    return decode(Path(path).read_text(encoding="utf-8-sig"))


def lines(path):
    return [decode(line) for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]


def equal(left, right):
    """Numerical tolerance is restricted to finite floating point arithmetic."""
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isfinite(left) and math.isfinite(right) and math.isclose(left, right, rel_tol=1e-10, abs_tol=1e-10)
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(equal(left[key], right[key]) for key in left)
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(equal(a, b) for a, b in zip(left, right))
    return type(left) is type(right) and left == right


def within(path, roots):
    path = Path(path).resolve()
    if not any(path.is_relative_to(Path(root).resolve()) for root in roots) or not path.is_file():
        raise ValueError(f"Evidence file missing or outside allowed scope: {path}")
    return path


def publication(directory, task_id, tool, required):
    directory = Path(directory).resolve()
    marker, manifest = read(directory / "completion.json"), read(directory / "artifact_manifest.json")
    if any(row.get("task_id") != task_id or row.get("tool") != tool or row.get("status") != "completed"
           for row in (marker, manifest)):
        return False
    if (Path(marker.get("artifact_manifest", "")).resolve() != directory / "artifact_manifest.json"
            or marker.get("artifact_manifest_sha256") != digest(directory / "artifact_manifest.json")):
        return False
    rows = manifest.get("files", [])
    names = {row.get("name") for row in rows}
    if len(rows) != len(names) or not required <= names:
        return False
    for row in rows:
        path = within(row["path"], [directory])
        if (path.parent != directory or path.name != row["name"] or row["size_bytes"] != path.stat().st_size
                or row["sha256"] != digest(path)):
            return False
    if marker.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
        return False
    marker_time = (directory / "completion.json").stat().st_mtime_ns
    return all(marker_time >= (directory / name).stat().st_mtime_ns for name in names | {"artifact_manifest.json"})


def independent_iou(a, b):
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    if union <= 0:
        raise ValueError("Invalid nonpositive box union")
    return intersection / union


def independent_matching(records, confidence, overlap=.5):
    """Per-image greedy same-class matching; ties use input prediction/GT index."""
    match, per_image = {}, []
    for record in sorted(records, key=lambda row: row["image_id"]):
        image = record["image_id"]
        truths = record["ground_truth"]
        used, matches = set(), {}
        active = [index for index, pred in enumerate(record["predictions"]) if pred["confidence"] >= confidence]
        active.sort(key=lambda index: (-record["predictions"][index]["confidence"], index))
        for index in active:
            pred = record["predictions"][index]
            selected, largest = None, -1.
            for gt_index, gt in enumerate(truths):
                value = independent_iou(gt["xyxy"], pred["xyxy"])
                if gt["class_id"] == pred["class_id"] and gt_index not in used and value >= overlap and value > largest:
                    selected, largest = gt_index, value
            if selected is not None:
                used.add(selected)
            matches[index] = selected
            match[image, index] = selected
        tp = len(used)
        per_image.append({"image_id": image, "tp": tp, "fp": len(active) - tp,
                          "fn": len(truths) - tp, "normal": not truths})
    tp, fp, fn = (sum(row[key] for row in per_image) for key in ("tp", "fp", "fn"))
    normal = [row for row in per_image if row["normal"]]
    nfp = sum(row["fp"] > 0 for row in normal)
    point = {"confidence_threshold": confidence, "iou_threshold": overlap,
             "tp": tp, "fp": fp, "fn": fn, "predictions": tp + fp,
             "precision": tp / (tp + fp) if tp + fp else 0.,
             "recall": tp / (tp + fn) if tp + fn else 0.,
             "normal_images": len(normal), "normal_fp_images": nfp,
             "normal_image_fp_rate": nfp / len(normal) if normal else None}
    return match, point


def _best(candidates):
    return max(candidates, key=lambda row: row["iou"], default=None)


def size_bucket(box):
    area = (box[2] - box[0]) * (box[3] - box[1])
    return "small" if area < 1024 else "medium" if area < 9216 else "large"


def region(box, width, height):
    col = min(2, max(0, int((box[0] + box[2]) / 2 / width * 3)))
    row = min(2, max(0, int((box[1] + box[3]) / 2 / height * 3)))
    return ("top", "middle", "bottom")[row] + "_" + ("left", "center", "right")[col]


def expected_details(records, confidence=.25, overlap=.5):
    matches, point = independent_matching(records, confidence, overlap)
    gt_rows, fp_rows = [], []
    for record in sorted(records, key=lambda row: row["image_id"]):
        image, truths, predictions = record["image_id"], record["ground_truth"], record["predictions"]
        inverted = {gt: pi for (img, pi), gt in matches.items() if img == image and gt is not None}
        for gi, gt in enumerate(truths):
            candidates = [{"prediction_index": pi, "class_id": p["class_id"], "confidence": p["confidence"],
                           "iou": independent_iou(gt["xyxy"], p["xyxy"]), "matched_gt_index": matches.get((image, pi))}
                          for pi, p in enumerate(predictions)]
            same = [row for row in candidates if row["class_id"] == gt["class_id"]]
            any_best, same_best = _best(candidates), _best(same)
            category, category_candidate = None, None
            if gi not in inverted:
                options = [
                    ("matching_conflict", [row for row in same if row["confidence"] >= confidence and row["iou"] >= overlap
                                           and row["matched_gt_index"] is not None and row["matched_gt_index"] != gi]),
                    ("localized_low_confidence", [row for row in same if row["confidence"] < confidence and row["iou"] >= overlap]),
                    ("wrong_class_candidate", [row for row in candidates if row["class_id"] != gt["class_id"] and row["iou"] >= overlap]),
                    ("localization_candidate", [row for row in candidates if row["iou"] > 0]),
                    ("no_overlap_candidate", [])]
                for category, options_for_category in options:
                    if options_for_category or category == "no_overlap_candidate":
                        category_candidate = _best(options_for_category)
                        break
            gt_rows.append({"image_id": image, "gt_index": gi, "class_id": gt["class_id"],
                            "class_name": CLASSES[gt["class_id"]], "xyxy": gt["xyxy"],
                            "area": (gt["xyxy"][2] - gt["xyxy"][0]) * (gt["xyxy"][3] - gt["xyxy"][1]),
                            "size_bucket": size_bucket(gt["xyxy"]), "region": region(gt["xyxy"], record["width"], record["height"]),
                            "status": "tp" if gi in inverted else "fn", "fn_category": category,
                            "matched_prediction_index": inverted.get(gi),
                            "best_any_class_iou": any_best["iou"] if any_best else 0.,
                            "best_same_class_iou": same_best["iou"] if same_best else 0.,
                            "best_any_candidate": any_best, "best_same_candidate": same_best, "category_candidate": category_candidate})
        for pi, pred in enumerate(predictions):
            if pred["confidence"] < confidence or matches[image, pi] is not None:
                continue
            candidates = [{"gt_index": gi, "class_id": gt["class_id"], "iou": independent_iou(pred["xyxy"], gt["xyxy"]),
                           "matched_prediction_index": inverted.get(gi)} for gi, gt in enumerate(truths)]
            same = [row for row in candidates if row["class_id"] == pred["class_id"]]
            any_best, same_best = _best(candidates), _best(same)
            options = [
                ("duplicates", [row for row in same if row["iou"] >= overlap and row["matched_prediction_index"] is not None]),
                ("wrong_class", [row for row in candidates if row["class_id"] != pred["class_id"] and row["iou"] >= overlap]),
                ("localization", [row for row in candidates if row["iou"] > 0]),
                ("background", [])]
            for category, options_for_category in options:
                if options_for_category or category == "background":
                    category_gt = _best(options_for_category)
                    break
            fp_rows.append({"image_id": image, "prediction_index": pi, "class_id": pred["class_id"],
                            "class_name": CLASSES[pred["class_id"]], "confidence": pred["confidence"], "xyxy": pred["xyxy"],
                            "area": (pred["xyxy"][2] - pred["xyxy"][0]) * (pred["xyxy"][3] - pred["xyxy"][1]),
                            "size_bucket": size_bucket(pred["xyxy"]), "region": region(pred["xyxy"], record["width"], record["height"]),
                            "fp_category": category, "best_any_class_iou": any_best["iou"] if any_best else 0.,
                            "best_same_class_iou": same_best["iou"] if same_best else 0.,
                            "best_any_gt": any_best, "best_same_gt": same_best, "category_gt": category_gt})
    return gt_rows, fp_rows, point


def detail_checks(records, gt_rows, fp_rows):
    expected_gt, expected_fp, point = expected_details(records)
    gt_by_id = {(row["image_id"], row["gt_index"]): row for row in gt_rows}
    fp_by_id = {(row["image_id"], row["prediction_index"]): row for row in fp_rows}
    def same_rows(expected, observed, identifier):
        return len(expected) == len(observed) and all(key in observed and all(equal(value, observed[key].get(name)) for name, value in row.items())
                                                   for row in expected for key in [identifier(row)])
    return {
        "gt_detail_ids_unique_and_complete": len(gt_by_id) == len(gt_rows) == len(expected_gt) and set(gt_by_id) == {(r["image_id"], r["gt_index"]) for r in expected_gt},
        "fp_detail_ids_unique_and_complete": len(fp_by_id) == len(fp_rows) == len(expected_fp) and set(fp_by_id) == {(r["image_id"], r["prediction_index"]) for r in expected_fp},
        "all_gt_candidates_and_matching_independently_recomputed": same_rows(expected_gt, gt_by_id, lambda r: (r["image_id"], r["gt_index"])),
        "all_fp_candidates_and_categories_independently_recomputed": same_rows(expected_fp, fp_by_id, lambda r: (r["image_id"], r["prediction_index"])),
        "best_any_iou_at_least_best_same_iou": all(r["best_any_class_iou"] + 1e-12 >= r["best_same_class_iou"] for r in gt_rows + fp_rows),
        "gt_categories_mutually_exclusive_and_sum_to_fn": sum(r.get("status") == "fn" for r in gt_rows) == point["fn"] and all(
            r.get("fn_category") in FN_CATEGORIES if r.get("status") == "fn" else r.get("status") == "tp" and r.get("fn_category") is None for r in gt_rows),
        "fp_categories_mutually_exclusive_and_sum_to_fp": len(fp_rows) == point["fp"] and all(r.get("fp_category") in FP_CATEGORIES for r in fp_rows),
        "detail_evidence_ids_unique": all(r.get("evidence_id") == f"{r['image_id']}:gt:{r['gt_index']}" for r in gt_rows)
                                     and all(r.get("evidence_id") == f"{r['image_id']}:prediction:{r['prediction_index']}" for r in fp_rows)
                                     and len({r["evidence_id"] for r in gt_rows + fp_rows}) == len(gt_rows) + len(fp_rows),
    }


def independent_threshold_curve(records, grid=GRID, baseline=.25, overlap=.5, max_normal_fp_images=5, normal_fp_budget=5/245):
    baseline_matches, point = independent_matching(records, baseline, overlap)
    baseline_tp = {(image, gi) for (image, _), gi in baseline_matches.items() if gi is not None}
    curve = []
    for confidence in grid:
        matches, row = independent_matching(records, confidence, overlap)
        current_tp = {(image, gi) for (image, _), gi in matches.items() if gi is not None}
        old_by_image, new_by_image = Counter(image for image, _ in baseline_tp), Counter(image for image, _ in current_tp)
        row.update(recovered_fn=len(current_tp - baseline_tp), lost_tp=len(baseline_tp - current_tp), tp_gain=row["tp"] - point["tp"],
                   gain_images_vs_baseline=sum(new_by_image[image] > old_by_image[image] for image in new_by_image),
                   within_normal_fp_budget=row["normal_fp_images"] <= max_normal_fp_images and row["normal_image_fp_rate"] is not None and row["normal_image_fp_rate"] <= normal_fp_budget)
        row["eligible_for_selection"] = row["within_normal_fp_budget"] and row["tp_gain"] >= 5 and row["gain_images_vs_baseline"] >= 5
        curve.append(row)
    return curve


def threshold_checks(records, actual_curve):
    expected = independent_threshold_curve(records)
    return {"threshold_grid_exact_no_posthoc_entries": [row.get("confidence_threshold") for row in actual_curve] == GRID,
            "threshold_curve_independently_recomputed": equal(actual_curve, expected),
            "threshold_confidence_floor_respected": min(GRID) >= .001,
            "baseline_threshold_row_matches_source_counts": any(row.get("confidence_threshold") == .25 and row.get("tp") == 231
                                                                and row.get("fp") == 149 and row.get("fn") == 365 for row in actual_curve)}


def selection_checks(curve, selection):
    eligible = [row for row in curve if row.get("within_normal_fp_budget") is True
                and row.get("tp_gain", -1) >= 5 and row.get("gain_images_vs_baseline", -1) >= 5]
    chosen = max(eligible, key=lambda row: (row["tp"], row["precision"], row["confidence_threshold"])) if eligible else None
    expected = {"status": "selected" if chosen else "stop",
                "reason": "fixed_grid_gain_and_normal_fp_budget_passed" if chosen else
                          "normal_image_denominator_missing" if curve and not curve[0]["normal_images"] else
                          "no_fixed_grid_threshold_passes_gain_and_normal_fp_budget",
                "baseline_threshold": .25, "selected_threshold": chosen["confidence_threshold"] if chosen else None,
                "selected_operating_point": chosen,
                "candidate_thresholds": [row["confidence_threshold"] for row in eligible], "threshold_applied": False}
    return {"threshold_selection_exact_fixed_budget_and_gain_gates": equal(selection, expected),
            "threshold_not_applied": selection.get("threshold_applied") is False}


def _subset(expected, observed):
    if not isinstance(observed, dict):
        return False
    return all(equal(value, observed.get(key)) for key, value in expected.items())


def decision_checks(records, gt_rows, threshold, decision):
    # Rebuild from source rather than trusting a forged detail category.
    gt_rows, _, _ = expected_details(records)
    for row in gt_rows:
        row["evidence_id"] = f"{row['image_id']}:gt:{row['gt_index']}"
    missed = [row for row in gt_rows if row["status"] == "fn"]
    low = [row for row in missed if row["fn_category"] == "localized_low_confidence"]
    spatial = [row for row in missed if row["fn_category"] in ("localization_candidate", "no_overlap_candidate")]
    overall = len(spatial) / len(gt_rows) if gt_rows else None
    support = []
    for bucket in ("small", "medium", "large"):
        truth = [row for row in gt_rows if row["size_bucket"] == bucket]
        candidates = [row for row in spatial if row["size_bucket"] == bucket]
        rate = len(candidates) / len(truth) if truth else None
        supported = bucket != "large" and len(truth) >= 20 and len(candidates) >= 10 and overall is not None and rate > overall
        support.append({"size_bucket": bucket, "gt": len(truth), "candidate_fn": len(candidates), "candidate_fn_rate": rate,
                        "overall_candidate_fn": len(spatial), "overall_gt": len(gt_rows), "overall_candidate_fn_rate": overall,
                        "affected_images": len({row["image_id"] for row in candidates}), "supported": supported,
                        "reason": "candidate_fn_enrichment_with_minimum_support" if supported else
                                  "reference_large_bin" if bucket == "large" else
                                  "insufficient_gt_support" if len(truth) < 20 else
                                  "insufficient_candidate_fn_support" if len(candidates) < 10 else "no_candidate_fn_enrichment"})
    eligible = [row for row in independent_threshold_curve(records) if row["within_normal_fp_budget"] and row["tp_gain"] >= 5 and row["gain_images_vs_baseline"] >= 5]
    chosen = max(eligible, key=lambda row: (row["tp"], row["precision"], row["confidence_threshold"])) if eligible else None
    recommendations = decision.get("recommendations", {})
    expected_threshold = {"status": "candidate_supported" if chosen else "stop", "evidence_count": len(low),
                          "affected_images": len({row["image_id"] for row in low}), "evidence_ids": [row["evidence_id"] for row in low],
                          "selected_threshold": chosen["confidence_threshold"] if chosen else None,
                          "selected_tp_gain": chosen["tp_gain"] if chosen else None,
                          "selected_gain_images": chosen["gain_images_vs_baseline"] if chosen else None}
    expected_slicing = {"status": "candidate_supported" if any(row["supported"] for row in support) else "insufficient_evidence",
                        "evidence_count": len(spatial), "affected_images": len({row["image_id"] for row in spatial}),
                        "evidence_ids": [row["evidence_id"] for row in spatial], "size_support": support}
    expected_branch = "threshold_analysis" if chosen else "sliced_inference_controlled" if any(row["supported"] for row in support) else "stop_pending_evidence"
    return {"decision_selection_matches_threshold_file": equal(decision.get("selection"), threshold.get("selection")),
            "threshold_recommendation_evidence_and_image_support_recomputed": _subset(expected_threshold, recommendations.get("threshold_analysis")),
            "slicing_minimum_evidence_and_enrichment_recomputed": _subset(expected_slicing, recommendations.get("slicing")),
            "next_branch_follows_pre_frozen_evidence_priority": recommendations.get("next_branch") == expected_branch,
            "decision_does_not_spend_new_inference_or_apply_threshold": decision.get("new_inference_budget") == 0 and decision.get("automatically_applied") is False,
            "recommendation_limitations_present": all(isinstance(value, list) and len(value) >= 3 and all(isinstance(v, str) and v for v in value)
                                                     for value in (recommendations.get("limitations"), recommendations.get("threshold_analysis", {}).get("limitations"), recommendations.get("slicing", {}).get("limitations")))}


def grouped_details(gt_rows, fp_rows, key, values):
    output = []
    for value in values:
        truth = [row for row in gt_rows if row[key] == value]
        false = [row for row in fp_rows if row[key] == value]
        missed = [row for row in truth if row["status"] == "fn"]
        tp, fp, fn = len(truth) - len(missed), len(false), len(missed)
        entry = {key: value, "gt": len(truth), "tp": tp, "fp": fp, "fn": fn,
                 "images_with_gt": len({row["image_id"] for row in truth}),
                 "images_with_fn": len({row["image_id"] for row in missed}),
                 "images_with_fp": len({row["image_id"] for row in false}),
                 "precision": tp / (tp + fp) if tp + fp else None, "recall": tp / len(truth) if truth else None,
                 "fn_categories": {name: sum(row["fn_category"] == name for row in missed) for name in FN_CATEGORIES},
                 "fp_categories": {name: sum(row["fp_category"] == name for row in false) for name in FP_CATEGORIES}}
        if key == "class_id":
            entry["class_name"] = CLASSES[value]
        output.append(entry)
    return output


def expected_summary(records, gt_rows, fp_rows):
    _, point = independent_matching(records, .25, .5)
    return {"images": len(records), "gt": len(gt_rows), "stored_predictions": sum(len(row["predictions"]) for row in records), "operating_point": point,
            "fn_categories": {name: sum(row["fn_category"] == name for row in gt_rows) for name in FN_CATEGORIES},
            "fp_categories": {name: sum(row["fp_category"] == name for row in fp_rows) for name in FP_CATEGORIES}}


def summary_checks(summary, result, gt_rows, fp_rows, point, records=None):
    reference = summary.get("reference", {})
    expected = {"images": 640, "gt": len(gt_rows),
                "operating_point": point,
                "fn_categories": {name: sum(row["fn_category"] == name for row in gt_rows) for name in FN_CATEGORIES},
                "fp_categories": {name: sum(row["fp_category"] == name for row in fp_rows) for name in FP_CATEGORIES}}
    if records is not None:
        expected["stored_predictions"] = sum(len(row["predictions"]) for row in records)
    checks = {"reference_summary_counts_recomputed": _subset(expected, reference),
              "result_reference_summary_matches_detail_summary": equal(result.get("summary", {}).get("reference"), reference),
              "result_descriptive_summary_matches_detail_summary": equal(result.get("summary", {}).get("descriptive_960"), summary.get("descriptive_960")),
              "all_class_group_metrics_recomputed": equal(summary.get("per_class"), grouped_details(gt_rows, fp_rows, "class_id", range(7))),
              "all_size_group_metrics_recomputed": equal(summary.get("per_size"), grouped_details(gt_rows, fp_rows, "size_bucket", ("small", "medium", "large"))),
              "all_region_group_metrics_recomputed": equal(summary.get("per_region"), grouped_details(gt_rows, fp_rows, "region", [f"{v}_{h}" for v in ("top", "middle", "bottom") for h in ("left", "center", "right")])),
              "result_no_inference_training_test_and_input_flags_truthful": all(result.get("summary", {}).get(key) is False for key in ("new_inference_performed", "training_performed", "test_inference_performed"))
                                                                         and result.get("summary", {}).get("input_hashes_unchanged") is True,
              "completed_result_has_no_errors": result.get("errors") == []}
    return checks


def png_dimensions(path):
    with Path(path).open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError("Invalid source PNG header")
    return struct.unpack(">II", header[16:24])


def decode_labels(path, width, height):
    values = []
    for row in Path(path).read_text(encoding="utf-8-sig").splitlines():
        if not row.strip():
            continue
        parts = row.split()
        if len(parts) != 5 or not re.fullmatch(r"[0-6]", parts[0]):
            raise ValueError("Invalid source label row")
        x, y, w, h = map(float, parts[1:])
        if not all(math.isfinite(value) and 0 <= value <= 1 for value in (x, y, w, h)) or min(w, h) <= 0:
            raise ValueError("Invalid source label coordinate")
        values.append({"class_id": int(parts[0]), "xyxy": [(x - w/2)*width, (y - h/2)*height,
                                                           (x + w/2)*width, (y + h/2)*height], "source_label": row})
    return values


def valid_predictions(records, eval_imgsz=640):
    if len({row["image_id"] for row in records}) != len(records):
        return False
    for record in records:
        if record.get("split") != "val" or record.get("eval_imgsz") != eval_imgsz:
            return False
        if record.get("precision") != "FP32" or record.get("device") != "0":
            return False
        for pred in record["predictions"]:
            box, confidence, class_id = pred.get("xyxy"), pred.get("confidence"), pred.get("class_id")
            if (type(class_id) is not int or class_id not in range(7) or not isinstance(box, list) or len(box) != 4
                    or any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in box)
                    or box[2] <= box[0] or box[3] <= box[1] or isinstance(confidence, bool)
                    or not isinstance(confidence, (float, int)) or not math.isfinite(confidence) or not .001 <= confidence <= 1):
                return False
    return True


def verify_run(directory, configuration=None):
    """Inspect a published diagnosis; report failed checks without rewriting evidence."""
    if configuration is None:
        from defect_researcher.config import load_config
        configuration = load_config()
    directory = Path(directory).resolve()
    paths = {key: Path(value).resolve() for key, value in configuration.items()}
    if not directory.is_relative_to(paths["output_root"]):
        raise ValueError("Diagnosis directory escapes configured output root")
    result, protocol, inputs, summary, threshold, decision = (read(directory / name) for name in
        ("diagnosis_result.json", "protocol.json", "inputs.json", "diagnosis_summary.json", "threshold_analysis.json", "decision.json"))
    task_id = directory.name
    frozen = read(ROOT / "fixtures" / "diagnosis_protocol.json")
    source_dir = paths["output_root"] / SOURCE_TASK
    source_result = read(source_dir / "comparison_result.json")
    source_protocol = read(source_dir / "protocol.json")
    source_inputs = read(source_dir / "inputs.json")
    checks = {
        "diagnosis_publication_chain_valid": publication(directory, task_id, TOOL, ARTIFACTS),
        "diagnosis_result_completed_same_task": result.get("task_id") == task_id and result.get("tool") == TOOL and result.get("status") == "completed",
        "frozen_protocol_values_and_types": all(protocol.get(key) == value and type(protocol.get(key)) is type(value) for key, value in frozen.items()),
        "frozen_protocol_references_known_validation_task": protocol.get("source_task_id") == SOURCE_TASK,
        "no_new_inference_training_test_or_threshold_application": protocol.get("new_inference_budget") == 0 and protocol.get("training_performed") is False
                                                                 and protocol.get("test_inference_performed") is False and protocol.get("automatically_apply_threshold") is False,
        "source_comparison_publication_chain_valid": publication(source_dir, SOURCE_TASK, SOURCE_TOOL, SOURCE_ARTIFACTS),
        "source_comparison_completed_same_task": source_result.get("task_id") == SOURCE_TASK and source_result.get("tool") == SOURCE_TOOL and source_result.get("status") == "completed",
        "source_completion_hash_bound_in_protocol_and_inputs": protocol.get("source_completion_sha256") == inputs.get("source_completion_sha256") == digest(source_dir / "completion.json"),
        "source_manifest_hash_bound_in_protocol": protocol.get("source_manifest_sha256") == digest(source_dir / "artifact_manifest.json"),
    }
    records = lines(source_dir / "predictions_640.jsonl")
    checks["source_prediction_bytes_frozen_in_protocol"] = protocol.get("predictions_640_sha256") == digest(source_dir / "predictions_640.jsonl")
    checks["saved_predictions_original_control_and_valid_values"] = valid_predictions(records)
    raw_members = [Path(line.strip()).resolve() for line in (paths["split_dir"] / "val.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    member_ids = sorted(path.stem for path in raw_members)
    checks["validation_membership_exactly_640_unique_frozen_ids"] = (
        len(raw_members) == len(set(raw_members)) == len(set(member_ids)) == 640
        and member_ids == source_protocol.get("image_ids") == source_inputs.get("validation_image_ids")
        and member_ids == sorted(row["image_id"] for row in records))
    other_members = set()
    for split in ("train", "test", "excluded_buffer"):
        other_members.update(Path(line.strip()).resolve() for line in (paths["split_dir"] / f"{split}.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip())
    checks["validation_disjoint_from_training_test_buffer"] = not set(raw_members) & other_members
    by_image = {row["image_id"]: row for row in records}
    allowed = [paths[key] for key in ("dataset_root", "raw_root", "split_dir", "research_root")] + [ROOT]
    exact_gt, dimension_ok, identity_ok, pixel_ok = True, True, True, True
    expected_source_files = set()
    for raw in raw_members:
        raw = within(raw, [paths["raw_root"]])
        image = within(paths["dataset_root"] / "images" / "val" / raw.name, [paths["dataset_root"]])
        label = within(paths["dataset_root"] / "labels" / "val" / f"{raw.stem}.txt", [paths["dataset_root"]])
        metadata = within(paths["dataset_root"] / "metadata" / "val" / f"{raw.stem}.json", [paths["dataset_root"]])
        expected_source_files.update((raw, image, label, metadata))
        width, height = png_dimensions(image)
        meta, record = read(metadata), by_image[raw.stem]
        dimension_ok &= png_dimensions(raw) == (width, height) == (record["width"], record["height"]) == (meta["width"], meta["height"])
        identity_ok &= meta["image"] == raw.relative_to(paths["raw_root"]).as_posix()
        identity_ok &= all(Path(record[key]).resolve() == target for key, target in (("image_path", image), ("source_path", raw), ("label_path", label), ("metadata_path", metadata)))
        pixel_ok &= digest(raw) == digest(image)
        exact_gt &= equal(decode_labels(label, width, height), record["ground_truth"])
    checks.update(validation_gt_exact_source_label_decode=exact_gt, validation_png_dimensions_match_metadata_and_predictions=dimension_ok,
                  validation_source_identity_and_paths_correct=identity_ok, validation_raw_and_dataset_pixel_bytes_same=pixel_ok)
    old_rows, new_rows = source_inputs["files"], inputs["files"]
    old_roles = {row["role"]: row for row in old_rows}
    new_paths = {Path(row["path"]).resolve(): row for row in new_rows}
    old_hash_ok, new_hash_ok = True, True
    for row in old_rows:
        path = within(row["path"], allowed)
        old_hash_ok &= digest(path) == row.get("sha256_before") == row.get("sha256_after") and row.get("unchanged") is True and row.get("size_bytes") == path.stat().st_size
    for row in new_rows:
        path = within(row["path"], allowed)
        new_hash_ok &= digest(path) == row.get("sha256_before") == row.get("sha256_after") and row.get("unchanged") is True and row.get("size_bytes") == path.stat().st_size
    checks.update(source_10256_input_records_unique_and_complete=len(old_roles) == len(old_rows) == 10256,
                  source_frozen_input_bytes_still_unchanged=old_hash_ok and source_inputs.get("all_unchanged") is True,
                  diagnosis_input_roles_and_paths_unique=len({row["role"] for row in new_rows}) == len(new_rows) and len(new_paths) == len(new_rows),
                  diagnosis_all_input_hashes_unchanged=new_hash_ok and inputs.get("all_unchanged") is True,
                  diagnosis_source_files_snapshot_coverage=expected_source_files <= new_paths.keys(),
                  diagnosis_old_task_sealed_artifacts_snapshot_coverage={source_dir / name for name in SOURCE_ARTIFACTS | {"completion.json", "artifact_manifest.json"}} <= new_paths.keys())
    gt_rows, fp_rows = lines(directory / "gt_details.jsonl"), lines(directory / "fp_details.jsonl")
    checks.update(detail_checks(records, gt_rows, fp_rows))
    _, point = independent_matching(records, .25, .5)
    checks["baseline_independently_recomputed_tp231_fp149_fn365"] = all(point[key] == target for key, target in (("tp", 231), ("fp", 149), ("fn", 365), ("normal_images", 245), ("normal_fp_images", 5)))
    checks.update(threshold_checks(records, threshold["curve"]))
    numeric_protocol = {key: frozen[key] for key in ("confidence_threshold", "iou_threshold", "threshold_grid", "prediction_floor", "normal_fp_budget", "max_normal_fp_images", "min_tp_gain", "min_gain_images", "min_scale_gt", "min_scale_fn")}
    checks["threshold_file_protocol_matches_frozen_parameters_and_declared_order"] = (
        _subset(numeric_protocol, threshold.get("protocol"))
        and threshold["protocol"].get("fn_category_priority") == ["matching_conflict", "localized_low_confidence", "wrong_class_candidate", "localization_candidate", "no_overlap_candidate"]
        and threshold["protocol"].get("fp_category_priority") == ["duplicates", "wrong_class", "localization", "background"]
        and threshold["protocol"].get("threshold_applied") is False and threshold["protocol"].get("new_inference") is False
        and threshold["protocol"].get("training_performed") is False)
    # Selection and decision fields are checked below separately from raw counts.
    checks.update(selection_checks(threshold["curve"], threshold["selection"]))
    checks.update(decision_checks(records, gt_rows, threshold, decision))
    checks.update(summary_checks(summary, result, gt_rows, fp_rows, point, records))
    records960 = lines(source_dir / "predictions_960.jsonl")
    gt960, fp960, point960 = expected_details(records960)
    checks["descriptive_960_summary_independently_recomputed"] = equal(summary.get("descriptive_960"), expected_summary(records960, gt960, fp960))
    checks["descriptive_960_source_membership_and_gt_same_as_reference"] = valid_predictions(records960, 960) and equal(
        sorted([{key: row[key] for key in ("image_id", "width", "height", "ground_truth")} for row in records960], key=lambda r: r["image_id"]),
        sorted([{key: row[key] for key in ("image_id", "width", "height", "ground_truth")} for row in records], key=lambda r: r["image_id"]))
    evidence = result.get("evidence", {})
    wanted_evidence = {"source_task_id": SOURCE_TASK, "source_completion_sha256": digest(source_dir / "completion.json"),
                       "source_manifest_sha256": digest(source_dir / "artifact_manifest.json"),
                       "predictions_640_sha256": digest(source_dir / "predictions_640.jsonl"),
                       "predictions_960_sha256": digest(source_dir / "predictions_960.jsonl"),
                       "protocol_sha256": digest(ROOT / "fixtures" / "diagnosis_protocol.json"),
                       "evidence_id": f"diagnosis:{task_id}:640"}
    checks["result_completion_manifest_input_evidence_hashes_all_bound"] = (
        equal(evidence, wanted_evidence) and all(_subset(wanted_evidence, read(directory / name)) for name in ("protocol.json", "inputs.json", "completion.json"))
        and equal(read(directory / "artifact_manifest.json").get("input_evidence"), wanted_evidence))
    checks["decision_references_exact_task_prediction_and_claim_scope"] = (
        decision.get("source_task_id") == SOURCE_TASK and decision.get("predictions_sha256") == wanted_evidence["predictions_640_sha256"]
        and decision.get("evidence_id") == wanted_evidence["evidence_id"] and decision.get("claim_scope") == frozen["claim_scope"])
    checks["new_snapshot_covers_all_old_source_paths_and_frozen_new_code"] = (
        {Path(row["path"]).resolve() for row in old_rows} <= new_paths.keys()
        and {ROOT / "fixtures" / "diagnosis_protocol.json", ROOT / "defect_researcher" / "diagnosis_task.py", ROOT / "defect_researcher" / "detection_diagnosis.py"} <= new_paths.keys())
    checks["result_counts_selection_and_decision_match_published_files"] = (
        result.get("summary", {}).get("input_files") == len(new_rows)
        and equal(result.get("summary", {}).get("threshold_selection"), threshold.get("selection"))
        and equal(result.get("summary", {}).get("recommendations"), decision.get("recommendations")))
    events = lines(directory / "events.jsonl")
    expected_events = [("configuration", "passed"), ("source_evidence_validation", "passed"), ("diagnosis", "passed"),
                       ("input_recheck", "passed"), ("artifact_publication", "ready")]
    checks["publication_event_order_has_input_recheck_before_completion_ready"] = (
        [(row.get("stage"), row.get("status")) for row in events] == expected_events
        and events[-1].get("completion_published_last") is True)
    source_manifest = read(source_dir / "artifact_manifest.json")
    gate = source_dir / "geometry_gate" / "gate"
    gate_files = {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"}
    checks["source_geometry_gate_nested_chain_and_completion_hash_valid"] = (
        publication(gate, "gate", "verify_label_geometry", gate_files)
        and read(source_dir / "completion.json").get("geometry_completion_sha256") == digest(gate / "completion.json")
        and set(source_manifest.get("geometry_gate", {})) == {"completion", "manifest"}
        and all(Path(row["path"]).resolve() == gate / ("completion.json" if key == "completion" else "artifact_manifest.json")
                and row["sha256"] == digest(Path(row["path"])) and row["size_bytes"] == Path(row["path"]).stat().st_size
                for key, row in source_manifest["geometry_gate"].items()))
    passed = sum(checks.values())
    return {"schema_version": "independent-diagnosis-review-v1", "task_id": task_id,
            "source_task_id": SOURCE_TASK, "status": "passed" if passed == len(checks) else "failed",
            "verified_at": datetime.now(timezone.utc).isoformat(), "checks": checks,
            "passed_checks": passed, "total_checks": len(checks), "failed_checks": [key for key, value in checks.items() if not value],
            "independent_implementation": "handwritten IoU, greedy matching, FN/FP categorization and threshold arithmetic; no diagnosis or metric scorer imported",
            "limitations": ["This checks source and artifact consistency. Candidate explanations remain descriptive and do not establish causality or test-set gains.",
                            "Completion mtime ordering is supporting evidence; an explicit protocol event order is also checked when available."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--config")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from defect_researcher.config import load_config
    configuration = load_config(args.config)
    try:
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", args.task_id):
            raise ValueError("Unsafe task ID")
        report = verify_run(Path(configuration["output_root"]) / args.task_id, configuration)
    except Exception as error:
        report = {"status": "failed", "task_id": args.task_id, "error": {"type": type(error).__name__, "message": str(error)}}
    output = args.output.resolve()
    allowed_output = Path(configuration["output_root"]).resolve()
    task_directory = allowed_output / args.task_id
    if not output.is_relative_to(allowed_output) or output.is_relative_to(task_directory):
        raise ValueError("Review output must be under output_root and outside the sealed diagnosis directory")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "passed_checks", "total_checks", "failed_checks", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
