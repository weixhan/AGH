// Public AGH hooks: one session, original clock, fixed action order, no polling.
import {createHash} from 'node:crypto';
import {readFile,lstat} from 'node:fs/promises';
import {resolve,dirname,join,isAbsolute} from 'node:path';

export const SERVER_ID='dr-science-v1';
export const TOOLS_PREFIX='mcp_'+SERVER_ID.replaceAll('-','_')+'_'+createHash('sha256').update(SERVER_ID).digest('hex').slice(0,8)+'_';
export const ACTION_TOOL=TOOLS_PREFIX+'research_action_v1';
export const READ_TOOL=TOOLS_PREFIX+'research_read_v1';
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const keys=(value,list)=>object(value)&&Object.keys(value).sort().join(',')===[...list].sort().join(',');
export const normalizePath=value=>typeof value==='string'?value.replaceAll('\\','/').replace(/\/+$/,'').toLowerCase():'';
const stable=value=>JSON.stringify(value,(_k,v)=>object(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
async function regular(path){
 path=resolve(path);for(let current=path;;current=dirname(current)){
  const stat=await lstat(current);if(stat.isSymbolicLink())throw new Error('Linked scientific evidence path refused');
  if(current===path&&!stat.isFile())throw new Error('Regular scientific evidence required');
  if(current===dirname(current))return path;
 }
}
async function recorded(path){path=await regular(path);const bytes=await readFile(path);return{path,sha256:digest(bytes),size_bytes:bytes.length};}
async function pinnedFile(pin){
 if(!keys(pin,['path','sha256'])||!isAbsolute(pin.path)||!/^[a-f0-9]{64}$/.test(pin.sha256))throw new Error('Exact scientific deployment pin required');
 const path=await regular(pin.path),bytes=await readFile(path);if(digest(bytes)!==pin.sha256)throw new Error('Scientific deployment/source pin changed');
 return JSON.parse(bytes.toString('utf8'));
}
async function checkedArtifact(row,path){
 if(!keys(row,['path','sha256','size_bytes'])||normalizePath(row.path)!==normalizePath(resolve(path))||stable(await recorded(path))!==stable(row))
  throw new Error('Scientific preflight artifact bytes/path changed');
 return JSON.parse(await readFile(path,'utf8'));
}

// Host notification text is never evidence. Only these fixed pinned files can
// advance the existing session after its admitted asynchronous audit action.
export async function readOwnedPreflightCompletion(policy,owned){
 if(!keys(owned,['deployment','source_lock','domain_task_directory'])||!isAbsolute(owned.domain_task_directory))
  throw new Error('Fixed owned preflight observer configuration required');
 const registry=join(dirname(owned.deployment.path),'mcp-owned'),resultPath=join(registry,'preflight-result.json');
 try{await lstat(resultPath);}catch(error){if(error.code==='ENOENT')return null;throw error;}
 const deployment=await pinnedFile(owned.deployment),lock=await pinnedFile(owned.source_lock);
 if(deployment.kind!=='resolution_research_mcp_deployment_v1'||deployment.schema_version!==1||
  deployment.request_id!==policy.request_id||deployment.task_id!==policy.task_id||
  normalizePath(deployment.workspace_root)!==normalizePath(policy.workspace_root)||
  Math.round(deployment.started_epoch*1000)!==policy.started_epoch_ms||Math.round(deployment.deadline_epoch*1000)!==policy.deadline_epoch_ms||
  deployment.deadline_epoch!==deployment.started_epoch+2400||deployment.deadline_monotonic!==deployment.started_monotonic+2400)
  throw new Error('Scientific preflight original outer anchors differ');
 if(lock.kind!=='resolution_research_mcp_source_lock_v1'||lock.status!=='passed_engineering_only'||lock.fixture_only!==false||
  !Array.isArray(lock.files)||!lock.files.length)throw new Error('Production source lock required for preflight observation');
 const seen=new Set();for(const row of lock.files){
  if(!keys(row,['path','sha256','size_bytes'])||!isAbsolute(row.path)||seen.has(normalizePath(row.path))||stable(await recorded(row.path))!==stable(row))
   throw new Error('Scientific execution source bytes/membership changed');
  seen.add(normalizePath(row.path));
 }
 const owner=JSON.parse(await readFile(await regular(join(registry,'owner.json')),'utf8'));
 if(stable(owner)!==stable({owner:'defect_researcher.resolution_research_mcp_v1',request_id:policy.request_id,task_id:policy.task_id,
  protocol_sha256:owned.deployment.sha256,source_lock_sha256:owned.source_lock.sha256,fixture_only:false}))throw new Error('Preflight registry owner differs');
 const wrapper=JSON.parse(await readFile(await regular(resultPath),'utf8'));
 const expected=['phase','task_id','result','fixture_only','request_id','deployment','source_lock','outer_started_epoch','outer_deadline_epoch',
  'outer_started_monotonic','outer_deadline_monotonic','deadline_reset'];
 if(wrapper.result?.status==='preflight_passed')expected.push('preflight_receipt','domain_registration');
 if(!keys(wrapper,expected)||wrapper.phase!=='preflight'||wrapper.request_id!==policy.request_id||wrapper.task_id!==policy.task_id||
  wrapper.fixture_only!==false||wrapper.deadline_reset!==false||stable(wrapper.deployment)!==stable(owned.deployment)||stable(wrapper.source_lock)!==stable(owned.source_lock)||
  ['started_epoch','deadline_epoch','started_monotonic','deadline_monotonic'].some(key=>wrapper['outer_'+key]!==deployment[key])||
  !object(wrapper.result)||wrapper.result.task_id!==policy.task_id||!['preflight_passed','failed'].includes(wrapper.result.status))
  throw new Error('Preflight result deployment/identity/clock differs');
 if(wrapper.result.status==='preflight_passed'){
  const receipt=await checkedArtifact(wrapper.preflight_receipt,join(owned.domain_task_directory,'staged_preflight_receipt.json')),
   registration=await checkedArtifact(wrapper.domain_registration,join(owned.domain_task_directory,'registration.json'));
  if(stable(receipt)!==stable(wrapper.result)||receipt.fixture_only!==false||receipt.deadline_reset!==false||receipt.new_prediction_calls!==0||
   registration.task_id!==policy.task_id||registration.fixture_only!==false||normalizePath(registration.task_directory)!==normalizePath(owned.domain_task_directory)||
   registration.deadline_epoch!==registration.started_epoch+1800||registration.deadline_monotonic!==registration.started_monotonic+1800||
   !(registration.started_epoch>=deployment.started_epoch&&registration.started_epoch<deployment.deadline_epoch)||
   !(registration.started_monotonic>=deployment.started_monotonic&&registration.started_monotonic<deployment.deadline_monotonic)||
   receipt.original_deadline_epoch!==registration.deadline_epoch||receipt.original_deadline_monotonic!==registration.deadline_monotonic)
   throw new Error('Scientific preflight domain clock or receipt differs');
 }
 return{status:wrapper.result.status==='preflight_passed'?'preflight_passed':'preflight_failed',
  result_artifact:await recorded(resultPath),evidence:wrapper.result,deadline_reset:false};
}

export function createResolutionResearchScopeGuard(policy, now=Date.now, owned=null){
 const expected=['schema_version','workspace_root','request_id','task_id','started_epoch_ms','deadline_epoch_ms',
  'qualified_action_tool','qualified_read_tool','max_model_requests','max_primary_requests','max_native_title_requests'];
 if(!keys(policy,expected)||policy.schema_version!==1||!normalizePath(policy.workspace_root)||typeof policy.request_id!=='string'||
  !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(policy.request_id)||policy.task_id!=='resolution-research-v1-'+policy.request_id||
  policy.qualified_action_tool!==ACTION_TOOL||policy.qualified_read_tool!==READ_TOOL||
  !Number.isFinite(policy.started_epoch_ms)||policy.started_epoch_ms<0||
  policy.deadline_epoch_ms!==policy.started_epoch_ms+2400000||policy.max_model_requests!==14||
  policy.max_primary_requests!==13||policy.max_native_title_requests!==1||TOOLS_PREFIX.length>32||ACTION_TOOL.length>64||READ_TOOL.length>64)
  throw new Error('Invalid fixed scientific scope policy');
 const pinned=structuredClone(policy), state={session:null,requests:0,last:pinned.started_epoch_ms,phase:'new',
  accepted:new Map(),results:new Set(),usedActions:new Set(),statusCalls:0,runningReads:0,faultReads:0,completedReads:0,reviewCount:0,decision:null,preflight:null};
 const ownership=owned===null?null:structuredClone(owned);
 const deny=reason=>({allow:false,reason:'RESOLUTION_RESEARCH_SCOPE_DENIED: '+reason});
 function contextValid(context){return object(context?.session)&&typeof context.session.key==='string'&&context.session.key&&
  normalizePath(context.session.workspaceRoot)===normalizePath(pinned.workspace_root)&&context.replayed!==true;}
 function current(context,bind=false){
  if(!contextValid(context))return false;
  if(state.session===null&&bind)state.session=context.session.key;
  if(state.session!==context.session.key)return false;
  const clock=now();if(!Number.isFinite(clock)||clock<state.last||clock<pinned.started_epoch_ms||clock>=pinned.deadline_epoch_ms)return false;
  state.last=clock;return true;
 }
 const required={audit_geometry:['new'],register_hypothesis:['gated'],start_registered_experiment:['registered'],
  resume_registered_failure:['fault_observed'],stop_insufficient_evidence:['gate_failed','gated','registered','fault_observed','failed'],
  decide_stop_resolution:['reviewed'],decide_retain_resolution:['reviewed'],decide_insufficient_evidence:['reviewed'],publish_report:['decided','stopped']};
 return {
  async observe_preflight_completion(context){
   if(state.phase!=='preflight_pending'||!current(context))return{observed:false};
   if(ownership===null)throw new Error('Fixed owned preflight observer is required');
   const value=await readOwnedPreflightCompletion(pinned,ownership);
   if(value===null)return{observed:false};
   if(!current(context))throw new Error('Original scientific scope expired during preflight observation');
   state.phase=value.status==='preflight_passed'?'gated':'gate_failed';state.preflight=value;
   return{observed:true,...value};
  },
  before_request(payload,context){
   if(!object(payload)||payload.slot!=='primary'||payload.model!=='agnes-3.0-flash'||!current(context,true))return deny('wrong session/route/slot or original clock expired');
   if(state.requests>=13)return deny('thirteen primary requests exhausted; native title budget is independent');
   state.requests++;return{allow:true,request_index:state.requests,session_key:state.session,
    started_epoch_ms:pinned.started_epoch_ms,deadline_epoch_ms:pinned.deadline_epoch_ms};
  },
  before_step(_payload,context){return current(context)?{}:{block:true,reason:'RESOLUTION_RESEARCH_SCOPE_DENIED: original session/deadline'};},
  tool_call(payload,context){
   if(!current(context)||state.requests===0||!object(payload)||typeof payload.toolUseId!=='string'||!payload.toolUseId||
    state.accepted.has(payload.toolUseId)||!keys(payload.args,['request_id','action'])||payload.args.request_id!==pinned.request_id||typeof payload.args.action!=='string')
    return deny('unowned, duplicate or broadened tool arguments');
   const action=payload.args.action;
   if([...state.accepted.keys()].some(id=>!state.results.has(id)))return deny('one observed tool result must precede the next action');
   if(payload.name===ACTION_TOOL){
    if(!required[action]?.includes(state.phase)||state.usedActions.has(action))return deny('action outside observed evidence stage or already consumed');
    if(action.startsWith('decide_')&&action!==state.decision)return deny('decision unsupported by actual frozen criteria');
    state.usedActions.add(action);
   }else if(payload.name===READ_TOOL){
    if(action==='status'){
     if(!['initial_running','resume_running'].includes(state.phase)||state.statusCalls>=3)
      return deny('status only while one owned phase is pending; no polling');
     state.statusCalls++;
    }else if(action==='independent_review'){
     if(state.phase!=='completed_observed'||state.reviewCount>=1)return deny('independent review requires observed completed result, once');
     state.reviewCount++;
    }else return deny('unknown read action');
   }else return deny('tool outside the two scientific tools');
   state.accepted.set(payload.toolUseId,{action,name:payload.name});return{allow:true};
  },
  tool_result(payload,context){
   if(!current(context)||!object(payload)||state.results.has(payload.toolUseId)||!state.accepted.has(payload.toolUseId))return{};
   state.results.add(payload.toolUseId);
   let value;try{const blocks=payload.result?.content?.filter(x=>x.type==='text');if(blocks?.length!==1)return{};value=JSON.parse(blocks[0].text);}catch{return{};}
   if(!object(value)||value.request_id!==pinned.request_id||value.task_id!==pinned.task_id||value.fixture_only!==false)return{};
   const {action}=state.accepted.get(payload.toolUseId);
   if(payload.result?.isError===true)return{};
   if(action==='audit_geometry')state.phase=value.status==='running'&&value.phase==='preflight'?'preflight_pending':value.status==='preflight_failed'?'gate_failed':state.phase;
   else if(action==='register_hypothesis'&&value.status==='hypothesis_registered')state.phase='registered';
   else if(action==='start_registered_experiment'&&value.status==='running')state.phase='initial_running';
   else if(action==='resume_registered_failure'&&value.status==='running')state.phase='resume_running';
   else if(['start_registered_experiment','resume_registered_failure'].includes(action)&&value.status==='experiment_failed')state.phase='failed';
   else if(action==='stop_insufficient_evidence'&&value.status==='stopped')state.phase='stopped';
   else if(action==='status'){
    if(value.status==='running'){if(state.runningReads>=1)state.phase='failed';else state.runningReads++;}
    else if(value.status==='recovery_pending'&&state.phase==='initial_running'&&object(value.actual_failure)){
     if(state.faultReads>=1)state.phase='failed';else{state.faultReads++;state.phase='fault_observed';}
    }else if(value.status==='experiment_completed'&&state.phase==='resume_running'){
     if(state.completedReads>=1)state.phase='failed';else{state.completedReads++;state.phase='completed_observed';}
    }else if(value.status==='experiment_failed'){state.completedReads++;state.phase='failed';}
   }else if(action==='independent_review'){
    if(value.status==='reviewed'&&value.verification?.status==='passed'&&value.verification?.real_recovery_accepted===true&&
     ['decide_stop_resolution','decide_retain_resolution','decide_insufficient_evidence'].includes(value.only_supported_decision_action)){
     state.phase='reviewed';state.decision=value.only_supported_decision_action;
    }else if(value.status==='independent_review_failed')state.phase='failed';
   }else if(action.startsWith('decide_')&&value.status==='decided')state.phase='decided';
   else if(action==='publish_report'&&value.status==='report_completed')state.phase='reported';
   return{};
  },
  snapshot(){return{session_key:state.session,primary_requests:state.requests,phase:state.phase,status_calls:state.statusCalls,running_status_reads:state.runningReads,
   fault_status_reads:state.faultReads,completed_status_reads:state.completedReads,independent_reviews:state.reviewCount,
   observed_preflight:state.preflight,native_title_gate:'root runner separately requires at most one title request, known usage/cost, total requests<=14'};},
 };
}

export function applyResolutionResearchScope(ctx,policy,owned=null){
 const guard=createResolutionResearchScopeGuard(policy,Date.now,owned),agnes=ctx.extension();
 const scoped=context=>normalizePath(context?.session?.workspaceRoot)===normalizePath(policy.workspace_root);
 agnes.registerHook('session_start',async(_payload,context)=>{
  if(scoped(context)&&context.replayed!==true)await agnes.events.append('resolution-scope-ready',{
   session_key:context.session.key,workspace_root:context.session.workspaceRoot,policy,
   primary_cap:13,native_title_gate:'Root runner independently requires known title usage/cost, <=1 title, total <=14.'});
 });
 agnes.registerHook('before_request',async(payload,context)=>{
  if(!scoped(context))return{};
  const observation=await guard.observe_preflight_completion(context);
  if(observation.observed)await agnes.events.append('resolution-scope-preflight-observed',{session_key:context.session.key,...observation});
  const verdict=guard.before_request(payload,context);
  await agnes.events.append('resolution-scope-request',{session_key:context.session.key,...verdict});
  if(verdict.allow!==true)throw new Error(verdict.reason);return{};
 });
 agnes.registerHook('before_step',(payload,context)=>scoped(context)?guard.before_step(payload,context):{});
 agnes.registerHook('tool_call',async(payload,context)=>{
  if(!scoped(context))return{allow:true};const verdict=guard.tool_call(payload,context);
  await agnes.events.append('resolution-scope-tool',{session_key:context.session.key,name:payload.name,
   action:payload.args?.action,tool_use_id:payload.toolUseId,...verdict});return verdict;
 });
 agnes.registerHook('tool_result',(payload,context)=>scoped(context)?guard.tool_result(payload,context):{});
 return guard;
}
