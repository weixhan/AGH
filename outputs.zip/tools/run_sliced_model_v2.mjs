// Reuse the public local SDK with a separately activated, workspace-scoped hook.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash, randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, origin, finishEventReading } from './agh_ws_client.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-sliced-model-v2');
const workspace = join(root, 'outputs', 'agh-sliced-model', 'workspace');
const freezePath = join(root, 'outputs', 'sliced-implementation-v2', 'freeze.json');
const freezeBytes = await readFile(freezePath);
const freeze = JSON.parse(freezeBytes);
if (freeze.execution_io_version !== 2 || freeze.scientific_protocol_changed !== false) throw new Error('Expected a frozen engineering-only v2 repair');
for (const file of freeze.files) {
  const bytes = await readFile(join(root, file.path));
  if (createHash('sha256').update(bytes).digest('hex') !== file.sha256) throw new Error(`Frozen v2 source changed: ${file.path}`);
}
const reload = JSON.parse(await readFile(join(root, 'outputs', 'agh-sliced-reload-v2', 'reload.json'), 'utf8'));
if (!reload.complete || reload.status.toolCount !== 7) throw new Error('Expected seven reloaded v2 tools');
const registration = JSON.parse(await readFile(join(root, 'outputs', 'agh-sliced-registration', 'registration.json'), 'utf8'));
if (!registration.complete || registration.status.toolCount !== 7) throw new Error('Expected seven ready tools');
const prompt = await readFile(join(root, 'agent', 'sliced_task.md'), 'utf8');
await mkdir(output, { recursive: true });
await mkdir(workspace, { recursive: true });
const record = { schema_version: 1, interface: 'official local SDK', origin, cwd: workspace,
  qualified_tool: 'mcp_defect_researcher_45e5cef9_compare_validation_slices',
  route: 'account-defect-researcher', model: 'agnes-3.0-flash', user_authorized: true,
  started_at: new Date().toISOString(), status: 'starting',
  execution_io_version: 2, implementation_freeze_sha256: createHash('sha256').update(freezeBytes).digest('hex'),
  fresh_full_cohort: true, reuse_v1_checkpoints: false,
  prompt_sha256: createHash('sha256').update(prompt).digest('hex'),
  permissions: [], calls: [], polls: [], turns: [], host_pauses: [], hook_events: [], final_texts: [],
  limitations: ['The host can send recorded same-task continuations; this is not business-step recovery.',
    'The workspace-scoped hook enforces execution; the general native tool catalog remains visible.'] };
const path = join(output, 'runner.json');
await writeFile(path, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(path, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let session, iterator, reading, afterSeq = 0, approvals = 0;
const abort = new AbortController();
const timer = setTimeout(() => abort.abort(), 35 * 60 * 1000);
let heartbeat;
try {
  await client.workspace.add(workspace);
  session = await client.session.new({ cwd: workspace, sessionKey: randomUUID() });
  record.session_id = session.id;
  record.session_url = `${origin}/?session=${encodeURIComponent(session.id)}`;
  await save();
  const normalizePath = value => String(value).replaceAll('\\', '/').replace(/\/$/, '').toLowerCase();
  const readyIterator = session.events()[Symbol.asyncIterator]();
  let readyTimer;
  try {
    record.scope_ready = await Promise.race([
      (async () => {
        for (;;) {
          const next = await readyIterator.next();
          if (next.done) throw new Error('Session event stream ended before scope readiness');
          const event = next.value;
          if (event.type.endsWith('/scope-ready')) {
            const policy = event.data.policy;
            if (event.data.mode !== 'sliced' || normalizePath(event.data.workspace_root) !== normalizePath(workspace) ||
                policy?.qualified_start_tool !== record.qualified_tool ||
                policy?.qualified_status_tool !== 'mcp_defect_researcher_45e5cef9_get_task_status' ||
                policy?.max_status_calls !== 120 || policy?.schema_version !== 1) {
              throw new Error('Scope hook initialized for another workspace or mode');
            }
            return { seq: event.seq, type: event.type, data: event.data };
          }
        }
      })(),
      new Promise((_, reject) => { readyTimer = setTimeout(() => reject(new Error('Scope hook did not confirm readiness')), 10_000); }),
    ]);
    await save();
  } finally {
    clearTimeout(readyTimer);
    await readyIterator.return?.();
  }
  session.onPermissionRequest(async request => {
    const name = request.toolCall?._meta?.['ai.agnes.harness']?.tool;
    const input = request.toolCall?.rawInput;
    const once = request.options.find(option => option.kind === 'allow_once');
    const allowed = request.sessionId === session.id && name === record.qualified_tool &&
      input && typeof input === 'object' && !Array.isArray(input) && Object.keys(input).length === 0 && approvals === 0 && Boolean(once);
    if (allowed) approvals++;
    record.permissions.push({ tool: name, input, tool_call_id: request.toolCall?.toolCallId, decision: allowed ? 'allowed-once' : 'rejected' });
    await save();
    return allowed ? { optionId: once.optionId } : { verdict: 'rejected' };
  });
  await session.setModel({ slot: 'primary', route: record.route, model: record.model });
  heartbeat = setInterval(() => console.log(JSON.stringify({ running: true, session: session.id,
    task_id: record.task_id, stage: record.polls.at(-1)?.stage, status: record.polls.at(-1)?.status })), 30_000);
  for (let turn = 0; turn < 12; turn++) {
    iterator = session.events()[Symbol.asyncIterator]();
    reading = (async () => {
      for (;;) {
        const next = await iterator.next();
        if (next.done) break;
        const event = next.value;
        if (event.seq <= afterSeq) continue;
        if (event.type === 'custom' || event.type.startsWith('extension/') || event.type.endsWith('/scope-ready') || event.type.endsWith('/scope-decision')) {
          record.hook_events.push({ seq: event.seq, type: event.type, data: event.data });
        }
        if (event.type === 'tool/call') {
          record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
          console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
        }
        if (event.type === 'tool/result') {
          const text = event.data.content?.find(block => block.type === 'text')?.text;
          let value;
          try { value = JSON.parse(text); } catch { /* ledger preserves the complete tool result */ }
          if (value?.task_id) {
            record.task_id ??= value.task_id;
            if (record.task_id !== value.task_id) throw new Error('Different task queried');
            record.polls.push({ seq: event.seq, task_id: value.task_id, status: value.status, stage: value.current_stage,
              summary: value.status === 'completed' ? value.summary : undefined, evidence: value.evidence, artifacts: value.artifacts });
          }
        }
        if (event.type === 'message' || event.type.startsWith('message/') || event.type.startsWith('assistant/')) record.final_texts.push({ seq: event.seq, type: event.type, data: event.data });
        await save();
        if (event.type === 'turn/end') break;
      }
    })();
    const message = turn === 0 ? prompt : `继续读取既有任务 ${record.task_id}，只调用 get_task_status，不能重复启动。每回合最多10次查询，若仍running则说明尚未完成并结束回合。完成后依据真实 summary 返回最初要求的中文结论与精简JSON。`;
    try {
      const result = await session.prompt(message, { signal: abort.signal, titleLocale: 'zh-CN' });
      await finishEventReading(reading);
      await iterator.return?.();
      record.turns.push({ turn, message_sha256: createHash('sha256').update(message).digest('hex'), result });
      afterSeq = result.lastSeq;
    } catch (error) {
      record.turns.push({ turn, failure: { type: error.name, message: error.message } });
      await iterator.return?.();
      await finishEventReading(reading).catch(() => undefined);
      if (!record.task_id || abort.signal.aborted) throw error;
      afterSeq = Math.max(afterSeq, ...record.calls.map(row => row.seq), ...record.polls.map(row => row.seq));
    }
    await save();
    if (record.polls.at(-1)?.status === 'failed') throw new Error('Sliced business task failed; refusing a repeated start or continuation');
    if (record.polls.at(-1)?.status === 'completed' && record.turns.at(-1)?.result) break;
    if (record.polls.at(-1)?.status === 'running' && turn < 11) {
      record.host_pauses.push({ after_turn: turn, milliseconds: 60000, reason: 'bounded same-session continuation pacing; not a model tool or business-step recovery' });
      await save();
      await new Promise(resolvePause => setTimeout(resolvePause, 60000));
    }
  }
  const terminal = record.polls.at(-1);
  if (terminal?.status !== 'completed' || terminal.summary?.slicing_status !== 'passed' || terminal.summary.input_hashes_unchanged !== true) {
    throw new Error('No passed terminal sliced result');
  }
  record.status = 'completed';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  clearTimeout(timer);
  clearInterval(heartbeat);
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  if (session) {
    for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
      let reader;
      try {
        reader = await webClient();
        await exportSession({ positional: [session.id], format, raw: false, out: join(output, filename) }, {
          cwd: workspace, io: { stdout: process.stdout, stderr: process.stderr },
          writeFile: (target, bytes) => writeFile(target, bytes, { flag: 'wx' }),
        }, reader);
      } catch (error) {
        record.export_failure = { type: error.name, message: error.message };
        process.exitCode = 1;
      } finally { await reader?.close(); }
    }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: record.session_id, task_id: record.task_id,
    failure: record.failure, export_failure: record.export_failure }));
}
