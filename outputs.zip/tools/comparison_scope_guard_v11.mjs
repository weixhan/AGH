// Bounded model actions; the trusted runner supplies one pre-existing clock.
export const normalizePath = value => typeof value==='string'?value.replaceAll('\\','/').replace(/\/+$/,'').toLowerCase():'';
const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const exact=(x,keys)=>object(x)&&Object.keys(x).sort().join(',')===[...keys].sort().join(',');
const HANDLE=/^cmp_[0-9a-f]{32}$/;
const actions=['inspect_input','verify_input','repair_copy','verify_copy','read_science','publish_report'];
export function createComparisonGuard(policy, now=Date.now){
 const keys=['schema_version','workspace_root','qualified_action_tool','allowed_handles','max_model_requests','max_wall_seconds','max_action_calls'];
 if(!exact(policy,keys)||policy.schema_version!==1||!normalizePath(policy.workspace_root)||
  !/^mcp_dr_compare_v11_(diagnostic|pilot|formal)_[0-9a-f]{8}_execute_case_action_v1$/.test(policy.qualified_action_tool)||
  !Array.isArray(policy.allowed_handles)||!policy.allowed_handles.length||new Set(policy.allowed_handles).size!==policy.allowed_handles.length||
  !policy.allowed_handles.every(x=>HANDLE.test(x))||policy.max_model_requests!==6||policy.max_wall_seconds!==120||policy.max_action_calls!==8)
  throw new Error('Invalid comparison scope policy');
 const pinned=structuredClone(policy),states=new Map(),denied=reason=>({allow:false,reason:'COMPARISON_SCOPE_DENIED: '+reason});
 const contextValid=ctx=>object(ctx?.session)&&typeof ctx.session.key==='string'&&ctx.session.key&&ctx.replayed!==true&&normalizePath(ctx.session.workspaceRoot)===normalizePath(pinned.workspace_root);
 function current(state){const t=now();if(!Number.isFinite(t)||t<state.last||t<state.started||t>=state.deadline-35000)return false;state.last=t;return true;}
 return {
  before_request(payload,ctx,binding){
   if(!contextValid(ctx)||payload?.slot!=='primary'||payload?.model!=='agnes-3.0-flash')return denied('session/model mismatch');
   let state=states.get(ctx.session.key);
   if(!state){
    const keys=['schema_version','owner','trial_handle','session_key','started_epoch_ms','deadline_epoch_ms','arm_sha256'];
    if(!exact(binding,keys)||binding.schema_version!==1||binding.owner!=='comparison-model-runner-v1'||binding.session_key!==ctx.session.key||
     !pinned.allowed_handles.includes(binding.trial_handle)||typeof binding.arm_sha256!=='string'||!/^[a-f0-9]{64}$/.test(binding.arm_sha256)||
     !Number.isFinite(binding.started_epoch_ms)||!Number.isFinite(binding.deadline_epoch_ms)||
     Math.abs(binding.deadline_epoch_ms-binding.started_epoch_ms-120000)>0.001)return denied('trusted original clock binding missing');
    state={handle:binding.trial_handle,started:binding.started_epoch_ms,deadline:binding.deadline_epoch_ms,last:binding.started_epoch_ms,requests:0,calls:0,accepted:new Set(),arm_sha256:binding.arm_sha256};
    states.set(ctx.session.key,state);
   }
   if(!current(state)||state.requests>=6)return denied('original deadline or request cap');
   state.requests++;
   return {allow:true,request_index:state.requests,trial_handle:state.handle,started_epoch_ms:state.started,deadline_epoch_ms:state.deadline,arm_sha256:state.arm_sha256};
  },
  before_step(_payload,ctx){if(!contextValid(ctx))return {block:true,reason:'COMPARISON_SCOPE_DENIED: invalid session'};const state=states.get(ctx.session.key);return !state||current(state)?{}:{block:true,reason:'COMPARISON_SCOPE_DENIED: original clock expired'};},
  tool_call(payload,ctx){
   const state=contextValid(ctx)?states.get(ctx.session.key):null;
   if(!state||!current(state)||!state.requests||!object(payload)||payload.name!==pinned.qualified_action_tool||
    typeof payload.toolUseId!=='string'||!payload.toolUseId||state.accepted.has(payload.toolUseId)||state.calls>=8)return denied('foreign/duplicate/exhausted action');
   const a=payload.args;
   if(!exact(a,a?.action==='publish_report'?['trial_handle','action','report']:['trial_handle','action'])||a.trial_handle!==state.handle||!actions.includes(a.action))return denied('action arguments outside registered trial');
   state.accepted.add(payload.toolUseId);state.calls++;
   return {allow:true,trial_handle:state.handle,action_index:state.calls,deadline_epoch_ms:state.deadline};
  }
 };
}
