"""Independently crosscheck a scoped Agnes sliced-comparison session and its artifacts.

Official exports can mask long decimal digits inside embedded tool JSON. Those
values are retained as unknown markers, never recovered from disk. Only the
fixed compact projection is compared to that export; exact detailed science is
separately bound to the public SDK result sequence and the independent review.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from tools.verify_diagnosis_run import decode, read, lines

START_TOOL = "mcp_defect_researcher_45e5cef9_compare_validation_slices"
STATUS_TOOL = "mcp_defect_researcher_45e5cef9_get_task_status"
TOOL = "compare_validation_slices"
UNKNOWN = "__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__"
COMPACT_KEYS = {"status","task_id","slicing_status","candidate_status","reference_reused","input_hashes_unchanged","training_performed","test_inference_performed","baseline","sliced","medium","failed_gates"}
COUNT_KEYS = {"tp", "fp", "fn", "normal_fp_images", "normal_fp_boxes"}
DECIMAL_KEYS = {"mAP50", "mAP50_95", "precision", "recall", "normal_image_fp_rate"}
MEDIUM_KEYS = {"gt", "images", "medium_tp_gain", "medium_gain_images", "medium_recovered_gt", "medium_lost_gt"}
MASKABLE_COMPACT_PATHS = {(arm, key) for arm in ("baseline", "sliced") for key in DECIMAL_KEYS}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def normalize_path(value):
    return str(value).replace("\\", "/").rstrip("/").lower()


def exact(left, right):
    """JSON booleans never compare equal to scientific integer counts."""
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    # JavaScript serializes 0.0/1.0 as 0/1. They are the same JSON number;
    # unlike bool coercion, preserving exact numerical equality is legitimate.
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def official_payload(text):
    """Parse masked numeric tokens as unknown strings, without restoring numbers."""
    try:
        return decode(text), []
    except (json.JSONDecodeError, ValueError):
        pattern = r'([:,\[]\s*)-?(?:\d+\.)?\[REDACTED:id\](?=\s*[,}\]])'
        changed, count = re.subn(pattern, lambda match: match[1] + json.dumps(UNKNOWN), text)
        if not count:
            raise
        value = decode(changed)
        masked = []
        def visit(item, path):
            if isinstance(item, dict):
                for key, child in item.items():
                    visit(child, path + [key])
            elif isinstance(item, list):
                for index, child in enumerate(item):
                    visit(child, path + [index])
            elif item == UNKNOWN:
                masked.append(path)
        visit(value, [])
        return value, masked


def _valid_compact(value, masked_paths=()):
    if not isinstance(value, dict) or value.keys() != COMPACT_KEYS:
        return False
    masks = {tuple(path) for path in masked_paths}
    if (value["status"] != "completed" or not isinstance(value["task_id"], str)
            or not re.fullmatch(r"[a-f0-9]{32}", value["task_id"])
            or value["slicing_status"] != "passed" or value["candidate_status"] not in {"accepted", "stop"}):
        return False
    if any(type(value[k]) is not bool for k in ("reference_reused", "input_hashes_unchanged", "training_performed", "test_inference_performed")):
        return False
    for arm in ("baseline", "sliced"):
        row = value[arm]
        if not isinstance(row, dict) or row.keys() != COUNT_KEYS | DECIMAL_KEYS:
            return False
        if any(type(row[k]) is not int or row[k] < 0 for k in COUNT_KEYS):
            return False
        for key in DECIMAL_KEYS:
            number = row[key]
            if number == UNKNOWN and (arm, key) in masks and (arm, key) in MASKABLE_COMPACT_PATHS:
                continue
            if (isinstance(number, bool) or not isinstance(number, (int, float))
                    or not math.isfinite(number) or not 0 <= number <= 1):
                return False
    medium = value["medium"]
    if not isinstance(medium, dict) or medium.keys() != MEDIUM_KEYS:
        return False
    if any(type(medium[k]) is not int or (k != "medium_tp_gain" and medium[k] < 0) for k in MEDIUM_KEYS):
        return False
    return (isinstance(value["failed_gates"], list)
            and all(isinstance(v, str) and v for v in value["failed_gates"])
            and len(set(value["failed_gates"])) == len(value["failed_gates"]))


def compact_target(disk, masked_paths=()):
    try:
        result = {"status": disk["status"], "task_id": disk["task_id"],
                  **{key: disk["summary"][key] for key in COMPACT_KEYS - {"status","task_id"}}}
        paths = [path[1:] for path in masked_paths if path and path[0] == "summary"]
        return result if _valid_compact(result, paths) else None
    except (KeyError,TypeError,AttributeError):
        return None


def _final_payload(text, *, official=False):
    blocks = re.findall(r"```json\s*\n(.*?)\n```", text, flags=re.S)
    if len(blocks) != 1:
        return None, []
    try:
        value, masks = official_payload(blocks[0]) if official else (decode(blocks[0]), [])
    except (ValueError,json.JSONDecodeError):
        return None, []
    return (value, masks) if _valid_compact(value, masks) else (None, masks)


def final_compact(text):
    return _final_payload(text)[0]


def projected_exact(observed, expected, masked_paths=()):
    """Only explicitly observed decimal masks may be excluded from a comparison."""
    if not _valid_compact(observed, masked_paths) or not _valid_compact(expected):
        return False
    value = copy.deepcopy(observed)
    target = copy.deepcopy(expected)
    for path in masked_paths:
        if tuple(path) not in MASKABLE_COMPACT_PATHS:
            return False
        arm, key = path
        if value[arm][key] != UNKNOWN:
            return False
        # Both projections keep the unknown marker. No source number is written
        # back into the observed official JSON, including in returned reports.
        target[arm][key] = UNKNOWN
    return exact(value, target)


def aligned_ready(event, workspace):
    value = copy.deepcopy(event)
    data = value["data"]
    if normalize_path(data.get("workspace_root")) == normalize_path(workspace):
        data["workspace_root"] = "<workspace>"
    if normalize_path(data.get("policy", {}).get("workspace_root")) == normalize_path(workspace):
        data["policy"]["workspace_root"] = "<workspace>"
    return value


def check_ledger(rows, runner, disk, *, expected_workspace=None):
    """Pure ledger verifier used by synthetic tamper tests and real review."""
    calls = [row for row in rows if row.get("type") == "tool/call"]
    result_rows = [row for row in rows if row.get("type") == "tool/result"]
    results = {row["data"]["toolUseId"]: row for row in result_rows}
    starts = [row for row in calls if row["data"].get("name") == START_TOOL]
    polls = [row for row in calls if row["data"].get("name") == STATUS_TOOL]
    ready = [row for row in rows if row.get("type", "").endswith("/scope-ready")]
    decisions = [row for row in rows if row.get("type", "").endswith("/scope-decision")]
    decisions_by_call = {row["data"].get("tool_use_id"): row for row in decisions}
    approvals = [row for row in rows if row.get("type") == "approval/decided"]
    ends = [row for row in rows if row.get("type") == "turn/end"]
    inference = [row for row in rows if row.get("type") == "cost/ledger" and row.get("data", {}).get("purpose") == "inference"]
    parsed, masks_by_call, masked, parse_errors = {}, {}, [], []
    for call in starts + polls:
        result = results.get(call["data"].get("toolUseId"), {})
        texts = [part.get("text") for part in result.get("data", {}).get("content", []) if part.get("type") == "text"]
        try:
            if len(texts) != 1:
                raise ValueError("Tool result has no unique text block")
            value, masks = official_payload(texts[0])
            parsed[call["seq"]] = value
            masks_by_call[call["seq"]] = masks
            masked.extend({"result_seq": result.get("seq"), "path": path} for path in masks)
        except (json.JSONDecodeError, ValueError, TypeError) as error:
            parse_errors.append({"call_seq": call["seq"], "type": type(error).__name__})
    start = starts[0] if len(starts) == 1 else None
    launch = parsed.get(start["seq"], {}) if start else {}
    task_id = disk.get("task_id")
    completed = [call for call in polls if parsed.get(call["seq"], {}).get("status") == "completed"]
    terminal_call = completed[-1] if completed else None
    terminal_result = results.get(terminal_call["data"]["toolUseId"], {}) if terminal_call else {}
    terminal = parsed.get(terminal_call["seq"], {}) if terminal_call else {}
    target = compact_target(disk)
    messages = [row for row in rows if row.get("type") == "assistant/message"]
    final = next((row for row in reversed(messages) if ends and row["seq"] == ends[-1]["data"].get("lastAssistantSeq")), None)
    text = "\n".join(part["text"] for part in final["data"].get("content", []) if part.get("type") == "text") if final else ""
    final_value, final_masks = _final_payload(text, official=True)
    terminal_masks = masks_by_call.get(terminal_call["seq"], []) if terminal_call else []
    compact_masks = [path[1:] for path in terminal_masks if path and path[0] == "summary"
                     and tuple(path[1:]) in MASKABLE_COMPACT_PATHS]
    sdk_final = next((row for row in runner.get("final_texts", [])
                      if final and row.get("seq") == final["seq"] and row.get("type") == final["type"]), None)
    sdk_final_text = "\n".join(part["text"] for part in sdk_final.get("data", {}).get("content", [])
                               if part.get("type") == "text") if sdk_final else ""
    sdk_final_value = final_compact(sdk_final_text)
    sdk_ready = runner.get("scope_ready", {})
    workspace = expected_workspace or runner.get("cwd")
    expected_policy = {"schema_version": 1, "workspace_root": "<workspace>", "qualified_start_tool": START_TOOL,
                       "qualified_status_tool": STATUS_TOOL, "max_status_calls": 120}
    first_ready = ready[0] if len(ready) == 1 else None
    extension_prefix = first_ready["type"].rsplit("/", 1)[0] if first_ready else None
    sdk_completed = [row for row in runner.get("polls", []) if row.get("status") == "completed"]
    sdk_terminal = next((row for row in sdk_completed if row.get("seq") == terminal_result.get("seq")), None)
    sdk_calls = {row["seq"]: row for row in runner.get("calls", [])}
    sdk_hook_events = {row["seq"]: row for row in runner.get("hook_events", []) if row.get("type", "").endswith("/scope-decision")}
    checks = {
        "continuous_official_ledger": [row.get("seq") for row in rows] == list(range(1, len(rows) + 1)),
        "fresh_session_identity": bool(rows and rows[0].get("type") == "session/start" and rows[0]["data"].get("key") == runner.get("session_id")),
        "one_empty_argument_model_sliced_start": bool(start and start.get("origin") == "model" and start["data"].get("args") == {}),
        "only_requested_model_tool_attempts": len(calls) == len(starts) + len(polls) and all(row.get("origin") == "model" for row in calls),
        "one_scope_ready_before_first_call": bool(first_ready and calls and first_ready["seq"] < min(row["seq"] for row in calls)),
        "scope_ready_mode_session_and_policy_bound": bool(first_ready and first_ready["data"].get("mode") == "sliced"
            and first_ready["data"].get("session_key") == runner.get("session_id")
            and first_ready["data"].get("workspace_root") == "<workspace>" and exact(first_ready["data"].get("policy"), expected_policy)),
        "public_sdk_readiness_exact_workspace_and_event": bool(first_ready and sdk_ready.get("seq") == first_ready["seq"] and sdk_ready.get("type") == first_ready["type"]
            and normalize_path(sdk_ready.get("data", {}).get("workspace_root")) == normalize_path(workspace)
            and exact(aligned_ready(sdk_ready, workspace).get("data"), first_ready["data"])),
        "each_attempt_has_one_paired_allowed_scope_decision": len(decisions) == len(calls) == len(decisions_by_call) and all(
            call["data"]["toolUseId"] in decisions_by_call
            and call["seq"] < decisions_by_call[call["data"]["toolUseId"]]["seq"] < results.get(call["data"]["toolUseId"], {}).get("seq", 0)
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("name") == call["data"].get("name")
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("session_key") == runner.get("session_id")
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("allow") is True
            and decisions_by_call[call["data"]["toolUseId"]]["data"].get("reason") is None for call in calls),
        "scope_events_from_same_registered_extension": bool(first_ready and all(row["type"].rsplit("/", 1)[0] == extension_prefix
            and row.get("origin") == first_ready.get("origin") and str(row.get("origin", "")).startswith("ext:plugin/") for row in ready + decisions)),
        "public_sdk_scope_decisions_equal_official": len(sdk_hook_events) == len(decisions) and all(
            row["seq"] in sdk_hook_events and sdk_hook_events[row["seq"]].get("type") == row["type"]
            and exact(sdk_hook_events[row["seq"]].get("data"), row["data"]) for row in decisions),
        "unique_call_result_ids_and_exact_pairing": len({row["data"]["toolUseId"] for row in calls}) == len(calls)
            and len(results) == len(result_rows) == len(calls) and all(row["data"]["toolUseId"] in results
            and results[row["data"]["toolUseId"]]["seq"] > row["seq"]
            and results[row["data"]["toolUseId"]].get("sourceEventSeqs") == [row["seq"]] for row in calls),
        "all_tool_results_successful_no_rejected_attempt": all(row["data"].get("isError") is False and row["data"].get("code") not in {"HOOK_DENIED", "APPROVAL_REJECTED"} for row in result_rows),
        "launch_returned_running_same_task": launch.get("status") == "running" and launch.get("task_id") == task_id == runner.get("task_id"),
        "status_polls_same_task_after_launch_within_budget": bool(start and polls and len(polls) <= 120 and all(
            row["data"].get("args") == {"task_id": task_id} and row["seq"] > results.get(start["data"]["toolUseId"], {}).get("seq", 0) for row in polls)),
        "one_allow_once_for_start_before_result": bool(start and len(approvals) == 1 and approvals[0]["data"].get("verdict") == "allowed-once"
            and approvals[0]["data"].get("scope") == f"tool:{START_TOOL}:execute"
            and start["seq"] < approvals[0]["seq"] < results.get(start["data"]["toolUseId"], {}).get("seq", 0)),
        "public_sdk_host_approval_budget_exact": len(runner.get("permissions", [])) == 1
            and runner["permissions"][0].get("tool") == START_TOOL and runner["permissions"][0].get("input") == {}
            and runner["permissions"][0].get("decision") == "allowed-once"
            and bool(start and runner["permissions"][0].get("tool_call_id") == start["data"].get("toolUseId")),
        "public_sdk_tool_calls_exact_official_calls": len(sdk_calls) == len(calls) and all(row["seq"] in sdk_calls
            and sdk_calls[row["seq"]].get("name") == row["data"].get("name") and sdk_calls[row["seq"]].get("args") == row["data"].get("args")
            and sdk_calls[row["seq"]].get("origin") == row.get("origin") for row in calls),
        "official_payloads_parse_without_numeric_recovery": not parse_errors and len(parsed) == len(starts) + len(polls),
        "all_official_payloads_same_task": bool(parsed and all(value.get("task_id") == task_id for value in parsed.values())),
        "terminal_official_compact_science_matches_disk": bool(target and terminal.get("tool") == TOOL
            and projected_exact(compact_target(terminal, terminal_masks), target, compact_masks)),
        "terminal_public_sdk_exact_summary_and_evidence_matches_disk": bool(sdk_terminal and sdk_terminal.get("task_id") == task_id
            and exact(sdk_terminal.get("summary"), disk.get("summary")) and exact(sdk_terminal.get("evidence"), disk.get("evidence"))),
        "model_requests_use_agnes_with_successful_response": bool(inference and any(row["data"].get("response", {}).get("status") == 200 for row in inference)
            and all(row["data"].get("model") == "agnes-3.0-flash" and (row["data"].get("response", {}).get("status") == 200 or row["data"].get("interrupted") is True) for row in inference)),
        "final_completed_turn_after_completed_tool": bool(final and ends and ends[-1]["data"].get("reason") == "completed"
            and final["seq"] > terminal_result.get("seq", float("inf")) and ends[-1]["seq"] > final["seq"]),
        "model_final_unique_compact_json_matches_disk": target is not None and projected_exact(final_value, target, final_masks),
        "public_sdk_final_model_json_exact_unmasked_science_matches_disk": bool(sdk_final and target is not None and exact(sdk_final_value, target)),
        "host_runner_completed_without_export_failure": runner.get("status") == "completed" and not runner.get("failure") and not runner.get("export_failure"),
        "sliced_terminal_same_weight_no_training_test": disk.get("status") == "completed" and disk.get("tool") == TOOL
            and disk.get("summary", {}).get("slicing_status") == "passed" and disk.get("summary", {}).get("input_hashes_unchanged") is True
            and disk.get("summary", {}).get("reference_reused") is True
            and disk.get("summary", {}).get("same_weight") is True
            and all(disk.get("summary", {}).get(key) is False for key in ("training_performed", "test_inference_performed")),
        "sliced_terminal_actual_inference_population_and_controls":
            type(disk.get("summary", {}).get("successful_observations")) is int
            and disk["summary"]["successful_observations"] == 5760
            and type(disk["summary"].get("formal_calls")) is int and 5760 <= disk["summary"]["formal_calls"] <= 5770
            and type(disk["summary"].get("warmup_calls")) is int and 0 <= disk["summary"]["warmup_calls"] <= 1
            and disk["summary"].get("precision") == "FP32" and disk["summary"].get("device") == "0"
            and exact(disk["summary"].get("train_imgsz"), 640) and exact(disk["summary"].get("eval_imgsz"), 640)
            and disk["summary"].get("split") == "val" and disk["summary"].get("threshold_changed") is False,
    }
    scope_keys = {"only_requested_model_tool_attempts", "one_empty_argument_model_sliced_start", "one_scope_ready_before_first_call",
                  "scope_ready_mode_session_and_policy_bound", "public_sdk_readiness_exact_workspace_and_event",
                  "each_attempt_has_one_paired_allowed_scope_decision", "scope_events_from_same_registered_extension",
                  "public_sdk_scope_decisions_equal_official", "all_tool_results_successful_no_rejected_attempt",
                  "status_polls_same_task_after_launch_within_budget", "one_allow_once_for_start_before_result", "public_sdk_host_approval_budget_exact"}
    return {"checks": checks, "strict_tool_scope_passed": all(checks[key] for key in scope_keys),
            "official_compact_science_passed": checks["terminal_official_compact_science_matches_disk"] and checks["model_final_unique_compact_json_matches_disk"],
            "task_id": task_id, "session_id": runner.get("session_id"), "event_count": len(rows), "tool_call_count": len(calls),
            "poll_count": len(polls), "model_turn_count": len(ends), "masked_numeric_paths_not_recovered": masked,
            "masked_final_numeric_paths_not_recovered": final_masks,
            "official_numeric_projection": "known counts and categories plus directly visible decimals; masked decimal values remain unknown",
            "parse_errors": parse_errors, "final_model_text": text,
            "unrequested_tool_attempts": [{"seq": row["seq"], "name": row["data"].get("name"),
                                           "result_code": results.get(row["data"]["toolUseId"], {}).get("data", {}).get("code")}
                                          for row in calls if row not in starts + polls]}


def check_scientific_binding(independent, task_dir, output_root, task_id, *, expected_protocol_sha256=None, expected_frozen_protocol=None):
    """Bind the prior complete scientific review to current sealed artifact bytes.

    This hashes saved artifacts and five completion/protocol identities. It does
    not decode images, rerun inference, regenerate tiles or rescore predictions.
    """
    checks = {
        "independent_review_passed_with_typed_nonzero_check_counts": isinstance(independent, dict)
            and independent.get("status") == "passed"
            and type(independent.get("passed_checks")) is int and independent["passed_checks"] > 0
            and type(independent.get("total_checks")) is int
            and independent["passed_checks"] == independent["total_checks"],
        "independent_review_bound_to_model_launched_task": isinstance(independent, dict) and independent.get("task_id") == task_id,
        "independent_review_check_values_all_true": isinstance(independent, dict)
            and isinstance(independent.get("checks"), dict) and bool(independent["checks"])
            and independent.get("total_checks") == len(independent["checks"])
            and all(value is True for value in independent["checks"].values()),
    }
    try:
        task_dir, output_root = Path(task_dir).resolve(), Path(output_root).resolve()
        if (not re.fullmatch(r"[a-f0-9]{32}", task_id) or task_dir.name != task_id
                or not task_dir.parent.samefile(output_root)):
            raise ValueError("Task identity or directory is outside the model task")
        protocol = read(task_dir / "protocol.json")
        source_id, diagnosis_id = protocol.get("source_task_id"), protocol.get("diagnosis_task_id")
        if (not isinstance(source_id, str) or not re.fullmatch(r"[a-f0-9]{32}", source_id)
                or not isinstance(diagnosis_id, str) or not re.fullmatch(r"diagnosis-[a-f0-9]{32}", diagnosis_id)):
            raise ValueError("Protocol source identities are unsafe")
        paths = {"task_completion_sha256": task_dir / "completion.json",
                 "task_manifest_sha256": task_dir / "artifact_manifest.json",
                 "task_protocol_sha256": task_dir / "protocol.json",
                 "source_completion_sha256": output_root / source_id / "completion.json",
                 "diagnosis_completion_sha256": output_root / diagnosis_id / "completion.json"}
        for key, path in paths.items():
            checks[f"independent_review_{key}_matches_current_bytes"] = (
                isinstance(independent.get(key), str) and re.fullmatch(r"[a-f0-9]{64}", independent[key]) is not None
                and independent[key] == digest(path))
        checks["task_protocol_matches_frozen_candidate_protocol"] = (
            expected_protocol_sha256 is None or protocol.get("protocol_sha256") == expected_protocol_sha256)
        # The saved protocol adds task/source identities to the frozen fixture;
        # its own byte hash differs legitimately and is bound above separately.
        checks["task_protocol_preserves_all_frozen_scientific_controls"] = (
            expected_frozen_protocol is None or isinstance(expected_frozen_protocol, dict)
            and all(key in protocol and exact(protocol[key], value) for key, value in expected_frozen_protocol.items()))
        completion, manifest = read(paths["task_completion_sha256"]), read(paths["task_manifest_sha256"])
        checks["current_task_completion_and_manifest_are_same_sealed_task"] = (
            completion.get("task_id") == manifest.get("task_id") == task_id
            and completion.get("status") == manifest.get("status") == "completed"
            and completion.get("tool") == manifest.get("tool") == TOOL
            and completion.get("artifact_manifest_sha256") == digest(paths["task_manifest_sha256"]))
        files = manifest.get("files")
        if not isinstance(files, list) or not files:
            raise ValueError("Missing sealed file list")
        seen, sealed = set(), True
        for row in files:
            if not isinstance(row, dict):
                raise ValueError("Invalid sealed file record")
            name = row.get("name")
            if not isinstance(name, str) or Path(name).name != name or name in seen or name in {"completion.json", "artifact_manifest.json"}:
                raise ValueError("Unsafe or duplicate sealed artifact name")
            seen.add(name)
            path = (task_dir / name).resolve()
            if path.parent != task_dir:
                raise ValueError("Sealed artifact resolves outside task")
            sealed = sealed and (normalize_path(row.get("path")) == normalize_path(path)
                and type(row.get("size_bytes")) is int and row["size_bytes"] == path.stat().st_size
                and row.get("sha256") == digest(path)
                and completion.get("artifacts_sha256", {}).get(name) == row.get("sha256"))
        checks["previous_review_current_sealed_artifact_bytes_unchanged"] = (
            sealed and {"sliced_result.json", "protocol.json", "sliced_comparison.json", "decision.json"} <= seen
            and set(completion.get("artifacts_sha256", {})) == seen)
    except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError) as error:
        checks["independent_review_binding_readable_and_safe"] = False
        return {"checks": checks, "passed": False, "error": {"type": type(error).__name__, "message": str(error)}}
    checks["independent_review_binding_readable_and_safe"] = True
    return {"checks": checks, "passed": all(checks.values()), "hashes_checked": {key: digest(path) for key, path in paths.items()},
            "scope": "reuse_previously_completed_full_scientific_review_without_repeating_tile_or_image_analysis"}


def expected_model_workspace(directory, output_root):
    """A fresh v2 receipt reuses the already registered, fixed guard workspace."""
    directory, output_root = Path(directory).resolve(), Path(output_root).resolve()
    if directory == output_root / "agh-sliced-model-v2":
        return output_root / "agh-sliced-model" / "workspace"
    return directory / "workspace"


def review(directory, configuration=None):
    configuration = configuration or load_config()
    directory = Path(directory).resolve()
    output_root = Path(configuration["output_root"]).resolve()
    if not directory.is_relative_to(output_root):
        raise ValueError("Model run directory escapes configured output root")
    runner = read(directory / "runner.json")
    task_id = runner.get("task_id")
    if not isinstance(task_id, str) or not re.fullmatch(r"[a-f0-9]{32}", task_id):
        raise ValueError("Model-launched sliced task must have a safe opaque task identity")
    task_dir = output_root / task_id
    # A prior full independent scientific review is mandatory below. Reading the
    # sealed result here avoids calling the business status path, whose semantic
    # verifier would otherwise repeat all tile decoding and geometric work.
    disk = read(task_dir / "sliced_result.json")
    rows = lines(directory / "session.jsonl")
    workspace = expected_model_workspace(directory, output_root)
    report = check_ledger(rows, runner, disk, expected_workspace=workspace)
    independent = read(directory / "independent_verification.json")
    binding = check_scientific_binding(independent, task_dir, output_root, task_id,
                                      expected_protocol_sha256=digest(ROOT / "fixtures" / "sliced_protocol.json"),
                                      expected_frozen_protocol=read(ROOT / "fixtures" / "sliced_protocol.json"))
    report["checks"].update(binding["checks"])
    report["checks"].update(
        runner_expected_project_workspace=normalize_path(runner.get("cwd")) == normalize_path(workspace),
        runner_prompt_matches_frozen_sliced_instruction=runner.get("prompt_sha256") == digest(ROOT / "agent" / "sliced_task.md"),
        independent_scientific_artifact_review_passed=binding["passed"],
        session_html_export_present=(directory / "session.html").is_file())
    paths = [directory / "runner.json", directory / "session.jsonl", directory / "session.html"] + sorted(path for path in task_dir.iterdir() if path.is_file())
    scan = [{"path": str(path), "candidate_count": len(re.findall(rb"\bsk-[A-Za-z0-9._-]{12,}", path.read_bytes()))} for path in paths]
    report["checks"]["no_credential_candidates_in_exports_and_task_artifacts"] = all(row["candidate_count"] == 0 for row in scan)
    report.update(schema_version=1, verification_kind="official_scoped_model_sliced_crosscheck",
                  status="passed" if all(report["checks"].values()) else "failed", model_used=True,
                  checks_passed=sum(report["checks"].values()), checks_total=len(report["checks"]),
                  reasons=[key for key, value in report["checks"].items() if not value],
                  scientific_artifact_checks_passed=binding["passed"], independent_artifact_review=independent,
                  independent_artifact_review_sha256=digest(directory / "independent_verification.json"),
                  independent_artifact_review_binding=binding,
                  new_detection_inference_performed=binding["passed"] and report["checks"]["sliced_terminal_actual_inference_population_and_controls"],
                  secret_scan=scan, evidence_sha256={path.name: digest(path) for path in paths[:3]},
                  numeric_redaction_rule="Masked numeric tokens remain unknown. Official compact integer and category fields must remain directly verifiable; only explicitly observed decimal masks may be omitted from the official comparison. Exact compact and detailed decimals are checked through the public SDK terminal result and final model message sequence, plus the hash-bound prior scientific review, never restored into the official export.",
                  limitations=["This acceptance covers a fresh sliced-comparison session, not the previously failed resolution-comparison session.",
                               "The hook enforces execution scope but does not remove native tools from the model-visible catalog.",
                               "Host continuations, if present, are recorded; they do not demonstrate business-step recovery or autonomous scheduling.",
                               "The saved slicing result is a validation-only, same-weight joint strategy; no training or test evaluation. A scientific stop is distinct from execution failure."])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, default=ROOT / "outputs" / "agh-sliced-model")
    parser.add_argument("--config")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = review(args.run_dir, load_config(args.config))
    except Exception as error:
        report = {"status": "failed", "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "checks_passed", "checks_total", "reasons", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
