// Use the public, already-running AGH web endpoint without reading private daemon files.
import { createClient, memoryJournal } from '../../agnes-harness/packages/sdk/src/index.node.ts';

export const origin = 'http://127.0.0.1:4177';
export async function finishEventReading(reading) {
  if (!reading) return;
  let timer;
  try {
    await Promise.race([reading, new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Terminal event was not observed after prompt completion')), 10_000);
    })]);
  } finally { clearTimeout(timer); }
}

export async function webClient() {
  const response = await fetch(origin);
  if (!response.ok) throw new Error('AGH web endpoint is unavailable');
  const html = await response.text();
  const address = html.match(/<meta\s+id="agnes-config"\s+data-ws="([^"]+)"\s*\/>/)?.[1];
  if (!address || !/^ws:\/\/127\.0\.0\.1:\d+\/$/.test(address)) {
    throw new Error('AGH did not publish the expected loopback WebSocket');
  }
  const client = createClient({
    transport: { kind: 'ws', url: address, protocols: ['agnes-v1'], headers: { Origin: origin } },
    auth: { kind: 'local' }, journal: memoryJournal(), locale: 'zh-CN',
  });
  await client.initialize();
  return client;
}

if (process.argv.includes('--check')) {
  const client = await webClient();
  try {
    const page = await client.session.list({ limit: 2 });
    console.log(JSON.stringify({ connected: true, sessions: page.items.map(row => ({ sessionId: row.sessionId, cwd: row.cwd })) }));
  } finally { await client.close(); }
}
