// Explicit official plugin-admin activation; imports perform no side effects.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {readModelProtocol,readCandidate,adminClient,effect,saveNew,cliArgs} from './resolution_research_deployment_v1.mjs';

export async function enableScope(path,hash,dependencies={}){
 if(Object.keys(dependencies).length&&dependencies.fixture_only!==true)throw new Error('Explicit fixture brand required for injected admin dependencies');
 const loaded=await readModelProtocol(path,hash,dependencies),p=loaded.protocol,c=await readCandidate(loaded);
 if(c.fixture_only===true&&dependencies.fixture_only!==true)throw new Error('Fixture candidate cannot activate');
 const api=dependencies.api??adminClient('plugins'),trace={schema_version:1,status:'running',interface:'official plugin-admin BFF',
  package_id:c.package_id,candidate:c.candidate,model_protocol_path:loaded.path,model_protocol_sha256:hash,
  steps:[],complete:false,model_requests:0,gpu_tasks:0,credentials_read:false,fixture_only:dependencies.fixture_only===true};
 await saveNew(p.scope_activation_path,trace);const save=()=>writeFile(p.scope_activation_path,JSON.stringify(trace,null,2)+'\n');
 const recheck=async()=>{await readModelProtocol(path,hash,dependencies);await readCandidate(loaded);};
 try{
  const context=await api('context');if(context.readOnly||context.profile!=='local-dev'||!context.clientId)throw new Error('Writable local-dev official context required');
  const base={profile:context.profile,clientId:context.clientId};
  const before=await api('list',{profile:base.profile});if(!Array.isArray(before.packages)||before.packages.some(r=>r.id===c.package_id))throw new Error('Refuse replacement of existing scope');
  trace.before=before.packages;await save();
  const opts={operationRoute:'operation/get',success:'completed',...dependencies,recheck};
  const source={type:'file',ref:'file:./'+relative(loaded.root,c.candidate).replaceAll('\\','/')};
  const inspected=await effect(api,'inspect',{source},base,trace,save,opts),preview=inspected.preview??inspected.result?.preview;
  if(!preview||preview.id!==c.package_id||!Array.isArray(preview.blockers)||preview.blockers.length||
   preview.dependencies&&Object.keys(preview.dependencies).length||typeof preview.integrity!=='string'||typeof preview.capabilityHash!=='string')throw new Error('Blocked or dependent scope preview');
  trace.preview=preview;await save();
  await effect(api,'install',{source,expectedIntegrity:preview.integrity},base,trace,save,opts);
  await effect(api,'trust',{id:c.package_id,expectedIntegrity:preview.integrity,capabilityHash:preview.capabilityHash},base,trace,save,opts);
  await effect(api,'enable',{id:c.package_id,expectedInstalledIntegrity:preview.integrity,expectedActiveIntegrity:null},base,trace,save,opts);
  await recheck();const after=await api('list',{profile:base.profile});trace.after=after.packages.find(r=>r.id===c.package_id);
  const preserved=trace.before.every(row=>after.packages.some(other=>other.id===row.id&&other.actual===row.actual&&other.actualIntegrity===row.actualIntegrity&&other.trusted===row.trusted&&other.desired===row.desired&&other.revision===row.revision));
  trace.complete=preserved&&trace.after?.trusted===true&&trace.after?.actual==='running'&&trace.after?.actualIntegrity===preview.integrity;
  if(!trace.complete)throw new Error('Trusted inspected scope state or prior package preservation failed');trace.status='passed';
 }catch(error){trace.status='failed_preserved';trace.failure={type:error.name,message:error.message};}
 finally{trace.finished_at=new Date().toISOString();await save();}
 return trace;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const a=cliArgs(process.argv.slice(2)),r=await enableScope(a.path,a.hash);console.log(JSON.stringify({status:r.status,complete:r.complete,failure:r.failure}));if(!r.complete)process.exitCode=1;
}
