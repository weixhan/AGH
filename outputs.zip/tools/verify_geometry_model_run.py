"""Recheck a redacted official model ledger against saved geometry artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from defect_researcher.config import load_config
from defect_researcher.task_runtime import get_task_status


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summary_matches_disk(exported: dict | None, saved: dict | None, is_repair: bool) -> bool:
    """Align only the known workspace-prefix redaction of the verified copy path."""
    if not exported or not saved:
        return False
    if exported == saved:
        return True
    if not is_repair or not isinstance(saved.get("copy_root"), str):
        return False
    aligned = dict(saved)
    path = saved["copy_root"]
    for prefix in (str(ROOT), ROOT.as_posix()):
        if path.startswith(prefix + "\\") or path.startswith(prefix + "/"):
            aligned["copy_root"] = "<workspace>" + path[len(prefix):]
            return exported == aligned
    return False


def check_run(directory: Path, session_id: str, tool_name: str = "verify_label_geometry", configuration: dict | None = None) -> dict:
    if tool_name not in {"verify_label_geometry", "repair_label_copy"}:
        raise ValueError("Unsupported model task evidence contract")
    is_repair = tool_name == "repair_label_copy"
    ledger = directory / "session.jsonl"
    rows = [json.loads(line) for line in ledger.read_text(encoding="utf-8").splitlines() if line.strip()]
    result_rows = [row for row in rows if row["type"] == "tool/result"]
    results = {row["data"]["toolUseId"]: row for row in result_rows}
    calls = [row for row in rows if row["type"] == "tool/call"]
    mcp = [row for row in calls if row["data"]["name"].startswith("mcp_defect_researcher_")]
    starts = [row for row in mcp if row["data"]["name"].endswith("_" + tool_name)]
    polls = [row for row in mcp if row["data"]["name"].endswith("_get_task_status")]
    parsed = {}
    for call in mcp:
        result = results.get(call["data"]["toolUseId"])
        if result:
            blocks = result["data"].get("content", [])
            texts = [block["text"] for block in blocks if block.get("type") == "text"]
            if len(texts) == 1:
                parsed[call["seq"]] = json.loads(texts[0])
    start = starts[0] if len(starts) == 1 else None
    launch = parsed.get(start["seq"], {}) if start else {}
    task_id = launch.get("task_id")
    completed = [row for row in polls if parsed.get(row["seq"], {}).get("status") == "completed"]
    terminal = parsed.get(completed[-1]["seq"], {}) if completed else {}
    configuration = load_config() if configuration is None else configuration
    safe_id = isinstance(task_id, str) and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id))
    disk = get_task_status(configuration, task_id) if safe_id else {}
    approvals = [row for row in rows if row["type"] == "approval/decided"
                 and row["data"].get("verdict") == "allowed-once"
                 and start and start["data"]["name"] in row["data"].get("scope", "")]
    turn_ends = [row for row in rows if row["type"] == "turn/end"]
    inference = [row for row in rows if row["type"] == "cost/ledger"
                 and row["data"].get("purpose") == "inference"]
    check = {
        "continuous_ledger": [row["seq"] for row in rows] == list(range(1, len(rows) + 1)),
        "session_identity": bool(rows and rows[0]["type"] == "session/start"
                                 and rows[0]["data"].get("key") == session_id),
        "one_model_repair_start" if is_repair else "one_model_verification_start": bool(start and start.get("origin") == "model"
                                              and start["data"].get("args") == {}),
        "startup_returned_running": launch.get("status") == "running",
        "same_task_model_polls": bool(polls and all(row.get("origin") == "model"
                                    and row["data"].get("args") == {"task_id": task_id} for row in polls)),
        "unique_call_and_result_ids": len({row["data"]["toolUseId"] for row in calls}) == len(calls)
                                        and len(results) == len(result_rows),
        "mcp_results_paired": bool(mcp and all(row["data"]["toolUseId"] in results
                                    and results[row["data"]["toolUseId"]]["seq"] > row["seq"]
                                    and results[row["data"]["toolUseId"]].get("sourceEventSeqs") == [row["seq"]]
                                    and not results[row["data"]["toolUseId"]]["data"].get("isError")
                                    for row in mcp)),
        "polls_after_launch_result": bool(start and polls and start["data"]["toolUseId"] in results
                    and all(row["seq"] > results[start["data"]["toolUseId"]]["seq"] for row in polls)),
        "all_tool_results_match_task": bool(safe_id and len(parsed) == len(mcp)
                    and all(payload.get("task_id") == task_id for payload in parsed.values())),
        "only_requested_tools": len(calls) == len(mcp) == len(starts) + len(polls),
        "allowed_once_before_execution": bool(start and approvals and start["seq"] < approvals[0]["seq"]
                                                < results[start["data"]["toolUseId"]]["seq"]),
        "completed_repair_task" if is_repair else "completed_geometry_task": bool(completed and terminal.get("task_id") == task_id
                                          and terminal.get("tool") == tool_name),
        "saved_manifest_and_artifacts_verified": disk.get("status") == "completed"
                                                  and disk.get("tool") == tool_name,
        "tool_summary_matches_disk": summary_matches_disk(terminal.get("summary"), disk.get("summary"), is_repair),
        "repair_and_independent_verification_passed" if is_repair else "verification_passed":
            (disk.get("summary", {}).get("repair_status") == "passed" and
             disk.get("summary", {}).get("verification_status") == "passed") if is_repair
            else disk.get("summary", {}).get("verification_status") == "passed",
        "model_inference_http_200": bool(inference and all(row["data"].get("response", {}).get("status") == 200
                                             and row["data"].get("model") == "agnes-3.0-flash" for row in inference)),
        "model_turn_completed_after_result": bool(turn_ends and completed
                    and turn_ends[-1]["data"].get("reason") == "completed"
                    and turn_ends[-1]["seq"] > results[completed[-1]["data"]["toolUseId"]]["seq"]),
    }
    task_dir = None
    if safe_id:
        output_root = Path(configuration["output_root"]).resolve()
        candidate = output_root / task_id
        if candidate.resolve().parent == output_root and candidate.resolve().name == task_id and candidate.is_dir():
            task_dir = candidate
    check["task_artifact_scan_inside_configured_output"] = task_dir is not None
    paths = [ledger, directory / "session.html"]
    if task_dir:
        paths.extend(sorted(path for path in task_dir.iterdir() if path.is_file()))
        if is_repair:
            paths.extend(sorted(path for path in task_dir.rglob("*")
                                if path.is_file() and path.parent != task_dir
                                and path.suffix in {".json", ".jsonl", ".txt", ".yaml", ".html"}))
    scans = [{"name": path.name, "candidate_count": len(re.findall(rb"\bsk-[A-Za-z0-9._-]{12,}", path.read_bytes()))}
             for path in paths]
    check["no_credential_candidates_in_exports_and_outputs"] = all(item["candidate_count"] == 0 for item in scans)
    return {
        "schema_version": 1, "verification_kind": "official_model_label_repair_run_artifact_crosscheck" if is_repair
                                                  else "official_model_geometry_run_artifact_crosscheck",
        "status": "passed" if all(check.values()) else "failed",
        "session_id": session_id, "task_id": task_id, "model_used": True,
        "checks": check, "reasons": [name for name, passed in check.items() if not passed],
        "summary": disk.get("summary"), "model_request_count": len(inference),
        "summary_redaction_rule": "Only the official <workspace> prefix of copy_root is aligned; the verified relative path and all other summary fields must match exactly." if is_repair else None,
        "tool_calls": [{"seq": row["seq"], "name": row["data"]["name"], "origin": row.get("origin"),
                        "result_seq": results.get(row["data"]["toolUseId"], {}).get("seq"),
                        "status": parsed.get(row["seq"], {}).get("status")} for row in calls],
        "files": [{"path": str(path), "size_bytes": path.stat().st_size, "sha256": digest(path)} for path in paths],
        "secret_scan": scans,
        "limitations": disk.get("limitations", []),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("session_id")
    parser.add_argument("--tool", choices=("verify_label_geometry", "repair_label_copy"), default="verify_label_geometry")
    parser.add_argument("--config", help="Path configuration used by the recorded MCP service")
    args = parser.parse_args()
    result = check_run(args.directory.resolve(), args.session_id, args.tool,
                       load_config(args.config) if args.config else None)
    destination = args.directory / "model_run_verification.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "task_id": result["task_id"],
                      "checks_passed": sum(result["checks"].values()), "checks_total": len(result["checks"]),
                      "reasons": result["reasons"], "evidence": str(destination)}, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
