// Retire the failed trial guard using its official installed integrity.
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177';
const output=join(root,'outputs/agh-research-workflow-model-v3');
const id='@defect-researcher/research-workflow-scope-guard-v2';
const old=JSON.parse(await readFile(join(root,'outputs/research-mcp-model-verification-v2/verification.json'),'utf8'));
if(old.status!=='failed')throw new Error('Expected preserved failed independent verification');
const trace={schema_version:1,status:'running',package_id:id,model_requests:0,prior_failed_verification_preserved:true};
const path=join(output,'old-scope-retirement-continued.json');
await writeFile(path,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(path,JSON.stringify(trace,null,2)+'\n');
async function api(route,body){const r=await fetch(origin+'/admin/plugins/api/'+route,{method:body?'POST':'GET',
 headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 const result=await r.json();if(!r.ok)throw new Error(`${route}: ${r.status} ${JSON.stringify(result)}`);return result;}
try{
 const context=await api('context');if(context.readOnly||context.profile!=='local-dev')throw new Error('Wrong admin context');
 trace.before=(await api('list',{profile:context.profile})).packages.find(row=>row.id===id);
 if(!trace.before?.trusted||trace.before.desired!=='enabled'||trace.before.actual!=='running')throw new Error('Unexpected guard state');
 trace.receipt=await api('disable',{profile:context.profile,clientId:context.clientId,commandId:randomUUID(),id});await save();
 const deadline=Date.now()+60000;
 for(;;){trace.operation=await api('operation/get',{profile:context.profile,operationId:trace.receipt.operationId});await save();
  if(['completed','failed','cancelled','rolled-back'].includes(trace.operation.state))break;
  if(Date.now()>=deadline)throw new Error('Original disable operation deadline expired');await new Promise(done=>setTimeout(done,500));}
 trace.after=(await api('list',{profile:context.profile})).packages.find(row=>row.id===id);
 trace.checks={official_operation_completed:trace.operation.state==='completed',installed_disabled:trace.after.desired==='installed-disabled',
  not_running:trace.after.actual==='not-running',source_integrity_preserved:trace.before.integrity===trace.after.integrity};
 trace.status=Object.values(trace.checks).every(Boolean)?'passed':'failed';
}catch(error){trace.status='failed';trace.error={name:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,checks:trace.checks,error:trace.error}));}
if(trace.status!=='passed')process.exitCode=1;
