// Preparation is local filesystem work only; no AGH connection or activation.
import {readFile,mkdir,writeFile,copyFile,constants} from 'node:fs/promises';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {ROOT,readModelProtocol,scopeIdentity,saveNew,record,cliArgs} from './resolution_research_deployment_v1.mjs';

export async function prepareScope(path,hash,dependencies={}){
 if(Object.keys(dependencies).length&&dependencies.fixture_only!==true)throw new Error('Explicit fixture brand required for injected preparation dependencies');
 const loaded=await readModelProtocol(path,hash,dependencies),p=loaded.protocol,id=scopeIdentity(p.scope_policy.request_id);
 const candidate=join(p.scope_policy.workspace_root,'.agh/extensions',id.scopeName);
 await mkdir(dirname(candidate),{recursive:true});await mkdir(candidate,{recursive:false});
 await saveNew(join(candidate,'policy.json'),p.scope_policy);
 await copyFile(join(loaded.root,'tools/resolution_research_scope_guard_v1.mjs'),join(candidate,'guard.mjs'),constants.COPYFILE_EXCL);
 await writeFile(join(candidate,'index.mjs'),`import {applyResolutionResearchScope} from './guard.mjs';
const policy=${JSON.stringify(p.scope_policy)};
const owned=${JSON.stringify({deployment:p.deployment,source_lock:p.source_lock,domain_task_directory:p.domain_task_directory})};
export const resolutionResearchScope={inject:['extension'],apply(ctx){
 // One guard per worker extension; session_start/followUp never recreate it.
 return applyResolutionResearchScope(ctx,policy,owned);
}};
`,{flag:'wx'});
 await saveNew(join(candidate,'package.json'),{name:id.packageId,version:'0.1.0',private:true,license:'UNLICENSED',
  type:'module',exports:'./index.mjs',agnes:{plugins:[{export:'resolutionResearchScope',id:'ext:defect-researcher/'+id.scopeName,inject:['extension']}]}});
 const files=await Promise.all(['policy.json','guard.mjs','index.mjs','package.json'].map(async name=>({name,...await record(join(candidate,name))})));
 const result={schema_version:1,status:'prepared_not_activated',package_id:id.packageId,candidate,
  workspace:p.scope_policy.workspace_root,model_protocol_path:loaded.path,model_protocol_sha256:loaded.sha256,
  protocol_path:loaded.path,protocol_sha256:loaded.sha256,
  deployment:p.deployment,source_lock:p.source_lock,files,public_hooks:['session_start','before_request','before_step','tool_call','tool_result'],
  same_session_phase_not_reset:true,preflight_observation:'fixed registry/deployment/source pins before same-session followUp request; no model status debit',
  model_requests:0,gpu_tasks:0,credentials_read:false,fixture_only:dependencies.fixture_only===true};
 await saveNew(p.scope_candidate_path,result);return result;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const a=cliArgs(process.argv.slice(2)),r=await prepareScope(a.path,a.hash);console.log(JSON.stringify({status:r.status,candidate:r.candidate}));
}
