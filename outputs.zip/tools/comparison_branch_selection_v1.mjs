import {createHash} from 'node:crypto';
const stable=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
export function selectBranchDiagnostic(protocol,publicProtocol){
 const diagnostic=publicProtocol.engineering_diagnostic,selection=diagnostic?.selection;
 const hash=createHash('sha256').update(stable(selection)).digest('hex');
 if(!selection||Object.keys(selection).sort().join(',')!=='arm,case_ids,schema_version,trial_handles'||selection.schema_version!==1||selection.arm!=='F'||
  stable(selection.case_ids)!==stable(['repair_coordinates','refuse_source_hash'])||!Array.isArray(selection.trial_handles)||selection.trial_handles.length!==2||new Set(selection.trial_handles).size!==2||
  hash!==diagnostic.selection_sha256||diagnostic.selected_trial_count!==2||diagnostic.planned_comparison_trials!==9||protocol.trials?.length!==9)
  throw new Error('Branch diagnostic selection differs');
 const selected=protocol.trials.filter(row=>selection.trial_handles.includes(row.trial_handle));
 if(selected.length!==2||selected.some((row,index)=>row.arm!=='F'||row.case_id!==selection.case_ids[index]||row.trial_handle!==selection.trial_handles[index])||
  stable(publicProtocol.scope_policy.allowed_handles)!==stable(selection.trial_handles)||
  publicProtocol.phase_model_budget.total_cap!==48||publicProtocol.phase_model_budget.prior_versions_actual_requests!==27||publicProtocol.phase_model_budget.this_pilot_cap!==16||publicProtocol.phase_model_budget.phase_remaining_before_diagnostic!==21)
  throw new Error('Selected task or phase budget differs');
 return selected;
}
