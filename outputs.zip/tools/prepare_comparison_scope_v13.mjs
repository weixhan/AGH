import {readFile,writeFile,mkdir,copyFile,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve,join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createComparisonGuard} from './comparison_scope_guard_v13.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),protocolPath=resolve(process.argv[2]??'');
if(!protocolPath.startsWith(root+'\\')&&!protocolPath.startsWith(root+'/'))throw new Error('Project protocol required');
const bytes=await readFile(protocolPath),protocol=JSON.parse(bytes),out=dirname(protocolPath),policy=protocol.scope_policy;
createComparisonGuard(policy);
if(!['diagnostic','pilot','formal'].includes(protocol.stage))throw new Error('Invalid frozen stage');
const scopeName='comparison-scope-guard-v13-'+protocol.stage;
const candidate=join(policy.workspace_root,'.agh/extensions/'+scopeName);
const active=join(out,'active_trial.json');
await mkdir(dirname(candidate),{recursive:true});await mkdir(candidate,{recursive:false});
const saveNew=(p,text)=>writeFile(p,text,{flag:'wx'}),sha=b=>createHash('sha256').update(b).digest('hex');
await saveNew(join(candidate,'policy.json'),JSON.stringify(policy,null,2)+'\n');
await copyFile(join(root,'tools/comparison_scope_guard_v13.mjs'),join(candidate,'guard.mjs'),1);
await saveNew(join(candidate,'index.mjs'),`import {readFile} from 'node:fs/promises';
import {createComparisonGuard,normalizePath} from './guard.mjs';
export const comparisonScopeGuard={inject:['extension'],apply(ctx){
 const policy=${JSON.stringify(policy)},guard=createComparisonGuard(policy),agnes=ctx.extension();
 const scoped=h=>normalizePath(h?.session?.workspaceRoot)===normalizePath(policy.workspace_root);
 agnes.registerHook('session_start',async (_p,h)=>{if(scoped(h)&&h.replayed!==true)await agnes.events.append('scope-ready',{session_key:h.session.key,workspace_root:h.session.workspaceRoot,mode:'case-comparison-v1',policy});});
 agnes.registerHook('before_request',async(p,h)=>{
  if(!scoped(h))return {};
  let binding;try{binding=JSON.parse(await readFile(${JSON.stringify(active)},'utf8'));}catch{}
  const verdict=guard.before_request(p,h,binding);await agnes.events.append('scope-request-decision',{session_key:h.session.key,...verdict});
  if(verdict.allow!==true)throw new Error(verdict.reason);return {};
 });
 agnes.registerHook('before_step',(p,h)=>scoped(h)?guard.before_step(p,h):{});
 agnes.registerHook('tool_call',async(p,h)=>{if(!scoped(h))return {allow:true};const verdict=guard.tool_call(p,h);await agnes.events.append('scope-decision',{session_key:h.session.key,name:p.name,tool_use_id:p.toolUseId,...verdict});return verdict.allow===true?{allow:true}:{allow:false,reason:verdict.reason};});
}};
`);
await saveNew(join(candidate,'package.json'),JSON.stringify({name:'@defect-researcher/'+scopeName,version:'0.1.0',private:true,license:'Apache-2.0',type:'module',exports:'./index.mjs',agnes:{plugins:[{export:'comparisonScopeGuard',id:'ext:defect-researcher/'+scopeName,inject:['extension']}]}},null,2)+'\n');
const files=await Promise.all(['policy.json','guard.mjs','index.mjs','package.json'].map(async name=>{const p=join(candidate,name);return {name,path:p,sha256:sha(await readFile(p)),size_bytes:(await stat(p)).size};}));
await saveNew(join(out,'scope_candidate.json'),JSON.stringify({schema_version:1,status:'prepared_not_activated',package_id:'@defect-researcher/'+scopeName,candidate,workspace:policy.workspace_root,protocol_path:protocolPath,protocol_sha256:sha(bytes),files,active_trial_binding_path:active,model_called:false,credentials_read:false},null,2)+'\n');
console.log(JSON.stringify({status:'prepared_not_activated',candidate}));
