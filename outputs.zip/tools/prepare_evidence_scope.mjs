// Prepare an immutable, project-local hook candidate; this does not activate or run it.
import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const output = join(root, 'outputs', 'agh-scoped-evidence');
const workspace = join(output, 'workspace');
const candidate = join(workspace, '.agh', 'extensions', 'evidence-scope-guard');
const task = '8d1d6900c7d74c90a29824495684807d';
const policy = { schema_version: 1, workspace_root: workspace,
  task_id: task, qualified_status_tool: 'mcp_defect_researcher_45e5cef9_get_task_status', max_status_calls: 1 };
await mkdir(candidate, { recursive: true });
const saveNew = (path, value) => writeFile(path, value, { flag: 'wx', mode: 0o600 });
await saveNew(join(candidate, 'policy.json'), JSON.stringify(policy, null, 2) + '\n');
await copyFile(join(root, 'tools', 'evidence_scope_guard.mjs'), join(candidate, 'guard.mjs'), 1);
const diagnosisWorkspace = join(root, 'outputs', 'agh-diagnosis-model', 'workspace');
const diagnosisPolicy = { schema_version: 1, workspace_root: diagnosisWorkspace,
  qualified_start_tool: 'mcp_defect_researcher_45e5cef9_diagnose_validation_errors',
  qualified_status_tool: policy.qualified_status_tool, max_status_calls: 20 };
await mkdir(diagnosisWorkspace, { recursive: true });
const entry = `import { createEvidenceScopeGuard, createDiagnosticScopeGuard, normalizeScopePath } from './guard.mjs';\n` +
  `export const evidenceScopeGuard = {\n  inject: ['extension'],\n  apply(ctx) {\n` +
  `    const policy = ${JSON.stringify(policy)};\n` +
  `    const diagnosisPolicy = ${JSON.stringify(diagnosisPolicy)};\n` +
  `    const guard = createEvidenceScopeGuard(policy);\n` +
  `    const diagnosis = createDiagnosticScopeGuard(diagnosisPolicy);\n` +
  `    const agnes = ctx.extension();\n` +
  `    const mode = hctx => normalizeScopePath(hctx?.session?.workspaceRoot) === normalizeScopePath(policy.workspace_root) ? 'evidence' : normalizeScopePath(hctx?.session?.workspaceRoot) === normalizeScopePath(diagnosisPolicy.workspace_root) ? 'diagnosis' : null;\n` +
  `    agnes.registerHook('session_start', async (_payload, hctx) => {\n` +
  `      if (mode(hctx)) await agnes.events.append('scope-ready', { session_key: hctx.session.key, workspace_root: hctx.session.workspaceRoot, mode: mode(hctx), policy: mode(hctx) === 'evidence' ? policy : diagnosisPolicy });\n    });\n` +
  `    agnes.registerHook('tool_call', async (payload, hctx) => {\n` +
  `      const scoped = mode(hctx);\n      if (!scoped) return { allow: true };\n` +
  `      const verdict = scoped === 'evidence' ? guard(payload, hctx) : diagnosis.tool_call(payload, hctx);\n` +
  `      await agnes.events.append('scope-decision', { session_key: hctx.session.key, name: payload.name, tool_use_id: payload.toolUseId, allow: verdict.allow, reason: verdict.reason ?? null });\n` +
  `      return verdict;\n    });\n` +
  `    agnes.registerHook('tool_result', (payload, hctx) => mode(hctx) === 'diagnosis' ? diagnosis.tool_result(payload, hctx) : {});\n  },\n};\n`;
await saveNew(join(candidate, 'index.mjs'), entry);
await saveNew(join(candidate, 'package.json'), JSON.stringify({ name: '@defect-researcher/evidence-scope-guard',
  version: '0.1.1', private: true, license: 'Apache-2.0', type: 'module', exports: './index.mjs',
  agnes: { plugins: [{ export: 'evidenceScopeGuard', id: 'ext:defect-researcher/evidence-scope-guard',
    inject: ['extension'] }] } }, null, 2) + '\n');
const sourceFiles = [
  'packages/sdk/src/client.ts', 'packages/sdk/src/session.ts',
  'packages/extension-api/src/plugin-extension.ts', 'packages/extension-api/src/hooks.ts',
  'packages/core/src/step/inference.ts', 'packages/core/src/step/tools.ts',
  'packages/package-manager/src/workspace.ts', 'packages/package-manager/src/manager.ts',
  'packages/host/src/profile/inputs.ts', 'packages/host/src/profile/resolve.ts',
  'packages/base/extensions/hooks-runner/src/index.ts',
];
const sourceHashes = {};
for (const relative of sourceFiles) {
  const bytes = await readFile(join(root, '..', 'agnes-harness', relative));
  sourceHashes[relative] = createHash('sha256').update(bytes).digest('hex');
}
const previous = JSON.parse(await readFile(join(root, 'outputs', 'agh-resolution-comparison',
  'model_run_verification.json'), 'utf8'));
const report = { schema_version: 1, observed_at: new Date().toISOString(),
  status: 'prepared_not_activated', candidate, workspace, policy,
  diagnosis_workspace: diagnosisWorkspace, diagnosis_policy: diagnosisPolicy,
  target_model: 'agnes-3.0-flash', target_route: 'account-defect-researcher',
  public_interface_findings: { sdk_session_tool_allowlist: false,
    sdk_session_local_extension_load: false, mcp_allowlist_controls_native_tools: false,
    public_execution_hook: 'ctx.extension().registerHook(tool_call, handler)',
    execution_hook_gate: 'Core returns HOOK_DENIED before approval and execute',
    workspace_deploy_requires_profile_lock_trust: true,
    windows_command_hook_requires_process_enforcement_or_profile_trust: true },
  model_called: false, model_session_created: false, global_home_modified: false,
  agh_core_modified: false, credentials_read: false, training_or_inference_started: false,
  strict_tool_scope_passed: false, execution_guard_live_verified: false,
  old_resolution_verification: { status: previous.status,
    strict_tool_scope_passed: previous.strict_tool_scope_passed },
  reason: 'The current public SDK has no session-local extension admission API. Ordinary plugin activation writes the managed profile inventory; workspace deployment requires profile-lock trust. Those global changes are outside this isolated-helper scope. No unguarded model prompt was sent.',
  limitations: ['Candidate validation and synthetic Core interception are separate from live Host activation.',
    'Execution gating does not remove tools from the model-visible catalog.',
    'The one-call budget is held in memory for one plugin activation, not persisted across Host reload.',
    'Reading completed evidence would not repeat or repair the original full comparison session acceptance.'],
  source_sha256: sourceHashes };
await saveNew(join(output, 'preflight.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ status: report.status, model_called: false, output, candidate }));
if (process.argv.includes('--run')) {
  console.error('Refusing a model turn: session-local guard activation is unavailable through this public SDK.');
  process.exitCode = 2;
}
