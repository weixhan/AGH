"""Preserve a failed pre-session launch, without accepting or restarting a case."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / 'outputs/comparison-pilot-v10'
OUT = ROOT / 'outputs/comparison-implementation-v10'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(rows):
        out = {}
        for key, value in rows:
            if key in out:
                raise ValueError('Duplicate JSON key')
            out[key] = value
        return out
    return json.loads(Path(path).read_text('utf8'), object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))


def record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def check(rows):
    for row in rows:
        path = Path(row['path'])
        if sha(path) != row['sha256'] or path.stat().st_size != row['size_bytes']:
            raise ValueError('Protected source or size changed: ' + str(path))


def save(path, value):
    with path.open('x', encoding='utf8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    suite = read(PILOT / 'run_result.json')
    public = read(PILOT / 'model_protocol.json')
    stage = read(PILOT / 'stage_ledger.json')
    from tools.verify_comparison_model_v10 import validate_stage_ledger
    validate_stage_ledger(stage)
    lock = public['source_lock']
    if sha(lock['path']) != lock['sha256']:
        raise ValueError('Source lock changed')
    sources = read(lock['path'])['files']
    check(sources)
    for item in stage['protected_history']:
        check([item['freeze']])
        history = read(item['freeze']['path'])
        for key in ('sources', 'archive', 'proof_files', 'preserved_files'):
            check(history.get(key, []))
    if not (suite['status'] == 'stopped' and suite['trials'] == []
            and suite['model_requests_actual'] == suite['model_requests_observed'] == 0
            and 'Get-FileHash' in suite['failure']['message']):
        raise ValueError('Not the observed pre-session PowerShell setup failure')
    protocol = read(PILOT / 'protocol.json')
    if len(protocol['trials']) != 9:
        raise ValueError('Original registration changed')
    runner = (ROOT / 'tools/run_comparison_pilot_v10.mjs').read_text('utf8')
    body = runner[runner.index('async function modeled(trial){'):]
    if not body.index('const processBefore=await captureRuntime();') < body.index('const record=') < body.index('session=await client.session.new('):
        raise ValueError('Source does not prove capture precedes session creation')
    attempts = []
    for trial in protocol['trials']:
        handle = trial['trial_handle']
        directory = PILOT / 'runtime/trials' / handle
        if any((directory / name).exists() for name in ('arm.json', 'arm_binding.json', 'actions.jsonl', 'budget.jsonl', 'completion.json')):
            raise ValueError('A case execution began; this preservation route is forbidden')
        for kind in ('model_runs', 'script_runs'):
            execution = PILOT / kind / handle
            if execution.exists():
                if any(path.is_file() for path in execution.rglob('*')):
                    raise ValueError('Execution evidence exists; cost must independently close')
                attempts.append({'trial_handle': handle, 'directory': str(execution),
                                 'status': 'preexecution_attempt_failed_empty_directory_preserved'})
    if len(attempts) != 1 or attempts[0]['trial_handle'] != public['engineering_diagnostic']['selection']['trial_handles'][0]:
        raise ValueError('Unexpected preexecution attempts')
    supplement = {'schema_version': 1, 'status': 'passed_preservation_only_not_acceptance',
        'checked_at': datetime.now(timezone.utc).isoformat(), 'original_driver_status': 'stopped',
        'original_failure': suite['failure'], 'all_nine_unarmed': True,
        'preexecution_attempts': attempts, 'no_session_or_model_request_started': True,
        'no_original_session_resume': True, 'model_requests_this_diagnostic_actual': 0,
        'new_stage_cap': 14, 'historical_prior_stage': stage['historical_prior_stage'],
        'selected_joint_correct_count': 0, 'diagnostic_acceptance_status': 'failed',
        'strict_original_closer_refusal': 'Unreported selected execution exists',
        'original_closer_not_overridden': True,
        'scope': 'Read-only preservation of launch failure; no case accepted or deadline reset'}
    save(PILOT / 'setup_failure_preservation.json', supplement)
    sources = sources + [record(Path(__file__)), record(PILOT / 'setup_failure_preservation.json')]
    archive = []
    for row in sources:
        target = OUT / 'source' / Path(row['path']).relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            raise FileExistsError('Archive already exists')
        shutil.copyfile(row['path'], target)
        archive.append(record(target))
    proofs = [record(path) for path in sorted(PILOT.rglob('*')) if path.is_file()]
    frozen = {'schema_version': 1, 'status': 'failed_setup_preserved', 'source_lock': lock,
        'sources': sources, 'archive': archive, 'proof_files': proofs,
        'protected_history': stage['protected_history'], 'original_driver_status': 'stopped',
        'selected_joint_correct_count': 0, 'all_nine_unarmed': True,
        'model_requests_this_diagnostic_actual': 0, 'old_stage_cap': 48,
        'old_request_slots_debited': 46, 'legacy_actual_usage': None,
        'no_original_session_resume': True, 'new_detector_calls': 0, 'gpu_seconds': 0}
    save(OUT / 'freeze.json', frozen)
    check(sources + archive + proofs)
    closure = {**supplement, 'freeze': record(OUT / 'freeze.json'),
               'new_records_checked': len(sources) + len(archive) + len(proofs)}
    save(PILOT / 'final_closure_verification.json', closure)
    print(json.dumps({'status': closure['status'], 'freeze': closure['freeze'],
                      'model_requests_actual': 0, 'joint_correct': 0}))


if __name__ == '__main__':
    main()
