import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {validateMethod} from '../../agnes-harness/packages/protocol/src/methods.ts';
const old='x/host/session-title-diagnostics',fixed='x/host/session-title/diagnostics';
const event={seq:49,ts:'2026-10-13T17:23:44.310Z',id:'01M4V4N9HNBK3V31C7Z9FM45CB',
 type:old,data:{schemaVersion:1,sourceTurn:1,effectId:'title:fixture',providerSent:true,
 responseSeen:true,usageObserved:true},actor:{id:'fixture',org:'local',role:'owner',deptPath:[],attrs:{}},
 origin:'system',trust:'trusted',lane:'main',v:1,ignorable:true};
test('the original title diagnostic cannot cross the official replay endpoint',()=>{
 const verdict=validateMethod('_agnes/v1/session.event','params',{sessionId:'fixture',event});
 assert.equal(verdict.ok,false);assert(verdict.errors.some(x=>x.path==='/event/type'));
});
test('the three-component diagnostic name crosses the same unchanged endpoint',()=>{
 const verdict=validateMethod('_agnes/v1/session.event','params',{sessionId:'fixture',event:{...event,type:fixed}});
 assert.equal(verdict.ok,true);
});
test('side-by-side bundles differ only in the registered two bytes',async()=>{
 const receipt=JSON.parse(await readFile('outputs/agh-title-repair-v2/transform_receipt.json','utf8'));
 let changed=0;
 for(const row of receipt.transforms){
  const a=await readFile(row.before.path),b=await readFile(row.after.path);
  assert.equal(a.length,b.length);assert.equal(createHash('sha256').update(a).digest('hex'),row.before.sha256);
  assert.equal(createHash('sha256').update(b).digest('hex'),row.after.sha256);
  assert.equal(a.toString().split(old).length-1,row.old_occurrences);
  assert.deepEqual(b,Buffer.from(a.toString().replaceAll(old,fixed)));
  changed+=row.byte_differences;
 }
 assert.equal(changed,2);
});
