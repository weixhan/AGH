// Local CPU fixtures and mocked official admin only. No real HTTP/AGH/model.
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,mkdir,writeFile,readFile,rm} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {ROOT,sha,record,MODEL_KEYS,readModelProtocol,adminClient,scopeIdentity} from './resolution_research_deployment_v1.mjs';
import {prepareScope} from './prepare_resolution_research_scope_v1.mjs';
import {enableScope} from './enable_resolution_research_scope_v1.mjs';
import {activateMCP,serverDefinition} from './activate_resolution_research_mcp_v1.mjs';
import {ACTION_TOOL,READ_TOOL,applyResolutionResearchScope} from './resolution_research_scope_guard_v1.mjs';
import {tsImport} from '../../agnes-harness/node_modules/tsx/dist/esm/api/index.mjs';

const save=(path,value)=>writeFile(path,JSON.stringify(value,null,2)+'\n');
const contract=JSON.parse(await readFile(join(ROOT,'fixtures/resolution_research_mcp_protocol_v1.json'),'utf8'));
async function fixture(){
 await mkdir(join(ROOT,'.runtime/test-tmp'),{recursive:true});
 const root=await mkdtemp(join(ROOT,'.runtime/test-tmp/science-deploy-'));
 const output=join(root,'outputs/fresh');await mkdir(join(output,'workspace'),{recursive:true});
 const runner=join(root,'runner.mjs'),prompt=join(root,'prompt.md');await writeFile(runner,'fixture runner');await writeFile(prompt,'fixture prompt');
 const shell=join(root,'pwsh.exe'),python=join(root,'python.exe');await writeFile(shell,'never run');await writeFile(python,'never run');
 await mkdir(join(root,'tools'));await writeFile(join(root,'tools/resolution_research_scope_guard_v1.mjs'),await readFile(join(ROOT,'tools/resolution_research_scope_guard_v1.mjs')));
 const sources=await Promise.all([runner,prompt,join(root,'tools/resolution_research_scope_guard_v1.mjs')].map(record));
 const lock=join(output,'source_lock.json');await save(lock,{kind:'resolution_research_mcp_source_lock_v1',status:'fixture_only',fixture_only:true,files:sources});
 const runtime=join(root,'runtime.json');await save(runtime,{status:'passed_local_repair',repair_version:2});
 const start=Date.now()-10;
 const policy={schema_version:1,workspace_root:join(output,'workspace'),request_id:'fixed',task_id:'resolution-research-v1-fixed',
  started_epoch_ms:start,deadline_epoch_ms:start+2400000,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,
  max_model_requests:14,max_primary_requests:13,max_native_title_requests:1};
 const deployment=join(output,'deployment_protocol.json');await save(deployment,{schema_version:1,kind:'resolution_research_mcp_deployment_v1',
  request_id:'fixed',task_id:policy.task_id,workspace_root:policy.workspace_root,started_epoch:start/1000,started_monotonic:1,
  deadline_epoch:start/1000+2400,deadline_monotonic:2401,contract_sha256:'f'.repeat(64)});
 const pin=async path=>({path,sha256:sha(await readFile(path))});
 const p={schema_version:1,kind:'resolution_research_model_protocol_v1',deployment:await pin(deployment),source_lock:await pin(lock),
  runtime_version:await pin(runtime),runner_source:await pin(runner),task_prompt:await pin(prompt),scope_policy:policy,
  scope_candidate_path:join(output,'scope_candidate.json'),scope_activation_path:join(output,'scope_activation.json'),
  mcp_activation_path:join(output,'mcp_activation.json'),python_executable:python,powershell_executable:shell,
  model:'agnes-3.0-flash',route:'account-defect-researcher',server_id:'dr-science-v1',domain_task_directory:join(root,'domain',policy.task_id),output_directory:output};
 const path=join(output,'model_protocol.json');await save(path,p);
 return{root,output,p,path,hash:sha(await readFile(path)),deps:{root,fixture_only:true},cleanup:()=>rm(root,{recursive:true,force:true})};
}
async function withFixture(fn){const f=await fixture();try{return await fn(f);}finally{await f.cleanup();}}
const identity={status:'passed',connections:0,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL};

function pluginAPI(packageId,{existing=false,fail=null}={}){
 const calls=[],operations=new Map();let installed=false;
 const old={id:'old',actual:'running',actualIntegrity:'oldhash',trusted:true};
 const api=async(route,body)=>{
  calls.push({route,body});
  if(route==='context')return{readOnly:false,profile:'local-dev',clientId:'fixture'};
  if(route==='list')return{packages:[old,...(installed||existing?[{id:packageId,trusted:true,actual:'running',actualIntegrity:'pinned'}]:[])]};
  if(route==='operation/get')return operations.get(body.operationId);
  const id='op'+calls.length;operations.set(id,{state:route===fail?'failed':'completed',...(route==='inspect'?{preview:{id:packageId,blockers:[],dependencies:{},integrity:'pinned',capabilityHash:'cap'}}:{})});
  if(route==='enable')installed=true;return{operationId:id};
 };return{api,calls};
}
function resourceAPI(p,{existing=false,badEnum=false}={}){
 const calls=[],operations=new Map(),old={revision:'old',definition:{serverId:'legacy'},trust:'trusted',desired:'enabled',actual:'ready'};
 const row={revision:'new',definition:serverDefinition(p),trust:'trusted',desired:'enabled',actual:'ready'};
 const api=async(route,body)=>{
  calls.push({route,body});
  if(route==='context')return{readOnly:false,profile:'local-dev',clientId:'fixture'};
  if(route==='mcp/list')return{items:[{serverId:'legacy'},...(existing?[{serverId:p.server_id}]:[])]};
  if(route==='mcp/get')return body.serverId==='legacy'?old:row;
  if(route==='mcp/status')return{toolCount:2};
  if(route==='mcp/tools')return{items:['research_action_v1','research_read_v1'].map(name=>({name,inputSchema:{type:'object',properties:{request_id:{type:'string',enum:[badEnum?'other':p.scope_policy.request_id]},
   action:{type:'string',enum:[...(name==='research_action_v1'?contract.action_enums:contract.read_enums)].sort()}},required:['request_id','action'],additionalProperties:false}}))};
  if(route==='operations/get')return operations.get(body.operationId);
  const id='op'+calls.length;operations.set(id,{state:'succeeded'});return{operationId:id};
 };return{api,calls};
}

test('exact 18-key host protocol and explicit fixture source lock cannot be production-activated',()=>withFixture(async f=>{
 assert.deepEqual(Object.keys(f.p).sort(),[...MODEL_KEYS].sort());
 assert.equal((await readModelProtocol(f.path,f.hash,f.deps)).deployment.task_id,'resolution-research-v1-fixed');
 await assert.rejects(()=>readModelProtocol(f.path,f.hash,{root:f.root}),/engineering-only/);
 await assert.rejects(()=>readModelProtocol(f.path,'0'.repeat(64),f.deps),/pin changed/);
}));
test('source drift, broadened protocol, shifted anchor and escaped receipt paths fail before activation',()=>withFixture(async f=>{
 for(const change of [{extra:true},{scope_activation_path:join(f.root,'outside.json')},{scope_policy:{...f.p.scope_policy,started_epoch_ms:f.p.scope_policy.started_epoch_ms+1,deadline_epoch_ms:f.p.scope_policy.deadline_epoch_ms+1}}]){
  await save(f.path,{...f.p,...change});const currentHash=await shaBuffer(f.path);await assert.rejects(()=>readModelProtocol(f.path,currentHash,f.deps));
 }
 await save(f.path,f.p);await writeFile(f.p.task_prompt.path,'changed');await assert.rejects(()=>readModelProtocol(f.path,f.hash,f.deps),/Source bytes/);
}));
async function shaBuffer(path){return sha(await readFile(path));}
test('prepared package contains actual tool_result hook, one persistent guard and no automatic activation',()=>withFixture(async f=>{
 const r=await prepareScope(f.path,f.hash,f.deps);assert.equal(r.status,'prepared_not_activated');assert.equal(r.model_requests,0);
 assert.ok(r.public_hooks.includes('tool_result'));assert.ok((await readFile(join(r.candidate,'index.mjs'),'utf8')).includes('applyResolutionResearchScope'));
 await assert.rejects(()=>prepareScope(f.path,f.hash,f.deps));
 assert.equal(await exists(f.p.scope_activation_path),false);assert.equal(await exists(f.p.mcp_activation_path),false);
 const pkg=JSON.parse(await readFile(join(r.candidate,'package.json'),'utf8'));assert.equal(pkg.license,'UNLICENSED');
}));
async function exists(path){try{await readFile(path);return true;}catch(e){if(e.code==='ENOENT')return false;throw e;}}
test('official plugin operation mock follows inspect/install/trust/enable and preserves failures',()=>withFixture(async f=>{
 const c=await prepareScope(f.path,f.hash,f.deps),mock=pluginAPI(c.package_id);
 const result=await enableScope(f.path,f.hash,{...f.deps,...mock});assert.equal(result.complete,true);assert.equal(result.fixture_only,true);
 assert.deepEqual(result.steps.map(s=>s.route),['inspect','install','trust','enable']);
 await assert.rejects(()=>enableScope(f.path,f.hash,{...f.deps,...mock}),/EEXIST/);
}));
test('existing plugin refusal performs no plugin mutation',()=>withFixture(async f=>{
 const c=await prepareScope(f.path,f.hash,f.deps),mock=pluginAPI(c.package_id,{existing:true});
 const r=await enableScope(f.path,f.hash,{...f.deps,...mock});assert.equal(r.status,'failed_preserved');assert.equal(r.steps.length,0);
}));
test('official MCP mock requires active exact scope and registers fixed no-secret two-tool definition',()=>withFixture(async f=>{
 const c=await prepareScope(f.path,f.hash,f.deps);await enableScope(f.path,f.hash,{...f.deps,...pluginAPI(c.package_id)});
 const mock=resourceAPI(f.p),r=await activateMCP(f.path,f.hash,{...f.deps,...mock,checkIdentity:async()=>identity});
 assert.equal(r.status,'passed');assert.equal(r.domain_clock_started,false);assert.equal(r.model_requests,0);
 assert.deepEqual(r.steps.map(s=>s.route),['mcp/create','mcp/trust','mcp/enable','mcp/test']);
 assert.deepEqual(r.definition.secretBinding,{kind:'none'});assert.equal(r.definition.transport.executable,f.p.python_executable);
 assert.ok(r.definition.transport.args.includes(f.p.deployment.sha256));assert.deepEqual(r.definition.toolPolicy.allow,['research_action_v1','research_read_v1']);
}));
test('MCP existing server refusal preserves a failed receipt with no mutation',()=>withFixture(async f=>{
 const c=await prepareScope(f.path,f.hash,f.deps);await enableScope(f.path,f.hash,{...f.deps,...pluginAPI(c.package_id)});
 const mock=resourceAPI(f.p,{existing:true}),r=await activateMCP(f.path,f.hash,{...f.deps,...mock,checkIdentity:async()=>identity});
 assert.equal(r.status,'failed_preserved');assert.equal(r.steps.length,0);
}));
test('mismatched frozen request enum cannot pass native two-tool acceptance',()=>withFixture(async f=>{
 const c=await prepareScope(f.path,f.hash,f.deps);await enableScope(f.path,f.hash,{...f.deps,...pluginAPI(c.package_id)});
 const r=await activateMCP(f.path,f.hash,{...f.deps,...resourceAPI(f.p,{badEnum:true}),checkIdentity:async()=>identity});
 assert.equal(r.status,'failed_preserved');assert.equal(r.checks.two_exact_tools,false);
}));
test('unbranded dependency injection cannot mint production activation receipts',()=>withFixture(async f=>{
 for(const fn of [prepareScope,enableScope,activateMCP])await assert.rejects(()=>fn(f.path,f.hash,{api:async()=>({})}),/fixture brand/);
}));
test('official admin transport is hard-bound loopback with no credentials or foreign host',async()=>{
 const seen=[];const api=adminClient('resources',{fetchImpl:async(url,opts)=>{seen.push({url,opts});return{ok:true,json:async()=>({readOnly:true})};}});
 await api('context');assert.equal(seen[0].url,'http://127.0.0.1:4177/admin/resources/api/context');
 assert.equal(seen[0].opts.headers.Origin,'http://127.0.0.1:4177');assert.equal(seen[0].opts.headers.Authorization,undefined);
 assert.throws(()=>adminClient('external'));
});
test('real public tool_result payload advances same-session phase across a new turn without resetting budget',async()=>{
 const {validateHook}=await tsImport('../../agnes-harness/packages/protocol/src/index.ts',import.meta.url);
 const hooks=new Map(),events=[],start=Date.now()-10,policy={schema_version:1,workspace_root:'E:/fixed/workspace',request_id:'fixed',task_id:'resolution-research-v1-fixed',
  started_epoch_ms:start,deadline_epoch_ms:start+2400000,qualified_action_tool:ACTION_TOOL,qualified_read_tool:READ_TOOL,max_model_requests:14,max_primary_requests:13,max_native_title_requests:1};
 const context={session:{key:'same',workspaceRoot:policy.workspace_root},replayed:false};
 const guard=applyResolutionResearchScope({extension:()=>({registerHook:(name,fn)=>hooks.set(name,fn),events:{append:async(kind,payload)=>events.push({kind,payload})}})},policy);
 const request={slot:'primary',model:'agnes-3.0-flash',attempt:1,request:{model:'agnes-3.0-flash',slot:'primary',messageCount:1,toolNames:[ACTION_TOOL,READ_TOOL],samplingParams:{}}};
 assert.equal(validateHook('before_request','payload',request).ok,true);await hooks.get('before_request')(request,context);
 const call=async(action,id=action,name=ACTION_TOOL)=>{const verdict=await hooks.get('tool_call')({name,toolUseId:id,args:{request_id:'fixed',action}},context);assert.equal(validateHook('tool_call','return',verdict).ok,true);return verdict;};
 const result=async(action,status,extra={},id=action,name=ACTION_TOOL)=>{
  const enforcement={level:'full',scope:['file']},payload={toolUseId:id,name,args:{request_id:'fixed',action},enforcement,
   result:{toolUseId:id,content:[{type:'text',text:JSON.stringify({request_id:'fixed',task_id:policy.task_id,fixture_only:false,status,...extra})}],isError:false,enforcement,authz:{decisionId:'once'}}};
  assert.equal(validateHook('tool_result','payload',payload).ok,true);const ret=await hooks.get('tool_result')(payload,context);
  assert.equal(validateHook('tool_result','return',ret).ok,true);
 };
 assert.equal((await call('audit_geometry')).allow,true);await result('audit_geometry','preflight_passed');
 await call('register_hypothesis');await result('register_hypothesis','hypothesis_registered');await call('start_registered_experiment');await result('start_registered_experiment','running');
 await hooks.get('session_start')({},context);await hooks.get('before_request')(request,context); // actual followUp stays in same session/extension
 assert.equal(guard.snapshot().phase,'initial_running');assert.equal(guard.snapshot().primary_requests,2);
 assert.equal((await call('resume_registered_failure')).allow,false);
 assert.equal((await call('status','fault',READ_TOOL)).allow,true);await result('status','recovery_pending',{actual_failure:{closed_cost:true}},'fault',READ_TOOL);
 assert.equal((await call('resume_registered_failure')).allow,true);
 await assert.rejects(()=>hooks.get('before_request')(request,{...context,session:{...context.session,key:'replacement'}}));
 assert.equal(guard.snapshot().session_key,'same');assert.equal(guard.snapshot().primary_requests,2);
});
