"""Freeze accepted diagnostic sources and evidence without changing executions."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT/'outputs/comparison-pilot-v6'
OUT = ROOT/'outputs/comparison-implementation-v6'


def read(path):
    return json.loads(Path(path).read_text('utf8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha(path), 'size_bytes': path.stat().st_size}


def assert_members(rows):
    for row in rows:
        if sha(row['path']) != row['sha256']:
            raise ValueError('Protected file changed: '+row['path'])


def main():
    acceptance = read(PILOT/'verification.json')
    if acceptance['status'] != 'passed_engineering_diagnostic':
        raise ValueError('Diagnostic is not accepted')
    history = []
    for name, groups in [('research-workflow-implementation-v1/freeze.json', ['sources', 'archive', 'preserved_files']),
                         ('research-mcp-implementation-v2/freeze.json', ['sources', 'archive', 'proof_files'])]:
        path = ROOT/'outputs'/name
        value = read(path)
        rows = [row for group in groups for row in value[group]]
        assert_members(rows)
        history.append({'inventory': record(path), 'checked_records': len(rows), 'unchanged': True})
    previous = ROOT/'outputs/agh-research-workflow-model-v3/previous_state.json'
    previous_rows = read(previous)['files']
    assert_members(previous_rows)
    history.append({'inventory': record(previous), 'checked_records': len(previous_rows), 'unchanged': True, 'overlap_not_added_to_other_populations': True})
    earlier_pins = []
    for version in range(1, 6):
        path = ROOT/f'outputs/comparison-implementation-v{version}/source_lock.json'
        rows = read(path)['files']
        assert_members(rows)
        earlier_pins.append({'source_lock': record(path), 'checked_records': len(rows), 'unchanged': True})
    pin = OUT/'source_lock.json'
    sources = read(pin)['files']
    assert_members(sources)
    sources += [record(ROOT/name) for name in ['tools/summarize_comparison_diagnostic_v1.py', 'tools/close_comparison_diagnostic_v1.py', 'tools/reconcile_comparison_titles_v2.mjs', 'tools/retire_comparison_mcp_v5.mjs']]
    archive_root = OUT/'source'
    archive_root.mkdir()
    archive = []
    for index, source in enumerate(sources):
        target = archive_root/f'{index:03d}_{Path(source["path"]).name}'
        shutil.copyfile(source['path'], target)
        archived = record(target)
        if archived['sha256'] != source['sha256']:
            raise ValueError('Archive differs')
        archive.append({**archived, 'source_path': source['path']})
    candidate = read(PILOT/'scope_candidate.json')
    assert_members(candidate['files'])
    proofs = set()
    for directory in [PILOT, ROOT/'outputs/comparison-pilot-v5', ROOT/'outputs/comparison-native-title-reconciliation-v1', ROOT/'outputs/comparison-native-title-reconciliation-v2']:
        for path in directory.rglob('*'):
            if path.is_file() and 'workspace' not in path.relative_to(directory).parts and '__pycache__' not in path.parts:
                proofs.add(path.resolve())
    for version in range(1, 5):
        directory = ROOT/f'outputs/comparison-pilot-v{version}'
        proofs.update(path.resolve() for path in directory.rglob('*') if path.is_file() and 'workspace' not in path.relative_to(directory).parts)
    proofs.update(Path(row['path']).resolve() for row in candidate['files'])
    proofs.update(path.resolve() for path in OUT.glob('*.json'))
    proofs.add((ROOT/'outputs/comparison-runtime-local-acceptance-v1/runtime-tests.json').resolve())
    services = {row['serverId']: row for row in read(PILOT/'live_service_status.json')['rows']}
    if not all(services[name]['actual'] == 'ready' and services[name]['toolCount'] == count
               for name, count in [('defect-researcher', 7), ('dr-workflow-v1', 2), ('dr-compare-v6', 1)]):
        raise ValueError('Expected live services absent')
    if services['dr-compare-v5']['actual'] != 'disabled':
        raise ValueError('Failed deployment not retired')
    frozen = {'schema_version': 1, 'status': 'passed_engineering_diagnostic_frozen',
              'checked_at': datetime.now(timezone.utc).isoformat(),
              'scope': acceptance['scope'], 'source_lock': record(pin),
              'sources': sources, 'archive': archive,
              'proof_files': [record(path) for path in sorted(proofs)],
              'protected_history': history, 'earlier_comparison_source_pins': earlier_pins,
              'models_this_closure': 0, 'new_detector_calls': 0, 'gpu_seconds': 0,
              'original_failures_and_deadlines_unchanged': True,
              'not_a_complete_nine_trial_pilot': True}
    with (OUT/'freeze.json').open('x', encoding='utf8') as stream:
        json.dump(frozen, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': frozen['status'], 'sources': len(sources), 'archive': len(archive),
                      'proof_files': len(proofs), 'protected_history_checked': [row['checked_records'] for row in history]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
