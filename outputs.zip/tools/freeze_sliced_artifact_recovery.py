"""Freeze the separate artifact-only review without changing the failed run."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
ORIGIN = "09c5ce4aceb7426e87af5334bdb03eb4"
RECOVERY = "b15612da05084920a3ce70772291557a"
ROLES = {"sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
         "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier"}
FILES = [
    "defect_researcher/sliced_artifact_recovery.py", "defect_researcher/task_runtime.py",
    "tools/run_sliced_artifact_recovery.py", "tools/verify_sliced_artifact_recovery.py",
    "tools/reload_sliced_artifact_status.py", "tools/freeze_sliced_artifact_recovery.py",
    "tools/sliced_artifact_scope_guard.mjs", "tools/prepare_sliced_artifact_scope.mjs",
    "tools/enable_sliced_artifact_scope.mjs", "tools/run_sliced_artifact_model.mjs",
    "tools/verify_sliced_artifact_model.py", "tests/test_sliced_artifact_runtime.py",
    "tests/test_sliced_artifact_recovery.py", "tests/test_sliced_artifact_recovery_evidence.py",
    "tests/test_sliced_artifact_model.py", "tests/sliced_artifact_scope_guard.test.mjs",
    "tests/sliced_artifact_scope_core.test.mjs",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    output = ROOT / "outputs/sliced-artifact-implementation-v1"
    if output.exists():
        raise FileExistsError("Preserve the existing artifact-only freeze; do not overwrite it")
    origin = ROOT / "outputs" / ORIGIN
    if (origin / "completion.json").exists():
        raise ValueError("The source task must retain its original failure")
    failure = json.loads((origin / "failure.json").read_text(encoding="utf-8"))
    if failure["status"] != "failed" or failure["task_id"] != ORIGIN:
        raise ValueError("Unexpected source task state")
    inputs = json.loads((origin / "inputs.json").read_text(encoding="utf-8"))["files"]
    execution = [row for row in inputs if row["role"] in ROLES]
    if {row["role"] for row in execution} != ROLES:
        raise ValueError("The complete seven-role execution identity is required")
    for row in execution:
        if sha(row["path"]) != row["sha256_before"]:
            raise ValueError("Original execution source changed: " + row["role"])
    regression = ROOT / "outputs/sliced-artifact-tests.log"
    log = regression.read_text(encoding="utf-8")
    counts = re.findall(r"Ran (\d+) tests", log)
    if not counts or not re.search(r"\nOK\s*$", log) or int(counts[-1]) < 369:
        raise ValueError("A passing full regression log is required before freezing")
    preflight = ROOT / "outputs/agh-sliced-artifact-model/preflight-tests.json"
    prepared = json.loads(preflight.read_text(encoding="utf-8"))
    if (prepared.get("status") != "passed" or prepared.get("model_called") is not False
            or prepared.get("new_detection_inference_performed") is not False):
        raise ValueError("Passing synthetic preflight is required before the model read")
    for name, expected in prepared.get("source_sha256", {}).items():
        if sha(ROOT / name) != expected:
            raise ValueError("Model preflight source changed: " + name)
    for result in prepared.get("tests", {}).values():
        if (type(result.get("passed")) is not int or type(result.get("total")) is not int
                or result["passed"] != result["total"] or result["passed"] <= 0):
            raise ValueError("Model preflight test counts are not fully passed")
    for name in FILES:
        if not (ROOT / name).is_file():
            raise FileNotFoundError(name)
    output.mkdir()
    records = []
    for name in FILES:
        source, target = ROOT / name, output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        if sha(source) != sha(target):
            raise ValueError("Archive byte comparison failed: " + name)
        records.append({"path": name, "sha256": sha(source), "size_bytes": source.stat().st_size})
    document = {"schema_version": 1, "frozen_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "Separate zero-detector artifact review of preserved failed full-cohort computation",
        "source_task_id": ORIGIN, "recovery_task_id": RECOVERY, "original_status": "failed",
        "original_completion_absent": True, "original_pipeline_acceptance_passed": False,
        "original_budget_reset": False, "new_predict_calls": 0, "new_gpu_calls": 0,
        "max_recovery_wall_seconds": 600, "source_failure_sha256": sha(origin / "failure.json"),
        "original_execution_source_files": execution, "files": records,
        "python_regression_tests_passed": int(counts[-1]), "regression_log_sha256": sha(regression),
        "model_preflight_sha256": sha(preflight), "model_preflight": prepared,
        "formal_artifact_review_started": False, "new_model_read_started": False,
        "source_scientific_protocol_sha256": sha(ROOT / "fixtures/sliced_protocol.json")}
    (output / "freeze.json").write_text(json.dumps(document, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"frozen": True, "files": len(records), "python_tests": int(counts[-1]),
                      "freeze_sha256": sha(output / "freeze.json")}))


if __name__ == "__main__":
    main()
