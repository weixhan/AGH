"""Read-only independent verification of the frozen nine-pass validation experiment.

No experiment runner, sliced inference module or project metric implementation is
imported. IoU, greedy matching, AP101, coordinate mapping and fusion are rederived
here from saved evidence. Source pixels are decoded with the bound OpenCV codec;
this is artifact verification, not a second detector inference.
"""
from __future__ import annotations

import argparse
from bisect import bisect_left
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import re
from statistics import fmean
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
CLASSES = ["broken_strand", "welded_strand", "bent_strand", "long_scratch",
           "crushed", "spaced_strand", "deposit"]
SIZES = ("small", "medium", "large")
REGIONS = tuple(f"{y}_{x}" for y in ("top", "middle", "bottom") for x in ("left", "center", "right"))
BASELINE_TASK = "8d1d6900c7d74c90a29824495684807d"
DIAGNOSIS_TASK = "diagnosis-d35fab352e614cf7a3bf4c9236987cf8"
WEIGHT_SHA = "57d430496f764593b49547897161fbafa93afaca83cc9942a3cc8c2e282d0d75"
PREDICTIONS_SHA = "82f0572b03f9a9ff4cd1d1527d3dfda4ef992e887f398aaf621777d4dd54c287"
SOURCE_SHA = {
    "decision.json": "4262e2b27d9a65ccc170af2f453e45423f1986e1b1b78eaa72f459f3aa89f094",
    "gt_details.jsonl": "ca122b8f2c5657773e20faf733152fcb3b1f5372ee8d51b96117fe62086c1b3f",
    "completion.json": "3395549b70fe884b33b33255aa2120bb71fa9eb09fdf7305d8023ebf659b5d23",
    "artifact_manifest.json": "68990dc2e7648c602c13daf1a6fb8a6beb0e2d71a3dca1b55c36529dadcab9e6",
    "protocol.json": "f2f40fe2bdcc91cfd6e8e1b05611899e43185f53dd9d5d2a0332695440633040",
}
BASELINE_FILES = {"protocol.json", "inputs.json", "events.jsonl", "predictions_640.jsonl",
                  "predictions_960.jsonl", "metrics_640.json", "metrics_960.json", "comparison.json",
                  "comparison_report.md", "comparison_result.json"}
DIAGNOSIS_FILES = {"protocol.json", "inputs.json", "events.jsonl", "diagnosis_summary.json",
                   "gt_details.jsonl", "fp_details.jsonl", "threshold_analysis.json", "decision.json",
                   "diagnosis_report.md", "diagnosis_result.json"}
ARTIFACTS = {"protocol.json", "inputs.json", "events.jsonl", "pass_observations.jsonl",
             "predictions_sliced.jsonl", "fusion_details.jsonl", "context_reuse.json", "environment.json",
             "budget.json", "metrics_baseline.json", "metrics_sliced.json", "sliced_comparison.json",
             "decision.json", "sliced_result.json", "sliced_report.md", "checkpoint_index.json", "worker_request.json", "worker_receipt.json",
             "checkpoint_journal.jsonl", "budget_snapshot.json"}
CONTROLS = {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
            "rect": False, "augment": False, "agnostic_nms": False, "quantize": None}


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def decode(value):
    def unique(pairs):
        out = {}
        for key, item in pairs:
            if key in out:
                raise ValueError(f"Duplicate JSON key: {key}")
            out[key] = item
        return out
    def invalid(item):
        raise ValueError(f"Nonfinite JSON constant: {item}")
    out = json.loads(value, object_pairs_hook=unique, parse_constant=invalid)
    json.dumps(out, allow_nan=False)
    return out


def read(path):
    return decode(Path(path).read_text(encoding="utf-8-sig"))


def lines(path):
    return [decode(row) for row in Path(path).read_text(encoding="utf-8-sig").splitlines() if row.strip()]


def same(left, right, tolerance=1e-10):
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isfinite(left) and math.isfinite(right) and math.isclose(left, right, rel_tol=0, abs_tol=tolerance)
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(same(left[key], right[key], tolerance) for key in left)
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(same(a, b, tolerance) for a, b in zip(left, right))
    return type(left) is type(right) and left == right


def contains(saved, expected, tolerance=1e-10):
    """Verify all independently recomputed fields, retaining descriptive extras."""
    if isinstance(expected, dict):
        return isinstance(saved, dict) and expected.keys() <= saved.keys() and all(
            contains(saved[key], value, tolerance) for key, value in expected.items())
    if isinstance(expected, list):
        return isinstance(saved, list) and len(saved) == len(expected) and all(
            contains(a, b, tolerance) for a, b in zip(saved, expected))
    return same(saved, expected, tolerance)


def finite(value, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def scoped_file(path, roots):
    path = Path(path).resolve()
    if not path.is_file() or not any(path.is_relative_to(Path(root).resolve()) for root in roots):
        raise ValueError(f"Evidence file absent or outside scope: {path}")
    return path


def publication(directory, task_id, tool, required, marker_name="completion.json"):
    directory = Path(directory).resolve()
    marker, manifest = read(directory / marker_name), read(directory / "artifact_manifest.json")
    if any(row.get("task_id") != task_id or row.get("tool") != tool or row.get("status") != "completed"
           for row in (marker, manifest)):
        return False
    if (Path(marker.get("artifact_manifest", "")).resolve() != directory / "artifact_manifest.json"
            or marker.get("artifact_manifest_sha256") != digest(directory / "artifact_manifest.json")):
        return False
    rows = manifest.get("files", [])
    names = {row.get("name") for row in rows}
    if len(rows) != len(names) or not required <= names:
        return False
    for row in rows:
        path = scoped_file(row["path"], [directory])
        if (path.parent != directory or path.name != row["name"] or row["size_bytes"] != path.stat().st_size
                or row["sha256"] != digest(path)):
            return False
    if marker.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
        return False
    marker_time = (directory / marker_name).stat().st_mtime_ns
    return all(marker_time >= (directory / name).stat().st_mtime_ns for name in names | {"artifact_manifest.json"})


def iou(a, b):
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - intersection
    if union <= 0:
        raise ValueError("Nonpositive box union")
    return intersection / union


def validate_box(row, width, height, prediction=False):
    box = row.get("xyxy")
    valid = (type(row.get("class_id")) is int and row["class_id"] in range(7)
             and isinstance(box, list) and len(box) == 4 and all(finite(x) for x in box)
             and 0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height)
    if prediction:
        valid &= finite(row.get("confidence"), True) and .001 <= row["confidence"] <= 1
    if not valid:
        raise ValueError("Invalid class, finite positive box, confidence or bounds")


def bucket(box):
    area = (box[2] - box[0]) * (box[3] - box[1])
    return "small" if area < 1024 else "medium" if area < 9216 else "large"


def region(box, width, height):
    x = min(2, int((box[0] + box[2]) / 2 / width * 3))
    y = min(2, int((box[1] + box[3]) / 2 / height * 3))
    return f"{('top', 'middle', 'bottom')[y]}_{('left', 'center', 'right')[x]}"


def expected_crops():
    return [[0, 0, 1920, 1080]] + [[x, y, x + 640, y + 640] for y in (0, 440) for x in (0, 512, 1024, 1280)]


def map_predictions(local, crop, pass_id):
    output = []
    x, y, right, bottom = crop
    for index, pred in enumerate(local):
        validate_box(pred, right - x, bottom - y, True)
        b = pred["xyxy"]
        output.append({"class_id": pred["class_id"], "confidence": pred["confidence"],
                       "xyxy": [b[0] + x, b[1] + y, b[2] + x, b[3] + y],
                       "pass_id": pass_id, "prediction_index": index, "local_xyxy": b, "crop": crop})
    return output


def fuse(observations, threshold=.7, max_det=300):
    """Derive all NMS decisions from saved per-pass outputs, independently."""
    candidates = [dict(p) for row in observations for p in row["global_predictions"]]
    candidates.sort(key=lambda p: (-p["confidence"], p["pass_id"], p["prediction_index"]))
    selected, suppressed, truncated = [], [], []
    while candidates:
        winner = candidates.pop(0)
        selected.append(winner)
        remaining = []
        for pred in candidates:
            overlap = iou(winner["xyxy"], pred["xyxy"])
            if winner["class_id"] == pred["class_id"] and overlap > threshold:
                suppressed.append({"pass_id": pred["pass_id"], "prediction_index": pred["prediction_index"],
                                   "suppressed_by_pass_id": winner["pass_id"],
                                   "suppressed_by_prediction_index": winner["prediction_index"], "iou": overlap})
            else:
                remaining.append(pred)
        candidates = remaining
    truncated = selected[max_det:]
    kept = selected[:max_det]
    predictions = [{"class_id": p["class_id"], "confidence": p["confidence"], "xyxy": p["xyxy"]} for p in kept]
    return predictions, kept, suppressed, truncated


def matching(records, confidence=.25, threshold=.5):
    """Each original GT enters exactly one match, independent of tile count."""
    matched, per_image = {}, []
    for row in sorted(records, key=lambda p: p["image_id"]):
        used = set()
        active = sorted((i for i, p in enumerate(row["predictions"]) if p["confidence"] >= confidence),
                        key=lambda i: (-row["predictions"][i]["confidence"], i))
        for index in active:
            pred = row["predictions"][index]
            options = [(iou(pred["xyxy"], gt["xyxy"]), gi) for gi, gt in enumerate(row["ground_truth"])
                       if gi not in used and gt["class_id"] == pred["class_id"]]
            best = min(options, key=lambda p: (-p[0], p[1])) if options else (0., None)
            gi = best[1] if best[0] >= threshold else None
            matched[row["image_id"], index] = gi
            if gi is not None:
                used.add(gi)
        per_image.append({"image_id": row["image_id"], "gt": len(row["ground_truth"]),
                          "tp": len(used), "fp": len(active) - len(used), "fn": len(row["ground_truth"]) - len(used)})
    return matched, per_image


def ap101(hits, gt_count):
    if not gt_count:
        return None
    precision, recall, tp = [], [], 0
    for index, hit in enumerate(hits, 1):
        tp += hit is not None
        precision.append(tp / index)
        recall.append(tp / gt_count)
    for index in range(len(precision) - 2, -1, -1):
        precision[index] = max(precision[index], precision[index + 1])
    samples = []
    for r in range(101):
        pos = bisect_left(recall, r / 100)
        samples.append(precision[pos] if pos < len(precision) else 0.)
    return fmean(samples)


def rates(tp, fp, fn):
    return {"tp": tp, "fp": fp, "fn": fn, "precision": tp / (tp + fp) if tp + fp else 0.,
            "recall": tp / (tp + fn) if tp + fn else 0.}


def metrics(records):
    """Separately implemented class-major AP and operating-point evaluator."""
    records = sorted(records, key=lambda row: row["image_id"])
    lookup = {row["image_id"]: row for row in records}
    by_image = {}
    matches, counts = matching(records)
    for row in counts:
        source = lookup[row["image_id"]]
        small_indices = {gi for gi, gt in enumerate(source["ground_truth"]) if bucket(gt["xyxy"]) == "small"}
        found = {gi for (image, _), gi in matches.items() if image == row["image_id"] and gi is not None}
        by_image[row["image_id"]] = {**row, **rates(row["tp"], row["fp"], row["fn"]),
            "predictions": row["tp"] + row["fp"], "small_gt": len(small_indices), "small_fn": len(small_indices - found)}
    per_class = []
    for class_id, name in enumerate(CLASSES):
        predictions = [(row["image_id"], index, pred) for row in records for index, pred in enumerate(row["predictions"])
                       if pred["class_id"] == class_id]
        predictions.sort(key=lambda p: (-p[2]["confidence"], p[0], p[1]))
        truths = {row["image_id"]: [(gi, gt) for gi, gt in enumerate(row["ground_truth"]) if gt["class_id"] == class_id]
                  for row in records}
        gt_count = sum(len(values) for values in truths.values())
        ap = {}
        for ti in range(10):
            threshold = round(.5 + ti * .05, 2)
            consumed, hits = {}, []
            for image, _, pred in predictions:
                used = consumed.setdefault(image, set())
                candidates = [(iou(pred["xyxy"], gt["xyxy"]), gi) for gi, gt in truths[image] if gi not in used]
                best = min(candidates, key=lambda item: (-item[0], item[1])) if candidates else (0., None)
                selected = best[1] if best[0] >= threshold else None
                hits.append(selected)
                if selected is not None:
                    used.add(selected)
            ap[f"{threshold:.2f}"] = ap101(hits, gt_count)
        selected = [(image, pi, pred) for image, pi, pred in predictions if pred["confidence"] >= .25]
        tp = sum(matches[image, pi] is not None for image, pi, _ in selected)
        small_gt = sum(bucket(gt["xyxy"]) == "small" for values in truths.values() for _, gt in values)
        small_tp = sum(matches[image, pi] is not None and bucket(lookup[image]["ground_truth"][matches[image, pi]]["xyxy"]) == "small"
                       for image, pi, _ in selected)
        per_class.append({"class_id": class_id, "class_name": name, "gt": gt_count,
            "images_with_class": sum(bool(values) for values in truths.values()), "predictions": len(predictions),
            "ap_defined": bool(gt_count), "AP50": ap["0.50"], "AP50_95": fmean(ap.values()) if gt_count else None,
            "ap_by_iou": ap, "operating_point": {**rates(tp, len(selected) - tp, gt_count - tp),
                "predictions": len(selected), "small_gt": small_gt, "small_fn": small_gt - small_tp}})
    per_image = list(by_image.values())
    tp, fp, fn = (sum(row[key] for row in per_image) for key in ("tp", "fp", "fn"))
    small_gt, small_fn = (sum(row[key] for row in per_image) for key in ("small_gt", "small_fn"))
    normal = [row for row in per_image if not row["gt"]]
    nf = sum(row["fp"] > 0 for row in normal)
    included = [row for row in per_class if row["ap_defined"]]
    canonical = [{"image_id": row["image_id"], "width": float(row["width"]), "height": float(row["height"]),
        "ground_truth": sorted([{"class_id": gt["class_id"], "xyxy": tuple(float(x) for x in gt["xyxy"])} for gt in row["ground_truth"]],
                               key=lambda gt: (gt["class_id"], gt["xyxy"]))} for row in records]
    signature = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()).hexdigest()
    return {"schema_version": "independent-detection-metrics-v1", "dataset_signature": signature,
        "counts": {"images": len(records), "gt": tp + fn, "predictions": sum(len(row["predictions"]) for row in records)},
        "mAP50": fmean(row["AP50"] for row in included) if included else 0.,
        "mAP50_95": fmean(row["AP50_95"] for row in included) if included else 0.,
        "ap_defined": bool(included), "ap_classes": [row["class_id"] for row in included], "per_class": per_class,
        "operating_point": {"confidence_threshold": .25, "iou_threshold": .5, **rates(tp, fp, fn), "predictions": tp + fp,
            "precision_defined": bool(tp + fp), "recall_defined": bool(tp + fn), "small_gt": small_gt,
            "small_fn": small_fn, "small_recall": (small_gt - small_fn) / small_gt if small_gt else None,
            "normal_images": len(normal), "normal_images_with_false_positives": nf,
            "normal_image_fp_rate": nf / len(normal) if normal else None}, "per_image": per_image,
        "protocol": {"evaluator": "independent-detection-metrics-v1",
            "matching": "confidence_descending_same_class_greedy_max_available_iou",
            "confidence_ties": "image_id_then_input_prediction_index", "iou_thresholds": [round(.5 + i * .05, 2) for i in range(10)],
            "ap_recall_points": 101, "ap_average": "macro_over_classes_with_ground_truth",
            "small_object_area_lt": 1024, "coordinate_space": "original_image_xyxy"}}


def corrected_strata(records):
    matches, _ = matching(records)
    output = {}
    for kind, groups in (("per_size", SIZES), ("per_region", REGIONS)):
        bins = {group: {"gt": 0, "tp_gt": 0, "fn_gt": 0, "tp_predictions": 0, "fp_predictions": 0} for group in groups}
        for row in records:
            found = {gi for (image, _), gi in matches.items() if image == row["image_id"] and gi is not None}
            identify = (lambda box: bucket(box)) if kind == "per_size" else (lambda box: region(box, row["width"], row["height"]))
            for gi, gt in enumerate(row["ground_truth"]):
                group = bins[identify(gt["xyxy"])]
                group["gt"] += 1
                group["tp_gt" if gi in found else "fn_gt"] += 1
            for pi, pred in enumerate(row["predictions"]):
                if pred["confidence"] >= .25:
                    bins[identify(pred["xyxy"])]["tp_predictions" if matches[row["image_id"], pi] is not None else "fp_predictions"] += 1
        for group in bins.values():
            group["recall_gt"] = group["tp_gt"] / group["gt"] if group["gt"] else None
            den = group["tp_predictions"] + group["fp_predictions"]
            group["precision_predictions"] = group["tp_predictions"] / den if den else None
        output[kind] = bins
    return output


def stratum_artifact(records):
    bins = corrected_strata(records)
    return {"schema_version": "separate-gt-and-prediction-strata-v1",
        "protocol": {"confidence_threshold": .25, "recall_grouping": "ground_truth_box_size_or_center",
            "precision_grouping": "prediction_box_size_or_center", "matching": "reuse_hash_bound_verified_one_to_one_matches"},
        "size_bucket": [{"size_bucket": key, **value} for key, value in bins["per_size"].items()],
        "region": [{"region": key, **value} for key, value in bins["per_region"].items()]}


def bootstrap(deltas):
    if not deltas:
        return {"eligible_images": 0, "mean_delta": None, "ci95": None, "seed": 42, "resamples": 2000}
    rng = random.Random(42)
    samples = sorted(fmean(rng.choices(deltas, k=len(deltas))) for _ in range(2000))
    def percentile(fraction):
        pos = (len(samples) - 1) * fraction
        lo, hi = math.floor(pos), math.ceil(pos)
        return samples[lo] + (samples[hi] - samples[lo]) * (pos - lo)
    return {"eligible_images": len(deltas), "mean_delta": fmean(deltas), "ci95": [percentile(.025), percentile(.975)],
            "seed": 42, "resamples": 2000}


def expected_trace(observations):
    predictions, selected, suppressed, truncated = fuse(observations)
    kept_lookup = {(p["pass_id"], p["prediction_index"]): i for i, p in enumerate(selected)}
    discard = {(p["pass_id"], p["prediction_index"]) for p in truncated}
    suppressed_lookup = {(p["pass_id"], p["prediction_index"]): p for p in suppressed}
    candidates = sorted((p for observation in observations for p in observation["global_predictions"]),
                        key=lambda p: (-p["confidence"], p["pass_id"], p["prediction_index"]))
    rows = []
    for rank, candidate in enumerate(candidates):
        key = candidate["pass_id"], candidate["prediction_index"]
        disposition = suppressed_lookup.get(key)
        row = {**candidate, "candidate_rank": rank, "status": "suppressed_iou" if disposition else
               "global_max_det" if key in discard else "kept", "suppressed_by": None,
               "suppression_iou": None, "final_prediction_index": kept_lookup.get(key)}
        if disposition:
            row.update(suppressed_by={"pass_id": disposition["suppressed_by_pass_id"],
                                      "prediction_index": disposition["suppressed_by_prediction_index"]},
                       suppression_iou=disposition["iou"])
        rows.append(row)
    return predictions, {"schema_version": "fixed-nine-pass-fusion-trace-v1", "nms_iou": .7,
        "suppression_comparator": ">", "global_max_det": 300,
        "confidence_ties": "pass_id_then_original_prediction_index", "candidate_count": len(candidates),
        "nms_survivor_count": len(selected) + len(truncated), "suppressed_count": len(suppressed),
        "global_max_det_discarded_count": len(truncated), "final_count": len(predictions), "rows": rows}


def comparison(baseline, sliced, protocol):
    """Derive every research denominator, transition and frozen metric gate."""
    baseline = sorted(baseline, key=lambda p: p["image_id"])
    sliced = sorted(sliced, key=lambda p: p["image_id"])
    if [(p["image_id"], p["width"], p["height"], p["ground_truth"]) for p in baseline] != [
            (p["image_id"], p["width"], p["height"], p["ground_truth"]) for p in sliced]:
        raise ValueError("Paired comparison changed original image/GT population")
    a, b = metrics(baseline), metrics(sliced)
    ma, ia = matching(baseline)
    mb, ib = matching(sliced)
    gt_a = {(image, gi): pi for (image, pi), gi in ma.items() if gi is not None}
    gt_b = {(image, gi): pi for (image, pi), gi in mb.items() if gi is not None}
    counts_a = {row["image_id"]: row for row in ia}
    counts_b = {row["image_id"]: row for row in ib}
    transitions, images = [], []
    cells = {(ci, size): Counter() for ci in range(7) for size in SIZES}
    for row in baseline:
        image = row["image_id"]
        before = {gi for img, gi in gt_a if img == image}
        after = {gi for img, gi in gt_b if img == image}
        medium = {gi for gi, gt in enumerate(row["ground_truth"]) if bucket(gt["xyxy"]) == "medium"}
        medium_delta = len(after & medium) - len(before & medium)
        images.append({"image_id": image, "gt": len(row["ground_truth"]), "baseline_tp": len(before),
            "sliced_tp": len(after), "tp_delta": len(after) - len(before), "baseline_fp": counts_a[image]["fp"],
            "sliced_fp": counts_b[image]["fp"], "fp_delta": counts_b[image]["fp"] - counts_a[image]["fp"],
            "recovered_gt": len(after - before), "lost_gt": len(before - after), "medium_gt": len(medium),
            "baseline_medium_tp": len(before & medium), "sliced_medium_tp": len(after & medium),
            "medium_tp_delta": medium_delta, "medium_recall_delta": medium_delta / len(medium) if medium else None,
            "medium_recovered_gt": len((after - before) & medium), "medium_lost_gt": len((before - after) & medium)})
        for gi, gt in enumerate(row["ground_truth"]):
            found_a, found_b = gi in before, gi in after
            size = bucket(gt["xyxy"])
            transition = "retained_tp" if found_a and found_b else "recovered_fn" if found_b else "lost_tp" if found_a else "retained_fn"
            transitions.append({"evidence_id": f"{image}:gt:{gi}", "image_id": image, "gt_index": gi,
                "class_id": gt["class_id"], "class_name": CLASSES[gt["class_id"]], "size_bucket": size,
                "xyxy": gt["xyxy"], "baseline_status": "tp" if found_a else "fn", "sliced_status": "tp" if found_b else "fn",
                "baseline_prediction_index": gt_a.get((image, gi)), "sliced_prediction_index": gt_b.get((image, gi)), "transition": transition})
            cells[gt["class_id"], size].update(gt=1, baseline_tp=int(found_a), sliced_tp=int(found_b),
                recovered_gt=int(found_b and not found_a), lost_gt=int(found_a and not found_b))
    class_size = []
    for (ci, size), cnt in cells.items():
        gt = cnt["gt"]
        class_size.append({"class_id": ci, "class_name": CLASSES[ci], "size_bucket": size, "gt": gt,
            "baseline_tp": cnt["baseline_tp"], "baseline_fn": gt - cnt["baseline_tp"],
            "baseline_recall_gt": cnt["baseline_tp"] / gt if gt else None,
            "sliced_tp": cnt["sliced_tp"], "sliced_fn": gt - cnt["sliced_tp"],
            "sliced_recall_gt": cnt["sliced_tp"] / gt if gt else None, "tp_delta": cnt["sliced_tp"] - cnt["baseline_tp"],
            "recovered_gt": cnt["recovered_gt"], "lost_gt": cnt["lost_gt"],
            "support_status": "no_gt" if not gt else "insufficient_gt" if gt < 20 else "sufficient_for_description"})
    per_class_gt = []
    for ci in range(7):
        cells_here = [r for r in class_size if r["class_id"] == ci]
        aggregated = {key: sum(r[key] for r in cells_here) for key in ("gt", "baseline_tp", "baseline_fn",
                      "sliced_tp", "sliced_fn", "tp_delta", "recovered_gt", "lost_gt")}
        per_class_gt.append({"class_id": ci, "class_name": CLASSES[ci], **aggregated,
            "baseline_recall_gt": aggregated["baseline_tp"] / aggregated["gt"] if aggregated["gt"] else None,
            "sliced_recall_gt": aggregated["sliced_tp"] / aggregated["gt"] if aggregated["gt"] else None})
    gains = {"tp_gain": b["operating_point"]["tp"] - a["operating_point"]["tp"],
        "gain_images": sum(row["tp_delta"] > 0 for row in images), "loss_images": sum(row["tp_delta"] < 0 for row in images),
        "medium_tp_gain": sum(row["medium_tp_delta"] for row in images),
        "medium_gain_images": sum(row["medium_tp_delta"] > 0 for row in images),
        "medium_loss_images": sum(row["medium_tp_delta"] < 0 for row in images),
        "recovered_gt": sum(row["transition"] == "recovered_fn" for row in transitions),
        "lost_gt": sum(row["transition"] == "lost_tp" for row in transitions),
        "medium_recovered_gt": sum(row["transition"] == "recovered_fn" and row["size_bucket"] == "medium" for row in transitions),
        "medium_lost_gt": sum(row["transition"] == "lost_tp" and row["size_bucket"] == "medium" for row in transitions)}
    point = b["operating_point"]
    values = [("overall_tp_gain", gains["tp_gain"], "required_min", "min_tp_gain"),
        ("overall_gain_images", gains["gain_images"], "required_min", "min_gain_images"),
        ("medium_tp_gain", gains["medium_tp_gain"], "required_min", "min_medium_tp_gain"),
        ("medium_gain_images", gains["medium_gain_images"], "required_min", "min_medium_gain_images"),
        ("normal_fp_images", point["normal_images_with_false_positives"], "required_max", "max_normal_fp_images"),
        ("normal_fp_rate", point["normal_image_fp_rate"], "required_max", "max_normal_fp_rate"),
        ("overall_fp", point["fp"], "required_max", "max_fp"),
        ("ap50_non_degradation", b["mAP50"], "required_min", "min_ap50"),
        ("ap50_95_non_degradation", b["mAP50_95"], "required_min", "min_ap50_95")]
    checks = [{"name": name, "actual": actual, bound: protocol["acceptance"][key],
        "passed": actual is not None and (actual >= protocol["acceptance"][key] if bound == "required_min" else actual <= protocol["acceptance"][key])}
        for name, actual, bound, key in values]
    population = {"images": len(baseline), "gt": sum(len(r["ground_truth"]) for r in baseline),
        "normal_images": sum(not r["ground_truth"] for r in baseline), "medium_gt": sum(r["medium_gt"] for r in images),
        "medium_images": sum(bool(r["medium_gt"]) for r in images)}
    deltas = {key: b[key] - a[key] for key in ("mAP50", "mAP50_95")}
    deltas.update({key: b["operating_point"][key] - a["operating_point"][key]
        if b["operating_point"][key] is not None and a["operating_point"][key] is not None else None
        for key in ("precision", "recall", "small_recall", "normal_image_fp_rate")})
    paired = bootstrap([(row["sliced_tp"] - row["baseline_tp"]) / row["gt"] for row in images if row["gt"]])
    paired["unit"] = "image_with_at_least_one_gt"
    medium = bootstrap([row["medium_recall_delta"] for row in images if row["medium_gt"]])
    medium["unit"] = "image_with_at_least_one_original_medium_gt"
    return {"schema_version": "fixed-nine-pass-validation-comparison-v1", "population": population,
        "baseline_metrics": a, "sliced_metrics": b, "paired_comparison": {"schema_version": "sliced-paired-comparison-v1",
            "scope": "validation_only_same_weight", "delta_direction": "sliced_minus_baseline",
            "delta_sliced_minus_baseline": deltas, "paired_recall": paired},
        "stratified_statistics": {"baseline": stratum_artifact(baseline), "sliced": stratum_artifact(sliced)},
        "class_size": class_size, "per_class_gt": per_class_gt,
        "normal_false_positives": {"baseline": {"images": a["operating_point"]["normal_images"],
            "fp_images": a["operating_point"]["normal_images_with_false_positives"],
            "fp_boxes": sum(row["baseline_fp"] for row in images if not row["gt"]),
            "image_fp_rate": a["operating_point"]["normal_image_fp_rate"]},
            "sliced": {"images": b["operating_point"]["normal_images"],
            "fp_images": b["operating_point"]["normal_images_with_false_positives"],
            "fp_boxes": sum(row["sliced_fp"] for row in images if not row["gt"]),
            "image_fp_rate": b["operating_point"]["normal_image_fp_rate"]}},
        "per_image": images, "gt_transitions": transitions, "gains": gains,
        "paired_medium_recall": medium, "scientific_decision": {"status": "accepted" if all(row["passed"] for row in checks) else "stop",
            "scope": "frozen_scientific_metric_gates_only", "checks": checks,
            "failed_gates": [row["name"] for row in checks if not row["passed"]],
            "execution_and_evidence_gates_required": True, "threshold_search_performed": False}}


def source_gt(path, width, height):
    truths = []
    for text in Path(path).read_text(encoding="utf-8-sig").splitlines():
        if not text.strip():
            continue
        parts = text.split()
        if len(parts) != 5 or not re.fullmatch(r"[0-6]", parts[0]):
            raise ValueError("Invalid frozen source label")
        x, y, w, h = map(float, parts[1:])
        if not all(finite(v) and v <= 1 for v in (x, y, w, h)) or not w or not h:
            raise ValueError("Invalid normalized source GT")
        truths.append({"class_id": int(parts[0]), "xyxy": [(x - w / 2) * width, (y - h / 2) * height,
                        (x + w / 2) * width, (y + h / 2) * height], "source_label": text})
    return truths


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def prepublication_receipt_valid(receipt, task_id, bindings):
    """Typed external receipt gate; successful research decision is separate."""
    total, passed, checks = receipt.get("total_checks"), receipt.get("passed_checks"), receipt.get("checks")
    return (receipt.get("status") == "passed" and receipt.get("prepublication") is True and receipt.get("task_id") == task_id
        and type(total) is int and type(passed) is int and total > 0 and total == passed
        and isinstance(checks, dict) and len(checks) == total and all(value is True for value in checks.values())
        and all(receipt.get(key) == value for key, value in bindings.items())
        and finite(receipt.get("acceptance_total_wall_seconds"), True) and receipt["acceptance_total_wall_seconds"] <= 1800)


def ledger_checks(budget, observations):
    checks = {}
    attempts = budget.get("formal_attempts", [])
    warmup = budget.get("warmup_attempts", [])
    observation_keys = {(r["image_id"], r["pass_id"]): r for r in observations}
    passed = [r for r in attempts if r.get("status") == "passed"]
    failed = [r for r in attempts if r.get("status") == "failed"]
    checks["budget_5760_formal_successes_no_successful_pass_reruns"] = (
        len(passed) == len(observation_keys) == 5760
        and len({(r["image_id"], r["pass_id"]) for r in passed}) == 5760
        and {(r["image_id"], r["pass_id"]) for r in passed} == observation_keys.keys()
        and all(r["call_index"] == observation_keys[r["image_id"], r["pass_id"]]["call_index"]
            and same(r["elapsed_seconds"], observation_keys[r["image_id"], r["pass_id"]]["elapsed_seconds"], 0)
            and same(r["gpu_seconds"], observation_keys[r["image_id"], r["pass_id"]]["gpu_seconds"], 0) for r in passed))
    checks["budget_formal_calls_failed_retry_limit_and_single_warmup"] = (len(attempts) == len(passed) + len(failed)
        and len(attempts) <= 5770 and len(failed) <= 10 and len(warmup) == 1 and warmup[0].get("status") == "passed"
        and warmup[0].get("image_id") == observations[0]["image_id"] and warmup[0].get("pass_id") == 0
        and budget.get("formal_calls") == len(attempts) and budget.get("warmup_calls") == len(warmup)
        and budget.get("successful_observations") == 5760)
    calls_valid = all(type(r.get("call_index")) is int and r["call_index"] == i for i, r in enumerate(attempts, 1))
    calls_valid &= warmup[0].get("call_index") == 1 if warmup else False
    timed = True
    all_calls = warmup + attempts
    starts, finishes = [], []
    for r in all_calls:
        timed &= (r.get("status") in ("passed", "failed") and finite(r.get("elapsed_seconds"), True)
                  and finite(r.get("gpu_seconds")) and (r["image_id"], r["pass_id"]) in observation_keys)
        started, finished = datetime.fromisoformat(r["utc_started"]), datetime.fromisoformat(r["utc_finished"])
        starts.append(started)
        finishes.append(finished)
        timed &= finished >= started
    timed &= all(started >= previous for started, previous in zip(starts[1:], finishes[:-1]))
    for r in failed:
        success = observation_keys.get((r["image_id"], r["pass_id"]))
        calls_valid &= bool(success) and r["call_index"] < success["call_index"] and isinstance(r.get("error"), dict)
    checks["all_actual_call_indices_times_and_necessary_failed_retries"] = calls_valid and timed
    gpu = sum(r["gpu_seconds"] for r in all_calls)
    checks["cumulative_gpu_cost_includes_all_calls_and_warmup"] = same(gpu, budget.get("gpu_seconds"), 1e-6) and gpu <= 900
    inference_wall, task_wall = budget.get("inference_wall_seconds"), budget.get("task_wall_seconds")
    checks["inference_and_task_wall_cost_within_frozen_limits"] = (
        finite(inference_wall, True) and finite(task_wall, True) and inference_wall <= 900 and task_wall <= 1800
        and task_wall >= inference_wall and inference_wall + 1e-3 >= sum(r["elapsed_seconds"] for r in all_calls)
        and budget.get("resumable") is True)
    if all_calls:
        measured_span = (finishes[-1] - starts[0]).total_seconds()
        checks["wall_time_contains_entire_recorded_predict_span"] = inference_wall + .05 >= measured_span
    segments = budget.get("wall_segments", [])
    monotonic_valid = bool(segments)
    previous_inference_end = previous_task_end = 0.
    for seg in segments:
        monotonic_valid &= all(finite(seg.get(key)) for key in ("task_wall_seconds_before", "inference_wall_seconds_before",
                              "monotonic_task_seconds", "monotonic_inference_seconds"))
        monotonic_valid &= seg.get("utc_finished") is not None
        if not monotonic_valid:
            break
        monotonic_valid &= datetime.fromisoformat(seg["utc_finished"]) >= datetime.fromisoformat(seg["utc_started"])
        monotonic_valid &= seg["task_wall_seconds_before"] >= previous_task_end
        monotonic_valid &= seg["inference_wall_seconds_before"] >= previous_inference_end
        previous_task_end = seg["task_wall_seconds_before"] + seg["monotonic_task_seconds"]
        previous_inference_end = seg["inference_wall_seconds_before"] + seg["monotonic_inference_seconds"]
        monotonic_valid &= seg["monotonic_task_seconds"] >= seg["monotonic_inference_seconds"]
    checks["monotonic_wall_segments_preserve_cumulative_cost"] = (monotonic_valid
        and task_wall >= previous_task_end - 1e-6 and inference_wall >= previous_inference_end - 1e-6)
    return checks


def _budget_checks(checks, budget, observations, directory, protocol, environment, execution_identity=None):
    checks.update(ledger_checks(budget, observations))
    observation_keys = {(r["image_id"], r["pass_id"]): r for r in observations}
    index = read(directory / "checkpoint_index.json")
    entries = index.get("checkpoints", [])
    checks["checkpoint_index_has_all_unique_observations"] = (
        len(entries) == len({(r["image_id"], r["pass_id"]) for r in entries}) == 5760
        and {(r["image_id"], r["pass_id"]) for r in entries} == observation_keys.keys())
    checkpoint_valid = True
    for entry in entries:
        path = scoped_file(directory / entry["relative_path"], [directory / "checkpoints"])
        record = read(path)
        observation = observation_keys[entry["image_id"], entry["pass_id"]]
        checkpoint_valid &= (digest(path) == entry.get("sha256") and path.stat().st_size == entry.get("size_bytes")
            and record.get("observation_sha256") == canonical_sha(observation)
            and same(record.get("observation"), observation, 0) and entry.get("call_index") == observation.get("call_index")
            and record.get("environment_identity") == observation.get("environment_identity"))
        identity = record.get("identity", {})
        checkpoint_valid &= contains(observation, identity, 0) and {"image_id", "pass_id", "crop", "source_image_sha256",
            "decoded_image_sha256", "input_pixels_sha256", "protocol_sha256", "weight_sha256", "scientific_inputs_sha256"} <= identity.keys()
    checks["every_checkpoint_hash_identity_output_and_call_binding"] = checkpoint_valid
    receipt = read(directory / "worker_receipt.json")
    checks["worker_completed_receipt_binds_all_checkpoint_sources"] = (
        receipt.get("status") == "completed" and receipt.get("observations") == 5760
        and receipt.get("environment_sha256") == digest(directory / "environment.json")
        and receipt.get("budget_sha256") == digest(directory / "budget.json")
        and receipt.get("checkpoint_index_sha256") == digest(directory / "checkpoint_index.json"))
    import importlib.util
    verifier_path = Path(__file__).with_name("verify_sliced_journal.py")
    spec = importlib.util.spec_from_file_location("independent_sliced_journal", verifier_path)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    if execution_identity is None:
        raise ValueError("Version 2 execution identity is required for journal verification")
    journal = verifier.verify_journal(directory, protocol, execution_identity, observations=observations)
    checks.update(journal["checks"])
    checks["worker_completed_receipt_binds_v2_durable_journal"] = (
        type(receipt.get("journal_version")) is int and receipt["journal_version"] == 2
        and type(receipt.get("journal_events")) is int and receipt["journal_events"] == journal["journal_events"]
        and receipt.get("journal_sha256") == journal["journal_sha256"]
        and receipt.get("journal_file_sha256") == journal["journal_file_sha256"])
    checks["positive_peak_gpu_memory_recorded"] = type(environment.get("peak_allocated_bytes")) is int and environment["peak_allocated_bytes"] > 0


def review(configuration, task_id, directory=None, baseline_directory=None, diagnosis_directory=None, *, prepublication=False):
    """Review successful publication; an unsuccessful scientific gate may be stop."""
    import cv2
    import numpy as np
    import yaml
    review_started_at = datetime.now(timezone.utc).isoformat()
    review_clock = time.perf_counter()
    if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
        raise ValueError("Unsafe single-directory task ID")
    paths = {key: Path(value).resolve() for key, value in configuration.items()}
    directory = Path(directory or paths["output_root"] / task_id).resolve()
    marker_name = "completion_candidate.json" if prepublication else "completion.json"
    baseline_directory = Path(baseline_directory or paths["output_root"] / BASELINE_TASK).resolve()
    diagnosis_directory = Path(diagnosis_directory or paths["output_root"] / DIAGNOSIS_TASK).resolve()
    if any(path.parent != paths["output_root"] for path in (directory, baseline_directory, diagnosis_directory)):
        raise ValueError("Task evidence directories must be direct configured output children")
    result, protocol, inputs, environment, budget = (read(directory / name) for name in
        ("sliced_result.json", "protocol.json", "inputs.json", "environment.json", "budget.json"))
    source_result = read(baseline_directory / "comparison_result.json")
    source_environment = source_result["summary"]["environments"]["640"]
    checks = {"task_publication_chain_valid": publication(directory, task_id, "compare_validation_slices", ARTIFACTS, marker_name),
        "task_result_completed_identity": result.get("task_id") == task_id and result.get("status") == "completed"
            and result.get("tool") == "compare_validation_slices",
        "baseline_publication_chain_valid": publication(baseline_directory, BASELINE_TASK, "compare_validation_resolutions", BASELINE_FILES),
        "diagnosis_publication_chain_valid": publication(diagnosis_directory, DIAGNOSIS_TASK, "diagnose_validation_errors", DIAGNOSIS_FILES),
        "fixed_protocol_matches_current_frozen_fixture": contains(protocol, read(ROOT / "fixtures" / "sliced_protocol.json"), 0),
        "frozen_baseline_prediction_bytes": digest(baseline_directory / "predictions_640.jsonl") == PREDICTIONS_SHA,
        "source_diagnosis_evidence_bytes": all(digest(diagnosis_directory / name) == value for name, value in SOURCE_SHA.items())}
    expected_protocol = {"schema_version": 1, "protocol_id": "val-hybrid640-nine-pass-v1", "source_task_id": BASELINE_TASK,
        "diagnosis_task_id": DIAGNOSIS_TASK, "evidence_id": f"diagnosis:{DIAGNOSIS_TASK}:640", "split": "val",
        "train_imgsz": 640, "eval_imgsz": 640, "device": "0", "precision": "FP32", "batch": 1,
        "prediction_confidence": .001, "nms_iou": .7, "max_det": 300, "rect": False, "augment": False,
        "agnostic_nms": False, "allow_tf32": False, "quantize": None, "global_nms_iou": .7, "global_max_det": 300,
        "class_names": {str(i): name for i, name in enumerate(CLASSES)},
        "population": {"images": 640, "gt": 596, "normal_images": 245, "medium_gt": 77, "medium_images": 74, "width": 1920, "height": 1080},
        "operating_point": {"confidence": .25, "match_iou": .5},
        "acceptance": {"min_tp_gain": 5, "min_gain_images": 5, "min_medium_tp_gain": 5, "min_medium_gain_images": 5,
            "max_normal_fp_images": 5, "max_normal_fp_rate": 5 / 245, "max_fp": 149,
            "min_ap50": .41068842396135186, "min_ap50_95": .16529868184635887},
        "budgets": {"successful_observations": 5760, "max_formal_calls": 5770, "max_failed_pass_retries": 10,
            "max_warmup_calls": 1, "max_gpu_seconds": 900, "max_inference_wall_seconds": 900, "max_task_wall_seconds": 1800},
        "reference_tolerance": {"confidence_abs": 1e-6, "coordinate_abs": 1e-4, "metric_abs": 1e-9, "rtol": 0},
        "tile_grid": {"x": [0, 512, 1024, 1280], "y": [0, 440], "size": 640},
        "training_performed": False, "test_inference_performed": False, "weight_change": False,
        "automatically_apply_threshold": False, "fallback": "fail_without_changing_protocol",
        "selection_data": "validation_only", "weight_sha256": WEIGHT_SHA}
    checks["fixed_numeric_controls_budget_and_selection_rules"] = contains(protocol, expected_protocol, 0)
    decision_source = read(diagnosis_directory / "decision.json")
    checks["sealed_diagnosis_chooses_medium_supported_slicing"] = (
        decision_source.get("source_task_id") == BASELINE_TASK and decision_source.get("predictions_sha256") == PREDICTIONS_SHA
        and decision_source.get("evidence_id") == f"diagnosis:{DIAGNOSIS_TASK}:640"
        and decision_source.get("selection", {}).get("status") == "stop"
        and decision_source.get("recommendations", {}).get("next_branch") == "sliced_inference_controlled"
        and any(row.get("size_bucket") == "medium" and row.get("gt") == 77 and row.get("candidate_fn") == 52
            and row.get("affected_images") == 51 and row.get("supported") is True
            for row in decision_source["recommendations"]["slicing"]["size_support"]))
    review_source = read(paths["output_root"] / "diagnosis-local-verification.json")
    checks["diagnosis_independent_review_source_bound_passed"] = (
        digest(paths["output_root"] / "diagnosis-local-verification.json") == "8bdbe3a6f7968868c8cfc775f5429bab5004a16176d59c21d2ab1b4a004d6f4c"
        and review_source.get("status") == "passed" and review_source.get("passed_checks") == review_source.get("total_checks") == 61)
    gate = baseline_directory / "geometry_gate" / "gate"
    checks["upstream_geometry_completion_chain"] = publication(gate, "gate", "verify_label_geometry",
        {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"})
    geo = read(gate / "verification_result.json")
    geo_rows = lines(gate / "geometry_details.jsonl")
    checks["upstream_geometry_full_population_and_passed"] = (
        geo.get("status") == "completed" and geo.get("summary", {}).get("verification_status") == "passed"
        and sum(row.get("record_type") == "image" for row in geo_rows) == 4479
        and sum(row.get("record_type") == "annotation" for row in geo_rows) == 3864
        and all(row.get("differences") == [] for row in geo_rows))
    summary = result.get("summary", {})
    checks["configuration_matches_bound_baseline_and_current"] = (
        {k: str(v) for k, v in paths.items()} == {k: str(Path(v).resolve()) for k, v in source_result["configuration"].items()}
        and result.get("configuration") == source_result.get("configuration"))
    source_inputs = read(baseline_directory / "inputs.json")["files"]
    allowed = [ROOT, paths["output_root"], paths["dataset_root"], paths["raw_root"], paths["research_root"], paths["split_dir"],
               Path(source_environment["python_executable"]).parent]
    rows = inputs.get("files", [])
    roles = {row["role"]: row for row in rows}
    checks["input_roles_unique_and_task_identity"] = len(roles) == len(rows) and inputs.get("task_id") == task_id
    mismatches, current_paths = [], set()
    for row in rows:
        path = scoped_file(row["path"], allowed)
        current_paths.add(path)
        actual = digest(path)
        if not (actual == row.get("sha256_before") == row.get("sha256_after") and row.get("unchanged") is True
                and path.stat().st_size == row.get("size_bytes")):
            mismatches.append(row["role"])
    checks["all_current_input_bytes_equal_before_and_after"] = not mismatches and inputs.get("all_unchanged") is True
    parent_mismatch = []
    for row in source_inputs:
        path = scoped_file(row["path"], allowed)
        if (digest(path) != row.get("sha256_before") or row.get("sha256_before") != row.get("sha256_after")
                or row.get("unchanged") is not True or path.stat().st_size != row.get("size_bytes") or path not in current_paths):
            parent_mismatch.append(row["role"])
    checks["all_10256_upstream_inputs_still_valid_and_inherited"] = len(source_inputs) == 10256 and not parent_mismatch
    checks["source_artifacts_and_current_science_code_in_input_manifest"] = (
        {baseline_directory / name for name in BASELINE_FILES | {"completion.json", "artifact_manifest.json"}} <= current_paths
        and {diagnosis_directory / name for name in SOURCE_SHA} <= current_paths
        and {ROOT / "fixtures" / "sliced_protocol.json", ROOT / "defect_researcher" / "sliced_inference.py",
             ROOT / "defect_researcher" / "sliced_task.py", ROOT / "defect_researcher" / "sliced_worker.py",
             ROOT / "defect_researcher" / "sliced_journal.py", ROOT / "tools" / "verify_sliced_journal.py"} <= current_paths)
    # Derive the complete runner input contract without importing its resolver.
    # Source roles retain their original list indices, preventing a resealed
    # subset/renamed duplicate from erasing required provenance.
    expected_roles = {f"source_input/{i}/{r['role']}": Path(r["path"]).resolve() for i, r in enumerate(source_inputs)}
    expected_roles.update({f"source_artifact/{name}": baseline_directory / name
        for name in BASELINE_FILES | {"completion.json", "artifact_manifest.json"}})
    expected_roles.update({"diagnostic_protocol": ROOT / "fixtures" / "diagnosis_protocol.json",
        "diagnostic_runner": ROOT / "defect_researcher" / "diagnosis_task.py",
        "diagnostic_core": ROOT / "defect_researcher" / "detection_diagnosis.py"})
    expected_roles.update({f"diagnosis_artifact/{name}": diagnosis_directory / name
        for name in DIAGNOSIS_FILES | {"completion.json", "artifact_manifest.json"}})
    expected_roles["preregistered/diagnosis_review"] = paths["output_root"] / "diagnosis-local-verification.json"
    for role in protocol["source_evidence_sha256"]:
        if role.startswith("diagnosis/"):
            expected_roles[f"preregistered/{role}"] = diagnosis_directory / role.split("/", 1)[1]
        elif role.startswith("comparison/"):
            expected_roles[f"preregistered/{role}"] = baseline_directory / role.split("/", 1)[1]
    expected_roles.update({"sliced_protocol": ROOT / "fixtures" / "sliced_protocol.json",
        "sliced_runner": ROOT / "defect_researcher" / "sliced_task.py",
        "sliced_worker": ROOT / "defect_researcher" / "sliced_worker.py",
        "sliced_journal": ROOT / "defect_researcher" / "sliced_journal.py",
        "sliced_journal_independent_verifier": ROOT / "tools" / "verify_sliced_journal.py",
        "sliced_core": ROOT / "defect_researcher" / "sliced_inference.py",
        "stratified_statistics": ROOT / "defect_researcher" / "stratified_statistics.py"})
    expected_roles["sliced_independent_verifier"] = Path(__file__).resolve()
    import importlib.util
    for package, relative in (("ultralytics", ("engine/model.py", "engine/predictor.py", "models/yolo/detect/predict.py",
        "utils/ops.py", "utils/nms.py", "data/loaders.py")), ("cv2", ("__init__.py",))):
        spec = importlib.util.find_spec(package)
        root = Path(spec.origin).resolve().parent
        for name in relative:
            expected_roles[f"dependency/{package}/{name}"] = root / name
        if package == "cv2":
            binaries = sorted(root.glob("*.pyd"))
            if not binaries:
                raise ValueError("Bound OpenCV Windows codec is missing")
            for binary in binaries:
                expected_roles[f"dependency/cv2/{binary.name}"] = binary
    checks["all_input_roles_paths_and_dependency_binary_contract_exact"] = (
        roles.keys() == expected_roles.keys()
        and all(Path(roles[role]["path"]).resolve() == path.resolve() for role, path in expected_roles.items()))
    training = read(paths["weights_path"].parent.parent / "experiment_manifest.json")
    dataset = read(paths["dataset_root"] / "manifest.json")
    checks["same_weight_training_and_dataset_provenance"] = (digest(paths["weights_path"]) == WEIGHT_SHA
        and training.get("status") == "completed" and training.get("best_weights_sha256") == WEIGHT_SHA
        and training["training_args"]["imgsz"] == training["actual_training_args"]["imgsz"] == 640
        and training.get("dataset_manifest_sha256") == digest(paths["dataset_root"] / "manifest.json")
        and training.get("data_yaml_sha256") == digest(paths["dataset_root"] / "data.yaml")
        and training.get("dataset_manifest") == dataset)
    data = yaml.safe_load((paths["dataset_root"] / "data.yaml").read_text(encoding="utf-8-sig"))
    checks["dataset_seven_classes_and_val_root"] = (data.get("names") == dict(enumerate(CLASSES))
        and Path(data.get("path", "")).resolve() == paths["dataset_root"] and data.get("val") == "images/val")
    raw_members = [Path(text.strip()).resolve() for text in (paths["split_dir"] / "val.txt").read_text(encoding="utf-8-sig").splitlines() if text.strip()]
    member_ids = sorted(path.stem for path in raw_members)
    old_protocol = read(baseline_directory / "protocol.json")
    checks["all_640_unique_val_members_same_frozen_order"] = (len(raw_members) == len(set(raw_members)) == len(set(member_ids)) == 640
        and member_ids == old_protocol.get("image_ids") == protocol.get("image_ids"))
    checks["validation_disjoint_train_test_buffer"] = all(not set(raw_members) & {
        Path(text.strip()).resolve() for text in (paths["split_dir"] / f"{split}.txt").read_text(encoding="utf-8-sig").splitlines() if text.strip()}
        for split in ("train", "test", "excluded_buffer"))
    checks["all_split_byte_hashes_remain_dataset_bound"] = all(digest(paths["split_dir"] / name) == sha for name, sha in dataset["split_sha256"].items())
    baseline = lines(baseline_directory / "predictions_640.jsonl")
    sliced = lines(directory / "predictions_sliced.jsonl")
    observations = lines(directory / "pass_observations.jsonl")
    checks["baseline_and_candidate_exact_validation_order"] = [r["image_id"] for r in baseline] == [r["image_id"] for r in sliced] == member_ids
    keys = [(row["image_id"], row["pass_id"]) for row in observations]
    checks["all_5760_unique_observations_same_order"] = len(keys) == len(set(keys)) == 5760 and keys == [(image, pi) for image in member_ids for pi in range(9)]
    groups = {image: [] for image in member_ids}
    for row in observations:
        groups[row["image_id"]].append(row)
    expected, image_sha, source_coverage, pixel_valid, coordinate_valid = {}, {}, True, True, True
    for raw in sorted(raw_members, key=lambda p: p.stem):
        raw = scoped_file(raw, [paths["raw_root"]])
        image = scoped_file(paths["dataset_root"] / "images" / "val" / raw.name, [paths["dataset_root"]])
        label = scoped_file(paths["dataset_root"] / "labels" / "val" / f"{raw.stem}.txt", [paths["dataset_root"]])
        metadata = scoped_file(paths["dataset_root"] / "metadata" / "val" / f"{raw.stem}.json", [paths["dataset_root"]])
        image_sha[raw.stem] = digest(image)
        image_array = cv2.imread(str(image), cv2.IMREAD_COLOR)
        if image_array is None or image_array.dtype != np.uint8 or list(image_array.shape) != [1080, 1920, 3]:
            raise ValueError("Decoded image differs from frozen 1920x1080 BGR population")
        decoded_sha = hashlib.sha256(np.ascontiguousarray(image_array).tobytes()).hexdigest()
        meta = read(metadata)
        source_coverage &= ({raw, image, label, metadata} <= current_paths and digest(raw) == image_sha[raw.stem]
            and meta.get("width") == 1920 and meta.get("height") == 1080 and meta.get("image") == raw.relative_to(paths["raw_root"]).as_posix())
        expected[raw.stem] = {"image_id": raw.stem, "width": 1920, "height": 1080, "split": "val", "image_path": str(image),
            "source_path": str(raw), "label_path": str(label), "metadata_path": str(metadata), "ground_truth": source_gt(label, 1920, 1080)}
        for observation in groups[raw.stem]:
            pi = observation["pass_id"]
            crop = expected_crops()[pi]
            x, y, r, b = crop
            tile_sha = hashlib.sha256(np.ascontiguousarray(image_array[y:b, x:r]).tobytes()).hexdigest()
            pixel_valid &= (same(observation.get("crop"), crop, 0) and all(type(v) is int for v in observation.get("crop", []))
                and observation.get("source_image_sha256") == image_sha[raw.stem]
                and observation.get("decoded_image_sha256") == decoded_sha and observation.get("input_pixels_sha256") == tile_sha
                and observation.get("orig_shape") == [b - y, r - x])
            local = observation.get("local_predictions", [])
            coordinate_valid &= len(local) <= 300 and same(observation.get("global_predictions"), map_predictions(local, crop, pi), 0)
    checks["current_image_bytes_pixels_and_label_metadata_input_coverage"] = source_coverage
    checks["frozen_crops_and_every_decoded_tile_pixel_hash"] = pixel_valid
    checks["complete_post_nms_lists_and_local_to_global_coordinates"] = coordinate_valid
    checks["both_arms_original_label_gt_exact"] = all(contains(row, expected[row["image_id"]], 0) for row in baseline + sliced)
    checks["baseline_596_gt_245_normal_77_medium_74_medium_images"] = (
        sum(len(r["ground_truth"]) for r in expected.values()) == 596
        and sum(not r["ground_truth"] for r in expected.values()) == 245
        and sum(bucket(g["xyxy"]) == "medium" for r in expected.values() for g in r["ground_truth"]) == 77
        and sum(any(bucket(g["xyxy"]) == "medium" for g in r["ground_truth"]) for r in expected.values()) == 74)
    checks["same_recorded_dependency_versions_and_backend"] = all(environment.get(key) == source_environment.get(key)
        for key in ("python", "python_executable", "torch", "ultralytics", "cuda", "cudnn", "gpu_name", "gpu_total_bytes"))
    checks["actual_fp32_tensor_model_cuda_and_tf32_disabled"] = contains(environment, {
        "device": "0", "precision": "FP32", "actual_input_dtype": "torch.float32", "actual_input_device": "cuda:0",
        "model_parameters_dtype": "torch.float32", "tf32_matmul": False, "tf32_cudnn": False,
        "cudnn_benchmark": False, "cudnn_deterministic": True, "actual_predictor_fp16": False,
        "actual_predictor_imgsz": [640, 640], "actual_predictor_device": "cuda:0"}, 0)
    checks["same_actual_predictor_controls"] = (same(environment.get("actual_predictor_options"), source_environment.get("actual_predictor_options"), 0)
        and contains(environment.get("actual_predictor_options", {}), CONTROLS, 0))
    checks["every_observation_actual_controls_fp32_and_positive_timing"] = all(
        contains(r.get("effective_options", {}), CONTROLS, 0) and same(r["effective_options"], environment["actual_predictor_options"], 0)
        and r.get("device") == "cuda:0" and r.get("precision") == "FP32" and r.get("model_parameters_dtype") == "torch.float32"
        and r.get("actual_input_dtype") == "torch.float32" and r.get("actual_input_device") == "cuda:0"
        and finite(r.get("elapsed_seconds"), True) and finite(r.get("gpu_seconds"), True)
        and set(r.get("ultralytics_speed_ms", {})) == {"preprocess", "inference", "postprocess"}
        and all(finite(v) for v in r["ultralytics_speed_ms"].values()) for r in observations)
    source_names = {"YOLO.predict", "BasePredictor.pre_transform", "BasePredictor.preprocess", "BasePredictor.setup_source",
                    "BasePredictor.inference", "DetectionPredictor.postprocess", "scale_boxes", "NMS"}
    callable_sources = environment.get("callable_sources", {})
    checks["current_dependency_sources_hash_bound_and_current_codec"] = (set(callable_sources) == source_names
        and environment.get("cv2") == cv2.__version__ and environment.get("legacy_dependency_source_hashes_available") is False
        and all((path := scoped_file(row["path"], allowed)).stat().st_size == row.get("size_bytes")
            and digest(path) == row.get("sha256") and path in current_paths for row in callable_sources.values()))
    checks["context_path_tile_bgr_no_alternative_predict_entry"] = contains(environment, {
        "prediction_entry": "YOLO.predict", "context_source_type": "original_path",
        "tile_source_type": "cv2_decoded_BGR_contiguous_ndarray"}, 0)
    checks["all_observations_bound_protocol_and_weight"] = all(r.get("protocol_sha256") == digest(ROOT / "fixtures" / "sliced_protocol.json")
        and r.get("weight_sha256") == WEIGHT_SHA for r in observations)
    scientific_identity = canonical_sha({r["role"]: {"path": r["path"], "sha256": r["sha256_before"], "size_bytes": r["size_bytes"]} for r in rows})
    execution_roles = {"sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
        "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier"}
    execution_sha = canonical_sha({r["role"]: {"path": r["path"], "sha256": r["sha256_before"], "size_bytes": r["size_bytes"]}
                                  for r in rows if r["role"] in execution_roles})
    evidence = {"source_task_id": BASELINE_TASK, "diagnosis_task_id": DIAGNOSIS_TASK,
        "source_completion_sha256": digest(baseline_directory / "completion.json"),
        "source_manifest_sha256": digest(baseline_directory / "artifact_manifest.json"),
        "source_predictions_sha256": PREDICTIONS_SHA, "diagnosis_completion_sha256": digest(diagnosis_directory / "completion.json"),
        "protocol_sha256": digest(ROOT / "fixtures" / "sliced_protocol.json"), "evidence_id": f"sliced:{task_id}:hybrid640"}
    checks["full_input_snapshot_identity_bound_across_protocol_and_passes"] = (
        protocol.get("scientific_inputs_sha256") == scientific_identity
        and all(r.get("scientific_inputs_sha256") == scientific_identity for r in observations)
        and contains(result.get("evidence", {}), evidence, 0) and contains(inputs, evidence, 0)
        and contains(protocol, {**{k: v for k, v in evidence.items() if k != "evidence_id"},
                               "task_evidence_id": evidence["evidence_id"], "task_id": task_id}, 0)
        and contains(read(directory / marker_name), evidence, 0))
    request = read(directory / "worker_request.json")
    checks["worker_request_has_only_exact_val_source_and_frozen_controls"] = (
        Path(request.get("directory", "")).resolve() == directory and same(request.get("protocol"), read(ROOT / "fixtures" / "sliced_protocol.json"), 0)
        and same(request.get("records"), baseline, 0) and Path(request.get("weights_path", "")).resolve() == paths["weights_path"]
        and request.get("protocol_sha256") == evidence["protocol_sha256"] and request.get("scientific_inputs_sha256") == scientific_identity
        and request.get("execution_source_sha256") == execution_sha
        and type(request.get("execution_io_version")) is int and request["execution_io_version"] == 2
        and same(request.get("reference_environment"), source_environment, 0)
        and request.get("image_sha256") == image_sha)
    environment_identity = canonical_sha({k: v for k, v in environment.items() if k != "peak_allocated_bytes"})
    checks["all_observations_same_environment_identity"] = all(r.get("environment_identity") == environment_identity for r in observations)
    trace_rows = lines(directory / "fusion_details.jsonl")
    checks["fusion_trace_full_unique_ordered_population"] = [r["image_id"] for r in trace_rows] == member_ids
    by_id = {r["image_id"]: r for r in sliced}
    fusion_valid = True
    for trace in trace_rows:
        predictions, expected_fusion = expected_trace(groups[trace["image_id"]])
        fusion_valid &= contains(trace.get("trace", {}), expected_fusion, 1e-12) and same(by_id[trace["image_id"]]["predictions"], predictions, 0)
        fusion_valid &= trace.get("candidate_count") == len(expected_fusion["rows"]) and trace.get("final_count") == len(predictions)
    checks["independent_same_class_nms_strict_gt_point7_ties_maxdet_and_full_trace"] = fusion_valid
    context = [{**row, "predictions": groups[row["image_id"]][0]["local_predictions"]} for row in baseline]
    counts_equal = True
    confidence_difference = coordinate_difference = 0.
    for a, b in zip(baseline, context):
        counts_equal &= len(a["predictions"]) == len(b["predictions"])
        for p, q in zip(a["predictions"], b["predictions"]):
            counts_equal &= p["class_id"] == q["class_id"]
            confidence_difference = max(confidence_difference, abs(p["confidence"] - q["confidence"]))
            coordinate_difference = max(coordinate_difference, *(abs(x - y) for x, y in zip(p["xyxy"], q["xyxy"])))
    baseline_score, context_score, sliced_score = metrics(baseline), metrics(context), metrics(sliced)
    metric_difference = {key: abs(context_score[key] - baseline_score[key]) for key in ("mAP50", "mAP50_95")}
    reuse = read(directory / "context_reuse.json")
    checks["full_640_context_reuse_gate_independently_recomputed"] = (counts_equal and confidence_difference <= 1e-6
        and coordinate_difference <= 1e-4 and max(metric_difference.values()) <= 1e-9
        and same(context_score["operating_point"], baseline_score["operating_point"], 0))
    checks["context_reuse_declared_gate_matches_derived_evidence"] = contains(reuse, {"status": "passed",
        "maximum_confidence_abs_difference": confidence_difference, "maximum_coordinate_abs_difference": coordinate_difference,
        "metric_abs_difference": max(metric_difference.values()), "samples_matched": 640, "count_order_class_equal": True,
        "operating_counts_equal": True, "rtol": 0, "source_predictions_sha256": PREDICTIONS_SHA}, 1e-12)
    checks["baseline_independent_ap101_matches_old_and_new_saved"] = (
        contains(read(baseline_directory / "metrics_640.json"), baseline_score) and contains(read(directory / "metrics_baseline.json"), baseline_score))
    checks["sliced_independent_ap101_tp_fp_fn_normalfp_matches_saved"] = contains(read(directory / "metrics_sliced.json"), sliced_score)
    analysis = comparison(baseline, sliced, protocol)
    saved_analysis = read(directory / "sliced_comparison.json")
    for label, key in (("population", "population"), ("correct_gt_recall_and_prediction_precision_strata", "stratified_statistics"),
                       ("all_21_class_size_cells_including_null_and_support", "class_size"),
                       ("all_seven_classes_original_gt_recall_and_transitions", "per_class_gt"),
                       ("normal_images_false_positive_images_boxes_and_rates", "normal_false_positives"),
                       ("all_640_paired_image_rows_and_medium_denominators", "per_image"),
                       ("all_596_gt_recovery_and_loss_provenance", "gt_transitions"),
                       ("net_gain_vs_recovered_and_lost_counts", "gains"),
                       ("paired_image_395_bootstrap_and_metric_deltas", "paired_comparison"),
                       ("paired_medium_74_image_bootstrap", "paired_medium_recall"),
                       ("frozen_scientific_gates_stop_or_accepted", "scientific_decision")):
        checks[label] = contains(saved_analysis.get(key), analysis[key])
    diagnosis_gt = {(r["image_id"], r["gt_index"]): r for r in lines(diagnosis_directory / "gt_details.jsonl")}
    checks["each_original_gt_transition_linked_to_diagnosis"] = all(
        (r["image_id"], r["gt_index"]) in diagnosis_gt
        and same(diagnosis_gt[r["image_id"], r["gt_index"]]["xyxy"], r["xyxy"], 0)
        and diagnosis_gt[r["image_id"], r["gt_index"]]["class_id"] == r["class_id"]
        and diagnosis_gt[r["image_id"], r["gt_index"]]["status"] == r["baseline_status"]
        for r in analysis["gt_transitions"])
    final_decision = read(directory / "decision.json")
    checks["published_scientific_decision_matches_nine_frozen_gates"] = (
        contains(final_decision.get("scientific_decision", final_decision), analysis["scientific_decision"])
        and final_decision.get("parent_evidence_id") == protocol["evidence_id"]
        and final_decision.get("evidence_id") == f"sliced:{task_id}:hybrid640"
        and final_decision.get("execution_and_evidence_gates_passed") is True
        and final_decision.get("automatically_applied") is False)
    # Budget/checkpoint contracts are verified below; hardware timings remain
    # recorded evidence rather than a second independent GPU measurement.
    journal_identity = {"protocol_sha256": evidence["protocol_sha256"], "weight_sha256": WEIGHT_SHA,
        "scientific_inputs_sha256": scientific_identity, "execution_source_sha256": execution_sha,
        "journal_source_sha256": digest(ROOT / "defect_researcher" / "sliced_journal.py")}
    _budget_checks(checks, budget, observations, directory, protocol, environment, journal_identity)
    events = lines(directory / "events.jsonl")
    stamps = [datetime.fromisoformat(row["at"]) for row in events]
    checks["events_ordered_and_completion_published_last"] = (bool(stamps) and stamps == sorted(stamps)
        and events[-1].get("stage") == "artifact_publication" and events[-1].get("completion_published_last") is True
        and not any(row.get("status") == "failed" for row in events))
    checks["no_training_test_inference_threshold_search_or_weight_change"] = (summary.get("training_performed") is False
        and summary.get("test_inference_performed") is False and summary.get("same_weight") is True
        and summary.get("split") == "val" and summary.get("input_hashes_unchanged") is True
        and saved_analysis["scientific_decision"].get("threshold_search_performed") is False)
    checks["summary_independent_metric_counts_and_branch_match"] = (
        contains(summary.get("metrics", {}).get("baseline"), {k: baseline_score[k] for k in ("mAP50", "mAP50_95", "operating_point")})
        and contains(summary.get("metrics", {}).get("sliced"), {k: sliced_score[k] for k in ("mAP50", "mAP50_95", "operating_point")}))
    checks["total_task_wall_includes_source_and_publication_within_budget"] = (
        finite(summary.get("total_task_wall_seconds"), True) and budget["task_wall_seconds"] <= summary["total_task_wall_seconds"] <= 1800
        and (datetime.fromisoformat(result["finished_at"]) - datetime.fromisoformat(result["started_at"])).total_seconds() <= 1800)
    checks["current_images_unchanged_during_independent_pixel_review"] = all(digest(Path(expected[image]["image_path"])) == sha for image, sha in image_sha.items())
    review_seconds = time.perf_counter() - review_clock
    if prepublication:
        acceptance_total_wall = max(time.time() - budget["task_started_epoch"], summary.get("total_task_wall_seconds", 0) + review_seconds)
    else:
        # Later read-only reviews must not consume the original experiment's
        # wall budget again. Verify the bound prepublication cost receipt.
        prior_path = result.get("evidence", {}).get("independent_verification_path")
        prior_path = scoped_file(prior_path or paths["output_root"] / "sliced-prepublication" / f"{task_id}.json", [paths["output_root"]])
        prior = read(prior_path)
        checks["original_prepublication_receipt_completed_and_candidate_bound"] = prepublication_receipt_valid(prior, task_id, {
            "task_completion_sha256": digest(directory / marker_name),
            "task_manifest_sha256": digest(directory / "artifact_manifest.json"),
            "task_protocol_sha256": digest(directory / "protocol.json"),
            "source_completion_sha256": digest(baseline_directory / "completion.json"),
            "diagnosis_completion_sha256": digest(diagnosis_directory / "completion.json")})
        acceptance_total_wall = prior.get("acceptance_total_wall_seconds")
    checks["independent_review_included_in_total_1800_second_acceptance_budget"] = finite(acceptance_total_wall, True) and acceptance_total_wall <= 1800
    checks["prepublication_final_marker_absent_or_same_candidate_bytes"] = (
        not (directory / "completion.json").exists() if prepublication else
        (directory / "completion_candidate.json").is_file() and digest(directory / "completion.json") == digest(directory / "completion_candidate.json"))
    return {"schema_version": 1, "kind": "independent_saved_nine_pass_slicing_crosscheck", "task_id": task_id,
        "status": "passed" if all(checks.values()) else "failed", "reviewed_at": datetime.now(timezone.utc).isoformat(),
        "prepublication": prepublication, "review_started_at": review_started_at,
        "review_finished_at": datetime.now(timezone.utc).isoformat(), "review_seconds": review_seconds,
        "acceptance_total_wall_seconds": acceptance_total_wall,
        "model_used": False, "gpu_inference_performed_by_reviewer": False,
        "checks": checks, "passed_checks": sum(checks.values()), "total_checks": len(checks),
        "source_files_checked": len(rows), "source_mismatches": mismatches, "parent_source_mismatches": parent_mismatch,
        "task_completion_sha256": digest(directory / marker_name),
        "completion_candidate_sha256": digest(directory / "completion_candidate.json"),
        "task_manifest_sha256": digest(directory / "artifact_manifest.json"), "task_protocol_sha256": digest(directory / "protocol.json"),
        "source_completion_sha256": digest(baseline_directory / "completion.json"),
        "diagnosis_completion_sha256": digest(diagnosis_directory / "completion.json"),
        "scientific_status": analysis["scientific_decision"]["status"], "failed_scientific_gates": analysis["scientific_decision"]["failed_gates"],
        "population": analysis["population"], "baseline": {k: baseline_score[k] for k in ("mAP50", "mAP50_95", "operating_point")},
        "sliced": {k: sliced_score[k] for k in ("mAP50", "mAP50_95", "operating_point")}, "gains": analysis["gains"],
        "limitations": ["Matching, AP101, fusion and paired statistics are separately implemented; no project scientific scorer is imported.",
            "Post-NMS evidence cannot prove completeness of the detector's internal pre-NMS candidates.",
            "Saved hardware times and effective settings are checked for consistency; GPU inference is not repeated.",
            "Legacy baseline lacks decoder version and dependency source hashes; all-image context output reuse is independently checked.",
            "Completion mtime order supports local publication order and is not cryptographic execution proof.",
            "The sealed summary stores wall time before independent review; final cumulative acceptance cost is recorded here and the parent enforces publication deadline.",
            "Image bootstrap is descriptive and does not remove correlation between cable frames or physical defects.",
            "Validation-only joint context/tile/fusion result does not prove held-out gain, causal scale effect or deployment readiness."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--config")
    parser.add_argument("--baseline", type=Path)
    parser.add_argument("--diagnosis", type=Path)
    parser.add_argument("--task-dir", type=Path)
    parser.add_argument("--prepublication", action="store_true", help="Verify completion_candidate.json before the final marker is published")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(ROOT))
    from defect_researcher.config import load_config
    configuration = load_config(args.config)
    positional = Path(args.task_id)
    if positional.is_dir():
        task_id, directory = positional.resolve().name, positional.resolve()
    else:
        task_id, directory = args.task_id, args.task_dir or Path(configuration["output_root"]) / args.task_id
    if args.output.resolve().is_relative_to(directory.resolve()):
        parser.error("Independent report must be outside the sealed task directory")
    try:
        report = review(configuration, task_id, directory, args.baseline, args.diagnosis, prepublication=args.prepublication)
    except Exception as error:
        report = {"status": "failed", "task_id": task_id,
                  "error": {"type": type(error).__name__, "message": str(error)}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({key: report.get(key) for key in ("status", "task_id", "passed_checks", "total_checks", "error")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
