// Read-only AGH connection and catalog diagnosis. No model or domain tool call.
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const helperPath = fileURLToPath(import.meta.url);
const projectRoot = resolve(dirname(helperPath), '..');
const harnessRoot = resolve(projectRoot, '..', 'agnes-harness');
const tracePath = resolve(projectRoot, 'outputs/research-mcp-local-acceptance-v1/registration-continued.json');
const outputPath = resolve(projectRoot, 'outputs/research-mcp-local-acceptance-v1/agh-native-connect.json');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const traceBytes = await readFile(tracePath);
const definition = JSON.parse(traceBytes.toString('utf8')).definition;
if (definition.serverId !== 'defect-researcher-workflow-v1' || definition.transport.kind !== 'stdio'
    || definition.secretBinding.kind !== 'none') throw new Error('Unexpected diagnosis scope');
const { connectMcp } = await import(pathToFileURL(resolve(harnessRoot, 'packages/base/src/mcp/connect.ts')).href);
const { inspectRemoteCatalog } = await import(pathToFileURL(resolve(harnessRoot, 'packages/base/src/mcp/register.ts')).href);
const configuration = { id: definition.serverId, transport: 'stdio',
  cmd: [definition.transport.executable, ...definition.transport.args],
  baseEnv: {}, allowedTools: definition.toolPolicy.allow, defer: false };
const report = { schema_version: 1, started_at: new Date().toISOString(),
  interface: 'AGH connectMcp + inspectRemoteCatalog', configuration, cwd: process.cwd(),
  scope: 'local_stdio_handshake_and_catalog_only', new_model_requests: 0,
  domain_tool_calls: 0, credentials_read: false, frozen_source_changes: 0,
  source_trace: { path: tracePath, sha256: sha(traceBytes) },
  helper: { path: helperPath, sha256: sha(await readFile(helperPath)) } };
let connection;
try {
  connection = await connectMcp(configuration);
  const catalog = await inspectRemoteCatalog(connection, configuration);
  report.status = 'passed';
  report.tool_names = catalog.tools.map(tool => tool.name);
  report.skipped = catalog.skipped;
  if (JSON.stringify(report.tool_names) !== JSON.stringify(definition.toolPolicy.allow)
      || report.skipped.length !== 0) throw new Error('Native catalog differs from fixed two-tool scope');
} catch (error) {
  report.status = 'failed';
  report.error = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  if (connection) await connection.close();
  report.finished_at = new Date().toISOString();
  await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n', { encoding: 'utf8', flag: 'wx' });
}
console.log(JSON.stringify({ status: report.status, output: outputPath,
  tool_names: report.tool_names, new_model_requests: 0, domain_tool_calls: 0 }));
