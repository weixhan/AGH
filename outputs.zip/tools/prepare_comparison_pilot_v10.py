"""Preregister a fresh two-branch stage without arming or invoking any model."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os

from defect_researcher.comparison_protocol_v1 import make_protocol
from defect_researcher.comparison_mcp_server_v9 import _tools
from defect_researcher.comparison_case_runtime_v1 import Runtime
from tools.verify_comparison_model_v10 import (
    NEW_PHASE_BUDGET, MODEL_ACCOUNTING, HISTORICAL_PRIOR_STAGE, V9_FREEZE_SHA256,
    validate_stage_ledger,
)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/comparison-pilot-v10"
IMPLEMENTATION = ROOT / "outputs/comparison-implementation-v10"
STAGE_ID = "cmp-pilot-20261013-10"
SELECTED_CASES = ["repair_coordinates", "refuse_source_hash"]
NEW_SOURCES = [
    "tools/prepare_comparison_pilot_v10.py", "tools/verify_comparison_model_v10.py",
    "tests/test_comparison_model_verifier_v10.py", "tools/comparison_scope_guard_v10.mjs",
    "tools/test_comparison_scope_guard_v10.mjs", "tools/prepare_comparison_scope_v10.mjs",
    "tools/enable_comparison_scope_v10.mjs", "tools/activate_comparison_mcp_v10.mjs",
    "tools/run_comparison_pilot_v10.mjs", "tools/comparison_branch_selection_v10.mjs",
    "tools/test_comparison_branch_selection_v10.mjs", "tools/verify_comparison_runtime_v10.py",
    "tests/test_comparison_runtime_v10.py", "tools/capture_comparison_runtime_v10.ps1",
    "tools/generate_comparison_stage_v10.py", "tools/close_comparison_branches_v10.py",
    "tests/test_comparison_closure_v10.py",
    "agent/修改版两分支联合诊断协议V10.md",
    "outputs/comparison-implementation-v9/freeze.json",
    "outputs/comparison-implementation-v9/source_lock.json",
    "outputs/comparison-pilot-v9/final_closure_verification.json",
    "outputs/comparison-pilot-v9/runtime_closure_audit.json",
    "outputs/comparison-pilot-v10/server-config.json",
    "outputs/comparison-implementation-v10/local-tests-final.json",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path), "size_bytes": path.stat().st_size}


def read(path):
    return json.loads(Path(path).read_text("utf8"))


def save(path, value):
    with Path(path).open("x", encoding="utf8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def check_history():
    history = []
    specs = [
        ("research-workflow-implementation-v1/freeze.json", ("sources", "archive", "preserved_files")),
        ("research-mcp-implementation-v2/freeze.json", ("sources", "archive", "proof_files")),
        ("comparison-implementation-v6/freeze.json", ("sources", "archive", "proof_files")),
        ("comparison-implementation-v7/freeze.json", ("sources", "archive", "proof_files")),
        ("comparison-implementation-v8/freeze.json", ("sources", "archive", "proof_files")),
        ("comparison-implementation-v9/freeze.json", ("sources", "archive", "proof_files")),
    ]
    for name, groups in specs:
        path = ROOT / "outputs" / name
        frozen = read(path)
        rows = [row for group in groups for row in frozen[group]]
        if any(sha(row["path"]) != row["sha256"] for row in rows):
            raise ValueError("Protected history changed: " + name)
        if name == "comparison-implementation-v9/freeze.json":
            if sha(path) != V9_FREEZE_SHA256 or len(rows) != 537 or frozen["status"] != "failed_diagnostic_preserved":
                raise ValueError("Original V9 failure or protected member identity changed")
        history.append({"freeze": record(path), "checked_records": len(rows), "unchanged": True,
                        "original_status_preserved": frozen["status"]})
    closure = read(ROOT / "outputs/comparison-pilot-v9/final_closure_verification.json")
    if (closure["status"] != "passed_preservation_not_modified_runtime_execution_acceptance"
            or closure["request_slots_debited"] != 46 or closure["phase_cap"] != 48
            or closure["original_v8_usage_unknown"] is not True):
        raise ValueError("Historical failure and unknown usage were not preserved")
    return history


def main():
    # Validate every dependency and old binding before creating any new record.
    old_lock = ROOT / "outputs/comparison-implementation-v9/source_lock.json"
    baseline = read(old_lock)["files"]
    for item in baseline:
        if sha(item["path"]) != item["sha256"]:
            raise ValueError("V9 baseline source changed: " + item["path"])
    paths = list(dict.fromkeys([str(Path(row["path"]).relative_to(ROOT)) for row in baseline] + NEW_SOURCES))
    for name in paths:
        if not (ROOT / name).is_file():
            raise ValueError("Required V10 source or test receipt is absent: " + name)
    if read(IMPLEMENTATION / "local-tests-final.json").get("status") != "passed":
        raise ValueError("V10 local tests have not passed")
    history = check_history()
    runtime_path = ROOT / "outputs/agh-title-repair-v1/repair_verification.json"
    repaired = read(runtime_path)
    if repaired.get("status") != "passed_local_repair" or repaired.get("agh_core_modified") is not True:
        raise ValueError("Modified AGH local repair has not passed")
    for row in repaired["runtime_files"]:
        if sha(row["path"]) != row["sha256"] or sha(row["archive"]) != row["sha256"]:
            raise ValueError("Modified AGH differs from the tested runtime")
    # Reject existing registration/output rather than resetting original budgets.
    generated = [IMPLEMENTATION / "source_lock.json"] + [OUT / name for name in
                 ("stage_ledger.json", "protocol.json", "model_protocol.json", "preflight.json")]
    if any(path.exists() for path in generated):
        raise FileExistsError("V10 is already registered; no overwrite or resume is allowed")
    config = read(OUT / "server-config.json")
    if Path(config["output_root"]).resolve() != (OUT / "runtime").resolve():
        raise ValueError("V10 server must write only its new runtime directory")
    if (OUT / "runtime").exists():
        raise FileExistsError("New runtime directory already exists")
    stage = {
        "schema_version": 1, "kind": "comparison_stage_preregistration_v10",
        "status": "preregistered_not_executed", "stage_id": STAGE_ID,
        "registered_at": datetime.now(timezone.utc).isoformat(),
        "authorization": {"user_message": "依次完成未完成项",
            "scope": "fresh_modified_runtime_two_branch_joint_acceptance", "new_stage_model_request_cap": 14},
        "counting_unit": "application_provider_invocation_not_HTTP_transmission",
        "phase_model_budget": NEW_PHASE_BUDGET, "model_accounting": MODEL_ACCOUNTING,
        "historical_prior_stage": HISTORICAL_PRIOR_STAGE,
        "case_ids": SELECTED_CASES, "arm": "F", "domain_invocations_per_trial": 6,
        "per_action_approval": "Allow once", "no_original_session_resume_or_deadline_reset": True,
        "model_calls_actual": 0, "new_detector_calls": 0, "new_training_runs": 0, "gpu_seconds": 0,
        "protected_history": history,
        "scope": "Fresh two-branch runtime diagnostic; not the nine-case or formal comparison",
    }
    validate_stage_ledger(stage)
    stage_path = OUT / "stage_ledger.json"
    save(stage_path, stage)
    paths.append(str(stage_path.relative_to(ROOT)))
    members = [record(ROOT / path) for path in paths]
    lock = IMPLEMENTATION / "source_lock.json"
    save(lock, {"schema_version": 1, "kind": "comparison_case_implementation_v1", "status": "passed",
                "scope": "Locally tested V10; all executions initially zero", "files": members})
    catalogue = [{key: row[key] for key in ("name", "description", "inputSchema")} for row in _tools()]
    protocol = make_protocol(STAGE_ID,
        model={"slot": "primary", "model": "agnes-3.0-flash", "route": "account-defect-researcher"},
        task_prompt=(ROOT / "agent/comparison_case_task_v4.md").read_text("utf8"), tool_catalog=catalogue,
        source_paths={path: ROOT / path for path in paths},
        generation_settings={"explicit_overrides": {}, "runtime_defaults_shared": True}, stage="pilot")
    selected = [row for row in protocol["trials"] if row["arm"] == "F" and row["case_id"] in SELECTED_CASES]
    if [row["case_id"] for row in selected] != SELECTED_CASES:
        raise ValueError("Protocol order does not match repair then refusal")
    save(OUT / "protocol.json", protocol)
    selection = {"schema_version": 1, "arm": "F", "case_ids": SELECTED_CASES,
                 "trial_handles": [row["trial_handle"] for row in selected]}
    selection_hash = hashlib.sha256(json.dumps(selection, sort_keys=True, ensure_ascii=False,
                                  separators=(",", ":")).encode("utf8")).hexdigest()
    suffix = hashlib.sha256(b"dr-compare-v10").hexdigest()[:8]
    public = {
        "schema_version": 1, "protocol_path": str(OUT / "protocol.json"),
        "protocol_sha256": sha(OUT / "protocol.json"), "source_lock": {"path": str(lock), "sha256": sha(lock)},
        "server_config": str(OUT / "server-config.json"), "server_id": "dr-compare-v10",
        "scope_policy": {"schema_version": 1, "workspace_root": str(OUT / "workspace"),
            "qualified_action_tool": "mcp_dr_compare_v10_" + suffix + "_execute_case_action_v1",
            "allowed_handles": selection["trial_handles"], "max_model_requests": 6,
            "max_wall_seconds": 120, "max_action_calls": 8},
        "stage_ledger": record(stage_path), "runtime_version": record(runtime_path),
        "phase_model_budget": NEW_PHASE_BUDGET,
        "engineering_diagnostic": {"selected_trial_count": 2,
            "selected_trials": [{key: row[key] for key in ("trial_id", "trial_handle", "case_id", "arm")} for row in selected],
            "selection": selection, "selection_sha256": selection_hash, "planned_comparison_trials": 9,
            "purpose": "Fresh repair and refusal joint acceptance after complete modified runtime reload"},
        "model_accounting": MODEL_ACCOUNTING,
        "route_limitations": [
            "Only two F trials may arm; the other seven registered positions remain unarmed",
            "The native action catalogue omits SDK annotations; action description/schema are common",
            "Independent checks do not resume sessions or extend their original deadlines",
            "Loaded daemon/worker and trusted native diagnostics require separate runtime acceptance",
            "The failed V9 execution and legacy unknown token usage remain preserved"],
    }
    save(OUT / "model_protocol.json", public)
    os.environ["DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH"] = str(lock)
    os.environ["DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256"] = sha(lock)
    runtime = Runtime(config_path=OUT / "server-config.json")
    registrations = []
    for trial in protocol["trials"]:
        runtime.prepare(trial["trial_id"], trial["case_id"], trial["arm"], trial_handle=trial["trial_handle"])
        registrations.append(read(runtime.root / "trials" / trial["trial_handle"] / "registration.json"))
    same = all(all(row["input_snapshot"] == group[0]["input_snapshot"]
                   and row["prepared_case"]["case_root"] == group[0]["prepared_case"]["case_root"] for row in group)
               for case in protocol["case_ids"] for group in [[row for row in registrations if row["case_id"] == case]])
    if not same or list(runtime.root.rglob("arm.json")):
        raise ValueError("Input paths/bytes differ or a trial was prematurely armed")
    save(OUT / "preflight.json", {"schema_version": 1, "status": "passed", "planned_trials": 9,
        "planned_per_arm": 3, "selected_trial_count": 2, "same_input_paths_and_bytes": same,
        "registered_handles": [row["trial_handle"] for row in registrations], "all_trials_unarmed": True,
        "model_calls_actual": 0, "new_detector_calls": 0, "gpu_seconds": 0,
        "source_lock": public["source_lock"], "stage_ledger": public["stage_ledger"],
        "protocol_sha256": sha(OUT / "protocol.json"), "protected_history": history,
        "route_limitations": public["route_limitations"]})
    print(json.dumps({"status": "preregistered_not_executed", "planned_trials": 9,
        "selected_trial_count": 2, "model_calls_actual": 0, "same_input_paths_and_bytes": same}))


if __name__ == "__main__":
    main()
