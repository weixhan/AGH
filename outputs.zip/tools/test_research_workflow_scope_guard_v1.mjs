import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createResearchWorkflowScopeGuard} from './research_workflow_scope_guard_v1.mjs';
const policy={schema_version:1,workspace_root:'E:/project/workspace',
  qualified_start_tool:'mcp_dr_workflow_v1_a78bff84_run_bounded_research_workflow_v1',
  qualified_status_tool:'mcp_dr_workflow_v1_a78bff84_get_research_workflow_status_v1',request_id:'agnes-v1',
  workflow_id:'research-workflow-v1-agnes-v1',case_id:'repair_coordinates',
  budget:{domain_invocations:6,wall_seconds:120,gpu_seconds:0,model_requests:0},
  max_start_calls:1,max_status_calls:6,max_model_requests:8,max_wall_seconds:120};
const context={session:{key:'first',workspaceRoot:'E:\\project\\workspace'}};
const request={slot:'primary',model:'agnes-3.0-flash'};
const start={name:policy.qualified_start_tool,toolUseId:'start',args:{request_id:policy.request_id,case_id:policy.case_id,budget:policy.budget}};
const status=id=>({name:policy.qualified_status_tool,toolUseId:id,args:{workflow_id:policy.workflow_id}});
const result=(value={workflow_id:policy.workflow_id,status:'running'})=>({toolUseId:'start',result:{isError:false,content:[{type:'text',text:JSON.stringify(value)}]}});
function prepared() {const guard=createResearchWorkflowScopeGuard(policy);assert.equal(guard.before_request(request,context).allow,true);return guard;}
test('fixed start then same-ID reads only after actual start result',()=>{
 const guard=prepared();assert.equal(guard.tool_call(status('early'),context).allow,false);
 assert.equal(guard.tool_call(start,context).allow,true);guard.tool_result(result(),context);
 assert.equal(guard.tool_call(status('read'),context).allow,true);
});
test('notifications or user calls before model request cannot execute',()=>{
 const guard=createResearchWorkflowScopeGuard(policy);assert.equal(guard.tool_call(start,context).allow,false);
});
test('alternate arguments, cases, budgets and shell tools are blocked',()=>{
 const guard=prepared();
 for(const value of [{...start,args:{...start.args,path:'E:/data'}},{...start,args:{...start.args,case_id:'normal_unrotated'}},
  {...start,args:{...start.args,budget:{...policy.budget,wall_seconds:121}}},{...start,name:'exec'}])
  assert.equal(guard.tool_call(value,context).allow,false);
 assert.equal(guard.tool_call(start,context).allow,true);
});
test('one start and call identities cannot repeat',()=>{
 const guard=prepared();assert.equal(guard.tool_call(start,context).allow,true);
 assert.equal(guard.tool_call(start,context).allow,false);
 assert.equal(guard.tool_call({...start,toolUseId:'second'},context).allow,false);
});
test('six reads exhaust the explicit tool budget',()=>{
 const guard=prepared();guard.tool_call(start,context);guard.tool_result(result(),context);
 for(let i=0;i<6;i++)assert.equal(guard.tool_call(status('read'+i),context).allow,true);
 assert.equal(guard.tool_call(status('read-extra'),context).allow,false);
});
test('wrong, failed or malformed start results do not authorize status',()=>{
 for(const value of [{workflow_id:'research-workflow-v1-other',status:'running'},{workflow_id:policy.workflow_id,status:'failed'}]){
  const guard=prepared();guard.tool_call(start,context);guard.tool_result(result(value),context);
  assert.equal(guard.tool_call(status('read'),context).allow,false);
 }
 const guard=prepared();guard.tool_call(start,context);guard.tool_result({toolUseId:'start',result:{isError:false,content:[{type:'text',text:'invalid'}]}},context);
 assert.equal(guard.tool_call(status('read'),context).allow,false);
});
test('wrong IDs, extra status args and duplicate reads are rejected',()=>{
 const guard=prepared();guard.tool_call(start,context);guard.tool_result(result(),context);
 assert.equal(guard.tool_call({...status('wrong'),args:{workflow_id:'other'}},context).allow,false);
 assert.equal(guard.tool_call({...status('extra'),args:{workflow_id:policy.workflow_id,path:'other'}},context).allow,false);
 assert.equal(guard.tool_call(status('right'),context).allow,true);
 assert.equal(guard.tool_call(status('right'),context).allow,false);
});
test('all attempts count toward eight requests before sending the ninth',()=>{
 const guard=createResearchWorkflowScopeGuard(policy);
 for(let i=1;i<=8;i++)assert.equal(guard.before_request({...request,attempt:i},context).request_index,i);
 assert.equal(guard.before_request(request,context).allow,false);
});
test('the original deadline and reversed clock block requests and tools',()=>{
 let clock=1000;const guard=createResearchWorkflowScopeGuard(policy,()=>clock);
 const first=guard.before_request(request,context);clock+=119000;
 assert.equal(guard.before_request(request,context).deadline_epoch_ms,first.deadline_epoch_ms);
 clock=first.deadline_epoch_ms;assert.equal(guard.before_request(request,context).allow,false);
 assert.equal(guard.tool_call(start,context).allow,false);assert.equal(guard.before_step({},context).block,true);
 let secondClock=500;const reversed=createResearchWorkflowScopeGuard(policy,()=>secondClock);
 reversed.before_request(request,context);secondClock=499;assert.equal(reversed.before_request(request,context).allow,false);
});
test('replays, foreign workspaces and auxiliary model slots cannot act',()=>{
 for(const other of [{...context,replayed:true},{session:{...context.session,workspaceRoot:'E:/other'}},{session:{key:''}}]){
  const guard=createResearchWorkflowScopeGuard(policy);assert.equal(guard.before_request(request,other).allow,false);
  assert.equal(guard.tool_call(start,other).allow,false);
 }
 const guard=createResearchWorkflowScopeGuard(policy);
 assert.equal(guard.before_request({...request,slot:'auxiliary'},context).allow,false);
 assert.equal(guard.before_request({...request,model:'other'},context).allow,false);
});
test('session counters cannot carry a workflow ID into another session',()=>{
 const guard=prepared();guard.tool_call(start,context);guard.tool_result(result(),context);
 const other={session:{key:'other',workspaceRoot:policy.workspace_root}};
 guard.before_request(request,other);assert.equal(guard.tool_call(status('read'),other).allow,false);
});
test('invalid or widened policies fail before use',()=>{
 for(const candidate of [{...policy,max_model_requests:9},{...policy,max_status_calls:7},
  {...policy,budget:{...policy.budget,domain_invocations:7}},{...policy,workflow_id:'other'},
  {...policy,unexpected:true}]) assert.throws(()=>createResearchWorkflowScopeGuard(candidate));
});
test('only the accepted short SID tool names within official prefix and name limits can configure scope',()=>{
 assert.ok('mcp_dr_workflow_v1_a78bff84_'.length<=33);
 assert.ok(policy.qualified_start_tool.length<=64);assert.ok(policy.qualified_status_tool.length<=64);
 for(const candidate of [
  {...policy,qualified_start_tool:'mcp_defect_researcher_workflow_v1_4943d0dd_run_bounded_research_workflow_v1'},
  {...policy,qualified_status_tool:'mcp_defect_researcher_workflow_v1_4943d0dd_get_research_workflow_status_v1'},
  {...policy,qualified_start_tool:'mcp_defect_researcher_workflow_v1_4943d0dd_run_bounded_research_'},
  {...policy,qualified_status_tool:'mcp_defect_researcher_workflow_v1_4943d0dd_get_research_workflow'},
  {...policy,qualified_start_tool:policy.qualified_start_tool.replace('a78bff84','12345678')},
  {...policy,qualified_status_tool:policy.qualified_status_tool.replace('a78bff84','12345678')},
  {...policy,qualified_start_tool:policy.qualified_status_tool,qualified_status_tool:policy.qualified_start_tool},
 ]) assert.throws(()=>createResearchWorkflowScopeGuard(candidate));
});
test('failed long SID names and another server prefix cannot execute registered calls',()=>{
 const guard=prepared();
 for(const name of [
  'mcp_defect_researcher_workflow_v1_4943d0dd_run_bounded_research_workflow_v1',
  'mcp_defect_researcher_workflow_v1_4943d0dd_run_bounded_research_',
  policy.qualified_start_tool.replace('a78bff84','12345678'),
 ]) assert.equal(guard.tool_call({...start,name},context).allow,false);
 assert.equal(guard.tool_call(start,context).allow,true);guard.tool_result(result(),context);
 for(const name of [
  'mcp_defect_researcher_workflow_v1_4943d0dd_get_research_workflow_status_v1',
  'mcp_defect_researcher_workflow_v1_4943d0dd_get_research_workflow',
  policy.qualified_status_tool.replace('a78bff84','12345678'),
 ]) assert.equal(guard.tool_call({...status('nonregistered-'+name),name},context).allow,false);
 assert.equal(guard.tool_call(status('registered'),context).allow,true);
});
