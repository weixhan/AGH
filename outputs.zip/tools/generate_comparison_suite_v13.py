"""Generate new V13 JavaScript stage adapters from frozen V12 sources only.

Import is inert. Writes are exclusive and all destinations must be absent.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MEMBERS = ("comparison_scope_guard", "test_comparison_scope_guard",
           "prepare_comparison_scope", "enable_comparison_scope",
           "activate_comparison_mcp", "diagnose_comparison_mcp",
           "reconcile_comparison_mcp", "run_comparison_suite")
def source(name):
    if name not in MEMBERS:
        raise ValueError("Unknown V13 adapter member")
    text = (ROOT / "tools" / (name + "_v12.mjs")).read_text("utf8")
    return (text.replace("_v12", "_v13").replace("-v12", "-v13").replace("V12", "V13")
            .replace("cmp12", "cmp13").replace("verify_comparison_runtime_v10", "verify_comparison_runtime_v13")
            .replace("capture_comparison_runtime_v10", "capture_comparison_runtime_v13"))


def main():
    destinations = {name: ROOT / "tools" / (name + "_v13.mjs") for name in MEMBERS}
    if any(path.exists() for path in destinations.values()):
        raise FileExistsError("A V13 adapter already exists; frozen implementations cannot be replaced")
    texts = {name: source(name) for name in MEMBERS}
    for name, path in destinations.items():
        with path.open("x", encoding="utf8", newline="\n") as stream:
            stream.write(texts[name])


if __name__ == "__main__":
    main()
