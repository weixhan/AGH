// Update only the two-tool sidecar; preserve the original seven-tool service.
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID,createHash} from 'node:crypto';
import {resolve,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177';
const output=join(root,'outputs/agh-research-workflow-model-v3');
const protocol=JSON.parse(await readFile(join(output,'protocol.json'),'utf8'));
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
if(sha(await readFile(protocol.source_lock.path))!==protocol.source_lock.sha256)throw new Error('Deployment pin differs');
const lock=JSON.parse(await readFile(protocol.source_lock.path,'utf8'));
if(lock.kind!=='research_mcp_implementation_v2')throw new Error('Expected V2 deployment');
for(const member of lock.files)if(sha(await readFile(member.path))!==member.sha256)throw new Error('Source lock member differs');
const serverId='dr-workflow-v1';
const prior=JSON.parse(await readFile(join(root,'outputs/agh-research-workflow-model-v1/mcp_activation_verification.json'),'utf8'));
if(prior.status!=='passed')throw new Error('Prior activation evidence not passed');
const definition=structuredClone(JSON.parse(await readFile(join(root,'outputs/agh-research-workflow-model-v1/mcp-activation.json'),'utf8')).definition);
definition.displayName='DefectResearcher bounded workflow runtime V2';
definition.transport.args=['-B',join(root,'run_research_mcp_v2.py'),'--config',join(root,'outputs/agh-research-workflow-model-v1/server-config.json'),
 '--source-lock',protocol.source_lock.path,'--expected-lock-sha256',protocol.source_lock.sha256];
const trace={schema_version:1,status:'running',definition,server_id:serverId,steps:[],model_requests:0,credentials_read:false,agh_core_modified:false};
const path=join(output,'mcp-activation.json');await writeFile(path,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(path,JSON.stringify(trace,null,2)+'\n');
async function api(route,body){const r=await fetch(origin+'/admin/resources/api/'+route,{method:body?'POST':'GET',
 headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 const result=await r.json();if(!r.ok)throw new Error(`${route}: ${r.status} ${JSON.stringify(result)}`);return result;}
let base;
async function effect(route,params){const step={route,params:{...base,commandId:'bounded-v2-'+randomUUID(),...params}};
 trace.steps.push(step);await save();step.receipt=await api(route,step.params);await save();const deadline=Date.now()+60000;
 for(;;){step.operation=await api('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();
  if(['succeeded','failed','cancelled'].includes(step.operation.state))break;
  if(Date.now()>=deadline)throw new Error('Original operation deadline expired');await new Promise(done=>setTimeout(done,400));}
 console.log(JSON.stringify({route,state:step.operation.state,error:step.operation.lastSafeError}));
 if(step.operation.state!=='succeeded')throw new Error(`${route} failed`);}
try{
 const context=await api('context');if(context.readOnly||context.profile!=='local-dev')throw new Error('Wrong admin context');
 base={profile:context.profile,clientId:context.clientId};
 trace.old_before=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 let row=await api('mcp/get',{profile:base.profile,serverId});trace.before=row;
 if(row.desired!=='enabled'||row.trust!=='trusted'||row.actual!=='ready')throw new Error('Unexpected original sidecar state');
 await effect('mcp/disable',{serverId,expectedRevision:row.revision});
 row=await api('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/update',{serverId,expectedRevision:row.revision,definition});
 row=await api('mcp/get',{profile:base.profile,serverId});
 if(row.trust!=='trusted')await effect('mcp/trust',{serverId,expectedRevision:row.revision,trust:'trusted'});
 row=await api('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/enable',{serverId,expectedRevision:row.revision});
 await effect('mcp/test',{serverId,expectedRevision:row.revision});
 trace.after=await api('mcp/get',{profile:base.profile,serverId});
 trace.status_snapshot=await api('mcp/status',{profile:base.profile,serverId});
 trace.tools=await api('mcp/tools',{profile:base.profile,serverId});
 trace.old_after=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 trace.checks={all_official_operations_succeeded:trace.steps.every(step=>step.operation.state==='succeeded'),
  original_service_unchanged:trace.old_before.revision===trace.old_after.revision&&JSON.stringify(trace.old_before.definition)===JSON.stringify(trace.old_after.definition)&&trace.old_after.actual==='ready',
  sidecar_trusted_ready:trace.after.trust==='trusted'&&trace.after.desired==='enabled'&&trace.after.actual==='ready',
  exact_two_tool_catalog:trace.status_snapshot.toolCount===2&&trace.tools.items.length===2,
  frozen_deployment_args:JSON.stringify(trace.after.definition.transport.args)===JSON.stringify(definition.transport.args)};
 trace.status=Object.values(trace.checks).every(Boolean)?'passed':'failed';
}catch(error){trace.status='failed';trace.error={name:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,checks:trace.checks,error:trace.error}));}
if(trace.status!=='passed')process.exitCode=1;
