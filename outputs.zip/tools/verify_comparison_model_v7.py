"""Independent stdlib check of one bounded U/F model session.

Engineering validity and model behaviour are separate. A declined or incorrect
publication can remain a valid observation. Missing clocks, unknown actual
costs, modified sources and tool execution outside scope cannot. This module
does not import the runtime, MCP server, scope guard or business evaluator.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime
import hashlib
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
UNKNOWN = "__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__"
FREEZE_SHA256 = "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"
PRODUCTION_GEOMETRY = ROOT.parent.parent / "projects/cableinspect-ad-code/project_start/cableinspect_geometry.py"
ACTIONS = {"inspect_input": 0, "verify_input": 1, "repair_copy": 3,
           "verify_copy": 1, "read_science": 1, "publish_report": 0}
HANDLE = re.compile(r"cmp_[0-9a-f]{32}\Z")
TOOL = re.compile(r"mcp_dr_compare_v7_[0-9a-f]{8}_execute_case_action_v1\Z")
POLICY_KEYS = {"schema_version", "workspace_root", "qualified_action_tool", "allowed_handles",
               "max_model_requests", "max_wall_seconds", "max_action_calls"}
SCIENCE_FLOAT_FIELDS = {
    "summary.relative_small.recall_640", "summary.relative_small.recall_960",
    "summary.tiny_small.recall_640", "summary.tiny_small.recall_960",
    "summary.resolution.map50_640", "summary.resolution.map50_960",
    "summary.slicing.map50_baseline", "summary.slicing.map50_sliced",
}
CLOCK_FIELDS = {"started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic",
                "current_epoch", "current_monotonic", "elapsed_wall_seconds"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def decode(text):
    result = json.loads(text, object_pairs_hook=_pairs,
                        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))
    require(finite_json(result), "Decoded JSON contains an overflowing or nonfinite number")
    return result


def read(path):
    return decode(Path(path).read_text(encoding="utf-8"))


def lines(path):
    return [decode(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def finite(number):
    return type(number) in (int, float) and math.isfinite(number)


def finite_json(value):
    if value is None or type(value) in (str, bool, int):
        return True
    if type(value) is float:
        return math.isfinite(value)
    if type(value) is list:
        return all(finite_json(item) for item in value)
    if type(value) is dict:
        return all(type(key) is str and finite_json(item) for key, item in value.items())
    return False


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exact(left, right):
    if type(left) is bool or type(right) is bool:
        return type(left) is type(right) and left == right
    if type(left) in (int, float) and type(right) in (int, float):
        return finite(left) and finite(right) and left == right
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(exact(left[key], right[key]) for key in left)
    if type(left) is list:
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def safe_path(path, *, bound_source=False):
    location = Path(path).absolute()
    for part in (location, *location.parents):
        require(not part.is_symlink() and not (hasattr(part, "is_junction") and part.is_junction()),
                "Linked source or evidence paths are refused")
    location = location.resolve()
    require(location.is_relative_to(ROOT) or (bound_source and location == PRODUCTION_GEOMETRY.resolve()),
            "Source or evidence path is outside its declared project scope")
    return location


def bound_file(record):
    require(type(record) is dict and {"path", "sha256"} <= set(record), "Missing source binding")
    require(type(record["path"]) is str and Path(record["path"]).is_absolute()
            and type(record["sha256"]) is str and re.fullmatch(r"[0-9a-f]{64}", record["sha256"]),
            "Source record requires an absolute path and SHA256")
    path = safe_path(record["path"], bound_source=True)
    require(path.is_file() and digest(path) == record["sha256"], "Bound bytes changed")
    if "size_bytes" in record:
        require(type(record["size_bytes"]) is int and record["size_bytes"] == path.stat().st_size,
                "Bound byte size differs")
    return path


def normalize_path(value):
    return str(value).replace("\\", "/").rstrip("/").lower()


def workspace_path(value, workspace):
    """Only project a typed path at the official literal workspace boundary."""
    require(type(value) is str and type(workspace) is str, "Typed path projection needs strings")
    windows = bool(re.match(r"^[A-Za-z]:[\\/]", workspace)) or workspace.startswith("\\\\")
    root = workspace.rstrip("\\/" if windows else "/")
    require(root, "Concrete workspace path required")
    pattern = r"[\\/]".join(re.escape(part) for part in re.split(r"[\\/]", root)) if windows else re.escape(root)
    match = re.match("^" + pattern + (r"(?=$|[\\/])" if windows else r"(?=$|/)"),
                     value, re.I if windows else 0)
    return "<workspace>" + value[match.end():] if match else value


def official_payload(text):
    """Do not replace an official numeric mask with a saved value."""
    try:
        value = decode(text)
    except (json.JSONDecodeError, ValueError):
        pattern = r"([:,\[]\s*)-?(?:\d+\.)?\[REDACTED:id\](?=\s*[,}\]])"
        changed, count = re.subn(pattern, lambda match: match[1] + json.dumps(UNKNOWN), text)
        require(count > 0, "Unsupported official payload or mask syntax")
        value = decode(changed)
    masks = []
    def visit(item, path):
        if type(item) is dict:
            for key, child in item.items():
                visit(child, path + [key])
        elif type(item) is list:
            for index, child in enumerate(item):
                visit(child, path + [index])
        elif item == UNKNOWN:
            masks.append(path)
    visit(value, [])
    return value, masks


def _mask_allowed(path, expected):
    if len(path) == 2 and path[0] == "budget" and path[1] in CLOCK_FIELDS:
        return True
    if path[:2] == ["evidence", "summary"]:
        return ".".join(path[1:]) in SCIENCE_FLOAT_FIELDS
    if len(path) == 4 and path[:2] == ["report", "claims"] and type(path[2]) is int and path[3] == "value":
        return expected["report"]["claims"][path[2]].get("field") in SCIENCE_FLOAT_FIELDS
    return False


def project_official(value, expected, masks, *, workspace=None):
    target = copy.deepcopy(expected)
    # Public action results should not disclose private filesystem paths.
    # The only typed workspace path projection is in scope-ready, handled below.
    for path in masks:
        require(_mask_allowed(path, target), "Unsupported or essential official numeric mask")
        node = target
        for key in path[:-1]:
            node = node[key]
        require(type(node[path[-1]]) is float and math.isfinite(node[path[-1]]),
                "Masked field is not an explicitly allowed decimal")
        node[path[-1]] = UNKNOWN
    return exact(value, target)


def event_ms(row):
    require(type(row.get("ts")) is str, "Official timestamp absent")
    value = datetime.fromisoformat(row["ts"].replace("Z", "+00:00")).timestamp() * 1000
    require(finite(value), "Official timestamp nonfinite")
    return value


def texts(row):
    return "\n".join(item["text"] for item in row.get("data", {}).get("content", [])
                     if item.get("type") == "text")


def journal(path):
    rows = lines(path)
    previous = "0" * 64
    for index, row in enumerate(rows):
        require(type(row) is dict and set(row) == {"schema_version", "sequence", "event", "previous_sha256", "record", "sha256"}
                and type(row["schema_version"]) is int and row["schema_version"] == 1
                and type(row["sequence"]) is int and row["sequence"] == index
                and row["previous_sha256"] == previous and type(row["record"]) is dict,
                "Private journal sequence or predecessor differs")
        require(row["sha256"] == hashlib.sha256(canonical({key: value for key, value in row.items() if key != "sha256"})).hexdigest(),
                "Private journal row hash differs")
        previous = row["sha256"]
    return rows


def check_budget(rows, arm):
    require(rows and rows[0]["event"] == "ledger_opened", "Missing original budget opening")
    require(all(exact(rows[0]["record"].get(key), value) for key, value in arm.items()),
            "Budget opening resets the armed trial")
    pending, used = None, 0
    previous = {"current_epoch": arm["started_epoch"], "current_monotonic": arm["started_monotonic"]}
    for row in rows:
        item = row["record"]
        for field, deadline in (("current_epoch", arm["deadline_epoch"]), ("current_monotonic", arm["deadline_monotonic"])):
            require(field in item and finite(item[field]) and previous[field] <= item[field] < deadline,
                    "Budget receipt clock moved backwards or escaped original deadline")
            previous[field] = item[field]
        if row["event"] == "action_reserved":
            action, cost = item.get("action"), item.get("reserved_cost")
            require(pending is None and type(cost) is int and action in ACTIONS and cost == ACTIONS[action]
                    and used + cost <= 6, "Overlapping, unknown or excessive action reservation")
            pending = (action, cost)
        elif row["event"] == "action_closed":
            actual = item.get("actual_cost")
            require(pending is not None and item.get("action") == pending[0] and type(actual) is int
                    and 0 <= actual <= pending[1], "Unknown actual action cost")
            used += actual
            require(item.get("used_domain_invocations") == used, "Actual cumulative cost differs")
            pending = None
        else:
            require(row["event"] == "ledger_opened" and row["sequence"] == 0, "Unknown budget event")
    require(pending is None and used <= 6, "Open reservation leaves actual cost unknown")
    return used


def validate_policy(policy, handle):
    require(type(policy) is dict and set(policy) == POLICY_KEYS and policy["schema_version"] == 1
            and type(policy["schema_version"]) is int and type(policy["qualified_action_tool"]) is str
            and TOOL.fullmatch(policy["qualified_action_tool"]), "Scope policy schema/tool differs")
    require(type(policy["allowed_handles"]) is list and handle in policy["allowed_handles"]
            and len(set(policy["allowed_handles"])) == len(policy["allowed_handles"])
            and all(type(item) is str and HANDLE.fullmatch(item) for item in policy["allowed_handles"]),
            "Scope handles absent, malformed or replayed")
    require(all(type(policy[key]) is int and policy[key] == expected for key, expected in
                (("max_model_requests", 7), ("max_wall_seconds", 120), ("max_action_calls", 8))),
            "Scope caps differ")
    safe_path(policy["workspace_root"])


def check_ledger(rows, run, arm, *, known_actions=None):
    """Pure ledger acceptance used by actual runs and negative fixture tests."""
    checks, errors, facts = {}, [], {}
    active = "official_contiguous_sequences_and_fresh_session"
    try:
        require(rows and all(type(row) is dict for row in rows), "Official event ledger missing")
        require([row.get("seq") for row in rows] == list(range(1, len(rows) + 1))
                and all(type(row.get("seq")) is int for row in rows), "Official sequences are not contiguous typed integers")
        stamps = [event_ms(row) for row in rows]
        require(stamps == sorted(stamps), "Official timestamps move backwards")
        require(rows[0].get("type") == "session/start" and rows[0].get("origin") == "system"
                and rows[0].get("trust") == "trusted" and rows[0].get("data", {}).get("key") == run["session_id"],
                "Session is not one fresh trusted session")
        checks[active] = True
        active = "original_backend_clock_bound_to_scope_and_runner"
        handle, policy = run["trial_handle"], run["scope_ready"]["data"]["policy"]
        validate_policy(policy, handle)
        begin, deadline = run["started_epoch_ms"], run["deadline_epoch_ms"]
        require(finite(begin) and finite(deadline) and begin == arm["started_epoch"] * 1000
                and deadline == arm["deadline_epoch"] * 1000 and abs(deadline - begin - 120000) <= 0.001,
                "Model runner reset or enlarged the backend original deadline")
        require(finite(run.get("finished_epoch_ms")) and begin <= run["finished_epoch_ms"] < deadline,
                "Runner finalization escaped the original deadline")
        require(normalize_path(run["workspace_root"]) == normalize_path(policy["workspace_root"]), "Model workspace differs")
        require(run.get("qualified_action_tool") == policy["qualified_action_tool"], "Qualified tool differs")
        binding = run.get("active_binding")
        require(type(binding) is dict and set(binding) == {"schema_version", "owner", "trial_handle", "session_key",
                "started_epoch_ms", "deadline_epoch_ms", "arm_sha256"}
                and binding["schema_version"] == 1 and binding["owner"] == "comparison-model-runner-v1"
                and binding["trial_handle"] == handle and binding["session_key"] == run["session_key"] == run["session_id"]
                and binding["started_epoch_ms"] == begin and binding["deadline_epoch_ms"] == deadline
                and binding["arm_sha256"] == run["arm_sha256"], "Trusted active binding differs from original arm")
        calls = [row for row in rows if row.get("type") == "tool/call"]
        results = [row for row in rows if row.get("type") == "tool/result"]
        requests = [row for row in rows if row.get("type") == "request/sent"]
        costs = [row for row in rows if row.get("type") == "cost/ledger" and row.get("data", {}).get("purpose") == "inference"]
        ready = [row for row in rows if row.get("type", "").endswith("/scope-ready")]
        gates = [row for row in rows if row.get("type", "").endswith("/scope-decision")]
        request_gates = [row for row in rows if row.get("type", "").endswith("/scope-request-decision")]
        approvals = [row for row in rows if row.get("type") == "approval/decided"]
        ends = [row for row in rows if row.get("type") == "turn/end"]
        require(all(begin <= event_ms(row) < deadline for row in calls + results + requests + costs + gates + request_gates + approvals + ends),
                "Model request, tool, approval or turn escaped original clock")
        checks[active] = True
        active = "scope_readiness_exact_common_policy_before_requests"
        require(len(ready) == 1 and requests and ready[0]["seq"] < requests[0]["seq"], "Scope was not ready before model inference")
        expected_ready = copy.deepcopy(run["scope_ready"])
        require(normalize_path(expected_ready["data"]["workspace_root"]) == normalize_path(policy["workspace_root"]),
                "SDK scope readiness workspace differs")
        expected_ready["data"]["workspace_root"] = "<workspace>"
        expected_ready["data"]["policy"]["workspace_root"] = "<workspace>"
        require(exact(expected_ready, ready[0]) and ready[0]["data"].get("mode") == "case-comparison-v1"
                and ready[0]["data"].get("session_key") == run["session_id"], "Official and SDK readiness differ")
        official_policy = copy.deepcopy(policy); official_policy["workspace_root"] = "<workspace>"
        require(exact(ready[0]["data"].get("policy"), official_policy)
                and str(ready[0].get("origin", "")).startswith("ext:plugin/"), "Official scope policy differs")
        checks[active] = True
        active = "actual_model_requests_including_failures_bounded_known_costs"
        require(1 <= len(requests) <= 7 and len(costs) == len(requests),
                "Request cap exceeded or inference cost unknown")
        require(type(run.get("model_request_count")) is int and run["model_request_count"] == len(requests),
                "SDK actual request count differs")
        require(run.get("model") == "agnes-3.0-flash" and run.get("route") == "account-defect-researcher",
                "Runner model route differs")
        schema_hashes = {row["data"].get("tool_schema_hash") for row in requests}
        require(len(schema_hashes) == 1 and all(type(item) is str and re.fullmatch(r"[0-9a-f]{64}", item) for item in schema_hashes),
                "Model tool schema changes within the trial")
        for index, (request, cost) in enumerate(zip(requests, costs)):
            require(request.get("origin") == cost.get("origin") == "system"
                    and request.get("trust") == cost.get("trust") == "trusted"
                    and request["data"].get("model", {}).get("id") == run["model"]
                    and request["data"]["model"].get("route") == run["route"]
                    and cost["data"].get("model") == run["model"]
                    and request["seq"] < cost["seq"]
                    and (index + 1 == len(requests) or cost["seq"] < requests[index + 1]["seq"]),
                    "Inference cost is not paired to the actual primary model request")
            tokens = cost["data"].get("tokens")
            require(type(tokens) is dict and tokens and all(type(number) is int and number >= 0 for number in tokens.values())
                    and type(cost["data"].get("response", {}).get("status")) is int,
                    "Inference usage or terminal response cost is unknown")
        require(exact(run.get("request_events"), requests)
                and exact(run.get("cost_events"), [row for row in rows if row.get("type") == "cost/ledger"]),
                "SDK model request or cost ledger differs")
        checks[active] = True
        active = "native_title_request_cost_and_terminal_within_original_budget"
        title_facts = check_native_title(rows, run, arm)
        checks[active] = True
        active = "scope_request_attempts_preserve_original_backend_anchor"
        allowed_requests = [row for row in request_gates if row["data"].get("allow") is True]
        require(len(allowed_requests) == len(requests) and len(allowed_requests) <= 7
                and len(run.get("scope_request_events", [])) == len(request_gates),
                "Guard request attempts differ from actual inference inventory")
        for index, gate in enumerate(allowed_requests, 1):
            data = gate["data"]
            require(gate["seq"] < requests[index - 1]["seq"]
                    and data.get("request_index") == index and type(data.get("request_index")) is int
                    and data.get("trial_handle") == handle and data.get("arm_sha256") == run["arm_sha256"]
                    and data.get("started_epoch_ms") == begin and data.get("deadline_epoch_ms") == deadline
                    and data.get("session_key") == run["session_id"] and gate.get("origin") == ready[0].get("origin"),
                    "Guard request resets the original clock, handle, source or count")
        require(all(exact(sdk, official) for sdk, official in zip(run["scope_request_events"], request_gates)),
                "SDK guard request decisions differ")
        checks[active] = True
        active = "tool_calls_results_and_scope_verdicts_paired_no_foreign_execution"
        require(len(calls) == len(results) == len(gates) == len(run.get("calls", [])) == len(run.get("results", []))
                == len(run.get("hook_events", [])), "Tool/result/scope inventories differ")
        require(len({row["data"].get("toolUseId") for row in calls}) == len(calls)
                and all(type(row["data"].get("toolUseId")) is str and row["data"]["toolUseId"] for row in calls),
                "Tool identities absent or duplicated")
        masks_seen, executed = [], []
        for call, sdk_call in zip(calls, run["calls"]):
            data = call["data"]; use_id = data["toolUseId"]
            result_matches = [row for row in results if row["data"].get("toolUseId") == use_id]
            gate_matches = [row for row in gates if row["data"].get("tool_use_id") == use_id]
            require(len(result_matches) == len(gate_matches) == 1, "Action result/gate pairing is not unique")
            result, gate = result_matches[0], gate_matches[0]
            require(call.get("origin") == "model" and call.get("trust") == "trusted"
                    and call["seq"] < gate["seq"] < result["seq"]
                    and result.get("sourceEventSeqs") == [call["seq"]]
                    and gate["data"].get("name") == data["name"] and gate["data"].get("session_key") == run["session_id"]
                    and gate.get("origin") == ready[0].get("origin")
                    and result.get("origin") == "tool:" + data["name"] and result.get("trust") == "untrusted",
                    "Tool action is not bound to the native scope/result chain")
            require(sdk_call.get("seq") == call["seq"] and sdk_call.get("origin") == "model"
                    and sdk_call.get("name") == data["name"] and sdk_call.get("toolUseId") == use_id,
                    "SDK action identity differs")
            require(exact(sdk_call.get("args"), data.get("args")), "SDK and official call arguments differ")
            sdk_result = next(row for row in run["results"] if row.get("seq") == result["seq"])
            require(sdk_result.get("tool_use_id") == use_id and sdk_result.get("is_error") is result["data"].get("isError")
                    and sdk_result.get("code") == result["data"].get("code"), "SDK result identity/error state differs")
            if gate["data"].get("allow") is not True:
                require(gate["data"].get("allow") is False and result["data"].get("isError") is True
                        and result["data"].get("code") == "HOOK_DENIED", "Denied scope action executed or lacks a known refusal")
                continue
            args = sdk_call["args"]
            require(data["name"] == policy["qualified_action_tool"] and type(args) is dict
                    and args.get("trial_handle") == handle and args.get("action") in ACTIONS
                    and set(args) == ({"trial_handle", "action", "report"} if args.get("action") == "publish_report" else {"trial_handle", "action"}),
                    "Allowed execution selects a foreign tool/trial or private capability")
            if result["data"].get("code") == "APPROVAL_REJECTED":
                require(result["data"].get("isError") is True, "Declined approval did not stop execution")
                continue
            blocks = [item for item in result["data"].get("content", []) if item.get("type") == "text"]
            require(len(blocks) == 1, "Action result does not contain one JSON evidence block")
            observed, masks = official_payload(blocks[0]["text"])
            payload = sdk_result.get("payload")
            require(type(payload) is dict and project_official(observed, payload, masks),
                    "Official result differs from SDK evidence beyond known decimal masks")
            require(payload.get("trial_handle") == handle and payload.get("action") == args["action"]
                    and payload.get("schema_version") == 1 and payload.get("status") in {"executed", "published", "rejected"}
                    and result["data"].get("isError") is (payload["status"] == "rejected"),
                    "Runtime result is not bound to this explicit action/error")
            masks_seen.extend(masks)
            executed.append((call, result, payload))
            if known_actions is not None:
                matched = [row for row in known_actions if row["event"] == "action_finished"
                           and row["record"].get("action") == args["action"]]
                if matched and (payload["status"] != "rejected" or "publication" in payload):
                    require(len(matched) == 1 and exact(matched[0]["record"].get("public_result"), payload),
                            "SDK payload differs from owned action receipt")
                else:
                    require(payload["status"] == "rejected" and bool(payload.get("errors")),
                            "Successful action lacks a known-cost owned receipt")
        require(all(exact(sdk, official) for sdk, official in zip(run["hook_events"], gates)), "SDK tool gates differ")
        require(sum(row["data"].get("allow") is True for row in gates) <= 8, "Guard action cap exceeded")
        checks[active] = True
        active = "actual_write_approvals_allow_once_bound_to_calls"
        permissions = run.get("permissions", [])
        require(len(permissions) == len(approvals), "Official/SDK approval inventories differ")
        matched_permissions, matched_approvals = set(), set()
        for call in calls:
            use_id = call["data"]["toolUseId"]
            result = next(row for row in results if row["data"].get("toolUseId") == use_id)
            gate = next(row for row in gates if row["data"].get("tool_use_id") == use_id)
            permitted = [index for index, row in enumerate(permissions) if row.get("tool_call_id") == use_id]
            paired = [row for row in approvals if row["data"].get("scope") == f"tool:{call['data']['name']}:execute"
                      and call["seq"] < row["seq"] < result["seq"]]
            require(len(paired) == len(permitted) <= 1, "Approval pairing is repeated or unbound")
            requires = gate["data"].get("allow") is True and call["data"].get("resolvedPolicy", {}).get("isReadOnly") is not True
            require(not requires or len(paired) == 1, "Actual write lacks one explicit approval")
            if not paired:
                continue
            permission = permissions[permitted[0]]
            verdict = paired[0]["data"].get("verdict")
            require((verdict == "allowed-once" or (verdict == "rejected" and result["data"].get("code") == "APPROVAL_REJECTED"))
                    and permission.get("decision") == verdict
                    and permission.get("tool") == call["data"]["name"]
                    and exact(permission.get("input"), run["calls"][calls.index(call)].get("args")),
                    "Actual write approval is persistent, rejected or for another input")
            matched_permissions.add(permitted[0]); matched_approvals.add(paired[0]["seq"])
        require(len(matched_permissions) == len(permissions) and len(matched_approvals) == len(approvals),
                "Extra approval rows do not bind actual actions")
        checks[active] = True
        active = "honest_terminal_turn_and_final_messages_preserved"
        require(len(ends) == 1 and exact(run.get("turn_end"), ends[0]), "Actual terminal turn is absent or changed")
        final_messages = [row for row in rows if row.get("type") == "assistant/message"]
        require(len(run.get("final_texts", [])) == len(final_messages)
                and all(exact(sdk, official) for sdk, official in zip(run["final_texts"], final_messages)),
                "SDK/official final message inventory differs")
        require(not run.get("export_failure"), "Official export failed")
        sdk_rows = run.get("sdk_events")
        require(type(sdk_rows) is list and [row.get("seq") for row in sdk_rows] == [row["seq"] for row in rows]
                and all(row.get("type") == official.get("type") and row.get("origin") == official.get("origin")
                        and row.get("trust") == official.get("trust") and row.get("ts") == official.get("ts")
                        for row, official in zip(sdk_rows, rows)), "SDK full event envelope inventory differs")
        publication = [payload for _, _, payload in executed if payload.get("action") == "publish_report"]
        facts = {"model_request_count": len(requests), "tool_call_count": len(calls),
                 "scope_denied_call_count": sum(row["data"].get("allow") is False for row in gates),
                 "approval_count": len(approvals), "tool_schema_hash": next(iter(schema_hashes)),
                 "masked_numeric_paths_not_recovered": masks_seen,
                 "turn_reason": ends[0]["data"].get("reason"), "publication_attempted": bool(publication),
                 "publication_accepted": bool(publication and publication[-1].get("publication", {}).get("accepted") is True),
                 "business_correctness": "evaluated_separately", "elapsed_seconds": (run["finished_epoch_ms"] - begin) / 1000,
                 "cost_basis": "official_token_usage; reported billing estimate is not a purchase price"}
        facts.update(title_facts)
        checks[active] = True
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
    return {"checks": checks, "errors": errors, **facts}


def check_native_title(rows, run, arm):
    """Count the native title provider call, which has no request/sent row."""
    title_rows = [r for r in rows if r.get("type") == "x/host/session-title"]
    requested = [r for r in title_rows if r["data"].get("status") == "requested"]
    terminal = [r for r in title_rows if r["data"].get("status") in {"generated", "failed"}]
    costs = [r for r in rows if r.get("type") == "cost/ledger" and r["data"].get("purpose") == "title"]
    require(len(terminal) == 1 and len(requested) == len(costs) <= 1,
            "Native title provider cost is open, duplicated or unknown")
    end = next(r for r in rows if r.get("type") == "turn/end")
    require(all(r.get("origin") == "system" and r.get("trust") == "trusted"
                and arm["started_epoch"]*1000 <= event_ms(r) < arm["deadline_epoch"]*1000
                for r in title_rows + costs), "Native title source or original deadline differs")
    require(end["seq"] < terminal[0]["seq"] and exact(run.get("title_terminal_event"), terminal[0])
            and event_ms(terminal[0]) <= run["finished_epoch_ms"],
            "Native title was not settled before finalization")
    if requested:
        request, cost = requested[0], costs[0]
        tokens = cost["data"].get("tokens")
        require(end["seq"] < request["seq"] < cost["seq"] < terminal[0]["seq"]
                and request["data"].get("route") == run["route"] and request["data"].get("model") == run["model"]
                and cost["data"].get("model") == run["model"]
                and type(cost["data"].get("sourceTurn")) is int
                and cost["data"]["sourceTurn"] == request["data"].get("turn") == terminal[0]["data"].get("turn")
                and type(tokens) is dict and {"input", "output", "cacheRead", "cacheWrite"} <= set(tokens)
                and all(type(v) is int and v >= 0 for v in tokens.values())
                and cost["data"].get("interrupted") is not True
                and exact(run.get("title_request_event"), request), "Native title actual usage is not closed and source bound")
    else:
        require(terminal[0]["data"].get("status") == "failed"
                and terminal[0]["data"].get("reason") in {"budget", "model-unavailable", "setup-failed", "cancelled", "aborted", "failed"},
                "Native title has no proved pre-request refusal")
    total = len([r for r in rows if r.get("type") == "request/sent"]) + len(requested)
    require(type(run.get("model_requests_including_title")) is int and run["model_requests_including_title"] == total <= 8,
            "Combined primary and native title model cap/accounting differs")
    return {"native_title_requests": len(requested), "actual_total_model_requests": total,
            "native_title_token_usage": costs[0]["data"]["tokens"] if costs else None,
            "native_title_status": terminal[0]["data"].get("status"), "native_title_cost_known": True}


def check_selected_policy(policy, selection, handle):
    validate_policy(policy, handle)
    require(policy["allowed_handles"] == selection["trial_handles"],
            "Policy does not cover exactly the selected diagnostic population")


def load_binding(directory, protocol_path, *, scripted=False):
    protocol = read(protocol_path)
    run = read(directory / "run_result.json")
    public_path = safe_path(run.get("model_protocol_path", protocol_path.parent / "model_protocol.json"))
    public = read(public_path)
    require(public.get("protocol_sha256") == digest(protocol_path), "Public/private preregistration hash differs")
    if not scripted:
        require(run.get("protocol_sha256") == digest(protocol_path)
                and run.get("model_protocol_sha256") == digest(public_path), "Runner protocol bytes changed")
    handle = run.get("trial_handle")
    require(type(handle) is str and HANDLE.fullmatch(handle) and directory.name == handle,
            "Execution directory does not bind one opaque handle")
    trials = [row for row in protocol["trials"] if row.get("trial_handle") == handle]
    allowed = {"C"} if scripted else {"U", "F"}
    require(len(trials) == 1 and trials[0]["arm"] in allowed, "Trial is not in the proper preregistered route")
    diagnostic = public["engineering_diagnostic"]
    selection = diagnostic["selection"]
    require(selection.get("schema_version") == 1 and selection.get("arm") == "F"
            and selection.get("case_ids") == ["repair_coordinates", "refuse_source_hash"]
            and len(selection.get("trial_handles", [])) == 2
            and len(set(selection["trial_handles"])) == 2
            and hashlib.sha256(canonical(selection)).hexdigest() == diagnostic["selection_sha256"],
            "Frozen diagnostic selection differs")
    selected = [row for row in protocol["trials"] if row["trial_handle"] in selection["trial_handles"]]
    require([{key: row[key] for key in ("trial_id", "trial_handle", "case_id", "arm")} for row in selected] == diagnostic["selected_trials"]
            and [row["case_id"] for row in selected] == selection["case_ids"]
            and all(row["arm"] == "F" for row in selected)
            and [row["trial_handle"] for row in selected] == selection["trial_handles"]
            and handle in selection["trial_handles"]
            and public["scope_policy"]["allowed_handles"] == selection["trial_handles"],
            "Run is outside the exact selected branch diagnostic")
    accounting_paths = [bound_file(row) for row in public["prior_accounting_sources"]]
    prior_reconciliation, prior_acceptance, prior_suite = [read(path) for path in accounting_paths]
    require(prior_reconciliation["actual_requests_observed"] == 17
            and prior_acceptance["model_requests_phase_actual"] == 27
            and prior_suite["model_requests_actual"] == 10
            and prior_reconciliation["actual_requests_observed"] + prior_suite["model_requests_actual"] == 27
            and public["phase_model_budget"]["prior_versions_actual_requests"] == 27
            and public["phase_model_budget"]["this_pilot_cap"] == 16
            and public["phase_model_budget"]["total_cap"] == 48,
            "Previous actual phase cost is not independently source bound")
    bound_file(run["source_lock"])
    require(exact(run["source_lock"], public["source_lock"]), "Public/runner source pins differ")
    lock = read(run["source_lock"]["path"])
    require(lock.get("schema_version") == 1 and lock.get("kind") == "comparison_case_implementation_v1"
            and lock.get("status") == "passed" and type(lock.get("files")) is list, "Deployment source lock differs")
    files = [bound_file(item) for item in lock["files"]]
    require(len(files) == len(set(files)), "Deployment source members replayed")
    needed = [ROOT / "defect_researcher/comparison_case_runtime_v1.py",
              ROOT / "defect_researcher/comparison_mcp_server_v7.py", ROOT / "run_comparison_mcp_v7.py",
              ROOT / "tools/verify_comparison_model_v7.py",
              ROOT / "defect_researcher/comparison_protocol_v1.py",
              ROOT / "defect_researcher/comparison_mcp_server_v1.py", ROOT / "run_comparison_mcp_v1.py",
              ROOT / "tools/verify_comparison_case_v1.py", ROOT / "tools/verify_comparison_model_v1.py",
              ROOT / "tools/run_comparison_pilot_v7.mjs", ROOT / "tools/comparison_scope_guard_v7.mjs",
              ROOT / "config/local.json", ROOT / "fixtures/labelguard_cases.json",
              ROOT / "outputs/research-workflow-implementation-v1/freeze.json", Path(public["server_config"])]
    require(all(path.resolve() in files for path in needed), "Source pin omits a required implementation member")
    for item in protocol["common"]["sources"]:
        bound_file(item)
    common = protocol["common"]
    require(digest_text(common["task_prompt"]) == common["task_prompt_sha256"]
            and hashlib.sha256(canonical(common["tool_catalog"])).hexdigest() == common["tool_catalog_sha256"],
            "Common prompt/action catalogue hash differs")
    require(len(common["tool_catalog"]) == 1 and common["tool_catalog"][0]["name"] == "execute_case_action_v1"
            and set(common["tool_catalog"][0]) == {"name", "description", "inputSchema"},
            "Common action catalogue differs from the native admin projection")
    frozen_path = ROOT / "outputs/research-workflow-implementation-v1/freeze.json"
    frozen = read(frozen_path)
    require(digest(frozen_path) == FREEZE_SHA256 and len(frozen.get("sources", [])) == 25
            and len(frozen.get("archive", [])) == 25 and len(frozen.get("preserved_files", [])) == 968,
            "Prior freeze changed")
    for group in ("sources", "archive", "preserved_files"):
        for item in frozen[group]:
            bound_file(item)
    runtime_root = safe_path(read(public["server_config"])["output_root"])
    trial_directory = runtime_root / "trials" / handle
    if "trial_directory" in run:
        require(safe_path(run["trial_directory"]) == trial_directory, "Private trial directory differs")
    bound_file(read(trial_directory / "registration_binding.json"))
    bound_file(read(trial_directory / "arm_binding.json"))
    registration, arm = read(trial_directory / "registration.json"), read(trial_directory / "arm.json")
    require(registration.get("owner") == "defect_researcher.comparison_case_runtime_v1"
            and registration.get("trial_handle") == handle and registration.get("trial_id") == trials[0]["trial_id"]
            and registration.get("case_id") == trials[0]["case_id"] and registration.get("arm") == trials[0]["arm"],
            "Registered private case/treatment differs from preregistration")
    require(exact(registration["source_binding"].get("deployment_lock"), run["source_lock"]), "Registered source pin differs")
    for item in registration["source_binding"]["files"]:
        bound_file(item)
    require(arm.get("registration_sha256") == digest(trial_directory / "registration.json")
            and arm.get("trial_handle") == handle and exact(run.get("arm"), arm), "Original arm bytes differ")
    if not scripted:
        require(run.get("arm_sha256") == digest(trial_directory / "arm.json"), "Model arm SHA256 differs")
    require(exact(arm.get("budget"), {"domain_invocations": 6, "model_requests": 8, "wall_seconds": 120, "gpu_seconds": 0})
            and all(finite(arm.get(key)) for key in ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic"))
            and arm["deadline_epoch"] == arm["started_epoch"] + 120
            and arm["deadline_monotonic"] == arm["started_monotonic"] + 120, "Original arm clock or budget changed")
    # Rebuild exact input membership independently, including copied geometry.
    prepared = registration["prepared_case"]
    current = {}
    for key in ("research_root", "dataset_root", "raw_root", "split_dir"):
        root = safe_path(prepared["configuration"][key])
        for path in sorted(root.rglob("*")):
            path = safe_path(path)
            if path.is_file():
                current[key + "/" + path.relative_to(root).as_posix()] = {
                    "path": str(path), "sha256": digest(path), "size_bytes": path.stat().st_size}
    require(exact(current, registration["input_snapshot"]), "Shared original input membership or bytes changed")
    for row in protocol["trials"]:
        if row["case_id"] == trials[0]["case_id"]:
            other = read(runtime_root / "trials" / row["trial_handle"] / "registration.json")
            require(exact(other["input_snapshot"], registration["input_snapshot"])
                    and other["prepared_case"]["case_root"] == prepared["case_root"],
                    "Arms do not read exactly the same frozen case input paths")
    policy = public["scope_policy"]
    check_selected_policy(policy, selection, handle)
    budget_rows = journal(trial_directory / "budget.jsonl")
    used = check_budget(budget_rows, arm)
    actions_path = trial_directory / "actions.jsonl"
    action_rows = journal(actions_path) if actions_path.exists() else []
    return protocol, public, run, trials[0], trial_directory, arm, used, action_rows


def _result(directory, checks, errors, facts):
    return {"schema_version": 1, "kind": "comparison_model_independent_verification_v1",
            "status": "passed" if checks and all(checks.values()) and not errors else "failed",
            "directory": str(directory), "checks_total": len(checks),
            "checks_passed": sum(value is True for value in checks.values()), "checks": checks,
            "errors": errors, "business_correctness": "evaluated_separately", **facts}


def verify(directory, protocol_path=None):
    directory = safe_path(directory)
    protocol_path = safe_path(protocol_path or directory.parent.parent / "protocol.json")
    checks, errors, facts = {}, [], {}
    active = "source_pin_shared_inputs_private_registration_original_arm_and_closed_cost"
    try:
        protocol, public, run, trial, trial_directory, arm, used, actions = load_binding(directory, protocol_path)
        require(exact(run["scope_ready"]["data"]["policy"], public["scope_policy"]), "Model readiness differs from registered policy")
        expected_prompt = (protocol["common"]["task_prompt"] + "\n本次工具：" + public["scope_policy"]["qualified_action_tool"]
                           + "\n本次句柄：" + run["trial_handle"])
        require(run.get("prompt") == expected_prompt and digest_text(expected_prompt) == run.get("prompt_sha256"),
                "Task prompt changed by treatment, case or expected answer")
        # Generated extension records are frozen before the original trial arm;
        # they bind a noncyclic model protocol to the actual enabled candidate.
        for key in ("scope_candidate", "scope_activation"):
            bound_file(run[key])
        candidate = read(run["scope_candidate"]["path"])
        activation = read(run["scope_activation"]["path"])
        require(candidate.get("protocol_sha256") == digest(run["model_protocol_path"])
                and len(candidate.get("files", [])) == 4 and activation.get("complete") is True
                and activation.get("after", {}).get("trusted") is True
                and activation["after"].get("actual") == "running"
                and activation["after"].get("actualIntegrity") == activation.get("preview", {}).get("integrity"),
                "Actual enabled scope package/source binding differs")
        for member in candidate["files"]:
            bound_file(member)
        generated = {member["name"]: Path(member["path"]) for member in candidate["files"]}
        require(set(generated) == {"policy.json", "guard.mjs", "index.mjs", "package.json"}
                and digest(generated["guard.mjs"]) == digest(ROOT / "tools/comparison_scope_guard_v7.mjs")
                and exact(read(generated["policy.json"]), public["scope_policy"]), "Generated scope differs from pinned guard/policy")
        checks[active] = True
        active = "official_export_and_sdk_ledger"
        require((directory / "session.html").is_file() and (directory / "session.html").stat().st_size > 0, "Official HTML export missing")
        ledger = check_ledger(lines(directory / "session.jsonl"), run, arm, known_actions=actions)
        checks.update(ledger["checks"]); errors.extend(ledger["errors"])
        facts.update({key: value for key, value in ledger.items() if key not in {"checks", "errors"}})
        facts.update(registered_arm=trial["arm"], registered_case_id=trial["case_id"], domain_invocations=used,
                     common_task_prompt_sha256=protocol["common"]["task_prompt_sha256"],
                     common_tool_catalog_sha256=protocol["common"]["tool_catalog_sha256"],
                     official_event_sha256=digest(directory / "session.jsonl"), official_html_sha256=digest(directory / "session.html"),
                     run_result_sha256=digest(directory / "run_result.json"), protocol_sha256=digest(protocol_path),
                     arm_sha256=run["arm_sha256"], catalogue_metadata_route="native admin omits annotations; action name/description/schema are common")
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
    return _result(directory, checks, errors, facts)


def verify_scripted(directory, protocol_path=None):
    directory = safe_path(directory)
    protocol_path = safe_path(protocol_path or directory.parent.parent / "protocol.json")
    checks, errors, facts = {}, [], {}
    active = "script_source_pin_shared_inputs_original_arm_and_closed_cost"
    try:
        protocol, public, run, trial, trial_directory, arm, used, actions = load_binding(directory, protocol_path, scripted=True)
        require(run.get("route") == "official_MCP_SDK_stdio" and type(run.get("model_requests")) is int
                and run["model_requests"] == 0 and run.get("agh_approval_count") is None,
                "C route invents model calls or AGH approvals")
        require(run.get("started_epoch_ms") == arm["started_epoch"] * 1000
                and run.get("deadline_epoch_ms") == arm["deadline_epoch"] * 1000
                and finite(run.get("finished_epoch_ms"))
                and run["started_epoch_ms"] <= run["finished_epoch_ms"] < run["deadline_epoch_ms"],
                "C original trial deadline changed or expired")
        checks[active] = True
        active = "script_actual_sdk_catalog_and_explicit_host_authorizations"
        catalogue = run.get("tool_catalog")
        require(type(catalogue) is list and all(type(row) is dict for row in catalogue), "C actual SDK catalogue absent")
        projected = [{key: row[key] for key in ("name", "description", "inputSchema")} for row in catalogue]
        require(exact(projected, protocol["common"]["tool_catalog"]), "C common action catalogue differs")
        calls, results, authorizations = run.get("calls", []), run.get("results", []), run.get("host_authorizations", [])
        require(len(calls) == len(results) == len(authorizations) and len(calls) <= 8, "C call/result/authorization inventory differs")
        for call, result, authorization in zip(calls, results, authorizations):
            args = call.get("args")
            require(call.get("name") == "execute_case_action_v1" and type(args) is dict
                    and args.get("trial_handle") == trial["trial_handle"] and args.get("action") in ACTIONS
                    and set(args) == ({"trial_handle", "action", "report"} if args["action"] == "publish_report" else {"trial_handle", "action"}),
                    "C selected a foreign action, input or capability")
            require(authorization.get("decision") == "authorized_scope_once" and authorization.get("action") == args["action"]
                    and authorization.get("arguments_sha256") == hashlib.sha256(canonical(args)).hexdigest(),
                    "C host authorization does not bind actual SDK arguments")
            payload = result.get("payload")
            require(type(payload) is dict and payload.get("trial_handle") == trial["trial_handle"]
                    and payload.get("action") == args["action"] and payload.get("status") in {"executed", "published", "rejected"}
                    and result.get("is_error") is (payload["status"] == "rejected"), "C result identity/error differs")
            matches = [row for row in actions if row["event"] == "action_finished" and row["record"].get("action") == args["action"]]
            if payload["status"] != "rejected" or "publication" in payload:
                require(len(matches) == 1 and exact(matches[0]["record"].get("public_result"), payload),
                        "C successful action lacks the exact owned cost receipt")
        checks[active] = True
        facts.update(registered_arm="C", registered_case_id=trial["case_id"], domain_invocations=used,
                     model_request_count=0, tool_call_count=len(calls), approval_count=None,
                     host_authorization_count=len(authorizations), protocol_sha256=digest(protocol_path),
                     run_result_sha256=digest(directory / "run_result.json"),
                     common_task_prompt_sha256=protocol["common"]["task_prompt_sha256"],
                     common_tool_catalog_sha256=protocol["common"]["tool_catalog_sha256"],
                     catalogue_metadata_route="SDK retains annotations; common native-admin projection uses name/description/inputSchema",
                     elapsed_seconds=(run["finished_epoch_ms"] - run["started_epoch_ms"]) / 1000,
                     publication_accepted=bool(run.get("publication", {}).get("status") == "published"))
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
    result = _result(directory, checks, errors, facts)
    result["kind"] = "comparison_script_independent_verification_v1"
    return result


def digest_text(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Independently verify one preregistered comparison U/F session")
    parser.add_argument("directory", type=Path)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--scripted", action="store_true", help="Verify fixed C checklist SDK execution")
    args = parser.parse_args(argv)
    result = (verify_scripted if args.scripted else verify)(args.directory, args.protocol)
    output = safe_path(args.output)
    require(not output.is_relative_to(safe_path(args.directory)), "Verification output must be outside model evidence")
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps({"status": result["status"], "checks_passed": result["checks_passed"],
                      "checks_total": result["checks_total"], "output": str(output)}, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
