// Read-only event settlement shares the original deadline, including failures.
export async function waitOriginalSettlement(reading, deadline, now=Date.now) {
  const remaining=deadline-now();
  if(!Number.isFinite(remaining)||remaining<=0)throw new Error('Original deadline expired before settlement');
  let timer;
  try{return await Promise.race([reading,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Original deadline expired during settlement')),remaining);})]);}
  finally{clearTimeout(timer);}
}
