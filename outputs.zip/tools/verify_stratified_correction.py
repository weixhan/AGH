"""Independently review the additive correction using saved raw predictions.

Only the standard library is imported. No diagnosis, matching, or corrected
statistics implementation is imported or executed. This intentionally limits
the input audit to the correction's eight source files and publication chains.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


TASK = "4b1fa9d234ba4033ba29223c6e5e632e"
PARENT = "8d1d6900c7d74c90a29824495684807d"
SIZES = ("small", "medium", "large")
REGIONS = tuple(f"{y}_{x}" for y in ("top", "middle", "bottom")
                for x in ("left", "center", "right"))


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def load_rows(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]


def same(a, b):
    """Typed JSON comparison: never let True equal an integer count of one."""
    if isinstance(a, bool) or isinstance(b, bool):
        return type(a) is type(b) and a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return math.isfinite(a) and math.isfinite(b) and a == b
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    return a == b


def box_valid(box):
    return (isinstance(box, list) and len(box) == 4
            and all(isinstance(v, (int, float)) and not isinstance(v, bool)
                    and math.isfinite(v) for v in box)
            and box[0] < box[2] and box[1] < box[3])


def overlap(a, b):
    area_a = (a[2] - a[0]) * (a[3] - a[1])
    area_b = (b[2] - b[0]) * (b[3] - b[1])
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(
        0., min(a[3], b[3]) - max(a[1], b[1]))
    return intersection / (area_a + area_b - intersection)


def assign(record):
    """Greedy predictions by confidence, then source index; max-IoU free GT."""
    truths, predictions = record["ground_truth"], record["predictions"]
    active = sorted((i for i, p in enumerate(predictions) if p["confidence"] >= .25),
                    key=lambda i: (-predictions[i]["confidence"], i))
    consumed, matches = set(), {}
    for pi in active:
        prediction = predictions[pi]
        candidates = [(overlap(prediction["xyxy"], gt["xyxy"]), gi)
                      for gi, gt in enumerate(truths)
                      if gi not in consumed and gt["class_id"] == prediction["class_id"]]
        eligible = [(iou, gi) for iou, gi in candidates if iou >= .5]
        chosen = min(eligible, key=lambda item: (-item[0], item[1]))[1] if eligible else None
        matches[pi] = chosen
        if chosen is not None:
            consumed.add(chosen)
    return matches


def keys(box, width, height):
    area = (box[2] - box[0]) * (box[3] - box[1])
    size = "small" if area < 32 * 32 else "medium" if area < 96 * 96 else "large"
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    col = min(2, max(0, math.floor(cx * 3 / width)))
    row = min(2, max(0, math.floor(cy * 3 / height)))
    return {"size_bucket": size, "region": REGIONS[row * 3 + col]}


def compute(records):
    counts = {field: {name: Counter() for name in names}
              for field, names in (("size_bucket", SIZES), ("region", REGIONS))}
    tp_gt, tp_pred, fp_pred, match_rows = set(), set(), set(), {}
    for record in records:
        image = record["image_id"]
        matches = assign(record)
        inverse = {gi: pi for pi, gi in matches.items() if gi is not None}
        for gi, gt in enumerate(record["ground_truth"]):
            match_rows[image, gi] = inverse.get(gi)
            for field, name in keys(gt["xyxy"], record["width"], record["height"]).items():
                counts[field][name]["gt"] += 1
                counts[field][name]["tp_gt" if gi in inverse else "fn_gt"] += 1
            if gi in inverse:
                tp_gt.add((image, gi))
        for pi, gi in matches.items():
            p = record["predictions"][pi]
            category = "tp_predictions" if gi is not None else "fp_predictions"
            for field, name in keys(p["xyxy"], record["width"], record["height"]).items():
                counts[field][name][category] += 1
            (tp_pred if gi is not None else fp_pred).add((image, pi))
    result = {}
    for field, names in (("size_bucket", SIZES), ("region", REGIONS)):
        rows = []
        for name in names:
            c = counts[field][name]
            denominator = c["tp_predictions"] + c["fp_predictions"]
            rows.append({field: name, "gt": c["gt"], "tp_gt": c["tp_gt"],
                         "fn_gt": c["fn_gt"], "recall_gt": c["tp_gt"] / c["gt"] if c["gt"] else None,
                         "tp_predictions": c["tp_predictions"], "fp_predictions": c["fp_predictions"],
                         "precision_predictions": c["tp_predictions"] / denominator if denominator else None})
        result[field] = rows
    return result, tp_gt, tp_pred, fp_pred, match_rows


def review(root):
    directory = root / "outputs" / "diagnosis-stratified-correction"
    task_dir, parent_dir = root / "outputs" / TASK, root / "outputs" / PARENT
    correction_path, marker_path = directory / "stratified_statistics.json", directory / "completion.json"
    correction, marker = load_json(correction_path), load_json(marker_path)
    expected_paths = {
        "predictions_640.jsonl": parent_dir / "predictions_640.jsonl",
        "gt_details.jsonl": task_dir / "gt_details.jsonl",
        "fp_details.jsonl": task_dir / "fp_details.jsonl",
        "diagnosis_summary.json": task_dir / "diagnosis_summary.json",
        "completion.json": task_dir / "completion.json",
        "artifact_manifest.json": task_dir / "artifact_manifest.json",
        "write_stratified_diagnosis.py": root / "tools" / "write_stratified_diagnosis.py",
        "stratified_statistics.py": root / "defect_researcher" / "stratified_statistics.py",
    }
    checks = {}
    evidence = correction["source_evidence"]
    checks["eight_unique_expected_source_records"] = (len(evidence) == 8
        and {r["name"] for r in evidence} == set(expected_paths))
    snapshots = {name: path.read_bytes() for name, path in expected_paths.items()}
    checks["eight_source_paths_sizes_and_hashes_match"] = all(
        Path(row["path"]).resolve() == expected_paths[row["name"]].resolve()
        and len(snapshots[row["name"]]) == row["size_bytes"]
        and digest(snapshots[row["name"]]) == row["sha256"] for row in evidence)
    correction_bytes = correction_path.read_bytes()
    checks["correction_completion_binds_exact_artifact"] = (marker.get("status") == "completed"
        and marker.get("source_task_id") == TASK
        and marker["artifact"]["name"] == correction_path.name
        and Path(marker["artifact"]["path"]).resolve() == correction_path.resolve()
        and marker["artifact"]["size_bytes"] == len(correction_bytes)
        and marker["artifact"]["sha256"] == digest(correction_bytes))
    checks["correction_completion_written_after_artifact"] = marker_path.stat().st_mtime_ns >= correction_path.stat().st_mtime_ns
    source_completion = load_json(task_dir / "completion.json")
    source_manifest = load_json(task_dir / "artifact_manifest.json")
    parent_completion = load_json(parent_dir / "completion.json")
    parent_manifest = load_json(parent_dir / "artifact_manifest.json")
    checks["source_completion_hash_bound"] = marker.get("source_completion_sha256") == digest(snapshots["completion.json"])
    checks["source_diagnosis_completion_identity"] = (source_completion.get("task_id") == TASK
        and source_completion.get("status") == "completed" and source_completion.get("source_task_id") == PARENT
        and source_completion.get("tool") == "diagnose_validation_errors")
    checks["source_diagnosis_manifest_hash_bound"] = (source_completion["artifact_manifest_sha256"] == digest(snapshots["artifact_manifest.json"])
        and Path(source_completion["artifact_manifest"]).resolve() == (task_dir / "artifact_manifest.json").resolve()
        and source_manifest.get("task_id") == TASK and source_manifest.get("status") == "completed")
    manifest_rows = {row["name"]: row for row in source_manifest["files"]}
    bound_names = ("gt_details.jsonl", "fp_details.jsonl", "diagnosis_summary.json")
    checks["source_detail_and_summary_hashes_bound_to_completion_and_manifest"] = all(
        source_completion["artifacts_sha256"][name] == digest(snapshots[name]) == manifest_rows[name]["sha256"]
        and len(snapshots[name]) == manifest_rows[name]["size_bytes"]
        and Path(manifest_rows[name]["path"]).resolve() == expected_paths[name].resolve() for name in bound_names)
    checks["source_publication_marker_after_reviewed_artifacts_and_manifest"] = all(
        (task_dir / "completion.json").stat().st_mtime_ns >= (task_dir / name).stat().st_mtime_ns
        for name in (*bound_names, "artifact_manifest.json"))
    checks["parent_comparison_completion_and_manifest_bound"] = (
        parent_completion.get("task_id") == PARENT and parent_completion.get("status") == "completed"
        and parent_manifest.get("task_id") == PARENT and parent_manifest.get("status") == "completed"
        and parent_completion["artifact_manifest_sha256"] == digest((parent_dir / "artifact_manifest.json").read_bytes())
        and source_completion["source_completion_sha256"] == digest((parent_dir / "completion.json").read_bytes())
        and source_completion["source_manifest_sha256"] == digest((parent_dir / "artifact_manifest.json").read_bytes()))
    pred_row = next(row for row in parent_manifest["files"] if row["name"] == "predictions_640.jsonl")
    pred_hash = digest(snapshots["predictions_640.jsonl"])
    checks["raw_predictions_bound_to_both_publication_chains"] = (
        pred_hash == parent_completion["artifacts_sha256"]["predictions_640.jsonl"]
        == pred_row["sha256"] == source_completion["predictions_640_sha256"]
        == source_manifest["input_evidence"]["predictions_640_sha256"]
        and len(snapshots["predictions_640.jsonl"]) == pred_row["size_bytes"]
        and Path(pred_row["path"]).resolve() == expected_paths["predictions_640.jsonl"].resolve())
    records = load_rows(expected_paths["predictions_640.jsonl"])
    gt_rows, fp_rows = load_rows(expected_paths["gt_details.jsonl"]), load_rows(expected_paths["fp_details.jsonl"])
    summary = load_json(expected_paths["diagnosis_summary.json"])
    checks["correction_claims_and_schema"] = (correction.get("status") == "completed"
        and correction.get("source_diagnosis_task") == TASK and correction.get("input_hashes_unchanged") is True
        and correction.get("aggregate_and_branch_unchanged") is True
        and correction.get("superseded_fields") == ["diagnosis_summary.json/per_size/precision", "diagnosis_summary.json/per_region/precision"]
        and correction["statistics"].get("schema_version") == "separate-gt-and-prediction-strata-v1")
    checks["explicit_gt_recall_and_prediction_precision_grouping"] = same(correction["statistics"]["protocol"], {
        "confidence_threshold": .25, "recall_grouping": "ground_truth_box_size_or_center",
        "precision_grouping": "prediction_box_size_or_center", "matching": "reuse_hash_bound_verified_one_to_one_matches"})
    checks["source_operating_point_is_frozen_point25_iou50"] = (
        same(summary["reference"]["operating_point"]["confidence_threshold"], .25)
        and same(summary["reference"]["operating_point"]["iou_threshold"], .5))
    checks["640_unique_validation_images"] = (len(records) == 640 and len({r["image_id"] for r in records}) == 640
        and all(r["split"] == "val" and r["eval_imgsz"] == 640 for r in records))
    checks["raw_box_dimension_class_and_confidence_validity"] = all(
        type(r["width"]) is int and r["width"] > 0 and type(r["height"]) is int and r["height"] > 0
        and all(box_valid(obj["xyxy"]) and type(obj["class_id"]) is int and 0 <= obj["class_id"] <= 6
                for obj in r["ground_truth"] + r["predictions"])
        and all(isinstance(p["confidence"], (int, float)) and not isinstance(p["confidence"], bool)
                and math.isfinite(p["confidence"]) and 0 <= p["confidence"] <= 1 for p in r["predictions"])
        for r in records)
    expected, tp_gt, tp_pred, fp_pred, matches = compute(records)
    gt_ids = {(r["image_id"], i) for r in records for i in range(len(r["ground_truth"]))}
    checks["596_ground_truth_and_380_active_predictions"] = len(gt_ids) == 596 and len(tp_pred | fp_pred) == 380
    checks["independent_match_totals_tp231_fp149_fn365"] = len(tp_gt) == len(tp_pred) == 231 and len(fp_pred) == 149 and len(gt_ids - tp_gt) == 365
    checks["gt_rows_form_unique_complete_source_population"] = len(gt_rows) == len(gt_ids) and {(r["image_id"], r["gt_index"]) for r in gt_rows} == gt_ids
    checks["gt_match_status_and_prediction_id_independently_recomputed"] = all(
        r["status"] == ("tp" if (r["image_id"], r["gt_index"]) in tp_gt else "fn")
        and same(r["matched_prediction_index"], matches[r["image_id"], r["gt_index"]]) for r in gt_rows)
    checks["fp_rows_form_unique_exact_unmatched_active_predictions"] = len(fp_rows) == len(fp_pred) and {(r["image_id"], r["prediction_index"]) for r in fp_rows} == fp_pred
    lookup = {r["image_id"]: r for r in records}
    checks["gt_and_fp_source_coordinates_and_classes_match"] = all(
        same(r["xyxy"], lookup[r["image_id"]]["ground_truth"][r["gt_index"]]["xyxy"])
        and same(r["class_id"], lookup[r["image_id"]]["ground_truth"][r["gt_index"]]["class_id"]) for r in gt_rows) and all(
        same(r["xyxy"], lookup[r["image_id"]]["predictions"][r["prediction_index"]]["xyxy"])
        and same(r["class_id"], lookup[r["image_id"]]["predictions"][r["prediction_index"]]["class_id"])
        and same(r["confidence"], lookup[r["image_id"]]["predictions"][r["prediction_index"]]["confidence"]) for r in fp_rows)
    checks["three_size_strata_all_fields_recomputed"] = same(correction["statistics"]["size_bucket"], expected["size_bucket"])
    checks["nine_region_strata_all_fields_recomputed"] = same(correction["statistics"]["region"], expected["region"])
    checks["both_groupings_have_identical_gt_tp_fp_fn_totals"] = all(
        {key: sum(row[key] for row in expected[field]) for key in ("gt", "tp_gt", "fn_gt", "tp_predictions", "fp_predictions")}
        == {"gt": 596, "tp_gt": 231, "fn_gt": 365, "tp_predictions": 231, "fp_predictions": 149}
        for field in ("size_bucket", "region"))
    checks["aggregate_counts_unchanged_from_sealed_summary"] = all(
        summary["reference"]["operating_point"][key] == value for key, value in {"tp": 231, "fp": 149, "fn": 365}.items())
    checks["source_snapshot_bytes_unchanged_during_review"] = all(path.read_bytes() == snapshots[name] for name, path in expected_paths.items())
    failed = [name for name, ok in checks.items() if not ok]
    return {"schema_version": "independent-stratified-correction-review-v1", "status": "failed" if failed else "passed",
            "source_task_id": TASK, "source_prediction_task_id": PARENT, "verified_at": datetime.now(timezone.utc).isoformat(),
            "checks": checks, "passed_checks": len(checks) - len(failed), "total_checks": len(checks), "failed_checks": failed,
            "independent_implementation": "standard-library IoU and confidence-ordered same-class greedy matching recomputed from raw predictions and GT; no project diagnostic/statistics modules imported",
            "recomputed_totals": {"images": 640, "gt": len(gt_ids), "tp_gt": len(tp_gt), "tp_predictions": len(tp_pred), "fp_predictions": len(fp_pred), "fn_gt": len(gt_ids - tp_gt)},
            "recomputed_statistics": expected,
            "review_evidence_sha256": {"stratified_statistics.json": digest(correction_bytes), "completion.json": digest(marker_path.read_bytes()), "reviewer": digest(Path(__file__).read_bytes())},
            "limitations": ["The original v1 size/region precision fields remain sealed and deprecated; this verifies the separate corrected artifact.",
                            "The eight bound source files and publication chains were checked; the earlier 10,271-input scan and 61-check diagnosis review were not repeated.",
                            "Raw saved predictions establish validation arithmetic only; no inference, model session, training, or experimental slicing was performed.",
                            "Completion mtime ordering is supporting evidence rather than a tamper-proof timing guarantee."]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or args.root / "outputs" / "diagnosis-stratified-correction" / "independent_verification.json"
    try:
        result = review(args.root.resolve())
    except Exception as exc:
        result = {"schema_version": "independent-stratified-correction-review-v1", "status": "failed", "error": f"{type(exc).__name__}: {exc}"}
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result.get(key) for key in ("status", "passed_checks", "total_checks", "failed_checks", "error")}, ensure_ascii=False))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
