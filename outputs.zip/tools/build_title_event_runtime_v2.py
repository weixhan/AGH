"""Create a side-by-side runtime by changing one invalid diagnostic event name.

The original sources, runtime and preserved sessions remain byte-identical.
This is a checked bundle transform, not a claim of a new TypeScript build.
"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[1]
OLD = b'x/host/session-title-diagnostics'
NEW = b'x/host/session-title/diagnostics'

def pin(path):
    path = Path(path).resolve(); raw = path.read_bytes()
    return {'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw)}

def save(path, value):
    with Path(path).open('x', encoding='utf8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write('\n')

def main():
    prior = ROOT / 'outputs/agh-title-repair-v1/repair_verification.json'
    manifest = json.loads(prior.read_text('utf8'))
    for row in manifest['runtime_files']:
        if pin(row['path'])['sha256'] != row['sha256'] or pin(row['archive'])['sha256'] != row['sha256']:
            raise ValueError('Original runtime changed; transform refused')
    source = ROOT.parent / 'agnes-harness/packages/cli/dist/local'
    target = ROOT / 'outputs/agh-title-repair-v2'
    target.mkdir()
    runtime = target / 'runtime/packages/cli/dist/local'
    # Explicitly omit diagnostic copies made during the preserved V11 diagnosis.
    shutil.copytree(source, runtime, ignore=shutil.ignore_patterns('*diagnostic-v11*.mjs'))
    transforms = []
    for name in ('agnes.mjs', 'daemon.mjs', 'worker.mjs'):
        path = runtime / name; before = path.read_bytes()
        expected = 0 if name == 'daemon.mjs' else 1
        if before.count(OLD) != expected:
            raise ValueError('Unexpected diagnostic event token population')
        after = before.replace(OLD, NEW)
        if len(after) != len(before) or sum(a != b for a,b in zip(before,after)) != expected:
            raise ValueError('Transform changed more than the registered event name')
        path.write_bytes(after)
        transforms.append({'before':pin(source/name),'after':pin(path),
                           'byte_differences':expected,'old_occurrences':expected,
                           'new_occurrences':after.count(NEW)})
    host = ROOT.parent / 'agnes-harness/packages/host/src/session-title.ts'
    patched = target / 'source/session-title.ts';patched.parent.mkdir()
    text = host.read_bytes()
    if text.count(OLD) != 1:raise ValueError('Unexpected original host event name')
    patched.write_bytes(text.replace(OLD,NEW))
    save(target/'transform_receipt.json', {'schema_version':1,
        'status':'transformed_pending_tests','original_runtime_manifest':pin(prior),
        'old_event':OLD.decode(),'new_event':NEW.decode(),
        'runtime_directory':str(runtime),'transforms':transforms,
        'source_before':pin(host),'source_after':pin(patched),
        'builder':pin(__file__),'original_sources_modified':False,
        'compiler_invoked':False,'model_requests':0})
    print(json.dumps({'status':'transformed_pending_tests','runtime_directory':str(runtime),
                      'changed_bundle_bytes':sum(r['byte_differences'] for r in transforms)}))

if __name__=='__main__':main()
