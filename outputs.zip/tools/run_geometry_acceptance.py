"""Persist isolated positive, injected-error and missing-input acceptance cases.

All images and annotations are synthetic geometry fixtures. No production
data, model weights, AGH permissions or provider configuration is changed.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))
from test_geometry_verifier import geometry_configuration
from defect_researcher.geometry_verifier import verify_label_geometry
from defect_researcher.task_runtime import get_task_status


def snapshot(root: Path) -> dict:
    return {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in root.rglob("*") if path.is_file()}


def main() -> int:
    tag = "geometry-acceptance-" + uuid.uuid4().hex
    source_base = ROOT / ".runtime" / "geometry-demo-inputs" / tag
    evidence_base = ROOT / "outputs" / tag
    source_base.mkdir(parents=True)
    evidence_base.mkdir(parents=True)
    cases = []
    for name, label_value, expected_status, expected_finding in (
        ("normal", None, "completed", "passed"),
        ("coordinate_changed", "0 0.41 0.35 0.10 0.40", "completed", "failed"),
        ("rotation_ignored", "0 0.40 0.35 0.40 0.10", "completed", "failed"),
        ("missing_source", None, "failed", None),
    ):
        source = source_base / name
        source.mkdir()
        config = geometry_configuration(source)
        config["output_root"] = str(evidence_base / name)
        if label_value:
            (Path(config["dataset_root"]) / "labels/train/image_1.txt").write_text(label_value, encoding="utf-8")
        if name == "missing_source":
            removed = (Path(config["raw_root"]) / "cable_2.json").resolve()
            if not removed.is_relative_to(source.resolve()):
                raise ValueError("Failure injection must stay inside the new synthetic case")
            removed.unlink()
        before = snapshot(source)
        report = verify_label_geometry(config, task_id=name)
        reread = get_task_status(config, name)
        finding = report.get("summary", {}).get("verification_status")
        differences = report.get("summary", {}).get("issue_samples", [])
        located = name not in {"coordinate_changed", "rotation_ignored"} or any(
            row.get("annotation_id") == 101 and row.get("code") == "yolo_geometry" for row in differences)
        check = {
            "expected_execution_status": report.get("status") == expected_status,
            "expected_verification_finding": finding == expected_finding,
            "changed_annotation_located": located,
            "synthetic_inputs_unchanged_by_verifier": before == snapshot(source),
            "saved_status_matches": reread.get("status") == expected_status
                and reread.get("summary", {}).get("verification_status") == expected_finding,
            "completion_marker_only_for_finished_execution":
                (evidence_base / name / name / "completion.json").exists() == (expected_status == "completed"),
        }
        cases.append({"case": name, "kind": "synthetic", "checks": check,
                      "status": "passed" if all(check.values()) else "failed",
                      "execution_status": report.get("status"), "verification_status": finding,
                      "task_id": name, "configuration": config, "artifacts": report.get("artifacts"),
                      "issue_samples": differences, "errors": report.get("errors")})
    result = {"schema_version": 1, "test_kind": "isolated_geometry_verifier_acceptance",
              "status": "passed" if all(case["status"] == "passed" for case in cases) else "failed",
              "cases": cases, "production_inputs_modified": False,
              "limitations": ["These are synthetic geometry cases with image membership placeholders, not decoded real images.",
                              "They demonstrate detection of two injected label errors and one execution failure; no repair is performed."]}
    destination = evidence_base / "acceptance.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "cases": len(cases), "evidence": str(destination)}, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
