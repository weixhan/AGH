import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {exportSession} from '../../agnes-harness/packages/cli/src/commands/export.ts';
import {webClient} from './agh_ws_client.mjs';
const root=resolve('.'),out=join(root,'outputs/comparison-native-title-reconciliation-v1');await mkdir(out,{recursive:false});
const rows=[{version:'v3',session_id:'042301d9-8a32-434c-8f9a-8993396c2a0a'},{version:'v4',session_id:'baab492e-401f-4e89-a852-75f0875d7c50'}];
for(const row of rows){const client=await webClient();try{await exportSession({positional:[row.session_id],format:'agnes',raw:false,out:join(out,row.version+'.jsonl')},{cwd:root,io:{stdout:process.stdout,stderr:process.stderr},writeFile:(p,b)=>writeFile(p,b,{flag:'wx'})},client);}finally{await client.close();}}
await writeFile(join(out,'export_receipt.json'),JSON.stringify({schema_version:1,status:'read_only_exported',sessions:rows,old_sources_and_exports_modified:false,model_requests_in_this_reconciliation:0},null,2)+'\n',{flag:'wx'});
