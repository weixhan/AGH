"""Check the completed scoped read from the official exported ledger and public SDK observation."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "outputs" / "agh-scoped-evidence"


def read(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    runner = read(OUTPUT / "runner.json")
    rows = [json.loads(line) for line in (OUTPUT / "session.jsonl").read_text(encoding="utf-8").splitlines() if line]
    events = [row for row in rows if isinstance(row.get("seq"), int)]
    calls = [row for row in events if row["type"] == "tool/call"]
    results = [row for row in events if row["type"] == "tool/result"]
    ready = [row for row in events if row["type"].endswith("/scope-ready")]
    gates = [row for row in events if row["type"].endswith("/scope-decision")]
    requests = [row for row in events if row["type"] == "request/sent"]
    policy = runner["policy"]
    # The official non-raw exporter maps its exact cwd to this literal marker.
    # Verify the public SDK's unmasked policy too; accept no other masked field.
    exported_policy = {**policy, "workspace_root": "<workspace>"}
    old = read(ROOT / "outputs" / "agh-resolution-comparison" / "model_run_verification.json")
    observed = runner["results"][0]
    expected = {"status": "completed", "task_id": policy["task_id"],
                "val_images": observed["summary"]["val_images"], "val_boxes": observed["summary"]["val_boxes"],
                "metrics": observed["summary"]["metrics"]}
    checks = {
        "runner_passed": runner["status"] == "passed" and all(runner["checks"].values()),
        "fresh_session_differs_from_full_comparison": runner["session_id"] != "3f0c8ed9-e5fd-4775-8b36-df37f00e1004",
        "official_ledger_contiguous": [row["seq"] for row in events] == list(range(1, len(events) + 1)),
        "one_status_call_and_result": len(calls) == len(results) == 1,
        "exact_tool_and_task": all(row["data"]["name"] == policy["qualified_status_tool"] and
                                   row["data"]["args"] == {"task_id": policy["task_id"]} for row in calls),
        "scope_ready_before_first_request": len(ready) == 1 and bool(requests) and ready[0]["seq"] < requests[0]["seq"],
        "scope_ready_policy_exact": bool(ready) and ready[0]["data"]["policy"] == exported_policy and
                                    ready[0]["data"]["mode"] == "evidence" and
                                    runner["scope_ready"]["data"]["policy"] == policy,
        "gate_precedes_tool_result": len(gates) == 1 and bool(results) and gates[0]["seq"] < results[0]["seq"],
        "gate_matches_call": len(gates) == len(calls) == 1 and gates[0]["data"]["allow"] is True and
                             gates[0]["data"]["tool_use_id"] == calls[0]["data"]["toolUseId"],
        "no_error_or_refusal": all(row["data"].get("isError") is False for row in results),
        "model_numbers_match_actual_result": runner["final_json"] == expected,
        "scope_does_not_launch_inference": runner["training_or_inference_started"] is False,
        "catalog_visibility_boundary_preserved": runner["tool_catalog_narrowed"] is False,
        "old_full_scope_failure_preserved": old["status"] == "failed" and old["strict_tool_scope_passed"] is False and
                                            runner["old_full_comparison_acceptance_repaired"] is False,
    }
    report = {"schema_version": 1, "status": "passed" if all(checks.values()) else "failed",
              "session_id": runner["session_id"], "checks": checks,
              "execution_scope_guard_live_verified": all(checks.values()),
              "model_tool_catalog_narrowed": False, "old_full_comparison_acceptance_repaired": False,
              "limitations": ["A completed-evidence read does not re-run the original GPU experiment.",
                              "Synthetic Core refusal tests establish the hook's execution gate separately.",
                              "A reloaded Host does not preserve the in-memory call budget."]}
    (OUTPUT / "independent_verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks_passed": sum(checks.values()), "checks_total": len(checks)}))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
