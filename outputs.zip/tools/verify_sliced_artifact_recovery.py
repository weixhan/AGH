"""New, zero-inference review of saved slicing artifacts from a failed task.

The original experiment remains failed and has no completion marker. Its
inference and execution budgets are never reset. This separate artifact review
has a new 600-second deadline and reuses the byte-bound independent scientific
oracle, not the production runner or scoring implementation.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

PRIMARY_PATH = Path(__file__).with_name("verify_sliced_run.py").resolve()
PRIMARY_SHA256 = "5c94e2210ecae92cde785a413cb01e09086a3fb1694dfc9bac2abb3465b213f1"
ROOT = Path(__file__).resolve().parents[1]
ORIGIN_ID = "09c5ce4aceb7426e87af5334bdb03eb4"
PROTOCOL_ID = "saved-sliced-artifacts-readonly-recovery-v1"
IMPLEMENTATION_VERSION = 3
EXECUTION_ROLES = {"sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
    "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier"}


def file_sha(path):
    out = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            out.update(chunk)
    return out.hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def load_primary():
    require(file_sha(PRIMARY_PATH) == PRIMARY_SHA256, "Frozen independent scientific verifier bytes changed")
    spec = importlib.util.spec_from_file_location("frozen_independent_sliced_science", PRIMARY_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_P = load_primary()
# Named aliases retain the original independent implementations and their
# original globals. No function, read operation or check result is monkeypatched.
for _name in ("CLASSES", "SIZES", "REGIONS", "BASELINE_TASK", "DIAGNOSIS_TASK", "WEIGHT_SHA", "PREDICTIONS_SHA",
    "SOURCE_SHA", "BASELINE_FILES", "DIAGNOSIS_FILES", "CONTROLS", "digest", "decode", "read", "lines", "same",
    "contains", "finite", "scoped_file", "publication", "bucket", "expected_crops", "map_predictions",
    "source_gt", "canonical_sha", "metrics", "comparison", "_budget_checks"):
    globals()[_name] = getattr(_P, _name)


class FreshHashBoundary:
    """Read each physical file once in one explicit integrity boundary.

    This cache has no persistence, timestamp shortcut or cross-boundary reuse.
    A new instance is required for the after-review boundary. Byte counts are
    obtained from the same full read as the SHA, rather than inferred from mtime.
    """

    def __init__(self):
        self._resolved = {}
        self._files = {}
        self.bytes_read = 0

    def resolve(self, path):
        path = Path(path)
        if path not in self._resolved:
            resolved = path.resolve()
            self._resolved[path] = resolved
            self._resolved[resolved] = resolved
        return self._resolved[path]

    def snapshot(self, path):
        path = self.resolve(path)
        if path not in self._files:
            sha, size = hashlib.sha256(), 0
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    sha.update(chunk)
                    size += len(chunk)
            self._files[path] = sha.hexdigest(), size
            self.bytes_read += size
        return self._files[path]

    def digest(self, path):
        return self.snapshot(path)[0]

    def size(self, path):
        return self.snapshot(path)[1]

    def scoped_file(self, path, roots):
        path = self.resolve(path)
        if not path.is_file() or not any(path.is_relative_to(self.resolve(root)) for root in roots):
            raise ValueError(f"Evidence file absent or outside scope: {path}")
        return path

    def measurements(self):
        return {"unique_files_hashed": len(self._files), "bytes_read": self.bytes_read}

    def publication(self, directory, task_id, tool, required, marker_name="completion.json"):
        """Preserve the primary publication contract using this boundary SHA.

        This is an integrity check, not a replacement scientific calculator.
        The marker/manifest/all-file identities and marker-last rule are exactly
        the original oracle's rules; all bytes share the role manifest cache.
        """
        directory = self.resolve(directory)
        marker, manifest = read(directory / marker_name), read(directory / "artifact_manifest.json")
        if any(row.get("task_id") != task_id or row.get("tool") != tool or row.get("status") != "completed"
               for row in (marker, manifest)):
            return False
        if (self.resolve(marker.get("artifact_manifest", "")) != directory / "artifact_manifest.json"
                or marker.get("artifact_manifest_sha256") != self.digest(directory / "artifact_manifest.json")):
            return False
        rows = manifest.get("files", [])
        names = {row.get("name") for row in rows}
        if len(rows) != len(names) or not required <= names:
            return False
        for row in rows:
            path = self.scoped_file(row["path"], [directory])
            if (path.parent != directory or path.name != row["name"] or row["size_bytes"] != self.size(path)
                    or row["sha256"] != self.digest(path)):
                return False
        if marker.get("artifacts_sha256") != {row["name"]: row["sha256"] for row in rows}:
            return False
        marker_time = (directory / marker_name).stat().st_mtime_ns
        return all(marker_time >= (directory / name).stat().st_mtime_ns for name in names | {"artifact_manifest.json"})


def expected_trace(observations, *, stats=None):
    """Independently reproduce the frozen full trace with same-class vector IoU.

    Winner order, strict suppression and truncation after all NMS survivors are
    unchanged. Float64 comparisons near the threshold use the original scalar
    oracle; every published suppression IoU is also computed by that oracle.
    The frozen primary module and its scientific functions are never modified.
    """
    import numpy as np

    candidates = sorted((dict(p) for row in observations for p in row["global_predictions"]),
        key=lambda p: (-p["confidence"], p["pass_id"], p["prediction_index"]))
    boxes = np.asarray([p["xyxy"] for p in candidates], dtype=np.float64).reshape((-1, 4))
    classes = np.asarray([p["class_id"] for p in candidates], dtype=np.int64)
    active = np.arange(len(candidates), dtype=np.int64)
    selected, suppressed = [], []
    scalar_calls, same_class_pairs = 0, 0
    while active.size:
        winner_index = int(active[0])
        winner = candidates[winner_index]
        selected.append(winner)
        remaining = active[1:]
        comparable = remaining[classes[remaining] == classes[winner_index]]
        rejected = np.zeros(remaining.size, dtype=bool)
        if comparable.size:
            same_class_pairs += int(comparable.size)
            a, b = boxes[winner_index], boxes[comparable]
            intersection = (np.maximum(0., np.minimum(a[2], b[:, 2]) - np.maximum(a[0], b[:, 0]))
                * np.maximum(0., np.minimum(a[3], b[:, 3]) - np.maximum(a[1], b[:, 1])))
            union = ((a[2] - a[0]) * (a[3] - a[1])
                + (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1]) - intersection)
            if np.any(union <= 0):
                raise ValueError("Nonpositive box union")
            overlap = intersection / union
            decisions = overlap > .7
            for position in np.flatnonzero(np.abs(overlap - .7) <= 1e-12):
                pred = candidates[int(comparable[position])]
                overlap[position] = _P.iou(winner["xyxy"], pred["xyxy"])
                scalar_calls += 1
                decisions[position] = overlap[position] > .7
            discarded = comparable[decisions]
            # Comparable/remaining arrays retain the original stable candidate
            # order. searchsorted maps back without any confidence reordering.
            rejected[np.searchsorted(remaining, discarded)] = True
            for candidate_index in discarded:
                pred = candidates[int(candidate_index)]
                exact_overlap = _P.iou(winner["xyxy"], pred["xyxy"])
                scalar_calls += 1
                suppressed.append({"pass_id": pred["pass_id"], "prediction_index": pred["prediction_index"],
                    "suppressed_by_pass_id": winner["pass_id"],
                    "suppressed_by_prediction_index": winner["prediction_index"], "iou": exact_overlap})
        active = remaining[~rejected]
    kept, truncated = selected[:300], selected[300:]
    predictions = [{"class_id": p["class_id"], "confidence": p["confidence"], "xyxy": p["xyxy"]} for p in kept]
    kept_lookup = {(p["pass_id"], p["prediction_index"]): i for i, p in enumerate(kept)}
    discard = {(p["pass_id"], p["prediction_index"]) for p in truncated}
    suppressed_lookup = {(p["pass_id"], p["prediction_index"]): p for p in suppressed}
    rows = []
    for rank, candidate in enumerate(candidates):
        key = candidate["pass_id"], candidate["prediction_index"]
        disposition = suppressed_lookup.get(key)
        row = {**candidate, "candidate_rank": rank, "status": "suppressed_iou" if disposition else
            "global_max_det" if key in discard else "kept", "suppressed_by": None,
            "suppression_iou": None, "final_prediction_index": kept_lookup.get(key)}
        if disposition:
            row.update(suppressed_by={"pass_id": disposition["suppressed_by_pass_id"],
                "prediction_index": disposition["suppressed_by_prediction_index"]}, suppression_iou=disposition["iou"])
        rows.append(row)
    if stats is not None:
        stats.update(candidate_count=len(candidates), same_class_pairs=same_class_pairs, scalar_iou_calls=scalar_calls)
    return predictions, {"schema_version": "fixed-nine-pass-fusion-trace-v1", "nms_iou": .7,
        "suppression_comparator": ">", "global_max_det": 300,
        "confidence_ties": "pass_id_then_original_prediction_index", "candidate_count": len(candidates),
        "nms_survivor_count": len(selected), "suppressed_count": len(suppressed),
        "global_max_det_discarded_count": len(truncated), "final_count": len(predictions), "rows": rows}


class ReviewProgress:
    """Flush stage measurements even when the external deadline kills review."""

    def __init__(self, task_id):
        self.task_id = task_id
        self.started = self.stage_started = time.perf_counter()
        self.stage = None
        self.timings = {}

    def begin(self, stage, **counts):
        if self.stage is not None:
            self.end()
        self.stage, self.stage_started = stage, time.perf_counter()
        self.emit("started", **counts)

    def emit(self, status, **counts):
        print(json.dumps({"task_id": self.task_id, "stage": self.stage, "status": status,
            "elapsed_seconds": time.perf_counter() - self.started,
            "stage_seconds": time.perf_counter() - self.stage_started, **counts}, allow_nan=False), flush=True)

    def end(self, **counts):
        self.timings[self.stage] = time.perf_counter() - self.stage_started
        self.emit("finished", **counts)
        self.stage = None


def source_manifest_check(directory, saved, origin_id, *, boundary=None):
    boundary = boundary or FreshHashBoundary()
    directory = boundary.resolve(directory)
    require(isinstance(saved, dict) and type(saved.get("schema_version")) is int and saved["schema_version"] == 1
        and saved.get("origin_task_id") == origin_id
        and boundary.resolve(saved.get("source_directory", "")) == directory
        and saved.get("original_completion_absent") is True,
        "Original artifact manifest identity differs")
    rows = saved.get("files")
    require(isinstance(rows, list) and type(saved.get("file_count")) is int and len(rows) == saved["file_count"] > 0,
        "Original artifact manifest count is invalid")
    observed = []
    for path in sorted(directory.rglob("*")):
        require(not path.is_symlink(), "Original source task contains a symlink")
        if path.is_file():
            observed.append(path.relative_to(directory).as_posix())
    relative = [row.get("relative_path") for row in rows]
    require(len(set(relative)) == len(relative) and set(relative) == set(observed),
        "Original artifact manifest omits, duplicates or adds a file")
    for row in rows:
        name = row["relative_path"]
        require(isinstance(name, str) and "\\" not in name and not Path(name).is_absolute()
            and not {".", ".."} & set(Path(name).parts), "Unsafe original artifact path")
        path = directory / name
        require(boundary.resolve(path).is_relative_to(directory) and type(row.get("size_bytes")) is int
            and row["size_bytes"] == boundary.size(path) and row.get("sha256") == boundary.digest(path),
            "Original artifact bytes changed")
    require(not (directory / "completion.json").exists(), "Original failed task acquired a completion marker")
    return True


def recovery_protocol_check(saved, recovery_id, origin_id, recovery_directory, directory, *, boundary=None):
    boundary = boundary or FreshHashBoundary()
    require(type(saved.get("schema_version")) is int and saved["schema_version"] == 1
        and saved.get("protocol_id") == PROTOCOL_ID and saved.get("task_id") == recovery_id
        and type(saved.get("artifact_review_implementation_version")) is int
        and saved["artifact_review_implementation_version"] == IMPLEMENTATION_VERSION
        and saved.get("computation_task_id") == saved.get("source_computation_task_id") == origin_id
        and Path(saved.get("execution_directory", "")).resolve() == directory
        and saved.get("original_business_status") == "failed"
        and saved.get("original_pipeline_acceptance_passed") is False
        and saved.get("original_budget_reset") is False,
        "Artifact-only recovery identity or historical failure claim differs")
    for key in ("new_predict_calls", "new_gpu_calls"):
        require(type(saved.get(key)) is int and saved[key] == 0, "Recovery protocol permits new inference")
    require(finite(saved.get("new_gpu_seconds")) and saved["new_gpu_seconds"] == 0,
        "Recovery protocol permits new GPU time")
    require(type(saved.get("new_warmup_calls")) is int and saved["new_warmup_calls"] == 0
        and saved.get("new_detection_inference_performed") is False, "Recovery protocol permits new warmup or detector inference")
    require("nms_expected" in saved and saved["nms_expected"] is None,
        "Recovery requires exactly the sealed external-NMS default, nms null")
    require(type(saved.get("max_recovery_wall_seconds")) is int and saved["max_recovery_wall_seconds"] == 600
        and finite(saved.get("recovery_started_epoch"), True), "Recovery deadline differs from the new 600-second budget")
    require(time.time() - saved["recovery_started_epoch"] <= 600, "New artifact-review deadline expired")
    require(saved.get("original_completion_absent") is True
        and saved.get("original_final_review_completed_within_1800_seconds") is False,
        "Original missing completion or failed final acceptance has been hidden")
    require(saved.get("independent_reviewer_sha256") == boundary.digest(Path(__file__)),
        "New recovery reviewer bytes differ from the frozen protocol")
    require(saved.get("producer_source_sha256") == boundary.digest(ROOT / "defect_researcher" / "sliced_artifact_recovery.py"),
        "New recovery producer bytes differ from the frozen protocol")
    for key, filename in (("source_failure_sha256", "failure.json"), ("source_inputs_sha256", "inputs.json")):
        require(saved.get(key) == boundary.digest(directory / filename), "Original recovery source binding differs")
    require(saved.get("source_manifest_sha256") == boundary.digest(recovery_directory / "recovery_source_manifest.json"),
        "New recovery source-manifest binding differs")
    return True


def strict_external_nms(actual, reference):
    return (isinstance(actual, dict) and isinstance(reference, dict)
        and "nms" in actual and "nms" in reference and actual["nms"] is None and reference["nms"] is None
        and same(actual, reference, 0) and contains(actual, CONTROLS, 0))


def failed_artifact_schema_subchecks(failure, expected_evidence, origin_id, directory):
    """Check the original failed-report schema without inventing a publication.

    Failed reports store their full source identities under ``evidence``. Only
    successful completion candidates flatten these fields. Exact nested values,
    task/tool/status and absent success artifacts are all required here; an
    empty, incomplete or flattened identity cannot stand in for the failed one.
    """
    directory = Path(directory)
    return {
        "failed_report_task_tool_status_exact": isinstance(failure, dict)
            and failure.get("task_id") == origin_id and failure.get("tool") == "compare_validation_slices"
            and failure.get("status") == "failed",
        "failed_report_all_nested_evidence_fields_exact": isinstance(failure, dict)
            and same(failure.get("evidence"), expected_evidence, 0),
        "failed_report_has_no_flat_success_marker_claim": isinstance(failure, dict)
            and not (set(expected_evidence) | {"artifact_manifest", "artifact_manifest_sha256", "artifacts_sha256"}) & failure.keys(),
        "original_completion_and_candidate_absent": all(not (directory / name).exists()
            for name in ("completion.json", "completion_candidate.json")),
        "original_unpublished_manifest_and_success_result_absent": all(not (directory / name).exists()
            for name in ("artifact_manifest.json", "sliced_result.json")),
    }


def summary_checks(summary, analysis, budget, rows):
    a, b, gains = analysis["baseline_metrics"], analysis["sliced_metrics"], analysis["gains"]
    def compact(value, arm):
        point = value["operating_point"]
        return {"mAP50": value["mAP50"], "mAP50_95": value["mAP50_95"],
            **{k: point[k] for k in ("tp", "fp", "fn", "precision", "recall")},
            "normal_fp_images": point["normal_images_with_false_positives"],
            "normal_image_fp_rate": point["normal_image_fp_rate"],
            "normal_fp_boxes": analysis["normal_false_positives"][arm]["fp_boxes"]}
    return {
        "artifact_recovery_summary_original_baseline_and_candidate_metrics_exact":
            same(summary.get("baseline"), compact(a, "baseline"), 1e-10)
            and same(summary.get("sliced"), compact(b, "sliced"), 1e-10),
        "artifact_recovery_summary_original_scientific_decision_and_gains_exact":
            summary.get("candidate_status") == analysis["scientific_decision"]["status"]
            and same(summary.get("failed_gates"), analysis["scientific_decision"]["failed_gates"], 0)
            and same(summary.get("gains"), gains, 1e-10) and same(summary.get("population"), analysis["population"], 0),
        "artifact_recovery_summary_original_medium_gt_and_gain_counts_exact":
            same(summary.get("medium"), {"gt": analysis["population"]["medium_gt"],
                "images": analysis["population"]["medium_images"], **{k: gains[k] for k in
                    ("medium_tp_gain", "medium_gain_images", "medium_recovered_gt", "medium_lost_gt")}}, 0),
        "artifact_recovery_summary_original_call_costs_and_input_count_exact":
            all(type(summary.get(k)) is int and summary[k] == budget[k]
                for k in ("successful_observations", "formal_calls", "warmup_calls"))
            and type(summary.get("input_files")) is int and summary["input_files"] == len(rows)
            and same(summary.get("gpu_seconds"), budget["gpu_seconds"], 0)
            and same(summary.get("inference_wall_seconds"), budget["inference_wall_seconds"], 0),
    }

REQUIRED_CHECKS = frozenset({
    'actual_fp32_tensor_model_cuda_and_tf32_disabled',
    'all_10256_upstream_inputs_still_valid_and_inherited',
    'all_21_class_size_cells_including_null_and_support',
    'all_5760_unique_observations_same_order',
    'all_596_gt_recovery_and_loss_provenance',
    'all_640_paired_image_rows_and_medium_denominators',
    'all_640_unique_val_members_same_frozen_order',
    'all_actual_call_indices_times_and_necessary_failed_retries',
    'all_current_input_bytes_equal_before_and_after',
    'all_input_roles_paths_and_dependency_binary_contract_exact',
    'all_observations_bound_protocol_and_weight',
    'all_observations_same_environment_identity',
    'all_original_artifact_bytes_unchanged_after_full_independent_review',
    'all_seven_classes_original_gt_recall_and_transitions',
    'all_split_byte_hashes_remain_dataset_bound',
    'artifact_recovery_new_protocol_and_separate_600_second_budget',
    'artifact_recovery_protocol_requires_zero_new_detector_and_gpu_calls',
    'artifact_recovery_summary_original_baseline_and_candidate_metrics_exact',
    'artifact_recovery_summary_original_call_costs_and_input_count_exact',
    'artifact_recovery_summary_original_medium_gt_and_gain_counts_exact',
    'artifact_recovery_summary_original_scientific_decision_and_gains_exact',
    'baseline_596_gt_245_normal_77_medium_74_medium_images',
    'baseline_and_candidate_exact_validation_order',
    'baseline_independent_ap101_matches_old_and_new_saved',
    'baseline_publication_chain_valid',
    'both_arms_original_label_gt_exact',
    'budget_5760_formal_successes_no_successful_pass_reruns',
    'budget_formal_calls_failed_retry_limit_and_single_warmup',
    'checkpoint_index_has_all_unique_observations',
    'complete_post_nms_lists_and_local_to_global_coordinates',
    'configuration_matches_bound_baseline_and_current',
    'context_path_tile_bgr_no_alternative_predict_entry',
    'context_reuse_declared_gate_matches_derived_evidence',
    'correct_gt_recall_and_prediction_precision_strata',
    'cumulative_gpu_cost_includes_all_calls_and_warmup',
    'current_dependency_sources_hash_bound_and_current_codec',
    'current_image_bytes_pixels_and_label_metadata_input_coverage',
    'current_images_unchanged_during_independent_pixel_review',
    'dataset_seven_classes_and_val_root',
    'diagnosis_independent_review_source_bound_passed',
    'diagnosis_publication_chain_valid',
    'each_original_gt_transition_linked_to_diagnosis',
    'every_checkpoint_hash_identity_output_and_call_binding',
    'every_observation_actual_controls_fp32_and_positive_timing',
    'fixed_numeric_controls_budget_and_selection_rules',
    'fixed_protocol_matches_current_frozen_fixture',
    'frozen_baseline_prediction_bytes',
    'frozen_crops_and_every_decoded_tile_pixel_hash',
    'frozen_primary_independent_scientific_verifier_exact_hash',
    'frozen_scientific_gates_stop_or_accepted',
    'full_640_context_reuse_gate_independently_recomputed',
    'full_input_snapshot_identity_bound_across_protocol_and_passes',
    'fusion_trace_full_unique_ordered_population',
    'independent_same_class_nms_strict_gt_point7_ties_maxdet_and_full_trace',
    'inference_and_task_wall_cost_within_frozen_limits',
    'input_roles_unique_and_task_identity',
    'journal_closed_call_costs_and_gpu_aggregation',
    'journal_cumulative_cost_stays_within_original_frozen_limits',
    'journal_fresh_source_and_fixed_budget_identity',
    'journal_monotonic_original_absolute_start_and_wall_cost',
    'journal_published_full_budget_and_index_match_independent_replay',
    'journal_recorded_start_before_matching_call_finish',
    'journal_terminal_status_matches_required_completion',
    'journal_unique_checkpoint_bytes_observation_and_call_bindings',
    'journal_unknown_gpu_or_open_call_forbids_completion_or_resume',
    'journal_v2_exact_sequence_and_sha256_chain',
    'monotonic_wall_segments_preserve_cumulative_cost',
    'net_gain_vs_recovered_and_lost_counts',
    'new_artifact_review_and_source_checks_within_separate_600_second_budget',
    'no_training_test_inference_threshold_search_or_weight_change',
    'normal_images_false_positive_images_boxes_and_rates',
    'original_artifact_snapshot_complete_and_current_bytes_equal',
    'original_failed_events_preserved_without_completion_claim',
    'original_failed_task_still_has_no_completion_after_review',
    'original_absolute_pipeline_deadline_not_reset',
    'original_pipeline_failure_preserved_and_completion_absent',
    'original_saved_generation_time_within_1800_before_failed_publication',
    'paired_image_395_bootstrap_and_metric_deltas',
    'paired_medium_74_image_bootstrap',
    'population',
    'positive_peak_gpu_memory_recorded',
    'published_scientific_decision_matches_nine_frozen_gates',
    'recovery_bound_original_execution_source_identity',
    'same_actual_predictor_controls_strict_nms_null',
    'same_recorded_dependency_versions_and_backend',
    'same_weight_training_and_dataset_provenance',
    'sealed_diagnosis_chooses_medium_supported_slicing',
    'sliced_independent_ap101_tp_fp_fn_normalfp_matches_saved',
    'source_artifacts_and_current_science_code_in_input_manifest',
    'source_diagnosis_evidence_bytes',
    'strict_null_nms_matches_bound_installed_backend_mode_switch',
    'summary_independent_metric_counts_and_branch_match',
    'upstream_geometry_completion_chain',
    'upstream_geometry_full_population_and_passed',
    'validation_disjoint_train_test_buffer',
    'wall_time_contains_entire_recorded_predict_span',
    'worker_completed_receipt_binds_all_checkpoint_sources',
    'worker_completed_receipt_binds_v2_durable_journal',
    'worker_request_has_only_exact_val_source_and_frozen_controls',
})

def review_recovery(configuration, recovery_id, origin_id=ORIGIN_ID, recovery_directory=None, *, prepublication=True):
    """A separate artifact review; original publication and wall acceptance failed."""
    task_id = origin_id
    import cv2
    import numpy as np
    import yaml
    review_started_at = datetime.now(timezone.utc).isoformat()
    review_clock = time.perf_counter()
    progress = ReviewProgress(recovery_id)
    progress.begin("source_integrity_before")
    before = FreshHashBoundary()
    digest, scoped_file, publication = before.digest, before.scoped_file, before.publication
    if not isinstance(task_id, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,127}", task_id):
        raise ValueError("Unsafe single-directory task ID")
    paths = {key: Path(value).resolve() for key, value in configuration.items()}
    require(re.fullmatch(r"[0-9a-f]{32}", recovery_id) is not None and recovery_id != origin_id,
            "Recovery ID must be a distinct opaque task identity")
    directory = (paths["output_root"] / origin_id).resolve()
    recovery_directory = Path(recovery_directory or paths["output_root"] / recovery_id).resolve()
    require(recovery_directory.parent == paths["output_root"] and recovery_directory.name == recovery_id,
            "Recovery directory must be the exact configured new task child")
    recovery_protocol = read(recovery_directory / "recovery_protocol.json")
    recovery_sources = read(recovery_directory / "recovery_source_manifest.json")
    digest(recovery_directory / "recovery_protocol.json")
    recovery_protocol_check(recovery_protocol, recovery_id, origin_id, recovery_directory, directory, boundary=before)
    source_manifest_check(directory, recovery_sources, origin_id, boundary=before)
    marker_name = "failure.json"
    baseline_directory = paths["output_root"] / BASELINE_TASK
    diagnosis_directory = paths["output_root"] / DIAGNOSIS_TASK
    if any(path.parent != paths["output_root"] for path in (directory, baseline_directory, diagnosis_directory)):
        raise ValueError("Task evidence directories must be direct configured output children")
    result, protocol, inputs, environment, budget = (read(directory / name) for name in
        ("failure.json", "protocol.json", "inputs.json", "environment.json", "budget.json"))
    source_result = read(baseline_directory / "comparison_result.json")
    source_environment = source_result["summary"]["environments"]["640"]
    checks = {
        "artifact_recovery_new_protocol_and_separate_600_second_budget": True,
        "frozen_primary_independent_scientific_verifier_exact_hash": digest(PRIMARY_PATH) == PRIMARY_SHA256,
        "artifact_recovery_protocol_requires_zero_new_detector_and_gpu_calls": True,
        "original_artifact_snapshot_complete_and_current_bytes_equal": True,
        "original_pipeline_failure_preserved_and_completion_absent":
            result.get("task_id") == origin_id and result.get("status") == "failed"
            and result.get("tool") == "compare_validation_slices"
            and len(result.get("errors", [])) == 1
            and result["errors"][0].get("stage") == "artifact_semantic_validation"
            and result["errors"][0].get("type") == "ValueError"
            and result["errors"][0].get("message") == "Sealed environment changed the fixed FP32 inference controls"
            and not (directory / "completion.json").exists(),
        "baseline_publication_chain_valid": publication(baseline_directory, BASELINE_TASK, "compare_validation_resolutions", BASELINE_FILES),
        "diagnosis_publication_chain_valid": publication(diagnosis_directory, DIAGNOSIS_TASK, "diagnose_validation_errors", DIAGNOSIS_FILES),
        "fixed_protocol_matches_current_frozen_fixture": contains(protocol, read(ROOT / "fixtures" / "sliced_protocol.json"), 0),
        "frozen_baseline_prediction_bytes": digest(baseline_directory / "predictions_640.jsonl") == PREDICTIONS_SHA,
        "source_diagnosis_evidence_bytes": all(digest(diagnosis_directory / name) == value for name, value in SOURCE_SHA.items())}
    expected_protocol = {"schema_version": 1, "protocol_id": "val-hybrid640-nine-pass-v1", "source_task_id": BASELINE_TASK,
        "diagnosis_task_id": DIAGNOSIS_TASK, "evidence_id": f"diagnosis:{DIAGNOSIS_TASK}:640", "split": "val",
        "train_imgsz": 640, "eval_imgsz": 640, "device": "0", "precision": "FP32", "batch": 1,
        "prediction_confidence": .001, "nms_iou": .7, "max_det": 300, "rect": False, "augment": False,
        "agnostic_nms": False, "allow_tf32": False, "quantize": None, "global_nms_iou": .7, "global_max_det": 300,
        "class_names": {str(i): name for i, name in enumerate(CLASSES)},
        "population": {"images": 640, "gt": 596, "normal_images": 245, "medium_gt": 77, "medium_images": 74, "width": 1920, "height": 1080},
        "operating_point": {"confidence": .25, "match_iou": .5},
        "acceptance": {"min_tp_gain": 5, "min_gain_images": 5, "min_medium_tp_gain": 5, "min_medium_gain_images": 5,
            "max_normal_fp_images": 5, "max_normal_fp_rate": 5 / 245, "max_fp": 149,
            "min_ap50": .41068842396135186, "min_ap50_95": .16529868184635887},
        "budgets": {"successful_observations": 5760, "max_formal_calls": 5770, "max_failed_pass_retries": 10,
            "max_warmup_calls": 1, "max_gpu_seconds": 900, "max_inference_wall_seconds": 900, "max_task_wall_seconds": 1800},
        "reference_tolerance": {"confidence_abs": 1e-6, "coordinate_abs": 1e-4, "metric_abs": 1e-9, "rtol": 0},
        "tile_grid": {"x": [0, 512, 1024, 1280], "y": [0, 440], "size": 640},
        "training_performed": False, "test_inference_performed": False, "weight_change": False,
        "automatically_apply_threshold": False, "fallback": "fail_without_changing_protocol",
        "selection_data": "validation_only", "weight_sha256": WEIGHT_SHA}
    checks["fixed_numeric_controls_budget_and_selection_rules"] = contains(protocol, expected_protocol, 0)
    decision_source = read(diagnosis_directory / "decision.json")
    checks["sealed_diagnosis_chooses_medium_supported_slicing"] = (
        decision_source.get("source_task_id") == BASELINE_TASK and decision_source.get("predictions_sha256") == PREDICTIONS_SHA
        and decision_source.get("evidence_id") == f"diagnosis:{DIAGNOSIS_TASK}:640"
        and decision_source.get("selection", {}).get("status") == "stop"
        and decision_source.get("recommendations", {}).get("next_branch") == "sliced_inference_controlled"
        and any(row.get("size_bucket") == "medium" and row.get("gt") == 77 and row.get("candidate_fn") == 52
            and row.get("affected_images") == 51 and row.get("supported") is True
            for row in decision_source["recommendations"]["slicing"]["size_support"]))
    review_source = read(paths["output_root"] / "diagnosis-local-verification.json")
    checks["diagnosis_independent_review_source_bound_passed"] = (
        digest(paths["output_root"] / "diagnosis-local-verification.json") == "8bdbe3a6f7968868c8cfc775f5429bab5004a16176d59c21d2ab1b4a004d6f4c"
        and review_source.get("status") == "passed" and review_source.get("passed_checks") == review_source.get("total_checks") == 61)
    gate = baseline_directory / "geometry_gate" / "gate"
    checks["upstream_geometry_completion_chain"] = publication(gate, "gate", "verify_label_geometry",
        {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"})
    geo = read(gate / "verification_result.json")
    geo_rows = lines(gate / "geometry_details.jsonl")
    checks["upstream_geometry_full_population_and_passed"] = (
        geo.get("status") == "completed" and geo.get("summary", {}).get("verification_status") == "passed"
        and sum(row.get("record_type") == "image" for row in geo_rows) == 4479
        and sum(row.get("record_type") == "annotation" for row in geo_rows) == 3864
        and all(row.get("differences") == [] for row in geo_rows))
    summary = result.get("summary", {})
    checks["configuration_matches_bound_baseline_and_current"] = (
        {k: str(v) for k, v in paths.items()} == {k: str(Path(v).resolve()) for k, v in source_result["configuration"].items()}
        and result.get("configuration") == source_result.get("configuration"))
    source_inputs = read(baseline_directory / "inputs.json")["files"]
    allowed = [ROOT, paths["output_root"], paths["dataset_root"], paths["raw_root"], paths["research_root"], paths["split_dir"],
               Path(source_environment["python_executable"]).parent]
    rows = inputs.get("files", [])
    roles = {row["role"]: row for row in rows}
    checks["input_roles_unique_and_task_identity"] = len(roles) == len(rows) and inputs.get("task_id") == task_id
    mismatches, current_paths = [], set()
    for row in rows:
        path = scoped_file(row["path"], allowed)
        current_paths.add(path)
        actual = digest(path)
        if not (actual == row.get("sha256_before") == row.get("sha256_after") and row.get("unchanged") is True
                and before.size(path) == row.get("size_bytes")):
            mismatches.append(row["role"])
    checks["all_current_input_bytes_equal_before_and_after"] = not mismatches and inputs.get("all_unchanged") is True
    parent_mismatch = []
    for row in source_inputs:
        path = scoped_file(row["path"], allowed)
        if (digest(path) != row.get("sha256_before") or row.get("sha256_before") != row.get("sha256_after")
                or row.get("unchanged") is not True or before.size(path) != row.get("size_bytes") or path not in current_paths):
            parent_mismatch.append(row["role"])
    checks["all_10256_upstream_inputs_still_valid_and_inherited"] = len(source_inputs) == 10256 and not parent_mismatch
    checks["source_artifacts_and_current_science_code_in_input_manifest"] = (
        {baseline_directory / name for name in BASELINE_FILES | {"completion.json", "artifact_manifest.json"}} <= current_paths
        and {diagnosis_directory / name for name in SOURCE_SHA} <= current_paths
        and {ROOT / "fixtures" / "sliced_protocol.json", ROOT / "defect_researcher" / "sliced_inference.py",
             ROOT / "defect_researcher" / "sliced_task.py", ROOT / "defect_researcher" / "sliced_worker.py",
             ROOT / "defect_researcher" / "sliced_journal.py", ROOT / "tools" / "verify_sliced_journal.py"} <= current_paths)
    # Derive the complete runner input contract without importing its resolver.
    # Source roles retain their original list indices, preventing a resealed
    # subset/renamed duplicate from erasing required provenance.
    expected_roles = {f"source_input/{i}/{r['role']}": before.resolve(r["path"]) for i, r in enumerate(source_inputs)}
    expected_roles.update({f"source_artifact/{name}": baseline_directory / name
        for name in BASELINE_FILES | {"completion.json", "artifact_manifest.json"}})
    expected_roles.update({"diagnostic_protocol": ROOT / "fixtures" / "diagnosis_protocol.json",
        "diagnostic_runner": ROOT / "defect_researcher" / "diagnosis_task.py",
        "diagnostic_core": ROOT / "defect_researcher" / "detection_diagnosis.py"})
    expected_roles.update({f"diagnosis_artifact/{name}": diagnosis_directory / name
        for name in DIAGNOSIS_FILES | {"completion.json", "artifact_manifest.json"}})
    expected_roles["preregistered/diagnosis_review"] = paths["output_root"] / "diagnosis-local-verification.json"
    for role in protocol["source_evidence_sha256"]:
        if role.startswith("diagnosis/"):
            expected_roles[f"preregistered/{role}"] = diagnosis_directory / role.split("/", 1)[1]
        elif role.startswith("comparison/"):
            expected_roles[f"preregistered/{role}"] = baseline_directory / role.split("/", 1)[1]
    expected_roles.update({"sliced_protocol": ROOT / "fixtures" / "sliced_protocol.json",
        "sliced_runner": ROOT / "defect_researcher" / "sliced_task.py",
        "sliced_worker": ROOT / "defect_researcher" / "sliced_worker.py",
        "sliced_journal": ROOT / "defect_researcher" / "sliced_journal.py",
        "sliced_journal_independent_verifier": ROOT / "tools" / "verify_sliced_journal.py",
        "sliced_core": ROOT / "defect_researcher" / "sliced_inference.py",
        "stratified_statistics": ROOT / "defect_researcher" / "stratified_statistics.py"})
    expected_roles["sliced_independent_verifier"] = PRIMARY_PATH
    import importlib.util
    for package, relative in (("ultralytics", ("engine/model.py", "engine/predictor.py", "models/yolo/detect/predict.py",
        "utils/ops.py", "utils/nms.py", "data/loaders.py")), ("cv2", ("__init__.py",))):
        spec = importlib.util.find_spec(package)
        root = Path(spec.origin).resolve().parent
        for name in relative:
            expected_roles[f"dependency/{package}/{name}"] = root / name
        if package == "cv2":
            binaries = sorted(root.glob("*.pyd"))
            if not binaries:
                raise ValueError("Bound OpenCV Windows codec is missing")
            for binary in binaries:
                expected_roles[f"dependency/cv2/{binary.name}"] = binary
    checks["all_input_roles_paths_and_dependency_binary_contract_exact"] = (
        roles.keys() == expected_roles.keys()
        and all(before.resolve(roles[role]["path"]) == before.resolve(path) for role, path in expected_roles.items()))
    training = read(paths["weights_path"].parent.parent / "experiment_manifest.json")
    dataset = read(paths["dataset_root"] / "manifest.json")
    checks["same_weight_training_and_dataset_provenance"] = (digest(paths["weights_path"]) == WEIGHT_SHA
        and training.get("status") == "completed" and training.get("best_weights_sha256") == WEIGHT_SHA
        and training["training_args"]["imgsz"] == training["actual_training_args"]["imgsz"] == 640
        and training.get("dataset_manifest_sha256") == digest(paths["dataset_root"] / "manifest.json")
        and training.get("data_yaml_sha256") == digest(paths["dataset_root"] / "data.yaml")
        and training.get("dataset_manifest") == dataset)
    data = yaml.safe_load((paths["dataset_root"] / "data.yaml").read_text(encoding="utf-8-sig"))
    checks["dataset_seven_classes_and_val_root"] = (data.get("names") == dict(enumerate(CLASSES))
        and Path(data.get("path", "")).resolve() == paths["dataset_root"] and data.get("val") == "images/val")
    raw_members = [before.resolve(text.strip()) for text in (paths["split_dir"] / "val.txt").read_text(encoding="utf-8-sig").splitlines() if text.strip()]
    member_ids = sorted(path.stem for path in raw_members)
    old_protocol = read(baseline_directory / "protocol.json")
    checks["all_640_unique_val_members_same_frozen_order"] = (len(raw_members) == len(set(raw_members)) == len(set(member_ids)) == 640
        and member_ids == old_protocol.get("image_ids") == protocol.get("image_ids"))
    checks["validation_disjoint_train_test_buffer"] = all(not set(raw_members) & {
        before.resolve(text.strip()) for text in (paths["split_dir"] / f"{split}.txt").read_text(encoding="utf-8-sig").splitlines() if text.strip()}
        for split in ("train", "test", "excluded_buffer"))
    checks["all_split_byte_hashes_remain_dataset_bound"] = all(digest(paths["split_dir"] / name) == sha for name, sha in dataset["split_sha256"].items())
    progress.end(input_roles=len(rows), parent_input_roles=len(source_inputs), **before.measurements())
    progress.begin("read_saved_predictions_and_observations")
    baseline = lines(baseline_directory / "predictions_640.jsonl")
    sliced = lines(directory / "predictions_sliced.jsonl")
    observations = lines(directory / "pass_observations.jsonl")
    checks["baseline_and_candidate_exact_validation_order"] = [r["image_id"] for r in baseline] == [r["image_id"] for r in sliced] == member_ids
    keys = [(row["image_id"], row["pass_id"]) for row in observations]
    checks["all_5760_unique_observations_same_order"] = len(keys) == len(set(keys)) == 5760 and keys == [(image, pi) for image in member_ids for pi in range(9)]
    groups = {image: [] for image in member_ids}
    for row in observations:
        groups[row["image_id"]].append(row)
    progress.end(images=len(member_ids), observations=len(observations))
    progress.begin("decoded_images_and_all_tile_pixels")
    expected, image_sha, source_coverage, pixel_valid, coordinate_valid = {}, {}, True, True, True
    for raw in sorted(raw_members, key=lambda p: p.stem):
        raw = scoped_file(raw, [paths["raw_root"]])
        image = scoped_file(paths["dataset_root"] / "images" / "val" / raw.name, [paths["dataset_root"]])
        label = scoped_file(paths["dataset_root"] / "labels" / "val" / f"{raw.stem}.txt", [paths["dataset_root"]])
        metadata = scoped_file(paths["dataset_root"] / "metadata" / "val" / f"{raw.stem}.json", [paths["dataset_root"]])
        image_sha[raw.stem] = digest(image)
        image_array = cv2.imread(str(image), cv2.IMREAD_COLOR)
        if image_array is None or image_array.dtype != np.uint8 or list(image_array.shape) != [1080, 1920, 3]:
            raise ValueError("Decoded image differs from frozen 1920x1080 BGR population")
        decoded_sha = hashlib.sha256(np.ascontiguousarray(image_array).tobytes()).hexdigest()
        meta = read(metadata)
        source_coverage &= ({raw, image, label, metadata} <= current_paths and digest(raw) == image_sha[raw.stem]
            and meta.get("width") == 1920 and meta.get("height") == 1080 and meta.get("image") == raw.relative_to(paths["raw_root"]).as_posix())
        expected[raw.stem] = {"image_id": raw.stem, "width": 1920, "height": 1080, "split": "val", "image_path": str(image),
            "source_path": str(raw), "label_path": str(label), "metadata_path": str(metadata), "ground_truth": source_gt(label, 1920, 1080)}
        for observation in groups[raw.stem]:
            pi = observation["pass_id"]
            crop = expected_crops()[pi]
            x, y, r, b = crop
            tile_sha = hashlib.sha256(np.ascontiguousarray(image_array[y:b, x:r]).tobytes()).hexdigest()
            pixel_valid &= (same(observation.get("crop"), crop, 0) and all(type(v) is int for v in observation.get("crop", []))
                and observation.get("source_image_sha256") == image_sha[raw.stem]
                and observation.get("decoded_image_sha256") == decoded_sha and observation.get("input_pixels_sha256") == tile_sha
                and observation.get("orig_shape") == [b - y, r - x])
            local = observation.get("local_predictions", [])
            coordinate_valid &= len(local) <= 300 and same(observation.get("global_predictions"), map_predictions(local, crop, pi), 0)
        if len(expected) % 80 == 0:
            progress.emit("running", images_checked=len(expected), observations_checked=len(expected) * 9)
    checks["current_image_bytes_pixels_and_label_metadata_input_coverage"] = source_coverage
    checks["frozen_crops_and_every_decoded_tile_pixel_hash"] = pixel_valid
    checks["complete_post_nms_lists_and_local_to_global_coordinates"] = coordinate_valid
    checks["both_arms_original_label_gt_exact"] = all(contains(row, expected[row["image_id"]], 0) for row in baseline + sliced)
    checks["baseline_596_gt_245_normal_77_medium_74_medium_images"] = (
        sum(len(r["ground_truth"]) for r in expected.values()) == 596
        and sum(not r["ground_truth"] for r in expected.values()) == 245
        and sum(bucket(g["xyxy"]) == "medium" for r in expected.values() for g in r["ground_truth"]) == 77
        and sum(any(bucket(g["xyxy"]) == "medium" for g in r["ground_truth"]) for r in expected.values()) == 74)
    progress.end(images_checked=len(expected), observations_checked=len(observations))
    progress.begin("execution_controls_and_source_identity")
    checks["same_recorded_dependency_versions_and_backend"] = all(environment.get(key) == source_environment.get(key)
        for key in ("python", "python_executable", "torch", "ultralytics", "cuda", "cudnn", "gpu_name", "gpu_total_bytes"))
    checks["actual_fp32_tensor_model_cuda_and_tf32_disabled"] = contains(environment, {
        "device": "0", "precision": "FP32", "actual_input_dtype": "torch.float32", "actual_input_device": "cuda:0",
        "model_parameters_dtype": "torch.float32", "tf32_matmul": False, "tf32_cudnn": False,
        "cudnn_benchmark": False, "cudnn_deterministic": True, "actual_predictor_fp16": False,
        "actual_predictor_imgsz": [640, 640], "actual_predictor_device": "cuda:0"}, 0)
    checks["same_actual_predictor_controls_strict_nms_null"] = strict_external_nms(
        environment.get("actual_predictor_options"), source_environment.get("actual_predictor_options"))
    mode_switch = Path(roles["dependency/ultralytics/engine/predictor.py"]["path"])
    checks["strict_null_nms_matches_bound_installed_backend_mode_switch"] = (
        "end2end=self.args.nms is False" in mode_switch.read_text(encoding="utf-8-sig"))
    checks["every_observation_actual_controls_fp32_and_positive_timing"] = all(
        contains(r.get("effective_options", {}), CONTROLS, 0) and same(r["effective_options"], environment["actual_predictor_options"], 0)
        and r.get("device") == "cuda:0" and r.get("precision") == "FP32" and r.get("model_parameters_dtype") == "torch.float32"
        and r.get("actual_input_dtype") == "torch.float32" and r.get("actual_input_device") == "cuda:0"
        and finite(r.get("elapsed_seconds"), True) and finite(r.get("gpu_seconds"), True)
        and set(r.get("ultralytics_speed_ms", {})) == {"preprocess", "inference", "postprocess"}
        and all(finite(v) for v in r["ultralytics_speed_ms"].values()) for r in observations)
    source_names = {"YOLO.predict", "BasePredictor.pre_transform", "BasePredictor.preprocess", "BasePredictor.setup_source",
                    "BasePredictor.inference", "DetectionPredictor.postprocess", "scale_boxes", "NMS"}
    callable_sources = environment.get("callable_sources", {})
    checks["current_dependency_sources_hash_bound_and_current_codec"] = (set(callable_sources) == source_names
        and environment.get("cv2") == cv2.__version__ and environment.get("legacy_dependency_source_hashes_available") is False
        and all(before.size(path := scoped_file(row["path"], allowed)) == row.get("size_bytes")
            and digest(path) == row.get("sha256") and path in current_paths for row in callable_sources.values()))
    checks["context_path_tile_bgr_no_alternative_predict_entry"] = contains(environment, {
        "prediction_entry": "YOLO.predict", "context_source_type": "original_path",
        "tile_source_type": "cv2_decoded_BGR_contiguous_ndarray"}, 0)
    checks["all_observations_bound_protocol_and_weight"] = all(r.get("protocol_sha256") == digest(ROOT / "fixtures" / "sliced_protocol.json")
        and r.get("weight_sha256") == WEIGHT_SHA for r in observations)
    scientific_identity = canonical_sha({r["role"]: {"path": r["path"], "sha256": r["sha256_before"], "size_bytes": r["size_bytes"]} for r in rows})
    execution_roles = {"sliced_runner", "sliced_worker", "sliced_core", "stratified_statistics",
        "sliced_independent_verifier", "sliced_journal", "sliced_journal_independent_verifier"}
    execution_sha = canonical_sha({r["role"]: {"path": r["path"], "sha256": r["sha256_before"], "size_bytes": r["size_bytes"]}
                                  for r in rows if r["role"] in execution_roles})
    evidence = {"source_task_id": BASELINE_TASK, "diagnosis_task_id": DIAGNOSIS_TASK,
        "source_completion_sha256": digest(baseline_directory / "completion.json"),
        "source_manifest_sha256": digest(baseline_directory / "artifact_manifest.json"),
        "source_predictions_sha256": PREDICTIONS_SHA, "diagnosis_completion_sha256": digest(diagnosis_directory / "completion.json"),
        "protocol_sha256": digest(ROOT / "fixtures" / "sliced_protocol.json"), "evidence_id": f"sliced:{task_id}:hybrid640"}
    identity_binding_subchecks = {
        "protocol_scientific_inputs_identity_exact": protocol.get("scientific_inputs_sha256") == scientific_identity,
        "all_observation_scientific_inputs_identities_exact": all(
            r.get("scientific_inputs_sha256") == scientific_identity for r in observations),
        "failure_nested_parent_evidence_bound": contains(result.get("evidence", {}), evidence, 0),
        "input_manifest_parent_evidence_bound": contains(inputs, evidence, 0),
        "protocol_parent_and_task_evidence_bound": contains(protocol,
            {**{k: v for k, v in evidence.items() if k != "evidence_id"},
             "task_evidence_id": evidence["evidence_id"], "task_id": task_id}, 0),
    }
    # The original failed result was never a completion candidate. Preserve all
    # five source bindings above, and validate its own stricter nested schema
    # rather than expecting the unpublished candidate's flattened fields.
    expected_failure_evidence = {**evidence, "execution_source_sha256": execution_sha,
        "independent_verification_path": str(paths["output_root"] / "sliced-prepublication" / f"{task_id}.json")}
    identity_binding_subchecks.update({
        "input_manifest_all_parent_and_execution_evidence_bound": contains(inputs, expected_failure_evidence, 0),
        "protocol_all_parent_and_execution_evidence_bound": contains(protocol,
            {**{k: v for k, v in expected_failure_evidence.items() if k != "evidence_id"},
             "task_evidence_id": evidence["evidence_id"], "task_id": task_id}, 0)
            and type(protocol.get("execution_io_version")) is int and protocol["execution_io_version"] == 2,
    })
    identity_binding_subchecks.update(failed_artifact_schema_subchecks(
        result, expected_failure_evidence, task_id, directory))
    checks["full_input_snapshot_identity_bound_across_protocol_and_passes"] = all(identity_binding_subchecks.values())
    request = read(directory / "worker_request.json")
    checks["worker_request_has_only_exact_val_source_and_frozen_controls"] = (
        Path(request.get("directory", "")).resolve() == directory and same(request.get("protocol"), read(ROOT / "fixtures" / "sliced_protocol.json"), 0)
        and same(request.get("records"), baseline, 0) and Path(request.get("weights_path", "")).resolve() == paths["weights_path"]
        and request.get("protocol_sha256") == evidence["protocol_sha256"] and request.get("scientific_inputs_sha256") == scientific_identity
        and request.get("execution_source_sha256") == execution_sha
        and type(request.get("execution_io_version")) is int and request["execution_io_version"] == 2
        and same(request.get("reference_environment"), source_environment, 0)
        and request.get("image_sha256") == image_sha)
    environment_identity = canonical_sha({k: v for k, v in environment.items() if k != "peak_allocated_bytes"})
    checks["all_observations_same_environment_identity"] = all(r.get("environment_identity") == environment_identity for r in observations)
    progress.end()
    progress.begin("independent_global_nms_and_full_trace")
    trace_rows = lines(directory / "fusion_details.jsonl")
    checks["fusion_trace_full_unique_ordered_population"] = [r["image_id"] for r in trace_rows] == member_ids
    by_id = {r["image_id"]: r for r in sliced}
    fusion_valid = True
    fusion_stats = {"candidate_count": 0, "same_class_pairs": 0, "scalar_iou_calls": 0}
    for trace_index, trace in enumerate(trace_rows, 1):
        image_stats = {}
        predictions, expected_fusion = expected_trace(groups[trace["image_id"]], stats=image_stats)
        for key in fusion_stats:
            fusion_stats[key] += image_stats[key]
        fusion_valid &= contains(trace.get("trace", {}), expected_fusion, 1e-12) and same(by_id[trace["image_id"]]["predictions"], predictions, 0)
        fusion_valid &= trace.get("candidate_count") == len(expected_fusion["rows"]) and trace.get("final_count") == len(predictions)
        if trace_index % 80 == 0:
            progress.emit("running", images_checked=trace_index, **fusion_stats)
    checks["independent_same_class_nms_strict_gt_point7_ties_maxdet_and_full_trace"] = fusion_valid
    progress.end(images_checked=len(trace_rows), **fusion_stats)
    progress.begin("independent_comparison_and_three_arm_metrics")
    context = [{**row, "predictions": groups[row["image_id"]][0]["local_predictions"]} for row in baseline]
    counts_equal = True
    confidence_difference = coordinate_difference = 0.
    for a, b in zip(baseline, context):
        counts_equal &= len(a["predictions"]) == len(b["predictions"])
        for p, q in zip(a["predictions"], b["predictions"]):
            counts_equal &= p["class_id"] == q["class_id"]
            confidence_difference = max(confidence_difference, abs(p["confidence"] - q["confidence"]))
            coordinate_difference = max(coordinate_difference, *(abs(x - y) for x, y in zip(p["xyxy"], q["xyxy"])))
    # The unchanged comparison oracle already computes both paired-arm metrics.
    # Reuse those exact objects; only the independent fresh context needs a
    # third metric calculation. No primary scientific function is patched.
    analysis = comparison(baseline, sliced, protocol)
    baseline_score, sliced_score = analysis["baseline_metrics"], analysis["sliced_metrics"]
    context_score = metrics(context)
    metric_difference = {key: abs(context_score[key] - baseline_score[key]) for key in ("mAP50", "mAP50_95")}
    reuse = read(directory / "context_reuse.json")
    checks["full_640_context_reuse_gate_independently_recomputed"] = (counts_equal and confidence_difference <= 1e-6
        and coordinate_difference <= 1e-4 and max(metric_difference.values()) <= 1e-9
        and same(context_score["operating_point"], baseline_score["operating_point"], 0))
    checks["context_reuse_declared_gate_matches_derived_evidence"] = contains(reuse, {"status": "passed",
        "maximum_confidence_abs_difference": confidence_difference, "maximum_coordinate_abs_difference": coordinate_difference,
        "metric_abs_difference": max(metric_difference.values()), "samples_matched": 640, "count_order_class_equal": True,
        "operating_counts_equal": True, "rtol": 0, "source_predictions_sha256": PREDICTIONS_SHA}, 1e-12)
    checks["baseline_independent_ap101_matches_old_and_new_saved"] = (
        contains(read(baseline_directory / "metrics_640.json"), baseline_score) and contains(read(directory / "metrics_baseline.json"), baseline_score))
    checks["sliced_independent_ap101_tp_fp_fn_normalfp_matches_saved"] = contains(read(directory / "metrics_sliced.json"), sliced_score)
    saved_analysis = read(directory / "sliced_comparison.json")
    for label, key in (("population", "population"), ("correct_gt_recall_and_prediction_precision_strata", "stratified_statistics"),
                       ("all_21_class_size_cells_including_null_and_support", "class_size"),
                       ("all_seven_classes_original_gt_recall_and_transitions", "per_class_gt"),
                       ("normal_images_false_positive_images_boxes_and_rates", "normal_false_positives"),
                       ("all_640_paired_image_rows_and_medium_denominators", "per_image"),
                       ("all_596_gt_recovery_and_loss_provenance", "gt_transitions"),
                       ("net_gain_vs_recovered_and_lost_counts", "gains"),
                       ("paired_image_395_bootstrap_and_metric_deltas", "paired_comparison"),
                       ("paired_medium_74_image_bootstrap", "paired_medium_recall"),
                       ("frozen_scientific_gates_stop_or_accepted", "scientific_decision")):
        checks[label] = contains(saved_analysis.get(key), analysis[key])
    diagnosis_gt = {(r["image_id"], r["gt_index"]): r for r in lines(diagnosis_directory / "gt_details.jsonl")}
    checks["each_original_gt_transition_linked_to_diagnosis"] = all(
        (r["image_id"], r["gt_index"]) in diagnosis_gt
        and same(diagnosis_gt[r["image_id"], r["gt_index"]]["xyxy"], r["xyxy"], 0)
        and diagnosis_gt[r["image_id"], r["gt_index"]]["class_id"] == r["class_id"]
        and diagnosis_gt[r["image_id"], r["gt_index"]]["status"] == r["baseline_status"]
        for r in analysis["gt_transitions"])
    final_decision = read(directory / "decision.json")
    checks["published_scientific_decision_matches_nine_frozen_gates"] = (
        contains(final_decision.get("scientific_decision", final_decision), analysis["scientific_decision"])
        and final_decision.get("parent_evidence_id") == protocol["evidence_id"]
        and final_decision.get("evidence_id") == f"sliced:{task_id}:hybrid640"
        and final_decision.get("execution_and_evidence_gates_passed") is True
        and final_decision.get("automatically_applied") is False)
    progress.end(metric_arms_recomputed=3)
    progress.begin("independent_budget_checkpoints_and_journal_replay")
    # Budget/checkpoint contracts are verified below; hardware timings remain
    # recorded evidence rather than a second independent GPU measurement.
    journal_identity = {"protocol_sha256": evidence["protocol_sha256"], "weight_sha256": WEIGHT_SHA,
        "scientific_inputs_sha256": scientific_identity, "execution_source_sha256": execution_sha,
        "journal_source_sha256": digest(ROOT / "defect_researcher" / "sliced_journal.py")}
    _budget_checks(checks, budget, observations, directory, protocol, environment, journal_identity)
    progress.end(observations=len(observations))
    progress.begin("historical_failure_and_scientific_summary")
    events = lines(directory / "events.jsonl")
    stamps = [datetime.fromisoformat(row["at"]) for row in events]
    checks["original_failed_events_preserved_without_completion_claim"] = (bool(stamps) and stamps == sorted(stamps)
        and events[-1].get("stage") == "artifact_semantic_validation" and events[-1].get("status") == "failed"
        and sum(row.get("status") == "failed" for row in events) == 1)
    checks.update(summary_checks(summary, analysis, budget, rows))
    checks["recovery_bound_original_execution_source_identity"] = (
        recovery_protocol.get("execution_source_sha256") == execution_sha
        and recovery_protocol.get("journal_source_sha256") == journal_identity["journal_source_sha256"])
    checks["original_absolute_pipeline_deadline_not_reset"] = (
        finite(recovery_protocol.get("original_pipeline_deadline_epoch"), True)
        and recovery_protocol["original_pipeline_deadline_epoch"] == budget["task_started_epoch"] + 1800)
    checks["no_training_test_inference_threshold_search_or_weight_change"] = (summary.get("training_performed") is False
        and summary.get("test_inference_performed") is False and summary.get("same_weight") is True
        and summary.get("split") == "val" and summary.get("input_hashes_unchanged") is True
        and saved_analysis["scientific_decision"].get("threshold_search_performed") is False)
    checks["summary_independent_metric_counts_and_branch_match"] = (
        contains(summary.get("metrics", {}).get("baseline"), {k: baseline_score[k] for k in ("mAP50", "mAP50_95", "operating_point")})
        and contains(summary.get("metrics", {}).get("sliced"), {k: sliced_score[k] for k in ("mAP50", "mAP50_95", "operating_point")}))
    checks["original_saved_generation_time_within_1800_before_failed_publication"] = (
        finite(summary.get("total_task_wall_seconds"), True) and budget["task_wall_seconds"] <= summary["total_task_wall_seconds"] <= 1800
        and (datetime.fromisoformat(result["finished_at"]) - datetime.fromisoformat(result["started_at"])).total_seconds() <= 1800)
    progress.end()
    progress.begin("source_integrity_after")
    # A new cache guarantees a fresh full SHA read after scientific review.
    # It deliberately shares nothing with the earlier boundary, even when file
    # sizes or mtimes are unchanged. Original artifacts, inputs and image roles
    # share only this new boundary's physically-read SHA/byte count.
    after = FreshHashBoundary()
    source_manifest_check(directory, recovery_sources, origin_id, boundary=after)
    after_mismatches = []
    for row in rows:
        path = after.scoped_file(row["path"], allowed)
        if after.digest(path) != row["sha256_before"] or after.size(path) != row["size_bytes"]:
            after_mismatches.append(row["role"])
    checks["all_current_input_bytes_equal_before_and_after"] &= not after_mismatches
    checks["current_images_unchanged_during_independent_pixel_review"] = all(
        after.digest(expected[image]["image_path"]) == sha for image, sha in image_sha.items())
    # Protocol, manifest and the new review/producer source identities also
    # remain fixed through both integrity boundaries.
    recovery_protocol_check(recovery_protocol, recovery_id, origin_id, recovery_directory, directory, boundary=after)
    require(after.digest(recovery_directory / "recovery_protocol.json") == digest(recovery_directory / "recovery_protocol.json")
        and after.digest(recovery_directory / "recovery_source_manifest.json") == digest(recovery_directory / "recovery_source_manifest.json"),
        "Recovery protocol or source snapshot changed during review")
    checks["all_original_artifact_bytes_unchanged_after_full_independent_review"] = True
    checks["original_failed_task_still_has_no_completion_after_review"] = not (directory / "completion.json").exists()
    progress.end(input_roles=len(rows), **after.measurements())
    recovery_wall = max(time.time() - recovery_protocol["recovery_started_epoch"], time.perf_counter() - review_clock)
    checks["new_artifact_review_and_source_checks_within_separate_600_second_budget"] = finite(recovery_wall, True) and recovery_wall <= 600
    review_seconds = time.perf_counter() - review_clock
    require(checks.keys() == REQUIRED_CHECKS and all(type(value) is bool for value in checks.values()),
        "Recovery independent check contract is incomplete or mistyped")
    original_elapsed_now = time.time() - budget["task_started_epoch"]
    return {"schema_version": 1, "kind": "saved_sliced_artifact_recovery_review",
        "artifact_review_implementation_version": IMPLEMENTATION_VERSION,
        "task_id": recovery_id, "source_task_id": origin_id, "computation_task_id": origin_id,
        "status": "passed" if all(checks.values()) else "failed", "prepublication": prepublication,
        "reviewed_at": datetime.now(timezone.utc).isoformat(), "review_started_at": review_started_at,
        "review_finished_at": datetime.now(timezone.utc).isoformat(), "review_seconds": review_seconds,
        "recovery_review_seconds": review_seconds, "recovery_total_wall_seconds": recovery_wall,
        "max_recovery_wall_seconds": 600, "model_used": False, "gpu_inference_performed_by_reviewer": False,
        "new_predict_calls": 0, "new_gpu_calls": 0, "new_gpu_seconds": 0,
        "original_business_status": "failed", "original_completion_absent": True,
        "original_pipeline_acceptance_passed": False, "original_budget_reset": False,
        "original_final_review_completed_within_1800_seconds": False,
        "original_absolute_elapsed_now_seconds": original_elapsed_now,
        "original_absolute_deadline_elapsed": original_elapsed_now > 1800,
        "original_prepublication_acceptance_status": "not_completed",
        "checks": checks, "passed_checks": sum(checks.values()), "total_checks": len(checks),
        "source_files_checked": len(rows), "source_mismatches": mismatches, "parent_source_mismatches": parent_mismatch,
        "after_source_mismatches": after_mismatches,
        "source_failure_sha256": after.digest(directory / "failure.json"),
        "source_manifest_sha256": after.digest(recovery_directory / "recovery_source_manifest.json"),
        "task_protocol_sha256": after.digest(recovery_directory / "recovery_protocol.json"),
        "source_protocol_sha256": after.digest(directory / "protocol.json"),
        "execution_source_sha256": execution_sha, "primary_scientific_verifier_sha256": PRIMARY_SHA256,
        "independent_reviewer_sha256": after.digest(Path(__file__)),
        "stage_timings_seconds": progress.timings,
        "source_hash_boundaries": {"before": before.measurements(), "after": after.measurements()},
        "fusion_recomputation": fusion_stats,
        "identity_binding_subchecks": identity_binding_subchecks,
        "verified_source_summary": summary, "verified_source_summary_sha256": canonical_sha(summary),
        "scientific_status": analysis["scientific_decision"]["status"],
        "failed_scientific_gates": analysis["scientific_decision"]["failed_gates"],
        "population": analysis["population"],
        "baseline": {k: baseline_score[k] for k in ("mAP50", "mAP50_95", "operating_point")},
        "sliced": {k: sliced_score[k] for k in ("mAP50", "mAP50_95", "operating_point")}, "gains": analysis["gains"],
        "not_applicable_original_checks": [
            "The failed source task has no scientific completion publication chain; this review never constructs one.",
            "The source task did not finish independent acceptance within its original 1800-second pipeline deadline.",
            "The new 600-second artifact-only review does not reset, replace or satisfy that historical deadline."],
        "limitations": [
            "Scientific calculations use byte-bound independent AP101, matching, fusion and statistics implementations.",
            "No detector, training, test inference, threshold search or model request occurs in this recovery.",
            "Recorded GPU times and settings are verified, not remeasured; original post-NMS candidates are retained.",
            "nms must be exactly null in baseline and candidate; False selects a different installed backend mode.",
            "Validation-only results and correlated-image bootstrap do not establish deployment or held-out gain."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("task_id")
    parser.add_argument("--origin-id", default=ORIGIN_ID)
    parser.add_argument("--recovery-directory", type=Path)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    configuration = read(args.config)
    output = args.output.resolve()
    original = (Path(configuration["output_root"]) / args.origin_id).resolve()
    require(output.is_relative_to(Path(configuration["output_root"]).resolve()),
        "Recovery report must be saved under the configured output root")
    require(not output.is_relative_to(original), "Recovery verifier must never write into the original task")
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.exists(), "Preserve any existing independent recovery report")
    try:
        result = review_recovery(configuration, args.task_id, args.origin_id, args.recovery_directory)
    except Exception as error:
        result = {"schema_version": 1, "kind": "saved_sliced_artifact_recovery_review",
            "task_id": args.task_id, "source_task_id": args.origin_id, "computation_task_id": args.origin_id,
            "status": "failed", "error": {"type": type(error).__name__, "message": str(error)},
            "original_business_status": "failed", "original_pipeline_acceptance_passed": False,
            "new_predict_calls": 0, "new_gpu_calls": 0, "gpu_inference_performed_by_reviewer": False}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    # Only a compact status is printed. The evidence report contains the full
    # measurements and provenance; no detector is called by this CLI.
    print(json.dumps({"task_id": args.task_id, "status": result["status"],
        "passed_checks": result.get("passed_checks"), "total_checks": result.get("total_checks"),
        "error": result.get("error")}, ensure_ascii=False))
    raise SystemExit(0 if result["status"] == "passed" else 1)


if __name__ == "__main__":
    main()

