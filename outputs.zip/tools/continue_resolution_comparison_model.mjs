// Recover model transport only: query the previously launched task without repeating inference.
import { readFile, writeFile, copyFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, finishEventReading } from './agh_ws_client.mjs';
const output = 'outputs/agh-resolution-comparison';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
if (!launch.task_id || launch.permissions.filter(row => row.decision === 'allowed-once').length !== 1) {
  throw new Error('Expected one previously approved comparison');
}
const initial = (await readFile(output + '/session.jsonl', 'utf8')).trim().split('\n').map(JSON.parse);
let afterSeq = initial.at(-1).seq;
for (const filename of ['session.jsonl', 'session.html', 'runner.json']) {
  await copyFile(output + '/' + filename, output + '/transport-attempt-1-' + filename, 1);
}
const record = { started_at: new Date().toISOString(), session_id: launch.session_id, task_id: launch.task_id,
  existing_task_only: true, no_new_inference_task: true, permissions: [], calls: [], results: [], turns: [], status: 'starting' };
const path = output + '/continuation.json';
await writeFile(path, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(path, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let iterator, reading;
try {
  const session = await client.session.load(launch.session_id, { cwd: process.cwd(), onPermissionRequest: async request => {
    record.permissions.push({ decision: 'rejected', tool: request.toolCall?._meta?.['ai.agnes.harness']?.tool });
    await save();
    return { verdict: 'rejected' };
  } });
  record.status = 'running';
  for (let turn = 0; turn < 3; turn++) {
    iterator = session.events()[Symbol.asyncIterator]();
    reading = (async () => {
      for (;;) {
        const next = await iterator.next();
        if (next.done) break;
        const event = next.value;
        if (event.seq <= afterSeq) continue;
        if (event.type === 'tool/call') {
          record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
          await save();
          console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
        }
        if (event.type === 'tool/result') {
          const payload = event.data.content?.find(item => item.type === 'text')?.text;
          let result;
          try { result = JSON.parse(payload); } catch { /* official export retains the payload */ }
          if (result?.task_id) {
            if (result.task_id !== launch.task_id) throw new Error('Read another task');
            record.results.push({ seq: event.seq, task_id: result.task_id, status: result.status, summary: result.summary });
            await save();
            console.log(JSON.stringify({ task_id: result.task_id, status: result.status }));
          }
        }
        if (event.type === 'turn/end') break;
      }
    })();
    record.prompt = `继续既有对照任务 ${launch.task_id}，此前模型通信中断但工具后台仍运行。只用 get_task_status 查询此编号直到终态，不再启动 compare_validation_resolutions、不调用其他工具。完成后中文分析真实640/960结果，明确验证集/单权重与CI限制，并引用证据路径。最终追加唯一JSON代码块{status,task_id,summary}，summary精确复制终态的 comparison_status,split,val_images,val_boxes,train_imgsz,eval_imgsz,weight_sha256,same_weight,device,precision,input_hashes_unchanged,test_inference_performed,training_performed,metrics,comparison。保留原始数字，不省略、不四舍五入，不复制 environments。`;
    const result = await session.prompt(record.prompt, { titleLocale: 'zh-CN' });
    await finishEventReading(reading);
    await iterator.return?.();
    record.turns.push({ turn, result });
    afterSeq = result.lastSeq;
    await save();
    if (['completed', 'failed'].includes(record.results.at(-1)?.status)) break;
  }
  const terminal = record.results.at(-1);
  if (terminal?.status !== 'completed' || terminal.summary?.comparison_status !== 'passed') throw new Error('No verified terminal comparison');
  record.status = 'completed';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
    let reader;
    try {
      reader = await webClient();
      await exportSession({ positional: [launch.session_id], format, raw: false, out: output + '/' + filename }, {
        cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
      }, reader);
    } catch (error) {
      record.export_failure = { type: error.name, message: error.message };
      process.exitCode = 1;
    } finally { await reader?.close(); }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, task_id: record.task_id, session_id: record.session_id,
    failure: record.failure, export_failure: record.export_failure }));
}
