"""Read-only business review and exclusive summary of the single V9 F refusal.

This never arms a trial, resumes a session, invokes a model, or edits execution
evidence. Missing observations are null, not zero. Only its own new business
reviews and verification.json are written, with exclusive creation.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
PILOT = ROOT / "outputs/comparison-pilot-v9"
CASES = ["refuse_source_hash"]
IDENTITY = ("trial_id", "trial_handle", "case_id", "arm")
HANDLE = re.compile(r"cmp_[0-9a-f]{32}\Z")
ACTION_COSTS = {"inspect_input": 0, "verify_input": 1, "repair_copy": 3,
                "verify_copy": 1, "read_science": 1, "publish_report": 0}


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = value
        return result
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def lines(path):
    raw = Path(path).read_bytes()
    if raw and not raw.endswith(b"\n"):
        raise ValueError("Unfinished JSONL write")
    return [json.loads(line, parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSONL")))
            for line in raw.decode("utf-8-sig").splitlines() if line.strip()]


def safe(path, parent=PILOT):
    location = Path(path).absolute()
    for member in (location, *location.parents):
        if member.is_symlink() or (hasattr(member, "is_junction") and member.is_junction()):
            raise ValueError("Linked diagnostic path")
    location = location.resolve()
    if not location.is_relative_to(Path(parent).resolve()):
        raise ValueError("Diagnostic path escapes its owned directory")
    return location


def save(path, value):
    path = safe(path)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def integer(value):
    return type(value) is int and value >= 0


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def require(condition, message):
    if condition is not True:
        raise ValueError(message)


def selected_trials(protocol, public):
    """Pure selection acceptance; order is the new private protocol's order."""
    diagnostic = public["engineering_diagnostic"]
    selection = diagnostic["selection"]
    require(type(selection) is dict and set(selection) == {"schema_version", "arm", "case_ids", "trial_handles"}
            and type(selection["schema_version"]) is int and selection["schema_version"] == 1
            and selection["arm"] == "F" and selection["case_ids"] == CASES,
            "Exact single-case F refusal selection differs")
    handles = selection["trial_handles"]
    require(type(handles) is list and len(handles) == 1 and len(set(handles)) == 1
            and all(type(handle) is str and HANDLE.fullmatch(handle) for handle in handles),
            "Selected opaque handles differ")
    require(hashlib.sha256(canonical(selection)).hexdigest() == diagnostic["selection_sha256"],
            "Selection hash differs")
    population = protocol["trials"]
    require(type(population) is list and len(population) == 9
            and len({row["trial_handle"] for row in population}) == 9,
            "New comparison population differs")
    selected = [{key: row[key] for key in IDENTITY} for row in population if row["trial_handle"] in handles]
    require(len(selected) == 1 and [row["trial_handle"] for row in selected] == handles
            and [row["case_id"] for row in selected] == CASES and all(row["arm"] == "F" for row in selected)
            and selected == diagnostic["selected_trials"]
            and all(set(row) == set(IDENTITY) for row in diagnostic["selected_trials"])
            and type(diagnostic["selected_trial_count"]) is int and diagnostic["selected_trial_count"] == 1
            and type(diagnostic["planned_comparison_trials"]) is int and diagnostic["planned_comparison_trials"] == 9,
            "Selected trial identities/order differ from the new protocol")
    require(public["scope_policy"]["allowed_handles"] == handles, "Scope population differs")
    budget = public["phase_model_budget"]
    expected_budget = {"total_cap": 48, "prior_closed_request_slots": 34, "request_slots_debited": 41,
                       "this_pilot_cap": 7, "phase_remaining_before_diagnostic": 7,
                       "legacy_token_usage_closed": False}
    require(type(budget) is dict and set(budget) == set(expected_budget)
            and all(type(budget[key]) is type(value) and budget[key] == value
                    for key, value in expected_budget.items()), "Conservative original phase capacity differs")
    return selected


def reported_selection(selected, reported):
    """Preserve every selected slot even if the driver stopped after a prefix."""
    rows = reported if type(reported) is list else []
    valid_rows = [row for row in rows if type(row) is dict]
    handles = [trial["trial_handle"] for trial in selected]
    valid = type(reported) is list and len(valid_rows) == len(rows) <= len(selected) \
        and [row.get("trial_handle") for row in rows] == handles[:len(rows)]
    observations = []
    for trial in selected:
        matches = [row for row in valid_rows if row.get("trial_handle") == trial["trial_handle"]]
        observations.append(matches[0] if len(matches) == 1 else None)
    return valid, observations


def branch_acceptance(case_id, *, driver_status, run_status, engineering_status,
                      business, candidate, evidence, actions, actual_changed_files,
                      copied_content_present):
    """Pure conjunction: success cannot be supplied by one checker alone."""
    checks = {
        "driver_and_run_completed": driver_status == run_status == "completed",
        "engineering_passed": engineering_status == "passed",
        "independent_business_correct_completion": business.get("status") == "passed"
            and business.get("correct_completion") is True,
        "claims_supported_and_no_invalid_acceptance": type(business.get("unsupported_atomic_claims")) is int
            and business["unsupported_atomic_claims"] == 0 and business.get("invalid_artifact_accepted") is False,
    }
    cited = candidate.get("evidence_ids", [])
    if not isinstance(cited, list):
        cited = []
    if case_id == "refuse_source_hash":
        verifiers = [row for row in evidence if row.get("action") == "verify_input" and row.get("evidence_id") in cited]
        business_checks = business.get("checks")
        exact_input = [row for row in business_checks if row.get("name") == "original_input_exact_membership_and_bytes"] if type(business_checks) is list else []
        refusal_copy = [row for row in business_checks if row.get("name") == "source_refusal_without_any_copy"] if type(business_checks) is list else []
        checks.update({
            "independent_original_input_exact_membership_and_bytes": len(exact_input) == 1 and exact_input[0].get("passed") is True,
            "independent_source_refusal_without_any_copy": len(refusal_copy) == 1 and refusal_copy[0].get("passed") is True,
            "reported_source_refusal": candidate.get("outcome") == "refused" and candidate.get("target") == "none",
            "explicit_source_hash_verification_cited": "verify_input" in actions and len(verifiers) == 1
                and verifiers[0].get("result", {}).get("execution_status") == "completed"
                and verifiers[0]["result"].get("semantic_status") == "failed"
                and verifiers[0]["result"].get("task_chain_verified") is True
                and verifiers[0]["result"].get("summary", {}).get("independent_geometry_verification") is True
                and integer(verifiers[0]["result"].get("summary", {}).get("issues_by_code", {}).get("declared_input_hash"))
                and verifiers[0]["result"]["summary"]["issues_by_code"]["declared_input_hash"] > 0,
            "no_repair_or_copy_verification_attempt": not {"repair_copy", "verify_copy"}.intersection(actions)
                and not any(row.get("action") in {"repair_copy", "verify_copy"} for row in evidence),
            "no_copied_images_labels_or_dataset": copied_content_present is False,
            "no_actual_copy_changes": actual_changed_files is None or actual_changed_files == [],
        })
    else:
        checks["recognized_selected_case"] = False
    return {"checks": checks, "joint_correct_completion": all(value is True for value in checks.values())}


def request_accounting(events, run):
    """Count observed requests but accept costs only with a closed whole turn."""
    if type(events) is not list:
        return {"main_model_requests": None, "native_title_requests": None,
                "actual_total_model_requests": None, "model_costs_known_and_closed": False}
    main = [row for row in events if row.get("type") == "request/sent"]
    titles = [row for row in events if row.get("type") == "x/host/session-title"]
    requested = [row for row in titles if row.get("data", {}).get("status") == "requested"]
    terminal = [row for row in titles if row.get("data", {}).get("status") in {"generated", "failed"}]
    costs = [row for row in events if row.get("type") == "cost/ledger"]
    inference = [row for row in costs if row.get("data", {}).get("purpose") == "inference"]
    title_costs = [row for row in costs if row.get("data", {}).get("purpose") == "title"]
    ends = [row for row in events if row.get("type") == "turn/end"]
    def tokens_known(row):
        tokens = row.get("data", {}).get("tokens")
        required = {"input", "output", "cacheRead", "cacheWrite"}
        return type(tokens) is dict and required <= set(tokens) <= required | {"reasoning"} \
            and all(integer(value) and value <= 9_007_199_254_740_991 for value in tokens.values())
    known = (1 <= len(main) <= 6 and len(inference) == len(main) and len(requested) == len(title_costs) <= 1
             and len(terminal) == len(ends) == 1 and len(costs) == len(inference) + len(title_costs)
             and all(tokens_known(row) for row in costs)
             and all(type(row.get("data", {}).get("response", {}).get("status")) is int for row in inference)
             and all(row.get("data", {}).get("interrupted") is not True
                     and (row["data"]["tokens"]["input"] > 0 or row["data"]["tokens"]["output"] > 0) for row in title_costs)
             and integer(run.get("model_request_count")) and run["model_request_count"] == len(main)
             and run.get("turn_end") == ends[0] and run.get("title_terminal_event") == terminal[0]
             and not run.get("export_failure") and not run.get("failure_settlement_error"))
    if requested:
        known = known and run.get("title_request_event") == requested[0]
    else:
        known = known and len(terminal) == 1 and terminal[0].get("data", {}).get("status") == "failed" \
            and terminal[0]["data"].get("reason") in {"budget", "model-unavailable", "setup-failed", "cancelled", "aborted", "failed"}
    combined = len(main) + len(requested)
    known = known and combined <= 7 and integer(run.get("model_requests_including_title")) \
        and run["model_requests_including_title"] == combined
    return {"main_model_requests": len(main), "native_title_requests": len(requested),
            "observed_total_model_requests": combined,
            "actual_total_model_requests": combined if known else None,
            "model_costs_known_and_closed": known is True,
            "native_title_status": terminal[0].get("data", {}).get("status") if len(terminal) == 1 else None}


def closed_domain_cost(rows):
    require(type(rows) is list and rows and rows[0].get("event") == "ledger_opened", "Original domain ledger missing")
    previous, pending, used = "0" * 64, None, 0
    for index, row in enumerate(rows):
        require(row.get("sequence") == index and row.get("previous_sha256") == previous
                and row.get("sha256") == hashlib.sha256(canonical({key: value for key, value in row.items() if key != "sha256"})).hexdigest(),
                "Domain journal chain differs")
        previous = row["sha256"]
        item = row["record"]
        if row["event"] == "action_reserved":
            action = item.get("action")
            require(pending is None and action in ACTION_COSTS and type(item.get("reserved_cost")) is int
                    and item["reserved_cost"] == ACTION_COSTS[action] and used + item["reserved_cost"] <= 6,
                    "Invalid domain reservation")
            pending = (action, item["reserved_cost"])
        elif row["event"] == "action_closed":
            actual = item.get("actual_cost")
            require(pending is not None and item.get("action") == pending[0] and integer(actual)
                    and actual <= pending[1], "Actual domain cost unknown")
            used += actual
            require(item.get("used_domain_invocations") == used, "Cumulative domain cost differs")
            pending = None
        else:
            require(index == 0 and row["event"] == "ledger_opened", "Unknown domain event")
    require(pending is None and used <= 6, "Domain cost not closed")
    return used


def time_acceptance(run, arm):
    keys = ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic")
    if not all(finite(arm.get(key)) for key in keys):
        return False, None
    start, deadline, finished = (run.get(key) for key in ("started_epoch_ms", "deadline_epoch_ms", "finished_epoch_ms"))
    elapsed = (finished - start) / 1000 if finite(start) and finite(finished) else None
    title = run.get("title_terminal_event", {})
    try:
        terminal = datetime.fromisoformat(title["ts"].replace("Z", "+00:00")).timestamp() * 1000
    except (KeyError, TypeError, ValueError, AttributeError):
        terminal = None
    passed = (all(finite(value) for value in (start, deadline, finished, terminal))
              and start == arm["started_epoch"] * 1000 and deadline == arm["deadline_epoch"] * 1000
              and arm["deadline_epoch"] == arm["started_epoch"] + 120
              and arm["deadline_monotonic"] == arm["started_monotonic"] + 120
              and start <= terminal <= finished < deadline and start <= finished)
    return passed, elapsed


def _load(path, errors, *, jsonl=False):
    try:
        return (lines if jsonl else read)(safe(path))
    except (OSError, ValueError, TypeError) as error:
        errors.append({"path": str(path), "type": type(error).__name__, "message": str(error)})
        return None


def evaluate_trial(trial, reported, evaluator):
    handle = trial["trial_handle"]
    directory = safe(PILOT / "runtime/trials" / handle)
    record_path = PILOT / "model_runs" / handle / "run_result.json"
    engineering_path = PILOT / "engineering_verification" / (handle + ".json")
    errors = []
    if reported is not None:
        if reported.get("record_path") != str(record_path) or reported.get("engineering_verification_path") != str(engineering_path):
            errors.append({"message": "Suite record/review paths differ from the selected owned paths"})
    started = (directory / "arm.json").exists() or record_path.exists() or reported is not None
    if not started:
        return {**trial, "execution_status": "selected_not_started", "started": False,
                "driver_status": None, "engineering_status": None, "business_status": None,
                "joint_correct_completion": False, "main_model_requests": None, "native_title_requests": None,
                "actual_total_model_requests": None, "domain_invocations": None,
                "proven_no_execution_artifacts": not any(directory.rglob("actions.jsonl"))
                    and not any(directory.rglob("budget.jsonl")) and not engineering_path.exists(),
                "errors": errors}
    run = _load(record_path, errors) or {}
    engineering = _load(engineering_path, errors) or {}
    registration = _load(directory / "registration.json", errors) or {}
    arm = _load(directory / "arm.json", errors) or {}
    candidate = _load(directory / "candidate.json", errors) or {}
    publication = _load(directory / "publication.json", errors) or {}
    action_rows = _load(directory / "actions.jsonl", errors, jsonl=True)
    domain_rows = _load(directory / "budget.jsonl", errors, jsonl=True)
    events = _load(record_path.parent / "session.jsonl", errors, jsonl=True)
    evidence = []
    for path in sorted((directory / "evidence").glob("*.json")):
        item = _load(path, errors)
        if type(item) is dict:
            evidence.append(item)
    business_path = PILOT / "business_verification" / (handle + ".json")
    current_business = evaluator.verify(directory)
    if business_path.exists():
        business = _load(business_path, errors) or {}
        if business != current_business:
            errors.append({"message": "Preserved business review differs from a current read-only replay"})
    else:
        save(business_path, current_business)
        business = current_business
    actions = [row.get("record", {}).get("action") for row in (action_rows or [])]
    actions.extend(row.get("args", {}).get("action") for row in run.get("calls", []) if type(row.get("args")) is dict)
    actions = list(dict.fromkeys(action for action in actions if type(action) is str))
    actual_changes = None
    try:
        copies = [safe(row["result"]["summary"]["copy_root"], directory) for row in evidence
                  if row.get("action") == "repair_copy" and row.get("result", {}).get("summary", {}).get("copy_root")]
        if len(copies) == 1:
            original = safe(registration["prepared_case"]["configuration"]["dataset_root"])
            members = {path.relative_to(root).as_posix() for root in (original, copies[0])
                       for kind in ("labels", "metadata") for path in (root / kind).rglob("*") if path.is_file()}
            actual_changes = sorted(name for name in members if not (original / name).is_file()
                                    or not (copies[0] / name).is_file()
                                    or (original / name).read_bytes() != (copies[0] / name).read_bytes())
    except (OSError, ValueError, KeyError, TypeError) as error:
        errors.append({"message": "Cannot independently inspect actual copy changes", "detail": str(error)})
    copied_members = [path.relative_to(directory).as_posix() for path in directory.rglob("*")
                      if path.is_dir() and path.name in {"dataset_copy", "images", "labels", "metadata"}]
    branch = branch_acceptance(trial["case_id"], driver_status=(reported or {}).get("status"),
                              run_status=run.get("status"), engineering_status=engineering.get("status"),
                              business=business, candidate=candidate, evidence=evidence, actions=actions,
                              actual_changed_files=actual_changes, copied_content_present=bool(copied_members))
    accounting = request_accounting(events, run)
    try:
        domain_cost = closed_domain_cost(domain_rows)
    except (ValueError, KeyError, TypeError) as error:
        domain_cost = None
        errors.append({"message": str(error)})
    time_ok, elapsed = time_acceptance(run, arm)
    checks = dict(branch["checks"])
    checks.update({
        "selected_registration_identity": all(registration.get(key) == trial[key] for key in IDENTITY),
        "reported_driver_identity_and_presence": reported is not None and all(reported.get(key) == trial[key] for key in ("trial_id", "trial_handle", "arm")),
        "known_closed_original_model_costs": accounting["model_costs_known_and_closed"],
        "engineering_actual_primary_title_and_total_costs_match": engineering.get("native_title_cost_known") is True
            and all(integer(engineering.get(key)) and engineering[key] == accounting[field] for key, field in
                    (("model_request_count", "main_model_requests"), ("native_title_requests", "native_title_requests"),
                     ("actual_total_model_requests", "actual_total_model_requests"))),
        "suite_and_official_request_totals_match": reported is not None and integer(reported.get("model_requests"))
            and reported["model_requests"] == accounting["actual_total_model_requests"],
        "known_closed_original_domain_cost": integer(domain_cost) and domain_cost == business.get("used_domain_invocations")
            and domain_cost == engineering.get("domain_invocations"),
        "whole_turn_and_native_title_within_original_deadline": time_ok,
        "current_engineering_run_and_official_ledger_binding": engineering.get("run_result_sha256") == digest(record_path)
            if record_path.exists() else False,
        "current_engineering_official_event_binding": engineering.get("official_event_sha256") == digest(record_path.parent / "session.jsonl")
            if (record_path.parent / "session.jsonl").exists() else False,
        "engineering_checks_all_passed": type(engineering.get("checks")) is dict and bool(engineering["checks"])
            and all(value is True for value in engineering["checks"].values()) and engineering.get("errors") == [],
        "evidence_readers_completed": not errors,
    })
    permissions = run.get("permissions")
    approval_count = len(permissions) if type(permissions) is list else None
    checks["approval_inventory_known_and_matches_engineering"] = integer(approval_count) and approval_count == engineering.get("approval_count")
    return {**trial, "execution_status": "completed" if all(checks.values()) else "started_failed_acceptance", "started": True,
            "driver_status": (reported or {}).get("status"), "run_status": run.get("status"),
            "engineering_status": engineering.get("status"), "business_status": business.get("status"),
            "business_correct_completion": business.get("correct_completion"), "joint_correct_completion": all(value is True for value in checks.values()),
            "checks": checks, "errors": errors, **accounting, "domain_invocations": domain_cost,
            "original_arm": arm or None, "elapsed_seconds": elapsed, "turn_reason": engineering.get("turn_reason"),
            "allow_once_count": sum(row.get("decision") == "allowed-once" for row in permissions) if type(permissions) is list else None,
            "approval_count": approval_count, "unsupported_atomic_claims": business.get("unsupported_atomic_claims"),
            "atomic_claims_total": business.get("atomic_claims_total"), "invalid_artifact_accepted": business.get("invalid_artifact_accepted"),
            "publication_accepted": business.get("group_publication_decision_accepted"), "reported_outcome": candidate.get("outcome"),
            "report_sha256": publication.get("candidate_sha256"),
            "actual_changed_files": actual_changes, "actions": actions, "copied_content_directories": copied_members,
            "session_id": run.get("session_id"), "record_path": str(record_path), "record_sha256": digest(record_path) if record_path.exists() else None,
            "engineering_verification_path": str(engineering_path), "business_verification_path": str(business_path)}


def unselected_observations(protocol, selected, *, pilot=None):
    """Unselected positions cannot hide executions outside the suite array."""
    pilot = PILOT if pilot is None else Path(pilot)
    handles = {row["trial_handle"] for row in selected}
    observations = []
    for trial in protocol["trials"]:
        if trial["trial_handle"] not in handles:
            directory = safe(pilot / "runtime/trials" / trial["trial_handle"], pilot)
            driver = safe(pilot / "model_runs" / trial["trial_handle"] / "run_result.json", pilot)
            observations.append({**{key: trial[key] for key in IDENTITY}, "status": "not_selected_for_branch_diagnostic",
                                 "arm_file_absent": not (directory / "arm.json").exists(),
                                 "driver_record_absent": not driver.exists(),
                                 "execution_journals_absent": not any(directory.rglob("actions.jsonl")) and not any(directory.rglob("budget.jsonl"))})
    return observations


def runtime_binding(public, suite, *, root=ROOT):
    """Bind this diagnostic to the frozen modified runtime, not future live files."""
    reference = public["runtime_version"]
    manifest_path = safe(reference["path"], root)
    require(digest(manifest_path) == reference["sha256"] and integer(reference["size_bytes"])
            and manifest_path.stat().st_size == reference["size_bytes"], "Runtime repair manifest binding differs")
    manifest = read(manifest_path)
    require(manifest.get("status") == "passed_local_repair" and manifest.get("agh_core_modified") is True
            and suite.get("agh_core_modified") is True, "Modified runtime disclosure missing")
    files = manifest["runtime_files"]
    require(type(files) is list and bool(files) and all(type(row) is dict and type(row.get("path")) is str
            and type(row.get("archive")) is str and type(row.get("sha256")) is str
            and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) for row in files)
            and len({row["path"] for row in files}) == len(files), "Runtime source inventory differs")
    for row in files:
        require(digest(safe(row["archive"], root)) == row["sha256"], "Frozen runtime archive differs")
    projected = [{"path": row["path"], "sha256": row["sha256"]} for row in files]
    require(suite.get("runtime_before") == projected == suite.get("runtime_after"),
            "Runtime changed during the diagnostic or transport inventory differs")
    return True


def phase_capacity_accounting(current_actual):
    """Capacity debit cannot close unknown historical token usage."""
    closed = integer(current_actual)
    return {"prior_closed_request_slots": 34, "request_slots_debited_before": 41,
            "request_slots_debited_after": 41 + current_actual if closed else None,
            "request_slots_debited_after_conservative_reservation": 48,
            "legacy_token_usage_closed": False, "model_requests_phase_actual": None,
            "phase_actual_usage_closed": None,
            "within_original_capacity": closed and current_actual <= 7 and 41 + current_actual <= 48}


def summarize():
    errors = []
    protocol = _load(PILOT / "protocol.json", errors)
    public = _load(PILOT / "model_protocol.json", errors)
    suite = _load(PILOT / "run_result.json", errors)
    checks, results, unselected = {}, [], []
    try:
        selected = selected_trials(protocol, public)
        checks["exact_preregistered_single_F_refusal"] = True
        checks["new_private_public_and_suite_protocol_binding"] = public.get("protocol_sha256") == suite.get("protocol_sha256") == digest(PILOT / "protocol.json")
        ledger_ref = public["capacity_ledger"]
        ledger_path = Path(ledger_ref["path"])
        require(digest(ledger_path) == ledger_ref["sha256"] and ledger_path.stat().st_size == ledger_ref["size_bytes"],
                "Capacity receipt binding differs")
        from tools.comparison_request_debit_v1 import validate_receipt
        receipt = validate_receipt(ledger_path, root=ROOT)
        checks["fresh_source_bound_capacity_ledger"] = receipt["status"] == "capacity_verified_with_legacy_usage_unknown" \
            and receipt["phase_model_budget"] == public["phase_model_budget"] and receipt["phase_actual_usage_closed"] is None
        reported = suite.get("trials")
        handles = [trial["trial_handle"] for trial in selected]
        prefix_ok, observations = reported_selection(selected, reported)
        checks["suite_records_follow_selected_protocol_prefix"] = prefix_ok
        spec = importlib.util.spec_from_file_location("_v9_refusal_business_evaluator", ROOT / "tools/verify_comparison_case_v1.py")
        evaluator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(evaluator)
        safe(PILOT / "business_verification").mkdir(exist_ok=True)
        for trial, observation in zip(selected, observations):
            try:
                results.append(evaluate_trial(trial, observation, evaluator))
            except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
                directory = PILOT / "runtime/trials" / trial["trial_handle"]
                record = PILOT / "model_runs" / trial["trial_handle"] / "run_result.json"
                started_here = observation is not None or record.exists() or (directory / "arm.json").exists()
                results.append({**trial, "started": started_here,
                                "execution_status": "started_failed_acceptance" if started_here else "selected_not_started",
                                "joint_correct_completion": False, "main_model_requests": None,
                                "native_title_requests": None, "actual_total_model_requests": None,
                                "domain_invocations": None, "proven_no_execution_artifacts": False,
                                "errors": [{"type": type(error).__name__, "message": str(error)}]})
        unselected = unselected_observations(protocol, selected)
        checks["frozen_modified_runtime_and_execution_binding"] = runtime_binding(public, suite)
        checks["all_selected_accounted_in_protocol_order"] = [row["trial_handle"] for row in results] == handles
        checks["selected_refusal_joint_correct"] = len(results) == 1 and all(row["joint_correct_completion"] is True for row in results)
        checks["other_eight_positions_remain_unarmed"] = len(unselected) == 8 and all(row["arm_file_absent"] and row["driver_record_absent"] and row["execution_journals_absent"] for row in unselected)
        checks["suite_terminal_and_original_caps"] = suite.get("status") == "engineering_diagnostic_executed_pending_independent_evaluation" \
            and all(type(suite.get(key)) is int and suite[key] == value for key, value in
                    {"model_requests_cap_total": 7, "phase_model_requests_cap_total": 48,
                     "prior_closed_request_slots": 34, "request_slots_debited_before": 41, "planned_trials": 9}.items()) \
            and suite.get("legacy_token_usage_closed") is False
    except (OSError, ValueError, KeyError, TypeError, AttributeError) as error:
        errors.append({"type": type(error).__name__, "message": str(error)})
        checks["summary_readers_and_protocol_acceptance"] = False
    started = [row for row in results if row["started"]]
    unknown = [row["trial_handle"] for row in started if not integer(row.get("actual_total_model_requests"))]
    proven_unstarted = all(row.get("proven_no_execution_artifacts") is True for row in results if not row["started"])
    total = sum(row["actual_total_model_requests"] for row in started) if results and not unknown and proven_unstarted else None
    domain_total = sum(row["domain_invocations"] for row in started) if results and all(integer(row.get("domain_invocations")) for row in started) and proven_unstarted else None
    checks["all_started_model_costs_known_and_closed"] = bool(results) and not unknown and proven_unstarted
    checks["suite_actual_requests_matches_closed_observations"] = integer(total) and type(suite) is dict \
        and integer(suite.get("model_requests_actual")) and suite["model_requests_actual"] == total
    phase = phase_capacity_accounting(total)
    checks["diagnostic_and_whole_phase_within_original_caps"] = phase["within_original_capacity"]
    checks["historical_usage_stays_unknown"] = phase["legacy_token_usage_closed"] is False and phase["model_requests_phase_actual"] is None
    checks["summary_has_no_reader_errors"] = not errors
    return {"schema_version": 1, "kind": "comparison_F_refusal_diagnostic_acceptance_v3",
            "status": "passed_branch_diagnostic" if checks and all(value is True for value in checks.values()) else "failed",
            "checked_at": datetime.now(timezone.utc).isoformat(), "checks": checks, "errors": errors,
            "scope": "One selected synthetic F source refusal; not a completed comparison or comparative superiority evidence",
            "selection": public.get("engineering_diagnostic", {}).get("selection") if type(public) is dict else None,
            "suite_status": suite.get("status") if type(suite) is dict else None,
            "suite_failure": suite.get("failure") if type(suite) is dict else None,
            "suite_reported_model_requests_actual": suite.get("model_requests_actual") if type(suite) is dict else None,
            "selected_trial_count": 1, "selected_started_count": len(started), "selected_joint_correct_count": sum(row["joint_correct_completion"] is True for row in results),
            "results": results, "failed_selected": [row["trial_handle"] for row in started if not row["joint_correct_completion"]],
            "selected_not_started": [row["trial_handle"] for row in results if not row["started"]],
            "unselected": unselected, "planned_comparison_trials": 9, "comparison_other_positions": len(unselected),
            "comparison_unexecuted_trials": 9 - len(started),
            "model_requests_this_diagnostic": total, **phase, "diagnostic_cap": 7, "phase_cap": 48,
            "capacity_ledger": public.get("capacity_ledger") if type(public) is dict else None,
            "runtime_version": public.get("runtime_version") if type(public) is dict else None,
            "agh_core_modified": suite.get("agh_core_modified") if type(suite) is dict else None,
            "unknown_model_cost_trials": unknown, "domain_invocations_this_diagnostic": domain_total,
            "recovery_time": "not_measured", "new_detector_calls": 0, "new_training_runs": 0, "gpu_seconds": 0,
            "conclusion": "Fresh refusal branch accepted; historical title usage remains unknown" if checks and all(value is True for value in checks.values()) else "Branch diagnostic incomplete or failed; preserve all original records"}


def main():
    if (PILOT / "verification.json").exists():
        raise FileExistsError("V9 verification.json already exists; preserved review cannot be overwritten")
    result = summarize()
    save(PILOT / "verification.json", result)
    print(json.dumps({key: result[key] for key in ("status", "checks", "selected_started_count", "selected_joint_correct_count",
                     "failed_selected", "selected_not_started", "model_requests_this_diagnostic", "model_requests_phase_actual")}, ensure_ascii=False))
    return 0 if result["status"] == "passed_branch_diagnostic" else 1


if __name__ == "__main__":
    raise SystemExit(main())
