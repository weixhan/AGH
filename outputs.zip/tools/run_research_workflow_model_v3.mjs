// One fresh, guarded Agnes turn. All effects use the public official SDK.
import {readFile,writeFile,access} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {exportSession} from '../../agnes-harness/packages/cli/src/commands/export.ts';
import {webClient,origin,finishEventReading} from './agh_ws_client.mjs';
import {normalizeResearchPath,createResearchWorkflowScopeGuard} from './research_workflow_scope_guard_v1.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const output=join(root,'outputs','agh-research-workflow-model-v3');
const protocol=JSON.parse(await readFile(join(output,'protocol.json'),'utf8'));
const keys=['schema_version','workspace_root','qualified_start_tool','qualified_status_tool','request_id',
 'workflow_id','case_id','budget','max_start_calls','max_status_calls','max_model_requests','max_wall_seconds'];
const policy=Object.fromEntries(keys.map(key=>[key,protocol[key]]));
createResearchWorkflowScopeGuard(policy); // Validate before creating a session.
const stable=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)
 ?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
if(stable(policy)!==stable(protocol.scope_policy))throw new Error('Policy projection differs from protocol');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const name of ['source_lock','scope_guard','runner_source'])
 if(sha(await readFile(protocol[name].path))!==protocol[name].sha256)throw new Error(`Changed ${name}`);
const lock=JSON.parse(await readFile(protocol.source_lock.path,'utf8'));
for(const member of lock.files)if(sha(await readFile(member.path))!==member.sha256)throw new Error('Changed deployment member');
const activation=JSON.parse(await readFile(join(output,'activation.json'),'utf8'));
if(!activation.complete||!activation.after?.trusted||activation.after.actual!=='running')throw new Error('Scope plugin inactive');
const workspace=protocol.workspace_root;
const workflowDirectory=join(workspace,'outputs',policy.workflow_id);
const registryDirectory=join(workspace,'.runtime','research-mcp-v2',policy.workflow_id);
for(const path of [workflowDirectory,registryDirectory]) {
 try{await access(path);throw new Error('Original request already exists; no budget reset or replay is allowed');}
 catch(error){if(error.code!=='ENOENT')throw error;}
}
const record={schema_version:1,status:'starting',started_at:new Date().toISOString(),policy,cwd:workspace,
 model:'agnes-3.0-flash',route:'account-defect-researcher',source_lock:protocol.source_lock,
 scope_guard:protocol.scope_guard,runner_source:protocol.runner_source,workflow_directory:workflowDirectory,
 registry_directory:registryDirectory,permissions:[],calls:[],results:[],hook_events:[],scope_request_events:[],
 final_texts:[],model_request_count:0,tool_catalog_narrowed:false,new_detection_inference_performed:false,
 new_model_inference_performed:false,model_prompt_sent:false};
const recordPath=join(output,'run_result.json');
await writeFile(recordPath,JSON.stringify(record,null,2)+'\n',{flag:'wx',mode:0o600});
const save=()=>writeFile(recordPath,JSON.stringify(record,null,2)+'\n');
let client,session,iterator,reading,readyTimer,timer,readyResolve,readyReject,startApprovals=0;
const ready=new Promise((yes,no)=>{readyResolve=yes;readyReject=no;});
const abort=new AbortController();
const compact=payload=>{
 const science=payload.scientific_summary;
 const subset=(row,names)=>Object.fromEntries(names.map(name=>[name,row[name]]));
 return {...subset(payload,['status','workflow_id','research_status','case_id','actual_tool_path','domain_invocations',
  'next_action','synthetic_only','new_inference_calls','new_model_requests']),
  relative_small:subset(science.relative_small,['definition_id','gt','tp_640','tp_960']),
  tiny_small:subset(science.tiny_small,['definition_id','gt','tp_640','tp_960']),
  resolution:subset(science.resolution,['fp_640','fp_960']),
  slicing:{candidate_status:science.slicing.candidate_status,failed_gate_count:science.slicing.failed_gates.length},
  evidence_ids:payload.evidence_ids};
};
try {
 const response=await fetch(`${origin}/admin/plugins/api/list`,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},
  body:JSON.stringify({profile:'local-dev'}),signal:AbortSignal.timeout(10000)});
 const live=(await response.json()).packages?.find(row=>row.id===activation.package_id);
 if(!response.ok||!live?.trusted||live.actual!=='running'||live.actualIntegrity!==activation.after.actualIntegrity)
  throw new Error('Live scope plugin differs from activation');
 const resource=await fetch(`${origin}/admin/resources/api/mcp/status`,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},
  body:JSON.stringify({profile:'local-dev',serverId:protocol.server_id}),signal:AbortSignal.timeout(10000)});
 const status=await resource.json();
 if(!resource.ok||status.connectionState!=='ready'||status.toolCount!==2)throw new Error('New MCP service is not ready with two tools');
 client=await webClient();await client.workspace.add(workspace);
 session=await client.session.new({cwd:workspace,sessionKey:randomUUID()});
 record.session_id=session.id;record.session_url=`${origin}/?session=${encodeURIComponent(session.id)}`;await save();
 session.onPermissionRequest(async request=>{
  const tool=request.toolCall?._meta?.['ai.agnes.harness']?.tool,input=request.toolCall?.rawInput;
  const once=request.options.find(option=>option.kind==='allow_once');
  const start=tool===policy.qualified_start_tool&&stable(input)===stable(protocol.start_arguments)&&startApprovals===0;
  const read=tool===policy.qualified_status_tool&&stable(input)===stable({workflow_id:policy.workflow_id});
  const allowed=request.sessionId===session.id&&Boolean(once)&&(start||read)&&Date.now()<record.deadline_epoch_ms;
  if(allowed&&start)startApprovals++;
  record.permissions.push({tool,input,tool_call_id:request.toolCall?.toolCallId??request.toolCall?.id,
   decision:allowed?'allowed-once':'rejected'});await save();
  return allowed?{optionId:once.optionId}:{verdict:'rejected'};
 });
 iterator=session.events()[Symbol.asyncIterator]();
 readyTimer=setTimeout(()=>readyReject(new Error('No scope readiness before the model turn')),15000);
 reading=(async()=>{
  for(;;){
   const next=await iterator.next();if(next.done)break;
   // SDK delivery metadata is absent from official exported event envelopes.
   const {_meta:deliveryMetadata,...event}=next.value;
   if(event.type.endsWith('/scope-ready')){
    if(event.data.mode!=='bounded-research-workflow-v1'||normalizeResearchPath(event.data.workspace_root)!==normalizeResearchPath(workspace)
       ||stable(event.data.policy)!==stable(policy))throw new Error('Scope readiness mismatch');
    record.scope_ready=event;readyResolve();
   }else if(event.type.endsWith('/scope-decision'))record.hook_events.push(event);
   else if(event.type.endsWith('/scope-request-decision'))record.scope_request_events.push(event);
   else if(event.type==='request/sent')record.model_request_count++;
   else if(event.type==='cost/ledger'&&event.data.purpose==='inference')record.new_model_inference_performed=true;
   else if(event.type==='tool/call')record.calls.push({seq:event.seq,origin:event.origin,...event.data});
   else if(event.type==='tool/result'){
    const texts=event.data.content?.filter(item=>item.type==='text')??[];let payload;
    if(texts.length===1)try{payload=JSON.parse(texts[0].text);}catch{/* Preserve actual malformed result. */}
    record.results.push({seq:event.seq,tool_use_id:event.data.toolUseId,code:event.data.code,is_error:event.data.isError,
     ...(payload?{payload}:{})});
   }else if(event.type==='assistant/message')record.final_texts.push(event);
   else if(event.type==='turn/end')record.turn_end=event;
   await save();if(event.type==='turn/end')break;
  }
 })();reading.catch(readyReject);
 await ready;clearTimeout(readyTimer);
 await session.setModel({slot:'primary',route:record.route,model:record.model});
 const task=await readFile(join(root,'agent','research_workflow_agnes_v1_task.md'),'utf8');
 const prompt=`${task}\n\n本次已冻结协议（直接使用工具与参数，不读文件）：\n${JSON.stringify({
  qualified_start_tool:policy.qualified_start_tool,qualified_status_tool:policy.qualified_status_tool,
  start_arguments:protocol.start_arguments,workflow_id:policy.workflow_id,max_status_calls:6,max_model_requests:8,max_wall_seconds:120},null,2)}\n\n最终输出硬约束：不得写“连续调用验收通过”或其他概述，是否通过由外部独立检查器决定。最终正文第一行必须逐字为“本次输入为隔离人工案例，科学结论复用历史验证证据；新增检测推理为0，不证明无限制研究自主性。”，后面只接一个json代码块。不得使用标题、验收总结、验证计数或任何其它正文。JSON内容仍只能复制这一次新任务completed结果。`;
 record.prompt=prompt;record.prompt_sha256=sha(prompt);record.model_started_epoch_ms=Date.now();
 record.deadline_epoch_ms=record.model_started_epoch_ms+policy.max_wall_seconds*1000;
 timer=setTimeout(()=>abort.abort(),record.deadline_epoch_ms-Date.now());
 record.status='running';record.model_prompt_sent=true;await save();
 console.log(JSON.stringify({session_id:session.id,guard_ready:true,url:record.session_url}));
 record.turn_result=await session.prompt(prompt,{signal:abort.signal,titleLocale:'zh-CN'});
 await finishEventReading(reading);
 const terminal=record.results.findLast(row=>row.payload?.status==='completed'&&row.payload?.workflow_id===policy.workflow_id);
 const final=record.final_texts.find(row=>row.seq===record.turn_end?.data?.lastAssistantSeq);
 const text=(final?.data?.content??[]).filter(item=>item.type==='text').map(item=>item.text).join('\n');
 const blocks=[...text.matchAll(/```json\s*\n([\s\S]*?)\n```/g)];
 if(blocks.length!==1)throw new Error('Final output did not contain exactly one compact JSON block');
 record.final_json=JSON.parse(blocks[0][1]);
 const starts=record.calls.filter(row=>row.name===policy.qualified_start_tool);
 const reads=record.calls.filter(row=>row.name===policy.qualified_status_tool);
 record.checks={scope_ready_before_model:Boolean(record.scope_ready),exactly_one_fixed_start:starts.length===1
  &&stable(starts[0].args)===stable(protocol.start_arguments),bounded_reads:reads.length>=1&&reads.length<=6
  &&reads.every(row=>stable(row.args)===stable({workflow_id:policy.workflow_id})),
  no_other_calls:record.calls.length===starts.length+reads.length,
  all_scope_gates_allowed:record.hook_events.length===record.calls.length&&record.hook_events.every(row=>row.data.allow===true),
  start_allow_once:startApprovals===1&&record.permissions.every(row=>row.decision==='allowed-once'),
  model_request_cap:record.model_request_count>=1&&record.model_request_count<=8,
  fresh_completed_status:Boolean(terminal&&!terminal.is_error&&terminal.payload.verification?.status==='passed'),
  exact_final:terminal&&stable(record.final_json)===stable(compact(terminal.payload)),
  fixed_scope_prose:text.replace(/```json\s*\n[\s\S]*?\n```/g,'').trim()===
   '本次输入为隔离人工案例，科学结论复用历史验证证据；新增检测推理为0，不证明无限制研究自主性。',
  completed_turn:record.turn_end?.data?.reason==='completed',original_deadline:Date.now()<record.deadline_epoch_ms};
 record.status=Object.values(record.checks).every(value=>value===true)?'completed':'failed';
 if(record.status!=='completed')process.exitCode=1;
}catch(error){record.status='failed';record.failure={type:error.name,message:error.message};process.exitCode=1;}
finally{
 clearTimeout(readyTimer);
 if(record.status==='failed')abort.abort();
 await client?.close();await iterator?.return?.();await finishEventReading(reading).catch(()=>undefined);
 if(session)for(const [format,name]of [['agnes','session.jsonl'],['html','session.html']]){
  let exporter;
  try{
   if(record.deadline_epoch_ms&&Date.now()>=record.deadline_epoch_ms)throw new Error('Original deadline expired; finalization cannot extend it');
   exporter=await webClient();
   await exportSession({positional:[session.id],format,raw:false,out:join(output,name)},
    {cwd:workspace,io:{stdout:process.stdout,stderr:process.stderr},writeFile:(path,bytes)=>writeFile(path,bytes,{flag:'wx',mode:0o600})},exporter);
  }catch(error){record.export_failure={type:error.name,message:error.message};record.status='failed';process.exitCode=1;}
  finally{await exporter?.close();}
 }
 clearTimeout(timer);record.finished_epoch_ms=Date.now();record.finished_at=new Date().toISOString();
 if(record.deadline_epoch_ms&&record.finished_epoch_ms>=record.deadline_epoch_ms){record.status='failed';
  record.failure??={type:'DeadlineError',message:'Finalization escaped original model deadline'};process.exitCode=1;}
 await save();console.log(JSON.stringify({status:record.status,session_id:record.session_id,model_requests:record.model_request_count,
  tool_calls:record.calls.length,checks:record.checks,failure:record.failure,export_failure:record.export_failure}));
}
