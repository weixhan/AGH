"""Independently replay a bounded research workflow without executing its tools.

Only the Python standard library is imported.  Domain publication chains, saved
source bytes, state transitions, budgets and report claims are inspected as data.
No controller, protocol decision helper, detector or model is loaded here.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def decode(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError("Nonfinite JSON constant: " + value)
    result = json.loads(text, object_pairs_hook=unique, parse_constant=invalid)
    json.dumps(result, allow_nan=False)
    return result


def read(path):
    return decode(Path(path).read_text(encoding="utf-8-sig"))


def lines(path):
    return [decode(row) for row in Path(path).read_text(encoding="utf-8-sig").splitlines() if row.strip()]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def inside(path, roots, *, file=True):
    value = Path(path).resolve()
    require(any(value.is_relative_to(Path(root).resolve()) for root in roots), "Evidence path escapes allowed scope")
    require(value.is_file() if file else value.is_dir(), "Evidence path is absent or wrong kind")
    return value


def record(row, roots):
    require(isinstance(row, dict), "Evidence file record must be an object")
    path = inside(row["path"], roots)
    require(isinstance(row.get("sha256"), str) and re.fullmatch(r"[0-9a-f]{64}", row["sha256"]), "Invalid evidence SHA256")
    require(row["sha256"] == digest(path), "Evidence SHA256 differs from current bytes")
    if "size_bytes" in row:
        require(type(row["size_bytes"]) is int and row["size_bytes"] == path.stat().st_size, "Evidence byte size differs")
    if "name" in row:
        require(row["name"] == path.name, "Evidence filename differs")
    return path


def publication(directory, tool, result_name, required):
    """Check a legacy domain completion chain independently of task_runtime."""
    directory = Path(directory).resolve()
    completion = read(directory / "completion.json")
    manifest = read(directory / "artifact_manifest.json")
    task_id = directory.name
    for document in (completion, manifest):
        require(document.get("task_id") == task_id and document.get("tool") == tool
                and document.get("status") == "completed", "Invalid domain completion identity")
    require(Path(completion.get("artifact_manifest", "")).resolve() == directory / "artifact_manifest.json",
            "Domain completion points to a different manifest")
    require(completion.get("artifact_manifest_sha256") == digest(directory / "artifact_manifest.json"),
            "Domain manifest hash differs")
    entries = manifest.get("files", [])
    require(isinstance(entries, list) and len(entries) == len(required)
            and {row.get("name") for row in entries} == set(required), "Incomplete domain artifact membership")
    for row in entries:
        require(record(row, [directory]).parent == directory, "Domain artifact is outside task directory")
    require(completion.get("artifacts_sha256") == {row["name"]: row["sha256"] for row in entries},
            "Domain completion artifact hashes differ")
    result = read(directory / result_name)
    require(result.get("status") == "completed" and result.get("task_id") == task_id and result.get("tool") == tool,
            "Domain result identity differs")
    require(not (directory / "failure.json").exists(), "Completed domain directory also contains failure")
    return result


GEOMETRY_FILES = {"verification_result.json", "geometry_details.jsonl", "fixture_results.json", "input_manifest.json", "events.jsonl"}
REPAIR_FILES = {"repair_result.json", "repair_changes.jsonl", "input_manifest.json", "events.jsonl", "copy_manifest.json"}
FROZEN_ORACLE_COUNTS = {"total": 30, "passed": 30, "failed": 0, "synthetic": 29, "real": 1, "expected_errors": 14}


def unchanged_inputs(document, configuration):
    roots = [configuration[key] for key in ("dataset_root", "raw_root", "split_dir", "research_root")]
    roots.append(Path(__file__).resolve().parents[1])
    entries = document.get("files", [])
    require(document.get("all_unchanged") is True and isinstance(entries, list) and bool(entries),
            "Domain source inventory is empty or changed")
    require(len({row.get("role") for row in entries}) == len(entries), "Duplicate domain source role")
    for row in entries:
        path = Path(row["path"]).resolve()
        require(any(path.is_relative_to(Path(root).resolve()) for root in roots), "Domain source escapes configured scope")
        exists = path.is_file()
        require(row.get("unchanged") is True and row.get("sha256_before") == row.get("sha256_after"),
                "Domain source changed during execution")
        if "exists_before" in row:
            require(exists == row["exists_before"] == row.get("exists_after"), "Domain source presence changed")
        else:
            require(exists, "Geometry source disappeared")
        require((digest(path) if exists else None) == row.get("sha256_before"), "Current domain source hash differs")


def close_numbers(actual, expected, tolerance):
    if isinstance(expected, list):
        return isinstance(actual, list) and len(actual) == len(expected) and all(
            close_numbers(a, b, tolerance) for a, b in zip(actual, expected))
    return type(actual) in {int, float} and type(expected) in {int, float} and math.isfinite(actual) and abs(actual - expected) <= tolerance


def independent_passing_labels(result, rows):
    """Reconstruct extrema from source vertices, without loading a geometry module."""
    config = result["configuration"]
    raw, dataset = Path(config["raw_root"]), Path(config["dataset_root"])
    sources = {}
    for row in rows:
        if row.get("record_type") != "annotation":
            continue
        source = row["source_json"]
        if source not in sources:
            sources[source] = read(inside(raw / source, [raw]))
        document = sources[source]
        image = next(item for item in document["images"] if item["id"] == row["image_id"])
        annotation = next(item for item in document["annotations"] if item["id"] == row["annotation_id"])
        require(annotation["image_id"] == image["id"] and image["file_name"] == row["image"], "Geometry source identity differs")
        x, y, w, h = annotation["bbox"]
        width, height = image["width"], image["height"]
        angle = (annotation.get("attributes") or {}).get("rotation", 0)
        require(all(type(v) in {int, float} and math.isfinite(v) for v in (x, y, w, h, width, height, angle))
                and w > 0 and h > 0 and width > 0 and height > 0, "Geometry source is not finite positive geometry")
        cx, cy = x + w / 2, y + h / 2
        theta = math.radians(angle % 360)
        cosine, sine = math.cos(theta), math.sin(theta)
        points = [[cx + dx * cosine - dy * sine, cy + dx * sine + dy * cosine]
                  for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2))]
        bounds = [max(0, min(width, min(p[0] for p in points))), max(0, min(height, min(p[1] for p in points))),
                  max(0, min(width, max(p[0] for p in points))), max(0, min(height, max(p[1] for p in points)))]
        left, top, right, bottom = bounds
        if right <= left or bottom <= top:
            require(row.get("status") == "invalid_source_box", "Empty clipped geometry was not excluded")
            continue
        expected = [(left + right) / (2 * width), (top + bottom) / (2 * height), (right - left) / width, (bottom - top) / height]
        require(row.get("status") == "passed" and row.get("source_bbox") == annotation["bbox"]
                and row.get("rotation") == angle, "Passing annotation source fields differ")
        label_path = inside(dataset / "labels" / row["split"] / (Path(row["image"]).stem + ".txt"), [dataset])
        labels = [line.split() for line in label_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
        label = labels[row["label_row"] - 1]
        require(len(label) == 5 and int(label[0]) == annotation["category_id"] - 1
                and close_numbers([float(v) for v in label[1:]], expected, 5.1e-9), "Independent label geometry differs")
        metadata = read(inside(dataset / "metadata" / row["split"] / (Path(row["image"]).stem + ".json"), [dataset]))
        item = next(entry for entry in metadata["annotations"] if entry["annotation_id"] == annotation["id"])
        require(close_numbers(item.get("hbb_xyxy"), bounds, 1e-8)
                and close_numbers(item.get("rotated_corners"), points, 1e-8)
                and item.get("original_bbox") == annotation["bbox"] and item.get("rotation") == angle,
                "Independent metadata geometry differs")


def geometry(directory, expected_status=None):
    result = publication(directory, "verify_label_geometry", "verification_result.json", GEOMETRY_FILES)
    summary = result.get("summary", {})
    status = summary.get("verification_status")
    require(status in {"passed", "failed"}, "Geometry semantic status is absent")
    if expected_status is not None:
        require(status == expected_status, "Geometry semantic status differs")
    rows = lines(Path(directory) / "geometry_details.jsonl")
    fixtures = read(Path(directory) / "fixture_results.json")
    inputs = read(Path(directory) / "input_manifest.json")
    unchanged_inputs(inputs, result["configuration"])
    require(inputs.get("all_unchanged") is True and all(row.get("unchanged") is True
            and row.get("sha256_before") == row.get("sha256_after") for row in inputs.get("files", [])),
            "Geometry input hashes were not preserved")
    require(summary.get("independent_geometry_verification") is True and summary.get("inference_performed") is False,
            "Geometry provenance assertions differ")
    images = [row for row in rows if row.get("record_type") == "image"]
    annotations = [row for row in rows if row.get("record_type") == "annotation"]
    totals = summary.get("totals", {})
    require(len(images) == totals.get("images") and len(annotations) == totals.get("source_annotations"),
            "Geometry detail population differs")
    if status == "passed":
        require(summary.get("issue_count") == 0 and summary.get("issues_by_code") == {}
                and fixtures.get("status") == "passed" and summary.get("fixture_status") == "passed",
                "Geometry passed status contradicts finding or fixture data")
        require(fixtures.get("counts") == FROZEN_ORACLE_COUNTS and summary.get("fixture_counts") == FROZEN_ORACLE_COUNTS,
                "Geometry fixture population differs from frozen oracle suite")
        require(all(not row.get("differences") for row in images)
                and all(row.get("status") in {"passed", "invalid_source_box"} and not row.get("differences") for row in annotations),
                "Geometry passed status contradicts detail rows")
        independent_passing_labels(result, rows)
    else:
        require(type(summary.get("issue_count")) is int and summary["issue_count"] > 0
                and isinstance(summary.get("issues_by_code"), dict)
                and sum(summary["issues_by_code"].values()) == summary["issue_count"],
                "Geometry failed status has no consistent findings")
    return result


def repair(directory):
    directory = Path(directory).resolve()
    result = publication(directory, "repair_label_copy", "repair_result.json", REPAIR_FILES)
    config, summary = result["configuration"], result["summary"]
    unchanged_inputs(read(directory / "input_manifest.json"), config)
    changes = lines(directory / "repair_changes.jsonl")
    copied = read(directory / "copy_manifest.json")
    require(summary.get("repair_status") == "passed" and summary.get("verification_status") == "passed"
            and summary.get("decision") == "repaired_copy" and summary.get("changed_files") == len(changes) > 0,
            "Repair is absent, refused, or falsely counts an unchanged copy")
    require(summary.get("inference_performed") is False and summary.get("inputs_unchanged") is True,
            "Repair scope assertions differ")
    root = inside(copied["copy_root"], [directory], file=False)
    require(root == directory / "dataset_copy" and copied.get("verification_status") == "passed",
            "Repair copy root or verification differs")
    after = copied["after_verification"]
    require(after.get("task_id") == "after" and after.get("verification_status") == "passed"
            and Path(after["output_root"]).resolve() == directory / "after_verification"
            and Path(after["result_path"]).resolve() == directory / "after_verification" / "after" / "verification_result.json"
            and Path(after["completion_path"]).resolve() == directory / "after_verification" / "after" / "completion.json",
            "Repair copy points to unrelated independent verification")
    verified = geometry(directory / "after_verification" / "after", "passed")
    require(Path(verified["configuration"]["dataset_root"]).resolve() == root
            and verified["summary"]["totals"] == summary.get("totals"), "After verification uses another copy or population")
    entries = copied.get("files", [])
    names = {row["relative_path"] for row in entries}
    require(len(names) == len(entries) and names == {path.relative_to(root).as_posix() for path in root.rglob("*")
            if path.is_file() and not path.relative_to(root).as_posix().startswith("images/")}, "Repair copy membership differs")
    changed = {row["relative_path"]: row for row in changes}
    require(len(changed) == len(changes), "Duplicate repair changes")
    for row in entries:
        target = record(row, [root])
        require(target == root / row["relative_path"], "Repair target differs from relative path")
        relative = row["relative_path"]
        if not relative.startswith(("labels/", "metadata/")):
            continue
        original = Path(config["dataset_root"]) / relative
        if relative in changed:
            item = changed[relative]
            require(item["before_sha256"] == (digest(original) if original.is_file() else None)
                    and item["after_sha256"] == digest(target)
                    and item["source_sha256"] == digest(inside(Path(config["raw_root"]) / item["source_json"], [config["raw_root"]]))
                    and item["after"].encode("utf-8") == target.read_bytes(), "Repair changes contradict actual bytes or raw source")
            require(item.get("before") == (original.read_bytes().decode("utf-8-sig", errors="replace") if original.is_file() else None),
                    "Repair before-text evidence differs from original bytes")
        else:
            require(original.is_file() and target.read_bytes() == original.read_bytes(), "Unmodified label/metadata bytes differ")
    require(set(changed).issubset(names), "Repair change is missing from copied files")
    for row in copied.get("images", []):
        target = inside(root / row["relative_path"], [root])
        original = inside(row["source_path"], [config["dataset_root"]])
        require(row.get("storage") == "hardlink" and Path(row["path"]).resolve() == target and os.path.samefile(target, original),
                "Repair image membership no longer uses recorded hardlink")
    require(read(root / "manifest.json")["source_sha256"] == read(Path(config["dataset_root"]) / "manifest.json")["source_sha256"],
            "Repair rewrote trusted raw-source hashes")
    return result


TOP_FILES = {"request.json", "protocol.json", "runtime.json", "input_case.json", "input_snapshots.json", "source_registry.json",
             "events.jsonl", "budget.jsonl", "evidence.json", "plan.json", "result.json", "claims.json", "report.md",
             "independent_verification.json"}
PROJECT_ROOT = Path(__file__).resolve().parents[1]
CASE_SHA256 = "3dd74146b0ad7f481ca1d5d3adaa5353182ff999b66d0e9f7a32472c54fefa6b"
PROTOCOL_SHA256 = "64b29779c5245dd2a5fb5a4e3a3eded75d39bf920b9c942620faa69351b0b25f"
ACTION_COSTS = {"verify_label_geometry": 1, "repair_label_copy": 3, "verify_copy": 1, "read_scientific_evidence": 1}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def finite(value):
    return type(value) in {int, float} and math.isfinite(value) and value >= 0


def request_and_protocol(directory):
    request, protocol = read(directory / "request.json"), read(directory / "protocol.json")
    frozen = read(PROJECT_ROOT / "fixtures" / "research_workflow_protocol_v1.json")
    require(digest(PROJECT_ROOT / "fixtures" / "research_workflow_protocol_v1.json") == PROTOCOL_SHA256,
            "Frozen workflow protocol bytes changed")
    require(protocol == frozen and canonical(protocol) == canonical(frozen), "Workflow protocol differs from frozen local scope")
    require(protocol.get("action_reservations") == ACTION_COSTS, "Frozen action reservations differ")
    specification = PROJECT_ROOT / "fixtures" / "labelguard_cases.json"
    require(digest(specification) == CASE_SHA256 == protocol["case_specification"]["sha256"], "Case specification was not frozen")
    cases = read(specification)["cases"]
    require(protocol["case_specification"]["case_ids"] == [case["id"] for case in cases] and len(cases) == 12,
            "Case specification population differs")
    require(type(request) is dict and set(request) == {"schema_version", "workflow_version", "request_id", "case_id", "budget"},
            "Request schema has unknown or missing fields")
    require(type(request["schema_version"]) is int and request["schema_version"] == 1
            and type(request["workflow_version"]) is int and request["workflow_version"] == 1,
            "Request version has wrong type or value")
    require(type(request["request_id"]) is str and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", request["request_id"])
            and directory.name == "research-workflow-v1-" + request["request_id"], "Request identity is unsafe or differs from directory")
    require(request["case_id"] in protocol["case_specification"]["case_ids"], "Request case is outside frozen population")
    budget = request["budget"]
    require(type(budget) is dict and set(budget) == {"domain_invocations", "wall_seconds", "gpu_seconds", "model_requests"},
            "Request budget schema differs")
    require(type(budget["domain_invocations"]) is int and 0 <= budget["domain_invocations"] <= 6
            and finite(budget["wall_seconds"]) and 0 < budget["wall_seconds"] <= 120
            and type(budget["gpu_seconds"]) is int and budget["gpu_seconds"] == 0
            and type(budget["model_requests"]) is int and budget["model_requests"] == 0, "Request budget exceeds local scope")
    return request, protocol, next(case for case in cases if case["id"] == request["case_id"])


def budget_replay(directory, request, *, prepublication):
    rows = lines(directory / "budget.jsonl")
    require(bool(rows), "Budget ledger is empty")
    previous, used, pending = "0" * 64, 0, None
    actions, costs = [], []
    start = rows[0].get("record", {})
    require(start.get("request") == request and start.get("protocol_sha256") == digest(PROJECT_ROOT / "fixtures" / "research_workflow_protocol_v1.json")
            and start.get("case_specification_sha256") == CASE_SHA256, "Budget original request or frozen hashes differ")
    require(all(finite(start.get(field)) for field in ("started_monotonic", "started_epoch", "deadline_monotonic", "deadline_epoch")),
            "Budget original clock is invalid")
    wall = request["budget"]["wall_seconds"]
    require(abs(start["deadline_monotonic"] - start["started_monotonic"] - wall) < 1e-7
            and abs(start["deadline_epoch"] - start["started_epoch"] - wall) < 1e-6, "Budget original deadline was reset")
    last_time, last_epoch = start["started_monotonic"], start["started_epoch"]
    for index, row in enumerate(rows):
        require(set(row) == {"schema_version", "event_version", "sequence", "event", "previous_sha256", "record", "sha256"}
                and type(row["schema_version"]) is int and row["schema_version"] == 1
                and type(row["event_version"]) is int and row["event_version"] == 1
                and type(row["sequence"]) is int and row["sequence"] == index, "Budget ledger sequence/schema differs")
        unsigned = {key: value for key, value in row.items() if key != "sha256"}
        require(row["previous_sha256"] == previous and row["sha256"] == hashlib.sha256(canonical(unsigned)).hexdigest(),
                "Budget ledger hash chain differs")
        previous = row["sha256"]
        entry, event = row["record"], row["event"]
        if index == 0:
            require(event == "ledger_opened", "Budget journal did not start with one opening")
            continue
        require(event in {"action_reserved", "action_closed"}, "Budget reopening or unknown event is refused")
        require(all(finite(entry.get(field)) for field in ("current_monotonic", "current_epoch", "elapsed_wall_seconds"))
                and entry["current_monotonic"] >= last_time and entry["current_epoch"] >= last_epoch,
                "Budget clocks regressed or are nonfinite")
        last_time, last_epoch = entry["current_monotonic"], entry["current_epoch"]
        require(abs(entry["elapsed_wall_seconds"] - (last_time - start["started_monotonic"])) < 1e-7,
                "Budget elapsed time does not use original start")
        expired = last_time >= start["deadline_monotonic"] or last_epoch >= start["deadline_epoch"]
        require(entry.get("expired") is expired and not expired, "Expired budget cannot publish a completed workflow")
        action, cost = entry.get("action"), entry.get("reserved_cost")
        require(action in ACTION_COSTS and type(cost) is int and cost == ACTION_COSTS[action], "Unknown action or wrong reservation cost")
        if event == "action_reserved":
            require(pending is None and entry.get("token") == f"reservation-{index:04d}" and used + cost <= request["budget"]["domain_invocations"]
                    and entry.get("used_domain_invocations") == used and entry.get("reserved_domain_invocations") == cost,
                    "Budget reservation overlaps or exceeds cumulative limit")
            pending = {"token": entry["token"], "action": action, "reserved_cost": cost}
            actions.append(action)
        else:
            require(pending is not None and all(entry.get(key) == value for key, value in pending.items()),
                    "Budget close does not match original reservation")
            actual = entry.get("actual_cost")
            require(type(actual) is int and 0 <= actual <= cost and entry.get("released_domain_invocations") == cost - actual
                    and entry.get("used_domain_invocations") == used + actual and entry.get("reserved_domain_invocations") == 0,
                    "Budget actual known cost was hidden or forged")
            used += actual
            costs.append(actual)
            pending = None
    require(pending is None and used <= request["budget"]["domain_invocations"], "Open/unknown or excessive budget cost")
    runtime = read(directory / "runtime.json")
    snapshot = read(directory / "result.json")["final_budget"]
    require(runtime.get("workflow_id") == directory.name and runtime.get("budget") == request["budget"],
            "Runtime identity differs from opened ledger")
    require(snapshot.get("request_id") == request["request_id"] and snapshot.get("budget") == request["budget"]
            and snapshot.get("used_domain_invocations") == used and snapshot.get("reserved_domain_invocations") == 0
            and snapshot.get("remaining_domain_invocations") == request["budget"]["domain_invocations"] - used
            and snapshot.get("pending") is None and snapshot.get("gpu_seconds") == 0 and snapshot.get("model_requests") == 0
            and snapshot.get("event_count") == len(rows) and snapshot.get("last_event_sha256") == previous
            and snapshot.get("journal_sha256") == digest(directory / "budget.jsonl") and snapshot.get("journal_file") == "budget.jsonl",
            "Runtime budget snapshot does not match independently replayed ledger")
    for field in ("started_monotonic", "started_epoch", "deadline_monotonic", "deadline_epoch"):
        require(runtime.get(field) == start.get(field), "Runtime changed the original budget identity/deadline")
    for field in ("started_monotonic", "started_epoch", "deadline_monotonic", "deadline_epoch", "protocol_sha256", "case_specification_sha256"):
        require(snapshot.get(field) == start.get(field), "Final snapshot changed the original budget identity/deadline")
    require(finite(snapshot.get("current_monotonic")) and finite(snapshot.get("current_epoch"))
            and snapshot["current_monotonic"] >= last_time and snapshot["current_epoch"] >= last_epoch
            and snapshot["current_monotonic"] < start["deadline_monotonic"] and snapshot["current_epoch"] < start["deadline_epoch"]
            and snapshot.get("expired") is False
            and abs(snapshot.get("elapsed_wall_seconds", -1) - (snapshot["current_monotonic"] - start["started_monotonic"])) < 1e-7,
            "Runtime snapshot is expired or uses another clock start")
    if prepublication:
        require(datetime.now(timezone.utc).timestamp() < start["deadline_epoch"], "Independent prepublication verification exceeded original deadline")
    return {"used": used, "actions": actions, "costs": costs, "deadline_epoch": start["deadline_epoch"], "elapsed": snapshot["elapsed_wall_seconds"]}


def case_and_snapshots(directory, request, case):
    prepared = read(directory / "input_case.json")
    require(prepared.get("schema_version") == 1 and prepared.get("kind") == "bounded_research_prepared_case"
            and prepared.get("case_id") == request["case_id"] and prepared.get("case_group") == case["group"]
            and prepared.get("case_expected") == case["expected"] and prepared.get("synthetic_only") is True
            and prepared.get("inference_performed") is False and prepared.get("model_used") is False,
            "Prepared input contradicts frozen case identity or local scope")
    root = Path(prepared["case_root"]).resolve()
    require(root.is_relative_to(PROJECT_ROOT), "Artificial case root escapes project workspace")
    config = prepared["configuration"]
    expected = {key: str(root / child) for key, child in (("research_root", "research"), ("dataset_root", "dataset"),
                ("raw_root", "raw"), ("split_dir", "splits"), ("output_root", "task_outputs"))}
    expected["weights_path"] = str(root / "research" / "unused.pt")
    require(config == expected and root == directory / "case_inputs",
            "Original case configuration overlaps workflow output or escapes case root")
    snapshot_path = record(prepared["source_snapshot"], [root])
    require(snapshot_path == root / "frozen_inputs.json", "Prepared snapshot points to another case")
    frozen = read(snapshot_path)
    require(frozen.get("configuration") == config and frozen.get("case_id") == request["case_id"]
            and frozen.get("synthetic_only") is True and frozen.get("spec_sha256") == CASE_SHA256
            and frozen.get("files") == prepared.get("source_files"), "Original case snapshot identity differs")
    literal_labels, literal_metadata = frozen_literal_answers(case)
    require(frozen.get("golden_labels") == literal_labels and frozen.get("golden_metadata") == literal_metadata,
            "Prepared golden answers differ from independently frozen static case literals")
    current = {}
    for key in ("research_root", "dataset_root", "raw_root", "split_dir"):
        path_root = Path(config[key]).resolve()
        for path in sorted(path_root.rglob("*")):
            require(not path.is_symlink() and not (hasattr(path, "is_junction") and path.is_junction()), "Linked input paths are refused")
            if path.is_file():
                role = key + "/" + path.relative_to(path_root).as_posix()
                current[role] = {"path": str(path), "size_bytes": path.stat().st_size, "sha256": digest(path)}
    snapshots = read(directory / "input_snapshots.json")
    require(snapshots.get("unchanged") is True and snapshots.get("before") == snapshots.get("after") == frozen["files"] == current,
            "Input snapshot membership or current bytes changed")
    dependencies = prepared.get("source_dependencies", {})
    require(isinstance(dependencies, dict) and bool(dependencies), "Prepared dependency inventory is absent")
    for row in dependencies.values():
        record(row, [PROJECT_ROOT, Path(row["path"]).parent] if row is dependencies.get("production_geometry") else [PROJECT_ROOT])
    source_registry = read(directory / "source_registry.json")
    entries = source_registry.get("files", [])
    require(isinstance(entries, list) and bool(entries) and len({Path(row["path"]).resolve() for row in entries}) == len(entries),
            "Source registry is absent or has duplicate paths")
    production_path = Path(dependencies["production_geometry"]["path"]).resolve()
    for row in entries:
        record(row, [PROJECT_ROOT, production_path.parent] if Path(row["path"]).resolve() == production_path else [PROJECT_ROOT])
    registry_paths = {Path(row["path"]).resolve() for row in entries}
    expected_sources = {PROJECT_ROOT / "defect_researcher" / (name + ".py") for name in (
        "research_protocol_v1", "research_domain_v1", "research_science_v1", "research_workflow_v1",
        "audit", "config", "geometry_verifier", "independent_geometry", "label_repair", "labelguard_fixtures", "task_runtime")}
    expected_sources.update(PROJECT_ROOT / "tools" / name for name in ("verify_research_workflow_v1.py", "review_plan_scale_alignment.py"))
    expected_sources.update(PROJECT_ROOT / "fixtures" / name for name in (
        "research_workflow_protocol_v1.json", "research_science_sources_v1.json", "labelguard_cases.json", "geometry_cases.json"))
    expected_sources.add(production_path)
    require(registry_paths == expected_sources and len(entries) == 18, "Source registry does not cover the exact 18 execution sources")
    return prepared, frozen, registry_paths


def frozen_literal_answers(case):
    specification = read(PROJECT_ROOT / "fixtures" / "labelguard_cases.json")
    source, golden = case["source"], case["golden"]
    labels, metadata = {}, {}
    width, height = source["dimensions"]
    for index, image in enumerate(specification["base"]["images"], 1):
        split, name, image_id = image["split"], image["file_name"], image["image_id"]
        active = split == source["annotation_split"]
        items = []
        if active:
            items = [{"annotation_id": source["annotation_id"], "image_id": image_id, "category_id": source["category_id"],
                      "class": specification["base"]["categories"][str(source["category_id"])], "source_json": f"cable_{index}.json",
                      "original_bbox": source["bbox"], "rotation": float(source["rotation"]),
                      "rotated_corners": [[float(v) for v in point] for point in golden["rotated_corners"]],
                      "hbb_xyxy": [float(v) for v in golden["hbb_xyxy"]], "bbox_clipped": golden["bbox_clipped"],
                      "geometry_version": "hbb_v1", "gradation": source["gradation"], "anomaly_id": source["anomaly_id"]}]
        stem = Path(name).stem
        labels[f"labels/{split}/{stem}.txt"] = golden["label"] if active else ""
        metadata[f"metadata/{split}/{stem}.json"] = {"image": name, "source_json": f"cable_{index}.json", "image_id": image_id,
                        "width": width, "height": height, "geometry_version": "hbb_v1", "annotations": items}
    return labels, metadata


def missing_label_guard(domain, prepared):
    guard = domain.get("source_guard")
    require(isinstance(guard, dict) and guard.get("kind") == "missing_label_trusted_source_guard_v1"
            and guard.get("status") == "passed" and guard.get("read_only") is True and guard.get("domain_tool_calls") == 0
            and guard.get("original_inputs_unchanged") is True and guard.get("oracle_fixture_status") == "passed",
            "Missing-label repair has no bounded passed source guard")
    config = prepared["configuration"]
    dataset, raw, splits = [Path(config[key]) for key in ("dataset_root", "raw_root", "split_dir")]
    missing = guard.get("missing_label", {})
    relative = missing.get("relative_path", "")
    require(re.fullmatch(r"labels/(train|val|test)/[A-Za-z0-9_-]+\.txt", relative)
            and Path(missing.get("path", "")).resolve() == dataset / relative and not (dataset / relative).exists()
            and guard.get("planned_changed_files") == [relative], "Source guard does not describe exactly one absent label")
    errors = domain.get("errors", [])
    require(len(errors) == 1 and errors[0].get("stage") == "label_geometry" and errors[0].get("type") == "FileNotFoundError"
            and errors[0].get("message") == "Missing geometry input: " + str(dataset / relative),
            "Source guard does not preserve actual missing-label execution failure")
    fixtures = read(Path(domain["task_dir"]) / "fixture_results.json")
    require(fixtures.get("status") == "passed" and fixtures.get("counts") == FROZEN_ORACLE_COUNTS,
            "Missing-label source guard lacks passed independent golden fixtures")
    specification = read(PROJECT_ROOT / "fixtures" / "labelguard_cases.json")
    case = next(item for item in specification["cases"] if item["id"] == prepared["case_id"])
    literal_labels, literal_metadata = frozen_literal_answers(case)
    require(relative in literal_labels, "Missing label is outside frozen literal membership")
    for name, value in literal_labels.items():
        if name != relative:
            require((dataset / name).read_bytes() == value.encode("utf-8"), "Missing-label guard hides another label discrepancy")
    for name, value in literal_metadata.items():
        require(read(dataset / name) == value, "Missing-label guard hides another metadata discrepancy")
    manifest = read(dataset / "manifest.json")
    require(record(guard["trusted_manifest"], [dataset]) == dataset / "manifest.json"
            and manifest.get("geometry_version") == "hbb_v1" and manifest.get("categories") == specification["base"]["categories"],
            "Missing-label source manifest mapping differs")
    yaml = (dataset / "data.yaml").read_text(encoding="utf-8")
    mappings = re.findall(r"^\s{2}([0-9]+):\s+([A-Za-z_]+)\s*$", yaml, flags=re.MULTILINE)
    require(len(mappings) == 7 and {int(key): value for key, value in mappings}
            == {int(key) - 1: value for key, value in specification["base"]["categories"].items()},
            "Missing-label source YAML class mapping differs")
    for group, root in (("source_sha256", raw), ("split_sha256", splits)):
        declared = manifest.get(group, {})
        expected_names = set(specification["base"]["raw_files"]) if group == "source_sha256" else {"train.txt", "val.txt", "test.txt", "excluded_buffer.txt"}
        require(set(declared) == expected_names and all((root / name).is_file() and digest(root / name) == value for name, value in declared.items()),
                "Missing-label source guard has untrusted raw/split hashes")
    module = Path(config["research_root"]) / "cableinspect_geometry.py"
    require(manifest.get("geometry_module_sha256") == digest(module) == prepared["source_dependencies"]["production_geometry"]["sha256"],
            "Missing-label source geometry module is untrusted")
    source = case["source"]
    categories = [{"id": int(key), "name": value} for key, value in specification["base"]["categories"].items()]
    counts = {}
    for index, image in enumerate(specification["base"]["images"], 1):
        document = read(raw / f"cable_{index}.json")
        active = image["split"] == source["annotation_split"]
        annotations = [{"id": source["annotation_id"], "image_id": image["image_id"], "category_id": source["category_id"],
                        "bbox": source["bbox"], "attributes": {"rotation": source["rotation"], "gradation": source["gradation"],
                        "anomaly_id": source["anomaly_id"]}}] if active else []
        expected = {"categories": categories, "images": [{"id": image["image_id"], "file_name": image["file_name"],
                    "width": source["dimensions"][0], "height": source["dimensions"][1]}], "annotations": annotations}
        require(document == expected and (splits / (image["split"] + ".txt")).read_text(encoding="utf-8").splitlines()
                == [str(raw / image["file_name"])], "Missing-label source identity, annotation or split membership differs from frozen literals")
        counts[image["split"]] = {"images": 1, "normal_images": int(not active), "abnormal_images": int(active),
                  "annotations": int(active), "source_annotations": int(active),
                  "nonzero_rotation_attributes": int(active and source["rotation"] != 0),
                  "rotated_annotations": int(active and source["rotation"] % 360 != 0),
                  "clipped_annotations": int(active and case["golden"]["bbox_clipped"]), "invalid_annotations": 0}
    require((splits / "excluded_buffer.txt").read_bytes() == b"", "Missing-label guard changed exclusion membership")
    require(manifest.get("counts") == counts and manifest.get("totals")
            == {key: sum(row[key] for row in counts.values()) for key in next(iter(counts.values()))}
            and manifest.get("raw_images") == 3 and manifest.get("raw_annotations") == 1
            and manifest.get("excluded_buffer_images") == 0, "Missing-label source manifest counts differ from raw identities")
    return True


def domain_evidence(entry, prepared, workflow_directory):
    domain = entry.get("domain")
    require(isinstance(domain, dict) and domain.get("kind") == "bounded_research_domain_evidence"
            and domain.get("case_id") == prepared["case_id"] and domain.get("synthetic_only") is True
            and domain.get("source_snapshot") == prepared["source_snapshot"]
            and domain.get("source_dependencies") == prepared["source_dependencies"]
            and domain.get("inference_performed") is False and domain.get("model_used") is False,
            "Domain evidence scope or original case binding differs")
    task = inside(domain["task_dir"], [workflow_directory], file=False)
    require(task.name == domain.get("task_id") and Path(domain["configuration"]["output_root"]).resolve() / task.name == task,
            "Domain task identity/configuration differs")
    kind = entry["kind"]
    expected_tool = "repair_label_copy" if kind == "repair" else "verify_label_geometry"
    require(domain.get("tool") == expected_tool and entry.get("origin") == "new_execution", "Domain tool or origin differs")
    actual = {path.relative_to(task).as_posix(): path for path in task.rglob("*") if path.is_file()}
    files = domain.get("task_files", [])
    require(len(files) == len(actual) and {row.get("relative_path") for row in files} == set(actual), "Domain full artifact population differs")
    for row in files:
        require(record(row, [task]) == actual[row["relative_path"]], "Domain task file path differs")
    for row in domain.get("artifacts", {}).values():
        record(row, [task])
    original = prepared["configuration"]
    if kind != "copy_geometry":
        require(all(domain["configuration"].get(key) == original[key] for key in ("research_root", "dataset_root", "raw_root", "split_dir", "weights_path")),
                "Original geometry/repair uses another input")
    source = domain.get("input_before_after", {})
    require(source.get("unchanged") is True and source.get("before") == source.get("after") == prepared["source_files"]
            and source.get("before_sha256") == source.get("after_sha256") == hashlib.sha256(canonical(source["before"])).hexdigest(),
            "Domain input before/after binding differs")
    execution, semantic = domain.get("execution_status"), domain.get("semantic_status")
    acceptance = domain.get("acceptance_checks", {})
    require(isinstance(acceptance, dict) and acceptance.get("original_input_bytes_unchanged") is True
            and acceptance.get("source_snapshot_unchanged") is True
            and acceptance.get("saved_completion_chain_verified") is (execution == "completed"),
            "Domain acceptance checks contradict immutable inputs or completion status")
    if execution == "failed":
        require(kind == "geometry" and semantic == "execution_failed" and (task / "failure.json").is_file()
                and not (task / "completion.json").exists(), "Failed domain evidence claims completion or wrong semantic status")
        failure = read(task / "failure.json")
        require(failure.get("status") == "failed" and failure.get("tool") == expected_tool
                and failure.get("task_id") == task.name and bool(failure.get("errors")), "Domain execution failure has no failure proof")
        result = failure
    else:
        require(execution == "completed" and domain.get("task_chain_verified") is True, "Domain execution chain is incomplete")
        result = repair(task) if kind == "repair" else geometry(task, semantic)
    require(result.get("configuration") == domain.get("configuration") and result.get("summary") == domain.get("summary"),
            "Domain returned summary contradicts current published result")
    require(entry.get("summary") == result.get("summary"), "Evidence claim summary differs from independently checked domain result")
    if kind == "repair":
        require(all(value is True for value in acceptance.values()), "Repair domain acceptance checks did not all pass")
        specification = read(PROJECT_ROOT / "fixtures" / "labelguard_cases.json")
        case = next(item for item in specification["cases"] if item["id"] == prepared["case_id"])
        changes = lines(task / "repair_changes.jsonl")
        require(sorted(row["relative_path"] for row in changes) == sorted(case["expected"]["changed_files"]),
                "Repair changed paths differ from exact frozen case scope")
        labels, metadata = frozen_literal_answers(case)
        copy = task / "dataset_copy"
        require(all((copy / name).read_bytes() == value.encode("utf-8") for name, value in labels.items())
                and all(read(copy / name) == value for name, value in metadata.items()),
                "Repair copy does not match independent frozen literal answers")
    cost = domain.get("cost", {})
    expected_calls = 3 if kind == "repair" else 1
    require(type(cost.get("domain_tool_calls")) is int and cost["domain_tool_calls"] == expected_calls
            and cost.get("geometry_verification_calls") == (2 if kind == "repair" else 1)
            and cost.get("repair_calls") == int(kind == "repair") and cost.get("gpu_seconds") == 0
            and cost.get("model_requests") == 0 and cost.get("inference_calls") == 0, "Domain actual cost differs from executed tool chain")
    return {"kind": kind, "status": semantic, "cost": expected_calls, "task": task, "configuration": domain["configuration"],
            "summary": entry["summary"], "domain": domain, "prepared": prepared}


SCIENCE_REGISTRATION_SHA256 = "64d0291afc70d683a5e0c0572a2fd5edcdb47b846d06b4e6516f13c4b814af1a"


def overlap(first, second):
    intersection = max(0, min(first[2], second[2]) - max(first[0], second[0])) * max(0, min(first[3], second[3]) - max(first[1], second[1]))
    union = (first[2] - first[0]) * (first[3] - first[1]) + (second[2] - second[0]) * (second[3] - second[1]) - intersection
    return intersection / union if union > 0 else 0


def independently_count_saved_small(directory):
    statistics, paired = {}, None
    for size in (640, 960):
        rows = lines(directory / f"predictions_{size}.jsonl")
        require(len(rows) == 640 and len({row["image_id"] for row in rows}) == 640, "Saved scientific prediction population differs")
        identities = [(row["image_id"], row["width"], row["height"], row["ground_truth"]) for row in rows]
        require(paired is None or identities == paired, "Paired resolution GT identities differ")
        paired = identities
        small = {name: {"gt": 0, "tp": 0, "fn": 0} for name in ("plan_area_ratio_lt_0_005", "implemented_area_lt_1024_px2")}
        totals = {"gt": 0, "tp": 0, "fp": 0, "fn": 0}
        for row in rows:
            require(row.get("split") == "val" and row.get("eval_imgsz") == size, "Saved scientific input scope differs")
            truth, matched = row["ground_truth"], set()
            kept = sorted([(index, box) for index, box in enumerate(row["predictions"]) if box["confidence"] >= .25],
                          key=lambda item: (-item[1]["confidence"], item[0]))
            for _, prediction in kept:
                candidates = [(overlap(prediction["xyxy"], box["xyxy"]), index) for index, box in enumerate(truth)
                              if index not in matched and box["class_id"] == prediction["class_id"]]
                candidates = [(iou, index) for iou, index in candidates if iou >= .5]
                if candidates:
                    matched.add(min(candidates, key=lambda item: (-item[0], item[1]))[1])
            totals["gt"] += len(truth)
            totals["tp"] += len(matched)
            totals["fp"] += len(kept) - len(matched)
            totals["fn"] += len(truth) - len(matched)
            for index, box in enumerate(truth):
                left, top, right, bottom = box["xyxy"]
                area = (right - left) * (bottom - top)
                memberships = {"plan_area_ratio_lt_0_005": area / (row["width"] * row["height"]) < .005,
                               "implemented_area_lt_1024_px2": area < 1024}
                for name, selected in memberships.items():
                    if selected:
                        small[name]["gt"] += 1
                        small[name]["tp"] += int(index in matched)
                        small[name]["fn"] += int(index not in matched)
        for bucket in [totals, *small.values()]:
            bucket["recall"] = bucket["tp"] / bucket["gt"] if bucket["gt"] else None
        statistics[str(size)] = {"overall": totals, "scale_definitions": small}
    return statistics


def science_evidence(entry, registry_paths):
    require(entry.get("origin") == "historical_reuse", "Saved science falsely claims fresh detector execution")
    registration_path = PROJECT_ROOT / "fixtures" / "research_science_sources_v1.json"
    require(registration_path in registry_paths and digest(registration_path) == SCIENCE_REGISTRATION_SHA256,
            "Scientific registration is absent or changed")
    registration = read(registration_path)
    require(registration.get("selection_data") == "validation_only" and registration.get("new_inference_allowed") is False
            and registration.get("new_training_allowed") is False and registration.get("test_inference_allowed") is False
            and registration.get("all_historical_inputs_rehashed") is False, "Scientific source scope differs")
    expected_files = {}
    def append(path, role):
        path = Path(path).resolve()
        require(path.is_file(), "Scientific source file is missing")
        expected_files[role] = {"role": role, "path": str(path), "sha256": digest(path), "size_bytes": path.stat().st_size}
    append(registration_path, "scientific_source_registration")
    sources = {}
    for source in registration["sources"]:
        directory = (PROJECT_ROOT / source["relative_directory"]).resolve()
        require(directory.is_relative_to(PROJECT_ROOT / "outputs")
                and digest(directory / "completion.json") == source["completion_sha256"]
                and digest(directory / "artifact_manifest.json") == source["manifest_sha256"], "Frozen scientific source changed")
        marker, manifest = read(directory / "completion.json"), read(directory / "artifact_manifest.json")
        require(marker.get("status") in {"passed", "completed"}
                and marker.get("manifest_sha256", marker.get("artifact_manifest_sha256")) == source["manifest_sha256"],
                "Scientific source completion is not sealed")
        records = manifest.get("files", [])
        require(len(records) == len(source["required_artifacts"]) and {row.get("name") for row in records} == set(source["required_artifacts"]),
                "Scientific sealed artifact membership differs")
        append(directory / "completion.json", source["kind"] + "/completion")
        append(directory / "artifact_manifest.json", source["kind"] + "/manifest")
        for row in records:
            target = directory / row["name"]
            require(target.resolve().parent == directory and digest(target) == row["sha256"] and target.stat().st_size == row["size_bytes"],
                    "Scientific sealed artifact bytes differ")
            append(target, source["kind"] + "/" + row["name"])
        sources[source["kind"]] = directory
    reviewer = PROJECT_ROOT / registration["scale_reviewer"]["relative_path"]
    require(digest(reviewer) == registration["scale_reviewer"]["sha256"], "Frozen independent scale reviewer changed")
    append(reviewer, "independent_scale_reader")
    scale = read(sources["scale"] / "scale_alignment.json")
    require(scale.get("status") == "passed" and scale.get("posthoc_no_new_inference") is True
            and scale.get("new_detector_predictions") == 0 and scale.get("new_model_requests") == 0
            and scale.get("training_resolution_effect_established") is False, "Scale appendix scope is overstated")
    for binding in scale["source_chain"]["bindings"]:
        require(digest(binding["path"]) == binding["sha256"], "Current scale source hash differs")
        append(binding["path"], "scale_source/" + binding["role"])
    comparison_directory = PROJECT_ROOT / "outputs" / scale["source_task_id"]
    statistics = independently_count_saved_small(comparison_directory)
    require(statistics == scale["statistics"]["results"], "Independent matching and scale definitions do not reproduce")
    failed = PROJECT_ROOT / registration["original_failed_computation"]["relative_directory"]
    require(not (failed / "completion.json").exists() and digest(failed / "failure.json") == registration["original_failed_computation"]["failure_sha256"],
            "Original failed detector execution was changed or backfilled")
    append(failed / "failure.json", "original_failed_computation")
    rows = entry.get("files", [])
    require(len(rows) == len(expected_files) and {row.get("role") for row in rows} == set(expected_files)
            and all(row == expected_files[row["role"]] for row in rows), "Scientific evidence omits, duplicates or changes registered source bindings")
    decision = read(sources["diagnosis"] / "decision.json")
    sliced = read(sources["slicing"] / "recovery_result.json")["summary"]
    independent = read(sources["slicing"] / "independent_verification.json")
    require(independent.get("status") == "passed" and independent.get("passed_checks") == independent.get("total_checks") == 99
            and independent.get("scientific_status") == "stop" and independent.get("original_business_status") == "failed"
            and independent.get("original_pipeline_acceptance_passed") is False
            and sliced["candidate_status"] == "stop" and sliced["failed_gates"] == independent.get("failed_scientific_gates"),
            "Historical science candidate stop is not independently supported")
    def definition(key, identity):
        a, b = [statistics[str(size)]["scale_definitions"][key] for size in (640, 960)]
        return {"definition_id": identity, "gt": a["gt"], "tp_640": a["tp"], "tp_960": b["tp"],
                "recall_640": a["recall"], "recall_960": b["recall"]}
    baseline, larger = [read(comparison_directory / f"metrics_{size}.json") for size in (640, 960)]
    expected = {"posthoc_no_new_inference": True, "analysis_executed_now": True, "original_all_inputs_rehashed": False,
                "scope": "sealed_validation_evidence_reuse", "relative_small": definition("plan_area_ratio_lt_0_005", "area_ratio_lt_0_005"),
                "tiny_small": definition("implemented_area_lt_1024_px2", "area_lt_1024_px2"),
                "resolution": {"map50_640": baseline["mAP50"], "map50_960": larger["mAP50"],
                    "fp_640": baseline["operating_point"]["fp"], "fp_960": larger["operating_point"]["fp"],
                    "normal_fp_640": baseline["operating_point"]["normal_images_with_false_positives"],
                    "normal_fp_960": larger["operating_point"]["normal_images_with_false_positives"], "status": "local_gain_with_overall_cost"},
                "diagnosis": {"threshold_status": decision["selection"]["status"], "next_branch": decision["recommendations"]["next_branch"]},
                "slicing": {"candidate_status": sliced["candidate_status"], "failed_gates": sliced["failed_gates"],
                    "map50_baseline": sliced["baseline"]["mAP50"], "map50_sliced": sliced["sliced"]["mAP50"],
                    "fp_baseline": sliced["baseline"]["fp"], "fp_sliced": sliced["sliced"]["fp"]}}
    require(entry.get("summary") == expected, "Science report summary mixes definitions, scope or saved metrics")
    return {"kind": "science", "status": "stop", "cost": 1, "summary": expected}


def typed_equal(first, second):
    if type(first) is not type(second):
        return False
    if isinstance(first, dict):
        return first.keys() == second.keys() and all(typed_equal(first[key], second[key]) for key in first)
    if isinstance(first, list):
        return len(first) == len(second) and all(typed_equal(a, b) for a, b in zip(first, second))
    return first == second


def workflow_events(directory, valid_ids, budget):
    events = lines(directory / "events.jsonl")
    require(bool(events), "Workflow events are empty")
    allowed = {None: {"planned"}, "planned": {"running", "stopped", "failed"},
               "running": {"awaiting_evidence", "stopped", "failed"},
               "awaiting_evidence": {"verified", "stopped", "failed"},
               "verified": {"running", "stopped", "failed"}, "stopped": set(), "failed": set()}
    state, elapsed, used = None, 0, 0
    referenced = set()
    for index, event in enumerate(events, 1):
        require(type(event.get("seq")) is int and event["seq"] == index and event.get("from_state") == state
                and event.get("state") in allowed.get(state, set()), "Workflow state sequence is illegal or rewritten")
        state = event["state"]
        require(isinstance(event.get("action"), str) and bool(event["action"])
                and isinstance(event.get("reason"), str) and bool(event["reason"]), "Workflow transition has no explicit action/reason")
        ids = event.get("evidence_ids")
        require(isinstance(ids, list) and len(ids) == len(set(ids)) and set(ids).issubset(valid_ids),
                "Workflow transition cites unverified or duplicate evidence")
        require(finite(event.get("elapsed_seconds")) and elapsed <= event["elapsed_seconds"] <= budget["elapsed"] + 1e-7
                and type(event.get("budget_used")) is int and used <= event["budget_used"] <= budget["used"],
                "Workflow event elapsed/cumulative budget regresses or exceeds ledger")
        elapsed, used = event["elapsed_seconds"], event["budget_used"]
        referenced.update(ids)
    require(events[0]["action"] == "plan" and state == "stopped" and used == budget["used"],
            "Workflow did not retain planned start and evidence-driven stopped terminal state")
    require(valid_ids.issubset(referenced), "Executed evidence never influences a recorded transition")
    return events


def branch_and_result(directory, request, case, evidence, budget):
    result, plan = read(directory / "result.json"), read(directory / "plan.json")
    require(result.get("schema_version") == 1 and result.get("workflow_id") == directory.name
            and result.get("status") == "completed" and result.get("case_id") == request["case_id"]
            and result.get("synthetic_only") is True and type(result.get("new_inference_calls")) is int
            and result["new_inference_calls"] == 0 and type(result.get("new_model_requests")) is int and result["new_model_requests"] == 0
            and result.get("domain_invocations") == budget["used"] and result.get("actual_tool_path") == budget["actions"],
            "Result scope, execution count or tool path contradicts durable ledger")
    full_paths = {"normal": ["verify_label_geometry", "read_scientific_evidence"],
                  "repairable": ["verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence"],
                  "refused": ["verify_label_geometry"]}
    full = full_paths[case["group"]]
    actual = budget["actions"]
    require(actual == full[:len(actual)], "Input class did not determine permitted tool order")
    kinds = {"verify_label_geometry": "geometry", "repair_label_copy": "repair", "verify_copy": "copy_geometry", "read_scientific_evidence": "science"}
    require([row["kind"] for row in evidence] == [kinds[action] for action in actual]
            and [row["cost"] for row in evidence] == budget["costs"], "Evidence/tool sequence or actual billed cost differs")
    if len(evidence) > 1:
        if case["group"] == "normal":
            require(evidence[0]["status"] == "passed", "Failed normal geometry incorrectly continued to research evidence")
        else:
            require(evidence[0]["status"] in {"failed", "execution_failed"} and evidence[1]["status"] == "passed",
                    "Repair was not triggered by a verified discrepancy or did not pass")
            if evidence[0]["status"] == "execution_failed":
                missing_label_guard(evidence[0]["domain"], evidence[0]["prepared"])
    if len(evidence) > 2:
        require(evidence[2]["status"] == "passed"
                and Path(evidence[2]["configuration"]["dataset_root"]).resolve() == evidence[1]["task"] / "dataset_copy",
                "Explicit copy recheck did not use the repaired copy or did not pass")
    ids = {row["evidence_id"] for row in read(directory / "evidence.json")["entries"]}
    require(isinstance(plan.get("reason"), str) and bool(plan["reason"]) and isinstance(plan.get("evidence_ids"), list)
            and set(plan["evidence_ids"]).issubset(ids), "Final plan has no supported reason/evidence")
    hypotheses = plan.get("hypotheses")
    require(isinstance(hypotheses, list), "Final plan has no explicit hypothesis ledger")
    require(len({row.get("hypothesis_id") for row in hypotheses}) == len(hypotheses), "Duplicate hypothesis identities")
    for hypothesis in hypotheses:
        require(isinstance(hypothesis.get("hypothesis_id"), str) and bool(hypothesis["hypothesis_id"])
                and isinstance(hypothesis.get("status"), str) and isinstance(hypothesis.get("reason"), str)
                and bool(hypothesis["reason"]) and isinstance(hypothesis.get("evidence_ids"), list)
                and set(hypothesis["evidence_ids"]).issubset(ids), "Hypothesis update is unsupported")
    next_action = plan.get("next_action")
    if next_action == "stop_no_registered_candidate":
        require(result.get("research_status") == "stopped" and actual == full and evidence and evidence[-1]["kind"] == "science"
                and evidence[-1]["summary"]["slicing"]["candidate_status"] == "stop"
                and bool(evidence[-1]["summary"]["slicing"]["failed_gates"]), "Scientific candidate stop did not change final next action")
    elif next_action == "stop_untrusted_source":
        require(result.get("research_status") == "refused" and case["group"] == "refused" and actual == full
                and evidence[0]["status"] in {"failed", "execution_failed"}, "Untrusted-source refusal is unsupported")
    elif next_action == "stop_budget":
        require(result.get("research_status") == "insufficient_evidence" and len(actual) < len(full)
                and request["budget"]["domain_invocations"] - budget["used"] < ACTION_COSTS[full[len(actual)]],
                "Budget exhaustion stop had sufficient remaining capacity or completed all evidence")
    elif next_action == "stop_invalid_evidence":
        require(result.get("research_status") == "insufficient_evidence" and bool(result.get("error")),
                "Invalid-evidence stop has no explicit error proof")
    else:
        raise ValueError("Final plan is unregistered or continues a stopped candidate")
    return result, plan


def report_claims(directory, request, entries, result, plan):
    claims = read(directory / "claims.json").get("claims")
    require(isinstance(claims, list) and result.get("claims_count") == len(claims)
            and len({row.get("claim_id") for row in claims}) == len(claims), "Claim inventory count or identities differ")
    sources = {row["evidence_id"]: row["summary"] for row in entries}
    report = ("# 受限研究流程验收报告\n\n"
              "范围：隔离人工LabelGuard输入与已封存验证集研究证据；本次不执行检测推理、训练或模型请求。\n"
              "两种数据来源分别核验，不将历史科学结果当作人工案例上的检测表现。\n\n"
              f"workflow_id: {result['workflow_id']}\ncase_id: {request['case_id']}\nresearch_status: {result['research_status']}\n"
              f"next_action: {plan['next_action']}\n\n")
    for claim in claims:
        require(set(claim) == {"claim_id", "evidence_id", "field", "value"}
                and isinstance(claim["claim_id"], str) and bool(re.fullmatch(r"[A-Za-z0-9_-]+", claim["claim_id"]))
                and claim["evidence_id"] in sources and isinstance(claim["field"], str)
                and bool(re.fullmatch(r"[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*", claim["field"])), "Claim source/path/schema is invalid")
        require(claim["field"].startswith("summary."), "Claim field must explicitly identify the evidence summary")
        value = {"summary": sources[claim["evidence_id"]]}
        for key in claim["field"].split("."):
            require(isinstance(value, dict) and key in value, "Claim field is absent from independently verified evidence")
            value = value[key]
        require(typed_equal(claim["value"], value), "Claim value contradicts independently verified evidence")
        report += f"- {claim['claim_id']}: {json.dumps(claim['value'], ensure_ascii=False, sort_keys=True)} [evidence={claim['evidence_id']}; field={claim['field']}]\n"
    require((directory / "report.md").read_text(encoding="utf-8") == report, "Report contains unsupported text, numbers or scope claims")
    return len(claims)


def published_workflow(directory, request, budget, *, prepublication):
    if prepublication:
        require(not (directory / "completion.json").exists() and not (directory / "completion_rejected.json").exists()
                and not (directory / "failure.json").exists(), "Prepublication workflow has already published or failed")
        return
    require(not (directory / "failure.json").exists() and not (directory / "completion_rejected.json").exists(),
            "Published workflow also has failure/rejected publication")
    independent = read(directory / "independent_verification.json")
    require(independent.get("status") == "passed" and independent.get("workflow_id") == directory.name
            and independent.get("prepublication") is True and independent.get("model_used") is False,
            "Published workflow lacks a passed independent prepublication check")
    manifest, marker = read(directory / "artifact_manifest.json"), read(directory / "completion.json")
    require(manifest.get("workflow_id") == directory.name and manifest.get("status") == "completed"
            and marker.get("workflow_id") == directory.name and marker.get("status") == "completed"
            and marker.get("state") == "completed", "Workflow publication identity or engineering state differs")
    rows = manifest.get("files", [])
    require(isinstance(rows, list) and len(rows) == 14 and {row.get("name") for row in rows} == TOP_FILES,
            "Workflow publication lacks exact 14 sealed artifacts")
    for row in rows:
        path = record(row, [directory])
        require(path.parent == directory and row.get("role") == path.name, "Workflow artifact path/role differs")
    require(marker.get("artifact_manifest_sha256") == digest(directory / "artifact_manifest.json")
            and marker.get("artifacts_sha256") == {row["name"]: row["sha256"] for row in rows}
            and marker.get("independent_verification_sha256") == digest(directory / "independent_verification.json"),
            "Workflow completion does not bind actual sealed artifacts and independent report")
    require(finite(marker.get("completed_epoch")) and marker["completed_epoch"] < budget["deadline_epoch"]
            and marker.get("original_deadline_epoch") == budget["deadline_epoch"]
            and marker.get("domain_invocations") == budget["used"]
            and finite(marker.get("elapsed_seconds")) and marker["elapsed_seconds"] >= budget["elapsed"],
            "Workflow marker exceeds or resets original publication budget")
    require((directory / "completion.json").stat().st_mtime <= budget["deadline_epoch"]
            and (directory / "completion.json").stat().st_mtime_ns >= max((directory / name).stat().st_mtime_ns for name in TOP_FILES | {"artifact_manifest.json"}),
            "Completion was late or was not written after all sealed artifacts")


def verify(directory, prepublication=False):
    """Return a read-only audit; a semantic stop can be a valid engineering result."""
    directory = Path(directory).resolve()
    checks, errors = {}, []
    workflow_id, summaries = directory.name, {}
    active = "strict_request_and_frozen_protocol"
    try:
        require(directory.is_relative_to(PROJECT_ROOT) and directory.is_dir(), "Workflow directory escapes project workspace")
        request, protocol, case = request_and_protocol(directory)
        checks[active] = True
        active = "original_cumulative_budget_ledger_replayed"
        budget = budget_replay(directory, request, prepublication=prepublication)
        checks[active] = True
        active = "artificial_input_and_execution_sources_unchanged"
        prepared, frozen, registry_paths = case_and_snapshots(directory, request, case)
        checks[active] = True
        active = "evidence_inventory_identity_and_unique_ids"
        document = read(directory / "evidence.json")
        entries = document.get("entries")
        require(document.get("schema_version") == 1 and document.get("workflow_id") == workflow_id
                and isinstance(entries, list) and len({row.get("evidence_id") for row in entries}) == len(entries),
                "Evidence inventory identity, schema or uniqueness differs")
        require(all(isinstance(row.get("evidence_id"), str) and re.fullmatch(r"[A-Za-z0-9_:-]+", row["evidence_id"])
                    and row.get("kind") in {"geometry", "repair", "copy_geometry", "science"}
                    and isinstance(row.get("summary"), dict) and isinstance(row.get("files"), list) and bool(row["files"])
                    for row in entries), "Evidence schema or record kinds differ")
        checks[active] = True
        verified = []
        for entry in entries:
            active = "independent_evidence_" + entry["evidence_id"]
            if entry["kind"] == "science":
                proof = science_evidence(entry, registry_paths)
            else:
                for row in entry["files"]:
                    record(row, [directory])
                proof = domain_evidence(entry, prepared, directory)
            verified.append(proof)
            checks[active] = True
        active = "legal_state_transitions_and_evidence_references"
        workflow_events(directory, {row["evidence_id"] for row in entries}, budget)
        checks[active] = True
        active = "input_class_and_evidence_change_actual_tool_path_and_stop"
        result, plan = branch_and_result(directory, request, case, verified, budget)
        checks[active] = True
        active = "every_report_claim_has_exact_verified_source"
        count = report_claims(directory, request, entries, result, plan)
        checks[active] = True
        active = "independent_verification_before_completion_last"
        published_workflow(directory, request, budget, prepublication=prepublication)
        checks[active] = True
        active = "inputs_and_execution_sources_still_unchanged_after_review"
        case_and_snapshots(directory, request, case)
        checks[active] = True
        summaries = {"research_status": result["research_status"], "next_action": plan["next_action"],
                     "actual_tool_path": budget["actions"], "domain_invocations": budget["used"], "claims_checked": count,
                     "evidence_entries_checked": len(entries), "synthetic_only": True}
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
    return {"schema_version": 1, "kind": "independent_bounded_research_workflow_verification_v1", "workflow_id": workflow_id,
            "status": "passed" if checks and all(checks.values()) else "failed", "prepublication": bool(prepublication),
            "model_used": False, "new_detector_predictions": 0, "new_model_requests": 0, "independent_of_controller": True,
            "checked_at": datetime.now(timezone.utc).isoformat(), "checks": checks, "passed_checks": sum(checks.values()),
            "total_checks": len(checks), "summary": summaries, "errors": errors,
            "limitations": ["Input cases are artificial and source-bound; saved validation science is a separate historical population.",
                            "No detector, model, training or GPU execution; saved small-defect matching is independently recalculated.",
                            "Historical sliced 99-check artifacts are hash-bound; the full historical input population is not rehashed here."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--prepublication", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    directory = args.directory.resolve()
    if not args.prepublication and output.is_relative_to(directory):
        parser.error("Postpublication verification output must be outside the completed workflow")
    if output.exists():
        parser.error("Verification output already exists; evidence cannot be overwritten")
    report = verify(directory, prepublication=args.prepublication)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "passed_checks": report["passed_checks"], "total_checks": report["total_checks"],
                      "workflow_id": report["workflow_id"], "errors": report["errors"], "output": str(output)}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
