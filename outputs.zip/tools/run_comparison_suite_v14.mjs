
import {waitOriginalSettlement} from './comparison_settlement_v1.mjs';
// One preregistered rotated pilot. No model-selected paths, cases or budgets.
import {readFile,writeFile,mkdir,readdir} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {exportSession} from '../../agnes-harness/packages/cli/src/commands/export.ts';
import {webClient,origin,finishEventReading} from './agh_ws_client.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),stage=process.argv[2];
if(!['diagnostic','pilot','formal'].includes(stage))throw new Error('Stage argument required');
const out=join(root,'outputs/comparison-suite-v14-'+stage);
const modelProtocolBytes=await readFile(join(out,'model_protocol.json'));
const publicProtocol=JSON.parse(modelProtocolBytes);
const protocol=JSON.parse(await readFile(join(out,'protocol.json'),'utf8'));
const config=publicProtocol.server_config,lockPin=publicProtocol.source_lock;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const stable=value=>JSON.stringify(value,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
const catalogContract=tools=>tools.map(({name,description,inputSchema})=>({name,description,inputSchema}));
if(sha(await readFile(join(out,'protocol.json')))!==publicProtocol.protocol_sha256||sha(await readFile(lockPin.path))!==lockPin.sha256)throw new Error('Preregistered source/conditions differ');
for(const row of JSON.parse(await readFile(lockPin.path,'utf8')).files)if(sha(await readFile(row.path))!==row.sha256)throw new Error('Changed pinned implementation');
const scopeCandidatePath=join(out,'scope_candidate.json'),scopeActivationPath=join(out,'scope_activation.json');
const scopeCandidateBytes=await readFile(scopeCandidatePath),scopeActivationBytes=await readFile(scopeActivationPath);
const scopeCandidate=JSON.parse(scopeCandidateBytes),scopeActivation=JSON.parse(scopeActivationBytes);
if(scopeActivation.complete!==true||scopeActivation.after?.actual!=='running'||scopeCandidate.protocol_sha256!==sha(modelProtocolBytes))throw new Error('Comparison guard activation evidence differs');
for(const member of scopeCandidate.files)if(sha(await readFile(member.path))!==member.sha256)throw new Error('Generated guard source changed');
const runtimeVersion=JSON.parse(await readFile(publicProtocol.runtime_version.path,'utf8'));
if(sha(await readFile(publicProtocol.runtime_version.path))!==publicProtocol.runtime_version.sha256||runtimeVersion.status!=='passed_local_repair'||runtimeVersion.agh_core_modified!==true)throw new Error('Pinned modified runtime version differs');
async function checkRuntime(){for(const row of runtimeVersion.runtime_files)if(sha(await readFile(row.path))!==row.sha256||sha(await readFile(row.archive))!==row.sha256)throw new Error('Modified runtime bytes changed');return runtimeVersion.runtime_files.map(({path,sha256})=>({path,sha256}));}
const runtimeBefore=await checkRuntime();
async function captureRuntime(){
 const result=await run('C:/Users/han/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe',['-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',join(root,'tools/capture_comparison_runtime_v14.ps1'),'-Manifest',publicProtocol.runtime_version.path],{cwd:root,windowsHide:true,timeout:25000});
 return JSON.parse(result.stdout.replace(/^\uFEFF/,''));
}
const run=promisify(execFile),python='E:/Anaconda_envs/envs/MMIOC_env/python.exe';
const environment={...process.env,DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH:lockPin.path,DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256:lockPin.sha256};
async function hostArm(handle){const result=await run(python,['-X','utf8','-B','-m','defect_researcher.comparison_case_runtime_v14','--config',config,'arm','--trial-handle',handle],{cwd:root,env:environment,windowsHide:true,timeout:15000});return JSON.parse(result.stdout);}
const runtimeRoot=JSON.parse(await readFile(config,'utf8')).output_root;
const cap={diagnostic:14,pilot:42,formal:168}[stage];
if(publicProtocol.stage!==stage||publicProtocol.phase_model_budget.total_cap!==cap||publicProtocol.selection_sha256!==sha(stable(publicProtocol.selection)))throw new Error('Frozen stage allocation differs');
const selected=protocol.trials.filter(t=>publicProtocol.selection.trial_handles.includes(t.trial_handle));
if(selected.length!==publicProtocol.selection.selected_trial_count||stable(selected.map(t=>t.trial_handle))!==stable(publicProtocol.selection.trial_handles))throw new Error('Frozen full selection differs');
const suite={schema_version:1,status:'running',stage,agh_core_modified:true,runtime_before:runtimeBefore,protocol_sha256:publicProtocol.protocol_sha256,model_requests_cap_total:cap,phase_model_requests_cap_total:cap,prior_closed_request_slots:0,request_slots_debited_before:0,historical_prior_slots_debited:46,historical_prior_phase_cap:48,legacy_token_usage_closed:true,historical_token_usage_closed:false,model_requests_observed:0,model_requests_actual:0,planned_trials:protocol.trials.length,selected_trials:selected.length,trials:[],new_detector_calls:0,gpu_seconds:0};
const suitePath=join(out,'run_result.json');await writeFile(suitePath,JSON.stringify(suite,null,2)+'\n',{flag:'wx'});
const saveSuite=()=>writeFile(suitePath,JSON.stringify(suite,null,2)+'\n');
const parse=result=>{const blocks=result.content?.filter(x=>x.type==='text');if(blocks?.length!==1)throw new Error('Expected one JSON action result');return JSON.parse(blocks[0].text);};
function claim(e,name,field,value){return {name,field,value,evidence_id:e.evidence_id};}
function candidate(handle,outcome,input,science){
 const claims=[claim(input,'input_verdict',input.semantic_status!==undefined?'semantic_status':'summary.declared_source_hashes_match',input.semantic_status??input.summary.declared_source_hashes_match)];
 if(science)claims.push(claim(science,'candidate_status','summary.slicing.candidate_status',science.summary.slicing.candidate_status));
 return {schema_version:1,trial_handle:handle,outcome,target:{clean:'input',repaired:'copy',refused:'none'}[outcome],evidence_ids:[input.evidence_id,...(science?[science.evidence_id]:[])],claims,
  scope:{synthetic_only:true,historical_evidence_reused:Boolean(science),new_detector_calls:0,gpu_seconds:0}};
}
async function scripted(trial){
 const directory=join(out,'script_runs',trial.trial_handle);await mkdir(directory,{recursive:true});
 const modules=join(root,'../agnes-harness/node_modules/.pnpm'),name=(await readdir(modules)).find(x=>x.startsWith('@modelcontextprotocol+sdk@1.25.2'));
 const sdk=join(modules,name,'node_modules/@modelcontextprotocol/sdk/dist/esm');
 const {Client}=await import(pathToFileURL(join(sdk,'client/index.js')).href),{StdioClientTransport}=await import(pathToFileURL(join(sdk,'client/stdio.js')).href);
 const client=new Client({name:'comparison-fixed-checklist-v1',version:'1'},{capabilities:{}});
 const transport=new StdioClientTransport({command:python,args:['-B',join(root,'run_comparison_mcp_v14.py'),'--config',config,'--source-lock',lockPin.path,'--expected-lock-sha256',lockPin.sha256],cwd:root,stderr:'pipe'});
 const record={schema_version:1,status:'starting',trial_handle:trial.trial_handle,route:'official_MCP_SDK_stdio',model_requests:0,agh_approval_count:null,host_authorizations:[],calls:[],results:[],source_lock:lockPin,protocol_path:join(out,'protocol.json'),protocol_sha256:publicProtocol.protocol_sha256,model_protocol_path:join(out,'model_protocol.json'),model_protocol_sha256:sha(modelProtocolBytes),trial_directory:join(runtimeRoot,'trials',trial.trial_handle)};
 const path=join(directory,'run_result.json');await writeFile(path,JSON.stringify(record,null,2)+'\n',{flag:'wx'});const save=()=>writeFile(path,JSON.stringify(record,null,2)+'\n');
 try{
  await client.connect(transport);record.tool_catalog=(await client.listTools()).tools;
  if(stable(catalogContract(record.tool_catalog))!==stable(protocol.common.tool_catalog))throw new Error('C native action catalog differs');
  record.arm=await hostArm(trial.trial_handle);record.started_epoch_ms=record.arm.started_epoch*1000;record.deadline_epoch_ms=record.arm.deadline_epoch*1000;
  record.arm_sha256=sha(await readFile(join(record.trial_directory,'arm.json')));
  async function action(action,report){
   if(Date.now()>=record.deadline_epoch_ms||record.calls.length>=8)throw new Error('Original C budget expired');
   const args={trial_handle:trial.trial_handle,action,...(report?{report}:{})};
   record.host_authorizations.push({decision:'authorized_scope_once',action,arguments_sha256:sha(stable(args))});record.calls.push({name:'execute_case_action_v1',args});await save();
   const raw=await client.callTool({name:'execute_case_action_v1',arguments:args},undefined,{timeout:Math.min(15000,record.deadline_epoch_ms-Date.now())});const payload=parse(raw);
   record.results.push({payload,is_error:raw.isError===true});await save();if(raw.isError)throw new Error('C actual action failed');return payload.evidence??payload;
  }
  await action('inspect_input');let current=await action('verify_input'),outcome='clean',science;
  if(current.semantic_status!=='passed'){
   const codes=Object.keys(current.summary.issues_by_code??{}),allowed=new Set(['declared_label_tree_hash','yolo_geometry','label_class','metadata_geometry']);
   const repairable=(codes.length&&codes.every(x=>allowed.has(x))&&codes.some(x=>x!=='declared_label_tree_hash'))||current.source_guard?.status==='passed';
   if(repairable){await action('repair_copy');current=await action('verify_copy');if(current.semantic_status!=='passed')throw new Error('C explicit copy verification failed');outcome='repaired';}
   else outcome='refused';
  }
  if(outcome!=='refused')science=await action('read_science');
  record.candidate=candidate(trial.trial_handle,outcome,current,science);record.publication=await action('publish_report',record.candidate);record.status=record.publication.status==='published'?'completed':'rejected';
 }catch(error){record.status='failed';record.failure={name:error.name,message:error.message};}
 finally{await client.close();record.finished_epoch_ms=Date.now();await save();}
 return {trial_id:trial.trial_id,trial_handle:trial.trial_handle,arm:'C',status:record.status,model_requests:0,record_path:path};
}
async function modeled(trial){
 const directory=join(out,'model_runs',trial.trial_handle);await mkdir(directory,{recursive:true});
 const processBefore=await captureRuntime();
 const record={schema_version:1,status:'starting',trial_handle:trial.trial_handle,model:'agnes-3.0-flash',route:'account-defect-researcher',
  protocol_path:join(out,'protocol.json'),protocol_sha256:publicProtocol.protocol_sha256,model_protocol_path:join(out,'model_protocol.json'),model_protocol_sha256:sha(modelProtocolBytes),
  source_lock:lockPin,scope_candidate:{path:scopeCandidatePath,sha256:sha(scopeCandidateBytes)},scope_activation:{path:scopeActivationPath,sha256:sha(scopeActivationBytes)},trial_directory:join(runtimeRoot,'trials',trial.trial_handle),workspace_root:publicProtocol.scope_policy.workspace_root,
  qualified_action_tool:publicProtocol.scope_policy.qualified_action_tool,permissions:[],calls:[],results:[],hook_events:[],scope_request_events:[],final_texts:[],model_request_count:0,request_events:[],error_events:[],cost_events:[],sdk_events:[]};
 const path=join(directory,'run_result.json');await writeFile(path,JSON.stringify(record,null,2)+'\n',{flag:'wx'});const save=()=>writeFile(path,JSON.stringify(record,null,2)+'\n');
 let client,session,iterator,reading,timer,readyTimer,readingTimer;const abort=new AbortController();
 let readyYes,readyNo;const ready=new Promise((y,n)=>{readyYes=y;readyNo=n;});
 try{
  client=await webClient();await client.workspace.add(record.workspace_root);const sessionKey=randomUUID();session=await client.session.new({cwd:record.workspace_root,sessionKey});
  record.session_id=session.id;record.session_key=session.id;record.client_request_key=sessionKey;record.session_url=origin+'/?session='+session.id;await save();
  session.onPermissionRequest(async request=>{
   const tool=request.toolCall?._meta?.['ai.agnes.harness']?.tool,args=request.toolCall?.rawInput,once=request.options.find(x=>x.kind==='allow_once');
   const allowed=request.sessionId===session.id&&tool===record.qualified_action_tool&&args?.trial_handle===trial.trial_handle&&once&&Date.now()<record.deadline_epoch_ms;
   record.permissions.push({tool,input:args,tool_call_id:request.toolCall?.toolCallId??request.toolCall?.id,decision:allowed?'allowed-once':'rejected'});await save();return allowed?{optionId:once.optionId}:{verdict:'rejected'};
  });
  iterator=session.events()[Symbol.asyncIterator]();readyTimer=setTimeout(()=>readyNo(new Error('No comparison guard readiness')),15000);
  reading=(async()=>{for(;;){const next=await iterator.next();if(next.done)break;const {_meta,...event}=next.value;
   record.sdk_events.push(event);
   if(event.type.endsWith('/scope-ready')){if(event.data.mode!=='case-comparison-v1'||stable(event.data.policy)!==stable(publicProtocol.scope_policy))throw new Error('Guard readiness differs');record.scope_ready=event;readyYes();}
   else if(event.type.endsWith('/scope-decision'))record.hook_events.push(event);
   else if(event.type.endsWith('/scope-request-decision'))record.scope_request_events.push(event);
   else if(event.type==='request/sent'){record.model_request_count++;record.request_events.push(event);}
   else if(event.type==='cost/ledger')record.cost_events.push(event);
   else if(event.type==='error'||event.type.endsWith('/error'))record.error_events.push(event);
   else if(event.type==='tool/call')record.calls.push({seq:event.seq,origin:event.origin,...event.data});
   else if(event.type==='tool/result'){const text=event.data.content?.filter(x=>x.type==='text');let payload;try{if(text?.length===1)payload=JSON.parse(text[0].text);}catch{}record.results.push({seq:event.seq,tool_use_id:event.data.toolUseId,code:event.data.code,is_error:event.data.isError,...(payload?{payload}:{})});}
   else if(event.type==='x/host/session-title'){if(event.data.status==='requested')record.title_request_event=event;if(['generated','failed'].includes(event.data.status))record.title_terminal_event=event;}
   else if(event.type==='assistant/message')record.final_texts.push(event);else if(event.type==='turn/end')record.turn_end=event;
   await save();if(record.turn_end&&record.title_terminal_event&&(!record.title_request_event||record.cost_events.some(x=>x.data.purpose==='title')))break;
  }})();reading.catch(readyNo);await ready;clearTimeout(readyTimer);
  await session.setModel({slot:'primary',route:record.route,model:record.model});
  record.arm=await hostArm(trial.trial_handle);record.arm_sha256=sha(await readFile(join(record.trial_directory,'arm.json')));
  record.started_epoch_ms=record.arm.started_epoch*1000;record.deadline_epoch_ms=record.arm.deadline_epoch*1000;
  const binding={schema_version:1,owner:'comparison-model-runner-v1',trial_handle:trial.trial_handle,session_key:record.session_key,started_epoch_ms:record.started_epoch_ms,deadline_epoch_ms:record.deadline_epoch_ms,arm_sha256:record.arm_sha256};
  record.active_binding=binding;await writeFile(join(out,'active_trial.json'),JSON.stringify(binding,null,2)+'\n');
  timer=setTimeout(()=>abort.abort(),Math.max(1,record.deadline_epoch_ms-35000-Date.now()));
  record.prompt=protocol.common.task_prompt+'\n本次工具：'+record.qualified_action_tool+'\n本次句柄：'+trial.trial_handle;
  record.prompt_sha256=sha(record.prompt);record.status='running';record.model_prompt_sent=true;await save();
  console.log(JSON.stringify({trial_handle:trial.trial_handle,session_id:session.id,started_epoch_ms:record.started_epoch_ms}));
  record.turn_result=await session.prompt(record.prompt,{signal:abort.signal,titleLocale:'zh-CN'});await waitOriginalSettlement(reading,record.deadline_epoch_ms);clearTimeout(readingTimer);record.model_requests_including_title=record.model_request_count+Math.max(record.cost_events.filter(x=>x.data.purpose==='title').length,Number(Boolean(record.title_request_event)));
  const publication=record.results.findLast(x=>x.payload?.action==='publish_report');record.publication=publication?.payload;
  record.status=publication?.payload?.status==='published'?'completed':publication?.payload?.status==='rejected'?'rejected':'failed';
 }catch(error){record.status='failed';record.failure={name:error.name,message:error.message};
  if(record.model_prompt_sent){abort.abort();try{await waitOriginalSettlement(reading,record.deadline_epoch_ms);}catch(settlement){record.failure_settlement_error={name:settlement.name,message:settlement.message};}finally{clearTimeout(readingTimer);}}
  record.model_requests_including_title=record.model_request_count+Math.max(record.cost_events.filter(x=>x.data.purpose==='title').length,Number(Boolean(record.title_request_event)));
 }
 finally{
  clearTimeout(readyTimer);clearTimeout(readingTimer);if(record.status==='failed')abort.abort();await client?.close();await iterator?.return?.();await finishEventReading(reading).catch(()=>undefined);
  if(session)for(const [format,name]of [['agnes','session.jsonl'],['html','session.html']]){let exporter;try{
   if(record.deadline_epoch_ms&&Date.now()>=record.deadline_epoch_ms)throw new Error('Original deadline expired; export cannot extend it');exporter=await webClient();
   await exportSession({positional:[session.id],format,raw:false,out:join(directory,name)},{cwd:record.workspace_root,io:{stdout:process.stdout,stderr:process.stderr},writeFile:(p,b)=>writeFile(p,b,{flag:'wx'})},exporter);
  }catch(error){record.export_failure={name:error.name,message:error.message};record.status='failed';}finally{await exporter?.close();}}
  clearTimeout(timer);record.finished_epoch_ms=Date.now();if(record.deadline_epoch_ms&&record.finished_epoch_ms>=record.deadline_epoch_ms){record.status='failed';record.failure??={name:'DeadlineError',message:'Original deadline expired during finalization'};}await save();
 }
 const processAfter=await captureRuntime();
 await writeFile(join(directory,'runtime_binding.json'),JSON.stringify({schema_version:1,runtime_manifest:publicProtocol.runtime_version,build_completed_at:processBefore.build_completed_at,before:processBefore,after:processAfter},null,2)+'\n',{flag:'wx'});
 return {trial_id:trial.trial_id,trial_handle:trial.trial_handle,arm:trial.arm,status:record.status,model_requests:record.model_requests_including_title??record.model_request_count+Number(Boolean(record.title_request_event)),record_path:path,session_id:record.session_id};
}
try{
 for(const trial of selected){
  if(trial.arm!=='C'&&(suite.model_requests_observed+7>cap))throw new Error('Phase budget remaining is below one full identical trial allocation');
  const result=await (trial.arm==='C'?scripted(trial):modeled(trial));suite.trials.push(result);suite.model_requests_observed+=result.model_requests;suite.model_requests_actual=null;await saveSuite();console.log(JSON.stringify(result));
  if(suite.model_requests_observed>cap)throw new Error('Total pilot model request budget exceeded');
  const directory=join(runtimeRoot,'trials',trial.trial_handle);let journal;
  try{journal=(await readFile(join(directory,'budget.jsonl'),'utf8')).trim().split('\n').map(line=>JSON.parse(line));}catch(error){if(error.code!=='ENOENT')throw error;}
  if(journal){let pending=false;for(const row of journal){if(row.event==='action_reserved'){if(pending)throw new Error('Overlapping action costs stop entire pilot');pending=true;}else if(row.event==='action_closed'){if(!pending||!Number.isInteger(row.record.actual_cost))throw new Error('Unknown actual cost stops entire pilot');pending=false;}}if(pending)throw new Error('Open unknown-cost action stops entire pilot');}
  for(const member of JSON.parse(await readFile(lockPin.path,'utf8')).files)if(sha(await readFile(member.path))!==member.sha256)throw new Error('Changed pinned source stops entire pilot');
  const verificationDirectory=join(out,'engineering_verification');await mkdir(verificationDirectory,{recursive:true});
  const verificationPath=join(verificationDirectory,trial.trial_handle+'.json');
  try{await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_model_v14.py'),dirname(result.record_path),'--protocol',join(out,'protocol.json'),'--output',verificationPath,...(trial.arm==='C'?['--scripted']:[])],{cwd:root,windowsHide:true,timeout:45000});}
  catch(error){result.engineering_verification_path=verificationPath;await saveSuite();throw new Error('Independent engineering check stopped pilot: '+error.message);}
  const verification=JSON.parse(await readFile(verificationPath,'utf8'));result.engineering_verification_path=verificationPath;result.engineering_status=verification.status;if(verification.status==='passed'&&(trial.arm==='C'?verification.model_request_count===0:verification.native_title_cost_known===true&&verification.actual_total_model_requests===result.model_requests))suite.model_requests_actual=suite.model_requests_observed;await saveSuite();if(verification.status!=='passed')throw new Error('Independent engineering checks failed');
  if(trial.arm!=='C'){
  const runtimeCheck=join(out,'runtime_verification',trial.trial_handle+'.json');
  await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_runtime_v14.py'),dirname(result.record_path),'--output',runtimeCheck],{cwd:root,windowsHide:true,timeout:45000});
  result.runtime_verification_path=runtimeCheck;
  }
  const businessCheck=join(out,'business_verification',trial.trial_handle+'.json');
  try{await run(python,['-X','utf8','-B',join(root,'tools/verify_comparison_case_v14.py'),directory,'--output',businessCheck],{cwd:root,windowsHide:true,timeout:45000});}catch(error){if(stage==='diagnostic'||!error.stdout||!error.stdout.includes('failed'))throw error;}
  const business=JSON.parse(await readFile(businessCheck,'utf8'));
  if(!['passed','failed'].includes(business.status))throw new Error('Business observation unknown');
  result.business_verification_path=businessCheck;await saveSuite();
 }
 suite.status='engineering_diagnostic_executed_pending_independent_evaluation';suite.unexecuted_comparison_trials=protocol.trials.length-suite.trials.length;
}catch(error){suite.status='stopped';suite.failure={name:error.name,message:error.message};process.exitCode=1;}
finally{try{suite.runtime_after=await checkRuntime();}catch(error){suite.status='stopped';suite.runtime_failure=error.message;process.exitCode=1;}suite.finished_at=new Date().toISOString();await saveSuite();console.log(JSON.stringify({status:suite.status,executed:suite.trials.length,model_requests:suite.model_requests_actual}));}
