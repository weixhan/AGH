// Continue the same real session to collect the terminal tool result, without launching a new repair.
import { readFile, writeFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient, finishEventReading } from './agh_ws_client.mjs';

const output = 'outputs/agh-label-repair';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
if (!launch.task_id || launch.permissions.filter(row => row.decision === 'allowed-once').length !== 1) {
  throw new Error('Expected exactly one previously authorized repair');
}
const record = { started_at: new Date().toISOString(), session_id: launch.session_id, task_id: launch.task_id,
  existing_task_only: true, calls: [], results: [], status: 'starting' };
const recordPath = output + '/continuation.json';
await writeFile(recordPath, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(recordPath, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let iterator;
let reading;
try {
  const session = await client.session.load(launch.session_id, {
    cwd: process.cwd(), onPermissionRequest: async () => ({ verdict: 'rejected' }),
  });
  iterator = session.events()[Symbol.asyncIterator]();
  reading = (async () => {
    while (true) {
      const next = await iterator.next();
      if (next.done) break;
      const event = next.value;
      if (event.seq <= launch.turn_result.lastSeq) continue;
      if (event.type === 'tool/call') {
        record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
        await save();
        console.log(JSON.stringify({ call: event.data.name, seq: event.seq }));
      }
      if (event.type === 'tool/result') {
        const text = event.data.content?.find(block => block.type === 'text')?.text;
        if (text) {
          try {
            const result = JSON.parse(text);
            if (result.task_id) {
              record.results.push({ seq: event.seq, task_id: result.task_id, status: result.status, summary: result.summary });
              await save();
              console.log(JSON.stringify({ task_id: result.task_id, status: result.status, summary: result.summary }));
            }
          } catch { /* The final official export retains authoritative content. */ }
        }
      }
      if (event.type === 'turn/end') break;
    }
  })();
  record.status = 'running';
  await save();
  record.prompt = `继续完成既有任务 ${launch.task_id}。你已获准查询直到终态，请立即调用 get_task_status，使用此编号；不要再调用 repair_label_copy，不要执行其他工具。若仍为running，继续查询同一任务，不能要求额外许可或把running当完成。若completed，依据实际summary核验repair_status与verification_status并报告changed_files、范围和证据路径。`;
  record.turn_result = await session.prompt(record.prompt, { titleLocale: 'zh-CN' });
  await finishEventReading(reading);
  record.status = 'turn_finished';
} catch (error) {
  record.status = 'failed';
  record.failure = { type: error.name, message: error.message };
  process.exitCode = 1;
} finally {
  await client.close();
  await iterator?.return?.();
  await finishEventReading(reading).catch(() => undefined);
  for (const [format, filename] of [['agnes', 'session.jsonl'], ['html', 'session.html']]) {
    const reader = await webClient();
    try {
      await exportSession({ positional: [launch.session_id], format, raw: false, out: output + '/' + filename }, {
        cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (path, bytes) => writeFile(path, bytes, { flag: 'wx', mode: 0o600 }),
      }, reader);
    } finally { await reader.close(); }
  }
  record.finished_at = new Date().toISOString();
  await save();
  console.log(JSON.stringify({ status: record.status, session_id: launch.session_id, task_id: launch.task_id }));
}
