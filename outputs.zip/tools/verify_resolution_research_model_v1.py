"""Independently accept a saved same-session real scientific loop, never run it.

Uses official outer events for model costs/permissions and raw SDK tool payloads
only as supplemental evidence cross-checked against independently read files.
No detector, Torch, model, continuation, or resume is invoked by this module.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
SAFE=9007199254740991
TITLE='x/host/session-title'
DIAGNOSTIC=TITLE+'/diagnostics'

def require(value,message):
    if not value:raise ValueError(message)

def integer(value,minimum=0):return type(value) is int and minimum<=value<=SAFE
def number(value):return type(value) in (int,float) and math.isfinite(value)
def same(a,b):
    if type(a) is not type(b):return False
    if type(a) is dict:return a.keys()==b.keys() and all(same(a[k],b[k]) for k in a)
    if type(a) is list:return len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    return a==b
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def decode(text):
    def pairs(items):
        result={}
        for k,v in items:
            require(k not in result,'Duplicate JSON key');result[k]=v
        return result
    value=json.loads(text,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))
    def finite(v):
        if type(v) is float:return math.isfinite(v)
        if type(v) is dict:return all(finite(x) for x in v.values())
        if type(v) is list:return all(finite(x) for x in v)
        return True
    require(finite(value),'Overflowing JSON number');return value
def read(path):return decode(Path(path).read_text('utf-8-sig'))
def stamp(text):
    require(type(text) is str,'Event UTC absent')
    t=datetime.fromisoformat(text.replace('Z','+00:00'));require(t.tzinfo is not None,'UTC timezone missing')
    value=t.timestamp()*1000;require(number(value),'Nonfinite event UTC');return value
def trusted(row):return row.get('origin')=='system' and row.get('trust')=='trusted'
def bound(pin):
    require(type(pin) is dict and {'path','sha256'}<=set(pin),'Artifact pin absent')
    p=Path(pin['path']);require(p.is_absolute(),'Artifact requires absolute path')
    for ancestor in (p,*p.parents):
        require(not ancestor.is_symlink() and not (hasattr(ancestor,'is_junction') and ancestor.is_junction()),'Linked evidence refused')
    require(re.fullmatch('[0-9a-f]{64}',str(pin['sha256'])) and p.is_file() and sha(p)==pin['sha256'],'Artifact bytes changed')
    if 'size_bytes' in pin:require(integer(pin['size_bytes']) and p.stat().st_size==pin['size_bytes'],'Artifact size changed')
    return p.resolve()
def tokens(value):
    fields={'input','output','cacheRead','cacheWrite'}
    require(type(value) is dict and fields<=set(value)<=fields|{'reasoning'}
        and all(integer(x) for x in value.values()) and sum(value[k] for k in fields)<=SAFE
        and (value['input']>0 or value['output']>0),'Unknown/default-zero/invalid token receipt')
    return value

def check_costs(rows,run):
    requests=[r for r in rows if r['type']=='request/sent']
    costs=[r for r in rows if r['type']=='cost/ledger' and r['data'].get('purpose')=='inference']
    require(0<len(requests)==len(costs)<=13,'Actual primary request/cost population is open or over cap')
    schemas={r['data'].get('tool_schema_hash') for r in requests}
    require(len(schemas)==1 and all(type(s) is str and re.fullmatch('[0-9a-f]{64}',s) for s in schemas),'Actual tool catalog changed')
    usage={k:0 for k in ('input','output','cacheRead','cacheWrite','reasoning')}
    effects=[]
    for i,(request,cost) in enumerate(zip(requests,costs)):
        data=cost['data'];model=request['data'].get('model',{})
        require(trusted(request) and trusted(cost) and model=={'id':run['model'],'route':run['route']}
            and data.get('model')==run['model'] and request['seq']<cost['seq']
            and (i+1==len(requests) or cost['seq']<requests[i+1]['seq']),'Primary usage was not paired to its request')
        require('interrupted' not in data or data['interrupted'] is False,'Interrupted primary cost')
        status=data.get('response',{}).get('status')
        require(integer(status,200) and status<300,'Primary response missing/error')
        require(type(data.get('effectId')) is str and data['effectId'],'Primary effect identity missing')
        effects.append(data['effectId'])
        for k,v in tokens(data.get('tokens')).items():usage[k]+=v
    require(len(set(effects))==len(effects),'Duplicate primary effect cost')
    require(all(r['data'].get('purpose') in {'inference','title'} for r in rows if r['type']=='cost/ledger'),
        'An unaccounted auxiliary model cost is present')
    return {'primary_requests':len(requests),'primary_tokens':usage,'primary_usage_closed':True}

def check_title(rows,run):
    requests=[r for r in rows if r['type']==TITLE and r['data'].get('status')=='requested']
    terminal=[r for r in rows if r['type']==TITLE and r['data'].get('status') in {'generated','failed'}]
    costs=[r for r in rows if r['type']=='cost/ledger' and r['data'].get('purpose')=='title']
    diagnostics=[r for r in rows if r['type']==DIAGNOSTIC]
    require(len(requests)==len(terminal)==len(costs)==len(diagnostics)==1,'Native title cost/terminal open or duplicated')
    request,finish,cost,diagnostic=(x[0] for x in (requests,terminal,costs,diagnostics))
    seed=request['data'];start=next((r for r in rows if r['seq']==seed.get('startSeq')),None)
    require(start is not None and start['type']=='turn/start' and start['data'].get('trigger')=='prompt'
        and integer(seed.get('turn'),1) and integer(start['data'].get('turn'),1) and seed['turn']==start['data']['turn']
        and integer(finish['data'].get('turn'),1) and seed['turn']==finish['data']['turn']
        and integer(finish['data'].get('startSeq'),1) and finish['data']['startSeq']==start['seq'],
        'Native title is not bound to the original actual prompt turn')
    ends=[r for r in rows if r['type']=='turn/end' and start['seq']<r['seq']<request['seq']]
    require(len(ends)==1 and ends[0]['data'].get('reason')=='completed','Title did not follow its completed source turn')
    require(all(trusted(r) and r.get('lane')==request.get('lane') for r in (start,ends[0],request,finish,cost,diagnostic)),
        'Native title source/lane is untrusted')
    require(seed.get('model')==finish['data'].get('model')==cost['data'].get('model')==run['model']
        and seed.get('route')==finish['data'].get('route')==run['route'],'Title route/model differs')
    d=diagnostic['data'];spend=cost['data']
    effect='title:'+hashlib.sha256(json.dumps([run['session_id'],request.get('lane'),start['seq']],
        ensure_ascii=False,separators=(',',':')).encode('utf8')).hexdigest()
    require(request['seq']<cost['seq'] and diagnostic['seq']==cost['seq']+1 and finish['seq']==diagnostic['seq']+1
        and cost['ts']==diagnostic['ts']==finish['ts'] and diagnostic.get('ignorable') is True
        and type(d.get('schemaVersion')) is int and d['schemaVersion']==1
        and integer(d.get('sourceTurn'),1) and integer(spend.get('sourceTurn'),1)
        and d['sourceTurn']==spend['sourceTurn']==seed['turn'] and d.get('effectId')==spend.get('effectId')==effect,
        'Title actual cost/diagnostic/terminal append differs')
    mandatory={'schemaVersion','sourceTurn','effectId','timeoutMs','durationMs','providerSent','responseSeen',
        'usageObserved','cancellationSettlementLimitMs','settledUsage','duplicateUsage','invalidUsage','responseStatus','usageAtMs'}
    require(mandatory<=set(d)<=mandatory|{'firstTextAtMs','firstThinkingAtMs'}
        and all(d[k] is True for k in ('providerSent','responseSeen','usageObserved'))
        and all(d[k] is False for k in ('settledUsage','duplicateUsage','invalidUsage'))
        and integer(d['responseStatus'],200) and d['responseStatus']<300
        and type(d['timeoutMs']) is int and d['timeoutMs']==30000
        and type(d['cancellationSettlementLimitMs']) is int and d['cancellationSettlementLimitMs']==25
        and integer(d['durationMs']) and d['durationMs']<30000 and integer(d['usageAtMs']) and d['usageAtMs']<=d['durationMs']
        and all(integer(d[k]) and d[k]<=d['durationMs'] for k in ('firstTextAtMs','firstThinkingAtMs') if k in d),
        'Native title response/usage/cancellation cost is unknown')
    require('interrupted' not in spend or spend['interrupted'] is False,'Interrupted native title')
    actual=tokens(spend.get('tokens'));status=finish['data'].get('status');reason=finish['data'].get('reason')
    require(status=='generated' or (status=='failed' and reason=='invalid-title'),'Unaccepted native title failure')
    return {'native_title_requests':1,'native_title_usage_closed':True,'native_title_tokens':actual,
        'native_title_status':status,'native_title_reason':reason,'title_generated':status=='generated'}

def check_official_sdk(rows,events,run):
    require(type(events) is list and len(events)==len(rows),'SDK/official event population differs')
    essential={'request/sent','cost/ledger','turn/start','turn/end','tool/call','approval/asked','approval/decided',TITLE,DIAGNOSTIC}
    for official,sdk in zip(rows,events):
        require(all(same(official.get(k),sdk.get(k)) for k in ('seq','ts','type','origin','trust','lane')),
            'SDK and official event envelope differs')
        kind=official['type']
        if kind in essential:
            a,b=official['data'],sdk['data']
            if kind=='cost/ledger':
                for key in ('purpose','effectId','sourceTurn','model','tokens','interrupted'):
                    require(same(a.get(key),b.get(key)),'Official/SDK actual cost differs')
                require(same(a.get('response',{}).get('status'),b.get('response',{}).get('status')),'Response status differs')
            elif kind==TITLE:
                require(all(same(a.get(k),b.get(k)) for k in ('status','turn','startSeq','route','model','reason')),'Title event identity differs')
            else:require(same(a,b),'Essential official event differs')
        elif kind=='tool/result':
            require(all(same(official['data'].get(k),sdk['data'].get(k)) for k in ('toolUseId','isError')),
                'SDK tool result identity differs')
    return {'official_sdk_envelopes_paired':len(rows),
        'official_inner_tool_text_not_restored':True}

def tool_payload(event):
    require(event['data'].get('isError') is not True,'Scientific tool returned error')
    blocks=event['data'].get('content');require(type(blocks) is list,'Tool content missing')
    text=[x['text'] for x in blocks if x.get('type')=='text']
    require(len(text)==1,'Expected one actual scientific payload');return decode(text[0])

def check_actions(rows,events,protocol,deployment):
    policy=protocol['scope_policy'];action_tool=policy['qualified_action_tool'];read_tool=policy['qualified_read_tool']
    calls=[e for e in rows if e['type']=='tool/call'];results=[e for e in events if e['type']=='tool/result']
    expected=['audit_geometry','register_hypothesis','start_registered_experiment','status',
        'resume_registered_failure','status','independent_review','DECISION','publish_report']
    require(len(calls)==len(results)==len(expected),'Incomplete/extra actual scientific actions')
    by_result={e['data']['toolUseId']:e for e in results};require(len(by_result)==len(results),'Duplicate tool result')
    payloads=[];observed=[]
    for index,call in enumerate(calls):
        data=call['data'];args=data.get('args');action=args.get('action') if type(args) is dict else None
        require(call.get('origin')=='model' and call.get('trust')=='trusted'
            and type(args) is dict and set(args)=={'request_id','action'} and args['request_id']==deployment['request_id'],
            'Foreign model action/argument or missing trusted tool call')
        want=expected[index];require(action in {'decide_stop_resolution','decide_retain_resolution','decide_insufficient_evidence'}
            if want=='DECISION' else action==want,'Actual actions do not complete the full scientific sequence')
        require(data.get('name')==(read_tool if action in {'status','independent_review'} else action_tool),'Wrong scientific tool')
        result=by_result.get(data.get('toolUseId'));require(result
            and result.get('origin')=='tool:'+data['name'] and result.get('trust')=='untrusted'
            and call['seq']<result['seq'], 'Tool result absent/foreign/origin changed/out of order')
        if index+1<len(calls):require(result['seq']<calls[index+1]['seq'],'Parallel or unobserved scientific steps')
        payload=tool_payload(result)
        require(payload.get('request_id')==deployment['request_id'] and payload.get('task_id')==deployment['task_id']
            and payload.get('fixture_only') is False,'A fixture or foreign task was used as real science')
        observed.append(action);payloads.append(payload)
    expected_states=['running','hypothesis_registered','running','recovery_pending','running',
        'experiment_completed','reviewed','decided','report_completed']
    require([p.get('status') for p in payloads]==expected_states,'Actual tool outcomes failed/incomplete')
    require(payloads[0].get('phase')=='preflight','Initial audit did not start the registered asynchronous CPU gates')
    require(payloads[3]['actual_failure'].get('closed_cost') is True,'Model recovery did not follow known actual cost')
    require(payloads[6].get('only_supported_decision_action')==observed[7]
        and payloads[6].get('verification',{}).get('real_recovery_accepted') is True
        and payloads[-1].get('science_accepted') is True,'Model decision/report did not follow accepted evidence')
    asked={e['data']['toolUseId']:e for e in rows if e['type']=='approval/asked'}
    decided={e['data']['requestId']:e for e in rows if e['type']=='approval/decided'}
    require(all(trusted(x) for x in (*asked.values(),*decided.values())),'Untrusted approval')
    for call in calls:
        if call['data']['name']==read_tool:continue
        ask=asked.get(call['data']['toolUseId']);require(ask is not None,'Write action lacked original Allow once')
        decision=decided.get(ask['data']['requestId'])
        require(decision and decision['data'].get('verdict')=='allowed-once'
            and call['seq']<ask['seq']<decision['seq']<by_result[call['data']['toolUseId']]['seq'],
            'Write approval missing/blanket/late/rejected')
    return {'actual_action_path':observed,'actual_scientific_tool_calls':len(calls),
        'model_explicit_resume_count':observed.count('resume_registered_failure'),
        'model_selected_decision':observed[7],'actual_report':payloads[-1]['report']}

def verify(directory):
    checks={};errors=[];facts={};directory=Path(directory).resolve()
    def check(name,fn):
        try:
            value=fn();checks[name]=True
            if type(value) is dict:facts.update(value)
            return value
        except Exception as e:
            checks[name]=False;errors.append({'check':name,'type':type(e).__name__,'message':str(e)})
            return None
    try:
        run=read(directory/'run_result.json');protocol_path=Path(run['protocol_path'])
        require(protocol_path.is_relative_to(ROOT) and sha(protocol_path)==run['protocol_sha256'],'Host protocol changed')
        protocol=read(protocol_path);deployment=read(bound(protocol['deployment']))
        rows=[decode(l) for l in (directory/'session.jsonl').read_text('utf8').splitlines() if l.strip()]
        events=run['sdk_events']
        def sources():
            require(protocol['kind']=='resolution_research_model_protocol_v1' and protocol['output_directory']==str(directory),
                'Foreign scientific deployment')
            require(run.get('status')=='completed' and run.get('fixture_only') is False,'Model run failed/incomplete/fixture')
            for name in ('source_lock','runner_source','runtime_version','task_prompt'):bound(protocol[name])
            lock=read(bound(protocol['source_lock']));paths=set()
            for p in lock['files']:paths.add(str(bound(p)))
            require(len(paths)==len(lock['files']) and lock['kind']=='resolution_research_mcp_source_lock_v1'
                and lock['status']=='passed_engineering_only'
                and str(Path(__file__).resolve()) in paths,'Source closure absent/duplicate or checker omitted')
            require(all(run.get(k)==protocol[k] for k in ('model','route'))
                and run.get('workspace_root')==deployment['workspace_root'],'Model/route/workspace differs')
            return {'current_deployment_source_members':len(paths)}
        check('complete_current_frozen_execution_and_host_sources',sources)
        def session():
            require(run.get('session_id')==run.get('session_key') and type(run['session_id']) is str,'Session identity missing')
            require(rows and [e['seq'] for e in rows]==list(range(1,len(rows)+1))
                and all(integer(e['seq'],1) for e in rows),'Official event ledger non-contiguous')
            require(rows[0]['type']=='session/start' and trusted(rows[0]) and rows[0]['data'].get('key')==run['session_id'],
                'Not the bound fresh original session')
            starts=[e for e in rows if e['type']=='turn/start'];ends=[e for e in rows if e['type']=='turn/end']
            require(len(starts)==len(ends)==4 and [e['data']['trigger'] for e in starts]==['prompt','follow_up','follow_up','follow_up']
                and all(trusted(e) for e in starts+ends) and all(e['data'].get('reason')=='completed' for e in ends),
                'Four honest completed turns in one session were not recorded')
            require(all(integer(e['data'].get('turn'),1) for e in starts)
                and [e['data']['turn'] for e in starts]==[1,2,3,4]
                and all(s['seq']<e['seq'] and (i==3 or e['seq']<starts[i+1]['seq']) for i,(s,e) in enumerate(zip(starts,ends))),
                'Actual turn order or identity differs')
            begin=deployment['started_epoch']*1000;deadline=deployment['deadline_epoch']*1000
            require(number(run.get('finished_epoch_ms')) and begin<=run['model_started_epoch_ms']<=run['finished_epoch_ms']<deadline
                and run['started_epoch_ms']==begin and run['deadline_epoch_ms']==deadline,'Original outer clock was reset/expired')
            require(all(run['model_started_epoch_ms']<=stamp(e['ts'])<=run['finished_epoch_ms'] for e in starts+ends),
                'Actual turns escaped original model interval')
            receipts=run['prompt_receipts'];require(len(receipts)==4 and [x['kind'] for x in receipts]==['prompt','followUp','followUp','followUp']
                and all(x['session_id']==run['session_id'] and hashlib.sha256(x['text'].encode('utf8')).hexdigest()==x['text_sha256'] for x in receipts),
                'Prompt/follow-up receipt or same session binding differs')
            for i,receipt in enumerate(receipts):
                require(number(receipt['sent_epoch_ms']) and begin<=receipt['sent_epoch_ms']<=stamp(starts[i]['ts']),
                    'Notification was sent after its turn or before original preparation')
                if i:require(receipt['preceding_turn_end_seq']==ends[i-1]['seq'],'Follow-up borrowed another prior turn')
            return {'completed_model_turns':4,'same_session_followups':3}
        check('same_session_actual_four_turns_and_original_outer_clock',session)
        check('official_sdk_core_events_costs_and_permissions_paired',lambda:check_official_sdk(rows,events,run))
        primary=check('every_primary_request_actual_usage_closed',lambda:check_costs(rows,run))
        title=check('unique_original_native_title_actual_usage_closed',lambda:check_title(rows,run))
        def total():
            require(primary and title and primary['primary_requests']+title['native_title_requests']<=14,'Combined model cap exceeded/unknown')
            return {'actual_total_model_requests':primary['primary_requests']+1,'all_model_usage_closed':True}
        check('combined_primary_and_native_title_cap',total)
        check('model_chose_fault_recovery_review_decision_and_report',lambda:check_actions(rows,events,protocol,deployment))
        def business():
            from tools.verify_resolution_recovery_v1 import verify as review
            task=Path(protocol['domain_task_directory']);actual=review(task,prepublication=False)
            require(actual['status']=='passed' and actual['real_recovery_accepted'] is True
                and actual['fixture_only'] is False and all(actual['checks'].values()),'Actual complete GPU business independently failed')
            registration=read(task/'registration.json');registry=bound(protocol['deployment']).parent/'mcp-owned'
            report=read(registry/'research_report.json');decision=read(registry/'decision.json');hypothesis=read(registry/'hypothesis.json')
            require(same(report,facts.get('actual_report')),'Model received a different report from the saved artifact')
            require(report['recovery_accepted'] is True and report['fixture_only'] is False and report['domain_deadline_reset'] is False
                and report['original_failure_preserved'] is True and report['task_id']==deployment['task_id'],
                'Report fabricated a complete/recovered scientific task')
            for name in ('preflight','hypothesis','independent_review','worker_result','model_decision','pre_report_review'):bound(report[name])
            require(hypothesis['deadline_reset'] is False and hypothesis['method_tuning_allowed'] is False
                and hypothesis['next_experiment_registered'] is False
                and bound(hypothesis['domain_registration'])==task/'registration.json',
                'Hypothesis did not precede registered unchanged scientific task')
            contract=read(ROOT/'fixtures/resolution_research_mcp_protocol_v1.json')
            require(hypothesis['primary_hypothesis']==contract['primary_hypothesis']
                and same(hypothesis['resolution_candidate'],contract['resolution_candidate']),'Hypothesis/criteria changed after results')
            values=[read(task/'groups'/s/'metrics.json') for s in ('reference_640','reference_960')]
            measured={};passed=[]
            def field(v,path):
                for k in path.split('.'):v=v[k]
                require(number(v),'Scientific metric missing/nonfinite');return v
            for rule in contract['resolution_candidate']['criteria']:
                a,b=[field(v,rule['field']) for v in values];measured[rule['field']]={'640':a,'960':b}
                passed.append(b>=a if rule['operator']=='greater_or_equal_baseline' else b<=a)
            require(all(field(v,k)>0 for v in values for k in contract['resolution_candidate']['required_denominators']),
                'Scientific denominator absent')
            outcome='resolution_candidate_accepted_for_this_validation_only' if all(passed) else 'resolution_candidate_stopped'
            action='decide_retain_resolution' if all(passed) else 'decide_stop_resolution'
            require(report['resolution_decision']==decision['resolution_decision']==outcome
                and decision['model_selected_action']==facts.get('model_selected_decision')==action
                and same(report['measured_frozen_fields'],measured) and same(decision['measured_frozen_fields'],measured)
                and report['next_plan']['new_experiment_registered'] is False and report['next_plan']['method_tuning'] is False
                and report['next_plan']['action']==('retain_bounded_validation_result' if all(passed) else 'stop_and_report'),
                'Actual results did not change the model decision/report/next plan')
            require(registration['deadline_epoch']==registration['started_epoch']+1800
                and report['budget_scope']['domain_deadline_epoch']==registration['deadline_epoch']
                and registration['started_epoch']<=report['budget_scope']['business_completion_file_mtime_epoch']<registration['deadline_epoch']
                and deployment['started_epoch']<=(registry/'research_report.json').stat().st_mtime<deployment['deadline_epoch'],
                'Domain or report publication escaped the original separate clock')
            waits=run['host_waits'];require(len(waits)==3 and [w['phase'] for w in waits]==['preflight','initial','resume'],
                'Host waiting/continuation phase count differs')
            for wait in waits:
                result=read(bound(wait['notification']['worker_result']));require(result['phase']==wait['phase'] and result['task_id']==deployment['task_id']
                    and result['fixture_only'] is False and result['result']['task_id']==deployment['task_id']
                    and result['result']['status']=={'preflight':'preflight_passed','initial':'recovery_pending','resume':'completed'}[wait['phase']],
                    'Continuation used a fixture/foreign/failed worker')
            return {'independent_business_checks':len(actual['checks']),'real_prediction_entries':3205,
                'resolution_decision':outcome,'new_research_report':str(registry/'research_report.json'),
                'scientific_metrics':measured,'domain_budget':read(task/'budget_final.json')}
        check('real_full_experiment_independent_verifier_and_evidence_bound_plan',business)
        def runtime():
            from tools.verify_comparison_runtime_v14 import check_runtime
            binding=read(directory/'runtime_binding.json');manifest=read(bound(protocol['runtime_version']))
            require(same(binding['runtime_manifest'],protocol['runtime_version']),'OS runtime manifest was not registered')
            # Runtime bracketing begins when the actual model turn starts, not at earlier deployment preparation.
            interval={'started_epoch_ms':run['model_started_epoch_ms'],'finished_epoch_ms':run['runtime_execution_finished_epoch_ms'],
                'deadline_epoch_ms':run['deadline_epoch_ms']}
            return check_runtime(binding,manifest,interval)
        check('live_tested_bundle_and_same_worker_execution_binding',runtime)
        def exports():
            require((directory/'session.html').stat().st_size>0 and (directory/'session.jsonl').stat().st_size>0,
                'Official exports absent')
            records=run['exports'];require(len(records)==2 and {r['format'] for r in records}=={'agnes','html'},'Official export count differs')
            for r in records:bound(r)
            return {'official_exports_verified':2}
        check('official_json_html_export_bytes',exports)
    except Exception as error:
        checks['complete_readable_evidence_population']=False;errors.append({'check':'complete_readable_evidence_population',
            'type':type(error).__name__,'message':str(error)})
    return {'schema_version':1,'status':'passed' if checks and all(checks.values()) else 'failed',
        'scope':'One bounded same-session actual scientific experiment and known-cost step recovery; not open-method autonomy.',
        'checked_at':datetime.now(timezone.utc).isoformat(),'directory':str(directory),'checks':checks,'errors':errors,**facts,
        'limitations':['AP recomputation uses the shared detection_metrics implementation.',
            'Masked official inner tool text is not restored; raw SDK payloads are checked against independent files.',
            'Estimated billing credits are not a purchase price.']}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('directory',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();result=verify(args.directory)
    with args.output.open('x',encoding='utf8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'status':result['status'],'checks_passed':sum(result['checks'].values()),'checks_total':len(result['checks']),
        'errors':result['errors']},ensure_ascii=False));return 0 if result['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
