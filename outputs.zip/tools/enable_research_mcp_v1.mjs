// Add a new managed server through official AGH ResourceAdmin, preserving the old server.
import {readFile,writeFile} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177';
const output=join(root,'outputs','research-mcp-local-acceptance-v1');
const continuing=process.argv.includes('--continue-create');
const path=join(output,continuing?'registration-continued.json':'registration.json');
const lock=join(root,'outputs','research-mcp-implementation-v1','source_lock.json');
const sha=createHash('sha256').update(await readFile(lock)).digest('hex');
if(sha!=='4e734324fffc10e647058c09195084d28246efd6637c6971f6aaa5a8b00d2e18')throw new Error('Deployment lock changed');
const local=JSON.parse(await readFile(join(output,'acceptance.json'),'utf8'));
if(local.status!=='passed')throw new Error('Local MCP acceptance has not passed');
const serverId='defect-researcher-workflow-v1';
const definition={serverId,displayName:'DefectResearcher workflow V1',transport:{kind:'stdio',
 executable:'E:\\Anaconda_envs\\envs\\MMIOC_env\\python.exe',args:['-B',join(root,'run_research_mcp_v1.py'),
 '--config',join(root,'config','local.json'),'--source-lock',lock,'--expected-lock-sha256',sha]},
 secretBinding:{kind:'none'},toolPolicy:{allow:['run_bounded_research_workflow_v1','get_research_workflow_status_v1']}};
const trace={schema_version:1,status:'running',interface:'official ResourceAdmin BFF',origin,definition,
 started_at:new Date().toISOString(),steps:[],credentials_read:false,new_model_requests:0,old_server_changed:false};
await writeFile(path,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(path,JSON.stringify(trace,null,2)+'\n');
async function request(endpoint,body) {
 const response=await fetch(`${origin}/admin/resources/api/${endpoint}`,{method:body?'POST':'GET',
 headers:{Origin:origin,Accept:'application/json','Content-Type':'application/json'},
 ...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000)});
 const data=await response.json();if(!response.ok)throw new Error(`${endpoint}: ${response.status} ${JSON.stringify(data)}`);return data;
}
try {
 const context=await request('context');if(context.readOnly||context.profile!=='local-dev')throw new Error('Expected writable local-dev context');
 const base={profile:context.profile,clientId:context.clientId};
 trace.old_before=await request('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 const list=await request('mcp/list',{profile:base.profile});
 const existing=list.items.find(row=>row.serverId===serverId);
 if(existing&&!continuing)throw new Error('New server already exists; refusing overwrite');
 if(continuing) {
  const prior=JSON.parse(await readFile(join(output,'registration.json'),'utf8'));
  if(prior.status!=='failed'||prior.steps.length!==1||prior.steps[0].endpoint!=='mcp/create'||
     !prior.steps[0].receipt?.operationId||!prior.error.message.startsWith('operation/get: 404')||
     !existing||existing.trust!=='untrusted'||existing.desired!=='disabled'||
     JSON.stringify(existing.definition)!==JSON.stringify(definition))throw new Error('Prior creation does not permit continuation');
  const step=structuredClone(prior.steps[0]);
  step.operation=await request('operations/get',{profile:base.profile,operationId:step.receipt.operationId});
  if(step.operation.state!=='succeeded')throw new Error('Prior creation operation did not succeed');
  trace.steps.push(step);trace.prior_failure_preserved=join(output,'registration.json');await save();
 }
 async function effect(endpoint,params) {
  const step={endpoint,params:{...base,commandId:`research-mcp-${randomUUID()}`,...params}};
  trace.steps.push(step);await save();step.receipt=await request(endpoint,step.params);await save();
  const deadline=Date.now()+60000;
  for(;;) {
   step.operation=await request('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();
   if(['succeeded','failed','cancelled'].includes(step.operation.state))break;
   if(Date.now()>=deadline)throw new Error('Resource operation deadline expired');
   await new Promise(done=>setTimeout(done,300));
  }
  if(step.operation.state!=='succeeded')throw new Error(`${endpoint} operation failed`);
  console.log(JSON.stringify({action:endpoint,state:step.operation.state}));
 }
 if(!continuing)await effect('mcp/create',{definition});
 let current=await request('mcp/get',{profile:base.profile,serverId});
 trace.created=current;await save();
 const revision=value=>value.revision??value.server?.revision;
 await effect('mcp/trust',{serverId,expectedRevision:revision(current),trust:'trusted'});
 current=await request('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/enable',{serverId,expectedRevision:revision(current)});
 trace.after=await request('mcp/get',{profile:base.profile,serverId});
 trace.status_snapshot=await request('mcp/status',{profile:base.profile,serverId});
 trace.tools=await request('mcp/tools',{profile:base.profile,serverId});
 trace.old_after=await request('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 const stable=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)
  ?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
 trace.checks={old_server_unchanged:stable(trace.old_before)===stable(trace.old_after),
  three_operations_completed:trace.steps.length===3&&trace.steps.every(step=>step.operation.state==='succeeded'),
  deployment_lock_unchanged:createHash('sha256').update(await readFile(lock)).digest('hex')===sha};
 trace.status=Object.values(trace.checks).every(Boolean)?'completed':'failed';
}catch(error){trace.status='failed';trace.error={name:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,checks:trace.checks,error:trace.error}));}
