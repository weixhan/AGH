"""Preregister the fixed two-image recovery inputs without importing a detector.

Only this recipe's two validation inputs and bounded, trusted upstream evidence
are rehashed. This is engineering preparation, not a fresh all-dataset review.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import re
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

PROTOCOL_PATH = PROJECT_ROOT / "fixtures" / "sliced_business_protocol_v2.json"
FROZEN_PROTOCOL_SHA256 = "4d6600c3cd5e31a1ce63081c49d6981e8ebc6a0d303c84070943a07279001079"
TOOL = "verify_sliced_business_recovery_v2"
PURPOSE = "two-image-known-cost-step-recovery-v2"
PATH_KEYS = ("research_root", "dataset_root", "raw_root", "split_dir", "weights_path", "output_root")
IDENTITY_KEYS = {"path", "sha256", "size_bytes"}
MANIFEST_KEYS = {"schema_version", "tool", "purpose", "execution_version", "protocol_sha256",
                 "configuration", "records", "reference_environment", "input_files", "pixel_inputs",
                 "preserved_files", "upstream_evidence", "dependency_versions", "preparation_scope",
                 "new_detector_calls", "new_gpu_calls", "new_model_requests"}


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"Duplicate JSON key: {key}")
        value[key] = item
    return value


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=_unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"Nonfinite JSON: {value}")))


def _equal(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(_equal(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(_equal(a, b) for a, b in zip(left, right))
    return left == right


def _identity(path, expected=None):
    path = Path(path).resolve()
    value = {"path": str(path), "sha256": _sha256(path), "size_bytes": path.stat().st_size}
    if expected is not None and value["sha256"] != expected:
        raise ValueError(f"Preregistered bytes differ: {path.name}")
    return value


def read_protocol():
    if _sha256(PROTOCOL_PATH) != FROZEN_PROTOCOL_SHA256:
        raise ValueError("Fixed business protocol bytes changed")
    value = _read(PROTOCOL_PATH)
    if (type(value["schema_version"]) is not int or value["schema_version"] != 1
            or type(value["execution_version"]) is not int or value["execution_version"] != 2
            or value["tool"] != TOOL or value["purpose"] != PURPOSE
            or "nms" not in value or value["nms"] is not None):
        raise ValueError("Unknown business protocol recipe")
    return value


def _configuration(configuration):
    from defect_researcher.config import load_config
    from defect_researcher.audit import _configured_paths
    trusted = load_config()
    value = trusted if configuration is None else configuration
    if type(value) is not dict or value.keys() != set(PATH_KEYS):
        raise ValueError("Configuration must contain exactly six trusted paths")
    resolved = {key: str(path) for key, path in _configured_paths(value).items()}
    if not _equal(resolved, trusted):
        raise ValueError("Configuration differs from the local trusted path configuration")
    if Path(resolved["output_root"]) != PROJECT_ROOT / "outputs":
        raise ValueError("Business evidence must use the trusted project outputs")
    return resolved


def select_records(records, members, protocol=None):
    """Select using membership and GT only; predictions never affect selection."""
    protocol = read_protocol() if protocol is None else protocol
    if len(records) != 640 or len(members) != 640 or len(set(members)) != 640:
        raise ValueError("Selection source requires 640 unique frozen validation members")
    by_id = {}
    for record in records:
        if type(record) is not dict:
            raise ValueError("Malformed validation selection record")
        image_id = record.get("image_id")
        if not isinstance(image_id, str) or image_id in by_id or record.get("split") != "val":
            raise ValueError("Duplicate or nonvalidation selection member")
        if (type(record.get("ground_truth")) is not list or record.get("width") != 1920
                or record.get("height") != 1080):
            raise ValueError("Frozen selection member dimensions/GT differ")
        by_id[image_id] = record
    if set(by_id) != set(members):
        raise ValueError("Frozen predictions and validation membership differ")
    normal = sorted(key for key, record in by_id.items() if not record["ground_truth"])
    anomaly = sorted(key for key, record in by_id.items() if record["ground_truth"])
    if not normal or not anomaly:
        raise ValueError("Selection requires normal and annotated validation members")
    selected = [by_id[key] for key in sorted([normal[0], anomaly[0]])]
    if [record["image_id"] for record in selected] != protocol["image_ids"]:
        raise ValueError("Fixed lexical selection differs; reselection is forbidden")
    if len(selected[0]["ground_truth"]) != 0 or len(selected[1]["ground_truth"]) != 1:
        raise ValueError("Fixed two-image GT counts differ")
    return selected


def _dependencies():
    paths = {}
    recipes = {
        "ultralytics": ("engine/model.py", "engine/predictor.py", "models/yolo/detect/predict.py",
                        "utils/ops.py", "utils/nms.py", "data/loaders.py", "cfg/default.yaml"),
        "torch": ("__init__.py", "version.py", "cuda/__init__.py", "backends/cudnn/__init__.py"),
        "cv2": ("__init__.py",), "numpy": ("__init__.py",),
    }
    for package, filenames in recipes.items():
        spec = importlib.util.find_spec(package)
        if spec is None or spec.origin is None:
            raise ValueError(f"Installed dependency missing: {package}")
        root = Path(spec.origin).resolve().parent
        for name in filenames:
            path = root / name
            if not path.is_file():
                raise ValueError(f"Dependency source missing: {package}/{name}")
            paths[f"dependency/{package}/{name}"] = path
        if package in {"cv2", "numpy"}:
            binary_root = root if package == "cv2" else root / "_core"
            binaries = sorted(binary_root.glob("*.pyd"))
            if not binaries:
                raise ValueError(f"Decode/pixel dependency binary missing: {package}")
            for path in binaries:
                paths[f"dependency/{package}/{path.relative_to(root).as_posix()}"] = path
    versions = {key: importlib.metadata.version(distribution) for key, distribution in
                (("torch", "torch"), ("ultralytics", "ultralytics"), ("numpy", "numpy"),
                 ("cv2", "opencv-python"))}
    return paths, versions


def _pixel_inputs(records, protocol):
    import cv2
    import numpy as np
    values = []
    for record in records:
        image = cv2.imread(record["image_path"], cv2.IMREAD_COLOR)
        if image is None or image.shape != (1080, 1920, 3) or image.dtype != np.uint8:
            raise ValueError("Fixed BGR uint8 decode dimensions differ")
        decoded = hashlib.sha256(np.ascontiguousarray(image).tobytes()).hexdigest()
        source_hash = _sha256(record["image_path"])
        crops = [[0, 0, 1920, 1080]] + [[x, y, x + 640, y + 640]
                 for y in protocol["tile_grid"]["y"] for x in protocol["tile_grid"]["x"]]
        for pass_id, crop in enumerate(crops):
            x1, y1, x2, y2 = crop
            pixels = np.ascontiguousarray(image[y1:y2, x1:x2])
            values.append({"image_id": record["image_id"], "pass_id": pass_id, "crop": crop,
                           "source_image_sha256": source_hash, "decoded_image_sha256": decoded,
                           "input_pixels_sha256": hashlib.sha256(pixels.tobytes()).hexdigest()})
    return values


def _upstream(protocol):
    paths = {}
    for relative, expected in protocol["upstream_sha256"].items():
        path = PROJECT_ROOT / relative
        paths[f"upstream/{relative}"] = _identity(path, expected)
    original = PROJECT_ROOT / "outputs" / protocol["source_failed_task_id"]
    if any((original / name).exists() for name in
           ("completion.json", "completion_candidate.json", "artifact_manifest.json", "sliced_result.json")):
        raise ValueError("Original failed task gained a success artifact")
    if _read(original / "failure.json").get("status") != "failed":
        raise ValueError("Original task failure state changed")
    review = PROJECT_ROOT / "outputs" / protocol["artifact_review_task_id"]
    independent = _read(review / "independent_verification.json")
    checks = independent.get("checks")
    if (independent.get("status") != "passed" or independent.get("task_id") != protocol["artifact_review_task_id"]
            or type(checks) is not dict or len(checks) != 99 or not all(item is True for item in checks.values())
            or independent.get("original_business_status") != "failed"
            or independent.get("original_completion_absent") is not True):
        raise ValueError("Accepted upstream 99-check evidence is incomplete")
    marker, manifest = _read(review / "completion.json"), _read(review / "artifact_manifest.json")
    if marker.get("status") != "completed" or marker.get("task_id") != protocol["artifact_review_task_id"]:
        raise ValueError("Accepted artifact review completion differs")
    names = set()
    for row in manifest["files"]:
        name = row["name"]
        if name in names or Path(name).name != name or name not in marker["artifacts_sha256"]:
            raise ValueError("Accepted upstream manifest duplicate/outside task")
        names.add(name)
        identity = _identity(review / name, marker["artifacts_sha256"][name])
        if row["sha256"] != identity["sha256"] or row["size_bytes"] != identity["size_bytes"]:
            raise ValueError("Accepted upstream artifact manifest identity differs")
        paths[f"upstream/review-artifact/{name}"] = identity
    if names != set(marker["artifacts_sha256"]):
        raise ValueError("Accepted upstream completion and manifest file sets differ")
    model = _read(PROJECT_ROOT / "outputs/agh-sliced-artifact-model-v3/model_run_verification.json")
    if (model.get("status") != "passed" or type(model.get("checks_total")) is not int
            or model["checks_total"] != 54 or model.get("checks_passed") != 54
            or len(model.get("checks", {})) != 54 or not all(v is True for v in model["checks"].values())
            or model.get("strict_tool_scope_passed") is not True):
        raise ValueError("Accepted Agnes 54-check evidence is incomplete")
    runner = _read(PROJECT_ROOT / "outputs/sliced-runner-v3-fix/verification.json")
    if (runner.get("status") != "passed" or runner.get("full_regression_count") != 600
            or not all(v is True for v in runner["checks"].values())):
        raise ValueError("Versioned runner preparation acceptance differs")
    preserved = {}
    snapshot = _read(PROJECT_ROOT / "outputs/sliced-runner-v3-fix/preservation_before.json")
    frozen = _read(PROJECT_ROOT / "outputs/sliced-runner-implementation-v3/freeze.json")
    for row in snapshot["files"] + frozen["files"]:
        path = Path(row["path"])
        if not path.is_absolute():
            path = PROJECT_ROOT / path
        identity = _identity(path, row["sha256"])
        if identity["size_bytes"] != row["size_bytes"]:
            raise ValueError("Preserved source size differs")
        prior = preserved.get(identity["path"])
        if prior is not None and prior != identity:
            raise ValueError("Conflicting preserved source identities")
        preserved[identity["path"]] = identity
    for relative, expected in protocol["additional_preserved_sha256"].items():
        identity = _identity(PROJECT_ROOT / relative, expected)
        prior = preserved.get(identity["path"])
        if prior is not None and prior != identity:
            raise ValueError("V1 preservation identities conflict")
        preserved[identity["path"]] = identity
    prior_trial = PROJECT_ROOT / "outputs" / protocol["prior_trial"]["experiment_id"]
    if (_read(prior_trial / "failure.json").get("status") != "failed"
            or (prior_trial / "completion.json").exists()):
        raise ValueError("V1 real failed trial gained a success state")
    return paths, sorted(preserved.values(), key=lambda row: row["path"])


def _derive_registration(configuration=None):
    protocol = read_protocol()
    configuration = _configuration(configuration)
    output_root = Path(configuration["output_root"])
    source = output_root / protocol["source_task_id"]
    files = {}
    files["source_predictions"] = _identity(source / "predictions_640.jsonl", protocol["preregistered_inputs"]["source_predictions"])
    member_path = Path(configuration["split_dir"]) / "val.txt"
    files["val_members"] = _identity(member_path, protocol["preregistered_inputs"]["val_members"])
    records = [_read_json_line(line) for line in (source / "predictions_640.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    members = [Path(line.strip()).stem for line in member_path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    selected = select_records(records, members, protocol)
    for record in selected:
        for field, kind, folder, suffix in (("image_path", "image", "images", ".png"),
                                           ("label_path", "label", "labels", ".txt"),
                                           ("metadata_path", "metadata", "metadata", ".json")):
            expected_path = Path(configuration["dataset_root"]) / folder / "val" / (record["image_id"] + suffix)
            if Path(record[field]).resolve() != expected_path:
                raise ValueError("Selected input path differs from configured validation dataset")
            role = record["image_id"] + "/" + kind
            files[role] = _identity(expected_path, protocol["preregistered_inputs"][role])
        metadata = _read(record["metadata_path"])
        if metadata.get("geometry_version") != "hbb_v1" or len(metadata.get("annotations", [])) != len(record["ground_truth"]):
            raise ValueError("Selected metadata geometry/member count differs")
    files["weights"] = _identity(configuration["weights_path"], protocol["weight_sha256"])
    upstream, preserved = _upstream(protocol)
    files.update(upstream)
    dependencies, versions = _dependencies()
    for role, path in dependencies.items():
        files[role] = _identity(path)
    reference = _read(source / "comparison_result.json")["summary"]["environments"]["640"]
    _validate_reference(reference)
    return {"schema_version": 1, "tool": TOOL, "purpose": PURPOSE, "execution_version": 2,
            "protocol_sha256": FROZEN_PROTOCOL_SHA256, "configuration": configuration,
            "records": selected, "reference_environment": reference,
            "input_files": [{"role": role, **row} for role, row in sorted(files.items())],
            "pixel_inputs": _pixel_inputs(selected, protocol), "preserved_files": preserved,
            "upstream_evidence": {"artifact_review_task_id": protocol["artifact_review_task_id"],
                "scientific_checks": 99, "agnes_checks": 54, "runner_regression_tests": 600,
                "original_status": "failed", "original_completion_absent": True,
                "original_budget_reset": False, "candidate_status": "stop",
                "scope": "Bounded accepted upstream chain; original full-source review is not rerun."},
            "dependency_versions": versions,
            "preparation_scope": "Preregistration of two fixed validation inputs; no detector, GPU or model call.",
            "new_detector_calls": 0, "new_gpu_calls": 0, "new_model_requests": 0}


def _read_json_line(line):
    return json.loads(line, object_pairs_hook=_unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"Nonfinite JSON: {value}")))


def _validate_reference(reference):
    expected = {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
                "rect": False, "augment": False, "agnostic_nms": False, "quantize": None, "nms": None}
    if (type(reference) is not dict or not _equal(reference.get("actual_predictor_options"), expected)
            or reference.get("precision") != "FP32" or reference.get("device") != "0"
            or reference.get("actual_predictor_device") != "cuda:0"
            or reference.get("actual_predictor_fp16") is not False
            or reference.get("tf32_matmul") is not False or reference.get("tf32_cudnn") is not False
            or reference.get("cudnn_benchmark") is not False or reference.get("cudnn_deterministic") is not True
            or not _equal(reference.get("actual_predictor_imgsz"), [640, 640])
            or reference.get("model_parameters_dtype") != "torch.float32"):
        raise ValueError("Reference exact external-NMS FP32 controls differ")


def validate_registration(value, fresh=True):
    """Check exact typed registration and optionally freshly rederive every byte.

    fresh=False checks structure only; it never attests to current source bytes.
    """
    protocol = read_protocol()
    if type(value) is not dict or value.keys() != MANIFEST_KEYS:
        raise ValueError("Registration schema has missing/unexpected fields")
    for key, expected in {"schema_version": 1, "execution_version": 2, "tool": TOOL, "purpose": PURPOSE,
                          "protocol_sha256": FROZEN_PROTOCOL_SHA256, "new_detector_calls": 0,
                          "new_gpu_calls": 0, "new_model_requests": 0}.items():
        if not _equal(value[key], expected):
            raise ValueError(f"Registration contract differs: {key}")
    _configuration(value["configuration"])
    _validate_reference(value["reference_environment"])
    records = value["records"]
    if (type(records) is not list or len(records) != 2
            or any(type(record) is not dict for record in records)
            or [r.get("image_id") for r in records] != protocol["image_ids"]
            or any(type(r.get("ground_truth")) is not list for r in records)
            or [len(r.get("ground_truth", [])) for r in records] != [0, 1]
            or any(r.get("split") != "val" or type(r.get("width")) is not int or r["width"] != 1920
                   or type(r.get("height")) is not int or r["height"] != 1080 for r in records)):
        raise ValueError("Registration fixed image selection differs")
    for collection, extra in ((value["input_files"], {"role"}), (value["preserved_files"], set())):
        if type(collection) is not list or not collection:
            raise ValueError("Registration lacks immutable file identities")
        seen = set()
        for row in collection:
            if (type(row) is not dict or row.keys() != IDENTITY_KEYS | extra
                    or type(row["path"]) is not str or not Path(row["path"]).is_absolute()
                    or type(row["size_bytes"]) is not int or row["size_bytes"] < 0
                    or type(row["sha256"]) is not str or not re.fullmatch(r"[0-9a-f]{64}", row["sha256"])):
                raise ValueError("Registration malformed file identity")
            key = row["role"] if extra else row["path"]
            if type(key) is not str or not key or key in seen:
                raise ValueError("Registration duplicate file role/path")
            seen.add(key)
    pixels = value["pixel_inputs"]
    if type(pixels) is not list or len(pixels) != 18:
        raise ValueError("Registration requires exactly eighteen pixel observations")
    expected_crops = [[0, 0, 1920, 1080]] + [[x, y, x + 640, y + 640]
                     for y in protocol["tile_grid"]["y"] for x in protocol["tile_grid"]["x"]]
    for index, row in enumerate(pixels):
        image_id, pass_id = protocol["image_ids"][index // 9], index % 9
        if (type(row) is not dict or row.keys() != {"image_id", "pass_id", "crop", "source_image_sha256", "decoded_image_sha256", "input_pixels_sha256"}
                or row["image_id"] != image_id or type(row["pass_id"]) is not int or row["pass_id"] != pass_id
                or not _equal(row["crop"], expected_crops[pass_id])
                or row["source_image_sha256"] != protocol["preregistered_inputs"][image_id + "/image"]
                or any(type(row[key]) is not str or not re.fullmatch(r"[0-9a-f]{64}", row[key])
                       for key in ("decoded_image_sha256", "input_pixels_sha256"))):
            raise ValueError("Registration duplicate/out-of-order/changed pixel identity")
    expected_upstream = {"artifact_review_task_id": protocol["artifact_review_task_id"],
        "scientific_checks": 99, "agnes_checks": 54, "runner_regression_tests": 600,
        "original_status": "failed", "original_completion_absent": True,
        "original_budget_reset": False, "candidate_status": "stop",
        "scope": "Bounded accepted upstream chain; original full-source review is not rerun."}
    if not _equal(value["upstream_evidence"], expected_upstream):
        raise ValueError("Registration changed upstream status/count/scope")
    if (type(value["dependency_versions"]) is not dict
            or value["dependency_versions"].keys() != {"torch", "ultralytics", "numpy", "cv2"}
            or any(type(v) is not str or not v for v in value["dependency_versions"].values())):
        raise ValueError("Registration malformed dependency versions")
    if fresh:
        expected = _derive_registration(value["configuration"])
        if not _equal(value, expected):
            raise ValueError("Registration differs from freshly verified fixed inputs or upstream evidence")
    return value


def prepare_protocol(output_path, configuration=None):
    """Write a new caller-created preparation path exactly once; zero GPU work."""
    output_path = Path(output_path).resolve()
    output_root = Path(_configuration(configuration)["output_root"])
    if (not output_path.is_relative_to(output_root) or not output_path.parent.is_dir()
            or output_path.exists() or any((output_path.parent / name).exists()
                 for name in ("completion.json", "failure.json"))):
        raise ValueError("Preparation requires a new file in a caller-created project outputs directory")
    value = _derive_registration(configuration)
    validate_registration(value, fresh=False)
    with output_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "outputs/sliced-business-preparation-v2/input_manifest.json")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    value = prepare_protocol(args.output)
    print(json.dumps({"status": "prepared", "output": str(args.output.resolve()),
                      "protocol_sha256": value["protocol_sha256"], "images": len(value["records"]),
                      "pixel_observations": len(value["pixel_inputs"]), "new_detector_calls": 0,
                      "new_gpu_calls": 0, "new_model_requests": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
