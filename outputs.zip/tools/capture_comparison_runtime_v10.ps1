param([Parameter(Mandatory=$true)][string]$Manifest)
$ErrorActionPreference = 'Stop'
$taskManifestPath = [IO.Path]::GetFullPath($Manifest)
$taskManifest = Get-Content -LiteralPath $taskManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($taskManifest.status -ne 'passed_local_repair' -or $taskManifest.local_runtime_build.exit_code -ne 0) { throw 'Successful modified runtime build required' }
$taskBuild = Get-Item -LiteralPath $taskManifest.local_runtime_build.path
if ((Get-FileHash -LiteralPath $taskBuild.FullName -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskManifest.local_runtime_build.sha256) { throw 'Build receipt bytes changed' }
$taskProject = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskCli = [IO.Path]::GetFullPath((Join-Path $taskProject '..\agnes-harness\packages\cli\dist\local'))
$taskProcesses = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -eq 'node.exe' -and $_.CommandLine -like ('*' + $taskCli + '*') })
$taskRows = @()
foreach ($taskRole in @('web','daemon','worker')) {
    $taskBundleName = if ($taskRole -eq 'web') { 'agnes.mjs' } else { $taskRole + '.mjs' }
    $taskMatches = @($taskProcesses | Where-Object { $_.CommandLine -like ('*' + (Join-Path $taskCli $taskBundleName) + '*') })
    if ($taskMatches.Count -ne 1) { throw ('Expected one owned process for ' + $taskRole) }
    $taskProcess = $taskMatches[0]
    $taskRows += [ordered]@{ role=$taskRole; pid=[int]$taskProcess.ProcessId; parent_pid=[int]$taskProcess.ParentProcessId; executable=$taskProcess.ExecutablePath; command_line=$taskProcess.CommandLine; started_at=$taskProcess.CreationDate.ToUniversalTime().ToString('o') }
}
$taskListeners = @(Get-NetTCPConnection -LocalPort 4177 -State Listen)
if ($taskListeners.Count -lt 1 -or @($taskListeners | Where-Object { $_.OwningProcess -ne $taskRows[0].pid }).Count -ne 0) { throw 'Web listener process identity differs' }
$taskBundles = @()
foreach ($taskBundleName in @('agnes.mjs','daemon.mjs','worker.mjs')) {
    $taskPath = Join-Path $taskCli $taskBundleName
    $taskPin = @($taskManifest.runtime_files | Where-Object { $_.path -eq $taskPath })
    if ($taskPin.Count -ne 1) { throw 'Runtime bundle pin absent' }
    $taskHash = (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskHash -ne $taskPin[0].sha256) { throw 'Runtime bundle bytes changed' }
    $taskBundles += [ordered]@{path=$taskPath; sha256=$taskHash}
}
[ordered]@{captured_at=[DateTime]::UtcNow.ToString('o'); web_port=4177; web_port_owner_pid=$taskRows[0].pid; processes=$taskRows; bundles=$taskBundles; build_completed_at=$taskBuild.LastWriteTimeUtc.ToString('o')} | ConvertTo-Json -Depth 6 -Compress
