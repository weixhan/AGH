// Observe the already-running final answer after a collector error; never prompt or launch another task.
import { readFile, writeFile } from 'node:fs/promises';
import { exportSession } from '../../agnes-harness/packages/cli/src/commands/export.ts';
import { webClient } from './agh_ws_client.mjs';
const output = 'outputs/agh-resolution-comparison';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
const snapshot = (await readFile(output + '/collection-attempt-1-session.jsonl', 'utf8')).trim().split('\n').map(JSON.parse);
const afterSeq = snapshot.filter(row => row.type === 'turn/end').at(-1).seq;
const record = { status: 'observing', started_at: new Date().toISOString(), session_id: launch.session_id,
  task_id: launch.task_id, existing_task_only: true, no_new_inference_task: true, no_prompt_sent: true, afterSeq, calls: [], results: [] };
const path = output + '/observation.json';
await writeFile(path, JSON.stringify(record, null, 2) + '\n', { flag: 'wx' });
const save = () => writeFile(path, JSON.stringify(record, null, 2) + '\n');
const client = await webClient();
let iterator, timer;
try {
  const session = await client.session.load(launch.session_id, { cwd: process.cwd(), onPermissionRequest: async () => ({ verdict: 'rejected' }) });
  iterator = session.events()[Symbol.asyncIterator]();
  const reading = (async () => {
    for (;;) {
      const next = await iterator.next();
      if (next.done) throw new Error('Event stream ended without terminal turn');
      const event = next.value;
      if (event.seq <= afterSeq) continue;
      if (event.type === 'tool/call') record.calls.push({ seq: event.seq, name: event.data.name, args: event.data.args, origin: event.origin });
      if (event.type === 'tool/result') {
        const text = event.data.content?.find(item => item.type === 'text')?.text;
        if (text) { try { record.results.push(JSON.parse(text)); } catch { /* official export retains it */ } }
      }
      await save();
      if (event.type === 'turn/end') { record.turn_end = event.data; break; }
    }
  })();
  await Promise.race([reading, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('No terminal turn after 180 seconds')), 180_000); })]);
  if (record.turn_end?.reason !== 'completed') throw new Error('Observed model turn did not complete');
  record.status = 'completed';
} catch (error) {
  record.status = 'failed'; record.failure = { type: error.name, message: error.message }; process.exitCode = 1;
} finally {
  clearTimeout(timer);
  await client.close();
  await iterator?.return?.();
  for (const [format, filename] of [['agnes', 'session-final.jsonl'], ['html', 'session-final.html']]) {
    const reader = await webClient();
    try {
      await exportSession({ positional: [launch.session_id], format, raw: false, out: output + '/' + filename }, {
        cwd: process.cwd(), io: { stdout: process.stdout, stderr: process.stderr },
        writeFile: (file, bytes) => writeFile(file, bytes, { flag: 'wx' }),
      }, reader);
    } finally { await reader.close(); }
  }
  record.finished_at = new Date().toISOString(); await save();
  console.log(JSON.stringify({ status: record.status, task_id: record.task_id, failure: record.failure }));
}
