"""Serve a real local CPU evidence panel; its Run button executes the ZIP smoke."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
import threading
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "outputs" / "submission-bundle-v1-r1-exclusive"
EXPECTED_ZIP_SHA256 = "7847e78b2c6998a29788b0922a1fbe6e42f7087fb777274737f40b5bf2c06f61"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--port", type=int, default=8766)
    args = parser.parse_args()
    destination = args.output.resolve()
    if destination.parent != (ROOT / "outputs").resolve() or not destination.name.startswith("actual-demo-v1"):
        raise ValueError("Demo output must be a new actual-demo-v1* directory under outputs")
    if destination.exists():
        raise FileExistsError("Demo output exists; preserve it and choose a new directory")
    archive = BUNDLE / "DefectResearcher-CPU-v1.zip"
    receipt_path = BUNDLE / "build_receipt.json"
    source = json.loads(receipt_path.read_text(encoding="utf-8"))
    if digest(archive) != EXPECTED_ZIP_SHA256 or source["status"] != "passed_cpu_bundle":
        raise ValueError("Accepted CPU bundle binding differs")
    destination.mkdir(parents=True, exist_ok=False)
    extract = destination / "extracted"
    extract.mkdir()
    with zipfile.ZipFile(archive) as zipped:
        if any(not (extract / row.filename).resolve().is_relative_to(extract) for row in zipped.infolist()):
            raise ValueError("Archive path escapes demonstration root")
        zipped.extractall(extract)
    package = extract / "DefectResearcher-CPU-v1"
    binding = {"schema_version": 1, "source_zip": str(archive), "source_zip_sha256": EXPECTED_ZIP_SHA256,
               "source_receipt": str(receipt_path), "source_receipt_sha256": digest(receipt_path),
               "new_extracted_root": str(package), "scope": "Real CPU tools; local evidence panel is not the AGH interface"}
    write_json(destination / "source_binding.json", binding)
    state = {"phase": "idle", "run_id": None, "result": None, "error": None}
    lock = threading.Lock()

    def event(kind, **details):
        with (destination / "demo-events.jsonl").open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"at": datetime.now(timezone.utc).isoformat(), "event": kind, **details}, ensure_ascii=False) + "\n")

    def execute(identifier):
        evidence = destination / "runs" / identifier
        event("real_cpu_smoke_started", run_id=identifier)
        process = subprocess.run([sys.executable, "-I", "-S", "-B", "tools/migration_smoke_v1.py", "--output", str(evidence)],
                                 cwd=package, capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
        (destination / (identifier + "-stdout.log")).write_text(process.stdout, encoding="utf-8")
        (destination / (identifier + "-stderr.log")).write_text(process.stderr, encoding="utf-8")
        path = evidence / "migration_acceptance.json"
        result = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None
        passed = process.returncode == 0 and result and result.get("status") == "passed"
        with lock:
            state.update(phase="passed" if passed else "failed", result=result,
                         error=None if passed else process.stderr[-2000:], evidence=str(path))
        event("real_cpu_smoke_finished", run_id=identifier, exit_code=process.returncode,
              status="passed" if passed else "failed", evidence=str(path), sha256=digest(path) if path.exists() else None)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def send(self, value, status=200):
            payload = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)

        def do_GET(self):
            if self.path == "/":
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write((ROOT / "tools" / "demo_evidence_v1.html").read_bytes())
            elif self.path == "/api/status":
                with lock:
                    result = state["result"] or {}
                    response = {"phase": state["phase"], "run_id": state["run_id"], "error": state["error"],
                                "zip_sha256": EXPECTED_ZIP_SHA256, "zip_bytes": source["archive"]["size_bytes"],
                                "groups": result.get("groups"), "case_outcomes": result.get("case_outcomes", []),
                                "geometry_counts": result.get("geometry_counts"), "checks": result.get("checks", {}),
                                "independent_reviews": result.get("independent_case_reviews", []),
                                "elapsed_seconds": result.get("elapsed_seconds"), "guard_attempts": result.get("guard_attempts"),
                                "unintended_modification_cases": result.get("unintended_modification_cases"),
                                "actual_repair_cases": result.get("actual_repair_cases"),
                                "model_calls": result.get("model_calls"), "gpu_tasks": result.get("gpu_tasks")}
                self.send(response)
            elif self.path.startswith("/api/case/"):
                identifier = self.path.split("/")[-1]
                with lock:
                    result = state["result"] or {}
                    selected = next((row for row in result.get("case_outcomes", []) if row["case_id"] == identifier), None)
                    run_id = state["run_id"]
                if not selected:
                    self.send({"error": "Actual completed case not found"}, 404)
                    return
                base = destination / "runs" / run_id / "labelguard"
                actual = json.loads((base / "acceptance.json").read_text(encoding="utf-8"))
                row = next(item for item in actual["cases"] if item["case_id"] == identifier)
                task = base / "tasks" / identifier / identifier
                changes = [json.loads(line) for line in (task / "repair_changes.jsonl").read_text(encoding="utf-8").splitlines()]
                golden = json.loads((base / "inputs" / identifier / "frozen_inputs.json").read_text(encoding="utf-8"))
                labels = [{"path": name, "before": (Path(row["configuration"]["dataset_root"]) / name).read_text(encoding="utf-8")
                           if (Path(row["configuration"]["dataset_root"]) / name).exists() else None,
                           "expected": value} for name, value in golden["golden_labels"].items() if value]
                review_path = destination / "runs" / run_id / (identifier + "-independent.json")
                review = json.loads(review_path.read_text(encoding="utf-8"))
                self.send({"outcome": selected, "summary": row["summary"], "changes": changes,
                           "labels": labels, "checks": row["checks"], "independent_checks": review.get("checks", {}),
                           "evidence_hash": digest(review_path)})
                event("actual_case_evidence_read", run_id=run_id, case_id=identifier)
            else:
                self.send({"error": "Not found"}, 404)

        def do_POST(self):
            if self.headers.get("Origin") not in (None, f"http://127.0.0.1:{self.server.server_port}"):
                self.send({"error": "Local origin required"}, 403)
                return
            if self.path != "/api/run":
                self.send({"error": "Not found"}, 404)
                return
            with lock:
                if state["phase"] == "running":
                    self.send({"error": "A real run is already active"}, 409)
                    return
                identifier = "demo-" + uuid.uuid4().hex
                state.update(phase="running", run_id=identifier, result=None, error=None)
            threading.Thread(target=execute, args=(identifier,), daemon=True).start()
            self.send({"status": "started", "run_id": identifier}, 202)

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    write_json(destination / "server.json", {"url": f"http://127.0.0.1:{server.server_port}", "output": str(destination),
        "scope": "Loopback only, no credentials, no model/GPU calls, no external publishing"})
    print(f"Local real CPU evidence panel: http://127.0.0.1:{server.server_port}", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
