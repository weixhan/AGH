"""Read-only independent artifact and recovery review, without detector imports.

Journal admission, source/GT checks and recovery comparisons are implemented here
separately from the coordinator. AP is recomputed with detection_metrics; this
is not a second independently implemented AP algorithm.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from defect_researcher.detection_metrics import score_detections, compare_scores
from tools.verify_resolution_run import CLASSES, FROZEN, png_dimensions, ground_truth

STEPS = {'reference_640':640,'reference_960':960,'fault_640':640,'fault_960':960,'resume_960':960}
TOOL = 'verify_full_resolution_step_recovery_v1'
PURPOSE = 'full-val-known-cost-second-group-step-recovery-v1'
BUDGET = {'max_prediction_calls':3205,'max_formal_calls':3200,'max_warmup_calls':5,
          'max_recovery_attempts':1,'max_task_wall_seconds':1800,'max_gpu_seconds':300}
FAULT = {'step_id':'fault_960','max_injections':1,
         'boundary':'after_all_predictions_and_metrics_closed_before_step_completion'}
TOLERANCES = {'xyxy_absolute_pixels':1e-4,'confidence_absolute':1e-6,'metric_absolute':1e-10,'relative':0}
GROUP_FILES = {'predictions.jsonl','environment.json','metrics.json','step_verification.json'}
# UTC is sampled next to a monotonic counter; NTFS/Windows clocks can round.
# This fixed allowance never extends the original task deadline or GPU cap.
TIMING_ABSOLUTE_SECONDS = .05
COORDINATION_FILES = {'shared_prediction_writer.lock'}
SOURCE_PATHS = (
    'defect_researcher/resolution_recovery_coordinator_v1.py',
    'defect_researcher/resolution_recovery_backend_v1.py',
    'defect_researcher/resolution_recovery_ledger_v1.py',
    'tools/verify_resolution_recovery_v1.py', 'tools/verify_resolution_run.py', 'config/local.json',
    'defect_researcher/resolution_comparison.py', 'fixtures/resolution_protocol.json',
    'defect_researcher/detection_metrics.py', 'defect_researcher/audit.py',
    'defect_researcher/config.py', 'defect_researcher/geometry_verifier.py',
    'defect_researcher/independent_geometry.py',
    'defect_researcher/resolution_research_mcp_v1.py',
    'defect_researcher/resolution_research_mcp_server_v1.py', 'run_resolution_research_mcp_v1.py',
    'fixtures/resolution_research_mcp_protocol_v1.json', 'tools/resolution_research_scope_guard_v1.mjs',
)
CALLABLE_PATHS = {'YOLO.predict':'ultralytics/engine/model.py',
    'BasePredictor.preprocess':'ultralytics/engine/predictor.py',
    'BasePredictor.inference':'ultralytics/engine/predictor.py',
    'BasePredictor.setup_source':'ultralytics/engine/predictor.py',
    'DetectionPredictor.postprocess':'ultralytics/models/yolo/detect/predict.py',
    'scale_boxes':'ultralytics/utils/ops.py', 'NMS':'ultralytics/utils/nms.py'}
DEPENDENCY_SOURCES = {
    'torch':('torch/__init__.py','torch/version.py','torch/_utils.py','torch/serialization.py',
        'torch/cuda/__init__.py','torch/nn/modules/module.py','torch/backends/cuda/__init__.py',
        'torch/backends/cudnn/__init__.py'),
    'ultralytics':('ultralytics/__init__.py','ultralytics/cfg/__init__.py','ultralytics/engine/model.py',
        'ultralytics/engine/predictor.py','ultralytics/models/yolo/detect/predict.py',
        'ultralytics/nn/autobackend.py','ultralytics/nn/tasks.py','ultralytics/utils/__init__.py',
        'ultralytics/utils/ops.py','ultralytics/utils/nms.py','ultralytics/data/loaders.py',
        'ultralytics/data/augment.py'),
    'numpy':('numpy/__init__.py',), 'opencv':('cv2/__init__.py',),
}
AUDIT_FILES = {'dataset_check.json','val_accessibility.json','checker.log','events.jsonl','audit_result.json'}
GEOMETRY_FILES = {'verification_result.json','geometry_details.jsonl','fixture_results.json','input_manifest.json','events.jsonl'}
ROOT_REQUIRED = {'registration.json','preparation_receipt.json','protocol.json','input_manifest.json',
    'source_lock.json','ledger_registration.json','execution_events.json','staged_preflight_receipt.json',
    'shared_prediction_journal.jsonl','budget_final.json','recovery_result.json',
    'fault_tree_before_resume.json','fault_tree_after_resume.json','resume_receipt.json'}
POST_CANDIDATE = {'completion_candidate.json','independent_verification.json','artifact_manifest.json',
    'completion.json','fixture_only_result.json'}

def require(condition, message):
    if condition is not True: raise ValueError(message)

def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf8')

def digest(value): return hashlib.sha256(canonical(value)).hexdigest()

def decode(text):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'Duplicate JSON key');result[key]=value
        return result
    result=json.loads(text,object_pairs_hook=pairs,
        parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))
    canonical(result)
    return result

def read(path): return decode(Path(path).read_text('utf-8-sig'))

def lines(path):
    raw=Path(path).read_bytes();require(bool(raw) and raw.endswith(b'\n'),'Empty or incomplete JSONL')
    return [decode(line) for line in raw.splitlines()]

def finite(value,positive=False):
    return type(value) in (int,float) and math.isfinite(value) and (value>0 if positive else value>=0)

def utc_epoch(value):
    require(type(value) is str,'UTC timestamp is not a string')
    stamp=datetime.fromisoformat(value.replace('Z','+00:00'))
    require(stamp.tzinfo is not None and stamp.utcoffset().total_seconds()==0,'Timestamp requires UTC')
    require(math.isfinite(stamp.timestamp()),'Nonfinite timestamp')
    return stamp.timestamp()

def safe(path,parent=None):
    path=Path(path).absolute()
    for member in (path,*path.parents):
        require(not member.is_symlink() and not (hasattr(member,'is_junction') and member.is_junction()),'Linked evidence path')
    path=path.resolve(strict=True)
    if parent is not None:require(path.is_relative_to(Path(parent).resolve()),'Evidence escaped task')
    return path

def pin(path):
    path=safe(path);raw=path.read_bytes()
    return {'name':path.name,'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'size_bytes':len(raw)}

def bound(row,parent=None):
    actual=pin(safe(row['path'],parent))
    require(all(type(row.get(key)) is type(value) and row[key]==value for key,value in actual.items()),'Pinned bytes/path differ: '+actual['path'])
    return actual

def typed_equal(a,b):
    if type(a) is not type(b):return False
    if type(a) is dict:
        return a.keys()==b.keys() and all(type(k) is type(next(v for v in b if v==k))
            and typed_equal(a[k],b[k]) for k in a)
    if type(a) is list:return len(a)==len(b) and all(typed_equal(x,y) for x,y in zip(a,b))
    return a==b

def chain(directory,tool,binding=None,expected=None,task_id=None):
    directory=safe(directory)
    marker,manifest=read(directory/'completion.json'),read(directory/'artifact_manifest.json')
    require(marker.get('status')=='completed' and manifest.get('status')=='completed'
        and marker.get('tool')==manifest.get('tool')==tool
        and marker.get('task_id')==manifest.get('task_id')
        and type(marker.get('task_id')) is str and bool(marker['task_id']),'Step identity/status differs')
    require(Path(marker['artifact_manifest']).resolve()==directory/'artifact_manifest.json'
        and marker['artifact_manifest_sha256']==pin(directory/'artifact_manifest.json')['sha256'],'Manifest binding differs')
    if binding is not None:require(typed_equal(marker.get('binding'),binding) and typed_equal(manifest.get('binding'),binding),'Step context differs')
    owner=task_id if task_id is not None else binding.get('task_id') if binding is not None else None
    if owner is not None:require(marker['task_id']==owner,'Completion belongs to a different task')
    rows=manifest['files'];require(type(rows) is list and bool(rows),'Empty artifact manifest')
    names=[row['name'] for row in rows]
    require(len(set(names))==len(names),'Duplicate artifacts')
    if expected is not None:require(set(names)==expected,'Step artifact population differs')
    for row in rows:
        bound(row,directory);require(Path(row['path']).resolve().parent==directory,'Nested artifact escaped step contract')
    require(marker.get('artifacts_sha256')=={row['name']:row['sha256'] for row in rows},'Marker file set differs')
    require({p.name for p in directory.iterdir() if p.is_file() and p.name not in COORDINATION_FILES}
        ==set(names)|{'completion.json','artifact_manifest.json'},'Unbound step artifact population')
    require((directory/'completion.json').stat().st_mtime_ns>=max((directory/name).stat().st_mtime_ns for name in ['artifact_manifest.json',*names]),'Completion not published last')
    return {'completion':pin(directory/'completion.json'),'manifest':pin(directory/'artifact_manifest.json'),'files':rows}

def inspect_journal(path,registration):
    """A separate parser; deliberately does not import the runtime ledger."""
    require(type(registration) is dict and set(registration)=={'budgets','image_ids','started_epoch','started_monotonic'}
        and typed_equal(registration['budgets'],BUDGET)
        and all(finite(registration[k]) for k in ('started_epoch','started_monotonic')),'Shared registration schema differs')
    ids=registration['image_ids']
    require(type(ids) is list and len(ids)==640 and all(type(v) is str and bool(v.strip()) for v in ids)
        and len(set(ids))==640 and ids==sorted(ids),'Shared full member identity differs')
    rows=lines(path);require(len(rows)==6410,'Five complete groups need 6410 journal events')
    previous='0'*64;calls=[];pending=None;gpu=elapsed=0.;heads={}
    intervals=[];reservation=None
    last_epoch,last_mono=registration['started_epoch'],registration['started_monotonic']
    row_keys={'schema_version','sequence','previous_sha256','registration_sha256','event','at_epoch','at_monotonic','wall_seconds','payload','sha256'}
    for index,row in enumerate(rows,1):
        require(type(row) is dict and set(row)==row_keys,'Journal row schema differs')
        require(type(row['schema_version']) is int and row['schema_version']==1 and type(row['sequence']) is int and row['sequence']==index,'Journal sequence differs')
        require(row['previous_sha256']==previous and row['registration_sha256']==digest(registration)
            and row['sha256']==digest({k:v for k,v in row.items() if k!='sha256'}),'Journal hash chain differs')
        epoch,mono,wall=row['at_epoch'],row['at_monotonic'],row['wall_seconds']
        require(all(finite(v) for v in (epoch,mono,wall)) and epoch>=last_epoch and mono>=last_mono
            and wall==max(epoch-registration['started_epoch'],mono-registration['started_monotonic'])
            and wall<1800,'Original journal clock escaped or reset')
        payload=row['payload']
        if index%2:
            require(row['event']=='reserved' and pending is None and gpu<300,'Reservation/cost order differs')
            call_index=(index+1)//2;group_index,offset=divmod(call_index-1,641)
            step=list(STEPS)[group_index]
            expected={'call_index':call_index,'kind':'warmup' if offset==0 else 'formal',
                'step_id':step,'image_id':registration['image_ids'][max(0,offset-1)],'imgsz':STEPS[step]}
            require(typed_equal(payload,expected),'Persisted group/member order differs')
            pending=payload;reservation=row
        else:
            require(row['event']=='closed' and type(payload) is dict and set(payload)=={'ticket','status','elapsed_seconds','gpu_seconds','cost_known','details'},'Closed receipt schema differs')
            require(typed_equal(payload['ticket'],pending) and payload['status']=='passed' and payload['cost_known'] is True,'Open, failed or unknown-cost call')
            require(finite(payload['elapsed_seconds'],True) and finite(payload['gpu_seconds'])
                and payload['gpu_seconds']<=payload['elapsed_seconds']+.05,'Invalid synchronized cost')
            detail=payload['details']
            required={'utc_started','utc_finished','cost_known','prediction_entered','prediction_returned','step_id','image_id','imgsz','kind','error_type','error_message','timing_error_type'}
            require(type(detail) is dict and set(detail)==required,'Actual prediction receipt schema differs')
            require(all(detail.get(k) is True for k in ('cost_known','prediction_entered','prediction_returned'))
                and all(detail.get(k) is None for k in ('error_type','error_message','timing_error_type'))
                and all(typed_equal(detail[k],pending[k]) for k in ('step_id','image_id','imgsz','kind')),'Actual prediction receipt differs')
            start,end=(utc_epoch(detail[k]) for k in ('utc_started','utc_finished'))
            require(reservation['at_epoch']-TIMING_ABSOLUTE_SECONDS<=start<=end<=epoch+TIMING_ABSOLUTE_SECONDS
                and abs(end-start-payload['elapsed_seconds'])<=TIMING_ABSOLUTE_SECONDS
                and payload['elapsed_seconds']<=mono-reservation['at_monotonic']+TIMING_ABSOLUTE_SECONDS,
                'Actual UTC/elapsed receipt escaped its reservation and close clocks')
            gpu+=payload['gpu_seconds'];elapsed+=payload['elapsed_seconds']
            intervals.append({'reserved_epoch':reservation['at_epoch'],'closed_epoch':epoch,
                'reserved_monotonic':reservation['at_monotonic'],'closed_monotonic':mono})
            calls.append(payload);pending=None
            if len(calls)%641==0:heads[len(calls)]=row['sha256']
        previous=row['sha256'];last_epoch,last_mono=epoch,mono
    require(pending is None and len(calls)==3205 and gpu<=300 and elapsed<=1800,'Shared task budgets exceeded')
    require(elapsed<=rows[-1]['wall_seconds']+TIMING_ABSOLUTE_SECONDS,'Prediction cost exceeds original task wall')
    return {'calls':calls,'intervals':intervals,'gpu_seconds':gpu,'elapsed_seconds':elapsed,'heads':heads,
            'journal_head_sha256':previous,'journal_events':len(rows),'last_wall':rows[-1]['wall_seconds']}

def near(a,b,tolerance):
    if type(a) is dict:return type(b) is dict and a.keys()==b.keys() and all(near(a[k],b[k],tolerance) for k in a)
    if type(a) is list:return type(b) is list and len(a)==len(b) and all(near(x,y,tolerance) for x,y in zip(a,b))
    if type(a) is float or type(b) is float:
        return type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and abs(a-b)<=tolerance
    return typed_equal(a,b)

def trusted_configuration():
    """Resolve the pinned distributed configuration; never use model/env paths."""
    value=read(ROOT/'config/local.json')
    keys=('research_root','dataset_root','raw_root','split_dir','weights_path','output_root')
    require(type(value) is dict and set(value)==set(keys)|{'schema_version'}
        and type(value['schema_version']) is int and value['schema_version']==1,'Trusted configuration schema differs')
    result={}
    for key in keys:
        raw=value[key];require(type(raw) is str and bool(raw.strip()),'Trusted path is empty')
        for reference,replacement in result.items():raw=raw.replace('${'+reference+'}',replacement)
        require('${' not in raw,'Unresolved trusted path')
        path=Path(raw).expanduser()
        result[key]=str((path if path.is_absolute() else ROOT/path).resolve())
    return result

def inspect_dependencies(identity):
    """Read installed distribution metadata and native files, without GPU imports."""
    require(type(identity) is dict and set(identity)=={'python','python_executable','packages','sys_path'},
        'Runtime identity schema differs')
    require(identity['python']==platform.python_version()
        and safe(identity['python_executable'])==Path(sys.executable).resolve()
        and type(identity['sys_path']) is list and all(type(v) is str for v in identity['sys_path']),
        'Python implementation identity differs')
    packages=identity['packages']
    require(type(packages) is dict and set(packages)==set(DEPENDENCY_SOURCES),'Dependency population differs')
    opencv=[]
    for name in ('opencv-python','opencv-python-headless','opencv-contrib-python','opencv-contrib-python-headless'):
        try:opencv.append((name,importlib.metadata.distribution(name)))
        except importlib.metadata.PackageNotFoundError:pass
    require(len(opencv)==1,'Exactly one OpenCV implementation is required')
    patterns={'torch':r'torch/_C[^/]*\.pyd','numpy':r'numpy/_core/_multiarray_umath[^/]*\.pyd',
        'opencv':r'cv2/(?:[^/]+/)*cv2[^/]*\.pyd'}
    expected={Path(sys.executable).resolve()}
    for name,critical in DEPENDENCY_SOURCES.items():
        distribution=opencv[0][1] if name=='opencv' else importlib.metadata.distribution(name)
        listed=[v.as_posix() for v in (distribution.files or [])]
        metadata=[v for v in listed if v.endswith(('.dist-info/METADATA','.dist-info/RECORD'))]
        require(len(metadata)==2,'Missing or ambiguous installed dependency metadata')
        selected=[*critical,*metadata]
        if name in patterns:
            native=[v for v in listed if re.fullmatch(patterns[name],v)]
            require(len(native)==1,'Missing or ambiguous installed native dependency');selected+=native
        located=[safe(distribution.locate_file(v)) for v in selected]
        actual={'distribution':opencv[0][0] if name=='opencv' else name,'version':distribution.version,
            'root':str(safe(distribution.locate_file(''))),'critical_files':[str(v) for v in located]}
        require(typed_equal(packages[name],actual),'Installed dependency identity differs: '+name)
        require(all(v.is_file() for v in located),'Dependency member is not a file')
        expected.update(located)
    return expected

def inspect_sources(lock,config,fixture):
    require(type(lock) is dict and set(lock)=={'schema_version','task_id','files','execution_source_sha256',
        'runtime_identity','runtime_identity_sha256'} and type(lock['schema_version']) is int
        and lock['schema_version']==1,'Execution source lock schema differs')
    files=lock['files']
    require(type(files) is list and bool(files) and lock['execution_source_sha256']==digest(files),
        'Execution source digest differs')
    require(lock['runtime_identity_sha256']==digest(lock['runtime_identity']),'Runtime identity digest differs')
    observed={}
    for row in files:
        require(type(row) is dict and set(row)=={'name','path','sha256','size_bytes'},'Execution source pin schema differs')
        actual=bound(row);path=Path(actual['path'])
        require(path not in observed,'Duplicate execution source');observed[path]=actual
    if fixture:
        require(typed_equal(lock['runtime_identity'],{'fixture_only':True}),'Fixture runtime identity differs')
    else:
        require(typed_equal(config,trusted_configuration()),'Production trusted paths differ')
        expected={ROOT/value for value in SOURCE_PATHS}
        expected.update({Path(config['research_root'])/'cableinspect_geometry.py',
            Path(config['research_root'])/'数据处理/7检查YOLO标注数据.py'})
        expected.update(inspect_dependencies(lock['runtime_identity']))
        require(set(observed)=={safe(v) for v in expected},'Exact execution source/dependency closure differs')
    return observed

def inspect_environment_sources(environment,lock,source_rows,fixture):
    if fixture:
        require(environment.get('callable_sources')=={},'Fixture cannot claim installed real callable sources')
        return
    backend=ROOT/'defect_researcher/resolution_recovery_backend_v1.py'
    require(typed_equal(environment.get('backend_source'),source_rows[backend]),'Backend implementation pin differs')
    callables=environment.get('callable_sources')
    require(type(callables) is dict and set(callables)==set(CALLABLE_PATHS),'Actual callable source population differs')
    root=Path(lock['runtime_identity']['packages']['ultralytics']['root'])
    for key,relative in CALLABLE_PATHS.items():
        require(typed_equal(callables[key],source_rows[root/relative]),'Loaded predictor callable differs: '+key)
    require(environment.get('python')==lock['runtime_identity']['python']
        and Path(environment.get('python_executable','')).resolve()==Path(lock['runtime_identity']['python_executable'])
        and environment.get('torch')==lock['runtime_identity']['packages']['torch']['version']
        and environment.get('ultralytics')==lock['runtime_identity']['packages']['ultralytics']['version'],
        'Loaded runtime version differs from preregistered distribution')

def inspect_group_cost(records,environment,step,journal,fixture=False):
    offset=list(STEPS).index(step)*641;calls=journal['calls'][offset:offset+641]
    require(len(calls)==641 and len(records)==640,'Group actual cost population differs')
    for row,cost in zip(records,calls[1:]):
        require(typed_equal(row.get('elapsed_seconds'),cost['elapsed_seconds'])
            and typed_equal(row.get('gpu_seconds'),cost['gpu_seconds']),'Formal prediction cost differs from its closed ticket')
        speed=row.get('ultralytics_speed_ms')
        require(type(speed) is dict and set(speed)=={'preprocess','inference','postprocess'}
            and all(finite(v) for v in speed.values()),'Actual predictor timing metadata differs')
    warmup=calls[0]
    require(type(environment.get('warmup_images')) is int and environment['warmup_images']==1
        and typed_equal(environment.get('warmup_seconds'),warmup['elapsed_seconds'])
        and typed_equal(environment.get('warmup_gpu_seconds'),warmup['gpu_seconds']),
        'Warmup cost differs from its closed ticket')
    require(near(environment.get('closed_prediction_gpu_seconds'),sum(c['gpu_seconds'] for c in calls),1e-9)
        and near(environment.get('closed_prediction_elapsed_seconds'),sum(c['elapsed_seconds'] for c in calls),1e-9),
        'Group cumulative cost differs from 641 closed tickets')
    duration=environment.get('group_elapsed_seconds')
    window=journal['intervals'][offset+640]['closed_monotonic']-journal['intervals'][offset+1]['reserved_monotonic']
    require(finite(duration,True) and sum(c['elapsed_seconds'] for c in calls[1:])<=duration+TIMING_ABSOLUTE_SECONDS
        and duration<=window+TIMING_ABSOLUTE_SECONDS,'Full formal group timing differs from original clocks')
    require(type(environment.get('actual_current_cuda_device')) is int and environment['actual_current_cuda_device']==0
        and environment.get('prediction_entry')=='YOLO.predict','Missing actual GPU/entry observation')
    if not fixture:
        require(type(environment.get('peak_allocated_bytes')) is int and environment['peak_allocated_bytes']>0,
            'Missing real positive GPU memory observation')

def inspect_inputs(inputs,configuration,fixture=False):
    """Independently validate actual data tree, split, GT and provenance."""
    expected=inputs["records"];ids=[r["image_id"] for r in expected]
    require(type(expected) is list and len(expected)==len(set(ids))==640 and ids==sorted(ids)
        and all(type(v) is str and bool(v.strip()) for v in ids),'Full sorted validation membership differs')
    row_keys={'image_id','width','height','split','image_path','source_path','label_path','metadata_path','ground_truth'}
    require(all(type(row) is dict and set(row)==row_keys and row['split']=='val'
        and type(row['width']) is int and row['width']>0 and type(row['height']) is int and row['height']>0
        and type(row['ground_truth']) is list for row in expected),'Typed full input record schema differs')
    if fixture:return
    require(typed_equal(configuration,trusted_configuration()),'Production configuration differs from fixed local paths')
    require(sum(len(r['ground_truth']) for r in expected)==596,'GT count differs')
    config={k:Path(v).resolve() for k,v in configuration.items()}
    roles=inputs['source_files']
    required_paths={'weights':config['weights_path'],
        'training_manifest':config['weights_path'].parent.parent/'experiment_manifest.json',
        'dataset/manifest.json':config['dataset_root']/'manifest.json',
        'dataset/data.yaml':config['dataset_root']/'data.yaml',
        'comparison_runner':ROOT/'defect_researcher/resolution_comparison.py',
        'comparison_protocol':ROOT/'fixtures/resolution_protocol.json',
        'detection_metrics':ROOT/'defect_researcher/detection_metrics.py',
        'config_loader':ROOT/'defect_researcher/config.py',
        'verifier':ROOT/'defect_researcher/geometry_verifier.py',
        'oracle':ROOT/'defect_researcher/independent_geometry.py',
        'fixtures':ROOT/'fixtures/geometry_cases.json'}
    for cable in ('cable_1','cable_2','cable_3'):required_paths['raw/'+cable+'.json']=config['raw_root']/(cable+'.json')
    for split in ('train','val','test','excluded_buffer'):
        required_paths['splits/'+split+'.txt']=config['split_dir']/(split+'.txt')
        if split!='excluded_buffer':
            for kind in ('labels','metadata'):
                for path in (config['dataset_root']/kind/split).iterdir():
                    require(path.is_file(),'Unexpected member in frozen source tree')
                    required_paths[f'{kind}/{split}/{path.name}']=path
    raw=[Path(s.strip()).resolve() for s in (config['split_dir']/'val.txt').read_text('utf-8-sig').splitlines() if s.strip()]
    require(sorted(p.stem for p in raw)==ids and len(raw)==len(set(raw))==640,'Actual val split differs')
    require(all(safe(p,config['raw_root']).is_file() for p in raw),'Raw split source escaped configured root')
    images=list(safe(config['dataset_root']/'images/val').iterdir())
    require(all(safe(p,config['dataset_root']).is_file() for p in images)
        and {p.name for p in images}=={p.name for p in raw},'Actual validation image tree population differs')
    for kind,suffix in (('labels','.txt'),('metadata','.json')):
        require({p.name for p in (config['dataset_root']/kind/'val').iterdir()}=={p.stem+suffix for p in raw},
            'Actual validation label/metadata tree population differs')
    for split in ('train','test','excluded_buffer'):
        listed=[Path(s.strip()).resolve() for s in (config['split_dir']/(split+'.txt')).read_text('utf-8-sig').splitlines() if s.strip()]
        require(len(listed)==len(set(listed)) and all(safe(p,config['raw_root']).is_file() for p in listed),
            'Duplicate or escaped non-validation split source')
        require(not set(raw)&set(listed),'Validation leaks into another split')
        if split!='excluded_buffer':
            for kind,suffix in (('labels','.txt'),('metadata','.json')):
                require({p.name for p in (config['dataset_root']/kind/split).iterdir()}
                    =={p.stem+suffix for p in listed},'Non-validation label/metadata tree population differs')
    coverage={Path(r['path']).resolve() for r in inputs['source_files'].values()}
    for row in expected:
        image,source,label,metadata=(safe(row[k]) for k in ('image_path','source_path','label_path','metadata_path'))
        require({image,source,label,metadata}<=coverage and source in raw,'Pixel/label source coverage differs')
        require(row['image_id']==source.stem and image==config['dataset_root']/'images/val'/source.name
            and label==config['dataset_root']/'labels/val'/(source.stem+'.txt')
            and metadata==config['dataset_root']/'metadata/val'/(source.stem+'.json'),'Exact image/label/metadata path identity differs')
        w,h=png_dimensions(image);meta=read(metadata)
        require(typed_equal([row['width'],row['height']],[w,h]) and (w,h)==png_dimensions(source)
            and typed_equal([meta['width'],meta['height']],[w,h])
            and meta.get('image')==source.relative_to(config['raw_root']).as_posix()
            and pin(source)['sha256']==pin(image)['sha256'],'Actual pixel dimensions/bytes/metadata source identity differ')
        require(typed_equal(row['ground_truth'],ground_truth(label,w,h)) and row['split']=='val','Independent decoded GT differs')
        required_paths['images/val/'+image.name]=image
        required_paths['raw_images/val/'+source.relative_to(config['raw_root']).as_posix()]=source
    require(set(roles)==set(required_paths) and all(Path(roles[k]['path']).resolve()==v.resolve() for k,v in required_paths.items()),'Actual complete input tree membership differs')
    training=read(config['weights_path'].parent.parent/'experiment_manifest.json');dataset=read(config['dataset_root']/'manifest.json')
    require(training['status']=='completed' and type(training['training_args']['imgsz']) is int and training['training_args']['imgsz']==640
        and type(training['actual_training_args']['imgsz']) is int and training['actual_training_args']['imgsz']==640
        and training['best_weights_sha256']==pin(config['weights_path'])['sha256']==inputs['provenance']['weight_sha256']
        and training['dataset_manifest_sha256']==pin(config['dataset_root']/'manifest.json')['sha256']
        and training['data_yaml_sha256']==pin(config['dataset_root']/'data.yaml')['sha256']
        and typed_equal(training['dataset_manifest'],dataset),'Weight/training/data provenance differs')
    require(training.get('geometry_version')==dataset.get('geometry_version')=='hbb_v1'
        and Path(training.get('data_root','')).resolve()==config['dataset_root']
        and Path(training.get('data_yaml','')).resolve()==config['dataset_root']/'data.yaml'
        and all(Path(training[group].get('data','')).resolve()==config['dataset_root']/'data.yaml'
                for group in ('training_args','actual_training_args')),'Training geometry/data path provenance differs')
    split_hashes={split+'.txt':pin(config['split_dir']/(split+'.txt'))['sha256']
        for split in ('train','val','test','excluded_buffer')}
    require(typed_equal(dataset.get('split_sha256'),split_hashes)
        and typed_equal(training.get('split_sha256'),split_hashes),'Frozen split hashes differ')
    label_trees={}
    for split in ('train','val','test'):
        checksum=hashlib.sha256()
        for path in sorted((config['dataset_root']/'labels'/split).glob('*.txt')):
            checksum.update(path.relative_to(config['dataset_root']).as_posix().encode('utf8')+b'\0')
            checksum.update(path.read_bytes()+b'\0')
        label_trees[split]=checksum.hexdigest()
    require(typed_equal(dataset.get('label_tree_sha256'),label_trees),'Frozen actual label tree hashes differ')
    require(typed_equal(dataset.get('source_sha256'),{cable+'.json':pin(config['raw_root']/(cable+'.json'))['sha256']
        for cable in ('cable_1','cable_2','cable_3')})
        and typed_equal(dataset.get('categories'),{str(i+1):name for i,name in enumerate(CLASSES)}),
        'Frozen raw annotations or class mapping differ')
    require(type(dataset.get('counts',{}).get('val',{}).get('images')) is int
        and dataset['counts']['val']['images']==640
        and type(dataset['counts']['val'].get('annotations')) is int
        and dataset['counts']['val']['annotations']==596,'Frozen validation dataset counts differ')
    import yaml
    data=yaml.safe_load((config['dataset_root']/'data.yaml').read_text('utf-8-sig'))
    require(type(data) is dict and Path(data.get('path','')).resolve()==config['dataset_root']
        and data.get('val')=='images/val' and typed_equal(data.get('names'),dict(enumerate(CLASSES))),
        'Actual data.yaml root/classes/validation path differ')
    provenance={'weight_sha256':pin(config['weights_path'])['sha256'],
        'training_manifest_path':str(config['weights_path'].parent.parent/'experiment_manifest.json'),
        'training_manifest_sha256':pin(config['weights_path'].parent.parent/'experiment_manifest.json')['sha256'],
        'dataset_manifest_sha256':pin(config['dataset_root']/'manifest.json')['sha256'],
        'data_yaml_sha256':pin(config['dataset_root']/'data.yaml')['sha256'],'train_imgsz':640}
    require(typed_equal(inputs['provenance'],provenance),'Full immutable checkpoint/data provenance differs')


def prediction_pair(a,b):
    require(len(a)==len(b)==640,'Paired prediction population differs')
    ignored={'elapsed_seconds','gpu_seconds','ultralytics_speed_ms','predictions'}
    for x,y in zip(a,b):
        require(typed_equal({k:v for k,v in x.items() if k not in ignored},{k:v for k,v in y.items() if k not in ignored}),'Paired scientific input identity differs')
        require(len(x['predictions'])==len(y['predictions']),'Paired predicted box count differs')
        for px,py in zip(x['predictions'],y['predictions']):
            require(set(px)==set(py)=={'class_id','xyxy','confidence'} and typed_equal(px['class_id'],py['class_id'])
                and near(px['xyxy'],py['xyxy'],1e-4) and near(px['confidence'],py['confidence'],1e-6),'Paired prediction tolerance exceeded')

def verify(taskdir,prepublication=True,*,allow_fixture=False):
    directory=safe(taskdir);checks={};errors=[];fixture=False
    def check(name,callback):
        try:callback();checks[name]=True
        except Exception as error:checks[name]=False;errors.append({'check':name,'type':type(error).__name__,'message':str(error)})
    try:
        reg,prep,protocol,inputs,lock,ledger_reg,result,candidate=(read(directory/name) for name in
            ('registration.json','preparation_receipt.json','protocol.json','input_manifest.json','source_lock.json','ledger_registration.json','recovery_result.json','completion_candidate.json'))
        fixture=reg.get('fixture_only') is True
        def registration_check():
            require(type(reg.get('schema_version')) is int and reg['schema_version']==1
                and reg.get('tool')==TOOL and reg.get('purpose')==PURPOSE and reg.get('task_id')==directory.name
                and Path(reg['task_directory']).resolve()==directory,'Task registration identity differs')
            require(typed_equal(reg.get('budgets'),BUDGET) and typed_equal(reg.get('fault_rule'),FAULT) and typed_equal(reg.get('tolerances'),TOLERANCES),'Frozen budgets/fault/tolerance differs')
            require(all(finite(reg.get(k)) for k in ('started_epoch','started_monotonic','deadline_epoch','deadline_monotonic'))
                and reg['deadline_epoch']==reg['started_epoch']+1800 and reg['deadline_monotonic']==reg['started_monotonic']+1800,'Original deadline reset')
            require(type(reg.get('fixture_only')) is bool and (not fixture or allow_fixture is True),'Fixture cannot be real acceptance')
            require(all(typed_equal(protocol.get(k),v) for k,v in {**FROZEN,'nms':None,'quantize':None}.items()),'Frozen FP32 inference protocol differs')
            require(typed_equal(protocol,{**read(ROOT/'fixtures/resolution_protocol.json'),'nms':None,'quantize':None}),
                'Protocol differs from the fixed original research contract')
            require(reg['protocol_sha256']==digest(protocol),'Protocol digest differs')
            require(type(prep.get('schema_version')) is int and prep['schema_version']==1
                and prep.get('task_id')==reg['task_id'] and prep.get('status')=='prepared'
                and prep.get('fixture_only') is fixture and type(prep.get('new_prediction_calls')) is int
                and prep['new_prediction_calls']==0,'Preparation receipt identity/status differs')
            for name in ('registration','source_lock','input_manifest','ledger_registration'):
                require(prep.get(name+'_sha256')==pin(directory/(name+'.json'))['sha256'],'Prepared identity differs: '+name)
            require(prep['protocol_file_sha256']==pin(directory/'protocol.json')['sha256'],'Prepared protocol file differs')
            expected={'budgets':BUDGET,'image_ids':[r['image_id'] for r in inputs['records']],
                'started_epoch':reg['started_epoch'],'started_monotonic':reg['started_monotonic']}
            require(typed_equal(ledger_reg,expected),'Shared budget anchor differs')
        check('immutable_registration_protocol_and_shared_clock',registration_check)
        source_rows={}
        def sources_check():
            source_rows.update(inspect_sources(lock,reg['configuration'],fixture))
            require(lock['task_id']==reg['task_id'] and type(inputs.get('schema_version')) is int
                and inputs['schema_version']==1 and inputs.get('task_id')==reg['task_id'],'Source/input registration task differs')
            identity={key:inputs[key] for key in ('records','source_files','provenance')}
            require(inputs['input_identity_sha256']==digest(identity),'Input digest differs')
            for row in inputs['source_files'].values():bound(row)
        check('current_execution_and_input_source_bytes',sources_check)
        expected=inputs['records'];ids=[r['image_id'] for r in expected]
        check('full_validation_membership_and_independent_gt',lambda:inspect_inputs(inputs,reg['configuration'],fixture))
        journal=inspect_journal(directory/'shared_prediction_journal.jsonl',ledger_reg)
        check('complete_known_actual_cost_and_five_group_journal',lambda:require(journal['journal_events']==6410,'Journal incomplete'))
        final=read(directory/'budget_final.json')
        def budget_check():
            for key,value in {'prediction_calls':3205,'formal_calls':3200,'warmup_calls':5,'journal_events':6410,
                'journal_head_sha256':journal['journal_head_sha256'],'cost_known':True,'open_call':None,'failed_detector_call':False}.items():
                require(typed_equal(final.get(key),value),'Final budget disagrees: '+key)
            require(near(final['gpu_seconds'],journal['gpu_seconds'],1e-9) and near(final['elapsed_prediction_seconds'],journal['elapsed_seconds'],1e-9)
                and finite(final['wall_seconds']) and journal['last_wall']<=final['wall_seconds']<1800
                and final.get('all_groups_complete') is True
                and type(final.get('complete_groups')) is int and final['complete_groups']==5
                and final.get('within_registered_limits') is True
                and final.get('journal_path')==str(directory/'shared_prediction_journal.jsonl')
                and final.get('journal_sha256')==pin(directory/'shared_prediction_journal.jsonl')['sha256']
                and final.get('journal_size_bytes')==pin(directory/'shared_prediction_journal.jsonl')['size_bytes'],
                'Actual costs escaped original limits or journal bytes differ')
        check('final_shared_budget_matches_actual_receipts',budget_check)
        audit=chain(directory/'audit/task','audit_dataset',expected={'audit_result.json'} if fixture else AUDIT_FILES,task_id='task')
        geometry=chain(directory/'geometry_gate/task','verify_label_geometry',expected={'verification_result.json'} if fixture else GEOMETRY_FILES,task_id='task')
        def gates_check():
            audit_result=read(directory/'audit/task/audit_result.json')
            require(audit_result['summary']['checker_status']=='passed','New audit failed')
            gate=read(directory/'geometry_gate/task/verification_result.json')
            require(gate['summary']['verification_status']=='passed' and gate['summary']['independent_geometry_verification'] is True,'Geometry gate failed')
            require(audit_result.get('task_id')==gate.get('task_id')=='task'
                and audit_result.get('tool')=='audit_dataset' and gate.get('tool')=='verify_label_geometry'
                and audit_result.get('status')==gate.get('status')=='completed','New gate result identity differs')
            if fixture:return
            for label,receipt in (('audit',audit_result),('geometry_gate',gate)):
                require(typed_equal(receipt.get('configuration'),{**reg['configuration'],'output_root':str(directory/label)}),
                    'New gate audited a different configuration')
                begin,end=utc_epoch(receipt.get('started_at')),utc_epoch(receipt.get('finished_at'))
                require(reg['started_epoch']<=begin<=end<reg['deadline_epoch']
                    and end<=journal['intervals'][0]['reserved_epoch']+TIMING_ABSOLUTE_SECONDS,
                    'Historical or late gate was reused as the new task gate')
            audit_paths={'checker':Path(reg['configuration']['research_root'])/'数据处理/7检查YOLO标注数据.py',
                'geometry':Path(reg['configuration']['research_root'])/'cableinspect_geometry.py',
                'dataset_manifest':Path(reg['configuration']['dataset_root'])/'manifest.json',
                'weights':Path(reg['configuration']['weights_path'])}
            require(type(audit_result.get('evidence')) is dict and set(audit_result['evidence'])==set(audit_paths),
                'Audit source evidence population differs')
            for key,path in audit_paths.items():
                require(typed_equal(audit_result['evidence'][key],{k:pin(path)[k] for k in ('path','sha256')}),
                    'Audit source bytes differ from current frozen sources')
            geometry_inputs=read(directory/'geometry_gate/task/input_manifest.json')
            source_roles={key:value for key,value in inputs['source_files'].items()
                if key.startswith(('labels/','metadata/','splits/','dataset/','raw/')) or key in {'verifier','oracle','fixtures'}}
            checked=geometry_inputs.get('files')
            require(geometry_inputs.get('task_id')=='task' and geometry_inputs.get('tool')=='verify_label_geometry'
                and geometry_inputs.get('all_unchanged') is True and type(checked) is list
                and len(checked)==len(source_roles) and {r['role'] for r in checked}==set(source_roles),
                'Geometry input source population differs')
            for row in checked:
                source=source_roles[row['role']]
                require(row.get('unchanged') is True and row.get('path')==source['path']
                    and row.get('sha256_before')==row.get('sha256_after')==source['sha256']
                    and type(row.get('size_bytes')) is int and row['size_bytes']==source['size_bytes'],
                    'Geometry verified different input bytes')
            detail=lines(directory/'geometry_gate/task/geometry_details.jsonl');fixtures=read(directory/'geometry_gate/task/fixture_results.json')
            require(sum(r.get('record_type')=='image' for r in detail)==4479 and sum(r.get('record_type')=='annotation' for r in detail)==3864
                and len(detail)==8343 and all(r.get('differences')==[] for r in detail)
                and all(r.get('status')=='passed' for r in detail if r.get('record_type')=='annotation'),'Full geometry detail differs')
            require(fixtures['status']=='passed' and len(fixtures['cases'])==30 and all(r['status']=='passed' for r in fixtures['cases']),'Geometry oracle fixtures differ')
        check('new_audit_and_full_independent_geometry_gate',gates_check)
        group_rows={};group_metrics={};group_chains={};group_details={};versions=[]
        for step,size in STEPS.items():
            group=directory/'groups'/step
            binding={'task_id':reg['task_id'],'step_id':step,'registration_sha256':pin(directory/'registration.json')['sha256'],
                'input_identity_sha256':inputs['input_identity_sha256'],'protocol_sha256':reg['protocol_sha256'],
                'execution_source_sha256':lock['execution_source_sha256']}
            def group_check(step=step,size=size,group=group,binding=binding):
                if step!='fault_960':group_chains[step]=chain(group,TOOL,binding,GROUP_FILES)
                else:
                    require(not (group/'completion.json').exists(),'Fault step got a completion marker')
                    manifest=read(group/'artifact_manifest.json')
                    require(manifest.get('tool')==TOOL and manifest.get('task_id')==reg['task_id']
                        and manifest.get('status')=='completed' and typed_equal(manifest['binding'],binding)
                        and len(manifest['files'])==len(GROUP_FILES)
                        and {r['name'] for r in manifest['files']}==GROUP_FILES,'Fault temporary manifest differs')
                    for row in manifest['files']:
                        bound(row,group);require(Path(row['path']).resolve().parent==group,'Fault temporary artifact escaped its step')
                    require({p.name for p in group.iterdir() if p.is_file()}==GROUP_FILES|{'artifact_manifest.json'},
                        'Fault group has unbound artifacts')
                records=lines(group/'predictions.jsonl');require([r['image_id'] for r in records]==ids,'Group ordered member set differs')
                for row,original in zip(records,expected):
                    require(all(typed_equal(row.get(k),v) for k,v in original.items()),'Group GT/identity differs')
                    require(row['eval_imgsz']==size and type(row['eval_imgsz']) is int and row['device']=='0' and row['precision']=='FP32','Group inference scope differs')
                    require(type(row['predictions']) is list and len(row['predictions'])<=300,'Invalid prediction count')
                    for prediction in row['predictions']:
                        box=prediction['xyxy'];require(type(prediction['class_id']) is int and prediction['class_id'] in range(7)
                            and finite(prediction['confidence']) and .001<=prediction['confidence']<=1
                            and type(box) is list and len(box)==4 and all(finite(v) for v in box)
                            and 0<=box[0]<box[2]<=row['width'] and 0<=box[1]<box[3]<=row['height'],'Invalid predicted geometry')
                environment=read(group/'environment.json')
                require(environment['fixture_only'] is fixture and environment['real_detector_used'] is (not fixture),'Fixture presented as real execution')
                inspect_environment_sources(environment,lock,source_rows,fixture)
                inspect_group_cost(records,environment,step,journal,fixture)
                controls={'imgsz':size,'batch':1,'conf':.001,'iou':.7,'max_det':300,'rect':False,'augment':False,'agnostic_nms':False,'quantize':None,'nms':None,'device':'0'}
                require(typed_equal(environment.get('actual_predictor_options'),controls),'Effective inference options differ')
                for key,value in {'device':'0','precision':'FP32','model_parameters_dtype':'torch.float32','actual_input_dtype':'torch.float32','actual_input_device':'cuda:0','actual_predictor_device':'cuda:0','actual_predictor_fp16':False,'tf32_matmul':False,'tf32_cudnn':False,'cudnn_benchmark':False,'cudnn_deterministic':True,'prediction_entry_calls':641,'formal_calls':640,'warmup_calls':1,'actual_predictor_imgsz':[size,size]}.items():
                    require(typed_equal(environment.get(key),value),'Actual backend control differs: '+key)
                versions.append({k:environment[k] for k in ('python','python_executable','torch','ultralytics','cuda','cudnn','gpu_name','gpu_total_bytes','backend_source','callable_sources')})
                metrics=score_detections(records,CLASSES,.25,.5)
                require(typed_equal(metrics,read(group/'metrics.json')),'Saved metrics differ from recomputation')
                step_verification=read(group/'step_verification.json')
                require(step_verification['status']=='passed' and typed_equal(step_verification['binding'],binding)
                    and type(step_verification.get('prediction_images')) is int and step_verification['prediction_images']==640
                    and step_verification.get('fixture_only') is fixture
                    and typed_equal(step_verification.get('checks'),{'ordered_full_validation_identity':True,
                        'actual_frozen_inference_controls':True,'closed_known_prediction_costs':True}),
                    'Group verification identity differs')
                number=list(STEPS).index(step)+1;summary=step_verification['ledger']
                require(type(summary.get('prediction_calls')) is int and summary['prediction_calls']==number*641
                    and type(summary.get('formal_calls')) is int and summary['formal_calls']==number*640
                    and type(summary.get('warmup_calls')) is int and summary['warmup_calls']==number
                    and summary.get('journal_head_sha256')==journal['heads'][number*641]
                    and summary.get('cost_known') is True and summary.get('open_call') is None
                    and summary.get('failed_detector_call') is False
                    and near(summary.get('gpu_seconds'),sum(c['gpu_seconds'] for c in journal['calls'][:number*641]),1e-9)
                    and near(summary.get('elapsed_prediction_seconds'),sum(c['elapsed_seconds'] for c in journal['calls'][:number*641]),1e-9),
                    'Saved step budget differs from actual journal prefix')
                group_rows[step]=records;group_metrics[step]=metrics
                if step!='fault_960':group_details[step]={'path':str(group),'binding':binding,
                    'chain':group_chains[step],'metrics':metrics,'environment':environment}
            check(step+'_artifacts_actual_controls_and_recomputed_metrics',group_check)
        check('all_group_dependency_and_gpu_identity_shared',lambda:require(len(versions)==5 and all(typed_equal(v,versions[0]) for v in versions),'Runtime identity changed'))
        def paired_check():
            for a,b in (('reference_640','fault_640'),('reference_960','fault_960'),('reference_960','resume_960')):
                prediction_pair(group_rows[a],group_rows[b]);require(near(group_metrics[a],group_metrics[b],1e-10),'Recomputed metrics exceeded frozen tolerance')
                require(typed_equal(group_metrics[a]['operating_point'],group_metrics[b]['operating_point']),'Operating TP/FP/FN differs')
            require(typed_equal(result['comparison'],compare_scores(group_metrics['fault_640'],group_metrics['resume_960'])),'Reported resolution comparison differs')
        check('new_reference_matches_recovery_full_predictions',paired_check)
        def recovery_check():
            failure=read(directory/'fault/failure.json');resume=read(directory/'resume_receipt.json')
            task_binding={'task_id':reg['task_id'],'registration_sha256':pin(directory/'registration.json')['sha256'],
                'input_identity_sha256':inputs['input_identity_sha256'],'protocol_sha256':reg['protocol_sha256'],
                'execution_source_sha256':lock['execution_source_sha256']}
            require(failure['type']=='InjectedResolutionStepFault' and typed_equal(failure['fault_rule'],FAULT)
                and failure['fault_rule_sha256']==digest(FAULT) and failure['closed_cost'] is True
                and failure.get('status')=='failed' and failure.get('task_id')==reg['task_id']
                and failure.get('step_id')=='fault_960'
                and typed_equal(failure.get('binding'),{**task_binding,'step_id':'fault_960'})
                and failure.get('original_deadline_epoch')==reg['deadline_epoch']
                and failure.get('original_deadline_monotonic')==reg['deadline_monotonic']
                and failure['step_completion_absent'] is True
                and type(failure['ledger'].get('prediction_calls')) is int and failure['ledger']['prediction_calls']==2564
                and failure['ledger'].get('cost_known') is True and failure['ledger'].get('open_call') is None
                and failure['ledger'].get('failed_detector_call') is False
                and failure['ledger']['journal_head_sha256']==journal['heads'][2564]
                and typed_equal(failure.get('temporary_artifacts'),read(directory/'groups/fault_960/artifact_manifest.json')['files']),
                'Fixed known-cost fault boundary differs')
            require(resume['recovery_attempt']==1 and type(resume['recovery_attempt']) is int
                and resume.get('task_id')==reg['task_id'] and resume.get('same_configuration') is True
                and resume['rerun']==['resume_960'] and resume['failed_step']=='fault_960' and resume['partial_960_reused'] is False
                and resume['deadline_reset'] is False and resume['original_deadline_epoch']==reg['deadline_epoch']
                and resume['original_deadline_monotonic']==reg['deadline_monotonic']
                and resume['original_failure_sha256']==pin(directory/'fault/failure.json')['sha256']
                and resume['journal_head_before_resume']==journal['heads'][2564],'Resume changed budget/configuration/failed target')
            require(typed_equal(resume['reuse'],{'audit':audit,'geometry_gate':geometry,'fault_640':group_chains['fault_640']}),'Resume reused a corrupted or different completed step')
            before,after=(read(directory/name) for name in ('fault_tree_before_resume.json','fault_tree_after_resume.json'))
            current=[]
            for relative in ('fault','groups/fault_640','groups/fault_960'):
                for path in sorted((directory/relative).rglob('*')):
                    if path.is_file():current.append({'relative_path':path.relative_to(directory).as_posix(),**pin(path)})
            require(typed_equal(before,after) and typed_equal(before.get('files'),current) and before['tree_sha256']==digest(current),'Original failure tree changed')
            require(not (directory/'fault/completion.json').exists(),'Fault parent falsely completed')
            preflight=read(directory/'staged_preflight_receipt.json')
            require(preflight.get('status')=='preflight_passed' and preflight.get('tool')==TOOL
                and preflight.get('task_id')==reg['task_id'] and typed_equal(preflight.get('binding'),task_binding)
                and typed_equal(preflight.get('audit'),audit) and typed_equal(preflight.get('geometry_gate'),geometry)
                and preflight.get('fixture_only') is fixture and preflight.get('deadline_reset') is False
                and type(preflight.get('new_prediction_calls')) is int and preflight['new_prediction_calls']==0
                and type(preflight.get('ledger',{}).get('prediction_calls')) is int
                and preflight['ledger']['prediction_calls']==0
                and preflight.get('original_deadline_epoch')==reg['deadline_epoch']
                and preflight.get('original_deadline_monotonic')==reg['deadline_monotonic'],
                'New preflight receipt did not precede every prediction')
        check('one_second_group_recovery_and_original_fault_preserved',recovery_check)
        def candidate_check():
            require(candidate['status']=='candidate_only' and candidate['fixture_only'] is fixture and candidate['registration_sha256']==pin(directory/'registration.json')['sha256'],'Parent candidate identity differs')
            rows=candidate['root_artifacts'];require(len({r['name'] for r in rows})==len(rows),'Duplicate root candidate artifacts')
            observed={p.name for p in directory.iterdir() if p.is_file() and p.name not in COORDINATION_FILES|POST_CANDIDATE}
            require({r['name'] for r in rows}==observed and ROOT_REQUIRED<=observed,
                'Root candidate omits or invents an actual required artifact')
            for row in rows:
                bound(row,directory);require(Path(row['path']).resolve().parent==directory,'Root artifact is not a direct child')
            require(typed_equal(candidate['group_chains'],group_chains) and typed_equal(candidate['audit_chain'],audit)
                and typed_equal(candidate['geometry_chain'],geometry),'Parent candidate child chains differ')
            require(type(candidate.get('schema_version')) is int and candidate['schema_version']==1
                and candidate.get('task_id')==reg['task_id'] and candidate.get('tool')==TOOL
                and candidate.get('fault_tree_sha256')==read(directory/'fault_tree_before_resume.json')['tree_sha256']
                and candidate.get('original_failure_sha256')==pin(directory/'fault/failure.json')['sha256'],
                'Parent candidate fault/identity claims differ')
            require(type(result.get('schema_version')) is int and result['schema_version']==1
                and result.get('tool')==TOOL and result.get('purpose')==PURPOSE and result.get('task_id')==reg['task_id']
                and result.get('status')=='ready_for_independent_verification'
                and result['fixture_only'] is fixture and result['real_detector_used'] is (not fixture)
                and type(result['recovery_attempts']) is int and result['recovery_attempts']==1
                and result['reused_steps']==['audit','geometry_gate','fault_640'] and result['rerun_steps']==['resume_960']
                and result['partial_predictions_reused'] is False and result['deadline_reset'] is False
                and result.get('fault_tree_preserved') is True
                and result.get('input_identity_sha256')==inputs['input_identity_sha256']
                and result.get('execution_source_sha256')==lock['execution_source_sha256']
                and typed_equal(result.get('final_budget'),final)
                and typed_equal(result.get('groups'),group_details)
                and typed_equal(result.get('audit'),audit) and typed_equal(result.get('geometry_gate'),geometry)
                and typed_equal(result.get('fault_failure'),pin(directory/'fault/failure.json')),
                'Reported recovery scope/actual cost/artifact claims differ')
            events=read(directory/'execution_events.json')
            require(events.get('scope')=='single_owned_coordinator' and events.get('fixture_only') is fixture
                and typed_equal(events.get('step_order'),['audit','geometry_gate',*STEPS]),'Execution order/scope differs')
            mode=events.get('execution_mode')
            claims={'execution_claim.json':'all'} if mode=='standalone_controlled' else {
                'preflight_claim.json':'preflight','fault_phase_claim.json':'until_fault','resume_execution_claim.json':'resume'}
            require(mode in {'standalone_controlled','explicit_staged_research'}
                and {name for name in ('execution_claim.json','preflight_claim.json','fault_phase_claim.json','resume_execution_claim.json')
                    if (directory/name).exists()}==set(claims),'Exclusive execution claims were mixed or replayed')
            for name,phase in claims.items():
                claim=read(directory/name)
                require(set(claim)=={'task_id','pid','phase','registered_sha256'}
                    and claim['task_id']==reg['task_id'] and claim['phase']==phase
                    and type(claim['pid']) is int and claim['pid']>0
                    and claim['registered_sha256']==pin(directory/'registration.json')['sha256'],
                    'Writer execution claim differs from the original registration')
            if prepublication:require(not (directory/'completion.json').exists(),'Parent completed before independent review')
            else:
                chain(directory,TOOL,task_id=reg['task_id'])
                marker=read(directory/'completion.json');require(marker['real_recovery_accepted'] is True
                    and marker['independent_verification_sha256']==pin(directory/'independent_verification.json')['sha256'],'Final independent acceptance link differs')
                saved=read(directory/'independent_verification.json')
                require(not fixture and saved.get('status')=='passed' and saved.get('fixture_only') is False
                    and saved.get('real_recovery_accepted') is True and saved.get('prepublication') is True
                    and saved.get('task_directory')==str(directory) and type(saved.get('checks')) is dict
                    and set(saved['checks'])==set(checks)|{'parent_candidate_evidence_and_publication_boundary'}
                    and all(v is True for v in saved['checks'].values()),
                    'Parent publication linked an unaccepted independent review')
                published=read(directory/'artifact_manifest.json')
                require(typed_equal(published.get('group_chains'),group_chains)
                    and typed_equal(published.get('audit_chain'),audit) and typed_equal(published.get('geometry_chain'),geometry)
                    and typed_equal(published.get('fault_tree'),read(directory/'fault_tree_after_resume.json')),
                    'Published parent manifest claimed different child evidence')
                require(reg['started_epoch']<=utc_epoch(saved['checked_at'])<reg['deadline_epoch']
                    and reg['started_epoch']<=(directory/'completion.json').stat().st_mtime<reg['deadline_epoch'],
                    'Independent review or final publication escaped original deadline')
        check('parent_candidate_evidence_and_publication_boundary',candidate_check)
    except Exception as error:
        checks['complete_readable_artifact_population']=False
        errors.append({'check':'complete_readable_artifact_population','type':type(error).__name__,'message':str(error)})
    passed=bool(checks) and all(checks.values())
    return {'schema_version':1,'status':('passed_fixture_only' if fixture else 'passed') if passed else 'failed',
        'task_directory':str(directory),'prepublication':prepublication,'fixture_only':fixture,
        'real_recovery_accepted':passed and not fixture,'checks':checks,'errors':errors,
        'checked_at':datetime.now(timezone.utc).isoformat(),
        'limitations':['AP recomputation reuses detection_metrics; no second independent AP implementation.',
                       'Full business recovery is separate from an integrated Agnes research task.']}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task-dir',required=True);parser.add_argument('--prepublication',action='store_true')
    parser.add_argument('--output');args=parser.parse_args()
    result=verify(args.task_dir,prepublication=args.prepublication)
    if args.output:
        with Path(args.output).open('x',encoding='utf8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps(result,ensure_ascii=False));return 0 if result['status']=='passed' else 1

if __name__=='__main__':raise SystemExit(main())
