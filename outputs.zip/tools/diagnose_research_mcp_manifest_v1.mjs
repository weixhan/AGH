// Validate actual AGH row manifests without opening a transport or model.
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const helperPath = fileURLToPath(import.meta.url);
const root = resolve(dirname(helperPath), '..');
const harness = resolve(root, '..', 'agnes-harness');
const tracePath = resolve(root, 'outputs/agh-research-workflow-model-v1/mcp-workspace-activation.json');
const diagnosticsPath = resolve(root, 'outputs/agh-research-workflow-model-v1/official-host-diagnostics.json');
const outputPath = resolve(root, 'outputs/agh-research-workflow-model-v1/mcp-manifest-diagnosis.json');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const traceBytes = await readFile(tracePath);
const trace = JSON.parse(traceBytes.toString('utf8'));
const diagnosticsBytes = await readFile(diagnosticsPath);
const diagnostics = JSON.parse(diagnosticsBytes.toString('utf8'));
const { mcpServerRowsFromDefinitions } = await import(pathToFileURL(resolve(harness, 'packages/worker-runtime/src/mcp-server-rows.ts')).href);
const { checkManifest } = await import(pathToFileURL(resolve(harness, 'packages/extension-api/src/manifest.ts')).href);
const { mcpLocalToolPrefix } = await import(pathToFileURL(resolve(harness, 'packages/base/src/mcp/naming.ts')).href);
const schemaPath = resolve(harness, 'packages/protocol/schema/extension-manifest.json');
const schema = JSON.parse((await readFile(schemaPath)).toString('utf8'));
const expectedPattern = schema.$defs.Capabilities.properties.tools.properties.prefix.pattern;
const results = [];
for (const serverId of ['defect-researcher-workflow-v1', 'dr-workflow-v1', 'drw-v1']) {
  const definition = { ...trace.after.definition, serverId };
  const { rows, skipped } = mcpServerRowsFromDefinitions(
    [{ definition, revision: trace.after.revision, desired: 'enabled', trust: 'trusted' }],
    { connect() { throw new Error('Manifest diagnosis must not open a transport'); } });
  if (rows.length !== 1 || skipped.length !== 0) throw new Error('Unexpected candidate row population');
  const checked = checkManifest(rows[0].manifest);
  const prefix = mcpLocalToolPrefix(serverId);
  results.push({ server_id: serverId, manifest: rows[0].manifest,
    prefix_length: prefix.length, manifest_valid: checked.ok, problems: checked.problems ?? [],
    qualified_tools: definition.toolPolicy.allow.map(name => prefix + name.slice(0, 64 - prefix.length)) });
}
if (results[0].manifest_valid || !results[1].manifest_valid || !results[2].manifest_valid
    || results[0].problems.length !== 1 || !results[0].problems[0].startsWith('/capabilities/tools/prefix:'))
  throw new Error('Manifest differential does not isolate the expected prefix constraint');
const sourceFiles = [helperPath, tracePath, diagnosticsPath, schemaPath,
  resolve(harness, 'packages/worker-runtime/src/mcp-server-rows.ts'),
  resolve(harness, 'packages/extension-api/src/manifest.ts'),
  resolve(harness, 'packages/base/src/mcp/naming.ts')];
const sources = [];
for (const path of sourceFiles) {
  const bytes = await readFile(path);
  sources.push({ path, sha256: sha(bytes), size_bytes: bytes.length });
}
const report = { schema_version: 1, status: 'passed', observed_at: new Date().toISOString(),
  root_cause: 'AGH_generated_tool_capability_prefix_exceeds_manifest_pattern',
  interface: 'AGH mcpServerRowsFromDefinitions + checkManifest',
  prefix_pattern: expectedPattern, maximum_nonempty_prefix_length: 33,
  official_failures: diagnostics.filter(item => item.kind === 'extension.failed'
    && item.detail?.package === '@agnes/base' && item.detail?.message === 'invalid extension manifest'),
  results, recommended_server_id: 'dr-workflow-v1', old_failed_server_must_remain_disabled: true,
  frozen_source_changes: 0, domain_tool_calls: 0, transport_connections: 0,
  model_requests: 0, credentials_read: false, sources };
await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n', { encoding: 'utf8', flag: 'wx' });
console.log(JSON.stringify({ status: 'passed', output: outputPath,
  root_cause: report.root_cause, recommended_server_id: report.recommended_server_id }));
