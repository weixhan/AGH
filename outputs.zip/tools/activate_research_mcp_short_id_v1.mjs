// Match the official Host manifest prefix contract without changing frozen code.
import {readFile,writeFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177';
const out=join(root,'outputs','agh-research-workflow-model-v1'),path=join(out,'mcp-activation.json');
const oldId='defect-researcher-workflow-v1',serverId='dr-workflow-v1';
const prior=JSON.parse(await readFile(join(out,'mcp-workspace-activation.json'),'utf8'));
const definition={...prior.definition,serverId};
const trace={schema_version:1,status:'running',reason:'Official Host tool prefix must be at most 33 characters; shorter managed ID preserves frozen tool implementation',
 server_id:serverId,definition,prior_failed_server_id:oldId,steps:[],model_requests:0,credentials_read:false,
 agh_core_modified:false,started_at:new Date().toISOString()};
await writeFile(path,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(path,JSON.stringify(trace,null,2)+'\n');
async function api(route,body){const r=await fetch(origin+'/admin/resources/api/'+route,{method:body?'POST':'GET',
 headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 const data=await r.json();if(!r.ok)throw new Error(`${route} ${r.status} ${JSON.stringify(data)}`);return data;}
let base;
async function effect(route,params){const step={route,params:{...base,commandId:'short-workflow-'+randomUUID(),...params}};
 trace.steps.push(step);await save();step.receipt=await api(route,step.params);await save();const stop=Date.now()+60000;
 for(;;){step.operation=await api('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();
  if(['succeeded','failed','cancelled'].includes(step.operation.state))break;
  if(Date.now()>=stop)throw new Error('Original admin operation deadline expired');await new Promise(yes=>setTimeout(yes,400));}
 console.log(JSON.stringify({route,state:step.operation.state,error:step.operation.lastSafeError}));
 if(step.operation.state!=='succeeded')throw new Error(`${route} failed`);}
try{
 const context=await api('context');base={profile:context.profile,clientId:context.clientId};
 if(context.readOnly||context.profile!=='local-dev')throw new Error('Wrong official admin context');
 trace.old_before=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 const list=await api('mcp/list',{profile:base.profile});if(list.items.some(row=>row.serverId===serverId))throw new Error('New server exists; refusing overwrite');
 const failed=await api('mcp/get',{profile:base.profile,serverId:oldId});trace.failed_before=failed;
 if(failed.desired!=='enabled'||failed.trust!=='trusted'||failed.actual!=='unavailable')throw new Error('Unexpected failed deployment state');
 await effect('mcp/disable',{serverId:oldId,expectedRevision:failed.revision});
 await effect('mcp/create',{definition});
 let row=await api('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/trust',{serverId,expectedRevision:row.revision,trust:'trusted'});
 row=await api('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/enable',{serverId,expectedRevision:row.revision});
 await effect('mcp/test',{serverId,expectedRevision:row.revision});
 trace.after=await api('mcp/get',{profile:base.profile,serverId});
 trace.status_snapshot=await api('mcp/status',{profile:base.profile,serverId});
 trace.tools=await api('mcp/tools',{profile:base.profile,serverId});
 trace.failed_after=await api('mcp/get',{profile:base.profile,serverId:oldId});
 trace.old_after=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 trace.checks={old_server_definition_and_revision_unchanged:JSON.stringify(trace.old_before.definition)===JSON.stringify(trace.old_after.definition)
  &&trace.old_before.revision===trace.old_after.revision&&trace.old_after.actual==='ready',
  failed_deployment_disabled:trace.failed_after.desired==='disabled'&&trace.failed_after.actual==='disabled',
  new_trusted_ready:trace.after.trust==='trusted'&&trace.after.desired==='enabled'&&trace.after.actual==='ready',
  exact_two_tools:trace.status_snapshot.toolCount===2&&trace.tools.items.length===2,
  official_operations_succeeded:trace.steps.every(step=>step.operation.state==='succeeded')};
 trace.status=Object.values(trace.checks).every(Boolean)?'completed':'failed';
}catch(error){trace.status='failed';trace.error={type:error.name,message:error.message};process.exitCode=1;}
finally{trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,checks:trace.checks,error:trace.error}));}
