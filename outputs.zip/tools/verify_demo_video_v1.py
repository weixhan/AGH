"""Decode actual video samples and crosscheck its recorded real CPU task."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--media", type=Path, required=True)
    parser.add_argument("--ffmpeg", type=Path, required=True)
    args = parser.parse_args()
    media = args.media.resolve()
    receipt = json.loads((media / "recording_receipt.json").read_text(encoding="utf-8"))
    video = Path(receipt["video"]["path"]).resolve()
    if video.parent != media or not video.is_file():
        raise ValueError("Video must be the captured file inside this media directory")
    output = media / "decode-qa"
    output.mkdir(exist_ok=False)
    probe = subprocess.run([str(args.ffmpeg.resolve()), "-hide_banner", "-i", str(video)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
    (output / "ffmpeg-metadata.log").write_text(probe.stderr, encoding="utf-8")
    match = re.search(r"Duration: (\d+):(\d+):(\d+\.\d+)", probe.stderr)
    duration = int(match[1]) * 3600 + int(match[2]) * 60 + float(match[3]) if match else None
    dimensions = re.search(r"Video:.*?\b(\d{3,4})x(\d{3,4})\b", probe.stderr)
    shape = [int(dimensions[1]), int(dimensions[2])] if dimensions else None
    frames = []
    for second in (3, 50, 75, 110, 145, 178, 195, 222):
        path = output / f"frame-{second:03d}.png"
        decode = subprocess.run([str(args.ffmpeg.resolve()), "-hide_banner", "-loglevel", "error", "-ss", str(second),
                                 "-i", str(video), "-frames:v", "1", str(path)],
                                capture_output=True, text=True, encoding="utf-8", errors="replace", check=False)
        frames.append({"second": second, "status": "passed" if decode.returncode == 0 and path.is_file() and path.stat().st_size > 0 else "failed",
                       "exit_code": decode.returncode, "path": str(path), "sha256": sha256(path) if path.is_file() else None,
                       "error": decode.stderr})
    actual = receipt["captured_real_run"]
    review_passed = sum(row["checks_passed"] for row in actual["independent_reviews"])
    review_total = sum(row["checks_total"] for row in actual["independent_reviews"])
    events = receipt["events"]
    viewed = {row["case_id"] for row in events if row["event"] == "actual_case_click"}
    checks = {
        "three_to_five_minutes": duration is not None and 180 <= duration <= 300,
        "1280_by_720": shape == [1280, 720],
        "webm_vp8_stream": "Video: vp8" in probe.stderr,
        "video_hash_and_size_match_capture_receipt": sha256(video) == receipt["video"]["sha256"] and video.stat().st_size == receipt["video"]["size_bytes"],
        "eight_actual_frames_decode": len(frames) == 8 and all(row["status"] == "passed" for row in frames),
        "no_page_errors": receipt["page_errors"] == [],
        "real_run_passed_twelve_cases": actual["phase"] == "passed" and len(actual["case_outcomes"]) == 12 and all(row["status"] == "passed" for row in actual["case_outcomes"]),
        "four_real_repairs_no_unintended_changes": actual["actual_repair_cases"] == 4 and actual["unintended_modification_cases"] == 0,
        "independent_saved_task_checks_144": review_passed == review_total == 144,
        "geometry_30_and_smoke_14": actual["geometry_counts"]["passed"] == actual["geometry_counts"]["total"] == 30 and len(actual["checks"]) == 14 and all(actual["checks"].values()),
        "real_run_button_then_pass_event": any(row["event"] == "actual_run_button_click" for row in events) and any(row["event"] == "real_cpu_run_passed" for row in events),
        "normal_repair_refusal_views_present": {"normal_unrotated", "repair_coordinates", "repair_metadata_rotation", "refuse_source_hash", "refuse_missing_source"} <= viewed,
        "model_and_gpu_zero": actual["model_calls"] == actual["gpu_tasks"] == 0,
    }
    result = {"schema_version": 1, "kind": "actual_demo_video_decode_and_task_crosscheck_v1",
              "status": "passed" if all(checks.values()) else "failed", "checks": checks,
              "video": {"path": str(video), "sha256": sha256(video), "size_bytes": video.stat().st_size,
                        "duration_seconds": duration, "dimensions": shape, "silent": "Audio:" not in probe.stderr},
              "recording_receipt_sha256": sha256(media / "recording_receipt.json"), "actual_run_id": actual["run_id"],
              "decoded_samples": frames, "visual_review": "pending_human_or_agent_frame_inspection",
              "limitations": receipt["limitations"]}
    (media / "video_decode_qa.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "video": result["video"], "checks": checks, "actual_run_id": actual["run_id"]}, ensure_ascii=True))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
