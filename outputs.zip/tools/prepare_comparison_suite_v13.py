"""Exclusively preregister V13 diagnostic, pilot, or formal execution.

The module is inert on import. main() registers immutable inputs but does not
arm any trial, connect a service, or request model/detector/GPU inference.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

from defect_researcher.comparison_protocol_v13 import make_protocol, validate_protocol
from defect_researcher.comparison_mcp_server_v13 import _tools
from defect_researcher.comparison_case_runtime_v13 import Runtime
from tools.verify_comparison_model_v13 import (
    SOURCE_MEMBERS, MODEL_ACCOUNTING, CASE_IDS, PILOT_CASES, phase_budget,
    validate_stage_ledger, verify_prerequisites, check_full_selection,
)

ROOT = Path(__file__).resolve().parents[1]
STAGES = ("diagnostic", "pilot", "formal")


def stage_service_identity(stage):
    """Check the native dynamic manifest identity before preregistration writes."""
    if stage not in STAGES:
        raise ValueError("Unknown V13 stage")
    code = {"diagnostic": "d", "pilot": "p", "formal": "f"}[stage]
    server = "dr-cmp13-" + code
    prefix = "mcp_" + server.replace("-", "_") + "_" + hashlib.sha256(server.encode()).hexdigest()[:8] + "_"
    qualified = prefix + "execute_case_action_v1"
    if (len(prefix) > 32 or len(qualified) > 64
            or re.fullmatch(r"mcp_dr_cmp13_[dpf]_[0-9a-f]{8}_execute_case_action_v1", qualified) is None):
        raise ValueError("V13 service identity exceeds native MCP naming limits")
    return {"server_id": server, "tools_prefix": prefix, "qualified_action_tool": qualified}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_native_identity(stage, identity):
    node = shutil.which("node")
    if not node:
        raise ValueError("Native MCP identity preflight requires the configured Node runtime")
    checked = subprocess.run([node, str(ROOT / "tools/check_comparison_mcp_identity_v13.mjs"), stage],
        cwd=ROOT, capture_output=True, text=True, encoding="utf8", check=True, timeout=30,
        creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
    receipt = json.loads(checked.stdout)
    result = receipt.get("results", [None])[0]
    if (receipt.get("status") != "passed" or len(receipt.get("results", [])) != 1
            or any(result.get(key) != value for key, value in identity.items())
            or receipt.get("connections") != 0 or receipt.get("model_requests") != 0):
        raise ValueError("Native dynamic MCP manifest differs from the proposed V13 identity")
    return result


def record(path):
    path = Path(path).resolve()
    return {"path": str(path), "sha256": sha(path), "size_bytes": path.stat().st_size}


def read(path):
    return json.loads(Path(path).read_text("utf8"))


def save(path, value):
    with Path(path).open("x", encoding="utf8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def unique_sources(names):
    """Bind each Windows file once, independent of slash or case spelling."""
    result, seen = [], set()
    for name in names:
        path = (ROOT / name).resolve()
        key = str(path).casefold()
        if key not in seen:
            result.append(path.relative_to(ROOT).as_posix())
            seen.add(key)
    return result


def build_stage_ledger(stage, protocol, protected_history, prerequisites=None):
    """Construct an inert allocation; useful for independent no-execution tests."""
    if stage not in STAGES:
        raise ValueError("Unknown V13 stage")
    cases = list(CASE_IDS if stage == "formal" else PILOT_CASES)
    if protocol.get("stage") != ("formal" if stage == "formal" else "pilot") or protocol.get("case_ids") != cases:
        raise ValueError("Ledger stage does not match its protocol population")
    ledger = {
        "schema_version": 1, "kind": "comparison_suite_stage_preregistration_v13",
        "status": "preregistered_not_executed", "stage": stage, "stage_id": "cmp-suite-v13-" + stage,
        "registered_at": datetime.now(timezone.utc).isoformat(),
        "authorization": {"user_message": "依次完成未完成项",
            "scope": "complete_fixed_three_arm_comparison", "new_stage_model_request_cap": phase_budget(stage)["total_cap"]},
        "counting_unit": "application_provider_invocation_not_HTTP_transmission",
        "phase_model_budget": phase_budget(stage), "model_accounting": dict(MODEL_ACCOUNTING),
        "case_ids": cases, "planned_trial_count": len(cases) * 3,
        "planned_model_trial_count": len(cases) * 2, "planned_scripted_trial_count": len(cases),
        "planned_execution_count": 2 if stage == "diagnostic" else len(cases) * 3,
        "selected_model_trial_count": 2 if stage == "diagnostic" else len(cases) * 2,
        "selected_scripted_trial_count": 0 if stage == "diagnostic" else len(cases),
        "scripted_model_cap": 0, "domain_invocations_per_trial": 6,
        "per_action_approval": "Allow once", "no_original_session_resume_or_deadline_reset": True,
        "model_calls_actual": 0, "new_detector_calls": 0, "new_training_runs": 0, "gpu_seconds": 0,
        "protected_history": protected_history, "prerequisites": prerequisites or {},
        "scope": "Fixed artificial cases; diagnostic is only two F branches; C uses actual MCP SDK with zero model requests",
        "business_errors": "Observed comparison outcomes; engineering, scope, runtime and actual cost must still be closed",
    }
    validate_stage_ledger(ledger)
    return ledger


def prerequisite_records(stage):
    pairs = [
        ("v10_freeze", ROOT / "outputs/comparison-implementation-v10/freeze.json"),
        ("v10_closure", ROOT / "outputs/comparison-pilot-v10/final_closure_verification.json"),
        ("v11_setup_freeze", ROOT / "outputs/comparison-implementation-v11-diagnostic/freeze.json"),
        ("v11_setup_closure", ROOT / "outputs/comparison-suite-v11-diagnostic/final_closure_verification.json"),
        ("v12_failed_freeze", ROOT / "outputs/comparison-implementation-v12-diagnostic/freeze.json"),
        ("v12_failed_closure", ROOT / "outputs/comparison-suite-v12-diagnostic/final_closure_verification.json"),
    ]
    if stage in {"pilot", "formal"}:
        pairs.extend([
            ("diagnostic_freeze", ROOT / "outputs/comparison-implementation-v13-diagnostic/freeze.json"),
            ("diagnostic_closure", ROOT / "outputs/comparison-suite-v13-diagnostic/final_closure_verification.json"),
        ])
    if stage == "formal":
        pairs.extend([
            ("pilot_freeze", ROOT / "outputs/comparison-implementation-v13-pilot/freeze.json"),
            ("pilot_closure", ROOT / "outputs/comparison-suite-v13-pilot/final_closure_verification.json"),
        ])
    prerequisites = {name: record(path) for name, path in pairs}
    history = []
    for key, pin in prerequisites.items():
        if not key.endswith("_freeze"):
            continue
        frozen = read(pin["path"])
        members = [row for group in ("sources", "archive", "proof_files") for row in frozen[group]]
        for row in members:
            current = record(row["path"])
            if current["sha256"] != row["sha256"] or current["size_bytes"] != row["size_bytes"]:
                raise ValueError("Protected prerequisite bytes changed")
        history.append({"freeze": pin, "checked_records": len(members), "unchanged": True,
                        "original_status_preserved": frozen["status"]})
    return prerequisites, history


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=STAGES, required=True)
    args = parser.parse_args(argv)
    stage = args.stage
    identity = stage_service_identity(stage)
    native_identity = verify_native_identity(stage, identity)
    out = ROOT / ("outputs/comparison-suite-v13-" + stage)
    implementation = ROOT / ("outputs/comparison-implementation-v13-" + stage)
    generated = [implementation / "source_lock.json"] + [out / name for name in
        ("stage_ledger.json", "protocol.json", "model_protocol.json", "preflight.json")]
    if any(path.exists() for path in generated) or (out / "runtime").exists():
        raise FileExistsError("This V13 stage already has registration or execution evidence; no overwrite or resume")
    config_path = out / "server-config.json"
    if Path(read(config_path)["output_root"]).resolve() != (out / "runtime").resolve():
        raise ValueError("The selected stage must write only its fresh runtime directory")
    tests_path = implementation / "local-tests-final.json"
    if read(tests_path).get("status") != "passed":
        raise ValueError("The V13 source tests have not passed")
    prerequisites, history = prerequisite_records(stage)
    baseline = read(prerequisites["v10_freeze"]["path"])["sources"]
    for item in baseline:
        if sha(item["path"]) != item["sha256"]:
            raise ValueError("Protected V10 source changed")
    sources = unique_sources([str(Path(row["path"]).relative_to(ROOT)) for row in baseline] + list(SOURCE_MEMBERS)
        + [str(config_path.relative_to(ROOT)), str(tests_path.relative_to(ROOT))]
        + [str(Path(pin["path"]).relative_to(ROOT)) for pin in prerequisites.values()])
    for name in sources:
        if not (ROOT / name).is_file():
            raise ValueError("V13 dependency is absent: " + name)
    runtime_path = ROOT / "outputs/agh-title-repair-v2/repair_verification.json"
    repaired = read(runtime_path)
    if repaired.get("status") != "passed_local_repair" or repaired.get("agh_core_modified") is not True:
        raise ValueError("Modified AGH repair has not passed")
    if (type(repaired.get("repair_version")) is not int or repaired["repair_version"] != 2
            or repaired.get("new_event") != "x/host/session-title/diagnostics"
            or repaired.get("original_v1_files_unchanged") is not True
            or repaired.get("compiler_invoked") is not False
            or Path(repaired.get("runtime_directory", "")).resolve() !=
            ROOT / "outputs/agh-title-repair-v2/runtime/packages/cli/dist/local"):
        raise ValueError("V13 requires the independently tested side-by-side V2 runtime")
    for row in repaired["runtime_files"]:
        if sha(row["path"]) != row["sha256"] or sha(row["archive"]) != row["sha256"]:
            raise ValueError("Modified AGH differs from its tested runtime")
    catalogue = [{key: row[key] for key in ("name", "description", "inputSchema")} for row in _tools()]
    protocol = make_protocol("cmp-suite-v13-" + stage,
        model={"slot": "primary", "model": "agnes-3.0-flash", "route": "account-defect-researcher"},
        task_prompt=(ROOT / "agent/comparison_case_task_v13.md").read_text("utf8"), tool_catalog=catalogue,
        source_paths={name: ROOT / name for name in sources},
        generation_settings={"explicit_overrides": {}, "runtime_defaults_shared": True},
        stage="formal" if stage == "formal" else "pilot")
    ledger = build_stage_ledger(stage, protocol, history, prerequisites)
    verify_prerequisites(ledger, expected_stage=stage)
    # All dependencies and prerequisite outcomes were checked before any writes.
    ledger_path = out / "stage_ledger.json"
    save(ledger_path, ledger)
    sources.append(str(ledger_path.relative_to(ROOT)))
    protocol["common"]["sources"].append({"role": "v13_stage_ledger", **record(ledger_path)})
    validate_protocol(protocol)
    lock = implementation / "source_lock.json"
    save(lock, {"schema_version": 1, "kind": "comparison_case_implementation_v1", "status": "passed",
                "scope": "V13 seven-call budget implementation; no execution has occurred", "files": [record(ROOT / name) for name in sources]})
    save(out / "protocol.json", protocol)
    selected = ([row for row in protocol["trials"] if row["arm"] == "F" and row["case_id"] in
                 {"repair_coordinates", "refuse_source_hash"}] if stage == "diagnostic" else protocol["trials"])
    selection = {"schema_version": 1, "stage": stage, "trial_handles": [row["trial_handle"] for row in selected],
                 "planned_trial_count": len(protocol["trials"]), "selected_trial_count": len(selected)}
    selection_hash = hashlib.sha256(json.dumps(selection, sort_keys=True, ensure_ascii=False,
                                  separators=(",", ":")).encode("utf8")).hexdigest()
    public = {
        "schema_version": 1, "stage": stage, "protocol_path": str(out / "protocol.json"),
        "protocol_sha256": sha(out / "protocol.json"), "source_lock": {"path": str(lock), "sha256": sha(lock)},
        "server_config": str(config_path), "server_id": identity["server_id"],
        "scope_policy": {"schema_version": 1, "workspace_root": str(out / "workspace"),
            "qualified_action_tool": identity["qualified_action_tool"],
            "allowed_handles": [row["trial_handle"] for row in selected if row["arm"] in {"U", "F"}],
            "max_model_requests": 6, "max_wall_seconds": 120, "max_action_calls": 8},
        "stage_ledger": record(ledger_path), "runtime_version": record(runtime_path),
        "phase_model_budget": phase_budget(stage), "model_accounting": MODEL_ACCOUNTING,
        "selection": selection, "selection_sha256": selection_hash,
        "route_limitations": [
            "Diagnostic selects two F branches; complete pilot/formal selects every C/U/F position",
            "C uses actual MCP SDK with zero model requests; only selected U/F handles enter the model scope",
            "Common protocol, actual runtime arm and domain payload caps all use seven model requests",
            "Post-execution checks cannot resume or reset any original trial clock",
            "Business errors are observations; engineering/runtime/cost failures stop the suite",
            "No new detector, training or GPU calls; all cases are frozen artificial cases"],
    }
    check_full_selection(protocol, public, selected[0]["trial_handle"], scripted=selected[0]["arm"] == "C")
    save(out / "model_protocol.json", public)
    os.environ["DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH"] = str(lock)
    os.environ["DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256"] = sha(lock)
    runtime = Runtime(config_path=config_path)
    registrations = []
    for trial in protocol["trials"]:
        runtime.prepare(trial["trial_id"], trial["case_id"], trial["arm"], trial_handle=trial["trial_handle"])
        registrations.append(read(runtime.root / "trials" / trial["trial_handle"] / "registration.json"))
    same = all(all(row["input_snapshot"] == group[0]["input_snapshot"]
                   and row["prepared_case"]["case_root"] == group[0]["prepared_case"]["case_root"] for row in group)
               for case in protocol["case_ids"] for group in [[row for row in registrations if row["case_id"] == case]])
    if not same or list(runtime.root.rglob("arm.json")):
        raise ValueError("Case input paths/bytes differ or registration armed a trial")
    save(out / "preflight.json", {"schema_version": 1, "status": "passed", "stage": stage,
        "native_mcp_identity": native_identity,
        "planned_trials": len(protocol["trials"]), "selected_trial_count": len(selected),
        "planned_per_arm": len(protocol["case_ids"]), "same_input_paths_and_bytes": same,
        "registered_handles": [row["trial_handle"] for row in registrations], "all_trials_unarmed": True,
        "model_calls_actual": 0, "new_detector_calls": 0, "gpu_seconds": 0,
        "source_lock": public["source_lock"], "stage_ledger": public["stage_ledger"],
        "protocol_sha256": sha(out / "protocol.json"), "protected_history": history,
        "route_limitations": public["route_limitations"]})
    print(json.dumps({"status": "preregistered_not_executed", "stage": stage,
        "planned_trials": len(protocol["trials"]), "selected_trial_count": len(selected),
        "stage_model_cap": phase_budget(stage)["total_cap"], "model_calls_actual": 0,
        "same_input_paths_and_bytes": same}))


if __name__ == "__main__":
    main()
