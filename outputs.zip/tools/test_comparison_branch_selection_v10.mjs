import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {selectBranchDiagnostic} from './comparison_branch_selection_v10.mjs';
const stable=v=>JSON.stringify(v,(_k,x)=>x&&typeof x==='object'&&!Array.isArray(x)?Object.fromEntries(Object.keys(x).sort().map(k=>[k,x[k]])):x);
function fixture(){
 const trials=Array.from({length:9},(_,i)=>({trial_handle:'cmp_'+(i+1).toString(16).padStart(32,'0'),case_id:i===3?'repair_coordinates':i===6?'refuse_source_hash':'normal_unrotated',arm:i===3||i===6?'F':'C'}));
 const selection={schema_version:1,arm:'F',case_ids:['repair_coordinates','refuse_source_hash'],trial_handles:[trials[3].trial_handle,trials[6].trial_handle]};
 return [{trials},{phase_model_budget:{total_cap:14,prior_closed_request_slots:0,request_slots_debited:0,this_pilot_cap:14,phase_remaining_before_diagnostic:14,legacy_token_usage_closed:true},scope_policy:{allowed_handles:selection.trial_handles},engineering_diagnostic:{selection,selected_trial_count:2,selection_sha256:createHash('sha256').update(stable(selection)).digest('hex')}}];
}
test('selects only two new F branches in frozen order',()=>{const [p,u]=fixture();assert.deepEqual(selectBranchDiagnostic(p,u).map(x=>x.case_id),['repair_coordinates','refuse_source_hash']);});
test('refuses altered allocation, population, identity and selected handles',()=>{
 const mutations=[(p,u)=>u.phase_model_budget.total_cap=48,(p,u)=>u.phase_model_budget.request_slots_debited=46,(p,u)=>u.phase_model_budget.this_pilot_cap=7,(p,u)=>u.phase_model_budget.legacy_token_usage_closed=false,(p,u)=>p.trials[3].arm='U',(p,u)=>p.trials[6].case_id='normal_unrotated',(p,u)=>p.trials[6].trial_handle=p.trials[3].trial_handle,(p,u)=>u.scope_policy.allowed_handles=[p.trials[3].trial_handle],(p,u)=>u.engineering_diagnostic.selection.trial_handles.reverse(),(p,u)=>p.trials.pop()];
 for(const mutate of mutations){const [p,u]=fixture();mutate(p,u);assert.throws(()=>selectBranchDiagnostic(p,u));}
});
