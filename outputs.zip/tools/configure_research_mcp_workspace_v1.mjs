// Preserve initial failed registration and stage the isolated model workspace.
import {readFile,writeFile} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {dirname,join,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),origin='http://127.0.0.1:4177';
const out=join(root,'outputs','agh-research-workflow-model-v1'),tracePath=join(out,'mcp-workspace-activation.json');
const lock=join(root,'outputs','research-mcp-implementation-v1','source_lock-model.json');
const sha=createHash('sha256').update(await readFile(lock)).digest('hex');
if(sha!=='4bfa0239d0721636f1ea778696cf911cfa12bcf8e5b7b04d73c19e621e4934b4')throw new Error('Isolated deployment lock changed');
const prior=JSON.parse(await readFile(join(root,'outputs/research-mcp-local-acceptance-v1/registration-continued.json'),'utf8'));
if(prior.status!=='failed'||prior.steps.at(-1).operation.lastSafeError.code!=='MCP_RECONCILE_FAILED')throw new Error('Expected preserved enable failure');
const serverId='defect-researcher-workflow-v1';
const definition=structuredClone(prior.definition);
definition.transport.args=['-B',join(root,'run_research_mcp_v1.py'),'--config',join(out,'server-config.json'),
 '--source-lock',lock,'--expected-lock-sha256',sha];
const trace={schema_version:1,status:'running',definition,steps:[],credentials_read:false,model_requests:0,
 reason:'Server owns isolated workspace outputs and registry; original registration failure preserved'};
await writeFile(tracePath,JSON.stringify(trace,null,2)+'\n',{flag:'wx'});
const save=()=>writeFile(tracePath,JSON.stringify(trace,null,2)+'\n');
async function api(route,body){const r=await fetch(origin+'/admin/resources/api/'+route,{method:body?'POST':'GET',
 headers:{Origin:origin,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 const data=await r.json();if(!r.ok)throw new Error(`${route}: ${r.status} ${JSON.stringify(data)}`);return data;}
let base;
async function effect(route,body){const step={route,params:{...base,commandId:'workflow-workspace-'+randomUUID(),...body}};
 trace.steps.push(step);await save();step.receipt=await api(route,step.params);await save();const stop=Date.now()+60000;
 for(;;){step.operation=await api('operations/get',{profile:base.profile,operationId:step.receipt.operationId});await save();
  if(['succeeded','failed','cancelled'].includes(step.operation.state))break;
  if(Date.now()>=stop)throw new Error('Original administration deadline expired');await new Promise(yes=>setTimeout(yes,400));}
 console.log(JSON.stringify({route,state:step.operation.state,error:step.operation.lastSafeError}));
 if(step.operation.state!=='succeeded')throw new Error(`${route} failed`);}
try{
 const context=await api('context');base={profile:context.profile,clientId:context.clientId};
 if(context.readOnly||context.profile!=='local-dev')throw new Error('Wrong admin context');
 trace.old_before=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'});
 let row=await api('mcp/get',{profile:base.profile,serverId});trace.before=row;
 if(row.desired!=='enabled'||row.actual!=='disabled'||row.trust!=='trusted')throw new Error('Unexpected original failed-enable state');
 await effect('mcp/disable',{serverId,expectedRevision:row.revision});
 row=await api('mcp/get',{profile:base.profile,serverId});
 await effect('mcp/update',{serverId,expectedRevision:row.revision,definition});
 row=await api('mcp/get',{profile:base.profile,serverId});
 if(row.trust!=='trusted'){await effect('mcp/trust',{serverId,expectedRevision:row.revision,trust:'trusted'});
  row=await api('mcp/get',{profile:base.profile,serverId});}
 await effect('mcp/test',{serverId,expectedRevision:row.revision});
 await effect('mcp/enable',{serverId,expectedRevision:row.revision});
 trace.status='completed';
}catch(error){trace.status='failed';trace.error={type:error.name,message:error.message};process.exitCode=1;}
finally{
 if(base){trace.after=await api('mcp/get',{profile:base.profile,serverId}).catch(error=>({error:error.message}));
  trace.status_snapshot=await api('mcp/status',{profile:base.profile,serverId}).catch(error=>({error:error.message}));
  trace.old_after=await api('mcp/get',{profile:base.profile,serverId:'defect-researcher'}).catch(error=>({error:error.message}));}
 trace.finished_at=new Date().toISOString();await save();console.log(JSON.stringify({status:trace.status,error:trace.error,status_snapshot:trace.status_snapshot}));
}
