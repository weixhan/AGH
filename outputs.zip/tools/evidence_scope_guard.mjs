// Pure policy for a public AGH tool_call hook. Loading/activation remains Host-owned.
const record = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const normalizeScopePath = value => typeof value === 'string' ? value.replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase() : '';
const normalizePath = normalizeScopePath;

export function createEvidenceScopeGuard(policy) {
  if (!record(policy) || Object.keys(policy).sort().join(',') !==
      'max_status_calls,qualified_status_tool,schema_version,task_id,workspace_root' ||
      policy.schema_version !== 1 || !normalizePath(policy.workspace_root) ||
      !/^[a-f0-9]{32}$/.test(policy.task_id) ||
      !/^mcp_[a-zA-Z0-9_]+_get_task_status$/.test(policy.qualified_status_tool) ||
      policy.max_status_calls !== 1) throw new Error('Invalid completed-evidence scope policy');
  const pinned = structuredClone(policy);
  const sessions = new Map();
  const deny = reason => Object.freeze({ allow: false, reason: `EVIDENCE_SCOPE_DENIED: ${reason}` });
  return (payload, context) => {
    const session = context?.session;
    if (!record(session) || typeof session.key !== 'string' || !session.key ||
        normalizePath(session.workspaceRoot) !== normalizePath(pinned.workspace_root))
      return deny('session workspace is outside the pinned evidence scope');
    if (context.replayed === true) return deny('replayed invocation is not permitted in this fresh acceptance session');
    if (!record(payload) || payload.name !== pinned.qualified_status_tool)
      return deny('only the pinned completed-task status tool is permitted');
    if (typeof payload.toolUseId !== 'string' || !payload.toolUseId)
      return deny('missing tool-call identity');
    if (!record(payload.args) || Object.keys(payload.args).join(',') !== 'task_id' ||
        payload.args.task_id !== pinned.task_id) return deny('arguments must identify exactly the pinned completed task');
    const state = sessions.get(session.key) ?? { accepted: new Set(), calls: 0 };
    if (state.accepted.has(payload.toolUseId)) return deny('duplicate tool-call identity');
    if (state.calls >= pinned.max_status_calls) return deny('completed-task status may be retrieved once');
    // Reserve synchronously before execution; concurrent duplicate calls cannot both pass.
    state.accepted.add(payload.toolUseId);
    state.calls++;
    sessions.set(session.key, state);
    return Object.freeze({ allow: true });
  };
}

export function createDiagnosticScopeGuard(policy) {
  if (!record(policy) || Object.keys(policy).sort().join(',') !==
      'max_status_calls,qualified_start_tool,qualified_status_tool,schema_version,workspace_root' ||
      policy.schema_version !== 1 || !normalizePath(policy.workspace_root) ||
      !/^mcp_[a-zA-Z0-9_]+_diagnose_validation_errors$/.test(policy.qualified_start_tool) ||
      !/^mcp_[a-zA-Z0-9_]+_get_task_status$/.test(policy.qualified_status_tool) ||
      policy.max_status_calls !== 20) throw new Error('Invalid diagnosis scope policy');
  const pinned = structuredClone(policy);
  const sessions = new Map();
  const deny = reason => ({ allow: false, reason: `DIAGNOSIS_SCOPE_DENIED: ${reason}` });
  const stateFor = context => {
    const session = context?.session;
    if (!record(session) || typeof session.key !== 'string' || !session.key ||
        normalizePath(session.workspaceRoot) !== normalizePath(pinned.workspace_root) || context.replayed === true)
      return undefined;
    if (!sessions.has(session.key)) sessions.set(session.key, { start: null, task: null, calls: 0, accepted: new Set() });
    return sessions.get(session.key);
  };
  return {
    tool_call(payload, context) {
      const state = stateFor(context);
      if (!state || !record(payload) || typeof payload.toolUseId !== 'string' || !payload.toolUseId)
        return deny('invalid session or tool-call identity');
      if (state.accepted.has(payload.toolUseId)) return deny('duplicate tool-call identity');
      if (payload.name === pinned.qualified_start_tool) {
        if (state.start || !record(payload.args) || Object.keys(payload.args).length !== 0)
          return deny('diagnosis may start once with empty arguments');
        state.start = payload.toolUseId;
        state.accepted.add(payload.toolUseId);
        return { allow: true };
      }
      if (payload.name !== pinned.qualified_status_tool) return deny('tool is outside the diagnosis protocol');
      if (!state.task || !record(payload.args) || Object.keys(payload.args).join(',') !== 'task_id' ||
          payload.args.task_id !== state.task) return deny('status must query the task returned by the one accepted start');
      if (state.calls >= pinned.max_status_calls) return deny('status polling budget exceeded');
      state.calls++;
      state.accepted.add(payload.toolUseId);
      return { allow: true };
    },
    tool_result(payload, context) {
      const state = stateFor(context);
      if (!state || payload?.toolUseId !== state.start || state.task !== null) return {};
      if (payload.result?.isError === true) return {};
      const text = payload.result?.content?.find(block => block.type === 'text')?.text;
      let result;
      try { result = JSON.parse(text); } catch { return {}; }
      if (!record(result) || !/^[a-f0-9]{32}$/.test(result.task_id) || !['running', 'completed'].includes(result.status))
        return {};
      state.task = result.task_id;
      return {};
    },
  };
}
