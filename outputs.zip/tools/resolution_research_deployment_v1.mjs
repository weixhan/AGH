// Shared inert deployment checks. Official admin writes require explicit calls.
import {readFile,stat,lstat,writeFile} from 'node:fs/promises';
import {createHash,randomUUID} from 'node:crypto';
import {resolve,dirname,join,relative,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createResolutionResearchScopeGuard,SERVER_ID,ACTION_TOOL,READ_TOOL} from './resolution_research_scope_guard_v1.mjs';

export const ROOT=resolve(dirname(fileURLToPath(import.meta.url)),'..');
export const ORIGIN='http://127.0.0.1:4177';
export const MODEL_KEYS=['schema_version','kind','deployment','source_lock','runtime_version','runner_source','task_prompt',
 'scope_policy','scope_candidate_path','scope_activation_path','mcp_activation_path','python_executable',
 'powershell_executable','model','route','server_id','domain_task_directory','output_directory'];
const object=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
export const exact=(v,keys)=>object(v)&&Object.keys(v).sort().join(',')===[...keys].sort().join(',');
export const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
export const stable=value=>JSON.stringify(value,(_k,v)=>object(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
export const inside=(root,path)=>{const value=relative(resolve(root),resolve(path));return value&&!value.startsWith('..')&&!isAbsolute(value);};

export async function regular(path){
 const absolute=resolve(path);
 for(let p=absolute;;p=dirname(p)){
  const value=await lstat(p);if(value.isSymbolicLink())throw new Error('Linked deployment or source path refused');
  if(p===dirname(p))break;
 }
 if(!(await stat(absolute)).isFile())throw new Error('Regular file required');return absolute;
}
export async function record(path){path=await regular(path);const bytes=await readFile(path);return{path,sha256:sha(bytes),size_bytes:bytes.length};}
export async function bound(pin){
 if(!exact(pin,['path','sha256'])||!isAbsolute(pin.path)||!/^[a-f0-9]{64}$/.test(pin.sha256))throw new Error('Exact path/hash pin required');
 const row=await record(pin.path);if(row.sha256!==pin.sha256)throw new Error('Pinned file changed');return JSON.parse(await readFile(row.path,'utf8'));
}
export async function readModelProtocol(path,expectedSha,{root=ROOT,now=Date.now,fixture_only=false}={}){
 path=resolve(path);if(!inside(join(root,'outputs'),path)||path!==join(dirname(path),'model_protocol.json'))throw new Error('Project-owned model_protocol.json required');
 const bytes=await readFile(await regular(path));if(!/^[a-f0-9]{64}$/.test(expectedSha)||sha(bytes)!==expectedSha)throw new Error('Model protocol pin changed');
 const p=JSON.parse(bytes);
 if(!exact(p,MODEL_KEYS)||p.schema_version!==1||p.kind!=='resolution_research_model_protocol_v1'||p.model!=='agnes-3.0-flash'||
  p.route!=='account-defect-researcher'||p.server_id!==SERVER_ID||resolve(p.output_directory)!==dirname(path))throw new Error('Fixed host model protocol differs');
 const deployment=await bound(p.deployment),lock=await bound(p.source_lock),runtime=await bound(p.runtime_version);
 const deploymentKeys=['schema_version','kind','request_id','task_id','workspace_root','started_epoch','started_monotonic','deadline_epoch','deadline_monotonic','contract_sha256'];
 if(!exact(deployment,deploymentKeys)||deployment.kind!=='resolution_research_mcp_deployment_v1'||deployment.schema_version!==1||
  deployment.deadline_epoch!==deployment.started_epoch+2400||deployment.deadline_monotonic!==deployment.started_monotonic+2400)
  throw new Error('Exact outer deployment clocks differ');
 createResolutionResearchScopeGuard(p.scope_policy);
 const policy=p.scope_policy;
 if(policy.request_id!==deployment.request_id||policy.task_id!==deployment.task_id||resolve(policy.workspace_root)!==resolve(deployment.workspace_root)||
  resolve(policy.workspace_root)!==join(dirname(path),'workspace')||Math.round(deployment.started_epoch*1000)!==policy.started_epoch_ms||
  Math.round(deployment.deadline_epoch*1000)!==policy.deadline_epoch_ms)throw new Error('Scope and deployment original anchors differ');
 if(!Number.isFinite(now())||now()<policy.started_epoch_ms||now()>=policy.deadline_epoch_ms)throw new Error('Original outer deadline expired or clock reversed');
 if(lock.kind!=='resolution_research_mcp_source_lock_v1'||!(lock.status==='passed_engineering_only'||fixture_only&&lock.status==='fixture_only')||
  !Array.isArray(lock.files)||!lock.files.length||!fixture_only&&lock.fixture_only!==false)throw new Error('Accepted engineering-only source lock required');
 const seen=new Set();
 for(const row of lock.files){
  if(!exact(row,['path','sha256','size_bytes']))throw new Error('Source record schema differs');
  const current=await record(row.path);if(stable(current)!==stable(row)||seen.has(current.path))throw new Error('Source bytes/membership differ');seen.add(current.path);
 }
 for(const key of ['runner_source','task_prompt']){
  const row=await record(p[key].path);if(!exact(p[key],['path','sha256'])||row.sha256!==p[key].sha256||!seen.has(row.path))throw new Error('Runner/prompt outside accepted source set');
 }
 for(const key of ['scope_candidate_path','scope_activation_path','mcp_activation_path']){
  if(resolve(p[key])!==join(dirname(path),key.replace('_path','')+'.json'))throw new Error('Fixed receipt path differs');
 }
 if(!isAbsolute(p.python_executable)||!isAbsolute(p.powershell_executable)||!isAbsolute(p.domain_task_directory)||
  !inside(root,p.domain_task_directory)||dirname(p.domain_task_directory)===dirname(path))throw new Error('Fixed executable/task paths differ');
 await regular(p.python_executable);await regular(p.powershell_executable);
 if(runtime.status!=='passed_local_repair'||runtime.repair_version!==2)throw new Error('Accepted V2 runtime required');
 return{path,sha256:expectedSha,protocol:p,deployment,lock,runtime,root};
}

export function scopeIdentity(requestId){return{scopeName:'resolution-research-scope-v1-'+requestId,
 packageId:'@defect-researcher/resolution-research-scope-v1-'+requestId};}
export async function readCandidate(loaded){
 const p=loaded.protocol,c=JSON.parse(await readFile(p.scope_candidate_path,'utf8')),id=scopeIdentity(p.scope_policy.request_id);
 const expected=join(p.scope_policy.workspace_root,'.agh/extensions',id.scopeName);
 if(c.status!=='prepared_not_activated'||c.package_id!==id.packageId||resolve(c.candidate)!==expected||c.model_protocol_sha256!==loaded.sha256||
  !Array.isArray(c.files)||c.files.length!==4||c.files.map(r=>r.name).sort().join(',')!=='guard.mjs,index.mjs,package.json,policy.json')throw new Error('Exact fresh scope candidate required');
 for(const row of c.files){const actual=await record(join(expected,row.name));if(row.path!==actual.path||row.sha256!==actual.sha256||row.size_bytes!==actual.size_bytes)throw new Error('Prepared candidate bytes changed');}
 return c;
}
export async function saveNew(path,value){await writeFile(path,JSON.stringify(value,null,2)+'\n',{flag:'wx',mode:0o600});}

export function adminClient(surface,{fetchImpl=fetch}={}){
 if(!['plugins','resources'].includes(surface))throw new Error('Only official loopback admin surfaces allowed');
 return async(route,body)=>{
  const response=await fetchImpl(ORIGIN+'/admin/'+surface+'/api/'+route,{method:body?'POST':'GET',
   headers:{Origin:ORIGIN,Accept:'application/json','Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
  const data=await response.json();if(!response.ok)throw new Error(route+': '+response.status);return data;
 };
}
export async function effect(api,route,params,base,trace,save,{operationRoute,success,now=Date.now,wait=ms=>new Promise(done=>setTimeout(done,ms)),recheck=async()=>{}}){
 await recheck();const step={route,params:{...base,commandId:'resolution-research-'+randomUUID(),...params}};
 trace.steps.push(step);await save();step.receipt=await api(route,step.params);await save();
 if(typeof step.receipt.operationId!=='string'||!step.receipt.operationId)throw new Error('Official operation ID required');
 const deadline=now()+60000;
 for(;;){step.operation=await api(operationRoute,{profile:base.profile,operationId:step.receipt.operationId});await save();
  if([success,'failed','cancelled','rolled-back'].includes(step.operation.state))break;
  if(now()>=deadline)throw new Error('Original admin deadline expired; preserve receipt');await wait(400);
 }
 if(step.operation.state!==success)throw new Error('Official '+route+' operation failed');return step.operation;
}
export function cliArgs(argv){
 if(argv.length!==4||argv[0]!=='--protocol'||argv[2]!=='--expected-sha256')throw new Error('Usage: --protocol <model_protocol.json> --expected-sha256 <SHA256>');
 return{path:argv[1],hash:argv[3]};
}
