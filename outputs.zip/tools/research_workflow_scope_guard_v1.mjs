// Public AGH hooks enforce one fixed workflow and a bounded model conversation.
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
// Official manifest limits the tool prefix to 33 characters; qualified names
// are capped at 64. Bind only the accepted short SID's exact observed names.
const START_TOOL = 'mcp_dr_workflow_v1_a78bff84_run_bounded_research_workflow_v1';
const STATUS_TOOL = 'mcp_dr_workflow_v1_a78bff84_get_research_workflow_status_v1';
const stable = value => JSON.stringify(value, (_key, item) => object(item)
  ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);
export const normalizeResearchPath = value => typeof value === 'string'
  ? value.replaceAll('\\', '/').replace(/\/+$/, '').toLowerCase() : '';

export function createResearchWorkflowScopeGuard(policy, now = Date.now) {
  const keys = ['schema_version','workspace_root','qualified_start_tool','qualified_status_tool','request_id',
    'workflow_id','case_id','budget','max_start_calls','max_status_calls','max_model_requests','max_wall_seconds'];
  if (!object(policy) || Object.keys(policy).sort().join(',') !== keys.sort().join(',') || policy.schema_version !== 1 ||
      !normalizeResearchPath(policy.workspace_root) || !/^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(policy.request_id) ||
      policy.workflow_id !== `research-workflow-v1-${policy.request_id}` || policy.case_id !== 'repair_coordinates' ||
      policy.qualified_start_tool !== START_TOOL || policy.qualified_status_tool !== STATUS_TOOL ||
      stable(policy.budget) !== stable({domain_invocations:6,wall_seconds:120,gpu_seconds:0,model_requests:0}) ||
      policy.max_start_calls !== 1 || policy.max_status_calls !== 6 || policy.max_model_requests !== 8 ||
      policy.max_wall_seconds !== 120) throw new Error('Invalid research workflow scope policy');
  const pinned = structuredClone(policy), sessions = new Map();
  const deny = reason => ({allow:false,reason:`RESEARCH_WORKFLOW_SCOPE_DENIED: ${reason}`});
  function stateFor(context) {
    const session = context?.session;
    if (!object(session) || typeof session.key !== 'string' || !session.key || context.replayed === true ||
        normalizeResearchPath(session.workspaceRoot) !== normalizeResearchPath(pinned.workspace_root)) return undefined;
    if (!sessions.has(session.key)) sessions.set(session.key, {requests:0,started:null,deadline:null,last:null,
      start:null,workflow:null,polls:0,accepted:new Set()});
    return sessions.get(session.key);
  }
  function current(state) {
    const value = now();
    if (!Number.isFinite(value) || (state.last !== null && value < state.last)) return false;
    state.last = value;
    return state.deadline === null || value < state.deadline;
  }
  return {
    before_request(payload, context) {
      const state = stateFor(context);
      if (!state || !object(payload) || payload.slot !== 'primary' || payload.model !== 'agnes-3.0-flash')
        return deny('invalid session or model route');
      if (!current(state)) return deny('original model deadline expired or clock reversed');
      if (state.requests >= pinned.max_model_requests) return deny('model request budget exhausted');
      if (state.started === null) { state.started=state.last; state.deadline=state.started+pinned.max_wall_seconds*1000; }
      state.requests++;
      return {allow:true,request_index:state.requests,started_epoch_ms:state.started,deadline_epoch_ms:state.deadline};
    },
    before_step(_payload, context) {
      const state = stateFor(context);
      if (!state || !current(state)) return {block:true,reason:'RESEARCH_WORKFLOW_SCOPE_DENIED: original model deadline expired'};
      return {};
    },
    tool_call(payload, context) {
      const state = stateFor(context);
      if (!state || !current(state) || state.requests === 0 || !object(payload) ||
          typeof payload.toolUseId !== 'string' || !payload.toolUseId) return deny('invalid call or expired session');
      if (state.accepted.has(payload.toolUseId)) return deny('duplicate call identity');
      if (payload.name === pinned.qualified_start_tool) {
        const expected = {request_id:pinned.request_id,case_id:pinned.case_id,budget:pinned.budget};
        if (state.start || stable(payload.args) !== stable(expected)) return deny('only one fixed request is allowed');
        state.start=payload.toolUseId; state.accepted.add(payload.toolUseId); return {allow:true};
      }
      if (payload.name !== pinned.qualified_status_tool) return deny('tool outside registered workflow scope');
      if (state.workflow !== pinned.workflow_id || !object(payload.args) || Object.keys(payload.args).join(',') !== 'workflow_id' ||
          payload.args.workflow_id !== state.workflow) return deny('status must follow the accepted start result');
      if (state.polls >= pinned.max_status_calls) return deny('status budget exhausted');
      state.polls++; state.accepted.add(payload.toolUseId); return {allow:true};
    },
    tool_result(payload, context) {
      const state = stateFor(context);
      if (!state || payload?.toolUseId !== state.start || state.workflow !== null || payload.result?.isError === true) return {};
      let value;
      try {
        const texts=payload.result?.content?.filter(item=>item.type==='text');
        if (texts?.length !== 1) return {};
        value=JSON.parse(texts[0].text);
      } catch { return {}; }
      if (object(value) && value.workflow_id === pinned.workflow_id && ['running','completed'].includes(value.status))
        state.workflow=value.workflow_id;
      return {};
    },
  };
}
