"""Generate new V12 JavaScript stage adapters from frozen V11 sources only.

Import is inert. Writes are exclusive and all destinations must be absent.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MEMBERS = ("comparison_scope_guard", "test_comparison_scope_guard",
           "prepare_comparison_scope", "enable_comparison_scope",
           "activate_comparison_mcp", "diagnose_comparison_mcp",
           "reconcile_comparison_mcp", "run_comparison_suite")
EXTRA_GUARD_TESTS = """
test('short V12 identities fit native prefix32 and full tool name64 for every stage',()=>{for(const stage of ['d','p','f']){const name='mcp_dr_cmp12_'+stage+'_12345678_execute_case_action_v1';const prefix=name.slice(0,-'execute_case_action_v1'.length);assert.ok(prefix.length<=32);assert.ok(name.length<=64);assert.doesNotThrow(()=>createComparisonGuard({...p,qualified_action_tool:name}));}});
test('legacy long-stage V11 and V12 tool identities cannot enter short V12 guard',()=>{for(const name of ['mcp_dr_compare_v11_diagnostic_12345678_execute_case_action_v1','mcp_dr_compare_v12_diagnostic_12345678_execute_case_action_v1','mcp_dr_cmp12_diagnostic_12345678_execute_case_action_v1'])assert.throws(()=>createComparisonGuard({...p,qualified_action_tool:name}));});
"""


def source(name):
    if name not in MEMBERS:
        raise ValueError("Unknown V12 adapter member")
    text = (ROOT / "tools" / (name + "_v11.mjs")).read_text("utf8")
    text = text.replace("_v11", "_v12").replace("-v11", "-v12").replace("V11", "V12")
    text = text.replace("mcp_dr_compare_v12_(diagnostic|pilot|formal)", "mcp_dr_cmp12_[dpf]")
    text = text.replace("mcp_dr_compare_v12_diagnostic_", "mcp_dr_cmp12_d_")
    text = text.replace("serverId='dr-compare-v12-diagnostic'", "serverId='dr-cmp12-d'")
    return text + (EXTRA_GUARD_TESTS if name == "test_comparison_scope_guard" else "")


def main():
    destinations = {name: ROOT / "tools" / (name + "_v12.mjs") for name in MEMBERS}
    if any(path.exists() for path in destinations.values()):
        raise FileExistsError("A V12 adapter already exists; frozen implementations cannot be replaced")
    texts = {name: source(name) for name in MEMBERS}
    for name, path in destinations.items():
        with path.open("x", encoding="utf8", newline="\n") as stream:
            stream.write(texts[name])


if __name__ == "__main__":
    main()
