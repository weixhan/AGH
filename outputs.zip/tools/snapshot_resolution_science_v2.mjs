// Save only the task's public SDK science fields: the official export masks one long decimal as an ID.
import { readFile, writeFile } from 'node:fs/promises';
import { webClient } from './agh_ws_client.mjs';
import { createHash } from 'node:crypto';
const output = 'outputs/agh-resolution-comparison';
const launch = JSON.parse(await readFile(output + '/runner.json', 'utf8'));
const rows = (await readFile(output + '/session-final-v2.jsonl', 'utf8')).trim().split('\n').map(JSON.parse);
const end = rows.filter(row => row.type === 'turn/end').at(-1);
const fields = ['comparison_status','split','val_images','val_boxes','train_imgsz','eval_imgsz','weight_sha256',
  'same_weight','device','precision','input_hashes_unchanged','test_inference_performed','training_performed','metrics','comparison'];
const record = { schema_version: 1, interface: 'public session.events SDK; selected scientific fields only',
  session_id: launch.session_id, task_id: launch.task_id, official_last_seq: end.seq, tool_summaries: [], final_model: null };
const client = await webClient();
let iterator;
try {
  const session = await client.session.load(launch.session_id, { cwd: process.cwd(), onPermissionRequest: async () => ({ verdict: 'rejected' }) });
  iterator = session.events()[Symbol.asyncIterator]();
  for (;;) {
    const next = await iterator.next();
    if (next.done) break;
    const event = next.value;
    if (event.type === 'tool/result') {
      const text = event.data.content?.find(item => item.type === 'text')?.text;
      let result;
      try { result = JSON.parse(text); } catch { /* unrelated result */ }
      if (result?.task_id === launch.task_id && result.status === 'completed') {
        record.tool_summaries.push({ seq: event.seq, toolUseId: event.data.toolUseId,
          summary: Object.fromEntries(fields.map(key => [key, result.summary[key]])) });
      }
    }
    if (event.type === 'assistant/message' && event.seq === end.data.lastAssistantSeq) {
      const text = event.data.content.filter(item => item.type === 'text').map(item => item.text).join('\n');
      record.final_model = { seq: event.seq, text, text_sha256: createHash('sha256').update(text).digest('hex') };
    }
    if (event.seq >= end.seq) break;
  }
  if (!record.final_model || !record.tool_summaries.length) throw new Error('No exact live scientific evidence');
  const text = JSON.stringify(record, null, 2) + '\n';
  if (/\bsk-[A-Za-z0-9._-]{12,}/.test(text)) throw new Error('Unexpected credential candidate in selected science');
  await writeFile(output + '/sdk-science-v2.json', text, { flag: 'wx' });
  console.log(JSON.stringify({ task_id: record.task_id, science_results: record.tool_summaries.length, final_model_seq: record.final_model.seq }));
} finally { await client.close(); await iterator?.return?.(); }
