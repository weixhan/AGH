"""Independently bind one guarded Agnes start/read session to a new CPU workflow.

This version verifies the owned worker's captured clock anchor independently.
It charges handoff delay to both original deadlines without adding tolerance.
This verifier uses official event exports and unmasked public SDK observations.
It does not import the controller, MCP server, runtime or scope guard. Long
decimal redactions stay unknown; the final scientific projection uses integers.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
UNKNOWN = "__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__"
PATH = ["verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence"]
FINAL_KEYS = {"status", "workflow_id", "research_status", "case_id", "actual_tool_path",
              "domain_invocations", "next_action", "synthetic_only", "new_inference_calls",
              "new_model_requests", "relative_small", "tiny_small", "resolution", "slicing", "evidence_ids"}
SCOPE_SENTENCE = "本次输入为隔离人工案例，科学结论复用历史验证证据；新增检测推理为0，不证明无限制研究自主性。"
FIXED_FREEZE_SHA256 = "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"
SCOPE_KEYS = {"schema_version", "workspace_root", "qualified_start_tool", "qualified_status_tool", "request_id",
              "workflow_id", "case_id", "budget", "max_start_calls", "max_status_calls", "max_model_requests", "max_wall_seconds"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def _pairs(values):
    result = {}
    for key, value in values:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def decode(text):
    return json.loads(text, object_pairs_hook=_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON number")))


def read(path):
    return decode(Path(path).read_text(encoding="utf-8"))


def lines(path):
    return [decode(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def exact(left, right):
    if isinstance(left, bool) or isinstance(right, bool):
        return type(left) is type(right) and left == right
    if isinstance(left, (int, float)) and isinstance(right, (int, float)):
        return math.isfinite(left) and math.isfinite(right) and left == right
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return left.keys() == right.keys() and all(exact(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(exact(a, b) for a, b in zip(left, right))
    return left == right


def normalize_path(value):
    return str(value).replace("\\", "/").rstrip("/").lower()


def epoch_ms(row):
    value = row.get("ts")
    require(isinstance(value, str), "Official event timestamp is absent")
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp() * 1000


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def validate_clock_anchor(registration, worker_start, worker_request, runtime, anchor, registration_sha256):
    """Check saved clock facts without importing the production clock adapter.

    The worker captures these origins before writing its request and the
    controller's initial ledger. Replaying those origins charges any intervening
    filesystem or scheduling delay instead of granting a new wall-time window.
    """
    keys = {"schema_version", "registration_sha256", "started_epoch", "started_monotonic",
            "original_deadline_epoch", "original_deadline_monotonic", "remaining_wall_seconds"}
    require(isinstance(anchor, dict) and set(anchor) == keys and type(anchor["schema_version"]) is int
            and anchor["schema_version"] == 1, "Worker clock anchor fields differ")
    require(isinstance(registration_sha256, str) and re.fullmatch(r"[0-9a-f]{64}", registration_sha256)
            and anchor["registration_sha256"] == registration_sha256,
            "Worker clock anchor is not bound to the owned registration bytes")
    require(all(finite(anchor[key]) for key in keys - {"schema_version", "registration_sha256"}),
            "Worker clock anchor contains a nonfinite or untyped clock value")
    require(finite(worker_start.get("started_epoch")) and worker_start["started_epoch"] <= anchor["started_epoch"],
            "Worker clock anchor predates its owned worker start")
    for clock in ("epoch", "monotonic"):
        begin, deadline = registration.get("started_" + clock), registration.get("deadline_" + clock)
        require(finite(begin) and finite(deadline) and deadline == begin + registration["request"]["budget"]["wall_seconds"],
                "Worker clock anchor registration has a reset original deadline")
        require(anchor["original_deadline_" + clock] == deadline and begin <= anchor["started_" + clock] < deadline,
                "Worker clock anchor reset or escaped an original registered deadline")
        require(0 <= anchor["started_" + clock] and finite(runtime.get("started_" + clock))
                and runtime["started_" + clock] == anchor["started_" + clock],
                "Controller ledger reset the captured worker clock origin")
    remaining = min(anchor["original_deadline_epoch"] - anchor["started_epoch"],
                    anchor["original_deadline_monotonic"] - anchor["started_monotonic"])
    require(0 < remaining <= registration["request"]["budget"]["wall_seconds"]
            and anchor["remaining_wall_seconds"] == remaining
            and worker_request["budget"]["wall_seconds"] == remaining,
            "Worker budget does not derive exactly from both original remaining deadlines")
    require(exact(runtime.get("budget"), worker_request["budget"]),
            "Controller ledger budget differs from the captured worker request")
    for clock in ("epoch", "monotonic"):
        deadline = anchor["started_" + clock] + remaining
        require(finite(runtime.get("deadline_" + clock)) and runtime["deadline_" + clock] == deadline
                and deadline <= registration["deadline_" + clock],
                "Controller deadline extends the original registered deadline or changes anchored arithmetic")
    return {"registration_sha256": registration_sha256, "remaining_wall_seconds": remaining,
            "started_epoch": anchor["started_epoch"], "started_monotonic": anchor["started_monotonic"],
            "epoch_extension_seconds": runtime["deadline_epoch"] - registration["deadline_epoch"],
            "monotonic_extension_seconds": runtime["deadline_monotonic"] - registration["deadline_monotonic"]}


def official_payload(text):
    """Keep observed masked numeric tokens unknown, without restoring disk data."""
    try:
        return decode(text), []
    except (json.JSONDecodeError, ValueError):
        pattern = r'([:,\[]\s*)-?(?:\d+\.)?\[REDACTED:id\](?=\s*[,}\]])'
        changed, count = re.subn(pattern, lambda match: match[1] + json.dumps(UNKNOWN), text)
        require(count > 0, "Official payload is neither strict JSON nor a supported numeric mask")
        value = decode(changed)
        masks = []
        def visit(item, path):
            if isinstance(item, dict):
                for key, child in item.items():
                    visit(child, path + [key])
            elif isinstance(item, list):
                for index, child in enumerate(item):
                    visit(child, path + [index])
            elif item == UNKNOWN:
                masks.append(path)
        visit(value, [])
        return value, masks


def final_value(text, *, official=False):
    blocks = re.findall(r"```json\s*\n(.*?)\n```", text, re.S)
    require(len(blocks) == 1, "Final message requires exactly one JSON code block")
    value, masks = official_payload(blocks[0]) if official else (decode(blocks[0]), [])
    require(isinstance(value, dict) and set(value) == FINAL_KEYS, "Final compact keys differ")
    require(not masks, "Integer final projection must remain directly verifiable")
    validate_final(value)
    require(re.sub(r"```json\s*\n.*?\n```", "", text, flags=re.S).strip() == SCOPE_SENTENCE,
            "Final scope declaration differs or includes unbound prose")
    return value


def validate_final(value):
    require(isinstance(value, dict) and set(value) == FINAL_KEYS, "Final compact keys differ")
    require(value["status"] == "completed" and value["research_status"] == "stopped"
            and value["case_id"] == "repair_coordinates" and value["next_action"] == "stop_no_registered_candidate"
            and value["actual_tool_path"] == PATH and value["synthetic_only"] is True,
            "Final workflow scope or evidence path differs")
    require(isinstance(value["workflow_id"], str) and re.fullmatch(r"research-workflow-v1-[A-Za-z0-9][A-Za-z0-9_-]{0,63}", value["workflow_id"]),
            "Final workflow identity is unsafe")
    require(type(value["domain_invocations"]) is int and value["domain_invocations"] == 6
            and type(value["new_inference_calls"]) is int and value["new_inference_calls"] == 0
            and type(value["new_model_requests"]) is int and value["new_model_requests"] == 0,
            "Final invocation counts must be exact integers")
    for field, definition in (("relative_small", "area_ratio_lt_0_005"), ("tiny_small", "area_lt_1024_px2")):
        row = value[field]
        require(isinstance(row, dict) and set(row) == {"definition_id", "gt", "tp_640", "tp_960"}
                and row["definition_id"] == definition and all(type(row[key]) is int and row[key] >= 0 for key in ("gt", "tp_640", "tp_960"))
                and row["tp_640"] <= row["gt"] and row["tp_960"] <= row["gt"], "Final small-defect population or integer counts differ")
    require(isinstance(value["resolution"], dict) and set(value["resolution"]) == {"fp_640", "fp_960"}
            and all(type(number) is int and number >= 0 for number in value["resolution"].values()), "Final false-positive counts are not exact integers")
    require(isinstance(value["slicing"], dict) and set(value["slicing"]) == {"candidate_status", "failed_gate_count"}
            and value["slicing"]["candidate_status"] == "stop" and type(value["slicing"]["failed_gate_count"]) is int
            and value["slicing"]["failed_gate_count"] > 0, "Final slicing stop lacks a typed gate count")
    ids = value["evidence_ids"]
    require(isinstance(ids, list) and len(ids) == 4 and len(set(ids)) == 4
            and all(isinstance(item, str) and item.startswith(value["workflow_id"] + ":") for item in ids), "Final evidence IDs differ")
    return value


def start_arguments(protocol):
    value = {key: protocol[key] for key in ("request_id", "case_id", "budget")}
    if "start_arguments" in protocol:
        require(exact(value, protocol["start_arguments"]), "Protocol duplicated start arguments differ")
    return value


def scope_policy(protocol):
    value = {key: protocol[key] for key in SCOPE_KEYS}
    if "scope_policy" in protocol:
        require(exact(value, protocol["scope_policy"]), "Duplicated scope projection differs from protocol")
    return value


def expected_summary(workflow_directory):
    directory = Path(workflow_directory)
    result, plan, evidence = read(directory / "result.json"), read(directory / "plan.json"), read(directory / "evidence.json")
    entries = evidence["entries"]
    science = [entry for entry in entries if entry["kind"] == "science"]
    require(len(science) == 1, "Exactly one source-bound historical science entry is required")
    summary = science[0]["summary"]
    def subset(row, keys):
        return {key: row[key] for key in keys}
    return {"status": result["status"], "workflow_id": result["workflow_id"],
            "research_status": result["research_status"], "case_id": result["case_id"],
            "actual_tool_path": result["actual_tool_path"], "domain_invocations": result["domain_invocations"],
            "next_action": plan["next_action"], "synthetic_only": result["synthetic_only"],
            "new_inference_calls": result["new_inference_calls"], "new_model_requests": result["new_model_requests"],
            "relative_small": subset(summary["relative_small"], ("definition_id", "gt", "tp_640", "tp_960")),
            "tiny_small": subset(summary["tiny_small"], ("definition_id", "gt", "tp_640", "tp_960")),
            "resolution": subset(summary["resolution"], ("fp_640", "fp_960")),
            "slicing": {"candidate_status": summary["slicing"]["candidate_status"],
                        "failed_gate_count": len(summary["slicing"]["failed_gates"])},
            "evidence_ids": [entry["evidence_id"] for entry in entries]}


def text_content(row):
    blocks = row.get("data", {}).get("content", [])
    return "\n".join(block["text"] for block in blocks if block.get("type") == "text")


def result_payload(row, *, official=False):
    blocks = [block for block in row.get("data", {}).get("content", []) if block.get("type") == "text"]
    require(len(blocks) == 1, "Tool result must have exactly one JSON text block")
    return official_payload(blocks[0]["text"]) if official else (decode(blocks[0]["text"]), [])


def aligned_ready(row, workspace):
    output = copy.deepcopy(row)
    for target in (output.get("data", {}), output.get("data", {}).get("policy", {})):
        if normalize_path(target.get("workspace_root")) == normalize_path(workspace):
            target["workspace_root"] = "<workspace>"
    return output


def _official_workspace_path(value, workspace):
    """Project two typed SDK paths using the official literal cwd boundary.

    export.ts passes cwd to privacyRules. replaceLiteralPath in the local
    official privacy source treats Windows separators and case alike, with a
    literal root boundary. This projects expected data; it never restores an
    official placeholder, changes SDK data, or interprets arbitrary prose.
    """
    require(isinstance(value, str) and isinstance(workspace, str), "Workspace path projection requires strings")
    windows = re.match(r"^[A-Za-z]:[\\/]", workspace) is not None or workspace.startswith("\\\\")
    normalized = re.sub(r"[\\/]+$" if windows else r"/+$", "", workspace) if len(workspace) > 1 else workspace
    require(normalized and normalized != "/", "A concrete workspace root is required")
    source = r"(?:\\\\|\\|/)".join(re.escape(part) for part in re.split(r"[\\/]", normalized)) if windows else re.escape(normalized)
    boundary = r'''(?=$|[\\/\s"',;:)])''' if windows else r"(?=$|/)"
    matched = re.match("^" + source + boundary, value, re.I if windows else 0)
    if matched is None:
        return value
    suffix = value[matched.end():]
    # The official text rule also recognizes punctuation/whitespace. Our only
    # allowed targets are typed paths, so require the semantic path boundary.
    if suffix and suffix[0] not in ("\\/" if windows else "/"):
        return value
    return "<workspace>" + suffix


def _official_projection(value, target, masks, workspace=None):
    expected = copy.deepcopy(target)
    if workspace is not None:
        if "report_path" in expected:
            expected["report_path"] = _official_workspace_path(expected["report_path"], workspace)
        if isinstance(expected.get("evidence"), dict) and "directory" in expected["evidence"]:
            expected["evidence"]["directory"] = _official_workspace_path(expected["evidence"]["directory"], workspace)
    for path in masks:
        require(path and path[0] not in {"summary", "workflow_id", "status"}, "Essential result field was masked")
        # Control-plane floating timestamps may be redacted by the official
        # exporter. They stay unknown and are checked through SDK + disk.
        require(path[0] in {"deadline_epoch", "original_deadline_epoch", "elapsed_seconds", "started_epoch", "budget_remaining_seconds"}
                or (path[0] == "budget_summary" and len(path) == 2 and path[1] in
                    {"original_deadline_epoch", "controller_wall_seconds", "controller_elapsed_seconds"})
                or (tuple(path) in {("scientific_summary", arm, key) for arm, keys in
                    (("relative_small", ("recall_640", "recall_960")), ("tiny_small", ("recall_640", "recall_960")),
                     ("resolution", ("map50_640", "map50_960")), ("slicing", ("map50_baseline", "map50_sliced"))) for key in keys})
                or (len(path) == 3 and path[0] == "claims" and type(path[1]) is int and path[2] == "value"),
                "Unsupported result redaction path")
        node = expected
        for key in path[:-1]:
            node = node[key]
        require(finite(node[path[-1]]) and type(node[path[-1]]) is float, "Mask is not a control-plane decimal")
        node[path[-1]] = UNKNOWN
    return exact(value, expected)


def terminal_compact(payload):
    science = payload.get("scientific_summary")
    require(isinstance(science, dict), "Completed MCP result lacks source-bound scientific summary")
    def subset(row, keys):
        return {key: row[key] for key in keys}
    value = {key: payload[key] for key in FINAL_KEYS - {"relative_small", "tiny_small", "resolution", "slicing"}}
    value.update(relative_small=subset(science["relative_small"], ("definition_id", "gt", "tp_640", "tp_960")),
                 tiny_small=subset(science["tiny_small"], ("definition_id", "gt", "tp_640", "tp_960")),
                 resolution=subset(science["resolution"], ("fp_640", "fp_960")),
                 slicing={"candidate_status": science["slicing"]["candidate_status"],
                          "failed_gate_count": len(science["slicing"]["failed_gates"])})
    return validate_final(value)


def check_ledger(rows, run, protocol, target):
    """Pure event checks used by synthetic negative tests and actual sessions."""
    checks, errors = {}, []
    active = "official_ledger_contiguous_and_timestamps_monotonic"
    try:
        require(rows and all(isinstance(row, dict) for row in rows), "Missing official event ledger")
        require(all(type(row.get("seq")) is int for row in rows)
                and [row["seq"] for row in rows] == list(range(1, len(rows) + 1)), "Official sequences are not typed contiguous integers")
        stamps = [epoch_ms(row) for row in rows]
        require(stamps == sorted(stamps), "Official timestamps move backwards")
        checks[active] = True
        active = "fresh_session_identity_and_runner_original_budget"
        require(rows[0].get("type") == "session/start" and rows[0].get("origin") == "system"
                and rows[0].get("trust") == "trusted" and rows[0].get("data", {}).get("key") == run.get("session_id"),
                "Official session identity is not a fresh trusted start")
        begin, deadline = run.get("model_started_epoch_ms"), run.get("deadline_epoch_ms")
        require(finite(begin) and finite(deadline) and deadline - begin == protocol["max_wall_seconds"] * 1000,
                "Runner reset or enlarged the original model deadline")
        require(normalize_path(run.get("cwd")) == normalize_path(protocol["workspace_root"])
                and exact(run.get("policy"), scope_policy(protocol)), "Runner and protocol workspace/scope differ")
        checks[active] = True
        calls = [row for row in rows if row.get("type") == "tool/call"]
        results = [row for row in rows if row.get("type") == "tool/result"]
        starts = [row for row in calls if row.get("data", {}).get("name") == protocol["qualified_start_tool"]]
        polls = [row for row in calls if row.get("data", {}).get("name") == protocol["qualified_status_tool"]]
        requests = [row for row in rows if row.get("type") == "request/sent"]
        costs = [row for row in rows if row.get("type") == "cost/ledger" and row.get("data", {}).get("purpose") == "inference"]
        ready = [row for row in rows if row.get("type", "").endswith("/scope-ready")]
        gates = [row for row in rows if row.get("type", "").endswith("/scope-decision")]
        approvals = [row for row in rows if row.get("type") == "approval/decided"]
        ends = [row for row in rows if row.get("type") == "turn/end"]
        active = "exactly_one_new_model_start_and_bounded_same_id_reads"
        require(len(starts) == protocol["max_start_calls"] == 1 and 1 <= len(polls) <= protocol["max_status_calls"] == 6
                and len(calls) == len(starts) + len(polls), "Tool call count or allowed tool set differs")
        require(all(row.get("origin") == "model" and row.get("trust") == "trusted" for row in calls)
                and starts[0]["seq"] < min(row["seq"] for row in polls), "Calls are not model-origin start then reads")
        require(exact(starts[0]["data"].get("args"), start_arguments(protocol))
                and all(exact(row["data"].get("args"), {"workflow_id": protocol["workflow_id"]}) for row in polls),
                "Model tool arguments do not match the frozen request and workflow")
        require(len({row["data"].get("toolUseId") for row in calls}) == len(calls)
                and all(isinstance(row["data"].get("toolUseId"), str) and row["data"]["toolUseId"] for row in calls),
                "Tool call identities are absent or duplicated")
        checks[active] = True
        active = "scope_ready_before_first_request_exact_registered_policy"
        require(len(ready) == 1 and requests and ready[0]["seq"] < requests[0]["seq"] < starts[0]["seq"],
                "Scope was not ready before the first model request")
        official_policy = copy.deepcopy(scope_policy(protocol)); official_policy["workspace_root"] = "<workspace>"
        require(ready[0].get("data", {}).get("mode") == "bounded-research-workflow-v1"
                and ready[0]["data"].get("session_key") == run["session_id"]
                and ready[0]["data"].get("workspace_root") == "<workspace>"
                and exact(ready[0]["data"].get("policy"), official_policy), "Official scope-ready policy differs")
        require(run.get("scope_ready", {}).get("seq") == ready[0]["seq"]
                and exact(aligned_ready(run["scope_ready"], protocol["workspace_root"]), ready[0]),
                "SDK readiness differs from official event")
        checks[active] = True
        active = "all_calls_paired_with_successful_official_results_and_scope_gates"
        require(len(results) == len(calls) == len(gates), "Call/result/gate counts differ")
        payloads, masks_seen = [], []
        for call in calls:
            use_id = call["data"]["toolUseId"]
            matched = [row for row in results if row.get("data", {}).get("toolUseId") == use_id]
            decisions = [row for row in gates if row.get("data", {}).get("tool_use_id") == use_id]
            require(len(matched) == len(decisions) == 1, "Result/gate pairing is not unique")
            result, gate = matched[0], decisions[0]
            require(call["seq"] < gate["seq"] < result["seq"] and result.get("sourceEventSeqs") == [call["seq"]]
                    and result["data"].get("isError") is False and result["data"].get("code") not in {"HOOK_DENIED", "APPROVAL_REJECTED"},
                    "Tool result is missing, refused or out of order")
            require(result.get("origin") == "tool:" + call["data"]["name"] and result.get("trust") == "untrusted",
                    "Official result is not native untrusted tool evidence")
            require(gate.get("data", {}).get("allow") is True and gate["data"].get("reason") is None
                    and gate["data"].get("name") == call["data"]["name"] and gate["data"].get("session_key") == run["session_id"]
                    and gate.get("origin") == ready[0].get("origin") and str(gate.get("origin", "")).startswith("ext:plugin/")
                    and gate["type"].rsplit("/", 1)[0] == ready[0]["type"].rsplit("/", 1)[0], "Scope gate differs or denied")
            sdk = [row for row in run.get("results", []) if row.get("seq") == result["seq"]]
            require(len(sdk) == 1 and sdk[0].get("tool_use_id") == use_id and sdk[0].get("is_error") is False,
                    "Public SDK result identity or success differs")
            payload, masks = result_payload(result, official=True)
            require(_official_projection(payload, sdk[0].get("payload"), masks, protocol["workspace_root"]),
                    "Official result does not match SDK observations and known cwd projection")
            require(payload.get("workflow_id") == protocol["workflow_id"], "Tool result uses a different workflow")
            payloads.append((call, result, sdk[0]["payload"])); masks_seen.extend(masks)
        require(len(run.get("results", [])) == len(results), "Extra SDK results")
        checks[active] = True
        active = "sdk_call_and_hook_events_exact_official"
        require(len(run.get("calls", [])) == len(calls) and len(run.get("hook_events", [])) == len(gates), "SDK call/gate inventory differs")
        for call, sdk in zip(calls, run["calls"]):
            require(sdk.get("seq") == call["seq"] and sdk.get("origin") == call.get("origin")
                    and sdk.get("name") == call["data"]["name"] and exact(sdk.get("args"), call["data"].get("args")),
                    "SDK tool call differs")
        for gate, sdk in zip(gates, run["hook_events"]):
            require(exact(sdk, gate), "SDK scope gate differs")
        checks[active] = True
        active = "write_start_allow_once_and_actual_read_approvals_exact_call_scope"
        permissions = run.get("permissions", [])
        require(len(approvals) == len(permissions) and 1 <= len(approvals) <= len(calls),
                "Actual approval inventory is absent, inconsistent or exceeds tool calls")
        matched_permissions = set()
        matched_approvals = set()
        for call in calls:
            permitted = [permission for permission in permissions if permission.get("tool_call_id") == call["data"]["toolUseId"]]
            paired = [row for row in approvals if row["data"].get("scope") == f"tool:{call['data']['name']}:execute"
                      and call["seq"] < row["seq"] < next(result["seq"] for result in results if result["data"]["toolUseId"] == call["data"]["toolUseId"])]
            required_count = 1 if call["data"]["name"] == protocol["qualified_start_tool"] else len(paired)
            require(len(paired) == len(permitted) == required_count and len(paired) <= 1,
                    "Write start needs Allow once; native read may omit approval but cannot duplicate it")
            if not paired:
                continue
            permission = permitted[0]
            require(paired[0]["data"].get("verdict") == "allowed-once"
                    and permission.get("decision") == "allowed-once" and permission.get("tool") == call["data"]["name"]
                    and permission.get("tool_call_id") == call["data"]["toolUseId"]
                    and exact(permission.get("input"), call["data"].get("args")), "Approval is missing, persistent, rejected or for a different call")
            matched_permissions.add(id(permission)); matched_approvals.add(paired[0]["seq"])
        require(len(matched_permissions) == len(permissions) and len(matched_approvals) == len(approvals),
                "Unmatched official or SDK approval records")
        checks[active] = True
        active = "actual_agnes_requests_bounded_successful_and_original_deadline"
        require(1 <= len(requests) <= protocol["max_model_requests"] == 8 and len(costs) == len(requests),
                "Actual request count exceeds cap or lacks successful inference costs")
        require(all(row.get("origin") == "system" and row.get("trust") == "trusted"
                    and row["data"].get("model", {}).get("id") == "agnes-3.0-flash"
                    and row["data"].get("model", {}).get("route") == "account-defect-researcher" for row in requests)
                and all(row["data"].get("model") == "agnes-3.0-flash" and row["data"].get("response", {}).get("status") == 200 for row in costs),
                "Official ledger does not show successful Agnes inference")
        require(all(begin <= epoch_ms(row) < deadline for row in requests + costs + calls + results + ends),
                "Request, tool action or final turn escaped the original shared model deadline")
        require(type(run.get("model_request_count")) is int and run["model_request_count"] == len(requests) and run.get("new_model_inference_performed") is True,
                "Runner inference count/flag differs from actual requests")
        checks[active] = True
        active = "one_completed_turn_after_new_completed_workflow_read"
        terminal = [(call, result, payload) for call, result, payload in payloads
                    if call["data"]["name"] == protocol["qualified_status_tool"] and payload.get("status") == "completed"]
        require(terminal and len(ends) == 1 and ends[0]["data"].get("reason") == "completed", "No completed workflow read or turn")
        require(exact(terminal_compact(terminal[-1][2]), target), "Terminal source summary differs from current verified workflow")
        final = [row for row in rows if row.get("type") == "assistant/message" and row.get("seq") == ends[0]["data"].get("lastAssistantSeq")]
        require(len(final) == 1 and terminal[-1][1]["seq"] < final[0]["seq"] < ends[0]["seq"], "Final model message did not follow completed proof")
        require(final[0].get("origin") == "model" and final[0].get("trust") == "trusted"
                and ends[0].get("origin") == "system" and ends[0].get("trust") == "trusted", "Final message/turn origin differs")
        checks[active] = True
        active = "official_and_sdk_final_integer_source_claims_exact"
        require(exact(final_value(text_content(final[0]), official=True), target), "Official final source claims differ")
        sdk_final = [row for row in run.get("final_texts", []) if row.get("seq") == final[0]["seq"]]
        require(len(sdk_final) == 1 and exact(final_value(text_content(sdk_final[0])), target)
                and exact(run.get("final_json"), target), "SDK final JSON differs from actual source")
        checks[active] = True
        active = "runner_completed_without_export_failure_and_scope_boundaries_honest"
        require(run.get("status") == "completed" and not run.get("failure") and not run.get("export_failure")
                and run.get("tool_catalog_narrowed") is False and run.get("new_detection_inference_performed") is False,
                "Runner failed, export failed, or inference/catalog boundary was misreported")
        checks[active] = True
        return {"checks": checks, "errors": errors, "model_request_count": len(requests), "tool_call_count": len(calls),
                "status_read_count": len(polls), "approval_count": len(approvals), "masked_numeric_paths_not_recovered": masks_seen,
                "official_workspace_path_fields_projected": ["report_path", "evidence.directory"],
                "start_call_epoch_ms": epoch_ms(starts[0]), "terminal_result_epoch_ms": epoch_ms(terminal[-1][1]),
                "terminal_payload": terminal[-1][2], "final_text": text_content(final[0])}
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
        return {"checks": checks, "errors": errors}


def validate_protocol(protocol):
    require(protocol.get("schema_version") == 1 and type(protocol["schema_version"]) is int
            and protocol.get("server_id") == "dr-workflow-v1", "Incorrect protocol schema or server")
    require(protocol.get("case_id") == "repair_coordinates" and protocol.get("workflow_id") == "research-workflow-v1-" + protocol["request_id"]
            and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", protocol["request_id"]), "Unsafe or nonfixed workflow request")
    require(exact(protocol.get("budget"), {"domain_invocations": 6, "wall_seconds": 120, "gpu_seconds": 0, "model_requests": 0})
            and all(type(protocol["budget"][key]) is int for key in protocol["budget"]), "Protocol budget changed or contains noninteger counts")
    require(all(type(protocol.get(key)) is int and protocol[key] == count for key, count in
                (("max_start_calls", 1), ("max_status_calls", 6), ("max_model_requests", 8), ("max_wall_seconds", 120)))
            and protocol.get("new_inference_allowed") is False, "Model scope or budget was enlarged")
    require(type(protocol.get("workspace_root")) is str and Path(protocol["workspace_root"]).resolve().is_relative_to(ROOT)
            and all(type(protocol.get(key)) is str and protocol[key].startswith("mcp_") for key in ("qualified_start_tool", "qualified_status_tool"))
            and protocol["qualified_start_tool"] != protocol["qualified_status_tool"], "Workspace or official tool identities differ")
    start_arguments(protocol)
    scope_policy(protocol)
    return protocol


def bound_file(record):
    require(isinstance(record, dict) and set(record) >= {"path", "sha256"}, "Missing source binding")
    path = Path(record["path"]).resolve()
    require(path.is_relative_to(ROOT) and path.is_file() and digest(path) == record["sha256"], "Bound source is absent, outside project or modified")
    if "size_bytes" in record:
        require(type(record["size_bytes"]) is int and record["size_bytes"] == path.stat().st_size, "Bound source size differs")
    return path


def verify_local_binding(protocol, run, ledger):
    checks, errors = {}, []
    active = "owned_new_workflow_and_registry_paths"
    try:
        workspace = Path(protocol["workspace_root"]).resolve()
        directory = Path(run["workflow_directory"]).resolve()
        registry = Path(run["registry_directory"]).resolve()
        identity = protocol["workflow_id"]
        require(directory.is_relative_to(workspace) and directory.name == identity
                and registry.is_relative_to(workspace) and registry.name == identity
                and registry.parent.name == "research-mcp-v2" and registry.parent.parent.name == ".runtime"
                and directory.is_dir() and registry.is_dir(), "Workflow or registry is not newly owned by this isolated workspace")
        require(not any((directory / name).exists() for name in ("failure.json", "completion_rejected.json"))
                and not (registry / "wrapper_failure.json").exists(), "Accepted workflow has a preserved failed or rejected publication")
        checks[active] = True
        active = "registration_sha_exact_request_configuration_and_original_deadline"
        registration = read(registry / "registration.json")
        require((registry / "registration.sha256").read_text(encoding="ascii").strip() == digest(registry / "registration.json"),
                "Owned registration bytes changed")
        require(exact(registration.get("source_state", {}).get("deployment_source_lock"), protocol["source_lock"]),
                "Registry deployment source lock differs from the frozen model protocol")
        require(registration.get("source_state", {}).get("runtime_sha256") == digest(ROOT / "defect_researcher/research_mcp_runtime_v2.py"),
                "Registry was created by a different runtime source")
        require(registration.get("source_state", {}).get("controller_sha256") == digest(ROOT / "defect_researcher/research_workflow_clock_v2.py"),
                "Registry was created for a different anchored clock controller source")
        freeze_path = ROOT / "outputs/research-workflow-implementation-v1/freeze.json"
        require(digest(freeze_path) == FIXED_FREEZE_SHA256 == registration.get("source_state", {}).get("freeze_sha256"),
                "Original accepted workflow freeze changed")
        frozen = read(freeze_path)
        require(frozen.get("status") == "passed" and frozen.get("execution_source_count") == 18
                and len(frozen.get("sources", [])) == len(frozen.get("archive", [])) == 25
                and len(frozen.get("preserved_files", [])) == 968, "Original frozen protected populations differ")
        for group in ("sources", "archive", "preserved_files"):
            for member in frozen[group]:
                path = Path(member["path"]).resolve()
                require(path.is_file() and type(member["size_bytes"]) is int and member["size_bytes"] == path.stat().st_size
                        and digest(path) == member["sha256"], "Accepted or historical protected evidence bytes changed")
        expected_request = {"schema_version": 1, "workflow_version": 1, **start_arguments(protocol)}
        require(registration.get("schema_version") == 1 and registration.get("owner") == "defect_researcher.research_mcp_runtime_v2"
                and registration.get("workflow_id") == identity and exact(registration.get("request"), expected_request), "Registered request differs")
        config = registration.get("configuration", {})
        require(Path(config.get("output_root", "")).resolve() == directory.parent, "Registered output is a different directory")
        for clock in ("epoch", "monotonic"):
            begin, deadline = registration.get("started_" + clock), registration.get("deadline_" + clock)
            require(finite(begin) and finite(deadline) and deadline == begin + protocol["budget"]["wall_seconds"], "Registered original deadline was reset")
        require(ledger["start_call_epoch_ms"] <= registration["started_epoch"] * 1000 < run["deadline_epoch_ms"],
                "Local workflow preexisted the model start or began after the model deadline")
        checks[active] = True
        active = "owned_worker_pid_start_exit_and_no_deadline_extension"
        launch, worker_start = read(registry / "launch.json"), read(registry / "worker_started.json")
        worker_request, worker_exit = read(registry / "worker_request.json"), read(registry / "worker_exit.json")
        require(type(launch.get("pid")) is int and launch["pid"] > 0 and worker_start.get("pid") == launch["pid"]
                and launch.get("registration_sha256") == digest(registry / "registration.json"), "Worker launch identity differs")
        require(finite(launch.get("launched_epoch")) and finite(worker_start.get("started_epoch")) and finite(worker_exit.get("finished_epoch"))
                and registration["started_epoch"] <= launch["launched_epoch"] <= worker_exit["finished_epoch"]
                and registration["started_epoch"] <= worker_start["started_epoch"] <= worker_exit["finished_epoch"]
                and type(worker_exit.get("exit_code")) is int and worker_exit["exit_code"] == 0, "Owned worker did not finish successfully in order")
        require({key: value for key, value in worker_request.items() if key != "budget"} == {key: value for key, value in expected_request.items() if key != "budget"}
                and exact({key: value for key, value in worker_request["budget"].items() if key != "wall_seconds"},
                          {key: value for key, value in expected_request["budget"].items() if key != "wall_seconds"})
                and finite(worker_request["budget"]["wall_seconds"]) and 0 < worker_request["budget"]["wall_seconds"] <= 120,
                "Worker request changed case, tools or enlarged its budget")
        require(exact(read(directory / "request.json"), worker_request), "Controller request differs from owned worker request")
        runtime, completion = read(directory / "runtime.json"), read(directory / "completion.json")
        checks[active] = True
        active = "trusted_clock_anchor_preserves_both_original_deadlines"
        anchor_binding = validate_clock_anchor(registration, worker_start, worker_request, runtime,
                        read(registry / "worker_clock_anchor.json"), digest(registry / "registration.json"))
        checks[active] = True
        active = "owned_completion_and_worker_exit_within_original_deadlines"
        require(worker_start["started_epoch"] <= runtime["started_epoch"] <= completion["completed_epoch"] <= worker_exit["finished_epoch"]
                and completion["completed_epoch"] * 1000 <= ledger["terminal_result_epoch_ms"] < run["deadline_epoch_ms"]
                and completion["completed_epoch"] < registration["deadline_epoch"]
                and worker_exit["finished_epoch"] < registration["deadline_epoch"]
                and worker_exit["finished_epoch"] * 1000 < run["deadline_epoch_ms"],
                "Workflow completion or worker exit escaped an original workflow or model deadline")
        checks[active] = True
        active = "current_stdlib_workflow_replay_all_checks_passed"
        verifier_path = ROOT / "tools/verify_research_workflow_v1.py"
        specification = importlib.util.spec_from_file_location("independent_workflow_replay_for_model_v2", verifier_path)
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
        independent = module.verify(directory)
        require(independent.get("status") == "passed" and independent.get("workflow_id") == identity
                and independent.get("prepublication") is False and type(independent.get("passed_checks")) is int
                and type(independent.get("total_checks")) is int and independent["passed_checks"] == independent["total_checks"] > 0
                and all(value is True for value in independent["checks"].values()), "Fresh independent local workflow replay failed")
        checks[active] = True
        active = "terminal_evidence_paths_hashes_and_full_science_summary_exact"
        target = expected_summary(directory)
        validate_final(target)
        terminal = ledger["terminal_payload"]
        require(exact(terminal_compact(terminal), target), "MCP compact summary does not derive from this new workflow")
        science = next(entry for entry in read(directory / "evidence.json")["entries"] if entry["kind"] == "science")
        require(exact(terminal["scientific_summary"], science["summary"]), "MCP complete scientific summary differs from sealed source evidence")
        evidence = terminal.get("evidence", {})
        require(normalize_path(evidence.get("directory")) == normalize_path(directory)
                and evidence.get("completion_sha256") == digest(directory / "completion.json")
                and evidence.get("manifest_sha256") == digest(directory / "artifact_manifest.json")
                and evidence.get("independent_verification_sha256") == digest(directory / "independent_verification.json"), "MCP terminal publication hashes differ")
        checks[active] = True
        active = "terminal_claim_source_ids_budget_and_current_verification_exact"
        expected_claims, expected_sources, source_ids = [], [], {}
        entries = {entry["evidence_id"]: entry for entry in read(directory / "evidence.json")["entries"]}
        for claim in read(directory / "claims.json")["claims"]:
            entry = entries[claim["evidence_id"]]
            members = []
            for record in entry["files"]:
                sha = record["sha256"]
                if sha not in source_ids:
                    source_ids[sha] = "source-" + str(len(source_ids) + 1)
                    expected_sources.append({"source_id": source_ids[sha], "sha256": sha})
                members.append(source_ids[sha])
            expected_claims.append({**claim, "source_ids": list(dict.fromkeys(members)),
                "scope": "sealed_validation_reuse" if entry["origin"] == "historical_reuse" else "isolated_synthetic_case"})
        result = read(directory / "result.json")
        require(exact(terminal.get("claims"), expected_claims) and exact(terminal.get("sources"), expected_sources)
                and normalize_path(terminal.get("report_path")) == normalize_path(directory / "report.md"), "MCP claim/source/report bindings differ")
        require(exact(terminal.get("verification"), {"status": "passed", "checks_total": independent["total_checks"],
                    "checks_passed": independent["passed_checks"], "completion_sha256": digest(directory / "completion.json")}), "MCP independent verification counts differ")
        require(exact(terminal.get("budget_summary"), {"domain_invocations": 6, "gpu_seconds": 0, "model_requests": 0,
                    "original_wall_seconds": 120, "controller_wall_seconds": worker_request["budget"]["wall_seconds"],
                    "original_deadline_epoch": registration["deadline_epoch"],
                    "controller_elapsed_seconds": result["final_budget"]["elapsed_wall_seconds"]})
                and exact(terminal.get("source_scope"), {"input": "isolated_synthetic_case", "science": "sealed_validation_reuse", "fresh_detector_calls": 0, "fresh_model_requests": 0}),
                "MCP budget or population scope differs from actual local execution")
        checks[active] = True
        return {"checks": checks, "errors": errors, "workflow_directory": str(directory), "registry_directory": str(registry),
                "workflow_verification": independent, "expected_final": target,
                "clock_anchor_binding": anchor_binding,
                "registration_deadline_epoch": registration["deadline_epoch"], "controller_deadline_epoch": runtime["deadline_epoch"],
                "completion_epoch": completion["completed_epoch"], "worker_exit_epoch": worker_exit["finished_epoch"]}
    except Exception as error:
        checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
        return {"checks": checks, "errors": errors}


def verify(directory):
    directory = Path(directory).resolve()
    checks, errors = {}, []
    active = "model_protocol_and_official_export_inventory"
    report = {"schema_version": 1, "kind": "independent_bounded_research_workflow_model_verification_v2",
              "checked_at": datetime.now(timezone.utc).isoformat(), "model_inference_performed_by_reviewer": False,
              "new_detector_predictions_by_reviewer": 0, "model_used": False, "independent_of_runtime": True}
    try:
        protocol = validate_protocol(read(directory / "protocol.json"))
        run, rows = read(directory / "run_result.json"), lines(directory / "session.jsonl")
        require((directory / "session.html").is_file(), "Official HTML session export is absent")
        report.update(workflow_id=protocol["workflow_id"], session_id=run.get("session_id"),
                      protocol_sha256=digest(directory / "protocol.json"), runner_result_sha256=digest(directory / "run_result.json"),
                      official_event_sha256=digest(directory / "session.jsonl"), official_html_sha256=digest(directory / "session.html"))
        checks[active] = True
        active = "source_lock_guard_and_model_runner_current_bindings"
        require(all(key in protocol and exact(protocol[key], run.get(key)) for key in ("source_lock", "scope_guard", "runner_source")),
                "Protocol and runner execution source bindings differ")
        for key in ("source_lock", "scope_guard", "runner_source"):
            bound_file(protocol[key])
        lock = read(bound_file(protocol["source_lock"]))
        require(lock.get("schema_version") == 1 and type(lock["schema_version"]) is int
                and lock.get("kind") == "research_mcp_implementation_v2" and lock.get("status") == "passed"
                and isinstance(lock.get("files"), list) and len(lock["files"]) >= 6, "Sidecar deployment lock omits accepted execution source members")
        for member in lock["files"]:
            bound_file(member)
        require(len({normalize_path(member["path"]) for member in lock["files"]}) == len(lock["files"]), "Duplicate sidecar lock members")
        required = {normalize_path(ROOT / name) for name in ("defect_researcher/research_mcp_runtime_v2.py",
                    "defect_researcher/research_mcp_server_v2.py", "run_research_mcp_v2.py", "defect_researcher/research_workflow_clock_v2.py",
                    "outputs/research-workflow-implementation-v1/freeze.json", "config/local.json")}
        require(required <= {normalize_path(member["path"]) for member in lock["files"]},
                "Sidecar deployment lock omits runtime, server, launcher, clock controller, original freeze or fixed configuration")
        checks[active] = True
        active = "unmasked_final_claims_derive_from_current_new_workflow"
        target = expected_summary(run["workflow_directory"])
        validate_final(target)
        ledger = check_ledger(rows, run, protocol, target)
        checks.update(ledger["checks"]); errors.extend(ledger["errors"])
        require(not ledger["errors"], "Official model event verification failed")
        report["model_ledger"] = ledger
        binding = verify_local_binding(protocol, run, ledger)
        checks.update(binding["checks"]); errors.extend(binding["errors"])
        require(not binding["errors"], "Owned current workflow binding failed")
        report["local_binding"] = binding
        active = "runner_finished_and_exported_within_original_model_deadline"
        require(finite(run.get("finished_epoch_ms")) and run["model_started_epoch_ms"] <= run["finished_epoch_ms"] < run["deadline_epoch_ms"],
                "Runner/export finalization escaped the original model deadline")
        checks[active] = True
        active = "no_credential_candidates_in_public_export_and_result_files"
        candidates = []
        for name in ("protocol.json", "run_result.json", "session.jsonl", "session.html"):
            raw = (directory / name).read_text(encoding="utf-8")
            if re.search(r"\bsk-[A-Za-z0-9_-]{20,}\b", raw) or re.search(r'"(?:api_key|access_token|authorization)"\s*:\s*"(?!\[REDACTED|<)[^"\s]{12,}"', raw, re.I):
                candidates.append(name)
        require(not candidates, "Credential-shaped values found in public evidence files")
        checks[active] = True
    except Exception as error:
        if active not in checks:
            checks[active] = False
        errors.append({"check": active, "type": type(error).__name__, "message": str(error)})
    report.update(status="passed" if checks and all(checks.values()) and not errors else "failed",
                  checks=checks, passed_checks=sum(value is True for value in checks.values()), total_checks=len(checks), errors=errors,
                  verifier_sha256=digest(__file__),
                  limitations=["One fixed repair case is driven by Agnes; twelve local synthetic cases and reused validation science are separate evidence populations.",
                               "The model may use only one fixed write start with Allow once and at most six native readonly status reads; any requested read approvals must be actual Allow once. The unchanged catalog is restricted before execution.",
                               "Current workflow publication and known integer scientific claims are checked; official masked timestamps remain unknown and use separately saved SDK/disk checks.",
                               "No new detector, training, test inference, new candidate experiment or proof of unrestricted research autonomy."])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    require(not output.exists(), "Verification output already exists")
    require(not output.is_relative_to(args.directory.resolve()), "Verification output must be outside evidence directory")
    report = verify(args.directory)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report.get(key) for key in ("status", "passed_checks", "total_checks", "workflow_id", "errors")}, ensure_ascii=True))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
