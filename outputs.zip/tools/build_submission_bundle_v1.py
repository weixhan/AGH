"""Build a whitelist-only CPU source ZIP, then actually smoke its extracted copy."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
from urllib.parse import urlsplit, urlunsplit
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DESTINATION = ROOT / "outputs" / "submission-bundle-v1-exclusive"
MAX_ZIP_BYTES = 200 * 1024 * 1024
# Explicit source closure for the CPU LabelGuard path. No recursive source copying.
PROJECT_ALLOWLIST = (
    "pyproject.toml", "README.md", "config/example.json", "config/submission-team.json",
    "fixtures/labelguard_cases.json", "fixtures/geometry_cases.json",
    "defect_researcher/__init__.py", "defect_researcher/config.py", "defect_researcher/audit.py",
    "defect_researcher/labelguard_fixtures.py", "defect_researcher/label_repair.py",
    "defect_researcher/geometry_verifier.py", "defect_researcher/independent_geometry.py",
    "defect_researcher/task_runtime.py", "tools/run_labelguard_acceptance.py",
    "tools/verify_labelguard_run.py", "tools/migration_smoke_v1.py",
    "tools/build_submission_bundle_v1.py", "docs/delivery-package-v1.md",
)
RESEARCH_ALLOWLIST = ("cableinspect_geometry.py", "数据处理/7检查YOLO标注数据.py")
FORBIDDEN_PARTS = {"node_modules", ".runtime", ".git", "__pycache__", ".aws", ".codex", ".agents"}
FORBIDDEN_SUFFIXES = {".pt", ".pth", ".onnx", ".safetensors", ".pyc", ".env"}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8", newline="\n")


def record(path: Path, root: Path) -> dict:
    return {"path": path.relative_to(root).as_posix(), "size_bytes": path.stat().st_size,
            "sha256": digest(path)}


def safe_file(path: Path, root: Path) -> Path:
    if not path.resolve().is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError("Missing or out-of-scope allowlisted file: " + str(path))
    for parent in (path, *path.parents):
        if parent.is_symlink() or (hasattr(parent, "is_junction") and parent.is_junction()):
            raise ValueError("Linked source paths are not allowed: " + str(path))
        if parent == root:
            break
    return path


def source_identity(path: Path) -> dict:
    def git(*arguments):
        process = subprocess.run(["git", "-C", str(path), *arguments], capture_output=True, text=True, check=False)
        return process.stdout.strip() if process.returncode == 0 else None
    try:
        commit = git("rev-parse", "HEAD")
        origin = git("remote", "get-url", "origin")
    except OSError:
        commit, origin = None, None
    if origin and "://" in origin:
        parsed = urlsplit(origin)
        host = parsed.hostname or ""
        if parsed.port:
            host += ":" + str(parsed.port)
        origin = urlunsplit((parsed.scheme, host, parsed.path, "", ""))
    return {"local_source_root": str(path.resolve()), "git_commit": commit,
            "origin_without_credentials": origin,
            "identity_note": "Copied-file SHA256 records are authoritative for this snapshot; a Git commit does not establish a clean worktree."}


def credential_scan(root: Path) -> dict:
    """Detect recognizable credential literals without reporting their values."""
    patterns = {
        "private_key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
        "aws_access_key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
        "github_token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})\b"),
        "provider_key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b"),
        "bearer_literal": re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{20,}", re.I),
        "credential_assignment": re.compile(r'''["']?(?:api[_-]?key|access[_-]?token|client[_-]?secret|password|provider[_-]?key)["']?\s*[:=]\s*["']([^"'\r\n]{8,})["']''', re.I),
    }
    placeholders = {"REDACTED", "YOUR_API_KEY", "YOUR_TOKEN", "EXAMPLE_ONLY", "PLACEHOLDER"}
    findings = []
    files = sorted(p for p in root.rglob("*") if p.is_file())
    for path in files:
        content = path.read_text(encoding="utf-8-sig")
        for name, pattern in patterns.items():
            for match in pattern.finditer(content):
                if name == "credential_assignment" and match.group(1).upper() in placeholders:
                    continue
                findings.append({"path": path.relative_to(root).as_posix(), "rule": name,
                                 "line": content.count("\n", 0, match.start()) + 1})
    return {"schema_version": 1, "kind": "recognizable_credential_literal_scan",
            "status": "passed" if not findings else "failed", "files_scanned": len(files),
            "rules": sorted(patterns), "findings": findings,
            "limitation": "No recognizable literal matched these rules; arbitrary credentials or secrets are not proven absent."}


def verify_hashes(root: Path) -> dict:
    value = json.loads((root / "HASHES.json").read_text(encoding="utf-8"))
    actual = [record(path, root) for path in sorted(root.rglob("*")) if path.is_file() and path.name != "HASHES.json"]
    if value.get("files") != actual or value.get("excluded") != ["HASHES.json"]:
        raise ValueError("Bundle hash manifest is incomplete or changed")
    return {"status": "passed", "files_checked": len(actual), "manifest_sha256": digest(root / "HASHES.json")}


def runtime_note(agh_root: Path) -> dict:
    receipt = ROOT / "outputs" / "agh-title-repair-v1" / "repair_verification.json"
    document = json.loads(receipt.read_text(encoding="utf-8")) if receipt.is_file() else {}
    names = ("packages/ai/src/adapters/pi/index.ts", "packages/ai/src/adapters/pi/translate.ts",
             "packages/host/src/session-title.ts")
    rows = []
    for name in names:
        path = agh_root / name
        old = next((row for row in document.get("runtime_files", [])
                    if Path(row["path"]).as_posix().endswith("/" + name)), {})
        rows.append({"source_file": name, "source_path": str(path),
                     "current_sha256": digest(path) if path.is_file() else None,
                     "historical_after_sha256": old.get("sha256"),
                     "bundled_source": False, "historical_receipt_source": str(receipt) if document else None})
    return {"schema_version": 1, "kind": "agh_local_runtime_change_inventory",
            "scope": "Title cancellation settlement and model usage preservation in the locally modified AGH runtime.",
            "files": rows, "historical_local_receipt_status": document.get("status"),
            "runtime_distributed": False, "current_runtime_model_acceptance": "pending",
            "limitations": ["Runtime TypeScript changes and built binaries are described, not distributed in this CPU bundle.",
                            "The historical repair receipt and current file fingerprints do not prove new-machine AGH execution."]}


def build(destination: Path, research_root: Path, agh_root: Path) -> dict:
    destination = destination.resolve()
    if destination.parent != (ROOT / "outputs").resolve() or not destination.name.startswith("submission-bundle-v1-"):
        raise ValueError("New bundle output must be a submission-bundle-v1-* child of project outputs")
    if destination.exists():
        raise FileExistsError("Bundle destination already exists; existing outputs are immutable")
    for relative in PROJECT_ALLOWLIST:
        safe_file(ROOT / relative, ROOT)
    for relative in RESEARCH_ALLOWLIST:
        safe_file(research_root / relative, research_root)
    safe_file(research_root.parent / "license.txt", research_root.parent)
    for name in ("LICENSE", "NOTICE"):
        safe_file(agh_root / name, agh_root)
    destination.mkdir(parents=True, exist_ok=False)
    package = destination / "staging" / "DefectResearcher-CPU-v1"
    package.mkdir(parents=True, exist_ok=False)
    sources = []

    def copy(source: Path, relative: str, origin: str):
        target = package / relative
        if target.is_file() or any(part in FORBIDDEN_PARTS for part in Path(relative).parts):
            raise ValueError("Forbidden or duplicate bundle target: " + relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        before = digest(source)
        shutil.copyfile(source, target)
        if before != digest(source) or before != digest(target):
            raise ValueError("Source changed during whitelist copy: " + str(source))
        sources.append({"bundle_path": relative, "source_path": str(source.resolve()), "origin": origin,
                        "sha256": before, "size_bytes": target.stat().st_size})

    for relative in PROJECT_ALLOWLIST:
        target = "docs/source-project-README.md" if relative == "README.md" else relative
        copy(ROOT / relative, target, "DefectResearcher project source")
    for relative in RESEARCH_ALLOWLIST:
        copy(research_root / relative, "research/" + relative, "Existing CableInspect research source")
    copy(research_root.parent / "license.txt", "licenses/cableinspect-upstream-license.txt", "Existing upstream repository license")
    copy(agh_root / "LICENSE", "licenses/agnes-harness-LICENSE", "Agnes Harness upstream")
    copy(agh_root / "NOTICE", "licenses/agnes-harness-NOTICE", "Agnes Harness upstream")
    write_json(package / "provenance.json", {
        "schema_version": 1, "created_at": datetime.now(timezone.utc).isoformat(), "sources": sources,
        "project": source_identity(ROOT), "research": source_identity(research_root),
        "agh": source_identity(agh_root),
        "pending_license_items": ["DefectResearcher code has no declared redistribution license in its pyproject or project root.",
                                  "The existing project_start additions lack explicit file-level authorship/license; upstream Apache-2.0 text alone does not resolve their status.",
                                  "Final authorship, contributor roles, submission model-rule clarification and public redistribution review remain pending."],
        "existing_and_new_code": {"existing": ["research/cableinspect_geometry.py", "research/数据处理/7检查YOLO标注数据.py"],
                                  "project_domain": "defect_researcher/* and frozen fixtures are project-specific; final w/c/l attribution is pending."}})
    write_json(package / "agh-runtime-fixes.json", runtime_note(agh_root))
    write_json(package / "bundle_scope.json", {
        "schema_version": 1, "kind": "initial_cpu_reproducible_submission_bundle_v1", "final_submission_ready": False,
        "scope": "CPU LabelGuard fixture repair/refusal and independent geometry/saved-task verification only",
        "team_configuration": "config/submission-team.json", "final_evidence_status": "pending",
        "v12_source_snapshot": "excluded_unstable_source", "full_agh_migration": "pending",
        "other_computer_migration": "pending", "gpu_migration": "pending", "license_review": "pending",
        "excluded": ["All pre-existing outputs and official model sessions", ".runtime", "node_modules", "config/local.json",
                     "Provider keys", "full datasets and weights", "GPU/model workflow sources outside the CPU closure", "V12 sources"],
        "migration_note": "The builder runs this exact ZIP after extraction at a new path; the actual receipt lives beside the ZIP. No existing output is re-labelled or modified."})
    (package / "README.md").write_text(
        "# DefectResearcher CPU delivery bundle v1\n\n"
        "This initial source bundle executes twelve frozen synthetic LabelGuard cases (4 normal, 4 real copy repairs, 4 refusals), "
        "thirty independent geometry fixtures and twelve saved-task crosschecks with Python's standard library.\n\n"
        "Extract to a new path. Use Python 3.10 or newer, then run from the extracted root:\n\n"
        "```powershell\npython -I -S -B tools/migration_smoke_v1.py --output ../smoke-evidence-new\n```\n\n"
        "The output directory must be new and outside this immutable bundle. No package installation is needed. "
        "The smoke refuses model/GPU libraries, network calls and child processes. It checks the complete source manifest before and after execution.\n\n"
        "Source and license provenance: `provenance.json`, `licenses/`, `agh-runtime-fixes.json`. Actual team details: "
        "`config/submission-team.json`. The source project's original README is preserved in `docs/source-project-README.md`; "
        "its historical output links refer to the original workspace and are outside this package.\n\n"
        "Final reports, V12 evidence, AGH/Provider setup, full data/weights, GPU execution, other-computer validation and redistribution permissions "
        "remain pending. This ZIP is a local reviewable CPU milestone, not a final contest submission or a verified AGH installation.\n",
        encoding="utf-8", newline="\n")
    scan = credential_scan(package)
    write_json(package / "credential_scan.json", scan)
    if scan["status"] != "passed":
        raise ValueError("Recognizable credential scan failed; review path/rule findings without exposing values")
    members = sorted(p for p in package.rglob("*") if p.is_file())
    for path in members:
        relative = path.relative_to(package)
        if any(part in FORBIDDEN_PARTS for part in relative.parts) or path.suffix.lower() in FORBIDDEN_SUFFIXES or path.name == "local.json":
            raise ValueError("Forbidden artifact in package: " + relative.as_posix())
    write_json(package / "HASHES.json", {"schema_version": 1, "algorithm": "SHA256",
        "excluded": ["HASHES.json"], "self_hash": "Recorded in detached build_receipt.json to avoid recursive self hashing",
        "files": [record(path, package) for path in members]})
    integrity = verify_hashes(package)
    final_scan = credential_scan(package)
    if final_scan["status"] != "passed":
        raise ValueError("Final complete-package credential scan failed")
    archive = destination / "DefectResearcher-CPU-v1.zip"
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in sorted(package.rglob("*")):
            if path.is_file():
                zipped.write(path, (Path(package.name) / path.relative_to(package)).as_posix())
    if archive.stat().st_size > MAX_ZIP_BYTES:
        raise ValueError("ZIP exceeds 200 MiB limit")
    migrated_parent = destination / "migration-new-path"
    migrated_parent.mkdir()
    with zipfile.ZipFile(archive) as zipped:
        for entry in zipped.infolist():
            if entry.is_dir() or not (migrated_parent / entry.filename).resolve().is_relative_to(migrated_parent.resolve()):
                raise ValueError("Unexpected ZIP member")
        zipped.extractall(migrated_parent)
    migrated = migrated_parent / package.name
    extracted_integrity = verify_hashes(migrated)
    if extracted_integrity != integrity:
        raise ValueError("Extracted ZIP differs from staging manifest")
    evidence = destination / "migration-evidence"
    execution = subprocess.run([sys.executable, "-I", "-S", "-B", "tools/migration_smoke_v1.py",
                                "--output", str(evidence)], cwd=migrated, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", check=False)
    (destination / "migration-stdout.log").write_text(execution.stdout, encoding="utf-8")
    (destination / "migration-stderr.log").write_text(execution.stderr, encoding="utf-8")
    acceptance_path = evidence / "migration_acceptance.json"
    acceptance = json.loads(acceptance_path.read_text(encoding="utf-8")) if acceptance_path.is_file() else {}
    receipt = {"schema_version": 1, "kind": "submission_bundle_v1_build_and_actual_extraction_receipt",
               "status": "passed_cpu_bundle" if execution.returncode == 0 and acceptance.get("status") == "passed" else "failed_migration",
               "final_submission_ready": False, "archive": record(archive, destination), "zip_limit_bytes": MAX_ZIP_BYTES,
               "bundle_integrity": integrity, "extracted_integrity": extracted_integrity,
               "credential_scan": final_scan, "cpu_migration": {"exit_code": execution.returncode,
                    "status": acceptance.get("status", "missing_receipt"), "evidence": str(acceptance_path),
                    "sha256": digest(acceptance_path) if acceptance_path.is_file() else None,
                    "groups": acceptance.get("groups"), "geometry_counts": acceptance.get("geometry_counts"),
                    "case_outcomes": acceptance.get("case_outcomes"), "actual_repair_cases": acceptance.get("actual_repair_cases"),
                    "unintended_modification_cases": acceptance.get("unintended_modification_cases"),
                    "same_computer_new_path_only": True},
               "pending": ["Final evidence/report v2", "V12 source/evidence", "AGH/Provider/new-computer acceptance", "GPU/data/weights migration", "Code authorship and redistribution license review"]}
    write_json(destination / "build_receipt.json", receipt)
    # Detached evidence inventory includes all migration files, the complete manifest and ZIP.
    write_json(destination / "artifact_manifest.json", {"schema_version": 1, "algorithm": "SHA256",
        "excluded": ["artifact_manifest.json"],
        "files": [record(path, destination) for path in sorted(destination.rglob("*")) if path.is_file()]})
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_DESTINATION)
    parser.add_argument("--research-root", type=Path,
                        default=ROOT.parent.parent / "projects" / "cableinspect-ad-code" / "project_start")
    parser.add_argument("--agh-root", type=Path, default=ROOT.parent / "agnes-harness")
    args = parser.parse_args()
    result = build(args.output, args.research_root.resolve(), args.agh_root.resolve())
    print(json.dumps({"status": result["status"], "archive": result["archive"],
                      "migration": result["cpu_migration"], "receipt": str(args.output.resolve() / "build_receipt.json")}, ensure_ascii=True))
    return 0 if result["status"] == "passed_cpu_bundle" else 1


if __name__ == "__main__":
    raise SystemExit(main())
