"""Protocol boundary tests, including an actual stdio subprocess."""

from __future__ import annotations

import io
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import unittest
import uuid
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

from defect_researcher.mcp_server import AuditMCPServer, PROTOCOL_VERSION, serve


def request(request_id, method, params=None):
    value = {"jsonrpc": "2.0", "id": request_id, "method": method}
    if params is not None:
        value["params"] = params
    return value


def initialize(request_id=1, version="2024-11-05"):
    return request(
        request_id,
        "initialize",
        {
            "protocolVersion": version,
            "capabilities": {},
            "clientInfo": {"name": "test-client", "version": "1.0"},
        },
    )


INITIALIZED = {"jsonrpc": "2.0", "method": "notifications/initialized"}


@contextmanager
def temporary_test_directory():
    # Windows sandbox tokens cannot use Python 3.12's mode-700 mkdtemp ACL.
    # An ordinary mkdir keeps the workspace's inherited permissions.
    base = (Path(__file__).resolve().parents[1] / ".runtime" / "test-tmp").resolve()
    base.mkdir(parents=True, exist_ok=True)
    root = (base / ("mcp-" + uuid.uuid4().hex)).resolve()
    if not root.is_relative_to(base) or root == base:
        raise RuntimeError("Test directory must stay inside the workspace test root")
    root.mkdir()
    try:
        yield root
    finally:
        resolved = root.resolve()
        if not resolved.is_relative_to(base) or resolved == base:
            raise RuntimeError("Refusing to clean up a directory outside the test root")
        shutil.rmtree(resolved)


def ready_server(configuration=None):
    server = AuditMCPServer(configuration or {})
    server.handle_message(initialize())
    server.handle_message(INITIALIZED)
    return server


class MCPServerTests(unittest.TestCase):
    def test_version_negotiation_and_lifecycle(self):
        server = AuditMCPServer({})
        before = server.handle_message(request(1, "tools/list"))
        self.assertEqual(before["error"]["code"], -32002)
        self.assertEqual(server.handle_message(request(2, "ping"))["result"], {})
        response = server.handle_message(initialize(3, "future-unknown-version"))
        self.assertEqual(response["result"]["protocolVersion"], PROTOCOL_VERSION)
        self.assertIn("tools", response["result"]["capabilities"])
        self.assertIn("error", server.handle_message(request(4, "tools/list")))
        self.assertIsNone(server.handle_message(INITIALIZED))
        tools = server.handle_message(request(5, "tools/list"))["result"]["tools"]
        self.assertEqual([tool["name"] for tool in tools], ["audit_dataset", "verify_label_geometry", "repair_label_copy", "compare_validation_resolutions", "diagnose_validation_errors", "compare_validation_slices", "get_task_status"])
        self.assertFalse(tools[0]["inputSchema"]["additionalProperties"])
        self.assertEqual(tools[0]["inputSchema"]["properties"], {})
        self.assertEqual(tools[1]["inputSchema"]["properties"], {})
        self.assertFalse(tools[1]["inputSchema"]["additionalProperties"])
        self.assertEqual(tools[2]["inputSchema"]["properties"], {})
        self.assertEqual(tools[3]["inputSchema"]["properties"], {})
        self.assertFalse(tools[3]["inputSchema"]["additionalProperties"])
        self.assertEqual(tools[4]["inputSchema"]["properties"], {})
        self.assertFalse(tools[4]["inputSchema"]["additionalProperties"])
        self.assertEqual(tools[-1]["inputSchema"]["required"], ["task_id"])
        self.assertEqual(tools[0]["annotations"], {
            "readOnlyHint": False, "destructiveHint": False,
            "idempotentHint": False, "openWorldHint": False,
        })
        self.assertEqual(tools[1]["annotations"], tools[0]["annotations"])
        self.assertEqual(tools[2]["annotations"], tools[0]["annotations"])
        self.assertEqual(tools[3]["annotations"], tools[0]["annotations"])
        self.assertEqual(tools[4]["annotations"], tools[0]["annotations"])
        self.assertEqual(tools[-1]["annotations"], {
            "readOnlyHint": True, "destructiveHint": False,
            "idempotentHint": True, "openWorldHint": False,
        })
        legacy = AuditMCPServer({})
        negotiated = legacy.handle_message(initialize(version="2024-11-05"))
        self.assertEqual(negotiated["result"]["protocolVersion"], "2024-11-05")
        legacy.handle_message(INITIALIZED)
        legacy_tools = legacy.handle_message(request(2, "tools/list"))["result"]["tools"]
        self.assertTrue(all("annotations" not in tool for tool in legacy_tools))

    def test_invalid_messages_methods_and_tool_arguments(self):
        server = ready_server()
        cases = [
            (None, -32600),
            (request(None, "ping"), -32600),
            (request(True, "ping"), -32600),
            (request(3.2, "ping"), -32600),
            (request(2, "missing"), -32601),
            (request(3, "tools/call", {"name": "missing"}), -32602),
            (request(4, "tools/call", {"name": "audit_dataset", "arguments": []}), -32602),
            (request(5, "tools/call", {"name": "audit_dataset", "arguments": {"dataset_root": "other"}}), -32602),
            (request(6, "tools/call", {"name": "audit_dataset", "arguments": {"task_id": "../../other"}}), -32602),
            (request(7, "tools/list", {"cursor": "unknown"}), -32602),
            (request(8, "tools/list", []), -32602),
            (request(9, "tools/call", {"name": []}), -32602),
            (request(10, "tools/call", {"name": "get_task_status", "arguments": {}}), -32602),
            (request(11, "tools/call", {"name": "get_task_status", "arguments": {"task_id": "../../outside"}}), -32602),
            (request(12, "tools/call", {"name": "get_task_status", "arguments": {"task_id": "safe", "output_root": "other"}}), -32602),
            (request(13, "tools/call", {"name": "get_task_status", "arguments": {"task_id": 12}}), -32602),
            (request(14, "tools/call", {"name": "verify_label_geometry", "arguments": []}), -32602),
            (request(15, "tools/call", {"name": "verify_label_geometry", "arguments": {"dataset_root": "other"}}), -32602),
            (request(16, "tools/call", {"name": "verify_label_geometry", "arguments": {"task_id": "chosen-id"}}), -32602),
            (request(17, "tools/call", {"name": "verify_label_geometry", "arguments": {"command": "anything"}}), -32602),
            (request(18, "tools/call", {"name": "repair_label_copy", "arguments": {"output": "chosen-path"}}), -32602),
            (request(19, "tools/call", {"name": "compare_validation_resolutions", "arguments": {"split": "test"}}), -32602),
            (request(20, "tools/call", {"name": "compare_validation_resolutions", "arguments": {"imgsz": 1280}}), -32602),
        ]
        for message, code in cases:
            with self.subTest(message=message):
                response = server.handle_message(message)
                self.assertEqual(response["error"]["code"], code)
        with patch("defect_researcher.task_runtime.start_audit") as audit:
            server.handle_message({"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "audit_dataset"}})
            audit.assert_not_called()
        with patch("defect_researcher.task_runtime.start_geometry_verification") as verification:
            server.handle_message({"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "verify_label_geometry"}})
            verification.assert_not_called()

    def test_batch_and_notification_responses(self):
        server = AuditMCPServer({})
        response = server.handle_message([
            initialize(), INITIALIZED, request(2, "tools/list"), request(3, "ping")
        ])
        self.assertEqual([item["id"] for item in response], [1, 2, 3])
        self.assertIsNone(server.handle_message([INITIALIZED]))
        self.assertEqual(server.handle_message([])["error"]["code"], -32600)
        self.assertEqual(server.handle_message([[]])[0]["error"]["code"], -32600)

    def test_successful_audit_preserves_evidence_and_protects_configuration(self):
        configuration = {"dataset_root": "configured-root"}
        server = ready_server(configuration)

        def fake_start(config):
            self.assertEqual(config, configuration)
            config["dataset_root"] = "mutated"
            return {"status": "running", "task_id": "audit-safe-task"}

        with patch("defect_researcher.task_runtime.start_audit", side_effect=fake_start):
            response = server.handle_message(request("audit-1", "tools/call", {"name": "audit_dataset", "arguments": {}}))
        self.assertFalse(response["result"]["isError"])
        report = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(report["request_id"], "audit-1")
        self.assertEqual(report["task_id"], "audit-safe-task")
        self.assertEqual(report["status"], "running")
        with patch("defect_researcher.task_runtime.get_task_status", return_value={"status": "completed", "task_id": "audit-safe-task", "evidence": ["报告.json"]}) as status:
            response = server.handle_message(request("poll-1", "tools/call", {"name": "get_task_status", "arguments": {"task_id": "audit-safe-task"}}))
        self.assertFalse(response["result"]["isError"])
        report = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(report["request_id"], "poll-1")
        self.assertEqual(report["evidence"], ["报告.json"])
        status.assert_called_once_with(configuration, "audit-safe-task")
        self.assertEqual(configuration["dataset_root"], "configured-root")
        self.assertEqual(server.configuration["dataset_root"], "configured-root")

    def test_business_failures_and_exceptions_are_tool_errors(self):
        server = ready_server()
        for outcome in [{"status": "failed", "task_id": "audit-failed", "errors": [{"message": "missing data"}]}, RuntimeError("audit unavailable"), {"status": "completed", "task_id": "audit-invalid-json", "value": float("nan")}, {"status": "unknown"}]:
            with self.subTest(outcome=outcome):
                options = {"side_effect": outcome} if isinstance(outcome, Exception) else {"return_value": outcome}
                with patch("defect_researcher.task_runtime.start_audit", **options):
                    response = server.handle_message(request(2, "tools/call", {"name": "audit_dataset"}))
                self.assertTrue(response["result"]["isError"])
                report = json.loads(response["result"]["content"][0]["text"])
                self.assertEqual(report["status"], "failed")
                self.assertEqual(report["request_id"], 2)
                self.assertTrue(report.get("task_id") or report.get("call_id"))
        with patch("defect_researcher.task_runtime.get_task_status", return_value={"status": "completed", "task_id": "different-task"}):
            response = server.handle_message(request("poll-mismatch", "tools/call", {"name": "get_task_status", "arguments": {"task_id": "requested-task"}}))
        self.assertTrue(response["result"]["isError"])
        failed = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(failed["task_id"], "requested-task")
        self.assertEqual(failed["request_id"], "poll-mismatch")

    def test_geometry_execution_completion_preserves_failed_findings(self):
        configuration = {"dataset_root": "configured-root"}
        server = ready_server(configuration)
        with patch("defect_researcher.task_runtime.start_geometry_verification", return_value={
            "status": "running", "task_id": "geometry-task", "tool": "verify_label_geometry",
        }) as starter:
            response = server.handle_message(request("geometry-start", "tools/call", {
                "name": "verify_label_geometry", "arguments": {},
            }))
        self.assertFalse(response["result"]["isError"])
        report = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(report["status"], "running")
        self.assertEqual(report["task_id"], "geometry-task")
        starter.assert_called_once_with(configuration)
        for findings in ("passed", "failed"):
            with self.subTest(findings=findings):
                completed = {
                    "status": "completed", "task_id": "geometry-task", "tool": "verify_label_geometry",
                    "summary": {"verification_status": findings, "mismatches": 3 if findings == "failed" else 0},
                    "errors": [],
                }
                with patch("defect_researcher.task_runtime.get_task_status", return_value=completed):
                    response = server.handle_message(request("geometry-poll", "tools/call", {
                        "name": "get_task_status", "arguments": {"task_id": "geometry-task"},
                    }))
                self.assertFalse(response["result"]["isError"])
                report = json.loads(response["result"]["content"][0]["text"])
                self.assertEqual(report["status"], "completed")
                self.assertEqual(report["summary"], completed["summary"])
        with patch("defect_researcher.task_runtime.start_geometry_verification", side_effect=RuntimeError("verification unavailable")):
            response = server.handle_message(request("geometry-error", "tools/call", {"name": "verify_label_geometry"}))
        self.assertTrue(response["result"]["isError"])
        failure = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(failure["errors"][0]["stage"], "geometry_verification_start")

    def test_malformed_json_does_not_stop_the_protocol_stream(self):
        source = io.BytesIO(
            b"not-json\n" + b'{"jsonrpc":"2.0","id":NaN,"method":"ping"}\n'
            + b'{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}\n'
            + b"\xff\n" + json.dumps(request(7, "ping")).encode("utf-8") + b"\n"
        )
        output = io.BytesIO()
        serve({}, stdin=source, stdout=output)
        lines = [json.loads(line) for line in output.getvalue().decode("utf-8").splitlines()]
        self.assertEqual(len(lines), 5)
        self.assertEqual([line["error"]["code"] for line in lines[:-1]], [-32700] * 4)
        self.assertEqual(lines[-1], {"jsonrpc": "2.0", "id": 7, "result": {}})

    def test_stdio_subprocess_missing_data_returns_only_json(self):
        package_root = Path(__file__).resolve().parents[1]
        with temporary_test_directory() as root:
            configuration = {
                "schema_version": 1,
                "research_root": str(root / "missing-research"),
                "dataset_root": str(root / "missing-dataset"),
                "raw_root": str(root / "missing-raw"),
                "split_dir": str(root / "missing-splits"),
                "weights_path": str(root / "missing-weights.pt"),
                "output_root": str(root / "output"),
            }
            config_path = root / "config.json"
            config_path.write_text(json.dumps(configuration), encoding="utf-8")
            environment = os.environ.copy()
            environment["PYTHONPATH"] = str(package_root)
            process = subprocess.Popen(
                [sys.executable, "-B", "-m", "defect_researcher.mcp_server", "--config", str(config_path)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=package_root, env=environment,
            )
            output = queue.Queue()
            wire_lines = []

            def read_stdout():
                for line in process.stdout:
                    wire_lines.append(line)
                    output.put(line)

            reader = threading.Thread(target=read_stdout, daemon=True)
            reader.start()

            def send(message, response=True):
                process.stdin.write((json.dumps(message) + "\n").encode("utf-8"))
                process.stdin.flush()
                return json.loads(output.get(timeout=10)) if response else None

            try:
                initialized = send(initialize(version="2025-03-26"))
                send(INITIALIZED, response=False)
                listed = send(request(2, "tools/list"))
                self.assertEqual(initialized["result"]["protocolVersion"], PROTOCOL_VERSION)
                self.assertEqual([tool["name"] for tool in listed["result"]["tools"]], ["audit_dataset", "verify_label_geometry", "repair_label_copy", "compare_validation_resolutions", "diagnose_validation_errors", "compare_validation_slices", "get_task_status"])
                for tool in ("diagnose_validation_errors", "compare_validation_resolutions", "audit_dataset", "verify_label_geometry", "repair_label_copy"):
                    started = send(request(f"missing-{tool}", "tools/call", {"name": tool, "arguments": {}}))
                    self.assertFalse(started["result"]["isError"])
                    report = json.loads(started["result"]["content"][0]["text"])
                    self.assertEqual(report["status"], "running")
                    self.assertEqual(report.get("tool"), tool, report)
                    self.assertEqual(report["request_id"], f"missing-{tool}")
                    task_id = report["task_id"]
                    deadline = time.monotonic() + 10
                    poll = 0
                    while True:
                        poll += 1
                        status = send(request(f"{tool}-poll-{poll}", "tools/call", {"name": "get_task_status", "arguments": {"task_id": task_id}}))
                        report = json.loads(status["result"]["content"][0]["text"])
                        if report["status"] != "running":
                            break
                        if time.monotonic() >= deadline:
                            self.fail("Missing-data task did not fail within ten seconds")
                        time.sleep(0.05)
                    self.assertEqual(status["result"]["isError"], tool != "repair_label_copy")
                    if tool == "repair_label_copy":
                        self.assertEqual(report["status"], "completed")
                        self.assertEqual(report["summary"]["repair_status"], "refused")
                    self.assertEqual(report.get("tool"), tool, report)
                    self.assertFalse(any(error.get("type") in {"ImportError", "ModuleNotFoundError"} for error in report["errors"]))
            finally:
                process.stdin.close()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=10)
                reader.join(timeout=2)
                stderr = process.stderr.read().decode("utf-8")
                process.stdout.close()
                process.stderr.close()
            self.assertEqual(process.returncode, 0, stderr)
            self.assertTrue(all(json.loads(line)["jsonrpc"] == "2.0" for line in wire_lines))
            self.assertEqual(report["status"], "completed")
            self.assertEqual(report["summary"]["repair_status"], "refused")
            self.assertEqual(report["task_id"], task_id)
            self.assertTrue(report["summary"]["refusal_reasons"])
            self.assertFalse(any(error.get("type") in {"ImportError", "ModuleNotFoundError"} for error in report["errors"]))


if __name__ == "__main__":
    unittest.main()
