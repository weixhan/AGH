"""Separate saved-cost admission and scientific-pair rejection contracts."""
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import struct
import sys
import unittest
from unittest.mock import patch
import zlib

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tools import verify_resolution_recovery_v1 as verifier
from test_config import temporary_workspace

def registration():
    return {'budgets':dict(verifier.BUDGET),'image_ids':[f'fixture_{i:04d}' for i in range(640)],
            'started_epoch':1000.,'started_monotonic':2000.}

def rows(reg):
    output=[];head='0'*64
    for index in range(1,6411):
        call=(index+1)//2;g,offset=divmod(call-1,641);step=list(verifier.STEPS)[g]
        ticket={'call_index':call,'kind':'warmup' if offset==0 else 'formal',
                'step_id':step,'image_id':reg['image_ids'][max(0,offset-1)],'imgsz':verifier.STEPS[step]}
        at=1000.+index*.01
        detail={'utc_started':datetime.fromtimestamp(at-.01,timezone.utc).isoformat(),
                'utc_finished':datetime.fromtimestamp(at,timezone.utc).isoformat(),
                'cost_known':True,'prediction_entered':True,'prediction_returned':True,
                **{k:ticket[k] for k in ('step_id','image_id','imgsz','kind')},
                'error_type':None,'error_message':None,'timing_error_type':None}
        payload=ticket if index%2 else {'ticket':ticket,'status':'passed','elapsed_seconds':.01,
                                       'gpu_seconds':.001,'cost_known':True,'details':detail}
        base={'schema_version':1,'sequence':index,'previous_sha256':head,
              'registration_sha256':verifier.digest(reg),'event':'reserved' if index%2 else 'closed',
              'at_epoch':at,'at_monotonic':2000.+index*.01,
              'wall_seconds':max(at-1000.,2000.+index*.01-2000.),'payload':payload}
        row={**base,'sha256':verifier.digest(base)};output.append(row);head=row['sha256']
    return output

def rechain(observed):
    head='0'*64
    for row in observed:
        row['previous_sha256']=head;row['sha256']=verifier.digest({k:v for k,v in row.items() if k!='sha256'});head=row['sha256']

class IndependentRecoveryVerifierTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.reg=registration();cls.baseline=rows(cls.reg)

    def journal(self,mutate=None):
        observed=deepcopy(self.baseline)
        if mutate:mutate(observed)
        rechain(observed)
        with temporary_workspace() as root:
            path=root/'journal.jsonl';path.write_bytes(b''.join(verifier.canonical(r)+b'\n' for r in observed))
            return verifier.inspect_journal(path,self.reg)

    def test_complete_3205_population_is_read_independently(self):
        result=self.journal();self.assertEqual(len(result['calls']),3205)
        self.assertEqual(len(result['heads']),5);self.assertAlmostEqual(result['gpu_seconds'],3.205)

    def test_rehashed_wrong_group_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'group/member'):
            self.journal(lambda r:r[0]['payload'].update(step_id='resume_960',imgsz=960))

    def test_rehashed_boolean_imgsz_is_rejected(self):
        with self.assertRaises(ValueError):self.journal(lambda r:r[0]['payload'].update(imgsz=True))

    def test_unknown_cost_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'unknown-cost'):
            self.journal(lambda r:r[1]['payload'].update(gpu_seconds=None,cost_known=False))

    def test_late_cost_inside_rehashed_chain_is_rejected(self):
        def late(r):r[-1].update(at_epoch=2800.,at_monotonic=3800.,wall_seconds=1800.)
        with self.assertRaisesRegex(ValueError,'clock'):self.journal(late)

    def test_missing_actual_prediction_receipt_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'receipt schema'):
            self.journal(lambda r:r[1]['payload']['details'].pop('prediction_returned'))

    def test_future_utc_receipt_cannot_pass_after_rehash(self):
        with self.assertRaisesRegex(ValueError,'UTC/elapsed'):
            self.journal(lambda r:r[1]['payload']['details'].update(
                utc_started='2099-01-01T00:00:00+00:00',utc_finished='2099-01-01T00:00:01+00:00'))

    def test_false_duration_cannot_pass_with_valid_utc_and_closed_chain(self):
        with self.assertRaisesRegex(ValueError,'UTC/elapsed'):
            self.journal(lambda r:r[1]['payload'].update(elapsed_seconds=1.))

    def test_shared_registration_bool_unknown_and_duplicate_members_are_rejected(self):
        for mutate in (lambda r:r.update(started_epoch=True),lambda r:r.update(extra='unknown'),
                       lambda r:r['image_ids'].__setitem__(1,r['image_ids'][0])):
            reg=deepcopy(self.reg);mutate(reg)
            with self.subTest(reg=reg.get('started_epoch')),patch.object(self,'reg',reg),self.assertRaises(ValueError):
                self.journal()

    def test_extra_journal_event_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'6410'):self.journal(lambda r:r.append(deepcopy(r[-1])))

    def test_declared_pair_tolerance_and_identity_boundaries(self):
        a=[{'image_id':f'fixture_{i:04d}','eval_imgsz':960,'ground_truth':[],
            'predictions':[{'class_id':0,'xyxy':[1.,2.,10.,20.],'confidence':.5}],
            'elapsed_seconds':.01} for i in range(640)]
        b=deepcopy(a);b[0]['predictions'][0]['xyxy'][0]+=.00001
        verifier.prediction_pair(a,b)
        b[0]['predictions'][0]['confidence']+=.0001
        with self.assertRaisesRegex(ValueError,'tolerance'):verifier.prediction_pair(a,b)
        b=deepcopy(a);b[3]['ground_truth']=[{'class_id':1}]
        with self.assertRaisesRegex(ValueError,'identity'):verifier.prediction_pair(a,b)

class FullRecoveryAcceptanceTests(unittest.TestCase):
    """Produce five complete CPU groups, then rehash conflicting artifacts."""
    @classmethod
    def setUpClass(cls):
        from test_resolution_recovery_coordinator_v1 import Fixture
        from defect_researcher import resolution_recovery_ledger_v1 as ledger_module
        cls.workspace=temporary_workspace();root=cls.workspace.__enter__()
        cls.fixture=Fixture(root,fast_journal_checks=True)
        # This fixture does no CUDA work and never publishes real acceptance.
        # Durability and full per-entry byte guards have separate ledger tests;
        # all actual ledger schemas/tickets/order/clocks/costs remain enabled.
        with patch.object(ledger_module.os,'fsync',lambda _:None):
            registration=cls.fixture.prepare();result=cls.fixture.run(registration)
        if result['status']!='passed_fixture_only':raise AssertionError(result)
        cls.directory=Path(registration['task_directory'])
        report=verifier.verify(cls.directory,allow_fixture=True)
        if report['status']!='passed_fixture_only':raise AssertionError(report)
        cls.baseline={path:(path.read_bytes(),path.stat().st_atime_ns,path.stat().st_mtime_ns)
            for path in cls.directory.rglob('*') if path.is_file()}

    @classmethod
    def tearDownClass(cls):cls.workspace.__exit__(None,None,None)

    def setUp(self):
        for path in self.directory.rglob('*'):
            if path.is_file() and path not in self.baseline:path.unlink()
        for path,(raw,at,mt) in self.baseline.items():
            path.write_bytes(raw);os.utime(path,ns=(at,mt))

    def read(self,relative):return verifier.read(self.directory/relative)

    def write(self,relative,value):
        (self.directory/relative).write_bytes(verifier.canonical(value)+b'\n')

    def change(self,relative,mutate):
        value=self.read(relative);mutate(value);self.write(relative,value)

    def rebind(self,update_reports=True):
        """Update complete SHA/marker/report links, so semantic checks decide."""
        group_chains={};group_details={}
        for step in verifier.STEPS:
            directory=self.directory/'groups'/step
            records=verifier.lines(directory/'predictions.jsonl')
            self.write('groups/'+step+'/metrics.json',verifier.score_detections(records,verifier.CLASSES,.25,.5))
            manifest=verifier.read(directory/'artifact_manifest.json')
            manifest['files']=[verifier.pin(directory/name) for name in sorted(verifier.GROUP_FILES)]
            self.write('groups/'+step+'/artifact_manifest.json',manifest)
            if step!='fault_960':
                marker=verifier.read(directory/'completion.json')
                marker.update(artifact_manifest_sha256=verifier.pin(directory/'artifact_manifest.json')['sha256'],
                    artifacts_sha256={r['name']:r['sha256'] for r in manifest['files']})
                self.write('groups/'+step+'/completion.json',marker)
                current=verifier.chain(directory,verifier.TOOL)
                group_chains[step]=current
                group_details[step]={'path':str(directory),'binding':manifest['binding'],'chain':current,
                    'metrics':verifier.read(directory/'metrics.json'),'environment':verifier.read(directory/'environment.json')}
        failure=self.read('fault/failure.json')
        failure['temporary_artifacts']=self.read('groups/fault_960/artifact_manifest.json')['files']
        self.write('fault/failure.json',failure)
        current=[]
        for relative in ('fault','groups/fault_640','groups/fault_960'):
            for path in sorted((self.directory/relative).rglob('*')):
                if path.is_file():current.append({'relative_path':path.relative_to(self.directory).as_posix(),**verifier.pin(path)})
        tree={'schema_version':1,'files':current,'tree_sha256':verifier.digest(current)}
        self.write('fault_tree_before_resume.json',tree);self.write('fault_tree_after_resume.json',tree)
        resume=self.read('resume_receipt.json')
        resume.update(original_failure_sha256=verifier.pin(self.directory/'fault/failure.json')['sha256'])
        resume['reuse']['fault_640']=group_chains['fault_640'];self.write('resume_receipt.json',resume)
        result=self.read('recovery_result.json')
        if update_reports:
            result['groups']=group_details;result['fault_failure']=verifier.pin(self.directory/'fault/failure.json')
        self.write('recovery_result.json',result)
        candidate=self.read('completion_candidate.json')
        candidate.update(group_chains=group_chains,fault_tree_sha256=tree['tree_sha256'],
            original_failure_sha256=verifier.pin(self.directory/'fault/failure.json')['sha256'],
            root_artifacts=[verifier.pin(path) for path in sorted(self.directory.iterdir())
                if path.is_file() and path.name not in verifier.COORDINATION_FILES|verifier.POST_CANDIDATE])
        self.write('completion_candidate.json',candidate)

    def fails(self,name):
        result=verifier.verify(self.directory,allow_fixture=True)
        self.assertEqual(result['status'],'failed',result)
        self.assertFalse(result['real_recovery_accepted'])
        self.assertFalse(result['checks'].get(name),result)

    def test_actual_full_verify_fixture_passes_all_checks_without_real_acceptance(self):
        result=verifier.verify(self.directory,allow_fixture=True)
        self.assertEqual(result['status'],'passed_fixture_only',result)
        self.assertEqual(len(result['checks']),15)
        self.assertTrue(all(v is True for v in result['checks'].values()))
        self.assertFalse(result['real_recovery_accepted'])
        self.assertFalse((self.directory/'completion.json').exists())

    def test_fixture_cannot_pass_default_production_acceptance(self):
        result=verifier.verify(self.directory)
        self.assertEqual(result['status'],'failed');self.assertFalse(result['real_recovery_accepted'])

    def test_rehashed_formal_cost_conflicts_with_actual_ticket(self):
        path=self.directory/'groups/reference_640/predictions.jsonl';rows=verifier.lines(path)
        rows[0]['gpu_seconds']=.0005
        path.write_bytes(b''.join(verifier.canonical(row)+b'\n' for row in rows));self.rebind()
        self.fails('reference_640_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_environment_totals_conflict_with_641_calls(self):
        self.change('groups/reference_960/environment.json',lambda e:e.update(closed_prediction_gpu_seconds=0.))
        self.rebind();self.fails('reference_960_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_warmup_cost_cannot_be_hidden_as_zero(self):
        self.change('groups/resume_960/environment.json',lambda e:e.update(warmup_seconds=0.))
        self.rebind();self.fails('resume_960_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_fault_960_predictions_must_match_new_reference(self):
        path=self.directory/'groups/fault_960/predictions.jsonl';rows=verifier.lines(path)
        rows[0]['predictions'][0]['confidence']=.6
        path.write_bytes(b''.join(verifier.canonical(row)+b'\n' for row in rows));self.rebind()
        self.fails('new_reference_matches_recovery_full_predictions')

    def test_rehashed_effective_options_cannot_change(self):
        self.change('groups/fault_640/environment.json',lambda e:e['actual_predictor_options'].update(half=True))
        self.rebind();self.fails('fault_640_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_normalized_precision_drift_is_still_rejected(self):
        changes=(('quantize',16),('actual_predictor_fp16',True),
                 ('actual_input_dtype','torch.float16'),('model_parameters_dtype','torch.float16'))
        for field,value in changes:
            with self.subTest(field=field):
                self.setUp()
                def mutate(environment):
                    target=environment['actual_predictor_options'] if field=='quantize' else environment
                    target[field]=value
                self.change('groups/reference_640/environment.json',mutate)
                self.rebind();self.fails('reference_640_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_step_budget_must_match_its_journal_prefix(self):
        self.change('groups/reference_640/step_verification.json',lambda r:r['ledger'].update(prediction_calls=640))
        self.rebind();self.fails('reference_640_artifacts_actual_controls_and_recomputed_metrics')

    def test_rehashed_report_cannot_claim_a_different_actual_budget(self):
        self.change('recovery_result.json',lambda r:r['final_budget'].update(gpu_seconds=0.))
        self.rebind(update_reports=False);self.fails('parent_candidate_evidence_and_publication_boundary')

    def test_rehashed_report_cannot_claim_a_different_source_identity(self):
        self.change('recovery_result.json',lambda r:r.update(execution_source_sha256='0'*64))
        self.rebind();self.fails('parent_candidate_evidence_and_publication_boundary')

    def test_parent_candidate_must_bind_every_actual_root_artifact(self):
        self.change('completion_candidate.json',lambda r:r['root_artifacts'].__setitem__(slice(None),
            [v for v in r['root_artifacts'] if v['name']!='shared_prediction_journal.jsonl']))
        self.fails('parent_candidate_evidence_and_publication_boundary')

    def test_standalone_and_staged_writer_claims_cannot_be_mixed(self):
        claim=self.read('execution_claim.json');claim['phase']='resume'
        self.write('resume_execution_claim.json',claim);self.rebind()
        self.fails('parent_candidate_evidence_and_publication_boundary')

    def test_parent_cannot_complete_before_independent_review(self):
        self.write('completion.json',{'status':'completed','real_recovery_accepted':True})
        self.fails('parent_candidate_evidence_and_publication_boundary')

    def test_rehashed_audit_marker_cannot_belong_to_another_task(self):
        manifest=self.read('audit/task/artifact_manifest.json');manifest['task_id']='foreign-task'
        self.write('audit/task/artifact_manifest.json',manifest)
        marker=self.read('audit/task/completion.json');marker.update(task_id='foreign-task',
            artifact_manifest_sha256=verifier.pin(self.directory/'audit/task/artifact_manifest.json')['sha256'])
        self.write('audit/task/completion.json',marker)
        report=verifier.verify(self.directory,allow_fixture=True)
        self.assertEqual(report['status'],'failed')
        self.assertTrue(any('different task' in row['message'] for row in report['errors']),report)

    def test_completion_last_must_be_actual_file_order_after_rehash(self):
        path=self.directory/'groups/reference_640/completion.json'
        os.utime(path,ns=(1,1))
        report=verifier.verify(self.directory,allow_fixture=True)
        self.assertEqual(report['status'],'failed')
        self.assertTrue(any('published last' in row['message'] for row in report['errors']),report)


class RealInputContractTests(unittest.TestCase):
    """Actual PNG/YOLO/YAML/manifest files exercise the production data checker."""
    @classmethod
    def setUpClass(cls):
        cls.workspace=temporary_workspace();cls.root=cls.workspace.__enter__()
        cls.config={key:str(cls.root/value) for key,value in {'research_root':'research','dataset_root':'dataset',
            'raw_root':'raw','split_dir':'splits','weights_path':'research/run/weights/best.pt','output_root':'outputs'}.items()}
        dataset=Path(cls.config['dataset_root']);raw=Path(cls.config['raw_root']);splits=Path(cls.config['split_dir'])
        splits.mkdir();(raw/'cable_1').mkdir(parents=True)
        for kind in ('images','labels','metadata'):
            for split in ('train','val','test'):(dataset/kind/split).mkdir(parents=True,exist_ok=True)
        weights=Path(cls.config['weights_path']);weights.parent.mkdir(parents=True);weights.write_bytes(b'fixed synthetic checkpoint bytes')
        def chunk(kind,body):return struct.pack('>I',len(body))+kind+body+struct.pack('>I',zlib.crc32(kind+body)&0xffffffff)
        png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',100,80,8,2,0,0,0))
        png+=chunk(b'IDAT',zlib.compress((b'\0'+b'\0'*300)*80))+chunk(b'IEND',b'')
        cls.records=[]
        members=[]
        for index in range(640):
            identity=f'fixture_{index:04d}';source=raw/'cable_1'/(identity+'.png')
            image=dataset/'images/val'/source.name;label=dataset/'labels/val'/(identity+'.txt')
            metadata=dataset/'metadata/val'/(identity+'.json')
            source.write_bytes(png);image.write_bytes(png)
            label.write_text('0 0.5 0.5 0.1 0.125\n' if index<596 else '',encoding='utf8')
            metadata.write_bytes(verifier.canonical({'width':100,'height':80,'image':source.relative_to(raw).as_posix()})+b'\n')
            members.append(str(source));cls.records.append({'image_id':identity,'width':100,'height':80,'split':'val',
                'image_path':str(image),'source_path':str(source),'label_path':str(label),'metadata_path':str(metadata),
                'ground_truth':verifier.ground_truth(label,100,80)})
        (splits/'val.txt').write_text('\n'.join(members)+'\n',encoding='utf8')
        for split in ('train','test','excluded_buffer'):(splits/(split+'.txt')).write_bytes(b'')
        for cable in ('cable_1','cable_2','cable_3'):(raw/(cable+'.json')).write_bytes(b'{"images":[],"annotations":[]}\n')
        yaml='path: '+json.dumps(str(dataset))+'\nval: images/val\nnames:\n'
        yaml+=''.join('  '+str(index)+': '+name+'\n' for index,name in enumerate(verifier.CLASSES))
        (dataset/'data.yaml').write_text(yaml,encoding='utf8')
        split_hashes={split+'.txt':verifier.pin(splits/(split+'.txt'))['sha256'] for split in ('train','val','test','excluded_buffer')}
        trees={}
        for split in ('train','val','test'):
            digest=verifier.hashlib.sha256()
            for path in sorted((dataset/'labels'/split).glob('*.txt')):
                digest.update(path.relative_to(dataset).as_posix().encode('utf8')+b'\0'+path.read_bytes()+b'\0')
            trees[split]=digest.hexdigest()
        manifest={'geometry_version':'hbb_v1','split_sha256':split_hashes,'label_tree_sha256':trees,
            'source_sha256':{cable+'.json':verifier.pin(raw/(cable+'.json'))['sha256'] for cable in ('cable_1','cable_2','cable_3')},
            'categories':{str(i+1):name for i,name in enumerate(verifier.CLASSES)},'counts':{'val':{'images':640,'annotations':596}}}
        (dataset/'manifest.json').write_bytes(verifier.canonical(manifest)+b'\n')
        training={'status':'completed','geometry_version':'hbb_v1','data_root':str(dataset),'data_yaml':str(dataset/'data.yaml'),
            'training_args':{'imgsz':640,'data':str(dataset/'data.yaml')},'actual_training_args':{'imgsz':640,'data':str(dataset/'data.yaml')},
            'best_weights_sha256':verifier.pin(weights)['sha256'],'dataset_manifest_sha256':verifier.pin(dataset/'manifest.json')['sha256'],
            'data_yaml_sha256':verifier.pin(dataset/'data.yaml')['sha256'],'dataset_manifest':manifest,'split_sha256':split_hashes}
        (weights.parent.parent/'experiment_manifest.json').write_bytes(verifier.canonical(training)+b'\n')
        paths={'weights':weights,'training_manifest':weights.parent.parent/'experiment_manifest.json',
            'dataset/manifest.json':dataset/'manifest.json','dataset/data.yaml':dataset/'data.yaml',
            'comparison_runner':ROOT/'defect_researcher/resolution_comparison.py','comparison_protocol':ROOT/'fixtures/resolution_protocol.json',
            'detection_metrics':ROOT/'defect_researcher/detection_metrics.py','config_loader':ROOT/'defect_researcher/config.py',
            'verifier':ROOT/'defect_researcher/geometry_verifier.py','oracle':ROOT/'defect_researcher/independent_geometry.py',
            'fixtures':ROOT/'fixtures/geometry_cases.json'}
        for cable in ('cable_1','cable_2','cable_3'):paths['raw/'+cable+'.json']=raw/(cable+'.json')
        for split in ('train','val','test','excluded_buffer'):
            paths['splits/'+split+'.txt']=splits/(split+'.txt')
            if split!='excluded_buffer':
                for kind in ('labels','metadata'):
                    for path in (dataset/kind/split).iterdir():paths[f'{kind}/{split}/{path.name}']=path
        for row in cls.records:
            source=Path(row['source_path']);image=Path(row['image_path'])
            paths['images/val/'+image.name]=image;paths['raw_images/val/'+source.relative_to(raw).as_posix()]=source
        cls.original_inputs={'records':cls.records,'source_files':{role:{**verifier.pin(path),'role':role} for role,path in paths.items()},
            'provenance':{'weight_sha256':verifier.pin(weights)['sha256'],'training_manifest_path':str(weights.parent.parent/'experiment_manifest.json'),
                'training_manifest_sha256':verifier.pin(weights.parent.parent/'experiment_manifest.json')['sha256'],
                'dataset_manifest_sha256':verifier.pin(dataset/'manifest.json')['sha256'],
                'data_yaml_sha256':verifier.pin(dataset/'data.yaml')['sha256'],'train_imgsz':640}}
        cls.file_set={path for path in cls.root.rglob('*') if path.is_file()}
        cls.restored={Path(cls.records[0]['metadata_path']),dataset/'manifest.json',dataset/'data.yaml',
            weights.parent.parent/'experiment_manifest.json',splits/'train.txt',splits/'val.txt'}
        cls.original_files={path:path.read_bytes() for path in cls.restored}

    @classmethod
    def tearDownClass(cls):cls.workspace.__exit__(None,None,None)

    def setUp(self):
        for path in self.root.rglob('*'):
            if path.is_file() and path not in self.file_set:path.unlink()
        for path,raw in self.original_files.items():path.write_bytes(raw)
        self.inputs=deepcopy(self.original_inputs)

    def check(self):
        with patch.object(verifier,'trusted_configuration',return_value=self.config):
            verifier.inspect_inputs(self.inputs,self.config)

    def refresh_provenance(self):
        dataset=Path(self.config['dataset_root']);weights=Path(self.config['weights_path'])
        path=weights.parent.parent/'experiment_manifest.json';training=verifier.read(path)
        training.update(dataset_manifest=verifier.read(dataset/'manifest.json'),
            dataset_manifest_sha256=verifier.pin(dataset/'manifest.json')['sha256'],data_yaml_sha256=verifier.pin(dataset/'data.yaml')['sha256'])
        path.write_bytes(verifier.canonical(training)+b'\n')
        self.inputs['provenance'].update(training_manifest_sha256=verifier.pin(path)['sha256'],
            dataset_manifest_sha256=verifier.pin(dataset/'manifest.json')['sha256'],data_yaml_sha256=verifier.pin(dataset/'data.yaml')['sha256'])

    def test_640_actual_png_label_yaml_training_and_tree_contract_passes(self):self.check()

    def test_decoded_gt_cannot_be_redefined(self):
        self.inputs['records'][0]['ground_truth'][0]['xyxy'][0]+=1
        with self.assertRaisesRegex(ValueError,'decoded GT'):self.check()

    def test_metadata_must_identify_the_actual_raw_image(self):
        path=Path(self.records[0]['metadata_path']);value=verifier.read(path);value['image']='cable_2/other.png'
        path.write_bytes(verifier.canonical(value)+b'\n')
        with self.assertRaisesRegex(ValueError,'metadata source identity'):self.check()

    def test_extra_actual_val_image_cannot_be_omitted_from_manifest(self):
        path=Path(self.config['dataset_root'])/'images/val/extra.png';path.write_bytes(Path(self.records[0]['image_path']).read_bytes())
        with self.assertRaisesRegex(ValueError,'image tree population'):self.check()

    def test_extra_actual_val_label_cannot_be_hidden(self):
        path=Path(self.config['dataset_root'])/'labels/val/extra.txt';path.write_bytes(b'')
        with self.assertRaisesRegex(ValueError,'label/metadata tree population'):self.check()

    def test_rehashed_yaml_class_mapping_must_remain_exact(self):
        path=Path(self.config['dataset_root'])/'data.yaml';path.write_text(path.read_text('utf8').replace('0: broken_strand','0: other'),encoding='utf8')
        self.refresh_provenance()
        with self.assertRaisesRegex(ValueError,'data.yaml'):self.check()

    def test_yaml_boolean_class_keys_cannot_equal_integer_classes(self):
        path=Path(self.config['dataset_root'])/'data.yaml';path.write_text(path.read_text('utf8').replace('1: welded_strand','true: welded_strand'),encoding='utf8')
        self.refresh_provenance()
        with self.assertRaisesRegex(ValueError,'data.yaml'):self.check()

    def test_training_data_path_cannot_change_with_unchanged_weights(self):
        path=Path(self.config['weights_path']).parent.parent/'experiment_manifest.json';training=verifier.read(path)
        training['actual_training_args']['data']=str(self.root/'foreign.yaml');path.write_bytes(verifier.canonical(training)+b'\n')
        with self.assertRaisesRegex(ValueError,'data path'):self.check()

    def test_self_consistent_training_manifest_cannot_mask_a_wrong_split_hash(self):
        path=Path(self.config['dataset_root'])/'manifest.json';value=verifier.read(path);value['split_sha256']['val.txt']='0'*64
        path.write_bytes(verifier.canonical(value)+b'\n');self.refresh_provenance()
        with self.assertRaisesRegex(ValueError,'split hashes'):self.check()

    def test_self_consistent_training_manifest_cannot_mask_a_wrong_raw_hash(self):
        path=Path(self.config['dataset_root'])/'manifest.json';value=verifier.read(path);value['source_sha256']['cable_1.json']='0'*64
        path.write_bytes(verifier.canonical(value)+b'\n');self.refresh_provenance()
        with self.assertRaisesRegex(ValueError,'raw annotations'):self.check()

    def test_manifest_label_tree_hash_must_match_actual_files(self):
        path=Path(self.config['dataset_root'])/'manifest.json';value=verifier.read(path);value['label_tree_sha256']['val']='0'*64
        path.write_bytes(verifier.canonical(value)+b'\n');self.refresh_provenance()
        with self.assertRaisesRegex(ValueError,'label tree hashes'):self.check()

    def test_production_configuration_cannot_be_repointed(self):
        config={**self.config,'raw_root':str(self.root/'foreign')}
        with patch.object(verifier,'trusted_configuration',return_value=self.config),self.assertRaisesRegex(ValueError,'fixed local paths'):
            verifier.inspect_inputs(self.inputs,config)


class SourceClosureContractTests(unittest.TestCase):
    def setUp(self):
        self.workspace=temporary_workspace();self.root=self.workspace.__enter__()
        self.config={key:str(self.root/name) for key,name in {'research_root':'research','dataset_root':'dataset',
            'raw_root':'raw','split_dir':'splits','weights_path':'research/weights.pt','output_root':'outputs'}.items()}
        sources=[self.root/name for name in verifier.SOURCE_PATHS]
        sources.extend([self.root/'research/cableinspect_geometry.py',self.root/'research/数据处理/7检查YOLO标注数据.py'])
        self.runtime=self.root/'installed';self.dependencies={self.runtime/'python.exe'}|{self.runtime/path for path in verifier.CALLABLE_PATHS.values()}
        for path in [*sources,*self.dependencies]:
            path.parent.mkdir(parents=True,exist_ok=True);path.write_text('fixed fixture bytes '+path.name,encoding='utf8')
        identity={'python':'fixture-python','python_executable':str(self.runtime/'python.exe'),
            'packages':{'torch':{'version':'fixture-torch'},'ultralytics':{'root':str(self.runtime),'version':'fixture-ultralytics'}},'sys_path':[]}
        files=[verifier.pin(path) for path in [*sources,*sorted(self.dependencies)]]
        self.lock={'schema_version':1,'task_id':'fixture','files':files,'execution_source_sha256':verifier.digest(files),
            'runtime_identity':identity,'runtime_identity_sha256':verifier.digest(identity)}
        self.root_patch=patch.object(verifier,'ROOT',self.root);self.root_patch.start()
        self.config_patch=patch.object(verifier,'trusted_configuration',return_value=self.config);self.config_patch.start()
        self.dependencies_patch=patch.object(verifier,'inspect_dependencies',return_value=self.dependencies);self.dependencies_patch.start()

    def tearDown(self):
        self.dependencies_patch.stop();self.config_patch.stop();self.root_patch.stop();self.workspace.__exit__(None,None,None)

    def inspect(self):return verifier.inspect_sources(self.lock,self.config,False)

    def test_exact_project_research_and_dependency_closure_passes(self):
        self.assertEqual(set(self.inspect()),{Path(r['path']) for r in self.lock['files']})

    def test_rehashed_omission_of_backend_or_dependency_is_rejected(self):
        baseline=deepcopy(self.lock)
        for path in (self.root/'defect_researcher/resolution_recovery_backend_v1.py',self.runtime/'ultralytics/utils/nms.py'):
            self.lock=deepcopy(baseline);self.lock['files']=[r for r in self.lock['files'] if Path(r['path'])!=path]
            self.lock['execution_source_sha256']=verifier.digest(self.lock['files'])
            with self.subTest(path=path),self.assertRaisesRegex(ValueError,'closure'):self.inspect()

    def test_rehashed_extra_source_cannot_broaden_execution_closure(self):
        path=self.root/'foreign.py';path.write_bytes(b'foreign source')
        self.lock['files'].append(verifier.pin(path));self.lock['execution_source_sha256']=verifier.digest(self.lock['files'])
        with self.assertRaisesRegex(ValueError,'closure'):self.inspect()

    def test_loaded_callable_pin_cannot_claim_a_different_implementation(self):
        sources=self.inspect();environment={'backend_source':sources[self.root/'defect_researcher/resolution_recovery_backend_v1.py'],
            'callable_sources':{key:sources[self.runtime/path] for key,path in verifier.CALLABLE_PATHS.items()},
            'python':'fixture-python','python_executable':str(self.runtime/'python.exe'),
            'torch':'fixture-torch','ultralytics':'fixture-ultralytics'}
        verifier.inspect_environment_sources(environment,self.lock,sources,False)
        environment['callable_sources']['NMS']=sources[self.runtime/'ultralytics/engine/model.py']
        with self.assertRaisesRegex(ValueError,'callable'):verifier.inspect_environment_sources(environment,self.lock,sources,False)

    def test_runtime_identity_digest_cannot_be_redefined(self):
        self.lock['runtime_identity']['python']='changed'
        with self.assertRaisesRegex(ValueError,'identity digest'):self.inspect()

    def test_actual_installed_identity_is_checked_without_model_imports(self):
        from defect_researcher import resolution_recovery_coordinator_v1 as coordinator
        self.dependencies_patch.stop()
        identity,paths=coordinator._dependencies()
        self.assertEqual(verifier.inspect_dependencies(identity),set(paths))
        bad=deepcopy(identity);bad['packages']['ultralytics']['critical_files'].pop()
        with self.assertRaisesRegex(ValueError,'dependency identity'):verifier.inspect_dependencies(bad)
        self.assertNotIn('torch',sys.modules);self.assertNotIn('ultralytics',sys.modules)


if __name__=='__main__':unittest.main()
