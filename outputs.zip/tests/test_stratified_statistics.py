import copy
import unittest
from defect_researcher.stratified_statistics import stratified_statistics


def fixture():
    record = {"image_id": "image", "width": 90, "height": 90,
        "ground_truth": [{"class_id": 0, "xyxy": [0, 0, 32, 32]}],
        "predictions": [{"class_id": 0, "xyxy": [0, 0, 31, 32], "confidence": .9},
                        {"class_id": 0, "xyxy": [40, 40, 74, 74], "confidence": .8}]}
    gt = [{"image_id": "image", "gt_index": 0, "class_id": 0, "xyxy": [0, 0, 32, 32],
           "status": "tp", "matched_prediction_index": 0}]
    fp = [{"image_id": "image", "prediction_index": 1, "class_id": 0, "xyxy": [40, 40, 74, 74]}]
    return [record], gt, fp


class StratifiedStatisticsTests(unittest.TestCase):
    def test_gt_size_and_prediction_size_use_their_own_denominators(self):
        value = stratified_statistics(*fixture())
        small, medium, _ = value["size_bucket"]
        self.assertEqual((small["gt"], small["tp_predictions"], small["precision_predictions"]), (0, 1, 1.0))
        self.assertEqual((medium["tp_gt"], medium["tp_predictions"], medium["fp_predictions"]), (1, 0, 1))
        self.assertEqual((medium["recall_gt"], medium["precision_predictions"]), (1.0, 0.0))

    def test_tp_and_fp_region_grouping_follows_prediction_centers(self):
        records, gt, fp = fixture()
        records[0]["ground_truth"][0]["xyxy"] = gt[0]["xyxy"] = [14, 0, 46, 32]
        records[0]["predictions"][0]["xyxy"] = [14, 0, 45, 32]
        rows = {r["region"]: r for r in stratified_statistics(records, gt, fp)["region"]}
        self.assertEqual(rows["top_center"]["tp_gt"], 1)
        self.assertEqual(rows["top_left"]["tp_predictions"], 1)
        self.assertEqual(rows["middle_center"]["fp_predictions"], 1)

    def test_missing_active_predictions_are_refused(self):
        records, gt, _ = fixture()
        with self.assertRaisesRegex(ValueError, "partition"):
            stratified_statistics(records, gt, [])

    def test_tp_prediction_cannot_also_be_false_positive(self):
        records, gt, fp = fixture()
        wrong = copy.deepcopy(fp[0]); wrong["prediction_index"] = 0
        with self.assertRaises(ValueError):
            stratified_statistics(records, gt, fp + [wrong])

    def test_duplicate_gt_or_missing_gt_is_refused(self):
        records, gt, fp = fixture()
        for rows in (gt + gt, []):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                stratified_statistics(records, rows, fp)

    def test_nonfinite_coordinate_is_refused(self):
        records, gt, fp = fixture()
        records[0]["predictions"][0]["xyxy"][2] = float("nan")
        with self.assertRaisesRegex(ValueError, "finite"):
            stratified_statistics(records, gt, fp)
