"""CPU-only preparation contracts; no model, AGH, domain setup or GPU calls."""
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from test_config import temporary_workspace

SOURCE = Path(__file__).resolve().parents[1] / "tools/prepare_resolution_research_model_v1.py"
SPEC = importlib.util.spec_from_file_location("resolution_deployment_preparation_v1", SOURCE)
module = importlib.util.module_from_spec(SPEC)
import sys
sys.modules[SPEC.name] = module
SPEC.loader.exec_module(module)


class Clock:
    epoch = 1000.1239
    mono = 5000.4569
    def time(self): return self.epoch
    def monotonic(self): return self.mono


class PreparationTests(unittest.TestCase):
    def fixture(self, root):
        for rel in set((*module.REQUIRED_SOURCES, *module.CONTROL_SOURCES)):
            path = root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("fixture source\n", encoding="utf-8")
        (root / "outputs").mkdir()
        worker = root / "worker.py"
        worker.write_text("fixture worker\n", encoding="utf-8")
        shell = root / "pwsh.exe"
        shell.write_bytes(b"fixture executable - never executed")
        runtime_path = root / "runtime.json"
        module.save(runtime_path, {"status": "passed_local_repair", "repair_version": 2,
                                  "runtime_files": [module.pin(worker)]})
        engineering = root / "engineering.json"
        module.save(engineering, {"status": "passed", "model_requests": 0, "gpu_tasks": 0,
                                  "tests": [{"name": "explicit fixture", "exit_code": 0}]})
        config = {"output_root": str(root / "domain-output")}
        deps = module.TestDependencies(root, config, (worker,), {"fixture_only": True}, Clock())
        return root / "outputs/deploy", engineering, runtime_path, shell, deps

    def run_prepare(self, values, request_id="fixed"):
        output, engineering, runtime, shell, deps = values
        with patch.object(module, "_dependencies", side_effect=AssertionError("No installed dependency inspection in fixtures")), \
             patch.object(module, "_sources", side_effect=AssertionError("No production worker preparation")):
            return module.prepare(output, request_id, engineering, runtime,
                                  powershell_executable=shell, test_dependencies=deps)

    def test_exact_separate_protocols_and_no_domain_clock_or_registry(self):
        with temporary_workspace() as root:
            values = self.fixture(root)
            receipt = self.run_prepare(values)
            output = values[0]
            deployment = module.read(output / "deployment_protocol.json")
            self.assertEqual(set(deployment), {"schema_version", "kind", "request_id", "task_id", "workspace_root",
                "started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic", "contract_sha256"})
            host = module.read(output / "model_protocol.json")
            self.assertEqual(len(host), 18)
            self.assertEqual(host["scope_policy"]["max_primary_requests"], 13)
            self.assertEqual(host["scope_policy"]["max_native_title_requests"], 1)
            self.assertEqual(host["scope_policy"]["max_model_requests"], 14)
            self.assertFalse(receipt["domain_clock_started"])
            self.assertFalse(receipt["domain_task_created"])
            self.assertFalse((output / "mcp-owned").exists())
            self.assertFalse((root / "domain-output").exists())
            self.assertEqual(receipt["status"], "fixture_only")
            self.assertEqual(module.read(output / "source_lock.json")["status"], "fixture_only")

    def test_actual_outer_anchor_sampled_once_and_rounded_down_only(self):
        with temporary_workspace() as root:
            values = self.fixture(root)
            receipt = self.run_prepare(values)
            deployment = module.read(values[0] / "deployment_protocol.json")
            self.assertEqual(receipt["sampled_actual_epoch"], values[4].clock.epoch)
            self.assertEqual(deployment["started_epoch"], 1000.123)
            self.assertEqual(deployment["deadline_epoch"], deployment["started_epoch"] + 2400)
            self.assertEqual(deployment["deadline_monotonic"], deployment["started_monotonic"] + 2400)
            self.assertEqual(module.read(values[0] / "model_protocol.json")["scope_policy"]["started_epoch_ms"], 1000123)

    def test_complete_source_snapshot_and_control_source_members(self):
        with temporary_workspace() as root:
            values = self.fixture(root)
            receipt = self.run_prepare(values)
            lock = module.read(values[0] / "source_lock.json")
            paths = {row["path"] for row in lock["files"]}
            for member in module.CONTROL_SOURCES:
                self.assertIn(str((root / member).resolve()), paths)
            self.assertEqual(len(paths), len(lock["files"]))
            for row in receipt["sources"]:
                self.assertEqual(module.pin(row["source"]["path"]), row["source"])
                self.assertEqual(row["source"]["sha256"], module.pin(row["archive"]["path"])["sha256"])
            self.assertFalse(lock["runtime_identity_is_domain_registration"])

    def test_existing_deployment_and_domain_task_are_never_replaced(self):
        with temporary_workspace() as root:
            values = self.fixture(root)
            self.run_prepare(values)
            before = module.pin(values[0] / "model_protocol.json")
            with self.assertRaises(FileExistsError): self.run_prepare(values)
            self.assertEqual(module.pin(values[0] / "model_protocol.json"), before)
        with temporary_workspace() as root:
            values = self.fixture(root)
            (root / "domain-output/resolution-research-v1-fixed").mkdir(parents=True)
            with self.assertRaises(FileExistsError): self.run_prepare(values)
            self.assertFalse(values[0].exists())

    def test_missing_sources_or_failed_engineering_rejected_before_output(self):
        for reason in ("source", "receipt", "runtime"):
            with self.subTest(reason=reason), temporary_workspace() as root:
                values = self.fixture(root)
                if reason == "source": (root / module.CONTROL_SOURCES[0]).unlink()
                elif reason == "receipt": values[1].write_text(json.dumps({"status": "failed"}), encoding="utf-8")
                else: (root / "worker.py").write_text("changed", encoding="utf-8")
                with self.assertRaises((ValueError, FileNotFoundError)): self.run_prepare(values)
                self.assertFalse(values[0].exists())

    def test_unsafe_request_escape_and_clock_are_rejected(self):
        with temporary_workspace() as root:
            values = self.fixture(root)
            for request in ("../escape", "", "x" * 65):
                with self.assertRaises(ValueError): self.run_prepare(values, request)
            escaped = (root / "escape", *values[1:])
            with self.assertRaises(ValueError): self.run_prepare(escaped)
            values[4].clock.epoch = float("nan")
            with self.assertRaises(ValueError): self.run_prepare(values)


if __name__ == "__main__":
    unittest.main()
