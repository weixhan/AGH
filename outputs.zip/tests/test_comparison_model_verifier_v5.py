import copy
from datetime import datetime, timezone
import unittest
from tools.verify_comparison_model_v5 import ROOT, check_ledger, check_budget, project_official, check_native_title


def fixture(request_count=1):
    begin = 1000000.0
    handle = 'cmp_' + 'a' * 32
    policy = {'schema_version': 1, 'workspace_root': str(ROOT/'outputs/comparison-pilot-v5/workspace'),
              'qualified_action_tool': 'mcp_dr_compare_v5_12345678_execute_case_action_v1',
              'allowed_handles': [handle], 'max_model_requests': 7, 'max_wall_seconds': 120, 'max_action_calls': 8}
    arm = {'started_epoch': begin / 1000, 'started_monotonic': 100,
           'deadline_epoch': (begin + 120000) / 1000, 'deadline_monotonic': 220}
    rows = []
    def add(kind, data, origin='system', trust='trusted'):
        index = len(rows) + 1
        row = {'seq': index, 'ts': datetime.fromtimestamp((begin+index)/1000, timezone.utc).isoformat().replace('+00:00','Z'),
               'type': kind, 'origin': origin, 'trust': trust, 'data': data}
        rows.append(row)
        return row
    add('session/start', {'key': 'session'})
    ready = add('x/plugin/test/scope-ready', {'mode': 'case-comparison-v1', 'session_key': 'session',
                'workspace_root': '<workspace>', 'policy': {**policy, 'workspace_root': '<workspace>'}}, 'ext:plugin/test','untrusted')
    sdk_ready = copy.deepcopy(ready)
    sdk_ready['data']['workspace_root'] = policy['workspace_root']
    sdk_ready['data']['policy'] = copy.deepcopy(policy)
    for index in range(1, request_count+1):
        add('x/plugin/test/scope-request-decision', {'session_key': 'session', 'allow': True,
            'request_index': index, 'trial_handle': handle, 'arm_sha256': 'b'*64,
            'started_epoch_ms': begin, 'deadline_epoch_ms': begin+120000}, 'ext:plugin/test', 'untrusted')
        add('request/sent', {'model': {'id':'agnes-3.0-flash','route':'account-defect-researcher'}, 'tool_schema_hash': 'c'*64})
        add('cost/ledger', {'purpose':'inference', 'model':'agnes-3.0-flash', 'tokens':{'input':1,'output':1}, 'response':{'status':200}})
    add('assistant/message', {'content':[{'type':'text','text':'未发布报告。'}]}, 'model')
    end = add('turn/end', {'reason':'completed', 'turn':1})
    title_request = add('x/host/session-title', {'status':'requested','turn':1,'route':'account-defect-researcher','model':'agnes-3.0-flash'})
    add('cost/ledger', {'purpose':'title','model':'agnes-3.0-flash','sourceTurn':1,'tokens':{'input':1,'output':1,'cacheRead':0,'cacheWrite':0}})
    title_terminal = add('x/host/session-title', {'status':'generated','turn':1,'title':'Fixture title'})
    run = {'trial_handle':handle, 'scope_ready':sdk_ready, 'session_id':'session', 'session_key':'session',
           'workspace_root':policy['workspace_root'], 'qualified_action_tool':policy['qualified_action_tool'],
           'started_epoch_ms':begin, 'deadline_epoch_ms':begin+120000, 'finished_epoch_ms':begin+100,
           'arm_sha256':'b'*64, 'model':'agnes-3.0-flash', 'route':'account-defect-researcher',
           'active_binding':{'schema_version':1,'owner':'comparison-model-runner-v1','trial_handle':handle,
                'session_key':'session','started_epoch_ms':begin,'deadline_epoch_ms':begin+120000,'arm_sha256':'b'*64},
           'model_request_count':request_count, 'model_requests_including_title':request_count+1, 'title_request_event':title_request, 'title_terminal_event':title_terminal,
           'calls':[], 'results':[], 'permissions':[], 'hook_events':[],
           'scope_request_events':[r for r in rows if r['type'].endswith('/scope-request-decision')],
           'request_events':[r for r in rows if r['type']=='request/sent'],
           'cost_events':[r for r in rows if r['type']=='cost/ledger'],
           'turn_end':end, 'final_texts':[r for r in rows if r['type']=='assistant/message'],
           'sdk_events':copy.deepcopy(rows)}
    run['sdk_events'][1] = sdk_ready
    return rows, run, arm


class ModelLedgerTests(unittest.TestCase):
    def assert_failed(self, rows, run, arm):
        self.assertTrue(check_ledger(rows, run, arm)['errors'])

    def test_missing_publication_is_valid_observation_not_success(self):
        rows, run, arm = fixture()
        result = check_ledger(rows, run, arm, known_actions=[])
        self.assertFalse(result['errors'], result)
        self.assertFalse(result['publication_accepted'])

    def test_seven_primary_requests_allowed_eighth_refused(self):
        rows, run, arm = fixture(7)
        self.assertFalse(check_ledger(rows, run, arm)['errors'])
        self.assert_failed(*fixture(8))

    def test_failed_provider_request_still_counted_when_actual_usage_known(self):
        rows, run, arm = fixture()
        run['cost_events'][0]['data']['response']['status'] = 500
        result = check_ledger(rows, run, arm)
        self.assertFalse(result['errors'], result)
        self.assertEqual(result['model_request_count'], 1)

    def test_missing_usage_is_unknown_cost_not_zero(self):
        rows, run, arm = fixture(); run['cost_events'][0]['data'].pop('tokens')
        self.assert_failed(rows, run, arm)

    def test_sequence_gap_refused(self):
        rows, run, arm = fixture(); rows[3]['seq'] += 1
        self.assert_failed(rows, run, arm)

    def test_extended_or_swapped_clock_refused(self):
        rows, run, arm = fixture(); run['deadline_epoch_ms'] += 1
        self.assert_failed(rows, run, arm)
        rows, run, arm = fixture(); run['active_binding']['session_key'] = 'foreign'
        self.assert_failed(rows, run, arm)

    def test_finalization_cannot_reset_original_deadline(self):
        rows, run, arm = fixture(); run['finished_epoch_ms'] = run['deadline_epoch_ms']
        self.assert_failed(rows, run, arm)

    def test_model_or_schema_change_refused(self):
        rows, run, arm = fixture(); rows[3]['data']['model']['id'] = 'other'
        self.assert_failed(rows, run, arm)
        rows, run, arm = fixture(2); rows[6]['data']['tool_schema_hash'] = 'd'*64
        self.assert_failed(rows, run, arm)

    def test_guard_attempt_cannot_replace_backend_anchor(self):
        rows, run, arm = fixture(); run['scope_request_events'][0]['data']['started_epoch_ms'] += 1
        self.assert_failed(rows, run, arm)

    def test_foreign_execution_without_scope_receipt_refused(self):
        rows, run, arm = fixture(); rows.insert(-1, {'seq':len(rows),'ts':rows[-1]['ts'],'type':'tool/call','origin':'model','trust':'trusted','data':{'name':'shell','toolUseId':'escape','args':{}}})
        rows[-1]['seq'] += 1
        self.assert_failed(rows, run, arm)

    def test_budget_open_unknown_reservation_and_late_known_cost_refused(self):
        arm = {'started_epoch':100,'started_monotonic':200,'deadline_epoch':220,'deadline_monotonic':320}
        opening = {'sequence':0,'event':'ledger_opened','record':{**arm,'current_epoch':100,'current_monotonic':200}}
        self.assertEqual(check_budget([opening],arm),0)
        reserve = {'sequence':1,'event':'action_reserved','record':{'action':'verify_input','reserved_cost':1,'current_epoch':101,'current_monotonic':201}}
        with self.assertRaises(ValueError):check_budget([opening,reserve],arm)

    def test_masks_never_restore_unknown_or_integer_claims(self):
        value={'budget':{'started_epoch':'__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__'}}
        self.assertTrue(project_official(value, {'budget':{'started_epoch':1.25}}, [['budget','started_epoch']]))
        with self.assertRaises(ValueError):project_official(value, {'budget':{'started_epoch':1}}, [['budget','started_epoch']])

    def test_native_title_is_counted_beyond_primary_request_sent(self):
        rows, run, arm = fixture(7)
        result = check_ledger(rows, run, arm)
        self.assertFalse(result['errors'], result)
        self.assertEqual(result['actual_total_model_requests'], 8)
        self.assertEqual(result['native_title_requests'], 1)

    def test_native_title_unknown_usage_cannot_be_treated_as_zero(self):
        rows, run, arm = fixture()
        cost = next(r for r in rows if r['type']=='cost/ledger' and r['data']['purpose']=='title')
        cost['data']['interrupted']=True
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)
        cost['data'].pop('interrupted');cost['data']['tokens'].pop('output')
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)

    def test_native_title_cannot_extend_original_deadline_or_skip_receipt(self):
        rows, run, arm = fixture()
        run['title_terminal_event']['ts']=datetime.fromtimestamp(arm['deadline_epoch'],timezone.utc).isoformat()
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)
        rows, run, arm = fixture()
        rows=[r for r in rows if not(r['type']=='cost/ledger' and r['data']['purpose']=='title')]
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)


if __name__ == '__main__': unittest.main()
