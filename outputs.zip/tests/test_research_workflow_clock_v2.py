"""Regression tests for charging trusted worker-to-controller handoff time."""
import hashlib
import ast
from pathlib import Path
import time
import unittest
from unittest.mock import patch

from defect_researcher.config import load_config
from defect_researcher.research_protocol_v1 import BudgetError, BudgetLedger
from defect_researcher import research_mcp_runtime_v2 as runtime
from defect_researcher import research_workflow_clock_v2 as workflow
from test_config import temporary_workspace


class IdleProcess:
    pid = __import__("os").getpid()

    def poll(self):
        return None


class ClockHandoffV2Tests(unittest.TestCase):
    def request(self, identity="clock", wall=120, calls=0):
        return {"schema_version": 1, "workflow_version": 1,
                "request_id": identity, "case_id": "normal_unrotated",
                "budget": {"domain_invocations": calls, "wall_seconds": wall,
                           "gpu_seconds": 0, "model_requests": 0}}

    def anchor(self, epoch=1000, monotonic=50, wall=120):
        return {"schema_version": 1, "registration_sha256": "a" * 64,
                "started_epoch": epoch, "started_monotonic": monotonic,
                "original_deadline_epoch": epoch + wall,
                "original_deadline_monotonic": monotonic + wall,
                "remaining_wall_seconds": wall}

    def test_both_deadlines_stay_anchored_and_full_handoff_delay_is_charged(self):
        # 75 ms exceeds the actual rejected trial's 19.607/15.186 ms drift.
        clocks = {"epoch": 1000.075, "monotonic": 50.075}
        anchor = self.anchor()
        with temporary_workspace() as directory, \
                patch.object(workflow.time, "time", side_effect=lambda: clocks["epoch"]), \
                patch.object(workflow.time, "monotonic", side_effect=lambda: clocks["monotonic"]):
            mono, epoch = workflow._anchored_clocks(self.request(), anchor)
            ledger = BudgetLedger(directory, self.request(), clock=mono, epoch_clock=epoch)
            snapshot = ledger.snapshot()
            self.assertEqual(snapshot["started_epoch"], anchor["started_epoch"])
            self.assertEqual(snapshot["started_monotonic"], anchor["started_monotonic"])
            self.assertEqual(snapshot["deadline_epoch"], anchor["original_deadline_epoch"])
            self.assertEqual(snapshot["deadline_monotonic"], anchor["original_deadline_monotonic"])
            self.assertAlmostEqual(snapshot["elapsed_wall_seconds"], 0.075)
            # Later readings are real clocks, rather than a frozen fake clock.
            clocks.update(epoch=1000.2, monotonic=50.2)
            self.assertAlmostEqual(ledger.snapshot()["elapsed_wall_seconds"], 0.2)
            ledger.check()

    def test_minimum_remaining_caps_both_clocks_when_epoch_advanced_faster(self):
        anchor = self.anchor(wall=119.5)
        anchor["original_deadline_monotonic"] = 170
        with temporary_workspace() as directory, \
                patch.object(workflow.time, "time", return_value=1000.05), \
                patch.object(workflow.time, "monotonic", return_value=50.05):
            mono, epoch = workflow._anchored_clocks(self.request(wall=119.5), anchor)
            ledger = BudgetLedger(directory, self.request(wall=119.5), clock=mono, epoch_clock=epoch)
            self.assertEqual(ledger.deadline_epoch, 1119.5)
            self.assertEqual(ledger.deadline_monotonic, 169.5)
            self.assertLessEqual(ledger.deadline_monotonic, anchor["original_deadline_monotonic"])

    def test_expiry_on_either_clock_refuses_before_workflow_output(self):
        for epoch, monotonic in ((1120, 50.05), (1000.05, 170)):
            with self.subTest(epoch=epoch, monotonic=monotonic), temporary_workspace() as directory, \
                    patch.object(workflow.time, "time", return_value=epoch), \
                    patch.object(workflow.time, "monotonic", return_value=monotonic):
                config = {**load_config(), "output_root": str(directory / "outputs")}
                with self.assertRaisesRegex(BudgetError, "expired"):
                    workflow.run_workflow(self.request(), config, trusted_clock_anchor=self.anchor())
                self.assertFalse((directory / "outputs").exists())

    def test_no_deadline_reset_after_anchor_validation_then_late_construction(self):
        clocks = {"epoch": 1000.05, "monotonic": 50.05}
        with temporary_workspace() as directory, \
                patch.object(workflow.time, "time", side_effect=lambda: clocks["epoch"]), \
                patch.object(workflow.time, "monotonic", side_effect=lambda: clocks["monotonic"]):
            mono, epoch = workflow._anchored_clocks(self.request(), self.anchor())
            clocks.update(epoch=1120.1, monotonic=170.1)
            ledger = BudgetLedger(directory, self.request(), clock=mono, epoch_clock=epoch)
            with self.assertRaisesRegex(BudgetError, "expired"):
                ledger.check()
            self.assertEqual(ledger.used_domain_invocations, 0)
            self.assertFalse((directory / "completion.json").exists())

    def test_backwards_clocks_refused_before_and_after_construction(self):
        for epoch, monotonic in ((999, 50), (1000, 49)):
            with self.subTest(epoch=epoch, monotonic=monotonic), \
                    patch.object(workflow.time, "time", return_value=epoch), \
                    patch.object(workflow.time, "monotonic", return_value=monotonic):
                with self.assertRaisesRegex(BudgetError, "backwards"):
                    workflow._anchored_clocks(self.request(), self.anchor())
        clocks = {"epoch": 1000.05, "monotonic": 50.05}
        with temporary_workspace() as directory, \
                patch.object(workflow.time, "time", side_effect=lambda: clocks["epoch"]), \
                patch.object(workflow.time, "monotonic", side_effect=lambda: clocks["monotonic"]):
            mono, epoch = workflow._anchored_clocks(self.request(), self.anchor())
            ledger = BudgetLedger(directory, self.request(), clock=mono, epoch_clock=epoch)
            ledger.check()
            clocks["monotonic"] = 50.04
            with self.assertRaisesRegex(BudgetError, "backwards"):
                ledger.check()

    def test_strict_internal_anchor_rejects_invalid_fields_and_budget_mismatch(self):
        examples = [None, {}, {**self.anchor(), "path": "x"},
                    {**self.anchor(), "schema_version": True},
                    {**self.anchor(), "registration_sha256": "b"},
                    {**self.anchor(), "started_epoch": True},
                    {**self.anchor(), "started_monotonic": float("nan")},
                    {**self.anchor(), "started_epoch": -1},
                    {**self.anchor(), "remaining_wall_seconds": 119},
                    {**self.anchor(), "original_deadline_epoch": 1119}]
        with patch.object(workflow.time, "time", return_value=1000.05), \
                patch.object(workflow.time, "monotonic", return_value=50.05):
            for anchor in examples:
                with self.subTest(anchor=anchor), self.assertRaises(ValueError):
                    workflow._anchored_clocks(self.request(), anchor)
            with self.assertRaises(ValueError):
                workflow._anchored_clocks(self.request(wall=119), self.anchor())
        with self.assertRaises(TypeError):
            workflow.run_workflow(self.request())

    def test_even_floating_point_representational_extension_is_refused(self):
        anchor = self.anchor(epoch=0.3, monotonic=50, wall=0.6)
        anchor["original_deadline_epoch"] = 0.9
        anchor["original_deadline_monotonic"] = 50.8
        remaining = min(0.9 - 0.3, 50.8 - 50)
        anchor["remaining_wall_seconds"] = remaining
        self.assertGreater(0.3 + remaining, 0.9)
        with self.assertRaisesRegex(ValueError, "extends"):
            workflow._anchored_clocks(self.request(wall=remaining), anchor)

    def test_business_function_matches_frozen_v1_after_clock_wiring_removed(self):
        frozen = runtime.PROJECT_ROOT / "defect_researcher/research_workflow_v1.py"

        def body(path):
            tree = ast.parse(path.read_text(encoding="utf-8"))
            node = next(item for item in tree.body
                        if isinstance(item, ast.FunctionDef) and item.name == "run_workflow")
            rows = node.body[1:]  # The version-specific documentation is separate.
            if path.name == "research_workflow_clock_v2.py":
                rows = [row for row in rows
                        if not (isinstance(row, ast.Assign)
                                and isinstance(row.value, ast.Call)
                                and isinstance(row.value.func, ast.Name)
                                and row.value.func.id == "_anchored_clocks")]
                ledger = next(row for row in rows
                              if isinstance(row, ast.Assign) and isinstance(row.value, ast.Call)
                              and isinstance(row.value.func, ast.Name) and row.value.func.id == "BudgetLedger")
                ledger.value.keywords = []
            return [ast.dump(row, include_attributes=False) for row in rows]

        self.assertEqual(body(Path(workflow.__file__)), body(frozen))

    def test_real_owned_worker_charges_slow_request_write_and_checks_both_deadlines(self):
        with temporary_workspace() as directory:
            owner = runtime.Runtime({**load_config(), "output_root": str(directory / "outputs")})
            arguments = {key: value for key, value in self.request().items()
                         if key in ("request_id", "case_id", "budget")}
            with patch.object(runtime.subprocess, "Popen", return_value=IdleProcess()):
                initial = owner.start(arguments)
            entry = owner.registry_root / initial["workflow_id"]
            original_write = runtime._write_exclusive

            def delayed_write(path, value):
                if Path(path).name == "worker_request.json":
                    time.sleep(0.075)
                return original_write(path, value)

            with patch.object(runtime, "_write_exclusive", side_effect=delayed_write):
                self.assertEqual(runtime.worker(entry / "registration.json"), 0)
            result = owner.get_status({"workflow_id": initial["workflow_id"]})
            self.assertEqual(result["status"], "completed", result)
            task = Path(result["evidence"]["directory"])
            anchor = runtime._read(entry / "worker_clock_anchor.json")
            original = runtime._registration(entry / "registration.json")
            controller = runtime._read(task / "runtime.json")
            budget_rows = [__import__("json").loads(line)
                           for line in (task / "budget.jsonl").read_text().splitlines()]
            self.assertEqual(budget_rows[0]["record"]["started_epoch"], anchor["started_epoch"])
            self.assertEqual(budget_rows[0]["record"]["started_monotonic"], anchor["started_monotonic"])
            events = [__import__("json").loads(line)
                      for line in (task / "events.jsonl").read_text().splitlines()]
            self.assertGreaterEqual(events[0]["elapsed_seconds"], 0.06)
            for suffix in ("epoch", "monotonic"):
                self.assertEqual(controller["started_" + suffix], anchor["started_" + suffix])
                self.assertLessEqual(controller["deadline_" + suffix], original["deadline_" + suffix])
            # Altering the new origin after publication prevents a terminal read.
            changed = {**anchor, "started_monotonic": anchor["started_monotonic"] - 0.05}
            (entry / "worker_clock_anchor.json").write_text(__import__("json").dumps(changed))
            self.assertEqual(owner.get_status({"workflow_id": initial["workflow_id"]})["status"], "failed")

    def test_all_original_frozen_sources_and_preserved_evidence_unchanged(self):
        state = runtime._verify_frozen_sources()
        self.assertEqual((state["current_sources"], state["archive_sources"], state["preserved_files"]),
                         (25, 25, 968))
        self.assertEqual(state["freeze_sha256"], runtime.FREEZE_SHA256)
        self.assertEqual(state["controller_sha256"], hashlib.sha256(Path(workflow.__file__).read_bytes()).hexdigest())


if __name__ == "__main__":
    unittest.main()
