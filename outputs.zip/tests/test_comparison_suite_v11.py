"""Fresh full-population selection and a consistent seven-call V11 contract.

All executions are local fixture actions. No model, detector, service deployment
or contest-stage registration is performed by this test module.
"""
import copy
import hashlib
import importlib
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch

from defect_researcher.config import load_config
from test_config import temporary_workspace


ROOT = Path(__file__).resolve().parents[1]
EXPECTED_BUDGET = {"domain_invocations": 6, "model_requests": 7,
                   "wall_seconds": 120, "gpu_seconds": 0}
HANDLE = "cmp_" + "a" * 32


def modules():
    return (importlib.import_module("defect_researcher.comparison_protocol_v11"),
            importlib.import_module("tools.verify_comparison_model_v11"))


def make_protocol(stage="pilot"):
    protocol, _ = modules()
    mcp = importlib.import_module("defect_researcher.comparison_mcp_server_v11")
    catalogue = [{key: row[key] for key in ("name", "description", "inputSchema")}
                 for row in mcp._tools()]
    return protocol.make_protocol("cmp-suite-v11-" + stage,
        model={"slot": "primary", "model": "agnes-3.0-flash",
               "route": "account-defect-researcher"},
        task_prompt="Inspect evidence, choose supported actions, and publish a report.",
        tool_catalog=catalogue, source_paths={"protocol": Path(protocol.__file__)},
        generation_settings={"explicit_overrides": {}, "runtime_defaults_shared": True},
        stage="formal" if stage == "formal" else "pilot")


def public_protocol(protocol):
    stage = protocol["run_id"].removeprefix("cmp-suite-v11-")
    selected = ([row for row in protocol["trials"] if row["arm"] == "F" and row["case_id"] in
                 {"repair_coordinates", "refuse_source_hash"}] if stage == "diagnostic" else protocol["trials"])
    selection = {"schema_version": 1, "stage": stage,
                 "trial_handles": [row["trial_handle"] for row in selected],
                 "planned_trial_count": len(protocol["trials"]), "selected_trial_count": len(selected)}
    server = "dr-compare-v11-" + stage
    cap = {"diagnostic": 14, "pilot": 42, "formal": 168}[stage]
    return {"stage": stage, "server_id": server,
        "phase_model_budget": {"total_cap": cap, "prior_closed_request_slots": 0, "request_slots_debited": 0,
            "this_pilot_cap": cap, "phase_remaining_before_diagnostic": cap, "legacy_token_usage_closed": True},
        "model_accounting": {"primary_cap": 6, "native_title_reserved_calls": 1,
            "combined_per_trial_cap": 7, "primary_wall_seconds": 85,
            "native_title_and_export_reserve_seconds": 35, "all_within_original_wall_seconds": 120},
        "scope_policy": {
        "schema_version": 1,
        "workspace_root": str(ROOT / ("outputs/comparison-suite-v11-" + stage) / "workspace"),
        "qualified_action_tool": "mcp_dr_compare_v11_" + stage + "_" +
            hashlib.sha256(server.encode()).hexdigest()[:8] + "_execute_case_action_v1",
        "allowed_handles": [row["trial_handle"] for row in selected if row["arm"] != "C"],
        "max_model_requests": 6, "max_wall_seconds": 120, "max_action_calls": 8},
        "selection": selection,
        "selection_sha256": hashlib.sha256(json.dumps(selection, sort_keys=True,
            ensure_ascii=False, separators=(",", ":")).encode("utf8")).hexdigest()}


def refresh_selection_hash(public):
    selection = public["selection"]
    public["selection_sha256"] = hashlib.sha256(json.dumps(
        selection, sort_keys=True, ensure_ascii=False, separators=(",", ":"),
        allow_nan=False).encode("utf8")).hexdigest()


class V11AdapterTests(unittest.TestCase):
    def setUp(self):
        self.environment = patch.dict(os.environ)
        self.environment.start()
        os.environ.pop("DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_PATH", None)
        os.environ.pop("DEFECT_RESEARCH_COMPARISON_SOURCE_LOCK_SHA256", None)
        self.runtime = importlib.import_module("defect_researcher.comparison_case_runtime_v11")
        self.evaluator = importlib.import_module("tools.verify_comparison_case_v11")

    def tearDown(self):
        self.environment.stop()

    def instance(self, directory):
        return self.runtime.Runtime({**load_config(), "output_root": str(directory / "comparison")})

    def candidate(self, handle, evidence, outcome):
        return {"schema_version": 1, "trial_handle": handle, "outcome": outcome,
            "target": {"clean": "input", "repaired": "copy", "refused": "none"}[outcome],
            "evidence_ids": [evidence["evidence_id"]],
            "claims": [{"name": "current_verdict", "field": "semantic_status",
                "value": evidence["result"]["semantic_status"],
                "evidence_id": evidence["evidence_id"]}],
            "scope": {"synthetic_only": True, "historical_evidence_reused": False,
                      "new_detector_calls": 0, "gpu_seconds": 0}}

    def completed(self, instance, identity, case, arm="F"):
        handle = instance.prepare(identity, case["id"], arm)["trial_handle"]
        instance.arm(handle)
        directory = instance.root / "trials" / handle
        instance.action(handle, "verify_input")
        final_action = "verify_input"
        if case["group"] == "repairable":
            instance.action(handle, "repair_copy")
            instance.action(handle, "verify_copy")
            final_action = "verify_copy"
        evidence = self.runtime.read(directory / "evidence" / (final_action + ".json"))
        outcome = {"normal": "clean", "repairable": "repaired", "refused": "refused"}[case["group"]]
        result = instance.action(handle, "publish_report", self.candidate(handle, evidence, outcome))
        return handle, directory, result

    def test_protocol_runtime_share_typed_seven_budget_without_changing_v1(self):
        protocol, _ = modules()
        old = importlib.import_module("defect_researcher.comparison_case_runtime_v1")
        self.assertEqual(protocol.BUDGET, {**EXPECTED_BUDGET, "detector_calls": 0})
        self.assertEqual(self.runtime.BUDGET, EXPECTED_BUDGET)
        self.assertTrue(all(type(value) is int for value in self.runtime.BUDGET.values()))
        self.assertEqual(old.BUDGET["model_requests"], 8)
        self.assertEqual(old.OWNER, "defect_researcher.comparison_case_runtime_v1")
        self.assertEqual(self.runtime.OWNER, "defect_researcher.comparison_case_runtime_v11")

    def test_private_arm_and_public_payload_preserve_seven_and_unknown_actual_usage(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle = instance.prepare("budget-seven", "normal_unrotated", "U")["trial_handle"]
            original = instance.arm(handle)
            public = instance.action(handle, "inspect_input")
            trial = instance.root / "trials" / handle
            self.assertEqual(original["budget"], EXPECTED_BUDGET)
            self.assertEqual(self.runtime.read(trial / "arm.json")["budget"], EXPECTED_BUDGET)
            self.assertEqual(public["budget"]["model_requests_cap"], 7)
            self.assertIsNone(public["budget"]["model_requests"])
            self.assertEqual(public["budget"]["model_request_accounting"], "external_official_sdk_ledger")
            self.assertEqual(self.runtime.read(trial / "registration.json")["owner"], self.runtime.OWNER)
            with self.assertRaises(FileExistsError):
                instance.arm(handle)
            self.assertEqual(original, self.runtime.read(trial / "arm.json"))

    def test_rebound_legacy_or_untyped_arm_budget_is_still_refused(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle = instance.prepare("typed-budget", "normal_unrotated", "F")["trial_handle"]
            instance.arm(handle)
            trial = instance.root / "trials" / handle
            original = self.runtime.read(trial / "arm.json")
            for value in (8, 7.0, True, "7", None):
                with self.subTest(value=value):
                    changed = copy.deepcopy(original)
                    changed["budget"]["model_requests"] = value
                    (trial / "arm.json").write_text(json.dumps(changed), encoding="utf8")
                    (trial / "arm_binding.json").write_text(json.dumps(
                        self.runtime.record(trial / "arm.json")), encoding="utf8")
                    with self.assertRaises(self.runtime.BudgetError):
                        instance._armed(trial)

    def test_all_twelve_local_cases_pass_independent_v11_evaluator_at_budget_seven(self):
        protocol, _ = modules()
        cases = protocol.load_case_spec()["cases"]
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            for case in cases:
                with self.subTest(case=case["id"]):
                    _, trial, result = self.completed(instance, "seven-" + case["id"], case)
                    checked = self.evaluator.verify(trial)
                    self.assertEqual(result["status"], "published", result)
                    self.assertEqual(checked["status"], "passed", checked["errors"])
                    self.assertEqual(checked["unsupported_atomic_claims"], 0)
                    self.assertEqual(result["budget"]["model_requests_cap"], 7)
                    self.assertIsNone(checked["model_requests"])
                    self.assertFalse(checked["model_budget_verified"])
                    self.assertEqual(checked["new_detector_calls"], 0)
                    self.assertEqual(checked["gpu_seconds"], 0)

    def test_evaluator_rejects_legacy_owner_and_budget_without_faking_model_accounting(self):
        protocol, _ = modules()
        case = protocol.load_case_spec()["cases"][0]
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            _, trial, _ = self.completed(instance, "owner-budget", case)
            registration = self.runtime.read(trial / "registration.json")
            registration["owner"] = "defect_researcher.comparison_case_runtime_v1"
            (trial / "registration.json").write_text(json.dumps(registration), encoding="utf8")
            checked = self.evaluator.verify(trial)
            checks = {row["name"]: row["passed"] for row in checked["checks"]}
            self.assertFalse(checks["owned_terminal_identity"])
            self.assertFalse(checked["model_budget_verified"])
            self.assertIsNone(checked["model_requests"])

    def test_evaluator_rejects_typed_legacy_capacity_after_exact_arm_rebinding(self):
        protocol, _ = modules()
        case = protocol.load_case_spec()["cases"][0]
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            _, trial, _ = self.completed(instance, "legacy-capacity", case)
            for value in (8, 7.0):
                with self.subTest(value=value):
                    arm = self.runtime.read(trial / "arm.json")
                    arm["budget"]["model_requests"] = value
                    (trial / "arm.json").write_text(json.dumps(arm), encoding="utf8")
                    (trial / "arm_binding.json").write_text(json.dumps(
                        self.runtime.record(trial / "arm.json")), encoding="utf8")
                    checked = self.evaluator.verify(trial)
                    checks = {row["name"]: row["passed"] for row in checked["checks"]}
                    self.assertFalse(checks["registration_hash_and_original_clock_bound"])

    def test_v11_pin_requires_new_adapter_members(self):
        members = [ROOT / name for name in (
            "defect_researcher/comparison_case_runtime_v11.py",
            "defect_researcher/comparison_protocol_v11.py",
            "defect_researcher/comparison_mcp_server_v11.py",
            "run_comparison_mcp_v11.py", "tools/verify_comparison_case_v11.py", "config/local.json")]
        members.append(self.runtime.FREEZE)
        with temporary_workspace() as directory:
            location = directory / "source-lock.json"
            value = {"schema_version": 1, "kind": "comparison_case_implementation_v1", "status": "passed",
                     "files": [self.runtime.record(path) for path in members]}
            location.write_text(json.dumps(value), encoding="utf8")
            self.runtime._check_pin({"path": str(location), "sha256": self.runtime.sha(location)})
            for omitted in ("comparison_case_runtime_v11.py", "comparison_protocol_v11.py",
                            "comparison_mcp_server_v11.py", "run_comparison_mcp_v11.py",
                            "verify_comparison_case_v11.py"):
                with self.subTest(omitted=omitted):
                    changed = copy.deepcopy(value)
                    changed["files"] = [row for row in changed["files"] if Path(row["path"]).name != omitted]
                    location.write_text(json.dumps(changed), encoding="utf8")
                    with self.assertRaisesRegex(ValueError, "omits a required"):
                        self.runtime._check_pin({"path": str(location), "sha256": self.runtime.sha(location)})


class V11MCPContractTests(unittest.TestCase):
    def server(self):
        mcp = importlib.import_module("defect_researcher.comparison_mcp_server_v11")
        class LocalRuntime:
            def execute(self, value):
                return {"schema_version": 1, **copy.deepcopy(value), "status": "executed",
                        "budget": {"model_requests_cap": 7, "model_requests": None}}
        server = mcp.ComparisonMCPServer(runtime=LocalRuntime())
        server.handle_message({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": mcp.PROTOCOL_VERSION, "capabilities": {},
            "clientInfo": {"name": "v11-local-test", "version": "1"}}})
        server.handle_message({"jsonrpc": "2.0", "method": "notifications/initialized"})
        return server

    def test_catalogue_is_shared_and_budget_cannot_be_selected_in_action(self):
        server = self.server()
        tools = server.handle_message({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})["result"]["tools"]
        self.assertEqual([row["name"] for row in tools], ["execute_case_action_v1"])
        self.assertNotIn("budget", tools[0]["inputSchema"]["properties"])
        arguments = {"trial_handle": HANDLE, "action": "inspect_input"}
        response = server.handle_message({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
            "name": "execute_case_action_v1", "arguments": arguments}})
        observed = json.loads(response["result"]["content"][0]["text"])
        self.assertEqual(observed["budget"]["model_requests_cap"], 7)
        for name, args in (("audit_dataset", {}), ("execute_case_action_v1", {**arguments, "budget": EXPECTED_BUDGET})):
            with self.subTest(name=name, args=args):
                result = server.handle_message({"jsonrpc": "2.0", "id": 4, "method": "tools/call",
                    "params": {"name": name, "arguments": args}})
                self.assertEqual(result["error"]["code"], -32602)


class V11FullSelectionTests(unittest.TestCase):
    def test_diagnostic_registers_nine_but_selects_only_f_repair_then_refusal(self):
        _, verifier = modules()
        protocol = make_protocol("diagnostic")
        public = public_protocol(protocol)
        selected = [row for row in protocol["trials"] if row["trial_handle"] in
                    public["selection"]["trial_handles"]]
        self.assertEqual(len(protocol["trials"]), 9)
        self.assertEqual([(row["arm"], row["case_id"]) for row in selected],
                         [("F", "repair_coordinates"), ("F", "refuse_source_hash")])
        self.assertEqual(public["phase_model_budget"]["total_cap"], 14)
        for row in selected:
            verifier.check_full_selection(protocol, public, row["trial_handle"])
        for row in protocol["trials"]:
            if row not in selected:
                with self.subTest(arm=row["arm"], case=row["case_id"]), self.assertRaises(ValueError):
                    verifier.check_full_selection(protocol, public, row["trial_handle"], scripted=row["arm"] == "C")

    def test_diagnostic_selection_cannot_expand_to_clean_or_other_treatments(self):
        _, verifier = modules()
        for target in ("all", "clean", "u"):
            with self.subTest(target=target):
                protocol = make_protocol("diagnostic")
                public = public_protocol(protocol)
                if target == "all": selected = protocol["trials"]
                elif target == "clean": selected = [row for row in protocol["trials"] if row["arm"] == "F"]
                else: selected = [row for row in protocol["trials"] if row["arm"] == "U" and row["case_id"] in
                                  {"repair_coordinates", "refuse_source_hash"}]
                public["selection"]["trial_handles"] = [row["trial_handle"] for row in selected]
                public["selection"]["selected_trial_count"] = len(selected)
                public["scope_policy"]["allowed_handles"] = [row["trial_handle"] for row in selected if row["arm"] != "C"]
                refresh_selection_hash(public)
                with self.assertRaises(ValueError):
                    verifier.check_full_selection(protocol, public, selected[0]["trial_handle"])

    def test_complete_pilot_and_formal_allow_models_and_scripted_c_separately(self):
        _, verifier = modules()
        for stage, count, models in (("pilot", 9, 6), ("formal", 36, 24)):
            with self.subTest(stage=stage):
                protocol = make_protocol(stage)
                public = public_protocol(protocol)
                before = copy.deepcopy((protocol, public))
                self.assertEqual(len(public["scope_policy"]["allowed_handles"]), models)
                self.assertEqual(public["selection"]["selected_trial_count"], count)
                for row in protocol["trials"]:
                    verifier.check_full_selection(protocol, public, row["trial_handle"], scripted=row["arm"] == "C")
                self.assertEqual((protocol, public), before)

    def test_partial_duplicated_reordered_or_foreign_selection_rejected_after_rehash(self):
        _, verifier = modules()
        for mutation in ("partial", "duplicate", "reorder", "foreign", "stage", "count"):
            with self.subTest(mutation=mutation):
                protocol = make_protocol()
                public = public_protocol(protocol)
                selection = public["selection"]
                handles = selection["trial_handles"]
                if mutation == "partial": handles.pop()
                elif mutation == "duplicate": handles[-1] = handles[0]
                elif mutation == "reorder": handles.reverse()
                elif mutation == "foreign": handles[-1] = "cmp_" + "b" * 32
                elif mutation == "stage": selection["stage"] = "formal"
                else: selection["selected_trial_count"] = 8
                refresh_selection_hash(public)
                with self.assertRaises(ValueError):
                    verifier.check_full_selection(protocol, public, protocol["trials"][1]["trial_handle"])

    def test_c_never_gets_model_guard_and_model_cannot_use_scripted_route(self):
        _, verifier = modules()
        protocol = make_protocol()
        public = public_protocol(protocol)
        c = next(row for row in protocol["trials"] if row["arm"] == "C")
        model = next(row for row in protocol["trials"] if row["arm"] == "F")
        with self.assertRaises(ValueError):
            verifier.check_full_selection(protocol, public, c["trial_handle"])
        with self.assertRaises(ValueError):
            verifier.check_full_selection(protocol, public, model["trial_handle"], scripted=True)
        public["scope_policy"]["allowed_handles"].append(c["trial_handle"])
        with self.assertRaises(ValueError):
            verifier.check_full_selection(protocol, public, model["trial_handle"])

    def test_case_and_arm_rotation_must_be_independently_fixed(self):
        _, verifier = modules()
        for mutation in ("case", "arm", "gate", "trial_id"):
            with self.subTest(mutation=mutation):
                protocol = make_protocol()
                public = public_protocol(protocol)
                row = protocol["trials"][1]
                if mutation == "case": row["case_id"] = "refuse_source_hash"
                elif mutation == "arm": row["arm"] = "F"
                elif mutation == "gate": row["forced_publication_gate"] = True
                else: row["trial_id"] = protocol["trials"][0]["trial_id"]
                with self.assertRaises(ValueError):
                    verifier.check_full_selection(protocol, public, row["trial_handle"])

    def test_stage_specific_policy_rejects_old_tools_and_capacity_expansion(self):
        _, verifier = modules()
        protocol = make_protocol()
        public = public_protocol(protocol)
        handle = protocol["trials"][1]["trial_handle"]
        verifier.validate_policy(public["scope_policy"], handle)
        for key, value in (("qualified_action_tool", "mcp_dr_compare_v10_12345678_execute_case_action_v1"),
                           ("max_model_requests", 7), ("max_model_requests", 6.0),
                           ("max_wall_seconds", 121), ("max_action_calls", True)):
            with self.subTest(key=key, value=value):
                policy = copy.deepcopy(public["scope_policy"])
                policy[key] = value
                with self.assertRaises(ValueError): verifier.validate_policy(policy, handle)


class V11StageLedgerTests(unittest.TestCase):
    def stage(self, name="pilot"):
        prepare = importlib.import_module("tools.prepare_comparison_suite_v11")
        return prepare.build_stage_ledger(name, make_protocol(name), [
            {"freeze": {"path": "fixture-history"}, "unchanged": True}])

    def test_new_pilot_and_formal_budget_caps_count_only_model_trials(self):
        _, verifier = modules()
        for name, total, models, scripts in (("diagnostic", 14, 6, 3), ("pilot", 42, 6, 3), ("formal", 168, 24, 12)):
            with self.subTest(stage=name):
                stage = self.stage(name)
                before = copy.deepcopy(stage)
                self.assertIs(verifier.validate_stage_ledger(stage), stage)
                self.assertEqual(stage, before)
                self.assertEqual(stage["phase_model_budget"]["total_cap"], total)
                self.assertEqual(stage["planned_model_trial_count"], models)
                self.assertEqual(stage["planned_scripted_trial_count"], scripts)
                self.assertEqual(stage["planned_execution_count"], 2 if name == "diagnostic" else models + scripts)
                self.assertEqual(stage["selected_model_trial_count"], 2 if name == "diagnostic" else models)
                self.assertEqual(stage["selected_scripted_trial_count"], 0 if name == "diagnostic" else scripts)
                self.assertEqual(stage["scripted_model_cap"], 0)
                self.assertEqual(stage["phase_model_budget"]["request_slots_debited"], 0)
                self.assertEqual(stage["model_accounting"]["combined_per_trial_cap"], 7)
                self.assertEqual(stage["model_accounting"]["primary_wall_seconds"] +
                                 stage["model_accounting"]["native_title_and_export_reserve_seconds"], 120)

    def test_legacy_phase_cannot_fund_new_suite_or_claim_execution(self):
        _, verifier = modules()
        for path, value in ((["phase_model_budget", "total_cap"], 48),
                            (["phase_model_budget", "request_slots_debited"], 46),
                            (["phase_model_budget", "prior_closed_request_slots"], 34),
                            (["phase_model_budget", "phase_remaining_before_diagnostic"], 2),
                            (["model_calls_actual"], 1), (["new_detector_calls"], 1),
                            (["new_training_runs"], 1), (["gpu_seconds"], 1)):
            with self.subTest(path=path):
                stage = self.stage()
                target = stage
                for part in path[:-1]: target = target[part]
                target[path[-1]] = value
                with self.assertRaises(ValueError): verifier.validate_stage_ledger(stage)

    def test_budget_capacity_clocks_population_and_zero_counters_require_ints(self):
        _, verifier = modules()
        for section in ("phase_model_budget", "model_accounting"):
            sample = self.stage()
            for key, value in sample[section].items():
                if type(value) is not int: continue
                for invalid in (float(value), True, str(value), None):
                    with self.subTest(section=section, key=key, invalid=invalid):
                        stage = self.stage()
                        stage[section][key] = invalid
                        with self.assertRaises(ValueError): verifier.validate_stage_ledger(stage)
        for field in ("planned_trial_count", "planned_model_trial_count", "planned_scripted_trial_count",
                      "planned_execution_count", "selected_model_trial_count", "selected_scripted_trial_count",
                      "scripted_model_cap", "domain_invocations_per_trial", "model_calls_actual",
                      "new_detector_calls", "new_training_runs", "gpu_seconds"):
            stage = self.stage()
            stage[field] = float(stage[field])
            with self.subTest(field=field), self.assertRaises(ValueError):
                verifier.validate_stage_ledger(stage)

    def test_authorization_approval_and_deadline_cannot_be_expanded_or_reset(self):
        _, verifier = modules()
        for path, value in ((["authorization", "user_message"], "继续执行旧任务"),
                            (["authorization", "scope"], "two_branch_only"),
                            (["authorization", "new_stage_model_request_cap"], 49),
                            (["per_action_approval"], "Allow always"),
                            (["no_original_session_resume_or_deadline_reset"], False),
                            (["model_accounting", "primary_wall_seconds"], 120)):
            with self.subTest(path=path):
                stage = self.stage()
                target = stage
                for part in path[:-1]: target = target[part]
                target[path[-1]] = value
                with self.assertRaises(ValueError): verifier.validate_stage_ledger(stage)


class V11NativeTitleTests(unittest.TestCase):
    def test_six_primary_plus_one_title_closes_at_seven_actual_calls(self):
        _, verifier = modules()
        from test_comparison_model_verifier_v10 import fixture
        rows, run, arm = fixture(6)
        result = verifier.check_native_title(rows, run, arm)
        self.assertTrue(result["native_title_cost_known"])
        self.assertEqual(result["native_title_requests"], 1)

    def test_seventh_primary_plus_native_title_exceeds_total_seven(self):
        _, verifier = modules()
        from test_comparison_model_verifier_v10 import fixture
        rows, run, arm = fixture(7)
        with self.assertRaises(ValueError):
            verifier.check_native_title(rows, run, arm)

    def test_interrupted_missing_or_default_zero_usage_cannot_become_known_zero(self):
        _, verifier = modules()
        from test_comparison_model_verifier_v10 import fixture
        for mutation in ("interrupted", "missing", "zero", "unsafe"):
            with self.subTest(mutation=mutation):
                rows, run, arm = fixture()
                cost = next(row for row in rows if row["type"] == "cost/ledger" and row["data"]["purpose"] == "title")
                if mutation == "interrupted": cost["data"]["interrupted"] = True
                elif mutation == "missing": cost["data"]["tokens"].pop("output")
                elif mutation == "unsafe": cost["data"]["tokens"]["input"] = 9007199254740992
                else: cost["data"]["tokens"] = {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}
                with self.assertRaises(ValueError): verifier.check_native_title(rows, run, arm)


if __name__ == "__main__":
    unittest.main()
