import copy
from datetime import datetime, timezone
import json
import unittest
from tools.verify_comparison_model_v9 import (
    ROOT, UNKNOWN, check_ledger, check_budget, project_official,
    check_native_title, official_payload,
)


def fixture(request_count=1):
    begin = 1000000.0
    handle = 'cmp_' + 'a' * 32
    policy = {'schema_version': 1, 'workspace_root': str(ROOT/'outputs/comparison-pilot-v9/workspace'),
              'qualified_action_tool': 'mcp_dr_compare_v9_12345678_execute_case_action_v1',
              'allowed_handles': [handle], 'max_model_requests': 6, 'max_wall_seconds': 120, 'max_action_calls': 8}
    arm = {'started_epoch': begin / 1000, 'started_monotonic': 100,
           'deadline_epoch': (begin + 120000) / 1000, 'deadline_monotonic': 220}
    rows = []
    def add(kind, data, origin='system', trust='trusted'):
        index = len(rows) + 1
        row = {'seq': index, 'ts': datetime.fromtimestamp((begin+index)/1000, timezone.utc).isoformat().replace('+00:00','Z'),
               'type': kind, 'origin': origin, 'trust': trust, 'data': data}
        rows.append(row)
        return row
    add('session/start', {'key': 'session'})
    ready = add('x/plugin/test/scope-ready', {'mode': 'case-comparison-v1', 'session_key': 'session',
                'workspace_root': '<workspace>', 'policy': {**policy, 'workspace_root': '<workspace>'}}, 'ext:plugin/test','untrusted')
    sdk_ready = copy.deepcopy(ready)
    sdk_ready['data']['workspace_root'] = policy['workspace_root']
    sdk_ready['data']['policy'] = copy.deepcopy(policy)
    for index in range(1, request_count+1):
        add('x/plugin/test/scope-request-decision', {'session_key': 'session', 'allow': True,
            'request_index': index, 'trial_handle': handle, 'arm_sha256': 'b'*64,
            'started_epoch_ms': begin, 'deadline_epoch_ms': begin+120000}, 'ext:plugin/test', 'untrusted')
        add('request/sent', {'model': {'id':'agnes-3.0-flash','route':'account-defect-researcher'}, 'tool_schema_hash': 'c'*64})
        add('cost/ledger', {'purpose':'inference', 'model':'agnes-3.0-flash', 'tokens':{'input':1,'output':1}, 'response':{'status':200}})
    add('assistant/message', {'content':[{'type':'text','text':'未发布报告。'}]}, 'model')
    end = add('turn/end', {'reason':'completed', 'turn':1})
    title_request = add('x/host/session-title', {'status':'requested','turn':1,'route':'account-defect-researcher','model':'agnes-3.0-flash'})
    add('cost/ledger', {'purpose':'title','model':'agnes-3.0-flash','sourceTurn':1,'tokens':{'input':1,'output':1,'cacheRead':0,'cacheWrite':0}})
    title_terminal = add('x/host/session-title', {'status':'generated','turn':1,'title':'Fixture title'})
    run = {'trial_handle':handle, 'scope_ready':sdk_ready, 'session_id':'session', 'session_key':'session',
           'workspace_root':policy['workspace_root'], 'qualified_action_tool':policy['qualified_action_tool'],
           'started_epoch_ms':begin, 'deadline_epoch_ms':begin+120000, 'finished_epoch_ms':begin+100,
           'arm_sha256':'b'*64, 'model':'agnes-3.0-flash', 'route':'account-defect-researcher',
           'active_binding':{'schema_version':1,'owner':'comparison-model-runner-v1','trial_handle':handle,
                'session_key':'session','started_epoch_ms':begin,'deadline_epoch_ms':begin+120000,'arm_sha256':'b'*64},
           'model_request_count':request_count, 'model_requests_including_title':request_count+1, 'title_request_event':title_request, 'title_terminal_event':title_terminal,
           'calls':[], 'results':[], 'permissions':[], 'hook_events':[],
           'scope_request_events':[r for r in rows if r['type'].endswith('/scope-request-decision')],
           'request_events':[r for r in rows if r['type']=='request/sent'],
           'cost_events':[r for r in rows if r['type']=='cost/ledger'],
           'turn_end':end, 'final_texts':[r for r in rows if r['type']=='assistant/message'],
           'sdk_events':copy.deepcopy(rows)}
    run['sdk_events'][1] = sdk_ready
    return rows, run, arm


def geometry_payload(handle='cmp_' + 'a' * 32):
    return {
        'schema_version': 1, 'trial_handle': handle,
        'action': 'verify_input', 'status': 'executed',
        'evidence': {
            'evidence_id': handle + '_verify_input', 'action': 'verify_input',
            'execution_status': 'completed', 'semantic_status': 'failed',
            'summary': {
                'issue_count': 2, 'issues_by_code': {'yolo_geometry': 1},
                'max_errors': {'yolo': 0.009999999999999953,
                               'hbb_pixels': 0.0, 'corners_pixels': 0.0},
                'tolerances': {'yolo': 5.1e-09, 'pixels': 1e-08},
            },
        },
        'budget': {'domain_invocations_used': 1, 'model_requests_cap': 8},
    }


def masked_geometry_text(payload):
    observed = copy.deepcopy(payload)
    observed['evidence']['summary']['max_errors']['yolo'] = '__TEST_YOLO_MASK__'
    return json.dumps(observed).replace('"__TEST_YOLO_MASK__"', '0.[REDACTED:id]')


def masked_tool_fixture():
    """One official action, SDK result, Allow once, and separate owned receipt."""
    rows, run, arm = fixture()
    tool = run['qualified_action_tool']
    use_id = 't1-masked-geometry'
    args = {'trial_handle': run['trial_handle'], 'action': 'verify_input'}
    payload = geometry_payload(run['trial_handle'])
    call = {'type': 'tool/call', 'origin': 'model', 'trust': 'trusted',
            'data': {'name': tool, 'toolUseId': use_id, 'args': copy.deepcopy(args),
                     'resolvedPolicy': {'isReadOnly': False}}}
    gate = {'type': 'x/plugin/test/scope-decision', 'origin': 'ext:plugin/test',
            'trust': 'untrusted', 'data': {'session_key': run['session_id'],
            'name': tool, 'tool_use_id': use_id, 'allow': True,
            'trial_handle': run['trial_handle'], 'action_index': 1,
            'deadline_epoch_ms': run['deadline_epoch_ms']}}
    approval = {'type': 'approval/decided', 'origin': 'system', 'trust': 'trusted',
                'data': {'scope': 'tool:' + tool + ':execute', 'verdict': 'allowed-once'}}
    result = {'type': 'tool/result', 'origin': 'tool:' + tool, 'trust': 'untrusted',
              'data': {'toolUseId': use_id, 'isError': False,
                       'content': [{'type': 'text', 'text': masked_geometry_text(payload)}]}}
    rows[5:5] = [call, gate, approval, result]
    for index, row in enumerate(rows, 1):
        row['seq'] = index
        row['ts'] = datetime.fromtimestamp(
            (run['started_epoch_ms'] + index) / 1000, timezone.utc,
        ).isoformat().replace('+00:00', 'Z')
    result['sourceEventSeqs'] = [call['seq']]
    run['calls'] = [{'seq': call['seq'], 'origin': call['origin'], **copy.deepcopy(call['data'])}]
    run['results'] = [{'seq': result['seq'], 'tool_use_id': use_id,
                       'is_error': False, 'payload': copy.deepcopy(payload)}]
    run['permissions'] = [{'tool': tool, 'input': copy.deepcopy(args),
                           'tool_call_id': use_id, 'decision': 'allowed-once'}]
    run['hook_events'] = [copy.deepcopy(gate)]
    run['sdk_events'] = copy.deepcopy(rows)
    run['sdk_events'][1] = copy.deepcopy(run['scope_ready'])
    owned = [{'event': 'action_finished', 'record': {
        'action': 'verify_input', 'public_result': copy.deepcopy(payload),
    }}]
    return rows, run, arm, owned


class ModelLedgerTests(unittest.TestCase):
    def assert_failed(self, rows, run, arm):
        self.assertTrue(check_ledger(rows, run, arm)['errors'])

    def test_missing_publication_is_valid_observation_not_success(self):
        rows, run, arm = fixture()
        result = check_ledger(rows, run, arm, known_actions=[])
        self.assertFalse(result['errors'], result)
        self.assertFalse(result['publication_accepted'])

    def test_six_primary_requests_allowed_seventh_refused(self):
        rows, run, arm = fixture(6)
        self.assertFalse(check_ledger(rows, run, arm)['errors'])
        self.assert_failed(*fixture(7))

    def test_failed_provider_request_still_counted_when_actual_usage_known(self):
        rows, run, arm = fixture()
        run['cost_events'][0]['data']['response']['status'] = 500
        result = check_ledger(rows, run, arm)
        self.assertFalse(result['errors'], result)
        self.assertEqual(result['model_request_count'], 1)

    def test_missing_usage_is_unknown_cost_not_zero(self):
        rows, run, arm = fixture(); run['cost_events'][0]['data'].pop('tokens')
        self.assert_failed(rows, run, arm)

    def test_sequence_gap_refused(self):
        rows, run, arm = fixture(); rows[3]['seq'] += 1
        self.assert_failed(rows, run, arm)

    def test_extended_or_swapped_clock_refused(self):
        rows, run, arm = fixture(); run['deadline_epoch_ms'] += 1
        self.assert_failed(rows, run, arm)
        rows, run, arm = fixture(); run['active_binding']['session_key'] = 'foreign'
        self.assert_failed(rows, run, arm)

    def test_finalization_cannot_reset_original_deadline(self):
        rows, run, arm = fixture(); run['finished_epoch_ms'] = run['deadline_epoch_ms']
        self.assert_failed(rows, run, arm)

    def test_model_or_schema_change_refused(self):
        rows, run, arm = fixture(); rows[3]['data']['model']['id'] = 'other'
        self.assert_failed(rows, run, arm)
        rows, run, arm = fixture(2); rows[6]['data']['tool_schema_hash'] = 'd'*64
        self.assert_failed(rows, run, arm)

    def test_guard_attempt_cannot_replace_backend_anchor(self):
        rows, run, arm = fixture(); run['scope_request_events'][0]['data']['started_epoch_ms'] += 1
        self.assert_failed(rows, run, arm)

    def test_foreign_execution_without_scope_receipt_refused(self):
        rows, run, arm = fixture(); rows.insert(-1, {'seq':len(rows),'ts':rows[-1]['ts'],'type':'tool/call','origin':'model','trust':'trusted','data':{'name':'shell','toolUseId':'escape','args':{}}})
        rows[-1]['seq'] += 1
        self.assert_failed(rows, run, arm)

    def test_budget_open_unknown_reservation_and_late_known_cost_refused(self):
        arm = {'started_epoch':100,'started_monotonic':200,'deadline_epoch':220,'deadline_monotonic':320}
        opening = {'sequence':0,'event':'ledger_opened','record':{**arm,'current_epoch':100,'current_monotonic':200}}
        self.assertEqual(check_budget([opening],arm),0)
        reserve = {'sequence':1,'event':'action_reserved','record':{'action':'verify_input','reserved_cost':1,'current_epoch':101,'current_monotonic':201}}
        with self.assertRaises(ValueError):check_budget([opening,reserve],arm)

    def test_masks_never_restore_unknown_or_integer_claims(self):
        value={'budget':{'started_epoch':'__OFFICIAL_MASKED_NUMERIC_VALUE_UNKNOWN__'}}
        self.assertTrue(project_official(value, {'budget':{'started_epoch':1.25}}, [['budget','started_epoch']]))
        with self.assertRaises(ValueError):project_official(value, {'budget':{'started_epoch':1}}, [['budget','started_epoch']])

    def test_native_title_is_counted_beyond_primary_request_sent(self):
        rows, run, arm = fixture(6)
        result = check_ledger(rows, run, arm)
        self.assertFalse(result['errors'], result)
        self.assertEqual(result['actual_total_model_requests'], 7)
        self.assertEqual(result['native_title_requests'], 1)

    def test_native_title_unknown_usage_cannot_be_treated_as_zero(self):
        rows, run, arm = fixture()
        cost = next(r for r in rows if r['type']=='cost/ledger' and r['data']['purpose']=='title')
        cost['data']['interrupted']=True
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)
        cost['data'].pop('interrupted');cost['data']['tokens'].pop('output')
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)

    def test_native_title_cannot_extend_original_deadline_or_skip_receipt(self):
        rows, run, arm = fixture()
        run['title_terminal_event']['ts']=datetime.fromtimestamp(arm['deadline_epoch'],timezone.utc).isoformat()
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)
        rows, run, arm = fixture()
        rows=[r for r in rows if not(r['type']=='cost/ledger' and r['data']['purpose']=='title')]
        with self.assertRaises(ValueError):check_native_title(rows, run, arm)


class TitleFinalizationBoundaryTests(unittest.TestCase):
    def test_default_zero_usage_is_unknown_even_without_interrupted_flag(self):
        rows, run, arm = fixture()
        cost = next(row for row in rows if row['type'] == 'cost/ledger' and row['data']['purpose'] == 'title')
        cost['data']['tokens'] = {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0}
        with self.assertRaises(ValueError):
            check_native_title(rows, run, arm)

    def test_optional_reasoning_usage_remains_compatible_with_native_receipt(self):
        rows, run, arm = fixture()
        cost = next(row for row in rows if row['type'] == 'cost/ledger' and row['data']['purpose'] == 'title')
        cost['data']['tokens']['reasoning'] = 0
        self.assertTrue(check_native_title(rows, run, arm)['native_title_cost_known'])

    def test_unsafe_or_unknown_token_fields_cannot_close_title_usage(self):
        for changes in ({'input': 9007199254740992}, {'estimatedOutput': 1},
                        {'input': 0, 'output': 0, 'cacheRead': 4}):
            with self.subTest(changes=changes):
                rows, run, arm = fixture()
                cost = next(row for row in rows if row['type'] == 'cost/ledger' and row['data']['purpose'] == 'title')
                cost['data']['tokens'].update(changes)
                with self.assertRaises(ValueError):
                    check_native_title(rows, run, arm)

    def test_native_title_cannot_finish_after_runner_finalization(self):
        rows, run, arm = fixture()
        terminal = run['title_terminal_event']
        from tools.verify_comparison_model_v9 import event_ms
        run['finished_epoch_ms'] = event_ms(terminal) - 1
        with self.assertRaisesRegex(ValueError, 'finalization'):
            check_native_title(rows, run, arm)

class SelectedPolicyTests(unittest.TestCase):
    def test_two_selected_handles_are_accepted(self):
        from tools.verify_comparison_model_v9 import check_selected_policy
        _, run, _ = fixture()
        policy=run['scope_ready']['data']['policy']
        selection={'trial_handles':[run['trial_handle'],'cmp_'+'b'*32]}
        policy['allowed_handles']=list(selection['trial_handles'])
        check_selected_policy(policy,selection,run['trial_handle'])

    def test_full_six_model_population_is_rejected(self):
        from tools.verify_comparison_model_v9 import check_selected_policy
        _, run, _ = fixture()
        policy=run['scope_ready']['data']['policy']
        selection={'trial_handles':[run['trial_handle'],'cmp_'+'b'*32]}
        policy['allowed_handles']=selection['trial_handles']+['cmp_'+letter*32 for letter in 'cdef']
        with self.assertRaisesRegex(ValueError,'selected diagnostic'):
            check_selected_policy(policy,selection,run['trial_handle'])


class MaskedGeometryTests(unittest.TestCase):
    path = ['evidence', 'summary', 'max_errors', 'yolo']

    def test_exact_mask_is_unknown_and_does_not_mutate_either_payload(self):
        expected = geometry_payload()
        observed, masks = official_payload(masked_geometry_text(expected))
        expected_before, observed_before = copy.deepcopy(expected), copy.deepcopy(observed)
        self.assertEqual(masks, [self.path])
        self.assertTrue(project_official(observed, expected, masks))
        self.assertEqual(observed['evidence']['summary']['max_errors']['yolo'], UNKNOWN)
        self.assertEqual(expected, expected_before)
        self.assertEqual(observed, observed_before)

    def test_geometry_mask_requires_both_verify_input_actions(self):
        for location in ('payload', 'evidence'):
            for action in ('verify_copy', 'repair_copy', 'read_science', 'publish_report'):
                with self.subTest(location=location, action=action):
                    expected = geometry_payload()
                    (expected if location == 'payload' else expected['evidence'])['action'] = action
                    observed, masks = official_payload(masked_geometry_text(expected))
                    with self.assertRaisesRegex(ValueError, 'Unsupported or essential'):
                        project_official(observed, expected, masks)

    def test_geometry_mask_requires_nonnegative_finite_float(self):
        invalid = (0, True, '0.01', None, -0.01, float('nan'), float('inf'), -float('inf'))
        for number in invalid:
            with self.subTest(number=repr(number)):
                expected = geometry_payload()
                expected['evidence']['summary']['max_errors']['yolo'] = number
                observed = copy.deepcopy(expected)
                observed['evidence']['summary']['max_errors']['yolo'] = UNKNOWN
                with self.assertRaisesRegex(ValueError, 'Unsupported or essential'):
                    project_official(observed, expected, [self.path])
        for number in (0.0, 0.009999999999999953):
            with self.subTest(valid=number):
                expected = geometry_payload()
                expected['evidence']['summary']['max_errors']['yolo'] = number
                observed, masks = official_payload(masked_geometry_text(expected))
                self.assertTrue(project_official(observed, expected, masks))

    def test_mask_does_not_expand_to_neighbouring_numbers_or_report_claims(self):
        expected = geometry_payload()
        expected['report'] = {'claims': [{'field': 'summary.max_errors.yolo', 'value': 0.01}]}
        paths = (
            ['evidence', 'summary', 'max_errors', 'hbb_pixels'],
            ['evidence', 'summary', 'max_errors', 'corners_pixels'],
            ['evidence', 'summary', 'tolerances', 'yolo'],
            ['evidence', 'summary', 'issue_count'],
            ['evidence', 'summary', 'issues_by_code', 'yolo_geometry'],
            ['budget', 'model_requests_cap'],
            ['report', 'claims', 0, 'value'],
        )
        for path in paths:
            with self.subTest(path=path):
                observed = copy.deepcopy(expected)
                node = observed
                for key in path[:-1]:
                    node = node[key]
                node[path[-1]] = UNKNOWN
                with self.assertRaisesRegex(ValueError, 'Unsupported or essential'):
                    project_official(observed, expected, [path])

    def test_unmasked_fields_remain_exact(self):
        for location, key, value in (
            ('summary', 'issue_count', 1),
            ('evidence', 'semantic_status', 'passed'),
            ('budget', 'domain_invocations_used', 2),
        ):
            with self.subTest(location=location, key=key):
                expected = geometry_payload()
                observed, masks = official_payload(masked_geometry_text(expected))
                node = observed['evidence']['summary'] if location == 'summary' else observed[location]
                node[key] = value
                self.assertFalse(project_official(observed, expected, masks))

    def test_full_ledger_binds_masked_tool_chain_and_allow_once_to_owned_receipt(self):
        rows, run, arm, owned = masked_tool_fixture()
        result = check_ledger(rows, run, arm, known_actions=owned)
        self.assertFalse(result['errors'], result)
        self.assertTrue(result['checks']['actual_write_approvals_allow_once_bound_to_calls'])
        self.assertEqual(result['tool_call_count'], 1)
        self.assertEqual(result['approval_count'], 1)
        self.assertEqual(result['masked_numeric_paths_not_recovered'], [self.path])

    def test_changed_sdk_float_cannot_borrow_unchanged_owned_receipt(self):
        rows, run, arm, owned = masked_tool_fixture()
        original_receipt = copy.deepcopy(owned)
        self.assertFalse(check_ledger(rows, run, arm, known_actions=owned)['errors'])
        payload = run['results'][0]['payload']
        payload['evidence']['summary']['max_errors']['yolo'] = 0.02
        official = next(row for row in rows if row['type'] == 'tool/result')
        observed, masks = official_payload(official['data']['content'][0]['text'])
        self.assertTrue(project_official(observed, payload, masks))
        result = check_ledger(rows, run, arm, known_actions=owned)
        self.assertFalse(result['checks']['tool_calls_results_and_scope_verdicts_paired_no_foreign_execution'])
        self.assertEqual(result['errors'][0]['message'], 'SDK payload differs from owned action receipt')
        self.assertEqual(owned, original_receipt)


if __name__ == '__main__':
    unittest.main()
