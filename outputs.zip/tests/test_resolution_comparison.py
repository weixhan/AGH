"""Exercise freeze barriers, val isolation, failure publication, and saved inference."""
import copy
import json
from pathlib import Path
import struct
import unittest
from unittest.mock import patch

from defect_researcher import resolution_comparison as runner
from test_config import temporary_workspace
from test_geometry_verifier import geometry_configuration, write_json, digest
from test_repair_task_runtime import reseal
from defect_researcher.task_runtime import get_task_status


def configuration_for_comparison(root):
    configuration = geometry_configuration(root)
    dataset = Path(configuration["dataset_root"])
    raw = Path(configuration["raw_root"])
    header = b"\x89PNG\r\n\x1a\n" + struct.pack(">I", 13) + b"IHDR" + struct.pack(">II", 100, 100)
    for index, split in enumerate(("train", "val", "test"), 1):
        (raw / f"cable_{index}" / f"image_{index}.png").write_bytes(header)
        (dataset / "images" / split / f"image_{index}.png").write_bytes(header)
    (dataset / "data.yaml").write_text(f"path: {dataset.as_posix()}\ntrain: images/train\nval: images/val\ntest: images/test\n"
                                      "names:\n" + "".join(f"  {key - 1}: {name}\n" for key, name in runner.CATEGORIES.items()), encoding="utf-8")
    weights = Path(configuration["research_root"]) / "runs" / "yolo11n_640" / "weights" / "best.pt"
    weights.parent.mkdir(parents=True)
    weights.write_bytes(b"mocked detector checkpoint; inference is injected, never deserialized")
    configuration["weights_path"] = str(weights)
    manifest = json.loads((dataset / "manifest.json").read_text(encoding="utf-8"))
    training = {"status": "completed", "geometry_version": "hbb_v1", "data_root": str(dataset),
                "data_yaml": str(dataset / "data.yaml"), "data_yaml_sha256": digest(dataset / "data.yaml"),
                "dataset_manifest_sha256": digest(dataset / "manifest.json"), "dataset_manifest": manifest,
                "split_sha256": manifest["split_sha256"], "best_weights_sha256": digest(weights),
                "training_args": {"imgsz": 640, "data": str(dataset / "data.yaml")},
                "actual_training_args": {"imgsz": 640, "data": str(dataset / "data.yaml")}}
    write_json(weights.parent.parent / "experiment_manifest.json", training)
    return configuration


def small_protocol():
    # The public protocol remains hard-coded to 640 images. Isolated geometry
    # fixture has one val image; only this internal test hook changes that count.
    return {**runner._protocol(), "expected_images": 1}


def injected_inference(records, weights, imgsz, protocol, directory):
    observed = [{**copy.deepcopy(record), "eval_imgsz": imgsz, "device": "0", "precision": "FP32",
                 "elapsed_seconds": 0.01, "ultralytics_speed_ms": {"preprocess": 0, "inference": 0, "postprocess": 0},
                 "predictions": [{"class_id": 0, "xyxy": [10.0, 10.0, 20.0, 20.0], "confidence": 0.5}]}
                for record in records]
    return observed, {"device": "0", "precision": "FP32", "gpu_name": "mocked", "warmup_images": 1,
                      "tf32_matmul": False, "tf32_cudnn": False}


class ResolutionComparisonTests(unittest.TestCase):
    def test_frozen_public_protocol_is_validation_only(self):
        protocol = runner._protocol()
        self.assertEqual(protocol["expected_images"], 640)
        self.assertEqual(protocol["split"], "val")
        self.assertEqual(protocol["eval_imgsz"], [640, 960])
        self.assertFalse(protocol["test_inference"])
        changed = {**protocol, "split": "test"}
        with patch.object(runner, "_json", return_value=changed), self.assertRaisesRegex(ValueError, "split"):
            runner._protocol()

    def test_completed_artifacts_hashes_predictions_gate_and_inputs(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            before = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
            protocol = small_protocol()
            with patch.object(runner, "_protocol", return_value=protocol), patch.object(runner, "_infer", side_effect=injected_inference) as infer, patch.object(runner, "_write", wraps=runner._write) as writes:
                result = runner.run_comparison(configuration, "paired")
            self.assertEqual(result["status"], "completed", result["errors"])
            self.assertEqual(result["summary"]["comparison_status"], "passed")
            self.assertTrue(result["summary"]["input_hashes_unchanged"])
            self.assertEqual(result["summary"]["val_images"], 1)
            self.assertEqual(infer.call_count, 2)
            self.assertEqual([call.args[2] for call in infer.call_args_list], [640, 960])
            self.assertEqual(writes.call_args_list[-1].args[0].name, "completion.json")
            directory = Path(configuration["output_root"]) / "paired"
            completion, manifest = [json.loads((directory / name).read_text(encoding="utf-8")) for name in ("completion.json", "artifact_manifest.json")]
            self.assertEqual(digest(directory / "artifact_manifest.json"), completion["artifact_manifest_sha256"])
            self.assertEqual({r["name"] for r in manifest["files"]}, set(runner.FILES.values()) - {"completion.json", "artifact_manifest.json"})
            for record in manifest["files"]:
                self.assertEqual(digest(Path(record["path"])), record["sha256"])
                self.assertEqual(Path(record["path"]).stat().st_size, record["size_bytes"])
            self.assertTrue((directory / "geometry_gate" / "gate" / "completion.json").is_file())
            inputs = json.loads((directory / "inputs.json").read_text(encoding="utf-8"))
            self.assertTrue(inputs["all_unchanged"])
            self.assertTrue(all(r["sha256_before"] == r["sha256_after"] for r in inputs["files"]))
            roles = {r["role"] for r in inputs["files"]}
            self.assertTrue({"weights", "training_manifest", "comparison_protocol", "comparison_runner", "detection_metrics"} <= roles)
            self.assertFalse(any(role.startswith("images/test/") for role in roles))
            for imgsz in (640, 960):
                saved = [json.loads(line) for line in (directory / f"predictions_{imgsz}.jsonl").read_text(encoding="utf-8").splitlines()]
                self.assertEqual([r["image_id"] for r in saved], ["image_2"])
                self.assertEqual(saved[0]["split"], "val")
                self.assertEqual(saved[0]["predictions"][0]["xyxy"], [10.0, 10.0, 20.0, 20.0])
            for path, content in before.items():
                self.assertEqual(path.read_bytes(), content)

    def test_weight_change_between_groups_fails_without_completion(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            def change_weight(*args):
                result = injected_inference(*args)
                Path(configuration["weights_path"]).write_bytes(b"changed by simulated external process")
                return result
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer", side_effect=change_weight) as infer:
                result = runner.run_comparison(configuration, "changed")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(infer.call_count, 1)
            self.assertIn("Frozen input", result["errors"][0]["message"])
            directory = Path(configuration["output_root"]) / "changed"
            self.assertFalse((directory / "completion.json").exists())
            self.assertTrue((directory / "failure.json").exists())

    def test_inference_failure_never_publishes_completed_result(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer", side_effect=RuntimeError("CUDA out of memory")):
                result = runner.run_comparison(configuration, "oom")
            self.assertEqual(result["status"], "failed")
            directory = Path(configuration["output_root"]) / "oom"
            self.assertFalse((directory / "completion.json").exists())
            self.assertFalse((directory / "comparison_result.json").exists())
            self.assertEqual(result["errors"][0]["stage"], "inference_640")

    def test_geometry_failure_blocks_all_inference(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            (Path(configuration["dataset_root"]) / "labels" / "val" / "image_2.txt").write_text("0 0.5 0.5 0.1 0.1", encoding="utf-8")
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer") as infer:
                result = runner.run_comparison(configuration, "bad-geometry")
            # Counts and geometry provenance are both barriers; neither permits inference.
            self.assertEqual(result["status"], "failed")
            infer.assert_not_called()
            self.assertFalse((Path(configuration["output_root"]) / "bad-geometry" / "completion.json").exists())

    def test_training_hash_or_training_resolution_mismatch_refused(self):
        for field, value in (("best_weights_sha256", "0" * 64), ("data_yaml_sha256", "1" * 64), ("dataset_manifest_sha256", "2" * 64),
                             ("training_args", {"imgsz": 960, "data": "irrelevant"}), ("actual_training_args", {"imgsz": 960, "data": "irrelevant"})):
            with self.subTest(field=field), temporary_workspace() as root:
                configuration = configuration_for_comparison(root)
                path = Path(configuration["weights_path"]).parent.parent / "experiment_manifest.json"
                manifest = json.loads(path.read_text(encoding="utf-8"))
                manifest[field] = value
                write_json(path, manifest)
                with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer") as infer:
                    result = runner.run_comparison(configuration)
                self.assertEqual(result["status"], "failed")
                infer.assert_not_called()

    def test_validation_overlap_with_test_is_rejected_even_if_declared_hash_updated(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            splits, dataset = Path(configuration["split_dir"]), Path(configuration["dataset_root"])
            (splits / "test.txt").write_bytes((splits / "val.txt").read_bytes())
            manifest = json.loads((dataset / "manifest.json").read_text(encoding="utf-8"))
            manifest["split_sha256"]["test.txt"] = digest(splits / "test.txt")
            write_json(dataset / "manifest.json", manifest)
            training_path = Path(configuration["weights_path"]).parent.parent / "experiment_manifest.json"
            training = json.loads(training_path.read_text(encoding="utf-8"))
            training.update(dataset_manifest=manifest, split_sha256=manifest["split_sha256"], dataset_manifest_sha256=digest(dataset / "manifest.json"))
            write_json(training_path, training)
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer") as infer:
                result = runner.run_comparison(configuration, "overlap")
            self.assertEqual(result["status"], "failed")
            self.assertIn("overlaps test", result["errors"][0]["message"])
            infer.assert_not_called()

    def test_prediction_missing_image_changed_gt_and_nonfinite_rejected(self):
        for mutation in (lambda rows: rows.clear(), lambda rows: rows[0].update(image_id="test-image"),
                         lambda rows: rows[0].update(ground_truth=[{"class_id": 1, "xyxy": [0, 0, 1, 1]}]),
                         lambda rows: rows[0]["predictions"][0].update(confidence=float("nan"))):
            with self.subTest(mutation=mutation), temporary_workspace() as root:
                configuration = configuration_for_comparison(root)
                def bad_predictions(*args):
                    rows, environment = injected_inference(*args)
                    mutation(rows)
                    return rows, environment
                with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer", side_effect=bad_predictions):
                    result = runner.run_comparison(configuration, "invalid")
                self.assertEqual(result["status"], "failed")
                self.assertFalse((Path(configuration["output_root"]) / "invalid" / "completion.json").exists())

    def test_existing_task_is_never_overwritten(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            directory = Path(configuration["output_root"]) / "exists"
            directory.mkdir(parents=True)
            marker = directory / "completion.json"
            marker.write_bytes(b"existing unrelated completion")
            result = runner.run_comparison(configuration, "exists")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(marker.read_bytes(), b"existing unrelated completion")
            self.assertFalse((directory / "failure.json").exists())

    def test_runtime_accepts_actual_geometry_chain_and_rejects_damaged_predictions(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer", side_effect=injected_inference):
                result = runner.run_comparison(configuration, "saved")
                self.assertEqual(result["status"], "completed", result["errors"])
                verified = get_task_status(configuration, "saved")
                self.assertEqual(verified["status"], "completed", verified.get("errors"))
                predictions = Path(configuration["output_root"]) / "saved" / "predictions_640.jsonl"
                predictions.write_text("{}\n", encoding="utf-8")
                damaged = get_task_status(configuration, "saved")
                self.assertEqual(damaged["status"], "failed")
                self.assertIn("hash/size", damaged["errors"][0]["message"])

    def test_runtime_rejects_resealed_false_metric_summary(self):
        with temporary_workspace() as root:
            configuration = configuration_for_comparison(root)
            with patch.object(runner, "_protocol", return_value=small_protocol()), patch.object(runner, "_infer", side_effect=injected_inference):
                result = runner.run_comparison(configuration, "sealed-lie")
                self.assertEqual(result["status"], "completed", result["errors"])
                directory = Path(configuration["output_root"]) / "sealed-lie"
                saved_result = json.loads((directory / "comparison_result.json").read_text(encoding="utf-8"))
                saved_result["summary"]["metrics"]["960"]["mAP50"] = 0.999
                write_json(directory / "comparison_result.json", saved_result)
                reseal(directory)
                damaged = get_task_status(configuration, "sealed-lie")
                self.assertEqual(damaged["status"], "failed")
                self.assertIn("summary differs from saved metrics", damaged["errors"][0]["message"])


if __name__ == "__main__":
    unittest.main()
