"""Independent hand-specified business oracles; no detector or production imports."""
from __future__ import annotations

from copy import deepcopy
import ast
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import unittest
import uuid

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("independent_business", ROOT / "tools" / "verify_sliced_business_recovery.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)


def pred(box=(0., 0., 10., 10.), confidence=.5, class_id=0):
    return {"class_id": class_id, "confidence": confidence, "xyxy": list(box)}


def observation(pass_id, predictions):
    crop = reviewer.crops()[pass_id]
    return {"pass_id": pass_id, "crop": crop, "local_predictions": predictions,
            "global_predictions": reviewer.map_predictions(predictions, crop, pass_id)}


def oracle_hash(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(raw).hexdigest()


def seal_shared(directory, records):
    previous = "0"*64
    for sequence, row in enumerate(records, 1):
        row.update(event_seq=sequence, previous_event_sha256=previous)
        row["event_sha256"] = oracle_hash({k: v for k, v in row.items() if k != "event_sha256"})
        previous = row["event_sha256"]
    raw = b"".join(json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()+b"\n" for row in records)
    (directory / "shared_journal.jsonl").write_bytes(raw)


@contextmanager
def scratch():
    directory = ROOT / "outputs" / ("business-verifier-unit-"+uuid.uuid4().hex)
    directory.mkdir()
    try:
        yield directory
    finally:
        if directory.resolve().parent != (ROOT / "outputs").resolve() or not directory.name.startswith("business-verifier-unit-"):
            raise ValueError("Unsafe unit scratch cleanup")
        shutil.rmtree(directory)


def shared_fixture(directory):
    """Hand-specified 39-call oracle, independent of every production writer."""
    start = datetime(2026, 10, 12, 2, tzinfo=timezone.utc).timestamp()
    coordinator = {"start_epoch": start, "deadline_epoch": start+300}
    identity = {"experiment_id": "manual", "protocol_sha256": "a"*64,
        "input_manifest_sha256": "b"*64, "execution_source_sha256": "c"*64}
    schedule = [("control", "warmup", reviewer.IMAGES[0], 0, 1)]
    schedule += [("control", "formal", reviewer.IMAGES[i//9], i%9, i+1) for i in range(18)]
    schedule += [("fault", "warmup", reviewer.IMAGES[0], 0, 1)]
    schedule += [("fault", "formal", reviewer.IMAGES[0], i, i+1) for i in range(3)]
    schedule += [("resume", "formal", reviewer.IMAGES[i//9], i%9, i+2) for i in range(2, 18)]
    budgets = {arm: {"formal_attempts": [], "warmup_attempts": [], "gpu_seconds": 0.} for arm in ("control", "fault", "resume")}
    records = []
    for shared_index, (arm, kind, image_id, pass_id, call_index) in enumerate(schedule, 1):
        if arm == "resume" and not budgets["resume"]["formal_attempts"]:
            budgets["resume"] = deepcopy(budgets["fault"])
        t = start+shared_index*.02
        status = "failed" if (arm, kind, pass_id) == ("fault", "formal", 2) else "passed"
        attempt = {"call_index": call_index, "image_id": image_id, "pass_id": pass_id,
            "status": status, "utc_started": datetime.fromtimestamp(t+.001, timezone.utc).isoformat(),
            "utc_finished": datetime.fromtimestamp(t+.006, timezone.utc).isoformat(),
            "elapsed_seconds": .005, "gpu_seconds": .001}
        if status == "failed":
            attempt["error"] = {"type": "InjectedBusinessFault", "message": "manual known cost"}
        budgets[arm][kind+"_attempts"].append(attempt)
        budgets[arm]["gpu_seconds"] += .001
        payload = {"shared_call_index": shared_index, "arm": arm, "kind": kind,
            "image_id": image_id, "pass_id": pass_id, "local_call_index": call_index,
            "utc_epoch": t, "elapsed_seconds": shared_index*.02, **identity}
        records.append({"schema_version": 1, "event_type": "started", "payload": payload})
        records.append({"schema_version": 1, "event_type": "finished",
            "payload": {**payload, "utc_epoch": t+.01, "elapsed_seconds": shared_index*.02+.01, "attempt": deepcopy(attempt)}})
    seal_shared(directory, records)
    return coordinator, budgets, identity, records


class PureBusinessVerifierTests(unittest.TestCase):
    def test_verifier_does_not_import_production_or_detector(self):
        source = (ROOT / "tools" / "verify_sliced_business_recovery.py").read_text(encoding="utf-8")
        for node in ast.walk(ast.parse(source)):
            if isinstance(node, ast.Import):
                imports = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                imports = [node.module or ""]
            else:
                continue
            self.assertFalse(any(name.startswith(("defect_researcher", "torch", "ultralytics")) for name in imports))

    def test_duplicate_json_rejected(self):
        with self.assertRaises(reviewer.BusinessVerificationError):
            reviewer.decode('{"nms":null,"nms":false}')

    def test_nonfinite_json_rejected(self):
        for value in ("NaN", "Infinity", "-Infinity"):
            with self.subTest(value=value), self.assertRaises(reviewer.BusinessVerificationError):
                reviewer.decode('{"v":'+value+'}')

    def test_explicit_null_only_nms(self):
        self.assertTrue(reviewer.options_valid(deepcopy(reviewer.OPTIONS)))
        for value in (False, True, "None", 0):
            row = {**reviewer.OPTIONS, "nms": value}
            with self.subTest(value=value):
                self.assertFalse(reviewer.options_valid(row))
        row = deepcopy(reviewer.OPTIONS)
        del row["nms"]
        self.assertFalse(reviewer.options_valid(row))

    def test_boolean_cannot_replace_typed_inference_number(self):
        self.assertFalse(reviewer.options_valid({**reviewer.OPTIONS, "batch": True}))
        self.assertFalse(reviewer.options_valid({**reviewer.OPTIONS, "imgsz": 640.}))

    def test_fixed_nine_crops_have_correct_order(self):
        self.assertEqual(reviewer.crops(), [[0, 0, 1920, 1080], [0, 0, 640, 640],
            [512, 0, 1152, 640], [1024, 0, 1664, 640], [1280, 0, 1920, 640],
            [0, 440, 640, 1080], [512, 440, 1152, 1080], [1024, 440, 1664, 1080],
            [1280, 440, 1920, 1080]])

    def test_coordinate_translation_preserves_complete_list(self):
        result = reviewer.map_predictions([pred((1., 2., 3., 4.)), pred((5., 6., 7., 8.), .2, 6)], reviewer.crops()[8], 8)
        self.assertEqual(result[0]["xyxy"], [1281., 442., 1283., 444.])
        self.assertEqual(result[1]["xyxy"], [1285., 446., 1287., 448.])
        self.assertEqual([r["prediction_index"] for r in result], [0, 1])

    def test_wrong_crop_and_boolean_pass_refused(self):
        for crop, pass_id in (([0, 0, 640, 640], 2), (reviewer.crops()[1], True)):
            with self.subTest(pass_id=pass_id), self.assertRaises(reviewer.BusinessVerificationError):
                reviewer.map_predictions([], crop, pass_id)

    def test_invalid_prediction_is_not_silently_dropped(self):
        invalid = [pred((0., 0., 0., 10.)), pred((-1., 0., 10., 10.)), pred((0., 0., 641., 10.)),
            pred(confidence=.0009), pred(confidence=float("nan")), pred(class_id=True), pred(class_id=7)]
        for row in invalid:
            with self.subTest(row=row), self.assertRaises(reviewer.BusinessVerificationError):
                reviewer.map_predictions([pred(), row], reviewer.crops()[1], 1)

    def test_over_300_backend_predictions_refused(self):
        with self.assertRaises(reviewer.BusinessVerificationError):
            reviewer.map_predictions([pred() for _ in range(301)], reviewer.crops()[0], 0)

    def test_zero_predictions_has_explicit_empty_trace(self):
        predictions, trace = reviewer.fusion_trace([observation(0, [])])
        self.assertEqual(predictions, [])
        self.assertEqual(trace["rows"], [])
        self.assertEqual(trace["candidate_count"], 0)

    def test_iou_point7_is_kept(self):
        a, b = pred((0., 0., 17., 10.)), pred((3., 0., 20., 10.))
        self.assertEqual(reviewer.iou(a["xyxy"], b["xyxy"]), .7)
        predictions, trace = reviewer.fusion_trace([observation(0, [a, b])])
        self.assertEqual(len(predictions), 2)
        self.assertEqual([row["status"] for row in trace["rows"]], ["kept", "kept"])

    def test_iou_above_point7_is_suppressed(self):
        a, b = pred((0., 0., 17., 10.)), pred((2.99, 0., 19.99, 10.))
        predictions, trace = reviewer.fusion_trace([observation(0, [a, b])])
        self.assertEqual(len(predictions), 1)
        self.assertEqual(trace["rows"][1]["status"], "suppressed_iou")
        self.assertEqual(trace["rows"][1]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})
        self.assertGreater(trace["rows"][1]["suppression_iou"], .7)

    def test_different_classes_never_suppress(self):
        predictions, trace = reviewer.fusion_trace([observation(0, [pred(class_id=0), pred(class_id=1)])])
        self.assertEqual(len(predictions), 2)
        self.assertEqual(trace["suppressed_count"], 0)

    def test_ties_prefer_pass_then_original_index(self):
        rows = [observation(1, [pred()]), observation(0, [pred(), pred(class_id=1)])]
        predictions, trace = reviewer.fusion_trace(rows)
        self.assertEqual([r["pass_id"] for r in trace["rows"]], [0, 0, 1])
        self.assertEqual([r["prediction_index"] for r in trace["rows"]], [0, 1, 0])
        self.assertEqual(len(predictions), 2)
        self.assertEqual(trace["rows"][-1]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})

    def test_unmapped_coordinates_refused(self):
        row = observation(2, [pred()])
        row["global_predictions"][0]["xyxy"][0] += 1.
        with self.assertRaises(reviewer.BusinessVerificationError):
            reviewer.fusion_trace([row])

    def test_duplicate_candidate_refused(self):
        row = observation(1, [pred()])
        with self.assertRaises(reviewer.BusinessVerificationError):
            reviewer.fusion_trace([row, deepcopy(row)])

    def test_all_nms_runs_before_global_truncation(self):
        # 300 disjoint candidates from pass0 then one new survivor at rank300,
        # then a lower confidence duplicate of that discarded survivor. The
        # latter is still NMS-suppressed rather than incorrectly cap-discarded.
        local = [pred((float(i*5), 0., float(i*5+1), 1.), .9) for i in range(300)]
        tail = [pred((1., 10., 2., 11.), .8), pred((1., 10., 2., 11.), .7)]
        predictions, trace = reviewer.fusion_trace([observation(0, local), observation(1, tail)])
        self.assertEqual(len(predictions), 300)
        self.assertEqual(trace["nms_survivor_count"], 301)
        self.assertEqual(trace["global_max_det_discarded_count"], 1)
        self.assertEqual([r["status"] for r in trace["rows"][-2:]], ["global_max_det", "suppressed_iou"])
        self.assertEqual(trace["rows"][-1]["suppressed_by"], {"pass_id": 1, "prediction_index": 0})

    def test_confidence_within_frozen_absolute_tolerance(self):
        self.assertTrue(reviewer.predictions_equal([pred()], [pred(confidence=.5+.9e-6)]))
        self.assertFalse(reviewer.predictions_equal([pred()], [pred(confidence=.5+1.1e-6)]))

    def test_coords_within_frozen_absolute_tolerance(self):
        self.assertTrue(reviewer.predictions_equal([pred()], [pred((.9e-4, 0., 10., 10.))]))
        self.assertFalse(reviewer.predictions_equal([pred()], [pred((1.1e-4, 0., 10., 10.))]))

    def test_large_coordinates_do_not_enable_relative_tolerance(self):
        a, b = pred((1000., 0., 1010., 10.)), pred((1000.001, 0., 1010., 10.))
        self.assertFalse(reviewer.predictions_equal([a], [b]))

    def test_counts_order_class_and_nonfinite_preserved(self):
        a, b = pred(class_id=0), pred(class_id=1)
        self.assertFalse(reviewer.predictions_equal([a], []))
        self.assertFalse(reviewer.predictions_equal([a, b], [b, a]))
        self.assertFalse(reviewer.predictions_equal([a], [pred(class_id=True)]))
        self.assertFalse(reviewer.predictions_equal([a], [pred(confidence=float("inf"))]))


class SharedBusinessVerifierTests(unittest.TestCase):
    def test_hand_specified_39_call_closed_cost_oracle(self):
        with scratch() as directory:
            coordinator, budgets, identity, _ = shared_fixture(directory)
            result = reviewer.verify_shared(directory, coordinator, budgets, identity)
            self.assertEqual(result["detector_calls"], 39)
            self.assertEqual(result["formal_calls"], 37)
            self.assertEqual(result["warmup_calls"], 2)
            self.assertAlmostEqual(result["gpu_seconds"], .039)
            self.assertEqual(result["callmap"][22]["status"], "failed")
            self.assertEqual(result["callmap"][23]["local_call_index"], 4)

    def reject_mutation(self, mutate, pattern=None):
        with scratch() as directory:
            coordinator, budgets, identity, records = shared_fixture(directory)
            mutate(coordinator, budgets, identity, records)
            seal_shared(directory, records)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, pattern or ".*"):
                reviewer.verify_shared(directory, coordinator, budgets, identity)

    def test_extra_outer_predict_is_refused_even_below_cap40(self):
        self.reject_mutation(lambda c, b, i, r: r.extend(deepcopy(r[-2:])), "39")

    def test_open_shared_call_is_refused(self):
        self.reject_mutation(lambda c, b, i, r: r.pop(), "39")

    def test_wrong_cached_pass_reprediction_is_refused_when_resealed(self):
        self.reject_mutation(lambda c, b, i, r: r[46]["payload"].update(pass_id=0), "population")

    def test_hidden_extra_explicit_resume_warmup_is_refused(self):
        self.reject_mutation(lambda c, b, i, r: r[46]["payload"].update(kind="warmup"), "population")

    def test_changed_source_identity_is_refused_when_resealed(self):
        self.reject_mutation(lambda c, b, i, r: r[4]["payload"].update(execution_source_sha256="d"*64), "identity")

    def test_unknown_failed_gpu_cost_is_refused(self):
        def mutate(c, b, i, r):
            r[45]["payload"]["attempt"]["gpu_seconds"] = None
            b["fault"]["formal_attempts"][-1]["gpu_seconds"] = None
        self.reject_mutation(mutate, "unknown")

    def test_shared_cost_cannot_be_substituted_for_replayed_cost(self):
        self.reject_mutation(lambda c, b, i, r: r[45]["payload"]["attempt"].update(gpu_seconds=0.), "closed cost")

    def test_shared_deadline_is_never_reset_for_resume(self):
        self.reject_mutation(lambda c, b, i, r: r[46]["payload"].update(elapsed_seconds=301.), "wall")

    def test_cross_arm_cumulative_gpu_total_has_no_fresh_budget(self):
        self.reject_mutation(lambda c, b, i, r: b["resume"].update(gpu_seconds=.016), "both cumulative")

    def test_schema_boolean_cannot_replace_version_one(self):
        self.reject_mutation(lambda c, b, i, r: r[0].update(schema_version=True), "sequence")

    def test_coordinator_monotonic_cost_cannot_decrease(self):
        self.reject_mutation(lambda c, b, i, r: r[10]["payload"].update(elapsed_seconds=0.), "wall")

    def test_prepublication_review_refuses_unbound_directory(self):
        with scratch() as directory:
            result = reviewer.review(directory)
            self.assertEqual(result["status"], "failed")
            self.assertIs(result["checks"]["all_required_independent_evidence_checks_completed"], False)
            self.assertEqual(result["evidence"], {})


class MonotonicBusinessVerifierTests(unittest.TestCase):
    def budget(self):
        return {"task_wall_seconds": 5., "inference_wall_seconds": 3., "wall_segments": [
            {"utc_started": "2026-10-12T02:00:00+00:00", "utc_finished": "2026-10-12T02:00:02+00:00",
             "task_wall_seconds_before": 1., "inference_wall_seconds_before": 0.,
             "monotonic_task_seconds": 2., "monotonic_inference_seconds": 1.},
            {"utc_started": "2026-10-12T02:00:03+00:00", "utc_finished": "2026-10-12T02:00:04+00:00",
             "task_wall_seconds_before": 4., "inference_wall_seconds_before": 2.,
             "monotonic_task_seconds": 1., "monotonic_inference_seconds": 1.}]}

    def test_closed_original_and_resume_segments_preserve_cumulative_cost(self):
        self.assertTrue(reviewer.monotonic_segments_valid(self.budget(), 2))

    def test_resumed_task_segment_cannot_reset_prior_cost(self):
        budget = self.budget()
        budget["wall_segments"][1]["task_wall_seconds_before"] = 0.
        with self.assertRaisesRegex(reviewer.BusinessVerificationError, "reset"):
            reviewer.monotonic_segments_valid(budget, 2)

    def test_unfinished_monotonic_segment_refused(self):
        budget = self.budget()
        budget["wall_segments"][1]["utc_finished"] = None
        with self.assertRaises((reviewer.BusinessVerificationError, TypeError)):
            reviewer.monotonic_segments_valid(budget, 2)

    def test_unknown_monotonic_inference_cost_refused(self):
        budget = self.budget()
        budget["wall_segments"][1]["monotonic_inference_seconds"] = None
        with self.assertRaisesRegex(reviewer.BusinessVerificationError, "unknown"):
            reviewer.monotonic_segments_valid(budget, 2)

    def test_final_aggregate_cannot_hide_monotonic_cost(self):
        budget = self.budget()
        budget["task_wall_seconds"] = 3.
        with self.assertRaisesRegex(reviewer.BusinessVerificationError, "hides"):
            reviewer.monotonic_segments_valid(budget, 2)


class SavedBusinessArtifactTests(unittest.TestCase):
    """Copies of the explicitly labelled fake integration acceptance.

    These test evidence rejection only. They do not call a runner or re-label
    simulated detector records as actual GPU work. Each helper's baseline is
    accepted before a mutation, so a pathname mismatch cannot pass a negative.
    """
    FIXTURE = ROOT / "outputs/sliced-business-v1-engineering-ee4518441832"

    def setUp(self):
        if not self.FIXTURE.is_dir():
            self.skipTest("Saved fake engineering fixture is unavailable")
        self.assertIs(reviewer.read(self.FIXTURE / "coordinator.json")["real_detector_used"], False)

    def write(self, path, value):
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")

    @contextmanager
    def copied(self):
        with scratch() as parent:
            directory = parent / self.FIXTURE.name
            shutil.copytree(self.FIXTURE, directory)
            yield directory

    def fault_args(self, directory):
        protocol = reviewer.read(directory / "protocol.json")
        fault = reviewer.read(directory / "fault/fault.json")
        identity = {k: fault[k] for k in ("protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256")}
        budget = reviewer.read(directory / "fault/budget.json")
        return directory / "fault", protocol, identity, directory.name, budget

    def test_saved_returned_prediction_tamper_is_refused(self):
        with self.copied() as directory:
            self.assertEqual(reviewer.fault_valid(*self.fault_args(directory))["pass_id"], 2)
            path = directory / "fault/fault.json"
            row = reviewer.read(path)
            row["prediction_output"]["local_predictions"][0]["confidence"] += .01
            self.write(path, row)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "hash"):
                reviewer.fault_valid(*self.fault_args(directory))

    def test_saved_fault_unknown_gpu_refused_even_when_output_hash_valid(self):
        with self.copied() as directory:
            reviewer.fault_valid(*self.fault_args(directory))
            path = directory / "fault/fault.json"
            row = reviewer.read(path)
            row["timing"]["gpu_seconds"] = None
            self.write(path, row)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "closed"):
                reviewer.fault_valid(*self.fault_args(directory))

    def test_saved_fault_rule_cannot_change_after_known_prediction(self):
        with self.copied() as directory:
            reviewer.fault_valid(*self.fault_args(directory))
            path = directory / "fault/fault.json"
            row = reviewer.read(path)
            row["boundary"] = "after_successful_checkpoint"
            self.write(path, row)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "rule"):
                reviewer.fault_valid(*self.fault_args(directory))

    def test_saved_complete_fusion_trace_tamper_is_refused(self):
        with self.copied() as directory:
            registration = reviewer.read(directory / "input_manifest.json")
            observations = reviewer.lines(directory / "control/pass_observations.jsonl")
            reviewer.arm_fusion(directory / "control", observations, registration)
            path = directory / "control/fusion_details.jsonl"
            rows = reviewer.lines(path)
            rows[0]["trace"]["rows"][0]["candidate_rank"] = 1
            path.write_text("".join(json.dumps(row, ensure_ascii=False)+"\n" for row in rows), encoding="utf-8")
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "trace"):
                reviewer.arm_fusion(directory / "control", observations, registration)

    def test_saved_fused_prediction_tamper_is_refused(self):
        with self.copied() as directory:
            registration = reviewer.read(directory / "input_manifest.json")
            observations = reviewer.lines(directory / "control/pass_observations.jsonl")
            reviewer.arm_fusion(directory / "control", observations, registration)
            path = directory / "control/predictions_sliced.jsonl"
            rows = reviewer.lines(path)
            rows[0]["predictions"][0]["class_id"] = 3
            path.write_text("".join(json.dumps(row, ensure_ascii=False)+"\n" for row in rows), encoding="utf-8")
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "predictions"):
                reviewer.arm_fusion(directory / "control", observations, registration)

    def test_publication_saved_file_mutation_refused(self):
        with self.copied() as directory:
            self.assertTrue(reviewer.publication_valid(directory))
            path = directory / "resume/checkpoints/0000-2.json"
            path.write_bytes(path.read_bytes()+b" ")
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "bytes"):
                reviewer.publication_valid(directory)

    def test_publication_uninventoried_extra_file_refused(self):
        with self.copied() as directory:
            self.assertTrue(reviewer.publication_valid(directory))
            (directory / "hidden_extra_predict.json").write_text("{}\n", encoding="utf-8")
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "inventory"):
                reviewer.publication_valid(directory)

    def test_completion_cannot_promote_simulated_mode_to_real(self):
        with self.copied() as directory:
            self.assertTrue(reviewer.publication_valid(directory))
            path = directory / "completion.json"
            marker = reviewer.read(path)
            marker["real_detector_used"] = True
            self.write(path, marker)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "mode"):
                reviewer.publication_valid(directory)

    def test_completion_39_call_claim_cannot_be_changed(self):
        with self.copied() as directory:
            self.assertTrue(reviewer.publication_valid(directory))
            path = directory / "completion.json"
            marker = reviewer.read(path)
            marker["detector_calls"] = 40
            self.write(path, marker)
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "counts"):
                reviewer.publication_valid(directory)

    def test_actual_marker_io_cannot_cross_deadline_with_earlier_body_timestamp(self):
        with self.copied() as directory:
            self.assertTrue(reviewer.publication_valid(directory))
            marker = directory / "completion.json"
            deadline = reviewer.read(directory / "coordinator.json")["deadline_epoch"]
            late_ns = int(deadline*1e9)+1_000_000_000
            os.utime(marker, ns=(late_ns, late_ns))
            with self.assertRaisesRegex(reviewer.BusinessVerificationError, "publication exceeded"):
                reviewer.publication_valid(directory)

    def test_passed_root_cannot_hide_late_rejected_marker_or_parent_failure(self):
        for name in ("completion_rejected.json", "failure.json"):
            with self.subTest(name=name), self.copied() as directory:
                self.assertTrue(reviewer.publication_valid(directory))
                (directory / name).write_text("{}\n", encoding="utf-8")
                with self.assertRaisesRegex(reviewer.BusinessVerificationError, "failure or rejected"):
                    reviewer.publication_valid(directory)

if __name__ == "__main__":
    unittest.main()
