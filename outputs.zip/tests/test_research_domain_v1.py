"""Real CPU LabelGuard domain branches and adversarial source boundaries."""
from __future__ import annotations

import copy
from pathlib import Path
import unittest
from unittest.mock import patch

from test_config import temporary_workspace
from defect_researcher import research_domain_v1 as domain
from defect_researcher import geometry_verifier, label_repair
from defect_researcher.labelguard_fixtures import load_case_spec

RESEARCH = Path(r"E:\PythonProject\projects\cableinspect-ad-code\project_start")


class ResearchDomainTests(unittest.TestCase):
    def prepared(self, root, case="repair_coordinates"):
        return domain.prepare_case(root / "input", case, RESEARCH)

    def test_all_twelve_frozen_cases_use_real_cpu_tools_and_explicit_verdicts(self):
        for case in load_case_spec()["cases"]:
            with self.subTest(case=case["id"]), temporary_workspace() as root:
                prepared = self.prepared(root, case["id"])
                verification = domain.verify_case(prepared, root / "tasks", "geometry")
                expected_before = case["expected"]["before_verification_status"]
                self.assertEqual(verification["semantic_status"], expected_before)
                self.assertEqual(verification["cost"]["domain_tool_calls"], 1)
                self.assertTrue(verification["synthetic_only"])
                self.assertFalse(verification["inference_performed"])
                self.assertEqual(verification["input_before_after"]["before"], prepared["source_files"])
                self.assertEqual(verification["input_before_after"]["before"], verification["input_before_after"]["after"])
                repair = domain.repair_case(prepared, root / "tasks", "repair")
                self.assertEqual(repair["execution_status"], "completed", repair["errors"])
                self.assertTrue(repair["task_chain_verified"])
                self.assertEqual(repair["semantic_status"], case["expected"]["repair_status"])
                self.assertEqual(repair["cost"]["domain_tool_calls"], 3 if case["group"] != "refused" else 2)
                self.assertEqual(repair["cost"]["repair_calls"], 1)
                self.assertEqual(repair["summary"]["changed_files"], len(case["expected"]["changed_files"]))
                self.assertTrue(all(repair["acceptance_checks"].values()))
                if case["group"] != "refused":
                    explicit = domain.verify_copy(prepared, repair, root / "copy_tasks", "explicit-copy-check")
                    self.assertEqual(explicit["semantic_status"], "passed")
                    self.assertEqual(explicit["configuration"]["dataset_root"], repair["summary"]["copy_root"])
                    self.assertEqual(explicit["cost"]["domain_tool_calls"], 1)
                    self.assertTrue(explicit["task_chain_verified"])

    def test_completed_geometry_with_failed_findings_is_not_passed(self):
        with temporary_workspace() as root:
            evidence = domain.verify_case(self.prepared(root), root / "tasks", "geometry")
            self.assertEqual(evidence["execution_status"], "completed")
            self.assertEqual(evidence["semantic_status"], "failed")
            self.assertTrue(evidence["task_chain_verified"])

    def test_classification_uses_actual_verdicts_and_fails_closed(self):
        for case in load_case_spec()["cases"]:
            with self.subTest(case=case["id"]), temporary_workspace() as root:
                evidence = domain.verify_case(self.prepared(root, case["id"]), root / "tasks", "geometry")
                expected = ("clean" if case["group"] == "normal" else "repairable"
                            if case["group"] == "repairable" else "untrusted")
                evidence["case_id"] = "ignored-case-name"
                self.assertEqual(domain.classify_geometry(evidence), expected)

    def test_missing_label_route_preserves_failed_execution_and_requires_guard(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root, "repair_missing_label")
            evidence = domain.verify_case(prepared, root / "tasks", "geometry")
            self.assertEqual(evidence["execution_status"], "failed")
            self.assertEqual(evidence["semantic_status"], "execution_failed")
            self.assertFalse(evidence["task_chain_verified"])
            self.assertEqual(evidence["source_guard"]["status"], "passed")
            self.assertEqual(evidence["source_guard"]["planned_changed_files"], ["labels/train/image_1.txt"])
            self.assertEqual(domain.classify_geometry(evidence), "repairable")
            evidence["source_guard"]["status"] = "untrusted"
            self.assertEqual(domain.classify_geometry(evidence), "untrusted")

    def test_missing_label_guard_refuses_an_additional_unresolved_difference(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root, "repair_missing_label")
            original = label_repair._trusted_plan

            def extra_difference(paths, before):
                manifest, plan, counts = original(paths, before)
                for row in plan:
                    if row["relative_path"].startswith("metadata/"):
                        row["changed"] = True
                        break
                return manifest, plan, counts

            with patch.object(label_repair, "_trusted_plan", side_effect=extra_difference):
                evidence = domain.verify_case(prepared, root / "tasks", "geometry")
            self.assertEqual(evidence["source_guard"]["status"], "untrusted")
            self.assertEqual(domain.classify_geometry(evidence), "untrusted")
            self.assertEqual(evidence["cost"]["domain_tool_calls"], 1)

    def test_null_or_malformed_route_metadata_fails_closed(self):
        with temporary_workspace() as root:
            actual = domain.verify_case(self.prepared(root), root / "tasks", "geometry")
            for key in ("input_before_after", "summary"):
                malformed = copy.deepcopy(actual)
                malformed[key] = None
                self.assertEqual(domain.classify_geometry(malformed), "untrusted")
            missing = domain.verify_case(domain.prepare_case(root / "missing", "repair_missing_label", RESEARCH), root / "tasks", "missing")
            missing["source_guard"] = None
            self.assertEqual(domain.classify_geometry(missing), "untrusted")

    def test_unknown_issues_and_inconsistent_issue_counts_refuse_repair_route(self):
        with temporary_workspace() as root:
            actual = domain.verify_case(self.prepared(root), root / "tasks", "geometry")
            self.assertEqual(domain.classify_geometry(actual), "repairable")
            for key, value in (("issues_by_code", {"arbitrary_unknown": 1}), ("issue_count", 99),
                               ("fixture_status", "failed"), ("inputs_unchanged", False)):
                evidence = copy.deepcopy(actual)
                evidence["summary"][key] = value
                self.assertEqual(domain.classify_geometry(evidence), "untrusted")

    def test_public_snapshot_refresh_is_read_only_and_source_bound(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            self.assertEqual(domain.snapshot_case(prepared), prepared["source_files"])

    def test_original_input_drift_is_rejected_before_call(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            (Path(prepared["configuration"]["dataset_root"]) / "labels/train/image_1.txt").write_bytes(b"changed")
            with patch.object(geometry_verifier, "verify_label_geometry") as called:
                with self.assertRaisesRegex(ValueError, "membership/hash changed"):
                    domain.verify_case(prepared, root / "tasks", "geometry")
                called.assert_not_called()

    def test_source_snapshot_change_is_rejected_before_call(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            Path(prepared["source_snapshot"]["path"]).write_bytes(b"{}")
            with self.assertRaisesRegex(ValueError, "snapshot hash"):
                domain.repair_case(prepared, root / "tasks", "repair")

    def test_arbitrary_model_or_root_configuration_is_rejected(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            prepared["configuration"] = {**prepared["configuration"], "weights_path": str(root / "arbitrary.pt")}
            with self.assertRaisesRegex(ValueError, "configuration"):
                domain.verify_case(prepared, root / "tasks", "geometry")

    def test_forged_case_expected_is_rejected(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            prepared["case_expected"] = {**prepared["case_expected"], "repair_status": "refused"}
            with self.assertRaisesRegex(ValueError, "specification"):
                domain.verify_case(prepared, root / "tasks", "geometry")

    def test_dependency_drift_is_rejected_before_call(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            prepared["source_dependencies"] = copy.deepcopy(prepared["source_dependencies"])
            prepared["source_dependencies"]["label_repair"]["sha256"] = "0" * 64
            with self.assertRaisesRegex(ValueError, "dependency membership/hash"):
                domain.repair_case(prepared, root / "tasks", "repair")

    def test_unsafe_task_name_and_input_output_overlap_are_rejected(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            for identifier in ("../escape", "x/y", "", "-bad"):
                with self.subTest(identifier=identifier), self.assertRaises(ValueError):
                    domain.verify_case(prepared, root / "tasks", identifier)
            with self.assertRaisesRegex(ValueError, "separate"):
                domain.verify_case(prepared, prepared["configuration"]["dataset_root"], "geometry")

    def test_history_is_preserved_when_task_name_repeats(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root, "normal_unrotated")
            evidence = domain.verify_case(prepared, root / "tasks", "geometry")
            marker = Path(evidence["task_dir"]) / "completion.json"
            before = marker.read_bytes()
            with self.assertRaises(FileExistsError):
                domain.verify_case(prepared, root / "tasks", "geometry")
            self.assertEqual(marker.read_bytes(), before)
            self.assertFalse((marker.parent / "failure.json").exists())

    def test_refused_repair_cannot_be_used_for_copy_verification(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root, "refuse_source_hash")
            refused = domain.repair_case(prepared, root / "tasks", "repair")
            with self.assertRaisesRegex(ValueError, "passed repair evidence"):
                domain.verify_copy(prepared, refused, root / "tasks", "copy")

    def test_copy_byte_drift_is_rejected_before_explicit_verification(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            repaired = domain.repair_case(prepared, root / "tasks", "repair")
            (Path(repaired["summary"]["copy_root"]) / "labels/train/image_1.txt").write_bytes(b"changed")
            with patch.object(geometry_verifier, "verify_label_geometry") as called:
                with self.assertRaisesRegex(ValueError, "artifact membership/hash changed"):
                    domain.verify_copy(prepared, repaired, root / "tasks", "copy")
                called.assert_not_called()

    def test_copy_from_another_case_is_rejected(self):
        with temporary_workspace() as root:
            first = domain.prepare_case(root / "first", "repair_coordinates", RESEARCH)
            second = domain.prepare_case(root / "second", "repair_coordinates", RESEARCH)
            repaired = domain.repair_case(first, root / "tasks", "repair")
            with self.assertRaisesRegex(ValueError, "passed repair evidence"):
                domain.verify_copy(second, repaired, root / "tasks", "copy")

    def test_failure_of_real_generator_has_no_passed_copy_evidence(self):
        with temporary_workspace() as root:
            prepared = self.prepared(root)
            module = label_repair._load_production(Path(prepared["configuration"]["research_root"]) / "cableinspect_geometry.py")
            module.coco_bbox_to_yolo = lambda *args: ([0.4, 0.35, 0.4, 0.1], False)
            with patch.object(label_repair, "_load_production", return_value=module):
                evidence = domain.repair_case(prepared, root / "tasks", "faulty")
            self.assertEqual(evidence["execution_status"], "failed")
            self.assertEqual(evidence["semantic_status"], "execution_failed")
            self.assertFalse(evidence["task_chain_verified"])
            self.assertEqual(evidence["cost"]["domain_tool_calls"], 3)
            self.assertFalse((Path(evidence["task_dir"]) / "completion.json").exists())

    def test_unknown_case_and_existing_input_root_are_refused(self):
        with temporary_workspace() as root:
            with self.assertRaises(ValueError):
                domain.prepare_case(root / "input", "custom", RESEARCH)
            self.prepared(root)
            with self.assertRaises(FileExistsError):
                self.prepared(root)


if __name__ == "__main__":
    unittest.main()
