"""Real ledger tests with synthetic journals/clocks; no detector/GPU imports."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

from defect_researcher.resolution_recovery_ledger_v1 import Ledger, GROUPS, STEPS, canonical, digest
from test_config import temporary_workspace


class Clock:
    def __init__(self):
        self.epoch, self.mono = 1001.0, 5001.0

    def time(self):
        return self.epoch

    def monotonic(self):
        return self.mono


def registration():
    return {'budgets': {'max_prediction_calls': 3205, 'max_formal_calls': 3200,
            'max_warmup_calls': 5, 'max_recovery_attempts': 1,
            'max_task_wall_seconds': 1800, 'max_gpu_seconds': 300},
            'image_ids': [f'image_{index:03d}' for index in range(640)],
            'started_epoch': 1000.0, 'started_monotonic': 5000.0}


def ticket(index, plan):
    group, position = divmod(index, 641)
    step = GROUPS[group]
    return {'call_index': index + 1, 'kind': 'warmup' if position == 0 else 'formal',
            'step_id': step, 'image_id': plan['image_ids'][max(position - 1, 0)], 'imgsz': STEPS[step]}


def closed(identity, *, status='passed', elapsed=.001, gpu=.001):
    return {'ticket': deepcopy(identity), 'status': status, 'elapsed_seconds': elapsed,
            'gpu_seconds': gpu, 'cost_known': elapsed is not None and gpu is not None, 'details': {}}


def rechain(rows, plan):
    previous = '0' * 64
    result = []
    for index, row in enumerate(rows):
        row = deepcopy(row)
        row.update(sequence=index + 1, previous_sha256=previous, registration_sha256=digest(plan))
        row.pop('sha256', None)
        row['sha256'] = digest(row)
        previous = row['sha256']
        result.append(row)
    return result


def journal(plan, calls=1):
    rows = []
    for index in range(calls):
        identity = ticket(index, plan)
        for event, payload in (('reserved', identity), ('closed', closed(identity))):
            rows.append({'schema_version': 1, 'event': event, 'at_epoch': 1001.0,
                         'at_monotonic': 5001.0, 'wall_seconds': 1.0, 'payload': payload})
    return rechain(rows, plan)


def save(root, rows):
    path = root / 'shared_prediction_journal.jsonl'
    path.write_bytes(b''.join(canonical(row) + b'\n' for row in rows))
    return path


class LedgerRegistrationTests(unittest.TestCase):
    def test_exact_fixed_counts_and_clock_budget_types_are_required(self):
        for key in registration()['budgets']:
            for value in (True, None, '3205', -1, float('nan'), float('inf')):
                with self.subTest(key=key, value=value), temporary_workspace() as root:
                    plan = registration()
                    plan['budgets'][key] = value
                    with self.assertRaises(ValueError): Ledger(root, plan, create=True, clock=Clock())
                    self.assertFalse((root / 'shared_prediction_journal.jsonl').exists())
        for key in ('max_prediction_calls', 'max_formal_calls', 'max_warmup_calls', 'max_recovery_attempts'):
            with temporary_workspace() as root:
                plan = registration()
                plan['budgets'][key] = float(plan['budgets'][key])
                with self.assertRaises(ValueError): Ledger(root, plan, create=True, clock=Clock())

    def test_registration_and_budget_unknown_missing_fields_are_rejected(self):
        for mutation in ('registration_extra', 'registration_missing', 'budget_extra', 'budget_missing'):
            with self.subTest(mutation=mutation), temporary_workspace() as root:
                plan = registration()
                if mutation == 'registration_extra': plan['invented'] = 1
                elif mutation == 'registration_missing': plan.pop('started_epoch')
                elif mutation == 'budget_extra': plan['budgets']['invented'] = 1
                else: plan['budgets'].pop('max_formal_calls')
                with self.assertRaises(ValueError): Ledger(root, plan, create=True, clock=Clock())

    def test_membership_is_exact_640_unique_nonempty_sorted_strings(self):
        for mutation in ('short', 'long', 'duplicate', 'blank', 'integer', 'reorder', 'tuple'):
            with self.subTest(mutation=mutation), temporary_workspace() as root:
                plan = registration()
                ids = plan['image_ids']
                if mutation == 'short': ids.pop()
                elif mutation == 'long': ids.append('image_640')
                elif mutation == 'duplicate': ids[1] = ids[0]
                elif mutation == 'blank': ids[0] = ' '
                elif mutation == 'integer': ids[0] = 1
                elif mutation == 'reorder': ids.reverse()
                else: plan['image_ids'] = tuple(ids)
                with self.assertRaises(ValueError): Ledger(root, plan, create=True, clock=Clock())

    def test_registration_is_copied_and_in_memory_rebinding_is_refused(self):
        with temporary_workspace() as root:
            plan = registration()
            with Ledger(root, plan, create=True, clock=Clock()) as ledger:
                plan['budgets']['max_gpu_seconds'] = 999
                self.assertEqual(ledger.registration['budgets']['max_gpu_seconds'], 300)
                ledger.registration['budgets']['max_gpu_seconds'] = 999
                with self.assertRaisesRegex(ValueError, 'changed'): ledger.check()


class LedgerAdmissionTests(unittest.TestCase):
    def test_durable_reservation_precedes_entry_and_cannot_overlap_or_swap_ticket(self):
        with temporary_workspace() as root, Ledger(root, registration(), create=True, clock=Clock()) as ledger:
            with patch('os.fsync', wraps=os.fsync) as flushed:
                identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                self.assertGreaterEqual(flushed.call_count, 1)
            persisted = json.loads(ledger.path.read_bytes().splitlines()[0])
            self.assertEqual(persisted['payload'], identity)
            ledger.check()  # Only the owning live handle may check immediately before predict.
            with self.assertRaises(ValueError): ledger.reserve('formal', 'reference_640', 'image_000', 640)
            with self.assertRaises(ValueError): ledger.closed({**identity, 'imgsz': 640.0}, 'passed', .1, .01)
            with self.assertRaises(ValueError): ledger.closed({**identity, 'call_index': True}, 'passed', .1, .01)
            self.assertEqual(ledger.sequence, 1)
            ledger.closed(identity, 'passed', .1, .01)
            with self.assertRaises(ValueError): ledger.closed(identity, 'passed', .1, .01)
            self.assertEqual(ledger.summary()['prediction_calls'], 1)

    def test_live_admission_rejects_later_group_wrong_resolution_and_member_order(self):
        with temporary_workspace() as root, Ledger(root, registration(), create=True, clock=Clock()) as ledger:
            for args in (('warmup', 'resume_960', 'image_000', 960),
                         ('formal', 'reference_640', 'image_000', 640),
                         ('warmup', 'reference_640', 'image_001', 640),
                         ('warmup', 'reference_640', 'image_000', 640.0)):
                with self.subTest(args=args), self.assertRaises(ValueError): ledger.reserve(*args)
            identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
            ledger.closed(identity, 'passed', .01, .001)
            for args in (('warmup', 'reference_960', 'image_000', 960),
                         ('warmup', 'reference_640', 'image_000', 640),
                         ('formal', 'reference_640', 'image_001', 640)):
                with self.subTest(args=args), self.assertRaises(ValueError): ledger.reserve(*args)
            self.assertEqual(ledger.reserve('formal', 'reference_640', 'image_000', 640)['call_index'], 2)

    def test_unknown_elapsed_gpu_or_failed_call_stops_live_and_reopened_admission(self):
        for status, elapsed, gpu in (('passed', None, .01), ('passed', .1, None), ('failed', .1, .01)):
            with self.subTest(status=status, elapsed=elapsed, gpu=gpu), temporary_workspace() as root:
                plan, clock = registration(), Clock()
                with Ledger(root, plan, create=True, clock=clock) as ledger:
                    identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                    ledger.closed(identity, status, elapsed, gpu)
                    with self.assertRaises(ValueError): ledger.reserve('formal', 'reference_640', 'image_000', 640)
                with Ledger(root, plan, clock=clock) as replay:
                    with self.assertRaises(ValueError): replay.check()
                    self.assertIsNone(replay.active)

    def test_open_reservation_reloads_as_unknown_and_cannot_predict(self):
        with temporary_workspace() as root:
            plan, clock = registration(), Clock()
            with Ledger(root, plan, create=True, clock=clock) as ledger:
                ledger.reserve('warmup', 'reference_640', 'image_000', 640)
            with Ledger(root, plan, clock=clock) as replay:
                self.assertFalse(replay.summary()['cost_known'])
                with self.assertRaises(ValueError): replay.check()
                with self.assertRaises(ValueError): replay.reserve('formal', 'reference_640', 'image_000', 640)

    def test_invalid_actual_costs_and_unknown_details_cannot_close_active_ticket(self):
        for kwargs in ({'elapsed_seconds': True}, {'gpu_seconds': -1}, {'gpu_seconds': float('nan')},
                       {'cost_known': False}, {'invented': 1}, {'prediction_entered': 1}, {'imgsz': 640.0}):
            with self.subTest(kwargs=kwargs), temporary_workspace() as root, Ledger(root, registration(), create=True, clock=Clock()) as ledger:
                identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                arguments = {'elapsed_seconds': .1, 'gpu_seconds': .01, **kwargs}
                with self.assertRaises(ValueError): ledger.closed(identity, 'passed', **arguments)
                self.assertEqual(ledger.sequence, 1)

    def test_deadline_gpu_and_elapsed_caps_block_next_entry_but_late_cost_is_recorded(self):
        for change in ('deadline', 'gpu', 'elapsed'):
            with self.subTest(change=change), temporary_workspace() as root:
                clock = Clock()
                with Ledger(root, registration(), create=True, clock=clock) as ledger:
                    identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                    if change == 'deadline': clock.epoch = 2800.0
                    ledger.closed(identity, 'passed', 1800 if change == 'elapsed' else .1,
                                  300 if change == 'gpu' else .01)
                    self.assertEqual(ledger.sequence, 2)
                    with self.assertRaises(ValueError): ledger.reserve('formal', 'reference_640', 'image_000', 640)

    def test_clock_must_never_move_backwards_or_be_nonfinite_even_inside_original_window(self):
        for field, value in (('epoch', 1000.5), ('mono', 5000.5), ('epoch', float('nan')),
                             ('mono', True), ('mono', -1), ('epoch', float('inf'))):
            with self.subTest(field=field, value=value), temporary_workspace() as root:
                clock = Clock()
                with Ledger(root, registration(), create=True, clock=clock) as ledger:
                    setattr(clock, field, value)
                    with self.assertRaises(ValueError): ledger.check()


class LedgerReplayTests(unittest.TestCase):
    def reject(self, rows, plan=None):
        plan = registration() if plan is None else plan
        with temporary_workspace() as root:
            save(root, rechain(rows, plan))
            with self.assertRaises(ValueError): Ledger(root, plan, clock=Clock(), read_only=True)

    def test_rehashing_cannot_bypass_group_member_warmup_or_boolean_ticket_rules(self):
        for field, value in (('kind', 'formal'), ('step_id', 'resume_960'), ('image_id', 'image_001'),
                             ('call_index', True), ('imgsz', 640.0), ('invented', 1)):
            with self.subTest(field=field, value=value):
                rows = journal(registration())
                rows[0]['payload'][field] = value
                rows[1]['payload']['ticket'][field] = value
                self.reject(rows)

    def test_replayed_unknown_or_failed_cost_forbids_even_valid_following_reservation(self):
        for change in ('failed', 'unknown_elapsed', 'unknown_gpu', 'gpu_exhausted', 'elapsed_exhausted'):
            with self.subTest(change=change):
                rows = journal(registration(), 2)
                receipt = rows[1]['payload']
                if change == 'failed': receipt['status'] = 'failed'
                elif change == 'unknown_elapsed': receipt.update(elapsed_seconds=None, cost_known=False)
                elif change == 'unknown_gpu': receipt.update(gpu_seconds=None, cost_known=False)
                elif change == 'gpu_exhausted': receipt['gpu_seconds'] = 300
                else: receipt['elapsed_seconds'] = 1800
                self.reject(rows)

    def test_rehashed_rows_and_receipts_have_exact_typed_schemas(self):
        for change in ('version_bool', 'row_extra', 'row_missing', 'closed_extra', 'closed_missing',
                       'cost_bool', 'known_integer', 'status_bool', 'details_extra', 'ticket_float'):
            with self.subTest(change=change):
                rows = journal(registration())
                receipt = rows[1]['payload']
                if change == 'version_bool': rows[0]['schema_version'] = True
                elif change == 'row_extra': rows[0]['invented'] = 1
                elif change == 'row_missing': rows[0].pop('at_monotonic')
                elif change == 'closed_extra': receipt['invented'] = 1
                elif change == 'closed_missing': receipt.pop('details')
                elif change == 'cost_bool': receipt['gpu_seconds'] = True
                elif change == 'known_integer': receipt['cost_known'] = 1
                elif change == 'status_bool': receipt['status'] = True
                elif change == 'details_extra': receipt['details']['invented'] = 1
                else: receipt['ticket']['call_index'] = 1.0
                self.reject(rows)

    def test_rehashed_persisted_clock_must_be_monotone_consistent_and_before_reservation_deadline(self):
        for change in ('epoch_backwards', 'mono_backwards', 'wall_wrong', 'clock_bool', 'future', 'expired_reserve'):
            with self.subTest(change=change):
                rows = journal(registration())
                if change == 'epoch_backwards': rows[1].update(at_epoch=1000.5, wall_seconds=1.)
                elif change == 'mono_backwards': rows[1].update(at_monotonic=5000.5, wall_seconds=1.)
                elif change == 'wall_wrong': rows[0]['wall_seconds'] = 0.
                elif change == 'clock_bool': rows[0]['at_epoch'] = True
                else:
                    for row in rows: row.update(at_epoch=2800. if change == 'expired_reserve' else 1002.,
                                              wall_seconds=1800. if change == 'expired_reserve' else 2.)
                self.reject(rows)

    def test_partial_duplicate_or_broken_chain_is_rejected(self):
        for change in ('partial', 'duplicate_key', 'hash', 'sequence', 'replay', 'registration'):
            with self.subTest(change=change), temporary_workspace() as root:
                plan = registration()
                rows = journal(plan)
                if change == 'hash': rows[1]['sha256'] = 'f' * 64
                elif change == 'sequence': rows[1]['sequence'] = True
                elif change == 'replay': rows.append(rows[0])
                elif change == 'registration': rows[0]['registration_sha256'] = 'f' * 64
                path = save(root, rows)
                if change == 'partial': path.write_bytes(path.read_bytes()[:-1])
                elif change == 'duplicate_key': path.write_bytes(path.read_bytes().replace(b'"schema_version":1', b'"schema_version":1,"schema_version":1', 1))
                with self.assertRaises(ValueError): Ledger(root, plan, clock=Clock(), read_only=True)

    def test_full_3205_budget_five_groups_replays_exactly_and_3206th_is_rejected(self):
        plan = registration()
        rows = journal(plan, 3205)
        with temporary_workspace() as root:
            save(root, rows)
            with Ledger(root, plan, clock=Clock()) as ledger:
                summary = ledger.summary()
                self.assertEqual((summary['prediction_calls'], summary['formal_calls'], summary['warmup_calls']), (3205, 3200, 5))
                self.assertTrue(summary['all_groups_complete'])
                self.assertEqual(summary['complete_groups'], 5)
                before = ledger.path.read_bytes()
                with self.assertRaises(ValueError): ledger.reserve('warmup', 'resume_960', 'image_000', 960)
                self.assertEqual(ledger.path.read_bytes(), before)
        extra = deepcopy(rows[-2])
        extra['payload']['call_index'] = 3206
        self.reject(rows + [extra], plan)


class LedgerWriterTests(unittest.TestCase):
    def test_second_writer_is_denied_and_read_only_inspection_works_while_owner_is_live(self):
        with temporary_workspace() as root:
            plan, clock = registration(), Clock()
            with Ledger(root, plan, create=True, clock=clock) as ledger:
                with self.assertRaisesRegex(ValueError, 'writer'): Ledger(root, plan, clock=clock)
                ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                with Ledger(root, plan, clock=clock, read_only=True) as reader:
                    self.assertEqual(reader.summary()['prediction_calls'], 1)
                    self.assertFalse(reader.summary()['cost_known'])
                    for action in (reader.check, lambda: reader.reserve('formal', 'reference_640', 'image_000', 640),
                                   lambda: reader.closed(ledger.active, 'passed', .1, .01)):
                        with self.assertRaisesRegex(ValueError, 'Read-only'): action()
            with Ledger(root, plan, clock=clock) as reopened:
                with self.assertRaises(ValueError): reopened.check()

    def test_os_lock_blocks_a_separate_process_before_it_can_admit_a_prediction(self):
        script = "import json,sys; from defect_researcher.resolution_recovery_ledger_v1 import Ledger; " + \
                 "from types import SimpleNamespace; clock=SimpleNamespace(time=lambda:1001.,monotonic=lambda:5001.); " + \
                 "plan=json.loads(sys.argv[2]);\ntry: ledger=Ledger(sys.argv[1],plan,clock=clock)\n" + \
                 "except ValueError: print('blocked')\nelse: ledger.close(); print('admitted')"
        with temporary_workspace() as root, Ledger(root, registration(), create=True, clock=Clock()):
            result = subprocess.run([sys.executable, '-B', '-c', script, str(root), json.dumps(registration())],
                cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True, timeout=15,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), 'blocked')

    def test_stale_or_same_length_modified_journal_is_refused_before_next_entry(self):
        for change in ('append', 'same_length'):
            with self.subTest(change=change), temporary_workspace() as root, Ledger(root, registration(), create=True, clock=Clock()) as ledger:
                identity = ledger.reserve('warmup', 'reference_640', 'image_000', 640)
                ledger.closed(identity, 'passed', .1, .01)
                raw = ledger.path.read_bytes()
                ledger.path.write_bytes(raw + b'\n' if change == 'append' else raw.replace(b'reference_640', b'reference_960', 1))
                with self.assertRaisesRegex(ValueError, 'stale'): ledger.check()
                with self.assertRaises(ValueError): ledger.reserve('formal', 'reference_640', 'image_000', 640)

    def test_released_handle_and_overwrite_creation_cannot_reserve_or_replace_history(self):
        with temporary_workspace() as root:
            plan = registration()
            ledger = Ledger(root, plan, create=True, clock=Clock())
            ledger.close()
            with self.assertRaises(ValueError): ledger.check()
            with self.assertRaises(FileExistsError): Ledger(root, plan, create=True, clock=Clock())
            with Ledger(root, plan, clock=Clock()) as current:
                self.assertEqual(current.summary()['journal_events'], 0)


if __name__ == '__main__':
    unittest.main()
