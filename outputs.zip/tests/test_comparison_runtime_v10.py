"""Acceptance boundary tests; none launch AGH or invoke a model."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import unittest

from tools.verify_comparison_runtime_v10 import ROOT, verify


def fixture():
    def ts(ms):
        return datetime.fromtimestamp(ms / 1000, timezone.utc).isoformat().replace("+00:00", "Z")
    begin = 1000000
    session = "v10-fresh-session"
    model = "agnes-3.0-flash"
    rows = []
    def add(kind, data, **extra):
        n = len(rows) + 1
        event = {"seq": n, "ts": ts(begin + n * 100), "lane": "main", "type": kind,
                 "origin": "system", "trust": "trusted", "data": data, **extra}
        rows.append(event)
        return event
    add("session/start", {"key": session})
    add("request/sent", {})
    add("turn/end", {"reason": "completed", "turn": 1})
    requested = add("x/host/session-title", {"status": "requested", "turn": 1, "startSeq": 2,
                    "model": model, "route": "account-defect-researcher"}, ignorable=True)
    effect = "title:" + hashlib.sha256(json.dumps([session, "main", 2], separators=(",", ":")).encode()).hexdigest()
    cost = add("cost/ledger", {"purpose": "title", "sourceTurn": 1, "effectId": effect,
                              "model": model, "creditSource": "estimated",
                              "tokens": {"input": 20, "output": 5, "cacheRead": 0, "cacheWrite": 0}})
    diagnostic = add("x/host/session-title-diagnostics", {
        "schemaVersion": 1, "sourceTurn": 1, "effectId": effect, "timeoutMs": 30000,
        "durationMs": 100, "providerSent": True, "responseSeen": True, "responseStatus": 200,
        "firstTextAtMs": 70, "usageObserved": True, "usageAtMs": 100,
        "cancellationSettlementLimitMs": 25, "settledUsage": False, "duplicateUsage": False,
        "invalidUsage": False}, ignorable=True)
    diagnostic["ts"] = cost["ts"]
    terminal = add("x/host/session-title", {**requested["data"], "status": "generated", "title": "Synthetic case"},
                   ignorable=True)
    terminal["ts"] = cost["ts"]
    run = {"started_epoch_ms": begin, "finished_epoch_ms": begin + 1000,
           "deadline_epoch_ms": begin + 120000, "session_id": session, "session_key": session,
           "model": model, "route": "account-defect-researcher", "model_requests_including_title": 2,
           "title_request_event": requested, "title_terminal_event": terminal, "sdk_events": rows}
    local = ROOT.parent / "agnes-harness" / "packages" / "cli" / "dist" / "local"
    manifest = {"status": "passed_local_repair", "agh_core_modified": True,
                "local_runtime_build": {"exit_code": 0}, "runtime_files": [
                    {"path": str(local / name), "sha256": char * 64}
                    for name, char in (("agnes.mjs", "a"), ("daemon.mjs", "b"), ("worker.mjs", "c"))]}
    processes = [{"role": role, "pid": pid, "parent_pid": parent,
                  "executable": "E:/nodejs24.15.0/node.exe", "started_at": ts(begin - 4000 + offset),
                  "command_line": f'"E:/nodejs24.15.0/node.exe" "{local / name}"' + args}
                 for role, name, pid, parent, offset, args in (
                     ("web", "agnes.mjs", 10, 9, 0, " serve"),
                     ("daemon", "daemon.mjs", 11, 10, 100,
                      f' --workspace "{ROOT}" --data-dir "{ROOT}/.runtime/agh/data"'),
                     ("worker", "worker.mjs", 12, 11, 200, ""))]
    binding = {"schema_version": 1, "build_completed_at": ts(begin - 5000),
               "runtime_manifest": {"path": "synthetic", "sha256": "d" * 64}}
    for name, captured in (("before", begin - 1000), ("after", begin + 1100)):
        binding[name] = {"captured_at": ts(captured), "build_completed_at": binding["build_completed_at"],
                         "web_port": 4177, "web_port_owner_pid": 10,
                         "processes": copy.deepcopy(processes),
                         "bundles": copy.deepcopy(manifest["runtime_files"])}
    return binding, manifest, rows, run


class RuntimeAcceptanceTests(unittest.TestCase):
    def test_live_execution_with_actual_title_tokens_passes(self):
        result = verify(*fixture())
        self.assertEqual(result["status"], "passed", result)
        self.assertEqual(result["actual_total_model_requests"], 2)
        self.assertEqual(result["native_title_actual_tokens"]["input"], 20)

    def test_runtime_negative_boundaries(self):
        mutations = {
            "old_daemon": lambda b, m, r, u: b["before"]["processes"][1].update(started_at="1970-01-01T00:16:34Z"),
            "old_worker": lambda b, m, r, u: b["before"]["processes"][2].update(started_at="1970-01-01T00:16:34Z"),
            "new_worker_after_arm": lambda b, m, r, u: b["after"]["processes"][2].update(started_at="1970-01-01T00:16:40.2Z"),
            "worker_changed": lambda b, m, r, u: b["after"]["processes"][2].update(pid=99),
            "worker_parent_changed": lambda b, m, r, u: b["before"]["processes"][2].update(parent_pid=99),
            "daemon_parent_changed": lambda b, m, r, u: b["before"]["processes"][1].update(parent_pid=99),
            "wrong_port_owner": lambda b, m, r, u: b["before"].update(web_port_owner_pid=99),
            "wrong_project": lambda b, m, r, u: b["before"]["processes"][1].update(command_line="node unrelated daemon.mjs"),
            "wrong_executable": lambda b, m, r, u: b["before"]["processes"][2].update(executable="E:/python.exe"),
            "changed_bundle": lambda b, m, r, u: b["after"]["bundles"][2].update(sha256="e"*64),
            "missing_worker_bundle": lambda b, m, r, u: b["before"]["bundles"].pop(),
            "duplicate_bundle": lambda b, m, r, u: b["before"]["bundles"].append(copy.deepcopy(b["before"]["bundles"][0])),
            "snapshot_after_arm": lambda b, m, r, u: b["before"].update(captured_at="1970-01-01T00:16:40.5Z"),
            "after_snapshot_too_early": lambda b, m, r, u: b["after"].update(captured_at="1970-01-01T00:16:40.5Z"),
            "build_in_future": lambda b, m, r, u: b.update(build_completed_at="1970-01-01T00:16:42Z"),
            "snapshot_build_changed": lambda b, m, r, u: b["after"].update(build_completed_at="1970-01-01T00:16:34Z"),
            "failed_build": lambda b, m, r, u: m["local_runtime_build"].update(exit_code=1),
            "build_exit_bool": lambda b, m, r, u: m["local_runtime_build"].update(exit_code=False),
            "deadline_expired": lambda b, m, r, u: u.update(finished_epoch_ms=u["deadline_epoch_ms"]),
            "timezone_absent": lambda b, m, r, u: b["before"].update(captured_at="1970-01-01T00:16:39"),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                args = fixture()
                mutate(*args)
                result = verify(*args)
                self.assertEqual(result["status"], "failed", result)
                self.assertFalse(result["checks"]["live_process_and_bundle_execution_binding"])

    def test_title_negative_boundaries(self):
        mutations = {
            "missing_diagnostic": lambda b, m, r, u: r.pop(5),
            "untrusted_diagnostic": lambda b, m, r, u: r[5].update(trust="untrusted"),
            "plugin_diagnostic": lambda b, m, r, u: r[5].update(origin="ext:plugin/fake"),
            "diagnostic_not_ignorable": lambda b, m, r, u: r[5].update(ignorable=False),
            "wrong_effect": lambda b, m, r, u: r[5]["data"].update(effectId="title:"+"f"*64),
            "forged_effect_in_both": lambda b, m, r, u: (r[4]["data"].update(effectId="title:"+"f"*64), r[5]["data"].update(effectId="title:"+"f"*64)),
            "wrong_source_turn": lambda b, m, r, u: r[5]["data"].update(sourceTurn=2),
            "boolean_source_turn": lambda b, m, r, u: r[5]["data"].update(sourceTurn=True),
            "unknown_usage": lambda b, m, r, u: r[5]["data"].update(usageObserved=False),
            "masked_usage_clock": lambda b, m, r, u: r[5]["data"].update(usageAtMs="[REDACTED:id]"),
            "default_zero_tokens": lambda b, m, r, u: r[4]["data"].update(tokens={"input":0,"output":0,"cacheRead":0,"cacheWrite":0}),
            "unknown_tokens": lambda b, m, r, u: r[4]["data"].update(tokens=None),
            "missing_cache_usage": lambda b, m, r, u: r[4]["data"]["tokens"].pop("cacheRead"),
            "boolean_token": lambda b, m, r, u: r[4]["data"]["tokens"].update(input=True),
            "unsafe_sum": lambda b, m, r, u: r[4]["data"]["tokens"].update(input=9007199254740991),
            "interrupted": lambda b, m, r, u: r[4]["data"].update(interrupted=True),
            "title_failed": lambda b, m, r, u: r[6]["data"].update(status="failed", reason="timeout"),
            "cancelled": lambda b, m, r, u: r[5]["data"].update(cancelledBy="timeout", cancelledAtMs=100),
            "settled_cancel_receipt": lambda b, m, r, u: r[5]["data"].update(settledUsage=True),
            "duplicate_usage": lambda b, m, r, u: r[5]["data"].update(duplicateUsage=True),
            "invalid_usage": lambda b, m, r, u: r[5]["data"].update(invalidUsage=True),
            "no_provider_sent": lambda b, m, r, u: r[5]["data"].update(providerSent=False),
            "no_response": lambda b, m, r, u: r[5]["data"].update(responseSeen=False),
            "error_status": lambda b, m, r, u: r[5]["data"].update(responseStatus=500),
            "duration_exceeds_timeout": lambda b, m, r, u: r[5]["data"].update(durationMs=30000),
            "usage_after_duration": lambda b, m, r, u: r[5]["data"].update(usageAtMs=101),
            "no_native_sdk_diagnostic": lambda b, m, r, u: u.update(sdk_events=[]),
            "native_atomic_clock_differs": lambda b, m, r, u: r[5].update(ts="1970-01-01T00:16:40.6Z"),
            "main_turn_failed": lambda b, m, r, u: r[2]["data"].update(reason="failed"),
            "wrong_model": lambda b, m, r, u: r[4]["data"].update(model="different-model"),
            "wrong_session": lambda b, m, r, u: u.update(session_id="other-session"),
            "unaccounted_title_call": lambda b, m, r, u: u.update(model_requests_including_title=1),
            "undeclared_raw_content": lambda b, m, r, u: r[5]["data"].update(prompt="unexpected prompt"),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                args = fixture()
                mutate(*args)
                result = verify(*args)
                self.assertEqual(result["status"], "failed", result)
                self.assertFalse(result["checks"]["trusted_patched_native_title_and_actual_usage"])


if __name__ == "__main__":
    unittest.main()
