"""Negative branch/accounting acceptance checks; no model or service calls."""
import copy
import hashlib
import unittest

from tools.summarize_comparison_branches_v2 import (
    branch_acceptance, canonical, reported_selection, request_accounting, selected_trials, time_acceptance,
)


def branch(case="repair_coordinates"):
    business = {"status": "passed", "correct_completion": True, "unsupported_atomic_claims": 0,
                "invalid_artifact_accepted": False}
    repair = {"evidence_id": "repair", "action": "repair_copy", "result": {
        "semantic_status": "passed", "summary": {"changed_files": 1}}}
    verifier = {"evidence_id": "verify", "action": "verify_copy", "result": {
        "execution_status": "completed", "semantic_status": "passed", "task_chain_verified": True,
        "summary": {"independent_geometry_verification": True}}}
    data = dict(driver_status="completed", run_status="completed", engineering_status="passed", business=business,
                candidate={"outcome": "repaired", "target": "copy", "evidence_ids": ["repair", "verify"]},
                evidence=[repair, verifier], actions=["repair_copy", "verify_copy", "publish_report"],
                actual_changed_files=["labels/train/image_1.txt"], copied_content_present=True)
    if case == "refuse_source_hash":
        verifier.update(action="verify_input")
        verifier["result"].update(semantic_status="failed")
        verifier["result"]["summary"]["issues_by_code"] = {"declared_input_hash": 1}
        data.update(candidate={"outcome": "refused", "target": "none", "evidence_ids": ["verify"]},
                    evidence=[verifier], actions=["verify_input", "publish_report"],
                    actual_changed_files=None, copied_content_present=False)
    return data


def selection():
    cases = ["normal_unrotated", "repair_coordinates", "refuse_source_hash"]
    trials = [{"trial_id": f"trial-{index}", "trial_handle": "cmp_" + f"{index:032x}", "case_id": case, "arm": arm}
              for index, (case, arm) in enumerate(((case, arm) for case in cases for arm in ("C", "U", "F")), 1)]
    selected = [row for row in trials if row["arm"] == "F" and row["case_id"] != "normal_unrotated"]
    value = {"schema_version": 1, "arm": "F", "case_ids": cases[1:], "trial_handles": [row["trial_handle"] for row in selected]}
    public = {"engineering_diagnostic": {"selection": value, "selection_sha256": hashlib.sha256(canonical(value)).hexdigest(),
                "selected_trials": selected, "selected_trial_count": 2, "planned_comparison_trials": 9},
              "scope_policy": {"allowed_handles": value["trial_handles"]},
              "phase_model_budget": {"total_cap": 48, "prior_versions_actual_requests": 34, "this_pilot_cap": 14,
                                      "phase_remaining_before_diagnostic": 14}}
    return {"trials": trials}, public


def accounting(request_count=1):
    end = {"type": "turn/end", "data": {"reason": "completed"}}
    requested = {"type": "x/host/session-title", "data": {"status": "requested"}}
    terminal = {"type": "x/host/session-title", "data": {"status": "generated"}}
    events = [{"type": "request/sent"}, {"type": "cost/ledger", "data": {
        "purpose": "inference", "tokens": {"input": 1, "output": 1}, "response": {"status": 200}}}, end, requested,
        {"type": "cost/ledger", "data": {"purpose": "title", "tokens": {"input": 1, "output": 1}}}, terminal]
    events = [copy.deepcopy(row) for _ in range(request_count) for row in events[:2]] + events[2:]
    run = {"model_request_count": request_count, "model_requests_including_title": request_count + 1, "turn_end": end,
           "title_request_event": requested, "title_terminal_event": terminal}
    return events, run


class BranchAcceptanceTests(unittest.TestCase):
    def test_two_correct_branches_pass(self):
        for case in ("repair_coordinates", "refuse_source_hash"):
            self.assertTrue(branch_acceptance(case, **branch(case))["joint_correct_completion"])

    def test_bad_business_artifact_cannot_pass(self):
        data = branch()
        data["business"].update(correct_completion=False, invalid_artifact_accepted=True)
        self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_engineering_failure_cannot_be_business_success(self):
        data = branch()
        data["engineering_status"] = "failed"
        self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_selected_unstarted_cannot_pass(self):
        data = branch()
        data.update(driver_status=None, run_status=None)
        self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_reported_positive_repair_without_actual_change_fails(self):
        data = branch()
        for actual in (None, [], ["metadata/train/image_1.json"]):
            data["actual_changed_files"] = actual
            self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_internal_or_uncited_copy_verification_is_insufficient(self):
        data = branch()
        data["candidate"]["evidence_ids"] = ["repair"]
        self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])
        data = branch()
        data["actions"].remove("verify_copy")
        self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_refusal_without_hash_basis_fails(self):
        data = branch("refuse_source_hash")
        data["evidence"][0]["result"]["summary"]["issues_by_code"] = {"yolo_geometry": 1}
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_refusal_repair_attempt_or_copied_directory_fails(self):
        data = branch("refuse_source_hash")
        data["actions"].append("repair_copy")
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])
        data = branch("refuse_source_hash")
        data["copied_content_present"] = True
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_unsupported_or_unknown_claims_fail(self):
        for count in (None, True, 1):
            data = branch()
            data["business"]["unsupported_atomic_claims"] = count
            self.assertFalse(branch_acceptance("repair_coordinates", **data)["joint_correct_completion"])

    def test_selection_matches_exact_new_protocol_order(self):
        protocol, public = selection()
        self.assertEqual([row["case_id"] for row in selected_trials(protocol, public)], ["repair_coordinates", "refuse_source_hash"])
        protocol["trials"][5], protocol["trials"][8] = protocol["trials"][8], protocol["trials"][5]
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)

    def test_selection_hash_or_old_phase_allocation_fails(self):
        protocol, public = selection()
        public["engineering_diagnostic"]["selection_sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)
        protocol, public = selection()
        public["phase_model_budget"]["prior_versions_actual_requests"] = 27
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)

    def test_early_failure_preserves_both_selected_slots(self):
        protocol, public = selection()
        selected = selected_trials(protocol, public)
        reported = [{**selected[0], "status": "failed"}]
        valid, observations = reported_selection(selected, reported)
        self.assertTrue(valid)
        self.assertEqual(len(observations), 2)
        self.assertEqual(observations[0]["status"], "failed")
        self.assertIsNone(observations[1])
        valid, observations = reported_selection(selected, [selected[1]])
        self.assertFalse(valid)
        self.assertEqual(len(observations), 2)

    def test_missing_cost_ledger_is_unknown_not_zero(self):
        self.assertIsNone(request_accounting(None, {})["actual_total_model_requests"])
        events, run = accounting()
        events = [row for row in events if row.get("type") != "cost/ledger"]
        result = request_accounting(events, run)
        self.assertEqual(result["observed_total_model_requests"], 2)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_title_and_turn_costs_must_both_settle(self):
        events, run = accounting()
        self.assertEqual(request_accounting(events, run)["actual_total_model_requests"], 2)
        for kind in ("x/host/session-title", "turn/end"):
            with self.subTest(kind=kind):
                incomplete = [row for row in events if row["type"] != kind]
                self.assertIsNone(request_accounting(incomplete, run)["actual_total_model_requests"])
        events, run = accounting()
        events[1]["data"]["tokens"] = None
        self.assertIsNone(request_accounting(events, run)["actual_total_model_requests"])

    def test_title_after_finalization_or_reset_deadline_fails(self):
        arm = {"started_epoch": 1000, "deadline_epoch": 1120, "started_monotonic": 100, "deadline_monotonic": 220}
        run = {"started_epoch_ms": 1000000, "deadline_epoch_ms": 1120000, "finished_epoch_ms": 1005000,
               "title_terminal_event": {"ts": "1970-01-01T00:16:44+00:00"}}
        self.assertTrue(time_acceptance(run, arm)[0])
        run["title_terminal_event"]["ts"] = "1970-01-01T00:16:46+00:00"
        self.assertFalse(time_acceptance(run, arm)[0])
        run["deadline_epoch_ms"] += 1000
        self.assertFalse(time_acceptance(run, arm)[0])

    def test_primary_seven_rejected_even_without_title_request(self):
        events, run = accounting(request_count=7)
        terminal = {"type": "x/host/session-title", "data": {"status": "failed", "reason": "budget"}}
        events = [row for row in events if row["type"] != "x/host/session-title"
                  and not (row["type"] == "cost/ledger" and row["data"]["purpose"] == "title")] + [terminal]
        run.pop("title_request_event")
        run.update(title_terminal_event=terminal, model_requests_including_title=7)
        result = request_accounting(events, run)
        self.assertEqual(result["main_model_requests"], 7)
        self.assertEqual(result["native_title_requests"], 0)
        self.assertEqual(result["observed_total_model_requests"], 7)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_eight_combined_requests_rejected(self):
        events, run = accounting(request_count=7)
        result = request_accounting(events, run)
        self.assertEqual(result["observed_total_model_requests"], 8)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_six_primary_and_one_title_accepts_exact_new_ceiling(self):
        events, run = accounting(request_count=6)
        result = request_accounting(events, run)
        self.assertEqual(result["main_model_requests"], 6)
        self.assertEqual(result["native_title_requests"], 1)
        self.assertEqual(result["actual_total_model_requests"], 7)


if __name__ == "__main__":
    unittest.main()
