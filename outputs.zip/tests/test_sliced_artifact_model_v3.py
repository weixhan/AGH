import copy
import hashlib
import json
from pathlib import Path
import sys
import shutil
from uuid import uuid4
import unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.verify_sliced_artifact_model_v3 import check_ledger, compact, projected, valid, final_value, UNKNOWN, SOURCE_TASK, check_binding, digest, REQUIRED_CHECKS, PRIMARY_SHA256

def fixture():
    task = '1c68e87faed946d490a5ad802186146a'
    metrics = {'mAP50': .4, 'mAP50_95': .16, 'tp': 231, 'fp': 149, 'fn': 365,
      'precision': .6, 'recall': .38, 'normal_fp_images': 5, 'normal_image_fp_rate': .02, 'normal_fp_boxes': 6}
    disk = {'status': 'completed', 'task_id': task, 'tool': 'verify_sliced_artifact_recovery', 'summary': {
      'slicing_status': 'passed', 'candidate_status': 'stop', 'source_original_status': 'failed',
      'source_computation_task_id': SOURCE_TASK, 'operation_kind': 'artifact_only_recovery',
      'artifact_recovery_status': 'passed', 'new_detection_inference_performed': False,
      'original_final_review_completed_within_1800_seconds': False, 'original_completion_absent': True,
      'reference_reused': True, 'input_hashes_unchanged': True, 'training_performed': False,
      'test_inference_performed': False, 'baseline': metrics, 'sliced': copy.deepcopy(metrics),
      'medium': {'gt': 77, 'images': 74, 'medium_tp_gain': 5, 'medium_gain_images': 5, 'medium_recovered_gt': 5, 'medium_lost_gt': 0},
      'failed_gates': ['overall_fp']}, 'evidence': {'report': 'sealed-report'}}
    workspace = 'E:/fixture/workspace'
    policy = {'schema_version': 1, 'workspace_root': '<workspace>', 'task_id': task,
      'qualified_status_tool': 'mcp_defect_researcher_45e5cef9_get_task_status', 'max_status_calls': 1}
    ext = 'ext:plugin/@defect-researcher/sliced-artifact-scope-guard'
    prefix = 'plugin/sliced-artifact-scope-guard'
    final = '已读取。\n```json\n' + json.dumps(compact(disk)) + '\n```'
    rows = [
      {'type': 'session/start', 'data': {'key': 'new-session'}},
      {'type': prefix+'/scope-ready', 'origin': ext, 'data': {'session_key': 'new-session', 'workspace_root': '<workspace>', 'mode': 'artifact-recovery', 'policy': policy}},
      {'type': 'request/sent', 'data': {}},
      {'type': 'cost/ledger', 'data': {'purpose': 'inference', 'model': 'agnes-3.0-flash', 'response': {'status': 200}}},
      {'type': 'tool/call', 'origin': 'model', 'data': {'toolUseId': 'call-1', 'name': policy['qualified_status_tool'], 'args': {'task_id': task}}},
      {'type': prefix+'/scope-decision', 'origin': ext, 'data': {'session_key': 'new-session', 'name': policy['qualified_status_tool'], 'tool_use_id': 'call-1', 'allow': True, 'reason': None}},
      {'type': 'tool/result', 'sourceEventSeqs': [5], 'data': {'toolUseId': 'call-1', 'isError': False, 'code': 'OK', 'content': [{'type': 'text', 'text': json.dumps(disk)}]}},
      {'type': 'assistant/message', 'data': {'content': [{'type': 'text', 'text': final}]}},
      {'type': 'turn/end', 'data': {'reason': 'completed', 'lastAssistantSeq': 8}},
    ]
    for index, row in enumerate(rows, 1): row['seq'] = index
    sdk_ready = copy.deepcopy(rows[1]); sdk_ready['data']['workspace_root'] = workspace; sdk_ready['data']['policy']['workspace_root'] = workspace
    runner = {'session_id': 'new-session', 'status': 'completed', 'scope_ready': sdk_ready, 'permissions': [],
      'calls': [{'seq': 5, 'origin': 'model', **rows[4]['data']}], 'hook_events': [copy.deepcopy(rows[5])],
      'results': [{'seq': 7, 'payload': copy.deepcopy(disk), 'is_error': False}],
      'final_texts': [copy.deepcopy(rows[7])], 'final_json': compact(disk),
      'source_execution_reclassified': False, 'new_detection_inference_performed': False,
      'new_model_inference_performed': True, 'tool_catalog_narrowed': False}
    return rows, runner, disk, workspace

class ArtifactModelLedgerTests(unittest.TestCase):
    def test_valid_one_read(self):
        f = fixture(); report = check_ledger(*f)
        self.assertTrue(all(report['checks'].values()), report['checks'])
    def assert_rejected(self, change, key=None):
        f = fixture(); change(*f); report = check_ledger(*f)
        self.assertFalse(all(report['checks'].values()))
        if key: self.assertFalse(report['checks'][key])
    def test_gap(self):
        self.assert_rejected(lambda r,s,d,w: r[2].update(seq=20), 'official_ledger_contiguous')
    def test_second_tool_attempt(self):
        self.assert_rejected(lambda r,s,d,w: r.append({'seq': 10, 'type':'tool/call', 'origin':'model','data':{'name':'shell'}}), 'exactly_one_model_status_read')
    def test_wrong_task(self):
        self.assert_rejected(lambda r,s,d,w: r[4]['data']['args'].update(task_id='f'*32), 'only_fixed_recovered_task_argument')
    def test_extra_argument(self):
        self.assert_rejected(lambda r,s,d,w: r[4]['data']['args'].update(resume=True), 'only_fixed_recovered_task_argument')
    def test_shell_instead(self):
        self.assert_rejected(lambda r,s,d,w: r[4]['data'].update(name='shell'), 'exactly_one_model_status_read')
    def test_gate_after_result(self):
        self.assert_rejected(lambda r,s,d,w: r[5].update(seq=8), 'paired_gate_allowed_between_call_and_result')
    def test_denied_gate(self):
        self.assert_rejected(lambda r,s,d,w: r[5]['data'].update(allow=False), 'paired_gate_allowed_between_call_and_result')
    def test_scope_not_ready_before_request(self):
        self.assert_rejected(lambda r,s,d,w: r[1].update(seq=4), 'scope_ready_before_first_model_request')
    def test_unpinned_workspace(self):
        self.assert_rejected(lambda r,s,d,w: s['scope_ready']['data'].update(workspace_root='E:/wrong'), 'public_sdk_ready_exact_event_and_workspace')
    def test_result_pair(self):
        self.assert_rejected(lambda r,s,d,w: r[6].update(sourceEventSeqs=[3]), 'single_result_paired_after_call')
    def test_sdk_number_tamper(self):
        self.assert_rejected(lambda r,s,d,w: s['results'][0]['payload']['summary']['sliced'].update(fp=100), 'public_sdk_exact_full_summary_and_evidence')
    def test_sdk_final_tamper(self):
        self.assert_rejected(lambda r,s,d,w: s['final_json']['sliced'].update(fp=100), 'public_sdk_final_compact_exact_unmasked')
    def test_source_success_misclassification(self):
        self.assert_rejected(lambda r,s,d,w: d['summary'].update(source_original_status='completed'), 'completed_artifact_recovery_preserves_source_failure')
    def test_new_detection_false_boundary(self):
        self.assert_rejected(lambda r,s,d,w: s.update(new_detection_inference_performed=True), 'no_detector_inference_or_training_in_model_read')
    def test_model_provider(self):
        self.assert_rejected(lambda r,s,d,w: r[3]['data'].update(model='other'), 'model_request_real_agnes_success')
    def test_export_failure(self):
        self.assert_rejected(lambda r,s,d,w: s.update(export_failure={'type':'error'}), 'host_runner_completed_without_export_failure')
    def test_optional_exact_allow_once(self):
        rows, runner, disk, workspace = fixture()
        approval={'seq':7,'type':'approval/decided','data':{'verdict':'allowed-once','scope':'tool:mcp_defect_researcher_45e5cef9_get_task_status:execute'}}
        for row in rows[6:]: row['seq']+=1
        rows[8]['data']['lastAssistantSeq']=9
        rows.insert(6,approval)
        runner['results'][0]['seq']=8; runner['final_texts'][0]['seq']=9
        runner['permissions']=[{'tool':'mcp_defect_researcher_45e5cef9_get_task_status','input':{'task_id':disk['task_id']},'tool_call_id':'call-1','decision':'allowed-once'}]
        self.assertTrue(all(check_ledger(rows,runner,disk,workspace)['checks'].values()))
        runner['permissions'][0]['decision']='allowed-always'
        self.assertFalse(check_ledger(rows,runner,disk,workspace)['checks']['optional_status_allow_once_exact_budget'])

class ArtifactCompactTests(unittest.TestCase):
    def test_known_count_cannot_be_bool(self):
        value=compact(fixture()[2]); value['sliced']['tp']=True
        self.assertFalse(valid(value))
    def test_masked_decimal_unknown_only(self):
        expected=compact(fixture()[2]); value=copy.deepcopy(expected); value['sliced']['mAP50']=UNKNOWN
        self.assertTrue(projected(value,expected,[['sliced','mAP50']]))
        self.assertEqual(value['sliced']['mAP50'],UNKNOWN)
        value['sliced']['tp']=UNKNOWN
        self.assertFalse(projected(value,expected,[['sliced','tp']]))
    def test_masked_status_invalid(self):
        value=compact(fixture()[2]); value['candidate_status']=UNKNOWN
        self.assertFalse(valid(value,[['candidate_status']]))
    def test_duplicate_final_json_block(self):
        text='```json\n'+json.dumps(compact(fixture()[2]))+'\n```'
        self.assertIsNone(final_value(text+'\n'+text)[0])

class ArtifactReviewBindingTests(unittest.TestCase):
    def setUp(self):
        self.output = (ROOT / 'outputs' / 'artifact-model-v3-binding-tests' / uuid4().hex).resolve()
        self.output.mkdir(parents=True)
        self.disk = fixture()[2]; self.task_id = self.disk['task_id']; self.task_dir = self.output / self.task_id
        self.task_dir.mkdir(); self.source_dir = self.output / SOURCE_TASK; self.source_dir.mkdir()
        self.disk['summary'].update(new_formal_calls=0,new_warmup_calls=0,new_gpu_seconds=0)
        self.independent = {'status':'passed','passed_checks':len(REQUIRED_CHECKS),'total_checks':len(REQUIRED_CHECKS),'checks':{key:True for key in REQUIRED_CHECKS},
          'task_id':self.task_id,'computation_task_id':SOURCE_TASK,'original_business_status':'failed',
          'original_completion_absent':True,'original_pipeline_acceptance_passed':False,
          'kind':'saved_sliced_artifact_recovery_review','schema_version':1,'prepublication':True,'model_used':False,
          'gpu_inference_performed_by_reviewer':False,'new_predict_calls':0,'new_gpu_calls':0,'new_gpu_seconds':0,
          'independent_reviewer_sha256':digest(ROOT/'tools'/'verify_sliced_artifact_recovery.py'),
          'primary_scientific_verifier_sha256':PRIMARY_SHA256}
        self.save(self.source_dir/'failure.json',{'status':'failed','task_id':SOURCE_TASK,'summary':self.disk['summary']})
        self.save(self.task_dir/'recovery_source_manifest.json',{'computation_task_id':SOURCE_TASK,'files':[]})
        self.save(self.task_dir/'recovery_protocol.json',{'operation_kind':'artifact_only_recovery','artifact_review_implementation_version':3})
        self.independent.update(source_failure_sha256=digest(self.source_dir/'failure.json'),
          source_manifest_sha256=digest(self.task_dir/'recovery_source_manifest.json'),
          task_protocol_sha256=digest(self.task_dir/'recovery_protocol.json'),verified_source_summary=copy.deepcopy(self.disk['summary']))
        self.independent['verified_source_summary_sha256']=hashlib.sha256(json.dumps(self.disk['summary'],sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')).hexdigest()
        self.save(self.task_dir/'independent_verification.json',self.independent)
        self.disk['evidence']={'source_failure_sha256':digest(self.source_dir/'failure.json'),
          'source_manifest_sha256':digest(self.task_dir/'recovery_source_manifest.json'),
          'independent_verification_sha256':digest(self.task_dir/'independent_verification.json')}
        self.save(self.task_dir/'recovery_result.json',self.disk)
        self.manifest = {'task_id':self.task_id,'tool':'verify_sliced_artifact_recovery','status':'completed','files':[]}
        for name in ['recovery_result.json','recovery_source_manifest.json','independent_verification.json','recovery_protocol.json']:
            p=self.task_dir/name; self.manifest['files'].append({'name':name,'path':str(p),'size_bytes':p.stat().st_size,'sha256':digest(p)})
        self.reseal()
    def save(self,path,value):
        path.write_text(json.dumps(value),encoding='utf-8')
    def reseal(self):
        self.save(self.task_dir/'artifact_manifest.json',self.manifest)
        self.save(self.task_dir/'completion.json',{'status':'completed','task_id':self.task_id,'tool':'verify_sliced_artifact_recovery',
          'artifact_manifest_sha256':digest(self.task_dir/'artifact_manifest.json'),
          'artifacts_sha256':{x['name']:x['sha256'] for x in self.manifest['files']}})
    def tearDown(self):
        assert self.output.is_relative_to((ROOT/'outputs'/'artifact-model-v3-binding-tests').resolve())
        shutil.rmtree(self.output)
    def review(self): return check_binding(self.independent,self.task_dir,self.output,self.task_id,self.disk)
    def test_sealed_complete_binding(self):
        report=self.review(); self.assertTrue(report['passed'],report)
    def test_bool_review_count_rejected(self):
        self.independent['passed_checks']=True
        self.assertFalse(self.review()['checks']['full_scientific_review_passed_typed_nonzero_counts'])
    def test_wrong_review_task_rejected(self):
        self.independent['task_id']='f'*32
        self.assertFalse(self.review()['checks']['full_review_same_recovery_and_original_computation'])
    def test_missing_required_scientific_check_rejected(self):
        self.independent['checks'].pop(next(iter(REQUIRED_CHECKS)))
        self.independent['passed_checks']=self.independent['total_checks']=len(self.independent['checks'])
        self.assertFalse(self.review()['checks']['full_scientific_review_all_checks_true'])
    def test_wrong_kind_rejected(self):
        self.independent['kind']='independent_saved_slicing_artifact_recovery'
        self.assertFalse(self.review()['checks']['full_review_exact_kind_and_zero_new_computation_contract'])
    def test_changed_saved_review_rejected(self):
        self.save(self.task_dir/'independent_verification.json',{'status':'passed','invented':True})
        self.assertFalse(self.review()['checks']['all_sealed_artifacts_current_bytes_unchanged'])
    def test_duplicate_manifest_file_rejected(self):
        self.manifest['files'].append(self.manifest['files'][0]); self.reseal()
        self.assertFalse(self.review()['checks']['binding_files_readable_and_safe'])
    def test_manipulated_manifest_path_rejected(self):
        self.manifest['files'][0]['path']=str(self.output/'elsewhere'); self.reseal()
        self.assertFalse(self.review()['checks']['all_sealed_artifacts_current_bytes_unchanged'])
    def test_original_completion_must_stay_absent(self):
        self.save(self.source_dir/'completion.json',{'status':'completed'})
        self.assertFalse(self.review()['checks']['original_actual_failure_remains_failed_without_completion'])
    def test_source_failure_hash_tamper_rejected(self):
        self.disk['evidence']['source_failure_sha256']='0'*64
        self.assertFalse(self.review()['checks']['result_source_failure_hash_matches_current_original'])
    def test_summarized_science_changed_rejected(self):
        self.disk['summary']['sliced']['fp']=0
        self.assertFalse(self.review()['checks']['recovered_science_exact_original_saved_complete_cohort_summary'])
    def test_false_zero_budget_bool_rejected(self):
        self.disk['summary']['new_formal_calls']=False
        self.assertFalse(self.review()['checks']['new_artifact_operation_gpu_and_call_budgets_are_zero'])
    def test_original_deadline_not_reclassified(self):
        self.disk['summary']['original_final_review_completed_within_1800_seconds']=True
        self.assertFalse(self.review()['checks']['old_final_review_deadline_not_reclassified'])

if __name__=='__main__': unittest.main()
