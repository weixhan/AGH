"""New artifact-review boundaries; no production inference or model is invoked."""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import random
import shutil
from contextlib import redirect_stdout
import io
import time
import unittest
import uuid
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("artifact_recovery_evidence", ROOT / "tools" / "verify_sliced_artifact_recovery.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)


@contextmanager
def scratch():
    output = ROOT / "outputs"
    directory = output / f"artifact-recovery-evidence-test-{uuid.uuid4().hex}"
    directory.mkdir()
    try:
        yield directory
    finally:
        if directory.resolve().parent != output.resolve() or not directory.name.startswith("artifact-recovery-evidence-test-"):
            raise ValueError("Unsafe scratch cleanup")
        shutil.rmtree(directory)


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def source_snapshot(directory):
    return {"schema_version": 1, "origin_task_id": directory.name, "source_directory": str(directory.resolve()),
        "files": [{"relative_path": p.relative_to(directory).as_posix(), "size_bytes": p.stat().st_size,
                   "sha256": reviewer.digest(p)} for p in sorted(directory.rglob("*")) if p.is_file()],
        "file_count": sum(p.is_file() for p in directory.rglob("*")), "original_completion_absent": True}


def protocol_fixture(root):
    original, new = root / reviewer.ORIGIN_ID, root / ("b" * 32)
    original.mkdir()
    new.mkdir()
    save(original / "failure.json", {"task_id": original.name, "status": "failed", "summary": {"candidate_status": "stop"}})
    save(original / "inputs.json", {"files": []})
    save(new / "recovery_source_manifest.json", source_snapshot(original))
    value = {"schema_version": 1, "protocol_id": reviewer.PROTOCOL_ID, "task_id": new.name,
        "artifact_review_implementation_version": 3,
        "computation_task_id": original.name, "source_computation_task_id": original.name,
        "execution_directory": str(original.resolve()), "original_business_status": "failed",
        "original_pipeline_acceptance_passed": False, "original_budget_reset": False,
        "original_completion_absent": True, "original_final_review_completed_within_1800_seconds": False,
        "new_predict_calls": 0, "new_gpu_calls": 0, "new_gpu_seconds": 0., "new_warmup_calls": 0,
        "new_detection_inference_performed": False, "nms_expected": None, "recovery_started_epoch": time.time(),
        "max_recovery_wall_seconds": 600, "independent_reviewer_sha256": reviewer.file_sha(Path(reviewer.__file__)),
        "producer_source_sha256": reviewer.file_sha(ROOT / "defect_researcher" / "sliced_artifact_recovery.py"),
        "source_failure_sha256": reviewer.digest(original / "failure.json"),
        "source_inputs_sha256": reviewer.digest(original / "inputs.json"),
        "source_manifest_sha256": reviewer.digest(new / "recovery_source_manifest.json")}
    return original, new, value


def summary_fixture():
    point = {"tp": 1, "fp": 0, "fn": 0, "precision": 1., "recall": 1.,
        "normal_images_with_false_positives": 0, "normal_image_fp_rate": 0., "ignored_unrelated_detail": 7}
    metric = {"mAP50": 1., "mAP50_95": 1., "operating_point": point}
    gains = {"medium_tp_gain": 0, "medium_gain_images": 0, "medium_recovered_gt": 0, "medium_lost_gt": 0}
    compact = {"mAP50": 1., "mAP50_95": 1., "tp": 1, "fp": 0, "fn": 0,
        "precision": 1., "recall": 1., "normal_fp_images": 0, "normal_image_fp_rate": 0., "normal_fp_boxes": 0}
    population = {"medium_gt": 1, "medium_images": 1}
    analysis = {"baseline_metrics": metric, "sliced_metrics": metric, "population": population, "gains": gains,
        "scientific_decision": {"status": "stop", "failed_gates": ["tp_gain"]},
        "normal_false_positives": {"baseline": {"fp_boxes": 0}, "sliced": {"fp_boxes": 0}}}
    budget = {"successful_observations": 1, "formal_calls": 1, "warmup_calls": 1,
        "gpu_seconds": .002, "inference_wall_seconds": .003}
    summary = {"baseline": deepcopy(compact), "sliced": deepcopy(compact), "candidate_status": "stop",
        "failed_gates": ["tp_gain"], "population": population, "gains": gains,
        "medium": {"gt": 1, "images": 1, **gains}, "input_files": 1, **budget}
    return summary, analysis, budget, [{}]


class ArtifactRecoveryEvidenceTests(unittest.TestCase):
    def test_scientific_functions_are_the_original_independent_objects(self):
        for name in ("metrics", "comparison", "map_predictions", "source_gt", "_budget_checks"):
            self.assertIs(getattr(reviewer, name), getattr(reviewer._P, name))
        self.assertEqual(reviewer.file_sha(reviewer.PRIMARY_PATH), reviewer.PRIMARY_SHA256)

    def test_fixed_required_contract_covers_science_journal_source_and_new_deadline(self):
        expected = {"baseline_independent_ap101_matches_old_and_new_saved",
            "sliced_independent_ap101_tp_fp_fn_normalfp_matches_saved",
            "frozen_crops_and_every_decoded_tile_pixel_hash",
            "independent_same_class_nms_strict_gt_point7_ties_maxdet_and_full_trace",
            "journal_v2_exact_sequence_and_sha256_chain", "journal_cumulative_cost_stays_within_original_frozen_limits",
            "original_pipeline_failure_preserved_and_completion_absent",
            "new_artifact_review_and_source_checks_within_separate_600_second_budget",
            "artifact_recovery_protocol_requires_zero_new_detector_and_gpu_calls",
            "same_actual_predictor_controls_strict_nms_null"}
        self.assertIsInstance(reviewer.REQUIRED_CHECKS, frozenset)
        self.assertEqual(len(reviewer.REQUIRED_CHECKS), 99)
        self.assertTrue(expected <= reviewer.REQUIRED_CHECKS)

    def test_new_reader_imports_no_production_scorer_or_detector(self):
        source = Path(reviewer.__file__).read_text(encoding="utf-8")
        for bad in ("from defect_researcher", "import torch", "YOLO(", ".predict("):
            self.assertNotIn(bad, source)
        self.assertNotIn("mock.patch", source)
        self.assertNotIn("_P.metrics =", source)
        self.assertNotIn("_P.iou =", source)
        self.assertNotIn("_P.expected_trace =", source)

    def test_null_nms_exact_baseline_matches(self):
        controls = {**reviewer.CONTROLS, "nms": None}
        self.assertTrue(reviewer.strict_external_nms(controls, deepcopy(controls)))

    def test_false_nms_is_not_equivalent_to_null(self):
        controls = {**reviewer.CONTROLS, "nms": None}
        for actual, reference in (({**controls, "nms": False}, controls), (controls, {**controls, "nms": False}),
                                  ({**controls, "nms": False}, {**controls, "nms": False})):
            self.assertFalse(reviewer.strict_external_nms(actual, reference))

    def test_missing_nms_is_not_laundered_as_null(self):
        controls = {**reviewer.CONTROLS, "nms": None}
        self.assertFalse(reviewer.strict_external_nms(reviewer.CONTROLS, controls))
        self.assertFalse(reviewer.strict_external_nms(controls, reviewer.CONTROLS))

    def test_other_frozen_predictor_control_mismatch_is_refused(self):
        controls = {**reviewer.CONTROLS, "nms": None}
        self.assertFalse(reviewer.strict_external_nms({**controls, "conf": .25}, controls))
        self.assertFalse(reviewer.strict_external_nms({**controls, "batch": True}, controls))

    def test_valid_protocol_preserves_failed_origin_and_separate_600_budget(self):
        with scratch() as root:
            old, new, value = protocol_fixture(root)
            self.assertTrue(reviewer.recovery_protocol_check(value, new.name, old.name, new, old))

    def reject_protocol(self, key, changed):
        with scratch() as root:
            old, new, value = protocol_fixture(root)
            value[key] = changed
            with self.assertRaises(ValueError):
                reviewer.recovery_protocol_check(value, new.name, old.name, new, old)

    def test_original_failed_state_cannot_be_promoted_to_success(self):
        self.reject_protocol("original_business_status", "completed")
        self.reject_protocol("original_pipeline_acceptance_passed", True)
        self.reject_protocol("original_final_review_completed_within_1800_seconds", True)

    def test_implementation_version_is_exact_int_three(self):
        for changed in (1, 2, 3., True, None):
            self.reject_protocol("artifact_review_implementation_version", changed)

    def test_original_budget_cannot_be_reset(self):
        self.reject_protocol("original_budget_reset", True)

    def test_false_or_missing_original_completion_claim_is_refused(self):
        self.reject_protocol("original_completion_absent", False)

    def test_inference_or_warmup_or_gpu_is_forbidden(self):
        for field in ("new_predict_calls", "new_gpu_calls", "new_gpu_seconds", "new_warmup_calls"):
            with self.subTest(field=field):
                self.reject_protocol(field, 1)
        self.reject_protocol("new_detection_inference_performed", True)

    def test_boolean_cannot_replace_zero_or_seconds(self):
        for field in ("new_predict_calls", "new_gpu_calls", "new_gpu_seconds", "new_warmup_calls"):
            with self.subTest(field=field):
                self.reject_protocol(field, False)

    def test_nms_null_protocol_cannot_be_false(self):
        self.reject_protocol("nms_expected", False)

    def test_review_budget_cannot_be_relaxed_or_bool(self):
        self.reject_protocol("max_recovery_wall_seconds", 601)
        self.reject_protocol("max_recovery_wall_seconds", True)

    def test_elapsed_new_review_budget_cannot_be_reset(self):
        self.reject_protocol("recovery_started_epoch", time.time() - 601)

    def test_reviewer_and_producer_sources_are_hash_bound(self):
        self.reject_protocol("independent_reviewer_sha256", "0" * 64)
        self.reject_protocol("producer_source_sha256", "0" * 64)

    def test_original_failure_inputs_and_snapshot_are_hash_bound(self):
        for field in ("source_failure_sha256", "source_inputs_sha256", "source_manifest_sha256"):
            with self.subTest(field=field):
                self.reject_protocol(field, "0" * 64)

    def test_complete_source_snapshot_is_readonly(self):
        with scratch() as root:
            old, _, _ = protocol_fixture(root)
            snapshot = source_snapshot(old)
            before = {p: p.read_bytes() for p in old.rglob("*") if p.is_file()}
            self.assertTrue(reviewer.source_manifest_check(old, snapshot, old.name))
            self.assertEqual(before, {p: p.read_bytes() for p in old.rglob("*") if p.is_file()})

    def test_resealed_snapshot_subset_is_not_complete(self):
        with scratch() as root:
            old, _, _ = protocol_fixture(root)
            snapshot = source_snapshot(old)
            snapshot["files"].pop()
            snapshot["file_count"] -= 1
            with self.assertRaisesRegex(ValueError, "omits"):
                reviewer.source_manifest_check(old, snapshot, old.name)

    def test_snapshot_duplicate_and_added_file_are_refused(self):
        with scratch() as root:
            old, _, _ = protocol_fixture(root)
            snapshot = source_snapshot(old)
            snapshot["files"].append(deepcopy(snapshot["files"][0]))
            snapshot["file_count"] += 1
            with self.assertRaises(ValueError):
                reviewer.source_manifest_check(old, snapshot, old.name)
            snapshot = source_snapshot(old)
            save(old / "extra.json", {})
            with self.assertRaises(ValueError):
                reviewer.source_manifest_check(old, snapshot, old.name)

    def test_source_mutation_during_review_is_refused(self):
        with scratch() as root:
            old, _, _ = protocol_fixture(root)
            snapshot = source_snapshot(old)
            save(old / "failure.json", {"status": "completed"})
            with self.assertRaisesRegex(ValueError, "bytes changed"):
                reviewer.source_manifest_check(old, snapshot, old.name)

    def test_even_resealed_original_completion_is_refused(self):
        with scratch() as root:
            old, _, _ = protocol_fixture(root)
            save(old / "completion.json", {"status": "completed"})
            snapshot = source_snapshot(old)
            with self.assertRaisesRegex(ValueError, "completion"):
                reviewer.source_manifest_check(old, snapshot, old.name)

    def test_compact_summary_has_exact_original_ten_metric_fields(self):
        summary, analysis, budget, rows = summary_fixture()
        self.assertTrue(all(reviewer.summary_checks(summary, analysis, budget, rows).values()))
        self.assertEqual(len(summary["baseline"]), 10)
        self.assertNotIn("ignored_unrelated_detail", summary["baseline"])

    def test_forged_ap_fp_and_branch_are_rejected(self):
        for key, changed in (("mAP50", .9), ("normal_fp_boxes", 1), ("tp", True)):
            with self.subTest(key=key):
                summary, analysis, budget, rows = summary_fixture()
                summary["sliced"][key] = changed
                self.assertFalse(all(reviewer.summary_checks(summary, analysis, budget, rows).values()))
        summary, analysis, budget, rows = summary_fixture()
        summary["candidate_status"] = "accepted"
        self.assertFalse(all(reviewer.summary_checks(summary, analysis, budget, rows).values()))

    def test_medium_denominator_and_calls_cannot_be_forged(self):
        summary, analysis, budget, rows = summary_fixture()
        summary["medium"]["gt"] = 4
        self.assertFalse(all(reviewer.summary_checks(summary, analysis, budget, rows).values()))
        summary, analysis, budget, rows = summary_fixture()
        summary["gpu_seconds"] = 0.
        self.assertFalse(all(reviewer.summary_checks(summary, analysis, budget, rows).values()))

    def test_one_true_resealed_report_cannot_match_required_checks(self):
        self.assertNotEqual({"one": True}.keys(), reviewer.REQUIRED_CHECKS)
        self.assertNotEqual((reviewer.REQUIRED_CHECKS - {next(iter(reviewer.REQUIRED_CHECKS))}), reviewer.REQUIRED_CHECKS)


def global_observations(values):
    """Pure synthetic NMS candidates, never detector or real dataset output."""
    return [{"pass_id": pi, "global_predictions": [{**p, "pass_id": pi, "prediction_index": index}
        for index, p in enumerate(predictions)]} for pi, predictions in enumerate(values)]


def prediction(box, confidence=.5, class_id=0):
    return {"class_id": class_id, "confidence": confidence, "xyxy": list(box)}


def failed_schema_fixture():
    evidence = {"source_task_id": "sealed_baseline", "diagnosis_task_id": "sealed_diagnosis",
        "source_completion_sha256": "1" * 64, "source_manifest_sha256": "2" * 64,
        "source_predictions_sha256": "3" * 64, "diagnosis_completion_sha256": "4" * 64,
        "protocol_sha256": "5" * 64, "evidence_id": f"sliced:{reviewer.ORIGIN_ID}:hybrid640",
        "execution_source_sha256": "6" * 64, "independent_verification_path": "sealed_original_review_path"}
    failure = {"task_id": reviewer.ORIGIN_ID, "tool": "compare_validation_slices", "status": "failed",
        "evidence": deepcopy(evidence)}
    return failure, evidence


class FailedSourceArtifactSchemaTests(unittest.TestCase):
    def check(self, directory, failure, evidence):
        values = reviewer.failed_artifact_schema_subchecks(failure, evidence, reviewer.ORIGIN_ID, directory)
        self.assertTrue(all(type(value) is bool for value in values.values()))
        return all(values.values())

    def test_complete_nested_failed_schema_with_no_publication_passes(self):
        with scratch() as directory:
            failure, evidence = failed_schema_fixture()
            self.assertEqual(len(evidence), 10)
            self.assertTrue(self.check(directory, failure, evidence))

    def test_nested_missing_any_of_ten_bindings_is_refused(self):
        with scratch() as directory:
            for key in failed_schema_fixture()[1]:
                with self.subTest(key=key):
                    failure, evidence = failed_schema_fixture()
                    del failure["evidence"][key]
                    self.assertFalse(self.check(directory, failure, evidence))

    def test_empty_or_extra_nested_evidence_is_refused(self):
        with scratch() as directory:
            failure, evidence = failed_schema_fixture()
            failure["evidence"] = {}
            self.assertFalse(self.check(directory, failure, evidence))
            failure, evidence = failed_schema_fixture()
            failure["evidence"]["unexpected_replacement_identity"] = "forged"
            self.assertFalse(self.check(directory, failure, evidence))

    def test_each_forged_nested_binding_is_refused(self):
        with scratch() as directory:
            for key in failed_schema_fixture()[1]:
                with self.subTest(key=key):
                    failure, evidence = failed_schema_fixture()
                    failure["evidence"][key] = "wrong"
                    self.assertFalse(self.check(directory, failure, evidence))

    def test_flat_success_candidate_cannot_stand_in_for_failed_report(self):
        with scratch() as directory:
            failure, evidence = failed_schema_fixture()
            failure.pop("evidence")
            failure.update(evidence)
            self.assertFalse(self.check(directory, failure, evidence))
            failure["status"] = "completed"
            self.assertFalse(self.check(directory, failure, evidence))

    def test_nested_bindings_do_not_allow_extra_flat_marker_claims(self):
        with scratch() as directory:
            for key in (*failed_schema_fixture()[1], "artifact_manifest", "artifact_manifest_sha256", "artifacts_sha256"):
                with self.subTest(key=key):
                    failure, evidence = failed_schema_fixture()
                    failure[key] = evidence.get(key, "fake_marker")
                    self.assertFalse(self.check(directory, failure, evidence))

    def test_wrong_task_tool_status_and_nonobject_are_refused(self):
        with scratch() as directory:
            for key, value in (("task_id", "wrong"), ("tool", "wrong"), ("status", "completed"), ("status", True)):
                with self.subTest(key=key):
                    failure, evidence = failed_schema_fixture()
                    failure[key] = value
                    self.assertFalse(self.check(directory, failure, evidence))
            self.assertFalse(self.check(directory, None, failed_schema_fixture()[1]))

    def test_any_original_published_success_artifact_is_refused_even_if_forged(self):
        with scratch() as directory:
            failure, evidence = failed_schema_fixture()
            for name in ("completion.json", "completion_candidate.json", "artifact_manifest.json", "sliced_result.json"):
                with self.subTest(name=name):
                    path = directory / name
                    save(path, {"task_id": reviewer.ORIGIN_ID, "status": "completed", **evidence})
                    self.assertFalse(self.check(directory, failure, evidence))
                    path.unlink()
            self.assertTrue(self.check(directory, failure, evidence))


class ArtifactRecoveryPerformanceTests(unittest.TestCase):
    def assert_trace_exact(self, observations):
        expected = reviewer._P.expected_trace(deepcopy(observations))
        actual = reviewer.expected_trace(observations)
        self.assertEqual(actual, expected)
        return actual

    def test_unique_resolved_paths_hash_once_in_a_boundary(self):
        with scratch() as directory:
            path = directory / "bytes.bin"
            path.write_bytes(b"fresh SHA bytes")
            boundary = reviewer.FreshHashBoundary()
            expected = hashlib.sha256(path.read_bytes()).hexdigest()
            for _ in range(10):
                self.assertEqual(boundary.digest(path), expected)
                self.assertEqual(boundary.digest(directory / "." / "bytes.bin"), expected)
                self.assertEqual(boundary.size(path), 15)
            self.assertEqual(boundary.measurements(), {"unique_files_hashed": 1, "bytes_read": 15})

    def test_after_boundary_reads_fresh_sha_even_if_same_size_and_mtime(self):
        with scratch() as directory:
            path = directory / "bytes.bin"
            path.write_bytes(b"before")
            before = reviewer.FreshHashBoundary()
            old_sha = before.digest(path)
            stamp = path.stat()
            path.write_bytes(b"change")
            os.utime(path, ns=(stamp.st_atime_ns, stamp.st_mtime_ns))
            self.assertEqual(path.stat().st_size, 6)
            self.assertEqual(path.stat().st_mtime_ns, stamp.st_mtime_ns)
            after = reviewer.FreshHashBoundary()
            self.assertNotEqual(after.digest(path), old_sha)
            self.assertEqual(before.measurements(), after.measurements())
            self.assertEqual(after.measurements(), {"unique_files_hashed": 1, "bytes_read": 6})

    def test_parent_roles_share_boundary_reads_without_skipping_any_role(self):
        with scratch() as directory:
            paths = [directory / f"source-{index}.txt" for index in range(5)]
            for index, path in enumerate(paths):
                path.write_bytes(bytes([index]) * (index + 1))
            boundary = reviewer.FreshHashBoundary()
            roles = [str(path) for path in paths] + [str(path) for path in reversed(paths)]
            parent_roles = roles[:5]
            self.assertEqual(len([boundary.digest(path) for path in roles + parent_roles]), 15)
            self.assertEqual(boundary.measurements(), {"unique_files_hashed": 5, "bytes_read": 15})

    def test_before_and_after_manifest_rechecks_use_separate_fresh_cache(self):
        with scratch() as directory:
            old, _, _ = protocol_fixture(directory)
            saved = source_snapshot(old)
            before, after = reviewer.FreshHashBoundary(), reviewer.FreshHashBoundary()
            self.assertTrue(reviewer.source_manifest_check(old, saved, old.name, boundary=before))
            self.assertTrue(reviewer.source_manifest_check(old, saved, old.name, boundary=after))
            self.assertEqual(before.measurements(), after.measurements())
            self.assertEqual(before.measurements()["unique_files_hashed"], 2)
            save(old / "inputs.json", {"files": ["mutated"]})
            with self.assertRaisesRegex(ValueError, "bytes changed"):
                reviewer.source_manifest_check(old, saved, old.name, boundary=reviewer.FreshHashBoundary())

    def test_scope_cache_does_not_accept_outside_file(self):
        with scratch() as directory:
            inside = directory / "inside"
            inside.mkdir()
            path = directory / "outside.txt"
            path.write_text("data")
            boundary = reviewer.FreshHashBoundary()
            with self.assertRaisesRegex(ValueError, "outside scope"):
                boundary.scoped_file(path, [inside])

    def test_cached_publication_rules_exact_to_original_integrity_oracle(self):
        with scratch() as directory:
            path = directory / "artifact.json"
            save(path, {"value": 17})
            row = {"name": path.name, "path": str(path), "size_bytes": path.stat().st_size,
                "sha256": reviewer.digest(path)}
            manifest_path = directory / "artifact_manifest.json"
            manifest = {"task_id": "fake", "tool": "fake_tool", "status": "completed", "files": [row]}
            save(manifest_path, manifest)
            marker = {"task_id": "fake", "tool": "fake_tool", "status": "completed",
                "artifact_manifest": str(manifest_path), "artifact_manifest_sha256": reviewer.digest(manifest_path),
                "artifacts_sha256": {path.name: row["sha256"]}}
            save(directory / "completion.json", marker)
            for mutate in (None, "status", "files", "artifact_manifest_sha256", "artifacts_sha256", "early_marker"):
                with self.subTest(mutate=mutate):
                    changed_manifest, changed_marker = deepcopy(manifest), deepcopy(marker)
                    if mutate == "status":
                        changed_marker["status"] = "failed"
                    elif mutate == "files":
                        changed_manifest["files"].append(deepcopy(row))
                    elif mutate == "artifact_manifest_sha256":
                        changed_marker["artifact_manifest_sha256"] = "0" * 64
                    elif mutate == "artifacts_sha256":
                        changed_marker["artifacts_sha256"] = {}
                    save(manifest_path, changed_manifest)
                    if mutate != "artifact_manifest_sha256":
                        changed_marker["artifact_manifest_sha256"] = reviewer.digest(manifest_path)
                    save(directory / "completion.json", changed_marker)
                    if mutate == "early_marker":
                        stamp = manifest_path.stat().st_mtime_ns - 100_000_000
                        os.utime(directory / "completion.json", ns=(stamp, stamp))
                    boundary = reviewer.FreshHashBoundary()
                    self.assertEqual(boundary.publication(directory, "fake", "fake_tool", {path.name}),
                        reviewer._P.publication(directory, "fake", "fake_tool", {path.name}))

    def test_empty_and_single_candidate_trace_exact(self):
        self.assert_trace_exact([])
        self.assert_trace_exact(global_observations([[prediction([0, 0, 1, 1])]]))

    def test_same_class_suppression_and_different_class_overlap_exact(self):
        values = [[prediction([0, 0, 20, 20], .9, 0), prediction([0, 0, 20, 20], .8, 1)],
            [prediction([1, 1, 20, 20], .8, 0), prediction([50, 50, 80, 80], .7, 0)]]
        _, trace = self.assert_trace_exact(global_observations(values))
        self.assertEqual(trace["suppressed_count"], 1)

    def test_confidence_ties_pass_then_prediction_index_and_zero_iou_exact(self):
        values = [[prediction([0, 0, 10, 10]), prediction([0, 0, 10, 10]), prediction([10, 0, 20, 10])],
            [prediction([0, 0, 10, 10]), prediction([30, 30, 40, 40])]]
        _, trace = self.assert_trace_exact(global_observations(values))
        self.assertEqual(trace["rows"][1]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})
        self.assertEqual(trace["rows"][3]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})

    def test_threshold_equal_and_nextafter_both_sides_scalar_decisions_exact(self):
        for width in (7., math.nextafter(7., -math.inf), math.nextafter(7., math.inf)):
            with self.subTest(width=width):
                box = [0., 0., width, 10.]
                scalar = reviewer._P.iou([0., 0., 10., 10.], box)
                _, trace = self.assert_trace_exact(global_observations([[prediction([0., 0., 10., 10.], .9),
                    prediction(box, .8)]]))
                self.assertEqual(trace["suppressed_count"], int(scalar > .7))
                if scalar > .7:
                    self.assertEqual(trace["rows"][1]["suppression_iou"], scalar)

    def test_original_local_global_edge_coordinates_stay_exact(self):
        observations = []
        for pass_id, crop in enumerate(reviewer.expected_crops()):
            width, height = crop[2] - crop[0], crop[3] - crop[1]
            values = [prediction([0, 0, width, height], .9, 0),
                prediction([width - 1, height - 1, width, height], .8, 1)]
            observations.append({"pass_id": pass_id,
                "global_predictions": reviewer.map_predictions(values, crop, pass_id)})
        self.assert_trace_exact(observations)

    def test_full_survivors_processed_before_max300_including_suppressed_tail(self):
        candidates = [prediction([i * 3, 0, i * 3 + 1, 1], 1 - i / 1000) for i in range(320)]
        candidates.append(prediction([319 * 3, 0, 319 * 3 + 1, 1], .001))
        predictions, trace = self.assert_trace_exact(global_observations([candidates]))
        self.assertEqual(len(predictions), 300)
        self.assertEqual(trace["nms_survivor_count"], 320)
        self.assertEqual(trace["global_max_det_discarded_count"], 20)
        self.assertEqual(trace["rows"][-1]["status"], "suppressed_iou")
        self.assertEqual(trace["rows"][-1]["suppressed_by"], {"pass_id": 0, "prediction_index": 319})

    def test_fixed_medium_randomized_traces_exact_to_original_scalar_oracle(self):
        for seed, per_pass in ((11, 40), (42, 70), (86, 100), (91, 45)):
            rng = random.Random(seed)
            observations = []
            for pass_id, crop in enumerate(reviewer.expected_crops()):
                width, height = crop[2] - crop[0], crop[3] - crop[1]
                values = []
                for index in range(per_pass):
                    left, top = rng.uniform(0, width - 40), rng.uniform(0, height - 40)
                    right, bottom = min(width, left + rng.uniform(1, 350)), min(height, top + rng.uniform(1, 350))
                    values.append(prediction([left, top, right, bottom], rng.choice((.001, .25, .5, .9)), rng.randrange(7)))
                    if index and index % 13 == 0:
                        values[-1] = deepcopy(values[-2])
                observations.append({"pass_id": pass_id,
                    "global_predictions": reviewer.map_predictions(values, crop, pass_id)})
            with self.subTest(seed=seed, candidates=9 * per_pass):
                self.assert_trace_exact(observations)

    def test_cross_class_comparisons_never_call_scalar_iou(self):
        stats = {}
        values = [[prediction([0, 0, 10, 10], .5, ci) for ci in range(7)]]
        observations = global_observations(values)
        self.assert_trace_exact(observations)
        reviewer.expected_trace(observations, stats=stats)
        self.assertEqual(stats, {"candidate_count": 7, "same_class_pairs": 0, "scalar_iou_calls": 0})

    def test_2700_synthetic_disjoint_candidates_exact_with_zero_scalar_iou(self):
        values = []
        for pi in range(9):
            predictions = []
            for index in range(300):
                position = pi * 300 + index
                x, y = (position % 90) * 20, (position // 90) * 20
                predictions.append(prediction([x, y, x + 8, y + 8], .5, position % 7))
            values.append(predictions)
        observations = global_observations(values)
        self.assert_trace_exact(observations)
        stats = {}
        reviewer.expected_trace(observations, stats=stats)
        self.assertEqual(stats["candidate_count"], 2700)
        self.assertEqual(stats["scalar_iou_calls"], 0)
        self.assertLess(stats["same_class_pairs"], 2700 * 2700 / 7)

    def test_five_metric_calls_replaced_by_original_comparison_plus_context_only(self):
        # Inspect orchestration rather than patching any frozen scientific oracle.
        import ast
        source = Path(reviewer.__file__).read_text(encoding="utf-8")
        tree = ast.parse(source)
        review = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "review_recovery")
        calls = [node for node in ast.walk(review) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)]
        self.assertEqual(sum(node.func.id == "comparison" for node in calls), 1)
        self.assertEqual(sum(node.func.id == "metrics" for node in calls), 1)
        self.assertIs(reviewer.comparison, reviewer._P.comparison)
        self.assertIs(reviewer.metrics, reviewer._P.metrics)

    def test_progress_flushes_phase_measurements_without_acceptance_claim(self):
        stream = io.StringIO()
        with redirect_stdout(stream):
            progress = reviewer.ReviewProgress("c" * 32)
            progress.begin("synthetic_phase")
            progress.emit("running", images_checked=80)
            progress.end(images_checked=160)
        rows = [json.loads(line) for line in stream.getvalue().splitlines()]
        self.assertEqual([row["status"] for row in rows], ["started", "running", "finished"])
        self.assertEqual(rows[1]["images_checked"], 80)
        self.assertGreaterEqual(progress.timings["synthetic_phase"], 0)
        self.assertTrue(all("checks" not in row and "completion" not in row for row in rows))


if __name__ == "__main__":
    unittest.main()
