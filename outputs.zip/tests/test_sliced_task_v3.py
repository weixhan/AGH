"""Isolated runner engineering fixtures; never production detector acceptance.

The fixture replaces the source loader and independent full-population oracle
only inside tests. It cannot demonstrate full640 or real two-image recovery.
"""
import copy
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from defect_researcher import sliced_task_v3 as runner
from defect_researcher import sliced_worker_v3 as worker
from defect_researcher import sliced_runtime_v3 as reader
from defect_researcher.audit import _artifact_record, _configured_paths, _sha256
from test_config import temporary_workspace
from test_sliced_task import fixture as legacy_fixture, FakeBackend


def fixture(root):
    configuration, protocol, source, frozen, old_loader = legacy_fixture(root)
    paths = _configured_paths(configuration)
    _, diagnosis, sources, _, records, environment = old_loader(paths, protocol)
    environment["actual_predictor_options"]["nms"] = None
    weight = paths["weights_path"]
    weight.write_bytes(b"isolated fake weight; no detector loads this file")
    protocol["weight_sha256"] = _sha256(weight)
    protocol["source_evidence_sha256"]["comparison/predictions_640.jsonl"] = _sha256(source / "predictions_640.jsonl")
    runner._write(source / "comparison_result.json", {"summary": {"environments": {"640": environment}}})
    sources.update(runner._execution_source_paths())
    sources.update({"fixture_weight": weight, "fixture_reference": source / "comparison_result.json"})
    before = {role: {**_artifact_record(path), "role": role} for role, path in sources.items()}

    def load_source(observed_paths, observed_protocol):
        if not runner._equal(observed_protocol, protocol) or observed_paths != paths:
            raise AssertionError("Only the isolated engineering fixture is accepted")
        for role, record in before.items():
            if _artifact_record(sources[role]) != {k: v for k, v in record.items() if k != "role"}:
                raise ValueError("Sealed fixture source bytes changed")
        return source, diagnosis, sources, before, copy.deepcopy(records), copy.deepcopy(environment)

    return configuration, protocol, load_source


def inline_worker(calls, mutate=None):
    def execute(directory, request, protocol):
        if mutate:
            mutate(request)
        runner._write(directory / runner.FILES["worker_request"], request)
        receipt = worker._execute(request, lambda value: FakeBackend(value, calls))
        if receipt["status"] != "completed":
            raise RuntimeError(str(receipt["error"]))
    return execute


def fixture_review(directory, result, output_path, remaining):
    if len(runner._rows(directory / runner.FILES["observations"])) != 18:
        raise AssertionError("Only a fake eighteen-pass fixture is accepted")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report = {"status": "passed", "task_id": result["task_id"], "passed_checks": 1, "total_checks": 1,
              "checks": {"isolated fixture only": True}, "prepublication": True,
              **runner._review_bindings(directory, result, "completion_candidate.json"),
              "acceptance_total_wall_seconds": result["summary"]["total_task_wall_seconds"] + 1}
    runner._write(output_path, report)
    return report


class RunnerV3Tests(unittest.TestCase):
    def prepare(self, root, mutate=None):
        configuration, protocol, loader = fixture(root)
        calls = []
        for context in (patch.object(runner, "_protocol", return_value=protocol),
                        patch.object(runner, "_load_source", side_effect=loader),
                        patch.object(runner, "_independent_review", side_effect=fixture_review),
                        patch.object(runner, "_run_worker", side_effect=inline_worker(calls, mutate))):
            context.start()
            self.addCleanup(context.stop)
        return configuration, protocol, calls

    def test_original_scientific_population_and_protocol_bytes_are_retained(self):
        protocol = runner._protocol()
        self.assertEqual(protocol["population"]["images"], 640)
        self.assertEqual(protocol["budgets"]["successful_observations"], 5760)
        self.assertEqual(_sha256(runner.PROTOCOL_PATH), runner.FROZEN_PROTOCOL_SHA256)
        self.assertEqual(runner.EXECUTION_VERSION, 3)
        self.assertEqual(runner.TOOL, "compare_validation_slices_v3")

    def test_isolated_null_controls_complete_and_sidecar_verifies_publication(self):
        with temporary_workspace() as root:
            configuration, _, calls = self.prepare(root)
            result = runner.run_sliced_comparison(configuration, "new-v3")
            self.assertEqual(result["status"], "completed", result["errors"])
            self.assertEqual(len(calls), 19)  # fake 18 formal + 1 warmup
            directory = Path(configuration["output_root"]) / "new-v3"
            request = runner._read(directory / "worker_request.json")
            self.assertEqual(request["execution_io_version"], 3)
            self.assertEqual(request["tool"], runner.TOOL)
            runner.validate_worker_request(request)
            runner.verify_sliced_artifacts(directory, result)
            verified = reader.get_task_status(configuration, "new-v3")
            self.assertEqual(verified["status"], "completed", verified.get("errors"))
            self.assertEqual(verified["summary"], result["summary"])
            self.assertEqual((directory / "completion.json").read_bytes(), (directory / "completion_candidate.json").read_bytes())

    def test_reference_nms_and_version_mutations_refuse_before_fake_predict(self):
        variations = ["missing", False, True, "None", "null", 0, "old-version", "bool-version", "string-version", "old-tool"]
        for variation in variations:
            with self.subTest(variation=variation), temporary_workspace() as root:
                def mutate(request):
                    if variation == "missing":
                        del request["reference_environment"]["actual_predictor_options"]["nms"]
                    elif variation == "old-version":
                        request["execution_io_version"] = 2
                    elif variation == "bool-version":
                        request["execution_io_version"] = True
                    elif variation == "string-version":
                        request["execution_io_version"] = "3"
                    elif variation == "old-tool":
                        request["tool"] = "compare_validation_slices"
                    else:
                        request["reference_environment"]["actual_predictor_options"]["nms"] = variation
                configuration, _, calls = self.prepare(root, mutate)
                result = runner.run_sliced_comparison(configuration, "refused-v3")
                self.assertEqual(result["status"], "failed")
                self.assertEqual(calls, [])
                self.assertFalse((Path(configuration["output_root"]) / "refused-v3/completion.json").exists())
                # Stop this fixture's patches before starting the next subtest.
                self.doCleanups()

    def test_record_and_image_hash_mutations_refuse_before_fake_predict(self):
        for variation in ("records", "image_hash", "reference_environment"):
            with self.subTest(variation=variation), temporary_workspace() as root:
                def mutate(request):
                    if variation == "records":
                        request["records"][0]["split"] = "test"
                    elif variation == "image_hash":
                        request["image_sha256"][request["records"][0]["image_id"]] = "0" * 64
                    else:
                        request["reference_environment"]["gpu_name"] = "other-device"
                configuration, _, calls = self.prepare(root, mutate)
                result = runner.run_sliced_comparison(configuration, "refused-records")
                self.assertEqual(result["status"], "failed")
                self.assertEqual(calls, [])
                self.doCleanups()

    def test_environment_and_each_observation_require_present_exact_null(self):
        environment = FakeBackend.make_environment(Path(__file__))
        environment["actual_predictor_options"]["nms"] = None
        row = {"effective_options": copy.deepcopy(environment["actual_predictor_options"]), "precision": "FP32",
               "device": "cuda:0", "actual_input_dtype": "torch.float32", "actual_input_device": "cuda:0",
               "model_parameters_dtype": "torch.float32"}
        runner.validate_inference_controls(environment, [row])
        for target in ("environment", "observation"):
            for value in (False, True, "null", 0, "missing"):
                with self.subTest(target=target, value=value):
                    changed_environment, changed_row = copy.deepcopy(environment), copy.deepcopy(row)
                    options = changed_environment["actual_predictor_options"] if target == "environment" else changed_row["effective_options"]
                    if value == "missing":
                        del options["nms"]
                    else:
                        options["nms"] = value
                    with self.assertRaises(ValueError):
                        runner.validate_inference_controls(changed_environment, [changed_row])

    def test_isolated_cold_resume_reuses_two_checkpoints_and_preserves_budget(self):
        class ColdBackend(FakeBackend, worker.DetectorBackend):
            def __init__(self, request, calls, fail=None):
                FakeBackend.__init__(self, request, calls, fail=fail)
                self.model = SimpleNamespace(predictor=None)

            def predict(self, source, shape):
                self.model.predictor = object()
                return FakeBackend.predict(self, source, shape)

            def environment(self, initial=False):
                if not initial and self.model.predictor is None:
                    raise AssertionError("Cold predictor has no fresh actual environment")
                value = FakeBackend.environment(self, initial)
                if initial:
                    for key in list(value):
                        if key.startswith("actual_predictor_") or key.startswith("actual_input_"):
                            del value[key]
                return value

        with temporary_workspace() as root:
            configuration, _, calls = self.prepare(root)
            failure_at = ("fixture-0000", 2)

            def execute(directory, request, protocol):
                runner._write(directory / "worker_request.json", request)
                failure = failure_at if directory.name == "fault-v3" else None
                receipt = worker._execute(request, lambda value: ColdBackend(value, calls, failure))
                if receipt["status"] != "completed":
                    raise RuntimeError(str(receipt["error"]))

            with patch.object(runner, "_run_worker", side_effect=execute):
                failed = runner.run_sliced_comparison(configuration, "fault-v3")
                self.assertEqual(failed["status"], "failed")
                original = Path(configuration["output_root"]) / "fault-v3"
                original_bytes = {path: path.read_bytes() for path in original.rglob("*") if path.is_file()}
                old_budget = runner._read(original / "budget.json")
                self.assertEqual((old_budget["formal_calls"], old_budget["warmup_calls"], old_budget["successful_observations"]), (3, 1, 2))
                old_call_count = len(calls)
                completed = runner.run_sliced_comparison(configuration, "resume-v3", resume_from="fault-v3")
            self.assertEqual(completed["status"], "completed", completed["errors"])
            self.assertEqual(len(calls) - old_call_count, 16)
            self.assertNotIn(("fixture-0000", 0), calls[old_call_count:])
            self.assertNotIn(("fixture-0000", 1), calls[old_call_count:])
            new_budget = runner._read(Path(configuration["output_root"]) / "resume-v3/budget.json")
            self.assertEqual((new_budget["formal_calls"], new_budget["warmup_calls"], new_budget["successful_observations"]), (19, 1, 18))
            for key in ("task_started_epoch", "inference_started_epoch"):
                self.assertEqual(new_budget[key], old_budget[key])
            self.assertGreater(new_budget["gpu_seconds"], old_budget["gpu_seconds"])
            self.assertEqual(new_budget["formal_attempts"][:3], old_budget["formal_attempts"])
            self.assertEqual(new_budget["warmup_attempts"], old_budget["warmup_attempts"])
            self.assertTrue(all(path.read_bytes() == before for path, before in original_bytes.items()))
            self.assertFalse((original / "completion.json").exists())

    def test_exact_gpu_exhaustion_stops_before_an_extra_fake_prediction(self):
        with temporary_workspace() as root:
            configuration, protocol, calls = self.prepare(root)
            protocol["budgets"]["max_gpu_seconds"] = 3

            class KnownCostBackend(FakeBackend):
                def predict(self, source, shape):
                    value = super().predict(source, shape)
                    self.last_timing = {"elapsed_seconds": 1., "gpu_seconds": 1.}
                    return value

            def execute(directory, request, observed_protocol):
                runner._write(directory / "worker_request.json", request)
                receipt = worker._execute(request, lambda value: KnownCostBackend(value, calls))
                if receipt["status"] != "completed":
                    raise RuntimeError(str(receipt["error"]))

            with patch.object(runner, "_run_worker", side_effect=execute):
                result = runner.run_sliced_comparison(configuration, "gpu-exhausted")
            self.assertEqual(result["status"], "failed")
            self.assertIn("exhausted before prediction", result["errors"][0]["message"])
            self.assertEqual(len(calls), 3)  # warmup + exactly two committed formal calls
            budget = runner._read(Path(configuration["output_root"]) / "gpu-exhausted/budget.json")
            self.assertEqual((budget["formal_calls"], budget["warmup_calls"], budget["successful_observations"]), (2, 1, 2))
            self.assertEqual(budget["gpu_seconds"], 3.)

    def test_parent_timeout_uses_saved_monotonic_floor_during_clock_rollback(self):
        with temporary_workspace() as root:
            protocol = runner._protocol()
            directory = root / "timeout-only"
            directory.mkdir()
            budget = runner._new_budget(999.)
            budget.update(inference_started_epoch=1001., inference_wall_seconds=899.)
            runner._write(directory / "budget.json", budget)
            for name in ("environment.json", "checkpoint_index.json", "checkpoint_journal.jsonl"):
                (directory / name).write_text("isolated timeout fixture", encoding="utf-8")
            receipt = {"status": "completed", **{key: _sha256(directory / name) for key, name in (
                ("environment_sha256", "environment.json"), ("budget_sha256", "budget.json"),
                ("checkpoint_index_sha256", "checkpoint_index.json"), ("journal_file_sha256", "checkpoint_journal.jsonl"))}}
            runner._write(directory / "worker_receipt.json", receipt)
            process = Mock(returncode=0)
            request = {"task_monotonic_elapsed_before_worker": 1.}
            with patch.object(runner, "validate_worker_request"), patch.object(runner.time, "time", return_value=1000.), \
                    patch.object(runner.subprocess, "Popen", return_value=process) as start:
                runner._run_worker(directory, request, protocol)
            process.wait.assert_called_once_with(timeout=1.)
            self.assertIn("defect_researcher.sliced_worker_v3", start.call_args.args[0])
            budget["inference_wall_seconds"] = 900.
            runner._write(directory / "budget.json", budget)
            with patch.object(runner, "validate_worker_request"), patch.object(runner.time, "time", return_value=1000.), \
                    patch.object(runner.subprocess, "Popen") as start, self.assertRaisesRegex(TimeoutError, "already expired"):
                runner._run_worker(directory, request, protocol)
            start.assert_not_called()

    def test_exact_source_bindings_and_fixed_paths_refuse_tampering(self):
        with temporary_workspace() as root:
            configuration, _, _ = self.prepare(root)
            result = runner.run_sliced_comparison(configuration, "manifest-v3")
            self.assertEqual(result["status"], "completed", result["errors"])
            directory = Path(configuration["output_root"]) / "manifest-v3"
            inputs = runner._read(directory / "inputs.json")
            protocol = runner._read(directory / "protocol.json")
            for variation in ("source_sha", "source_path", "missing_role", "duplicate_role"):
                changed = copy.deepcopy(inputs)
                source_row = next(row for row in changed["files"] if row["role"] == "sliced_runner")
                if variation == "source_sha":
                    source_row["sha256_before"] = source_row["sha256_after"] = "0" * 64
                elif variation == "source_path":
                    source_row["path"] = str(Path(runner.__file__).with_name("sliced_task.py"))
                elif variation == "missing_role":
                    changed["files"].remove(source_row)
                else:
                    changed["files"].append(copy.deepcopy(source_row))
                resealed = runner._canonical({row["role"]: {"path": row["path"], "sha256": row["sha256_before"],
                                             "size_bytes": row["size_bytes"]} for row in changed["files"]})
                with self.subTest(variation=variation), self.assertRaises(ValueError):
                    runner.validate_execution_manifest(changed, protocol["execution_source_sha256"], resealed)

    def test_sidecar_rejects_unknown_schema_version_and_tool_without_reader_call(self):
        with temporary_workspace() as root:
            configuration, _, _ = self.prepare(root)
            result = runner.run_sliced_comparison(configuration, "route-v3")
            self.assertEqual(result["status"], "completed", result["errors"])
            directory = Path(configuration["output_root"]) / "route-v3"
            original = runner._read(directory / "protocol.json")
            for key, value in (("schema_version", True), ("schema_version", 1.), ("execution_io_version", 2), ("execution_io_version", "3"),
                               ("execution_io_version", True), ("protocol_id", "two-image"), ("tool", "unknown")):
                runner._write(directory / "protocol.json", {**original, key: value})
                with self.subTest(key=key, value=value), patch.object(runner, "verify_sliced_artifacts") as semantic:
                    status = reader.get_task_status(configuration, "route-v3")
                    self.assertEqual(status["status"], "failed")
                    self.assertEqual(status["errors"][0]["stage"], "v3_task_status")
                    semantic.assert_not_called()
            runner._write(directory / "protocol.json", original)

    def test_sidecar_does_not_skip_completion_artifact_hash_verification(self):
        with temporary_workspace() as root:
            configuration, _, _ = self.prepare(root)
            result = runner.run_sliced_comparison(configuration, "tampered-v3")
            self.assertEqual(result["status"], "completed", result["errors"])
            (Path(configuration["output_root"]) / "tampered-v3/sliced_report.md").write_text("changed", encoding="utf-8")
            with patch.object(runner, "verify_sliced_artifacts") as semantic:
                status = reader.get_task_status(configuration, "tampered-v3")
                self.assertEqual(status["status"], "failed")
                self.assertIn("hash/size/path", status["errors"][0]["message"])
                semantic.assert_not_called()

    def test_historical_tools_use_original_reader_and_unknown_saved_code_never_runs(self):
        with temporary_workspace() as root:
            configuration, _, _ = fixture(root)
            output = Path(configuration["output_root"])
            for tool in reader.historical._TASK_ARTIFACTS:
                directory = output / f"historical-{tool}"
                directory.mkdir()
                runner._write(directory / "completion.json", {"tool": tool, "verifier_path": "untrusted.py"})
                expected = {"status": "fixture-original-reader", "tool": tool}
                with patch.object(reader.historical, "get_task_status", return_value=expected) as old_reader, \
                        patch.object(reader, "_completed_v3") as new_reader:
                    self.assertEqual(reader.get_task_status(configuration, directory.name), expected)
                    old_reader.assert_called_once_with(configuration, directory.name)
                    new_reader.assert_not_called()
            unknown = output / "unknown-tool"
            unknown.mkdir()
            runner._write(unknown / "completion.json", {"tool": "arbitrary", "verifier_path": "untrusted.py"})
            with patch.object(reader.historical, "get_task_status") as old_reader:
                status = reader.get_task_status(configuration, "unknown-tool")
                self.assertEqual(status["status"], "failed")
                old_reader.assert_not_called()

    def test_original_failure_cannot_be_imported_by_new_resume(self):
        with temporary_workspace() as root:
            configuration, protocol, loader = fixture(root)
            paths = _configured_paths(configuration)
            _, _, _, before, _, _ = loader(paths, protocol)
            previous, destination = paths["output_root"] / "old-failed", paths["output_root"] / "new-resume"
            previous.mkdir()
            destination.mkdir()
            runner._write(previous / "failure.json", {"status": "failed", "task_id": "old-failed", "tool": "compare_validation_slices"})
            original = (previous / "failure.json").read_bytes()
            with self.assertRaisesRegex(ValueError, "preserved failed tasks"):
                runner._resume(paths, "old-failed", destination, protocol, before, "0" * 64)
            self.assertEqual((previous / "failure.json").read_bytes(), original)
            self.assertEqual(list(destination.iterdir()), [])


if __name__ == "__main__":
    unittest.main()
