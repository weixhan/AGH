"""Request trust boundaries and cumulative known-cost workflow budgeting."""
import builtins
import copy
import hashlib
import json
from pathlib import Path
import unittest
from unittest import mock

from defect_researcher import research_protocol_v1 as protocol
from test_config import temporary_workspace


def request(**budget_changes):
    budget = {"domain_invocations": 6, "wall_seconds": 120,
              "gpu_seconds": 0, "model_requests": 0}
    budget.update(budget_changes)
    return {"schema_version": 1, "workflow_version": 1,
            "request_id": "local-run_01", "case_id": "normal_unrotated",
            "budget": budget}


class ControlledClocks:
    def __init__(self):
        self.monotonic = 100.0
        self.epoch = 1000.0

    def advance(self, seconds):
        self.monotonic += seconds
        self.epoch += seconds

    def create(self, directory, value=None):
        return protocol.BudgetLedger(directory, request() if value is None else value,
                                     clock=lambda: self.monotonic,
                                     epoch_clock=lambda: self.epoch)


class ResearchRequestTests(unittest.TestCase):
    def test_frozen_case_specification_and_protocol_are_bound(self):
        frozen = protocol.load_protocol()
        self.assertEqual(hashlib.sha256(protocol.PROTOCOL_PATH.read_bytes()).hexdigest(),
                         protocol.FROZEN_PROTOCOL_SHA256)
        self.assertEqual(len(frozen["case_specification"]["case_ids"]), 12)
        self.assertEqual(frozen["case_specification"]["sha256"], protocol.CASE_SPECIFICATION_SHA256)
        self.assertEqual(frozen["expected_maximum_domain_invocations"],
                         {"normal": 2, "repairable": 6, "refused": 1})

    def test_every_frozen_case_can_be_requested_and_normalization_is_detached(self):
        for case in protocol.load_protocol()["case_specification"]["case_ids"]:
            value = request()
            value["case_id"] = case
            actual = protocol.validate_request(value)
            self.assertEqual(actual["case_id"], case)
            self.assertIs(type(actual["budget"]["wall_seconds"]), float)
            actual["budget"]["domain_invocations"] = 1
            self.assertEqual(value["budget"]["domain_invocations"], 6)

    def test_protocol_byte_drift_is_refused(self):
        with mock.patch.object(protocol, "FROZEN_PROTOCOL_SHA256", "0" * 64):
            with self.assertRaisesRegex(ValueError, "protocol bytes changed"):
                protocol.load_protocol()

    def test_case_source_byte_drift_is_refused_without_editing_old_source(self):
        original = Path.read_bytes
        def changed(path):
            raw = original(path)
            return raw + b"\n" if path.name == "labelguard_cases.json" else raw
        with mock.patch.object(Path, "read_bytes", changed):
            with self.assertRaisesRegex(ValueError, "case specification bytes changed"):
                protocol.load_protocol()

    def test_provided_protocol_cannot_change_cap_or_type(self):
        for replacement in (7, 6.0, True):
            value = copy.deepcopy(protocol.load_protocol())
            value["budget_caps"]["domain_invocations"] = replacement
            with self.subTest(replacement=replacement):
                with self.assertRaisesRegex(ValueError, "Provided protocol"):
                    protocol.validate_request(request(), value)

    def test_versions_refuse_bool_float_string_and_wrong_version(self):
        for field in ("schema_version", "workflow_version"):
            for replacement in (True, 1.0, "1", 2, None):
                value = request()
                value[field] = replacement
                with self.subTest(field=field, replacement=replacement):
                    with self.assertRaises(ValueError):
                        protocol.validate_request(value)

    def test_unknown_or_missing_request_or_budget_field_is_refused(self):
        values = []
        for parent, key in ((None, "request_id"), ("budget", "wall_seconds")):
            value = request()
            del (value if parent is None else value[parent])[key]
            values.append(value)
            value = request()
            (value if parent is None else value[parent])["unexpected"] = 0
            values.append(value)
        values.extend([None, [], {"schema_version": 1}])
        for value in values:
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "schema"):
                protocol.validate_request(value)

    def test_pathlike_empty_nonstring_and_oversized_request_ids_are_refused(self):
        for value in ("", "../escape", "a/b", "a\\b", ".hidden", "a b", "a" * 65, 1, True):
            altered = request()
            altered["request_id"] = value
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "request_id"):
                protocol.validate_request(altered)

    def test_unfrozen_case_id_and_nonstring_are_refused(self):
        for case in ("real_dataset", "../normal_unrotated", None, True):
            value = request()
            value["case_id"] = case
            with self.subTest(case=case), self.assertRaisesRegex(ValueError, "case_id"):
                protocol.validate_request(value)

    def test_integer_call_budgets_refuse_bool_float_negative_and_over_cap(self):
        for field, cap in (("domain_invocations", 6), ("model_requests", 0)):
            for value in (True, False, float(cap), -1, cap + 1, "0", None):
                with self.subTest(field=field, value=value), self.assertRaisesRegex(ValueError, field):
                    protocol.validate_request(request(**{field: value}))

    def test_wall_and_gpu_budgets_refuse_bool_nonfinite_negative_and_over_cap(self):
        for field, cap in (("wall_seconds", 120), ("gpu_seconds", 0)):
            for value in (True, False, float("nan"), float("inf"), -float("inf"), -0.1,
                          cap + 0.1, "0", None, 10 ** 1000):
                with self.subTest(field=field, value=repr(value)), self.assertRaisesRegex(ValueError, field):
                    protocol.validate_request(request(**{field: value}))

    def test_zero_domain_budget_is_valid_but_wall_must_be_positive(self):
        self.assertEqual(protocol.validate_request(request(domain_invocations=0))["budget"]["domain_invocations"], 0)
        with self.assertRaisesRegex(ValueError, "greater than zero"):
            protocol.validate_request(request(wall_seconds=0))
        self.assertEqual(protocol.validate_request(request(wall_seconds=0.25))["budget"]["wall_seconds"], 0.25)

    def test_protocol_and_ledger_never_import_detector_or_network_model_modules(self):
        original = builtins.__import__
        def reject(name, *args, **kwargs):
            if name.split(".")[0] in {"torch", "ultralytics", "openai", "requests", "httpx"}:
                raise AssertionError(f"Forbidden module {name}")
            return original(name, *args, **kwargs)
        with temporary_workspace() as directory, mock.patch.object(builtins, "__import__", reject):
            ledger = ControlledClocks().create(directory)
            token = ledger.reserve("verify_label_geometry", 1)
            ledger.close(token)
            self.assertEqual(ledger.snapshot()["model_requests"], 0)


class ResearchBudgetTests(unittest.TestCase):
    def test_normal_path_charges_two_calls_and_repair_path_charges_six(self):
        paths = [("verify_label_geometry", "read_scientific_evidence"),
                 ("verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence")]
        for actions, expected in zip(paths, (2, 6)):
            with self.subTest(actions=actions), temporary_workspace() as directory:
                ledger = ControlledClocks().create(directory)
                costs = protocol.load_protocol()["action_reservations"]
                for action in actions:
                    ledger.close(ledger.reserve(action, costs[action]))
                ledger.check()
                self.assertEqual(ledger.snapshot()["used_domain_invocations"], expected)
                self.assertEqual(ledger.snapshot()["gpu_seconds"], 0)

    def test_budget_exhaustion_allows_publication_check_but_no_new_action(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory, request(domain_invocations=1))
            ledger.close(ledger.reserve("verify_label_geometry", 1))
            ledger.check()
            self.assertEqual(ledger.snapshot()["remaining_domain_invocations"], 0)
            self.assertFalse(ledger.snapshot()["can_start_domain_action"])
            with self.assertRaisesRegex(protocol.BudgetError, "exhausted"):
                ledger.reserve("read_scientific_evidence", 1)

    def test_zero_call_budget_creates_evidence_without_any_reservation(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory, request(domain_invocations=0))
            ledger.check()
            self.assertEqual(ledger.snapshot()["event_count"], 1)
            with self.assertRaisesRegex(protocol.BudgetError, "exhausted"):
                ledger.reserve("verify_label_geometry", 1)

    def test_worst_case_reservation_refuses_before_domain_call(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory, request(domain_invocations=3))
            ledger.close(ledger.reserve("verify_label_geometry", 1))
            before = ledger.path.read_bytes()
            with self.assertRaisesRegex(protocol.BudgetError, "worst-case"):
                ledger.reserve("repair_label_copy", 3)
            self.assertEqual(ledger.path.read_bytes(), before)
            self.assertEqual(ledger.snapshot()["pending"], None)

    def test_action_and_cost_are_frozen_and_typed(self):
        for action, cost in (("repair_label_copy", 1), ("verify_label_geometry", True),
                             ("verify_label_geometry", 1.0), ("run_training", 1), ([], 1)):
            with self.subTest(action=action, cost=cost), temporary_workspace() as directory:
                ledger = ControlledClocks().create(directory)
                with self.assertRaisesRegex(protocol.BudgetError, "frozen protocol"):
                    ledger.reserve(action, cost)
                self.assertEqual(ledger.snapshot()["event_count"], 1)

    def test_open_unknown_cost_reservation_refuses_publication_and_continuation(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory)
            ledger.reserve("repair_label_copy", 3)
            with self.assertRaisesRegex(protocol.BudgetError, "unknown actual cost"):
                ledger.check()
            with self.assertRaisesRegex(protocol.BudgetError, "unknown actual cost"):
                ledger.reserve("verify_copy", 1)
            self.assertEqual(ledger.snapshot()["reserved_domain_invocations"], 3)

    def test_known_actual_cost_releases_only_unused_reservation(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory)
            receipt = ledger.close(ledger.reserve("repair_label_copy", 3), actual_cost=1)
            self.assertEqual(receipt["released_domain_invocations"], 2)
            self.assertEqual(ledger.snapshot()["used_domain_invocations"], 1)
            self.assertEqual(ledger.snapshot()["remaining_domain_invocations"], 5)

    def test_close_rejects_wrong_token_bool_negative_overage_and_double_close(self):
        for wrong in (True, -1, 4, 1.0, "1"):
            with self.subTest(wrong=wrong), temporary_workspace() as directory:
                ledger = ControlledClocks().create(directory)
                token = ledger.reserve("repair_label_copy", 3)
                with self.assertRaisesRegex(protocol.BudgetError, "actual cost"):
                    ledger.close(token, actual_cost=wrong)
                self.assertIsNotNone(ledger.snapshot()["pending"])
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory)
            token = ledger.reserve("verify_label_geometry", 1)
            with self.assertRaisesRegex(protocol.BudgetError, "token"):
                ledger.close("wrong")
            ledger.close(token)
            with self.assertRaisesRegex(protocol.BudgetError, "token"):
                ledger.close(token)

    def test_deadline_is_original_and_never_restarted_by_another_action(self):
        with temporary_workspace() as directory:
            clocks = ControlledClocks()
            ledger = clocks.create(directory, request(wall_seconds=10))
            ledger.close(ledger.reserve("verify_label_geometry", 1))
            clocks.advance(9)
            ledger.close(ledger.reserve("read_scientific_evidence", 1))
            self.assertEqual(ledger.snapshot()["deadline_epoch"], 1010)
            self.assertEqual(ledger.snapshot()["deadline_monotonic"], 110)
            clocks.advance(1)
            with self.assertRaisesRegex(protocol.BudgetError, "deadline expired"):
                ledger.check()

    def test_either_clock_expiry_refuses_start_before_new_journal_event(self):
        for which in ("monotonic", "epoch"):
            with self.subTest(which=which), temporary_workspace() as directory:
                clocks = ControlledClocks()
                ledger = clocks.create(directory, request(wall_seconds=10))
                setattr(clocks, which, getattr(clocks, which) + 10)
                before = ledger.path.read_bytes()
                with self.assertRaisesRegex(protocol.BudgetError, "deadline expired"):
                    ledger.reserve("verify_label_geometry", 1)
                self.assertEqual(ledger.path.read_bytes(), before)

    def test_expired_known_cost_is_closed_before_timeout_is_reported(self):
        with temporary_workspace() as directory:
            clocks = ControlledClocks()
            ledger = clocks.create(directory, request(wall_seconds=10))
            token = ledger.reserve("repair_label_copy", 3)
            clocks.advance(11)
            with self.assertRaisesRegex(protocol.BudgetError, "Known actual cost closed"):
                ledger.close(token, actual_cost=2)
            state = ledger.snapshot()
            self.assertEqual(state["used_domain_invocations"], 2)
            self.assertIsNone(state["pending"])
            self.assertTrue(state["expired"])
            self.assertEqual(json.loads(ledger.path.read_text().splitlines()[-1])["event"], "action_closed")

    def test_journal_io_uses_original_wall_deadline(self):
        with temporary_workspace() as directory:
            clocks = ControlledClocks()
            ledger = clocks.create(directory, request(wall_seconds=10))
            token = ledger.reserve("verify_label_geometry", 1)
            original = ledger._append
            def delayed_append(*args, **kwargs):
                result = original(*args, **kwargs)
                clocks.advance(10)
                return result
            with mock.patch.object(ledger, "_append", side_effect=delayed_append):
                with self.assertRaisesRegex(protocol.BudgetError, "deadline expired"):
                    ledger.close(token)
            self.assertEqual(ledger.snapshot()["used_domain_invocations"], 1)

    def test_backward_clock_is_refused_even_if_after_original_start(self):
        for which in ("monotonic", "epoch"):
            with self.subTest(which=which), temporary_workspace() as directory:
                clocks = ControlledClocks()
                ledger = clocks.create(directory)
                clocks.advance(5)
                ledger.snapshot()
                setattr(clocks, which, getattr(clocks, which) - 1)
                with self.assertRaisesRegex(protocol.BudgetError, "backwards"):
                    ledger.check()

    def test_journal_cannot_be_reopened_resumed_or_given_more_budget(self):
        with temporary_workspace() as directory:
            clocks = ControlledClocks()
            ledger = clocks.create(directory, request(domain_invocations=1))
            before = ledger.path.read_bytes()
            with self.assertRaises(FileExistsError):
                clocks.create(directory, request(domain_invocations=6))
            self.assertEqual(ledger.path.read_bytes(), before)

    def test_even_empty_existing_journal_refuses_initialization(self):
        with temporary_workspace() as directory:
            (directory / "budget.jsonl").write_bytes(b"")
            with self.assertRaises(FileExistsError):
                ControlledClocks().create(directory)

    def test_changed_truncated_and_externally_appended_journal_is_refused(self):
        for mutation in (lambda b: b[:-1], lambda b: b + b"{}\n", lambda b: b.replace(b"local-run", b"other-run")):
            with temporary_workspace() as directory:
                ledger = ControlledClocks().create(directory)
                ledger.path.write_bytes(mutation(ledger.path.read_bytes()))
                with self.assertRaisesRegex(protocol.BudgetError, "journal was changed"):
                    ledger.check()

    def test_hash_chain_replays_reserved_and_closed_known_costs(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory)
            ledger.close(ledger.reserve("verify_label_geometry", 1))
            ledger.close(ledger.reserve("repair_label_copy", 3), actual_cost=2)
            rows = [json.loads(row) for row in ledger.path.read_text().splitlines()]
            previous = "0" * 64
            for number, row in enumerate(rows):
                self.assertEqual(row["sequence"], number)
                self.assertEqual(row["previous_sha256"], previous)
                claimed = row.pop("sha256")
                actual = hashlib.sha256(json.dumps(row, sort_keys=True, separators=(",", ":"),
                                                   ensure_ascii=False, allow_nan=False).encode()).hexdigest()
                self.assertEqual(claimed, actual)
                previous = claimed
            state = ledger.snapshot()
            self.assertEqual(state["last_event_sha256"], previous)
            self.assertEqual(state["journal_sha256"], hashlib.sha256(ledger.path.read_bytes()).hexdigest())
            self.assertEqual(state["event_count"], 5)
            self.assertEqual(state["used_domain_invocations"], 3)

    def test_failed_receipt_write_preserves_open_cost_and_blocks_next_action(self):
        with temporary_workspace() as directory:
            ledger = ControlledClocks().create(directory)
            token = ledger.reserve("verify_label_geometry", 1)
            with mock.patch.object(ledger, "_append", side_effect=OSError("disk write failed")):
                with self.assertRaisesRegex(OSError, "disk write failed"):
                    ledger.close(token)
            self.assertEqual(ledger.snapshot()["used_domain_invocations"], 0)
            self.assertIsNotNone(ledger.snapshot()["pending"])
            with self.assertRaisesRegex(protocol.BudgetError, "unknown actual cost"):
                ledger.reserve("read_scientific_evidence", 1)


if __name__ == "__main__":
    unittest.main()
