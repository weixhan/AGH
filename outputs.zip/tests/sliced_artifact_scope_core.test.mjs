// Real Core execution gate with a scripted provider; no model account or OS tool is used.
import test from 'node:test';
import assert from 'node:assert/strict';
import { ToolRegistry } from '../../agnes-harness/packages/core/src/index.ts';
import { actor, openSession, fakeProvider, fakeSeams, shellTool, toolTurn } from
  '../../agnes-harness/packages/core/testkit/index.ts';
import { createSlicedArtifactScopeGuard } from '../tools/sliced_artifact_scope_guard.mjs';

const task = 'b15612da05084920a3ce70772291557a';
const statusName = 'mcp_defect_researcher_45e5cef9_get_task_status';
const policy = { schema_version: 1, workspace_root: '/w', task_id: task,
  qualified_status_tool: statusName, max_status_calls: 1 };
const parameters = { [Symbol.for('TypeBox.Kind')]: 'Object', type: 'object',
  properties: { task_id: { [Symbol.for('TypeBox.Kind')]: 'String', type: 'string' } },
  required: ['task_id'] };

async function executeCase(name, args, alreadyRead = false) {
  let executions = 0, approvals = 0;
  const registry = new ToolRegistry();
  const statusTool = { name: statusName, description: 'Read a completed task', parameters,
    meta: { isReadOnly: true, isDestructive: false, isConcurrencySafe: true,
      isOpenWorld: false, replay: 'safe', requiresApproval: 'never', costHint: undefined, deferLoading: undefined },
    execute: async () => { executions++; return { content: [{ type: 'text', text: '{"status":"completed"}' }] }; } };
  registry.add(statusTool, { source: 'scope-fixture', trust: 'builtin' });
  registry.add(shellTool(async () => { executions++; return { content: [{ type: 'text', text: 'unexpected' }] }; }),
    { source: 'scope-fixture', trust: 'builtin' });
  const seams = fakeSeams({ approval: { ask: async () => { approvals++; return 'allowed-once'; } } });
  const state = await openSession({ provider: fakeProvider([toolTurn(name, args)]), registry, seams });
  const guard = createSlicedArtifactScopeGuard(policy);
  const context = { session: { key: state.session.key, workspaceRoot: '/w' }, replayed: false };
  if (alreadyRead) assert.equal(guard({ name: statusName, args: { task_id: task }, toolUseId: 'preseed' }, context).allow, true);
  state.session.hooks = { ...state.session.hooks, toolCall: payload => guard(payload, context) };
  await state.session.enqueue('next-turn', { content: [{ type: 'text', text: 'scope fixture' }], actor });
  await state.session.acceptInput();
  await state.session.runInference();
  await state.session.runToolsPhase();
  const rows = await state.log.scan({ type: 'tool/result', limit: 10 });
  return { result: rows.at(-1)?.data, executions, approvals };
}

test('Core denies a synthetic native shell call before approval and execute', async () => {
  const result = await executeCase('shell', { command: 'synthetic-do-not-execute' });
  assert.equal(result.result.code, 'HOOK_DENIED');
  assert.equal(result.executions, 0);
  assert.equal(result.approvals, 0);
});
test('Core denies an otherwise valid status call for another task', async () => {
  const result = await executeCase(statusName, { task_id: 'f'.repeat(32) });
  assert.equal(result.result.code, 'HOOK_DENIED');
  assert.equal(result.executions, 0);
});
test('Core denies another read when the completed evidence budget was consumed', async () => {
  const result = await executeCase(statusName, { task_id: task }, true);
  assert.equal(result.result.code, 'HOOK_DENIED');
  assert.equal(result.executions, 0);
});
test('Core executes the permitted read once without broadening its approval policy', async () => {
  const result = await executeCase(statusName, { task_id: task });
  assert.equal(result.result.isError, false);
  assert.equal(result.executions, 1);
  assert.equal(result.approvals, 0);
});
