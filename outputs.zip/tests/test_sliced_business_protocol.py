"""Zero-detector preregistration and immutable selection rejection coverage."""
import builtins
import copy
import json
from pathlib import Path
import shutil
import unittest
import uuid
from unittest import mock

from tools import prepare_sliced_business_protocol as prepare


class BusinessProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.registration = prepare._derive_registration()
        cls.protocol = prepare.read_protocol()
        source = Path(cls.registration["configuration"]["output_root"]) / cls.protocol["source_task_id"] / "predictions_640.jsonl"
        cls.all_records = [json.loads(line) for line in source.read_text(encoding="utf-8").splitlines() if line]
        cls.members = [r["image_id"] for r in cls.all_records]

    def altered(self):
        return copy.deepcopy(self.registration)

    def test_fixed_machine_recipe_and_shared_budget_are_exact(self):
        self.assertEqual(prepare._sha256(prepare.PROTOCOL_PATH), prepare.FROZEN_PROTOCOL_SHA256)
        self.assertEqual(self.protocol["population"]["observations_per_arm"], 18)
        self.assertIsNone(self.protocol["nms"])
        self.assertEqual(self.protocol["shared_budgets"], {"max_detector_calls": 40, "max_gpu_seconds": 60, "max_wall_seconds": 300})
        self.assertEqual(self.protocol["expected_counts"]["total"]["detector_calls"], 39)
        self.assertEqual(set(self.protocol["budgets"]), {"successful_observations", "max_formal_calls", "max_failed_pass_retries", "max_warmup_calls", "max_gpu_seconds", "max_inference_wall_seconds", "max_task_wall_seconds"})
        self.assertEqual(self.protocol["fault"]["pass_index"], 2)
        self.assertEqual(self.protocol["fault"]["boundary"], "after_predict_closed_cost_before_passed")

    def test_fixture_byte_change_is_refused(self):
        with mock.patch.object(prepare, "_sha256", return_value="0" * 64):
            with self.assertRaisesRegex(ValueError, "protocol bytes changed"):
                prepare.read_protocol()

    def test_preparation_does_not_import_torch_or_detector(self):
        original_import = builtins.__import__
        def reject_detector_import(name, *args, **kwargs):
            if name.split(".")[0] in {"torch", "ultralytics"}:
                raise AssertionError("Preregistration must not import detector/CUDA modules")
            return original_import(name, *args, **kwargs)
        with mock.patch.object(builtins, "__import__", side_effect=reject_detector_import):
            value = prepare._derive_registration()
        self.assertEqual(value["new_detector_calls"], 0)
        self.assertEqual(value["new_gpu_calls"], 0)
        self.assertEqual(value["new_model_requests"], 0)

    def test_fresh_registration_matches_frozen_inputs(self):
        self.assertIs(prepare.validate_registration(self.registration), self.registration)

    def test_two_ids_and_eighteen_ordered_pixels_are_fixed(self):
        self.assertEqual([r["image_id"] for r in self.registration["records"]], self.protocol["image_ids"])
        self.assertEqual(len(self.registration["pixel_inputs"]), 18)
        self.assertEqual([r["pass_id"] for r in self.registration["pixel_inputs"]], list(range(9)) * 2)
        self.assertEqual(self.registration["pixel_inputs"][0]["crop"], [0, 0, 1920, 1080])
        self.assertEqual(self.registration["pixel_inputs"][8]["crop"], [1280, 440, 1920, 1080])
        self.assertEqual(self.registration["pixel_inputs"][0]["input_pixels_sha256"], self.registration["pixel_inputs"][0]["decoded_image_sha256"])

    def test_selection_never_uses_saved_predictions(self):
        values = copy.deepcopy(self.all_records)
        for record in values:
            record["predictions"] = [{"arbitrary": "ignored for selection"}]
        chosen = prepare.select_records(list(reversed(values)), list(reversed(self.members)))
        self.assertEqual([r["image_id"] for r in chosen], self.protocol["image_ids"])

    def test_duplicate_prediction_member_is_rejected(self):
        values = copy.deepcopy(self.all_records)
        values[-1] = values[0]
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            prepare.select_records(values, self.members)

    def test_duplicate_validation_member_is_rejected(self):
        values = self.members.copy()
        values[-1] = values[0]
        with self.assertRaisesRegex(ValueError, "640 unique"):
            prepare.select_records(self.all_records, values)

    def test_nonvalidation_and_member_mismatch_are_rejected(self):
        values = copy.deepcopy(self.all_records)
        values[0]["split"] = "test"
        with self.assertRaisesRegex(ValueError, "nonvalidation"):
            prepare.select_records(values, self.members)
        members = self.members.copy()
        members[-1] = "unknown_member"
        with self.assertRaisesRegex(ValueError, "membership differ"):
            prepare.select_records(self.all_records, members)

    def test_gt_change_cannot_silently_reselect_images(self):
        values = copy.deepcopy(self.all_records)
        values[0]["ground_truth"] = [{"class_id": 4}]
        with self.assertRaisesRegex(ValueError, "reselection is forbidden"):
            prepare.select_records(values, self.members)

    def test_nms_missing_false_true_string_integer_are_refused(self):
        for replacement in (False, True, "null", 0):
            value = self.altered()
            value["reference_environment"]["actual_predictor_options"]["nms"] = replacement
            with self.subTest(value=replacement), self.assertRaisesRegex(ValueError, "external-NMS"):
                prepare.validate_registration(value, fresh=False)
        value = self.altered()
        del value["reference_environment"]["actual_predictor_options"]["nms"]
        with self.assertRaisesRegex(ValueError, "external-NMS"):
            prepare.validate_registration(value, fresh=False)

    def test_boolean_and_numeric_contract_coercion_is_refused(self):
        for key, replacement in (("schema_version", True), ("execution_version", 1.0), ("new_gpu_calls", False)):
            value = self.altered()
            value[key] = replacement
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "contract differs"):
                prepare.validate_registration(value, fresh=False)

    def test_changed_protocol_identity_is_refused(self):
        value = self.altered()
        value["protocol_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "protocol_sha256"):
            prepare.validate_registration(value, fresh=False)

    def test_duplicate_pixel_and_crop_change_are_refused(self):
        for change in ("duplicate", "crop", "typed_pass"):
            value = self.altered()
            if change == "duplicate":
                value["pixel_inputs"][2] = value["pixel_inputs"][1]
            elif change == "crop":
                value["pixel_inputs"][2]["crop"][0] += 1
            else:
                value["pixel_inputs"][0]["pass_id"] = False
            with self.subTest(change=change), self.assertRaisesRegex(ValueError, "pixel identity"):
                prepare.validate_registration(value, fresh=False)

    def test_changed_pixel_digest_is_freshly_refused(self):
        value = self.altered()
        value["pixel_inputs"][2]["input_pixels_sha256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "freshly verified"):
            prepare.validate_registration(value)

    def test_changed_weight_or_dependency_digest_is_freshly_refused(self):
        for role in ("weights", "dependency/ultralytics/engine/predictor.py"):
            value = self.altered()
            next(row for row in value["input_files"] if row["role"] == role)["sha256"] = "0" * 64
            with self.subTest(role=role), self.assertRaisesRegex(ValueError, "freshly verified"):
                prepare.validate_registration(value)

    def test_duplicate_and_malformed_file_identity_are_refused(self):
        value = self.altered()
        value["input_files"].append(value["input_files"][0])
        with self.assertRaisesRegex(ValueError, "duplicate file"):
            prepare.validate_registration(value, fresh=False)
        value = self.altered()
        value["preserved_files"][0]["size_bytes"] = True
        with self.assertRaisesRegex(ValueError, "malformed file"):
            prepare.validate_registration(value, fresh=False)

    def test_unknown_fields_and_upstream_reclassification_are_refused(self):
        value = self.altered()
        value["extra"] = "unknown"
        with self.assertRaisesRegex(ValueError, "schema"):
            prepare.validate_registration(value, fresh=False)
        value = self.altered()
        value["upstream_evidence"]["original_status"] = "completed"
        with self.assertRaisesRegex(ValueError, "upstream"):
            prepare.validate_registration(value, fresh=False)

    def test_saved_config_cannot_redirect_inputs_or_outputs(self):
        value = self.altered()
        value["configuration"]["weights_path"] = str(Path(value["configuration"]["output_root"]) / "fake.pt")
        with self.assertRaisesRegex(ValueError, "trusted path|separate from"):
            prepare.validate_registration(value, fresh=False)

    def test_missing_old_failed_state_is_rejected(self):
        original_read = prepare._read
        def changed(path):
            if Path(path).name == "failure.json":
                return {"status": "completed"}
            return original_read(path)
        with mock.patch.object(prepare, "_read", side_effect=changed), self.assertRaisesRegex(ValueError, "failure state"):
            prepare._upstream(self.protocol)

    def test_preparation_writes_once_to_new_output_only(self):
        output_root = Path(self.registration["configuration"]["output_root"])
        # pathlib's ordinary inherited permissions work in the Windows sandbox;
        # tempfile's mode 0700 creates a directory the sandbox cannot reopen.
        directory = output_root / ("business-protocol-test-" + uuid.uuid4().hex)
        directory.mkdir()
        try:
            target = directory / "input_manifest.json"
            value = prepare.prepare_protocol(target)
            self.assertEqual(prepare._read(target), value)
            with self.assertRaisesRegex(ValueError, "new file"):
                prepare.prepare_protocol(target)
            (directory / "failure.json").write_text("{}", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "new file"):
                prepare.prepare_protocol(directory / "another.json")
        finally:
            resolved = directory.resolve()
            self.assertTrue(resolved.is_relative_to(output_root.resolve()))
            self.assertTrue(resolved.name.startswith("business-protocol-test-"))
            shutil.rmtree(resolved)

    def test_duplicate_json_keys_and_nonfinite_literals_are_rejected(self):
        for text in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                prepare._read_json_line(text)


if __name__ == "__main__":
    unittest.main()
