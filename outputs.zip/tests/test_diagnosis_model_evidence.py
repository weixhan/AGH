"""Reject forged, unscoped, mismatched and numerically ambiguous model ledgers."""
import copy
import json
import unittest

from tools.verify_diagnosis_model_run import (
    START_TOOL, STATUS_TOOL, UNKNOWN, check_ledger, compact_target, final_compact, official_payload,
)


def fixture():
    task = "1a23456789abcdef0123456789abcdef"
    session = "diagnosis-session"
    workspace = "E:/project/outputs/agh-diagnosis-model/workspace"
    summary = {"diagnosis_status": "passed", "input_hashes_unchanged": True,
               "new_inference_performed": False, "training_performed": False, "test_inference_performed": False,
               "reference": {"images": 640, "gt": 596, "operating_point": {"tp": 231, "fp": 149, "fn": 365,
                  "normal_image_fp_rate": 0.02040816326530612},
                  "fn_categories": {"matching_conflict": 0, "localized_low_confidence": 133, "wrong_class_candidate": 23,
                                    "localization_candidate": 147, "no_overlap_candidate": 62},
                  "fp_categories": {"duplicates": 6, "wrong_class": 16, "localization": 110, "background": 17}},
               "threshold_selection": {"status": "stop", "selected_threshold": None},
               "recommendations": {"next_branch": "sliced_inference_controlled"}}
    disk = {"task_id": task, "status": "completed", "tool": "diagnose_validation_errors", "summary": summary,
            "evidence": {"source_task_id": "8d1d6900c7d74c90a29824495684807d"}}
    policy = {"schema_version": 1, "workspace_root": "<workspace>", "qualified_start_tool": START_TOOL,
              "qualified_status_tool": STATUS_TOOL, "max_status_calls": 20}
    origin = "ext:plugin/test-extension"
    rows = [
        {"type": "session/start", "data": {"key": session}},
        {"type": "x/plugin/test-extension/scope-ready", "origin": origin,
         "data": {"session_key": session, "workspace_root": "<workspace>", "mode": "diagnosis", "policy": policy}},
        {"type": "request/sent", "data": {}},
        {"type": "tool/call", "origin": "model", "data": {"name": START_TOOL, "args": {}, "toolUseId": "start"}},
        {"type": "x/plugin/test-extension/scope-decision", "origin": origin,
         "data": {"session_key": session, "name": START_TOOL, "tool_use_id": "start", "allow": True, "reason": None}},
        {"type": "approval/decided", "data": {"verdict": "allowed-once", "scope": f"tool:{START_TOOL}:execute"}},
        {"type": "tool/result", "sourceEventSeqs": [4], "data": {"toolUseId": "start", "isError": False,
         "content": [{"type": "text", "text": json.dumps({"task_id": task, "status": "running"})}]}},
        {"type": "tool/call", "origin": "model", "data": {"name": STATUS_TOOL, "args": {"task_id": task}, "toolUseId": "poll"}},
        {"type": "x/plugin/test-extension/scope-decision", "origin": origin,
         "data": {"session_key": session, "name": STATUS_TOOL, "tool_use_id": "poll", "allow": True, "reason": None}},
        {"type": "tool/result", "sourceEventSeqs": [8], "data": {"toolUseId": "poll", "isError": False,
         "content": [{"type": "text", "text": json.dumps(disk)}]}},
        {"type": "cost/ledger", "data": {"purpose": "inference", "model": "agnes-3.0-flash", "response": {"status": 200}}},
        {"type": "assistant/message", "data": {"content": [{"type": "text", "text": "候选诊断仅支持受控研究。\n```json\n" + json.dumps(compact_target(disk)) + "\n```"}]}},
        {"type": "turn/end", "data": {"reason": "completed", "lastAssistantSeq": 12}},
    ]
    for seq, row in enumerate(rows, 1):
        row["seq"] = seq
    sdk_ready = copy.deepcopy(rows[1])
    sdk_ready["data"]["workspace_root"] = workspace
    sdk_ready["data"]["policy"]["workspace_root"] = workspace
    runner = {"status": "completed", "cwd": workspace, "session_id": session, "task_id": task, "scope_ready": sdk_ready,
              "calls": [{"seq": row["seq"], "name": row["data"]["name"], "args": row["data"]["args"], "origin": row["origin"]}
                        for row in rows if row["type"] == "tool/call"],
              "polls": [{"seq": 7, "task_id": task, "status": "running"},
                        {"seq": 10, "task_id": task, "status": "completed", "summary": summary, "evidence": disk["evidence"]}],
              "permissions": [{"tool": START_TOOL, "input": {}, "tool_call_id": "start", "decision": "allowed-once"}],
              "hook_events": [copy.deepcopy(rows[4]), copy.deepcopy(rows[8])]}
    return rows, runner, disk


class DiagnosisModelLedgerTests(unittest.TestCase):
    def setUp(self):
        self.rows, self.runner, self.disk = fixture()

    def checks(self):
        return check_ledger(self.rows, self.runner, self.disk)["checks"]

    def test_valid_scoped_ledger_and_public_science_pass(self):
        checks = self.checks()
        self.assertTrue(all(checks.values()), checks)
        self.assertTrue(check_ledger(self.rows, self.runner, self.disk)["strict_tool_scope_passed"])

    def test_denied_extra_shell_attempt_never_counts_as_scope_pass(self):
        call = {"seq": 14, "type": "tool/call", "origin": "model", "data": {"name": "shell", "args": {"command": "wait"}, "toolUseId": "extra"}}
        verdict = {"seq": 15, "type": "x/plugin/test-extension/scope-decision", "origin": "ext:plugin/test-extension",
                   "data": {"session_key": self.runner["session_id"], "name": "shell", "tool_use_id": "extra", "allow": False, "reason": "outside protocol"}}
        result = {"seq": 16, "type": "tool/result", "sourceEventSeqs": [14], "data": {"toolUseId": "extra", "isError": True, "code": "HOOK_DENIED"}}
        self.rows.extend((call, verdict, result))
        self.runner["calls"].append({"seq": 14, "name": "shell", "args": {"command": "wait"}, "origin": "model"})
        self.runner["hook_events"].append(verdict)
        report = check_ledger(self.rows, self.runner, self.disk)
        self.assertFalse(report["strict_tool_scope_passed"])
        self.assertFalse(report["checks"]["only_requested_model_tool_attempts"])
        self.assertFalse(report["checks"]["all_tool_results_successful_no_rejected_attempt"])
        self.assertEqual(report["unrequested_tool_attempts"][0]["result_code"], "HOOK_DENIED")

    def test_late_ready_or_wrong_mode_fails(self):
        self.rows[1]["seq"] = 5
        self.assertFalse(self.checks()["one_scope_ready_before_first_call"])
        self.rows[1]["seq"] = 2
        self.rows[1]["data"]["mode"] = "evidence"
        self.assertFalse(self.checks()["scope_ready_mode_session_and_policy_bound"])

    def test_sdk_ready_must_match_exact_expected_workspace(self):
        self.runner["scope_ready"]["data"]["workspace_root"] = "E:/another/project"
        self.assertFalse(self.checks()["public_sdk_readiness_exact_workspace_and_event"])

    def test_missing_scope_decision_or_denied_start_fails(self):
        self.rows[4]["data"]["tool_use_id"] = "unrelated"
        self.assertFalse(self.checks()["each_attempt_has_one_paired_allowed_scope_decision"])
        self.rows[4]["data"]["tool_use_id"] = "start"
        self.rows[4]["data"]["allow"] = False
        self.assertFalse(self.checks()["each_attempt_has_one_paired_allowed_scope_decision"])

    def test_scope_decision_from_another_extension_rejected(self):
        self.rows[8]["origin"] = "ext:plugin/another"
        self.assertFalse(self.checks()["scope_events_from_same_registered_extension"])

    def test_scope_sdk_snapshot_cannot_disagree_with_official_event(self):
        self.runner["hook_events"][0]["data"]["allow"] = False
        self.assertFalse(self.checks()["public_sdk_scope_decisions_equal_official"])

    def test_result_before_call_or_wrong_source_pair_rejected(self):
        self.rows[9]["sourceEventSeqs"] = [4]
        self.assertFalse(self.checks()["unique_call_result_ids_and_exact_pairing"])
        self.rows[9]["sourceEventSeqs"] = [8]
        self.rows[9]["seq"] = 7
        self.assertFalse(self.checks()["unique_call_result_ids_and_exact_pairing"])

    def test_same_task_poll_and_approval_scope_exact(self):
        self.rows[7]["data"]["args"]["task_id"] = "different"
        self.assertFalse(self.checks()["status_polls_same_task_after_launch_within_budget"])
        self.rows[5]["data"]["scope"] = "tool:shell:execute"
        self.assertFalse(self.checks()["one_allow_once_for_start_before_result"])

    def test_second_allow_once_is_not_hidden_by_valid_first_one(self):
        self.rows.append({"seq": 14, "type": "approval/decided", "data": {"verdict": "allowed-once", "scope": f"tool:{START_TOOL}:execute"}})
        self.assertFalse(self.checks()["one_allow_once_for_start_before_result"])

    def test_compact_integer_or_category_tamper_rejected(self):
        payload = json.loads(self.rows[9]["data"]["content"][0]["text"])
        payload["summary"]["reference"]["fn_categories"]["localized_low_confidence"] = 132
        self.rows[9]["data"]["content"][0]["text"] = json.dumps(payload)
        self.assertFalse(self.checks()["terminal_official_compact_science_matches_disk"])

    def test_detailed_sdk_decimal_or_event_sequence_tamper_rejected(self):
        self.runner["polls"][1]["summary"] = copy.deepcopy(self.runner["polls"][1]["summary"])
        self.runner["polls"][1]["summary"]["reference"]["operating_point"]["normal_image_fp_rate"] = .1
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])
        self.runner["polls"][1]["summary"] = self.disk["summary"]
        self.runner["polls"][1]["seq"] = 11
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])

    def test_model_final_must_match_terminal_counts_and_stop_branch(self):
        value = compact_target(self.disk)
        value["threshold_status"] = "selected"
        self.rows[11]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["model_final_unique_compact_json_matches_disk"])

    def test_final_turn_cannot_claim_complete_before_terminal_tool(self):
        self.rows[11]["seq"] = 9
        self.assertFalse(self.checks()["final_completed_turn_after_completed_tool"])

    def test_official_decimal_mask_is_unknown_and_never_recovered(self):
        text = self.rows[9]["data"]["content"][0]["text"]
        text = text.replace("0.02040816326530612", "0.[REDACTED:id]")
        parsed, paths = official_payload(text)
        self.assertEqual(parsed["summary"]["reference"]["operating_point"]["normal_image_fp_rate"], UNKNOWN)
        self.assertEqual(paths, [["summary", "reference", "operating_point", "normal_image_fp_rate"]])
        self.rows[9]["data"]["content"][0]["text"] = text
        checks = self.checks()
        self.assertTrue(checks["terminal_official_compact_science_matches_disk"])
        self.assertTrue(checks["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])

    def test_masked_compact_count_fails_closed_and_bad_json_unrepaired(self):
        text = self.rows[9]["data"]["content"][0]["text"].replace('"tp": 231', '"tp": [REDACTED:id]')
        self.rows[9]["data"]["content"][0]["text"] = text
        self.assertFalse(self.checks()["terminal_official_compact_science_matches_disk"])
        with self.assertRaises(ValueError):
            official_payload('{"count": [UNRECOGNIZED:mask]}')

    def test_final_json_duplicate_key_multiple_blocks_and_bool_counts_rejected(self):
        self.assertIsNone(final_compact('```json\n{"tp":1,"tp":2}\n```'))
        text = self.rows[11]["data"]["content"][0]["text"]
        self.assertIsNone(final_compact(text + "\n" + text))
        disk = copy.deepcopy(self.disk)
        disk["summary"]["reference"]["operating_point"]["tp"] = True
        self.assertIsNone(compact_target(disk))

    def test_zero_count_cannot_be_laundered_as_false_in_model_or_sdk(self):
        value = compact_target(self.disk)
        value = copy.deepcopy(value)
        value["fn_categories"]["matching_conflict"] = False
        self.rows[11]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["model_final_unique_compact_json_matches_disk"])
        self.runner["polls"][1]["summary"] = copy.deepcopy(self.disk["summary"])
        self.runner["polls"][1]["summary"]["reference"]["fn_categories"]["matching_conflict"] = False
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])


if __name__ == "__main__":
    unittest.main()
