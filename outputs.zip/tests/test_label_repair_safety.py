"""Independent verification gates a faulty generator; history is immutable."""
from pathlib import Path
import unittest
from unittest.mock import patch

from test_config import temporary_workspace
from defect_researcher.labelguard_fixtures import build_case, load_case_spec
from defect_researcher import label_repair

RESEARCH = Path(r"E:\PythonProject\projects\cableinspect-ad-code\project_start")


class LabelRepairSafetyTests(unittest.TestCase):
    def test_faulty_production_generator_never_publishes_completion(self):
        with temporary_workspace() as root:
            spec = load_case_spec()
            config = build_case(root / "fixture", spec["cases"][4], spec, RESEARCH)["configuration"]
            module = label_repair._load_production(Path(config["research_root"]) / "cableinspect_geometry.py")
            module.coco_bbox_to_yolo = lambda *args: ([0.4, 0.35, 0.4, 0.1], False)
            with patch.object(label_repair, "_load_production", return_value=module):
                report = label_repair.repair_label_copy(config, "faulty")
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["errors"][0]["stage"], "after_independent_verification")
            self.assertFalse((Path(config["output_root"]) / "faulty/completion.json").exists())

    def test_existing_task_and_production_source_directory_are_preserved(self):
        with temporary_workspace() as root:
            spec = load_case_spec()
            config = build_case(root / "fixture", spec["cases"][0], spec, RESEARCH)["configuration"]
            report = label_repair.repair_label_copy(config, "normal")
            self.assertEqual(report["status"], "completed", report["errors"])
            marker = Path(config["output_root"]) / "normal/completion.json"
            content = marker.read_bytes()
            repeated = label_repair.repair_label_copy(config, "normal")
            self.assertEqual(repeated["status"], "failed")
            self.assertEqual(marker.read_bytes(), content)
            self.assertFalse((marker.parent / "failure.json").exists())
            self.assertFalse((Path(config["research_root"]) / "__pycache__").exists())
