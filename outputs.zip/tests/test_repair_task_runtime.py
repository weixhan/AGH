"""Reject damaged copies and unrelated nested evidence, including sealed lies."""
import json
from pathlib import Path
import unittest

from test_config import temporary_workspace
from defect_researcher.labelguard_fixtures import build_case, load_case_spec, sha256
from defect_researcher.label_repair import repair_label_copy
from defect_researcher.task_runtime import get_task_status

RESEARCH = Path(r"E:\PythonProject\projects\cableinspect-ad-code\project_start")


def reseal(directory):
    manifest_path = directory / "artifact_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for row in manifest["files"]:
        row["sha256"] = sha256(Path(row["path"]))
        row["size_bytes"] = Path(row["path"]).stat().st_size
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    marker_path = directory / "completion.json"
    marker = json.loads(marker_path.read_text(encoding="utf-8"))
    marker["artifact_manifest_sha256"] = sha256(manifest_path)
    marker["artifacts_sha256"] = {row["name"]: row["sha256"] for row in manifest["files"]}
    marker_path.write_text(json.dumps(marker), encoding="utf-8")


class RepairTaskEvidenceTests(unittest.TestCase):
    def build(self, root):
        spec = load_case_spec()
        config = build_case(root / "case", spec["cases"][4], spec, RESEARCH)["configuration"]
        report = repair_label_copy(config, "repair")
        self.assertEqual(report["status"], "completed", report["errors"])
        self.assertEqual(get_task_status(config, "repair")["status"], "completed")
        return config, Path(config["output_root"]) / "repair"

    def test_changed_copy_label_is_rejected_without_touching_original(self):
        with temporary_workspace() as root:
            config, directory = self.build(root)
            original = Path(config["dataset_root"]) / "labels/train/image_1.txt"
            content = original.read_bytes()
            (directory / "dataset_copy/labels/train/image_1.txt").write_text("0 0 0 0 0", encoding="utf-8")
            self.assertEqual(get_task_status(config, "repair")["status"], "failed")
            self.assertEqual(original.read_bytes(), content)

    def test_sealed_nested_reference_cannot_point_to_before_verification(self):
        with temporary_workspace() as root:
            config, directory = self.build(root)
            path = directory / "copy_manifest.json"
            copied = json.loads(path.read_text(encoding="utf-8"))
            copied["after_verification"]["output_root"] = str(directory / "before_verification")
            path.write_text(json.dumps(copied), encoding="utf-8")
            reseal(directory)
            failure = get_task_status(config, "repair")
            self.assertEqual(failure["status"], "failed")
            self.assertIn("expected task", failure["errors"][0]["message"])

    def test_extra_copy_file_is_rejected(self):
        with temporary_workspace() as root:
            config, directory = self.build(root)
            (directory / "dataset_copy/labels/train/extra.txt").write_bytes(b"")
            self.assertEqual(get_task_status(config, "repair")["status"], "failed")
