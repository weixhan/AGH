"""Actual event-schema cost boundaries; no model, detector or AGH process."""
from copy import deepcopy
import hashlib
import json
import unittest
from tools.verify_resolution_research_model_v1 import check_costs,check_title,check_official_sdk

def fixture():
    run={'session_id':'science-saved-session','model':'agnes-3.0-flash','route':'account-defect-researcher'}
    rows=[]
    def add(kind,data):
        row={'seq':len(rows)+1,'type':kind,'ts':'2026-10-14T00:00:00Z','origin':'system','trust':'trusted','lane':'main','data':data}
        rows.append(row);return row
    add('session/start',{'key':run['session_id']})
    add('turn/start',{'turn':1,'trigger':'prompt'})
    add('request/sent',{'model':{'id':run['model'],'route':run['route']},'tool_schema_hash':'a'*64})
    add('cost/ledger',{'purpose':'inference','model':run['model'],'effectId':'request-first',
        'tokens':{'input':20,'output':5,'cacheRead':0,'cacheWrite':0},'response':{'status':200}})
    add('turn/end',{'reason':'completed','lastAssistantSeq':4})
    seed={'status':'requested','turn':1,'startSeq':2,'model':run['model'],'route':run['route']}
    add('x/host/session-title',seed)
    effect='title:'+hashlib.sha256(json.dumps([run['session_id'],'main',2],separators=(',',':')).encode()).hexdigest()
    add('cost/ledger',{'purpose':'title','model':run['model'],'sourceTurn':1,'effectId':effect,
        'tokens':{'input':10,'output':3,'cacheRead':0,'cacheWrite':0}})
    add('x/host/session-title/diagnostics',{'schemaVersion':1,'sourceTurn':1,'effectId':effect,
        'timeoutMs':30000,'durationMs':100,'providerSent':True,'responseSeen':True,'usageObserved':True,
        'cancellationSettlementLimitMs':25,'settledUsage':False,'duplicateUsage':False,'invalidUsage':False,
        'responseStatus':200,'usageAtMs':100})['ignorable']=True
    add('x/host/session-title',{**seed,'status':'failed','reason':'invalid-title'})
    for turn in (2,3):
        add('turn/start',{'turn':turn,'trigger':'follow_up'})
        add('request/sent',{'model':{'id':run['model'],'route':run['route']},'tool_schema_hash':'a'*64})
        add('cost/ledger',{'purpose':'inference','model':run['model'],'effectId':f'request-{turn}',
            'tokens':{'input':30,'output':5,'cacheRead':0,'cacheWrite':0},'response':{'status':200}})
        add('turn/end',{'reason':'completed','lastAssistantSeq':len(rows)})
    return rows,run

class ScientificModelCostTests(unittest.TestCase):
    def test_three_actual_turns_one_cost_closed_format_failure(self):
        rows,run=fixture()
        self.assertEqual(check_costs(rows,run)['primary_requests'],3)
        self.assertFalse(check_title(rows,run)['title_generated'])
        self.assertEqual(check_official_sdk(rows,deepcopy(rows),run)['official_sdk_envelopes_paired'],17)
    def test_generated_auxiliary_title_is_reported_separately(self):
        rows,run=fixture();rows[8]['data'].update(status='generated');rows[8]['data'].pop('reason')
        self.assertTrue(check_title(rows,run)['title_generated'])
    def test_primary_unknown_zero_boolean_interrupted_and_response_error(self):
        for mutate in (
            lambda r:r[3]['data'].update(tokens=None),
            lambda r:r[3]['data']['tokens'].update(input=True),
            lambda r:r[3]['data'].update(tokens={'input':0,'output':0,'cacheRead':100,'cacheWrite':0}),
            lambda r:r[3]['data'].update(interrupted=1),
            lambda r:r[3]['data'].update(response={'status':500}),
            lambda r:r[11]['data'].update(effectId='request-first'),
            lambda r:r[10]['data'].update(tool_schema_hash='b'*64),
            lambda r:r[3]['data'].update(purpose='verifier'),
        ):
            with self.subTest(mutation=mutate):
                rows,run=fixture();mutate(rows)
                with self.assertRaises(ValueError):check_costs(rows,run)
    def test_missing_primary_receipt_is_not_known_zero(self):
        rows,run=fixture();rows.pop(3)
        with self.assertRaises(ValueError):check_costs(rows,run)
    def test_title_original_start_and_typed_seed(self):
        for mutate in (
            lambda r:r[1]['data'].update(trigger='follow_up'),
            lambda r:r[1]['data'].update(turn=True),
            lambda r:r[8]['data'].update(startSeq=True),
            lambda r:r[5]['data'].update(startSeq=3),
            lambda r:r[1].update(lane='other'),
            lambda r:r[4]['data'].update(reason='aborted'),
        ):
            rows,run=fixture();mutate(rows)
            with self.assertRaises(ValueError):check_title(rows,run)
    def test_auxiliary_format_exception_preserves_usage_guards(self):
        for mutate in (
            lambda r:r[7]['data'].update(usageObserved=False),
            lambda r:r[7]['data'].update(cancelledBy='timeout'),
            lambda r:r[7]['data'].update(duplicateUsage=True),
            lambda r:r[7]['data'].update(invalidUsage=True),
            lambda r:r[6]['data'].update(interrupted='false'),
            lambda r:r[8]['data'].update(reason='timeout'),
            lambda r:r[6]['data'].update(tokens=None),
            lambda r:r[7].update(ts='2026-10-14T00:00:01Z'),
        ):
            rows,run=fixture();mutate(rows)
            with self.assertRaises(ValueError):check_title(rows,run)
    def test_followup_cannot_borrow_second_native_title_budget(self):
        rows,run=fixture();rows.extend(deepcopy(rows[5:9]))
        with self.assertRaises(ValueError):check_title(rows,run)
    def test_sdk_cannot_substitute_changed_official_cost(self):
        rows,run=fixture();events=deepcopy(rows);events[3]['data']['tokens']['input']+=1
        with self.assertRaises(ValueError):check_official_sdk(rows,events,run)
    def test_unknown_native_title_numeric_is_not_restored_from_sdk(self):
        rows,run=fixture();events=deepcopy(rows);rows[7]['data']['usageAtMs']='[REDACTED:id]'
        with self.assertRaises(ValueError):check_official_sdk(rows,events,run)

if __name__=='__main__':unittest.main()
