"""Public sliced-tool scope and execution-versus-hypothesis status boundaries."""
import contextlib
import io
import json
import unittest
from unittest.mock import patch
from defect_researcher.mcp_server import AuditMCPServer
from defect_researcher.__main__ import main


def ready():
    server=AuditMCPServer({})
    server.handle_message({"jsonrpc":"2.0","id":1,"method":"initialize","params":{
        "protocolVersion":"2025-03-26","capabilities":{},"clientInfo":{"name":"fixture","version":"1"}}})
    server.handle_message({"jsonrpc":"2.0","method":"notifications/initialized"})
    return server


class SlicedMCPTests(unittest.TestCase):
    def test_scope_rejects_caller_paths_controls_and_recovery(self):
        server=ready()
        for arguments in ({"split":"test"},{"device":"cpu"},{"confidence":.2},
                          {"resume_from":"old"},{"output":"other"},[]):
            response=server.handle_message({"jsonrpc":"2.0","id":2,"method":"tools/call","params":{
                "name":"compare_validation_slices","arguments":arguments}})
            self.assertEqual(response["error"]["code"],-32602)

    def test_one_start_returns_exact_runtime_task_without_running_detector(self):
        expected={"task_id":"1"*32,"tool":"compare_validation_slices","status":"running"}
        with patch("defect_researcher.task_runtime.start_sliced_comparison",return_value=expected) as start:
            response=ready().handle_message({"jsonrpc":"2.0","id":2,"method":"tools/call","params":{
                "name":"compare_validation_slices","arguments":{}}})
        self.assertFalse(response["result"]["isError"])
        self.assertEqual(json.loads(response["result"]["content"][0]["text"])["task_id"],expected["task_id"])
        start.assert_called_once_with({})

    def test_cli_does_not_confuse_scientific_stop_with_execution_failure(self):
        cases=[({"status":"completed","summary":{"slicing_status":"passed","candidate_status":"stop"}},0),
               ({"status":"completed","summary":{"slicing_status":"passed","candidate_status":"accepted"}},0),
               ({"status":"failed"},1),({"status":"running"},1),({"status":"completed"},1)]
        for report,code in cases:
            with self.subTest(report=report),patch("sys.argv",["run.py","slices"]), \
                 patch("defect_researcher.__main__.load_config",return_value={}), \
                 patch("defect_researcher.sliced_task.run_sliced_comparison",return_value=report) as run, \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(),code)
                run.assert_called_once_with({},resume_from=None)

    def test_resume_flag_is_rejected_for_other_commands(self):
        with patch("sys.argv",["run.py","audit","--resume-from","old"]), \
             contextlib.redirect_stderr(io.StringIO()),self.assertRaises(SystemExit) as raised:
            main()
        self.assertEqual(raised.exception.code,2)


if __name__ == "__main__":
    unittest.main()
