"""Hand-written durability and replay oracles; no detector or GPU imports."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import shutil
import unittest
import uuid
from unittest.mock import patch

from defect_researcher import sliced_journal as journal


class Scratch:
    # Default mkdir permissions inherit the workspace ACL. tempfile's private
    # mkdir mode is inaccessible to the restricted Windows execution token.
    def __init__(self, prefix):
        self.root = (Path(__file__).resolve().parents[1] / "outputs").resolve()
        self.path = self.root / f"{prefix}{uuid.uuid4().hex}"
        self.path.mkdir()
        self.name = str(self.path)

    def cleanup(self):
        resolved = self.path.resolve()
        if resolved.parent != self.root or not resolved.name.startswith("journal-"):
            raise RuntimeError("Unsafe unit-test cleanup target")
        shutil.rmtree(resolved)


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def protocol(observations=20):
    return {"budgets": {"successful_observations": observations, "max_formal_calls": 5770,
                       "max_failed_pass_retries": 10, "max_warmup_calls": 1,
                       "max_gpu_seconds": 900, "max_inference_wall_seconds": 900,
                       "max_task_wall_seconds": 1800}}


def identities():
    return {"protocol_sha256": "1" * 64, "weight_sha256": "2" * 64,
            "scientific_inputs_sha256": "3" * 64, "execution_source_sha256": "4" * 64}


def empty_budget():
    return {"schema_version": 1, "task_started_epoch": 1000., "task_started_at": "start",
            "inference_started_epoch": None, "inference_started_at": None,
            "inference_finished_epoch": None, "inference_finished_at": None,
            "formal_attempts": [], "warmup_attempts": [], "formal_calls": 0,
            "warmup_calls": 0, "successful_observations": 0, "gpu_seconds": 0.,
            "task_wall_seconds": 0., "inference_wall_seconds": 0., "resumable": True,
            "resume_chain": [], "wall_segments": []}


class Worker:
    """The current worker call/checkpoint sequence, with known fake timing."""
    def __init__(self, directory, count=20):
        self.directory, self.protocol, self.identity = directory, protocol(count), identities()
        self.budget, self.index = empty_budget(), {"schema_version": 1, "checkpoints": []}
        (directory / "checkpoints").mkdir()
        self.writer = journal.PassJournal(directory, self.protocol, self.budget, self.index, self.identity)

    def start(self, number, *, warmup=False):
        collection = self.budget["warmup_attempts" if warmup else "formal_attempts"]
        if self.budget["inference_started_epoch"] is None:
            self.budget["inference_started_epoch"] = 1000.
            self.budget["inference_started_at"] = "infer"
        row = {"call_index": len(collection) + 1, "image_id": f"image-{number // 9}",
               "pass_id": number % 9, "status": "started", "utc_started": "start-call",
               "utc_finished": None, "elapsed_seconds": None, "gpu_seconds": None}
        collection.append(row)
        self.budget["warmup_calls" if warmup else "formal_calls"] = len(collection)
        self.writer.started(row, warmup=warmup)
        return row

    def finish(self, row, *, warmup=False, status="passed", gpu=.001, elapsed=.002):
        row.update(status=status, utc_finished="finish-call", elapsed_seconds=elapsed, gpu_seconds=gpu)
        if gpu is not None:
            self.budget["gpu_seconds"] += gpu
        if gpu is None or elapsed is None:
            self.budget["resumable"] = False
        self.budget["task_wall_seconds"] += .002
        self.budget["inference_wall_seconds"] += .002
        self.writer.finished(row, warmup=warmup)

    def checkpoint(self, row):
        identity = {"image_id": row["image_id"], "image_index": int(row["image_id"].split("-")[-1]),
                    "pass_id": row["pass_id"], "crop": [0, 0, 640, 640],
                    "source_image_sha256": "5" * 64, "decoded_image_sha256": "6" * 64,
                    "input_pixels_sha256": "7" * 64,
                    **{key: value for key, value in self.identity.items() if key != "execution_source_sha256"}}
        observation = {**identity, "call_index": row["call_index"],
                       "elapsed_seconds": row["elapsed_seconds"], "gpu_seconds": row["gpu_seconds"],
                       "environment_identity": "8" * 64, "local_predictions": [], "global_predictions": []}
        relative = f"checkpoints/{identity['image_index']:04d}-{row['pass_id']}.json"
        payload = {"identity": identity, "observation": observation,
                   "environment_identity": "8" * 64, "observation_sha256": canonical(observation)}
        record = journal.write_immutable_json(self.directory / relative, payload)
        entry = {"image_id": row["image_id"], "pass_id": row["pass_id"], "call_index": row["call_index"],
                 "relative_path": relative, **record}
        self.index["checkpoints"].append(entry)
        self.budget["successful_observations"] = len(self.index["checkpoints"])
        self.writer.checkpoint(entry)
        return entry

    def pass_(self, number, *, checkpoint=True):
        row = self.start(number)
        self.finish(row)
        if checkpoint:
            self.checkpoint(row)
        return row

    def load(self, **options):
        return journal.load_journal(self.directory, self.protocol, self.identity, **options)


class SlicedJournalTests(unittest.TestCase):
    def setUp(self):
        self.temporary = Scratch("journal-unit-")
        self.directory = Path(self.temporary.name) / "task"
        self.directory.mkdir()
        self.workers = []

    def tearDown(self):
        for worker in self.workers:
            worker.writer.close()
        self.temporary.cleanup()

    def worker(self, count=20):
        value = Worker(self.directory, count)
        self.workers.append(value)
        return value

    def test_twenty_passes_and_one_warmup_roundtrip_legacy_fields(self):
        worker = self.worker()
        row = worker.start(0, warmup=True)
        worker.finish(row, warmup=True)
        for number in range(20):
            worker.pass_(number)
        receipt = worker.writer.publish("completed")
        state = worker.load()
        self.assertEqual((state.budget["formal_calls"], state.budget["warmup_calls"], state.budget["successful_observations"]), (20, 1, 20))
        self.assertAlmostEqual(state.budget["gpu_seconds"], .021)
        self.assertEqual(state.budget["schema_version"], 1)
        self.assertEqual(state.budget["journal_version"], 2)
        self.assertEqual(receipt["journal_sha256"], state.journal_sha256)
        self.assertEqual(state.checkpoint_index["checkpoints"], worker.index["checkpoints"])
        self.assertEqual(worker.writer.stats["full_budget_writes"], 1)
        self.assertEqual(worker.writer.stats["full_index_writes"], 1)
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, now_epoch=1001.)
        with self.assertRaises(journal.JournalError):
            worker.writer.publish("completed")

    def test_started_is_fsynced_before_predict_can_be_called(self):
        worker = self.worker()
        with patch.object(journal.os, "fsync", wraps=journal.os.fsync) as sync:
            worker.start(0)
            self.assertEqual(sync.call_count, 1)
            state = worker.load(check_published=False)
            self.assertEqual(state.budget["formal_attempts"][0]["status"], "started")
            self.assertFalse(state.budget["resumable"])
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, now_epoch=1001., check_published=False)

    def test_known_gpu_with_unknown_elapsed_is_charged_and_nonresumable(self):
        worker = self.worker()
        row = worker.start(0)
        worker.finish(row, status="failed", gpu=3., elapsed=None)
        worker.writer.publish("failed")
        state = worker.load()
        self.assertEqual(state.budget["gpu_seconds"], 3.)
        self.assertFalse(state.budget["resumable"])
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, now_epoch=1001.)

    def test_unknown_gpu_is_never_treated_as_zero_cost_resume(self):
        worker = self.worker()
        row = worker.start(0)
        worker.finish(row, status="failed", gpu=None)
        worker.writer.publish("failed")
        self.assertFalse(worker.load().budget["resumable"])
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, now_epoch=1001.)

    def test_torn_tail_inspection_keeps_known_prefix_and_never_resumes(self):
        worker = self.worker()
        worker.pass_(0)
        worker.writer.close()
        path = self.directory / journal.JOURNAL_FILE
        with path.open("ab") as stream:
            stream.write(b'{"sequence":5,"event":"started"')
        before = path.read_bytes()
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False)
        state = worker.load(check_published=False, inspection_only_allow_truncated_tail=True)
        self.assertEqual(state.budget["formal_calls"], 1)
        self.assertEqual(state.budget["successful_observations"], 1)
        self.assertTrue(state.uncertain_tail)
        self.assertFalse(state.budget["resumable"])
        self.assertGreater(state.unparsed_tail_bytes, 0)
        self.assertEqual(path.read_bytes(), before)
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, check_published=False, inspection_only_allow_truncated_tail=True)

    def test_snapshot_is_untrusted_and_never_replaces_journal(self):
        worker = self.worker()
        worker.pass_(0)
        (self.directory / journal.SNAPSHOT_FILE).write_text('{"formal_calls":0,"gpu_seconds":0}', encoding="utf-8")
        state = worker.load(check_published=False, require_resumable=True, now_epoch=1001.)
        self.assertEqual(state.budget["formal_calls"], 1)
        self.assertAlmostEqual(state.budget["gpu_seconds"], .001)

    def test_source_and_frozen_budget_identity_cannot_change(self):
        worker = self.worker()
        identity = {**worker.identity, "execution_source_sha256": "9" * 64}
        with self.assertRaises(journal.JournalError):
            journal.load_journal(self.directory, worker.protocol, identity)
        altered = deepcopy(worker.protocol)
        altered["budgets"]["max_formal_calls"] = 6000
        with self.assertRaises(journal.JournalError):
            journal.load_journal(self.directory, altered, worker.identity)
        with self.assertRaises(journal.JournalError):
            journal.execution_identity({**worker.identity, "journal_source_sha256": "a" * 64})

    def test_nonempty_version_one_cache_is_not_imported(self):
        budget = empty_budget()
        budget["formal_attempts"].append({"call_index": 1})
        with self.assertRaises(journal.JournalError):
            journal.PassJournal(self.directory, protocol(), budget, {"checkpoints": []}, identities())
        with self.assertRaises(journal.JournalError):
            journal.PassJournal(self.directory, protocol(), empty_budget(), {"checkpoints": [{"call_index": 1}]}, identities())

    def test_checkpoint_mutation_and_unpromoted_file_refuse_resume(self):
        worker = self.worker()
        entry = worker.checkpoint(worker.pass_(0, checkpoint=False))
        path = self.directory / entry["relative_path"]
        original = path.read_bytes()
        path.write_bytes(original + b" ")
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, require_resumable=True, now_epoch=1001.)
        path.write_bytes(original)
        (self.directory / "checkpoints" / "orphan.json").write_text("{}", encoding="utf-8")
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, require_resumable=True, now_epoch=1001.)

    def test_passed_call_without_checkpoint_is_not_repredicted_on_resume(self):
        worker = self.worker()
        worker.pass_(0, checkpoint=False)
        self.assertFalse(worker.load(check_published=False).budget["resumable"])
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, require_resumable=True, now_epoch=1001.)

    def test_conservative_nonresume_flag_is_preserved_without_inventing_gpu_cost(self):
        worker = self.worker()
        worker.pass_(0)
        worker.budget["resumable"] = False
        worker.writer.publish("failed")
        state = worker.load()
        self.assertFalse(state.budget["resumable"])
        self.assertAlmostEqual(state.budget["gpu_seconds"], .001)

    def test_immutable_checkpoint_does_not_overwrite_existing_bytes(self):
        path = self.directory / "immutable.json"
        journal.write_immutable_json(path, {"original": 1})
        before = path.read_bytes()
        with self.assertRaises(FileExistsError):
            journal.write_immutable_json(path, {"original": 2})
        self.assertEqual(path.read_bytes(), before)

    def test_duplicate_start_and_checkpoint_are_rejected(self):
        worker = self.worker()
        row = worker.start(0)
        with self.assertRaises(journal.JournalError):
            worker.writer.started(row)
        worker.finish(row)
        entry = worker.checkpoint(row)
        with self.assertRaises(journal.JournalError):
            worker.writer.checkpoint(entry)

    def test_changed_finish_identity_is_rejected(self):
        worker = self.worker()
        row = worker.start(0)
        row["image_id"] = "changed"
        with self.assertRaises(journal.JournalError):
            worker.finish(row)

    def test_gpu_overrun_is_durable_then_further_predictions_stop(self):
        worker = self.worker()
        row = worker.start(0)
        worker.finish(row, status="failed", gpu=901.)
        worker.writer.publish("failed")
        self.assertEqual(worker.load().budget["gpu_seconds"], 901.)
        with self.assertRaises(journal.JournalError):
            worker.load(require_resumable=True, now_epoch=1001.)

    def test_wall_overrun_is_rejected_before_started_can_reach_predict(self):
        worker = self.worker()
        worker.budget["task_wall_seconds"] = 1801.
        with self.assertRaises(journal.JournalError):
            worker.start(0)
        state = worker.load(check_published=False)
        self.assertEqual(state.budget["formal_calls"], 0)

    def test_absolute_deadline_does_not_reset_at_recovery(self):
        worker = self.worker()
        worker.pass_(0)
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, require_resumable=True, now_epoch=1901.)
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, require_resumable=True, now_epoch=2801.)

    def test_known_failed_call_can_resume_in_new_directory_with_bound_prefix(self):
        worker = self.worker(count=2)
        worker.pass_(0)
        row = worker.start(1)
        worker.finish(row, status="failed")
        worker.writer.publish("failed")
        prior = worker.load(require_resumable=True, now_epoch=1001.)
        destination = Path(self.temporary.name) / "new-task"
        shutil.copytree(self.directory, destination)
        budget, index = deepcopy(prior.budget), deepcopy(prior.checkpoint_index)
        budget["resume_chain"].append({"task_id": self.directory.name, "failure_sha256": "a" * 64,
                                      "budget_sha256": hashlib.sha256((self.directory / "budget.json").read_bytes()).hexdigest(),
                                      "checkpoint_index_sha256": hashlib.sha256((self.directory / "checkpoint_index.json").read_bytes()).hexdigest(),
                                      "journal_head_sha256": prior.journal_sha256,
                                      "journal_file_sha256": hashlib.sha256((self.directory / journal.JOURNAL_FILE).read_bytes()).hexdigest()})
        resumed = journal.PassJournal.resume(destination, worker.protocol, budget, index, worker.identity, now_epoch=1001.)
        try:
            other = object.__new__(Worker)
            other.directory, other.protocol, other.identity = destination, worker.protocol, worker.identity
            other.budget, other.index, other.writer = budget, index, resumed
            other.pass_(1)
            resumed.publish("completed")
            state = other.load()
            self.assertEqual(state.budget["formal_calls"], 3)
            self.assertAlmostEqual(state.budget["gpu_seconds"], .003)
            self.assertEqual(state.budget["task_started_epoch"], 1000.)
            self.assertEqual(state.budget["inference_started_epoch"], 1000.)
            self.assertEqual(state.budget["successful_observations"], 2)
        finally:
            resumed.close()

    def test_corrupted_chain_sequence_and_duplicate_json_are_not_tolerated(self):
        worker = self.worker()
        worker.pass_(0)
        worker.writer.close()
        path = self.directory / journal.JOURNAL_FILE
        original = path.read_bytes()
        lines = original.splitlines(keepends=True)
        row = json.loads(lines[1])
        row["sequence"] = 1
        lines[1] = (json.dumps(row) + "\n").encode()
        path.write_bytes(b"".join(lines))
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False, inspection_only_allow_truncated_tail=True)
        path.write_bytes(original.replace(b'"event":"started"', b'"event":"started","event":"finished"', 1))
        with self.assertRaises(journal.JournalError):
            worker.load(check_published=False)

    def test_published_counters_cannot_override_durable_call_count(self):
        worker = self.worker(count=1)
        worker.pass_(0)
        worker.writer.publish("completed")
        path = self.directory / "budget.json"
        budget = json.loads(path.read_text(encoding="utf-8"))
        budget["formal_calls"] = 0
        path.write_text(json.dumps(budget), encoding="utf-8")
        with self.assertRaises(journal.JournalError):
            worker.load()

    def test_nan_bool_timing_and_escaping_checkpoint_are_rejected(self):
        worker = self.worker()
        row = worker.start(0)
        row.update(status="failed", utc_finished="end", elapsed_seconds=True, gpu_seconds=0.)
        with self.assertRaises(journal.JournalError):
            worker.writer.finished(row)
        for relative in ("../escape.json", "checkpoints/../escape.json", "checkpoints/a/b.json", "E:/escape.json"):
            with self.subTest(relative=relative), self.assertRaises(journal.JournalError):
                worker.writer.checkpoint({"relative_path": relative})

    def test_5000_fake_passes_write_linear_journal_and_bounded_snapshots(self):
        worker = self.worker(count=5760)
        # Real small-case tests above exercise fsync. This IO complexity oracle
        # counts large journal bytes without 10,000 physical disk flush waits.
        samples = {}
        with patch.object(journal.os, "fsync") as sync:
            for number in range(5000):
                worker.pass_(number, checkpoint=False)
                if (number + 1) % 32 == 0:
                    worker.writer.snapshot()
                if number + 1 in (1000, 5000):
                    samples[number + 1] = worker.writer.stats["journal_bytes"]
            self.assertEqual(worker.writer.stats["full_budget_writes"], 0)
            self.assertEqual(worker.writer.stats["full_index_writes"], 0)
            worker.writer.publish("failed")
            self.assertGreaterEqual(sync.call_count, 10_000)
        self.assertEqual(worker.writer.stats["journal_events"], 10_002)
        self.assertEqual(worker.writer.stats["full_budget_writes"], 1)
        self.assertEqual(worker.writer.stats["full_index_writes"], 1)
        self.assertLess(samples[5000], samples[1000] * 6)
        self.assertLess(worker.writer.stats["max_snapshot_bytes"], 1200)
        self.assertLess(worker.writer.stats["snapshot_bytes"], 200_000)
        state = worker.load()
        self.assertEqual(state.budget["formal_calls"], 5000)
        self.assertEqual(len(state.budget["formal_attempts"]), 5000)
        self.assertEqual(state.budget["successful_observations"], 0)


class ReplaceRetryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = Scratch("journal-replace-unit-")
        self.path = Path(self.temporary.name) / "snapshot.json"

    def tearDown(self):
        self.temporary.cleanup()

    @staticmethod
    def windows_error(code):
        error = PermissionError("simulated reader holds destination")
        error.winerror = code
        return error

    def test_only_replace_is_retried_with_same_bytes_without_predict_repeat(self):
        original = journal.os.replace
        seen, sleeps, predictions = [], [], []
        def replace(source, destination):
            seen.append(Path(source).read_bytes())
            if len(seen) <= 3:
                raise self.windows_error((5, 32, 33)[len(seen) - 1])
            return original(source, destination)
        predictions.append("one fake prediction")
        with patch.object(journal.os, "replace", side_effect=replace), patch.object(journal.time, "sleep", side_effect=sleeps.append), patch.object(journal.time, "monotonic", return_value=0.):
            journal.atomic_write_json(self.path, {"same": "bytes"})
        self.assertEqual(len(predictions), 1)
        self.assertEqual(len(seen), 4)
        self.assertTrue(all(value == seen[0] for value in seen))
        self.assertLessEqual(sum(sleeps), .15)
        self.assertEqual(json.loads(self.path.read_text(encoding="utf-8")), {"same": "bytes"})

    def test_persistent_reader_has_strict_150ms_bound_and_preserves_destination(self):
        self.path.write_bytes(b"original")
        sleeps = []
        with patch.object(journal.os, "replace", side_effect=self.windows_error(5)) as replace, patch.object(journal.time, "sleep", side_effect=sleeps.append), patch.object(journal.time, "monotonic", return_value=0.):
            with self.assertRaises(PermissionError):
                journal.atomic_write_json(self.path, {"different": "bytes"})
        self.assertLessEqual(sum(sleeps), .15000000001)
        self.assertLessEqual(replace.call_count, 8)
        self.assertEqual(self.path.read_bytes(), b"original")
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_unrelated_error_is_not_retried(self):
        with patch.object(journal.os, "replace", side_effect=OSError("disk or unrelated IO failure")) as replace, patch.object(journal.time, "sleep") as sleep:
            with self.assertRaises(OSError):
                journal.atomic_write_json(self.path, {"value": 1})
        self.assertEqual(replace.call_count, 1)
        sleep.assert_not_called()


if __name__ == "__main__":
    unittest.main()
