"""Two-image oracle exercises publication, cost, source reuse and pass recovery.

No production image, detector or GPU is used. Geometry/fusion/scoring and the
durable checkpoint implementation are real; only the source and backend vary.
"""
import copy
import json
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

import cv2
import numpy as np

from defect_researcher import sliced_task as runner
from defect_researcher import sliced_worker as worker
from defect_researcher import sliced_journal as durability
from defect_researcher.audit import _artifact_record, _configured_paths, _sha256
from defect_researcher.detection_metrics import score_detections
from test_config import temporary_workspace
from test_geometry_verifier import geometry_configuration


def fixture(root):
    configuration = geometry_configuration(root)
    paths = _configured_paths(configuration)
    protocol = copy.deepcopy(runner._protocol())
    protocol["population"] = {"images": 2, "gt": 1, "normal_images": 1, "medium_gt": 1,
                              "medium_images": 1, "width": 1920, "height": 1080}
    protocol["budgets"]["successful_observations"] = 18
    protocol["budgets"]["max_formal_calls"] = 28
    protocol["bootstrap"]["resamples"] = 2000
    source = paths["output_root"] / protocol["source_task_id"]
    diagnosis = paths["output_root"] / protocol["diagnosis_task_id"]
    source.mkdir(parents=True)
    diagnosis.mkdir()
    frozen = root / "source-input.txt"
    frozen.write_text("sealed fixture source\n", encoding="utf-8")
    records = []
    for index in range(2):
        image = np.zeros((1080,1920,3), dtype=np.uint8)
        image[:,:,0] = np.arange(1920,dtype=np.int64)[None,:] % 255
        image[:,:,1] = np.arange(1080,dtype=np.int64)[:,None] % 255
        image[:,:,2] = index
        image_path = root / f"fixture-{index:04d}.png"
        if not cv2.imwrite(str(image_path),image):
            raise AssertionError("Fixture PNG write failed")
        truth = [{"class_id":0,"xyxy":[50.,50.,100.,100.]}] if index == 0 else []
        records.append({"image_id":image_path.stem,"width":1920,"height":1080,"split":"val",
                        "image_path":str(image_path),"source_path":str(image_path),
                        "ground_truth":truth,"predictions":[{**g,"confidence":.9} for g in truth],
                        "eval_imgsz":640,"precision":"FP32","device":"0"})
    runner._jsonl(source / "predictions_640.jsonl", records)
    metrics = score_detections(records,{int(k):v for k,v in protocol["class_names"].items()})
    runner._write(source / "metrics_640.json",metrics)
    for directory in (source,diagnosis):
        runner._write(directory / "completion.json",{"fixture":"source chain sealed independently in production"})
        runner._write(directory / "artifact_manifest.json",{"fixture":"bound hand oracle"})
    sources = {"fixture_input":frozen, **{f"image/{r['image_id']}":Path(r["image_path"]) for r in records},
               **{f"parent/{p.parent.name}/{p.name}":p for d in (source,diagnosis) for p in d.iterdir()}}
    application = Path(runner.__file__).resolve().parents[1]
    sources.update({"sliced_runner": Path(runner.__file__).resolve(), "sliced_worker": Path(worker.__file__).resolve(),
                    "sliced_core": application/"defect_researcher"/"sliced_inference.py",
                    "stratified_statistics": application/"defect_researcher"/"stratified_statistics.py",
                    "sliced_independent_verifier": application/"tools"/"verify_sliced_run.py",
                    "sliced_journal": Path(durability.__file__).resolve(),
                    "sliced_journal_independent_verifier": application/"tools"/"verify_sliced_journal.py"})
    before = {role:{**_artifact_record(path),"role":role} for role,path in sources.items()}
    environment = FakeBackend.make_environment(frozen)
    def load_source(observed_paths, observed_protocol):
        if not runner._equal(observed_protocol,protocol) or observed_paths != paths:
            raise AssertionError("Unexpected fixture protocol/configuration")
        # Production loader performs the complete saved contract checks. This
        # fixture loader still requires unchanged sealed source/image bytes.
        for role,record in before.items():
            if _artifact_record(sources[role]) != {k:v for k,v in record.items() if k != "role"}:
                raise ValueError("Sealed fixture source bytes changed")
        return source,diagnosis,sources,before,copy.deepcopy(records),copy.deepcopy(environment)
    return configuration,protocol,source,frozen,load_source


class FakeBackend:
    @staticmethod
    def make_environment(frozen):
        return {"python":"fixture","torch":"fixture","ultralytics":"fixture","cv2":"fixture","cuda":"fixture",
                "cudnn":1,"device":"0","gpu_name":"fixture","gpu_total_bytes":1,"precision":"FP32",
                "tf32_matmul":False,"tf32_cudnn":False,"cudnn_benchmark":False,"cudnn_deterministic":True,
                "actual_predictor_options":{"imgsz":640,"batch":1,"conf":.001,"iou":.7,"max_det":300,
                    "rect":False,"augment":False,"agnostic_nms":False,"quantize":None,"nms":False},
                "actual_predictor_imgsz":[640,640],"actual_predictor_fp16":False,"actual_predictor_device":"cuda:0",
                "actual_input_dtype":"torch.float32","actual_input_device":"cuda:0","model_parameters_dtype":"torch.float32",
                "callable_sources":{"fixture":_artifact_record(frozen)},"legacy_dependency_source_hashes_available":False,
                "peak_allocated_bytes":1}
    def __init__(self,request,calls,fail=None,changed_context=False,invalid=None):
        self.request,self.calls,self.fail = request,calls,fail
        self.changed_context,self.invalid = changed_context,invalid
        self.last_timing = None
    def predict(self,source,shape):
        if isinstance(source,str):
            image_id,pass_id = Path(source).stem,0
            predictions = copy.deepcopy(next(r["predictions"] for r in self.request["records"] if r["image_id"] == image_id))
            if self.changed_context and predictions:
                predictions[0]["confidence"] -= .00001
        else:
            image_index = int(source[0,0,2])
            x = {0:0,2:512,4:1024,5:1280}[int(source[0,0,0])]
            y = {0:0,185:440}[int(source[0,0,1])]
            image_id = f"fixture-{image_index:04d}"
            pass_id = 1+[0,440].index(y)*4+[0,512,1024,1280].index(x)
            predictions = []
        self.calls.append((image_id,pass_id))
        self.last_timing = {"elapsed_seconds":.002,"gpu_seconds":.001}
        if (image_id,pass_id) == self.fail:
            raise MemoryError("CUDA out of memory fixture; no fallback permitted")
        if self.invalid == "nonfinite" and pass_id == 1:
            predictions = [{"class_id":0,"confidence":.5,"xyxy":[0.,0.,float('nan'),10.]}]
        environment = self.request["reference_environment"]
        return {"local_predictions":predictions,"effective_options":copy.deepcopy(environment["actual_predictor_options"]),
                "orig_shape":list(shape),"device":"cuda:0","precision":"FP32","actual_input_dtype":"torch.float32",
                "actual_input_device":"cuda:0","model_parameters_dtype":"torch.float32","ultralytics_speed_ms":{}}
    def environment(self,initial=False):
        return copy.deepcopy(self.request["reference_environment"])
    def close(self):
        pass


def inline_worker(calls,fail=None,changed_context=False,invalid=None):
    def run(directory,request,protocol):
        runner._write(directory / runner.FILES["worker_request"],request)
        receipt = worker._execute(request,lambda r:FakeBackend(r,calls,fail,changed_context,invalid))
        if receipt["status"] != "completed":
            raise RuntimeError(str(receipt["error"]))
    return run


class SlicedTaskTests(unittest.TestCase):
    def setUp(self):
        self.real_independent_review=runner._independent_review
        # The separate production oracle is exercised by its own independent
        # suite. This hand fixture binds its exact candidate and never accepts
        # a production task through the mock.
        def accept(directory,result,output_path,remaining):
            if len(runner._rows(directory/runner.FILES["observations"])) != 18:
                raise AssertionError("Only the isolated eighteen-pass fixture is accepted")
            output_path.parent.mkdir(parents=True,exist_ok=True)
            report={"status":"passed","task_id":result["task_id"],"passed_checks":1,"total_checks":1,"checks":{"isolated fixture":True},
                    "prepublication":True,**runner._review_bindings(directory,result,"completion_candidate.json"),
                    "acceptance_total_wall_seconds":result["summary"]["total_task_wall_seconds"]+1}
            runner._write(output_path,report)
            return report
        self.accept=accept
        self.review_patch=patch.object(runner,"_independent_review",side_effect=accept)
        self.review_patch.start()
        self.addCleanup(self.review_patch.stop)

    def complete(self,root,task_id="sliced"):
        configuration,protocol,source,frozen,load_source = fixture(root)
        calls = []
        with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load_source),patch.object(runner,"_run_worker",side_effect=inline_worker(calls)):
            result = runner.run_sliced_comparison(configuration,task_id)
        self.assertEqual(result["status"],"completed",result["errors"])
        return configuration,protocol,source,frozen,load_source,calls,result

    def test_actual_protocol_is_frozen_without_test_or_training_or_fallback(self):
        protocol = runner._protocol()
        self.assertEqual(protocol["budgets"]["successful_observations"],5760)
        self.assertEqual(protocol["budgets"]["max_formal_calls"],5770)
        self.assertFalse(protocol["training_performed"])
        self.assertFalse(protocol["test_inference_performed"])
        for field,value in (("device","cpu"),("precision","FP16"),("batch",True),("rect",0),("test_inference_performed",True)):
            with self.subTest(field=field),patch.object(runner,"_read",return_value={**protocol,field:value}):
                with self.assertRaisesRegex(ValueError,field):
                    runner._protocol()

    def test_real_core_publication_is_completion_last_and_exact_unique_passes(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load_source = fixture(root)
            calls=[]
            original={p:p.read_bytes() for p in root.rglob("*") if p.is_file()}
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load_source),patch.object(runner,"_run_worker",side_effect=inline_worker(calls)),patch.object(runner,"_atomic_text",wraps=runner._atomic_text) as writes:
                result=runner.run_sliced_comparison(configuration,"oracle")
            self.assertEqual(result["status"],"completed",result["errors"])
            self.assertEqual(writes.call_args_list[-1].args[0].name,"completion.json")
            directory=Path(configuration["output_root"])/"oracle"
            self.assertEqual(len(calls),19) # one warmup, exactly eighteen formal
            rows=runner._rows(directory/runner.FILES["observations"])
            self.assertEqual(len({(r["image_id"],r["pass_id"]) for r in rows}),18)
            self.assertEqual(result["summary"]["baseline"]["tp"],1)
            self.assertEqual(result["summary"]["sliced"]["tp"],1)
            self.assertEqual(result["summary"]["candidate_status"],"stop")
            self.assertTrue(result["summary"]["reference_reused"])
            manifest=runner._read(directory/runner.FILES["manifest"])
            self.assertTrue(all(Path(r["path"]).parent==directory for r in manifest["files"]))
            for path,content in original.items():
                self.assertEqual(path.read_bytes(),content)

    def test_existing_directory_and_unsafe_ids_are_not_modified(self):
        with temporary_workspace() as root:
            configuration=geometry_configuration(root)
            existing=Path(configuration["output_root"])/"existing"
            existing.mkdir(parents=True)
            sentinel=existing/"completion.json"
            sentinel.write_bytes(b"preserve")
            with patch.object(runner,"_load_source") as load:
                result=runner.run_sliced_comparison(configuration,"existing")
                self.assertEqual(result["status"],"failed")
                self.assertEqual(sentinel.read_bytes(),b"preserve")
                load.assert_not_called()
            for task_id in ("../escape","bad\\slash",True,"x"*129):
                self.assertEqual(runner.run_sliced_comparison(configuration,task_id)["status"],"failed")

    def test_changed_fresh_context_refuses_saved_reference_without_extra_group(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            calls=[]
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker(calls,changed_context=True)):
                result=runner.run_sliced_comparison(configuration,"different-context")
            self.assertEqual(result["status"],"failed")
            self.assertEqual(result["errors"][0]["stage"],"context_reference_reuse")
            self.assertIn("reference_reuse_refused",result["errors"][0]["message"])
            self.assertEqual(len(calls),19)
            self.assertFalse((Path(configuration["output_root"])/"different-context"/"completion.json").exists())

    def test_oom_keeps_checkpoints_and_recovers_only_missing_passes_with_cumulative_budget(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            first_calls,resumed_calls=[],[]
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                with patch.object(runner,"_run_worker",side_effect=inline_worker(first_calls,fail=("fixture-0000",3))):
                    failed=runner.run_sliced_comparison(configuration,"interrupted")
                failed_dir=Path(configuration["output_root"])/"interrupted"
                original={p:p.read_bytes() for p in failed_dir.rglob("*") if p.is_file()}
                self.assertEqual(failed["status"],"failed")
                self.assertEqual(len(runner._checkpoint_rows(failed_dir)),3)
                with patch.object(runner,"_run_worker",side_effect=inline_worker(resumed_calls)):
                    resumed=runner.run_sliced_comparison(configuration,"resumed",resume_from="interrupted")
            self.assertEqual(resumed["status"],"completed",resumed["errors"])
            self.assertEqual(len(resumed_calls),15)
            self.assertTrue(all(key not in resumed_calls for key in (("fixture-0000",0),("fixture-0000",1),("fixture-0000",2))))
            self.assertEqual(resumed["summary"]["formal_calls"],19)
            self.assertEqual(resumed["summary"]["warmup_calls"],1)
            self.assertAlmostEqual(resumed["summary"]["gpu_seconds"],.020)
            for path,content in original.items():
                self.assertEqual(path.read_bytes(),content)

    def test_damaged_checkpoint_refuses_resume_before_new_inference(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                with patch.object(runner,"_run_worker",side_effect=inline_worker([],fail=("fixture-0000",2))):
                    runner.run_sliced_comparison(configuration,"failed")
                checkpoint=Path(configuration["output_root"])/"failed"/"checkpoints"/"0000-0.json"
                checkpoint.write_text("damaged",encoding="utf-8")
                with patch.object(runner,"_run_worker") as inference:
                    result=runner.run_sliced_comparison(configuration,"resume-rejected",resume_from="failed")
                    inference.assert_not_called()
            self.assertEqual(result["status"],"failed")
            self.assertIn("Checkpoint bytes differ",result["errors"][0]["message"])

    def test_changed_source_refuses_resume_and_preserves_prior_attempt(self):
        with temporary_workspace() as root:
            configuration,protocol,_,frozen,load=fixture(root)
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                with patch.object(runner,"_run_worker",side_effect=inline_worker([],fail=("fixture-0000",2))):
                    runner.run_sliced_comparison(configuration,"failed")
                frozen.write_text("source changed",encoding="utf-8")
                with patch.object(runner,"_run_worker") as inference:
                    result=runner.run_sliced_comparison(configuration,"changed-source",resume_from="failed")
                    inference.assert_not_called()
            self.assertEqual(result["status"],"failed")
            self.assertIn("source bytes changed",result["errors"][0]["message"])

    def test_nonfinite_output_is_not_dropped_to_complete_population(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            calls=[]
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker(calls,invalid="nonfinite")):
                result=runner.run_sliced_comparison(configuration,"invalid")
            self.assertEqual(result["status"],"failed")
            self.assertEqual(len(calls),3)
            self.assertFalse((Path(configuration["output_root"])/"invalid"/"completion.json").exists())

    def test_source_mutation_after_inference_prevents_completion(self):
        with temporary_workspace() as root:
            configuration,protocol,_,frozen,load=fixture(root)
            actual=inline_worker([])
            def mutate(directory,request,observed_protocol):
                actual(directory,request,observed_protocol)
                frozen.write_text("external mutation",encoding="utf-8")
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=mutate):
                result=runner.run_sliced_comparison(configuration,"mutated")
            self.assertEqual(result["status"],"failed")
            self.assertEqual(result["errors"][0]["stage"],"input_recheck")

    def test_independent_deadline_terminates_child_and_forbids_uncertain_resume(self):
        with temporary_workspace() as root:
            directory=root/"worker"
            directory.mkdir()
            protocol=runner._protocol()
            budget = runner._new_budget(worker.time.time())
            index = {"schema_version":1,"checkpoints":[]}
            runner._write(directory/"budget.json",budget)
            runner._write(directory/"checkpoint_index.json",index)
            request={"task_monotonic_elapsed_before_worker":0, "protocol": protocol,
                     "protocol_sha256":"1"*64, "scientific_inputs_sha256":"2"*64,
                     "execution_source_sha256":"3"*64, "execution_io_version":2}
            journal = durability.PassJournal(directory,protocol,budget,index,runner._journal_identity(request))
            budget.update(inference_started_epoch=worker.time.time())
            attempt={"call_index":1,"image_id":"fixture","pass_id":0,"status":"started",
                     "utc_started":"2026-10-11T00:00:00Z","utc_finished":None,"elapsed_seconds":None,"gpu_seconds":None}
            budget["warmup_attempts"].append(attempt)
            journal.started(attempt,warmup=True)
            journal.close()
            process=type("Process",(),{})()
            process.wait=unittest.mock.Mock(side_effect=[subprocess.TimeoutExpired("worker",900),0])
            process.terminate=unittest.mock.Mock()
            process.kill=unittest.mock.Mock()
            with patch.object(runner.subprocess,"Popen",return_value=process):
                with self.assertRaisesRegex(TimeoutError,"hard deadline"):
                    runner._run_worker(directory,request,protocol)
            process.terminate.assert_called_once()
            process.kill.assert_not_called()
            self.assertFalse(runner._read(directory/"budget.json")["resumable"])
            stopped=runner._read(directory/"budget.json")
            self.assertEqual(stopped["warmup_calls"],1)
            self.assertEqual(stopped["warmup_attempts"][0]["status"],"started")
            self.assertEqual(stopped["warmup_attempts"][0]["gpu_seconds"],None)
            self.assertEqual(stopped["journal_version"],2)
            self.assertTrue(stopped["call_count_known"])
            self.assertFalse(stopped["gpu_total_cost_known"])

    def test_v2_full_documents_are_written_once_and_snapshots_have_bounded_scalars(self):
        with temporary_workspace() as root:
            configuration,_,_,_,_,calls,result=self.complete(root)
            directory=Path(configuration["output_root"])/result["task_id"]
            receipt=runner._read(directory/runner.FILES["worker_receipt"])
            self.assertEqual(len(calls),19)
            self.assertEqual(receipt["durability_io"]["full_budget_writes"],1)
            self.assertEqual(receipt["durability_io"]["full_index_writes"],1)
            self.assertEqual(receipt["durability_io"]["snapshot_writes"],3)
            snapshot=runner._read(directory/runner.FILES["budget_snapshot"])
            self.assertNotIn("formal_attempts",snapshot)
            self.assertNotIn("checkpoints",snapshot)
            self.assertLessEqual(receipt["durability_io"]["max_snapshot_bytes"],16384)
            self.assertEqual(receipt["journal_file_sha256"],_sha256(directory/runner.FILES["journal"]))

    def test_poisoned_progress_publication_preserves_known_calls_from_journal(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            original_write=durability.atomic_write_json
            def busy_snapshot(path,value):
                if Path(path).name==durability.SNAPSHOT_FILE and value["successful_observations"]==1:
                    error=PermissionError("Windows snapshot publication remained busy")
                    error.winerror=5
                    raise error
                return original_write(path,value)
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker([])),patch.object(durability,"atomic_write_json",side_effect=busy_snapshot):
                result=runner.run_sliced_comparison(configuration,"poisoned-cache")
            directory=Path(configuration["output_root"])/result["task_id"]
            budget=runner._read(directory/runner.FILES["budget"])
            self.assertEqual(result["status"],"failed")
            self.assertEqual((budget["formal_calls"],budget["warmup_calls"],budget["successful_observations"]),(1,1,1))
            self.assertAlmostEqual(budget["gpu_seconds"],.002)
            self.assertTrue(budget["stopped_journal_materialized"])
            self.assertFalse((directory/"completion.json").exists())
            # Recovery is a separate task with the original absolute clocks;
            # the one durably promoted pass is never predicted again.
            later_calls=[]
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker(later_calls)):
                resumed=runner.run_sliced_comparison(configuration,"poisoned-cache-resumed",resume_from="poisoned-cache")
            self.assertEqual(resumed["status"],"completed",resumed["errors"])
            self.assertEqual(len(later_calls),17)
            self.assertNotIn(("fixture-0000",0),later_calls)
            self.assertEqual(resumed["summary"]["formal_calls"],18)
            self.assertEqual(resumed["summary"]["warmup_calls"],1)

    def test_missing_v2_journal_and_changed_execution_binding_cannot_import_old_cache(self):
        for variation in ("missing-journal","changed-execution"):
            with self.subTest(variation=variation),temporary_workspace() as root:
                configuration,protocol,_,_,load=fixture(root)
                with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                    with patch.object(runner,"_run_worker",side_effect=inline_worker([],fail=("fixture-0000",2))):
                        runner.run_sliced_comparison(configuration,"prior")
                    prior=Path(configuration["output_root"])/"prior"
                    if variation=="missing-journal":
                        (prior/runner.FILES["journal"]).unlink()
                    else:
                        request=runner._read(prior/runner.FILES["worker_request"])
                        request["execution_source_sha256"]="0"*64
                        runner._write(prior/runner.FILES["worker_request"],request)
                    with patch.object(runner,"_run_worker") as inference:
                        refused=runner.run_sliced_comparison(configuration,"refused",resume_from="prior")
                        inference.assert_not_called()
                self.assertEqual(refused["status"],"failed")
                self.assertIn("Version 1 caches" if variation=="missing-journal" else "execution source/durability",refused["errors"][0]["message"])

    def test_unknown_gpu_cost_is_recorded_and_refused_before_resume(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            predict=FakeBackend.predict
            def unknown(backend,source,shape):
                value=predict(backend,source,shape)
                if len(backend.calls)==3:
                    backend.last_timing["gpu_seconds"]=None
                return value
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(FakeBackend,"predict",unknown):
                with patch.object(runner,"_run_worker",side_effect=inline_worker([])):
                    result=runner.run_sliced_comparison(configuration,"unknown-cost")
                with patch.object(runner,"_run_worker") as inference:
                    resumed=runner.run_sliced_comparison(configuration,"unknown-refused",resume_from="unknown-cost")
                    inference.assert_not_called()
            directory=Path(configuration["output_root"])/result["task_id"]
            budget=runner._read(directory/runner.FILES["budget"])
            self.assertEqual(result["status"],"failed")
            self.assertEqual(budget["formal_calls"],2)
            self.assertIsNone(budget["formal_attempts"][-1]["gpu_seconds"])
            self.assertFalse(budget["resumable"])
            self.assertEqual(resumed["status"],"failed")

    def test_terminal_truncated_journal_exports_complete_prefix_without_truncating(self):
        with temporary_workspace() as root:
            directory=root/"truncated"
            directory.mkdir()
            protocol=runner._protocol()
            budget=runner._new_budget(worker.time.time())
            index={"schema_version":1,"checkpoints":[]}
            runner._write(directory/"budget.json",budget)
            runner._write(directory/"checkpoint_index.json",index)
            request={"protocol":protocol,"protocol_sha256":"1"*64,"scientific_inputs_sha256":"2"*64,
                     "execution_source_sha256":"3"*64,"task_monotonic_elapsed_before_worker":0}
            journal=durability.PassJournal(directory,protocol,budget,index,runner._journal_identity(request))
            budget["inference_started_epoch"]=worker.time.time()
            attempt={"call_index":1,"image_id":"fixture","pass_id":0,"status":"started",
                     "utc_started":"2026-10-11T00:00:00Z","utc_finished":None,"elapsed_seconds":None,"gpu_seconds":None}
            budget["warmup_attempts"].append(attempt)
            journal.started(attempt,warmup=True)
            journal.close()
            with (directory/durability.JOURNAL_FILE).open("ab") as stream:
                stream.write(b'{"sequence":3')
            original=(directory/durability.JOURNAL_FILE).read_bytes()
            stopped=runner._recover_stopped_worker(directory,request,protocol,forced=True,deadline_seconds=900)
            self.assertEqual(stopped["warmup_calls"],1)
            self.assertTrue(stopped["uncertain_journal_tail"])
            self.assertFalse(stopped["resumable"])
            self.assertFalse(stopped["call_count_known"])
            self.assertFalse(stopped["gpu_total_cost_known"])
            self.assertEqual((directory/durability.JOURNAL_FILE).read_bytes(),original)

    def test_corrupted_complete_journal_never_labels_seed_zero_as_actual_cost(self):
        with temporary_workspace() as root:
            directory=root/"invalid-complete-record"
            directory.mkdir()
            protocol=runner._protocol()
            budget=runner._new_budget(worker.time.time())
            index={"schema_version":1,"checkpoints":[]}
            runner._write(directory/"budget.json",budget)
            runner._write(directory/"checkpoint_index.json",index)
            request={"protocol":protocol,"protocol_sha256":"1"*64,"scientific_inputs_sha256":"2"*64,
                     "execution_source_sha256":"3"*64,"task_monotonic_elapsed_before_worker":0}
            journal=durability.PassJournal(directory,protocol,budget,index,runner._journal_identity(request))
            journal.close()
            path=directory/durability.JOURNAL_FILE
            row=runner._rows(path)[0]
            row["sha256"]="0"*64
            runner._jsonl(path,[row])
            original=path.read_bytes()
            stopped=runner._recover_stopped_worker(directory,request,protocol,forced=True,deadline_seconds=900)
            self.assertFalse(stopped["resumable"])
            self.assertFalse(stopped["call_count_known"])
            self.assertFalse(stopped["gpu_total_cost_known"])
            self.assertIn("hash",stopped["journal_replay_error"]["message"])
            self.assertEqual(path.read_bytes(),original)

    def test_budget_uses_monotonic_floor_and_does_not_reset_on_resume(self):
        protocol=runner._protocol()
        budget=runner._new_budget(100.)
        budget.update(inference_started_epoch=100.,inference_wall_seconds=901.)
        with self.assertRaisesRegex(TimeoutError,"never reset"):
            worker._check_budget(budget,protocol,now=99.)
        budget.update(inference_wall_seconds=10.,task_wall_seconds=1801.)
        with self.assertRaisesRegex(TimeoutError,"Task wall"):
            worker._check_budget(budget,protocol,now=99.)

    def test_typed_semantic_reader_rejects_false_zero_precision_and_control_reseal(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load,_,result=self.complete(root)
            directory=Path(configuration["output_root"])/"sliced"
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                summary=copy.deepcopy(result)
                summary["summary"]["baseline"]["fp"]=False
                with self.assertRaisesRegex(ValueError,"summary differs"):
                    runner.verify_sliced_artifacts(directory,summary)
                environment=runner._read(directory/"environment.json")
                environment["actual_predictor_options"]["rect"]=0
                runner._write(directory/"environment.json",environment)
                with self.assertRaisesRegex(ValueError,"FP32 inference controls"):
                    runner.verify_sliced_artifacts(directory,result)

    def test_resealed_scientific_lie_and_duplicate_observations_are_rejected(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load,_,result=self.complete(root)
            directory=Path(configuration["output_root"])/"sliced"
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load):
                comparison=runner._read(directory/"sliced_comparison.json")
                comparison["gains"]["tp_gain"]=99
                runner._write(directory/"sliced_comparison.json",comparison)
                with self.assertRaisesRegex(ValueError,"science differs"):
                    runner.verify_sliced_artifacts(directory,result)
                rows=runner._rows(directory/"pass_observations.jsonl")
                rows.append(rows[0])
                runner._jsonl(directory/"pass_observations.jsonl",rows)
                with self.assertRaisesRegex(ValueError,"observations differ"):
                    runner.verify_sliced_artifacts(directory,result)

    def test_prepublication_independent_failure_and_deadline_forbid_final_marker(self):
        for error in (ValueError("Independent review fixture failed"),TimeoutError("Task deadline fixture expired")):
            with self.subTest(error=type(error).__name__),temporary_workspace() as root:
                configuration,protocol,_,_,load=fixture(root)
                with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker([])),patch.object(runner,"_independent_review",side_effect=error):
                    result=runner.run_sliced_comparison(configuration,"review-refused")
                directory=Path(configuration["output_root"])/"review-refused"
                self.assertEqual(result["status"],"failed")
                self.assertEqual(result["errors"][0]["stage"],"independent_prepublication_review")
                self.assertTrue((directory/"completion_candidate.json").exists())
                self.assertFalse((directory/"completion.json").exists())
                self.assertEqual(len(runner._checkpoint_rows(directory)),18)

    def test_candidate_and_final_marker_bytes_are_identical_and_bound_to_external_review(self):
        with temporary_workspace() as root:
            configuration,_,_,_,_,_,result=self.complete(root)
            directory=Path(configuration["output_root"])/"sliced"
            self.assertEqual((directory/"completion.json").read_bytes(),(directory/"completion_candidate.json").read_bytes())
            independent=runner._read(Path(result["evidence"]["independent_verification_path"]))
            self.assertEqual(independent["task_completion_sha256"],_sha256(directory/"completion.json"))

    def test_changed_artifact_after_independent_acceptance_forbids_publication(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load=fixture(root)
            def corrupt(directory,result,output_path,remaining):
                self.accept(directory,result,output_path,remaining)
                (directory/"predictions_sliced.jsonl").write_text("changed after review",encoding="utf-8")
            with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load),patch.object(runner,"_run_worker",side_effect=inline_worker([])),patch.object(runner,"_independent_review",side_effect=corrupt):
                result=runner.run_sliced_comparison(configuration,"corrupt-after-review")
            self.assertEqual(result["status"],"failed")
            self.assertIn("after independent acceptance",result["errors"][0]["message"])
            self.assertFalse((Path(configuration["output_root"])/"corrupt-after-review"/"completion.json").exists())

    def test_real_independent_receipt_dict_counts_and_exact_candidate_binding(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,_=fixture(root)
            directory=root/"task"
            directory.mkdir()
            runner._write(directory/"completion_candidate.json",{"task_id":"task"})
            runner._write(directory/runner.FILES["manifest"],{"fixture":"manifest"})
            runner._write(directory/runner.FILES["protocol"],protocol)
            result={"task_id":"task","configuration":configuration}
            output=root/"external.json"
            report={"status":"passed","task_id":"task","checks":{"real_dict_shape":True},"passed_checks":1,"total_checks":1,
                    "prepublication":True,**runner._review_bindings(directory,result,"completion_candidate.json"),
                    "acceptance_total_wall_seconds":1.}
            process=type("Process",(),{})()
            process.returncode=0
            process.wait=unittest.mock.Mock(return_value=0)
            for change,success in (({},True),({"passed_checks":True},False),({"checks":{"real_dict_shape":1}},False),
                                   ({"task_completion_sha256":"0"*64},False),({"acceptance_total_wall_seconds":1801.},False)):
                with self.subTest(change=change):
                    runner._write(output,{**report,**change})
                    with patch.object(runner.subprocess,"Popen",return_value=process):
                        if success:
                            self.assertEqual(self.real_independent_review(directory,result,output,10)["status"],"passed")
                        else:
                            with self.assertRaises(ValueError):
                                self.real_independent_review(directory,result,output,10)
            for key in ("task_manifest_sha256","task_protocol_sha256","source_completion_sha256","diagnosis_completion_sha256"):
                for missing in (False,True):
                    broken=copy.deepcopy(report)
                    if missing:
                        broken.pop(key)
                    else:
                        broken[key]="0"*64
                    with self.subTest(binding=key,missing=missing):
                        runner._write(output,broken)
                        with patch.object(runner.subprocess,"Popen",return_value=process),self.assertRaises(ValueError):
                            self.real_independent_review(directory,result,output,10)

    def test_terminal_reader_refuses_missing_or_tampered_independent_five_bindings(self):
        with temporary_workspace() as root:
            configuration,protocol,_,_,load_source,_,result=self.complete(root)
            directory=Path(configuration["output_root"])/result["task_id"]
            receipt_path=Path(result["evidence"]["independent_verification_path"])
            original=runner._read(receipt_path)
            for key in ("task_manifest_sha256","task_protocol_sha256","source_completion_sha256","diagnosis_completion_sha256"):
                for missing in (False,True):
                    broken=copy.deepcopy(original)
                    if missing:
                        broken.pop(key)
                    else:
                        broken[key]="0"*64
                    with self.subTest(binding=key,missing=missing):
                        runner._write(receipt_path,broken)
                        with patch.object(runner,"_protocol",return_value=protocol),patch.object(runner,"_load_source",side_effect=load_source):
                            with self.assertRaisesRegex(ValueError,"prepublication acceptance"):
                                runner.verify_sliced_artifacts(directory,result)


if __name__ == "__main__":
    unittest.main()
