"""Isolated publication fixtures; no real data, scorer, model or GPU runs."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import stat
import time
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

from defect_researcher import sliced_artifact_recovery as recovery
from test_config import temporary_workspace
from test_geometry_verifier import geometry_configuration


def review_contract():
    spec=importlib.util.spec_from_file_location("recovery_contract_fixture",recovery.REVIEWER)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def fixture(root):
    configuration=geometry_configuration(root)
    source=Path(configuration["output_root"])/"fixture-origin"
    source.mkdir(parents=True)
    summary={"slicing_status":"passed","candidate_status":"stop","reference_reused":True,
             "baseline":{"tp":1,"fp":0,"fn":1},"sliced":{"tp":2,"fp":10,"fn":0},
             "medium":{"gt":1,"medium_tp_gain":1},"failed_gates":["overall_fp"],
             "successful_observations":2,"formal_calls":2,"warmup_calls":1,"gpu_seconds":.003,
             "inference_wall_seconds":.02,"total_task_wall_seconds":.05,
             "total_task_wall_seconds_recorded_at":"before_independent_review"}
    recovery._write(source/"failure.json",{"task_id":source.name,"tool":"compare_validation_slices",
                                         "configuration":configuration,
                                         "status":"failed","summary":summary,"errors":[{"stage":"artifact_semantic_validation"}]})
    recovery._write(source/"budget.json",{"task_started_epoch":time.time()-3600,"successful_observations":2,
                                        "inference_finished_epoch":time.time()-3000,"resumable":True})
    options={"imgsz":640,"conf":.001,"nms":None}
    recovery._write(source/"worker_request.json",{"protocol":{"budgets":{"successful_observations":2,"max_task_wall_seconds":1800}},
                                                 "reference_environment":{"actual_predictor_options":options},
                                                 "execution_source_sha256":"1"*64})
    recovery._write(source/"environment.json",{"actual_predictor_options":options})
    recovery._write(source/"worker_receipt.json",{"status":"completed","observations":2})
    recovery._write(source/"inputs.json",{"fixture":"isolated read-only publication test"})
    (source/"checkpoint_journal.jsonl").write_text(json.dumps({"payload":{"identity":{"journal_source_sha256":"2"*64}}})+"\n",encoding="utf-8")
    (source/"checkpoints").mkdir()
    (source/"checkpoints"/"fixture-0.json").write_bytes(b"immutable fixture bytes")
    return configuration,source,summary


def fake_review(configuration,task_id,source_id,directory,output,remaining):
    protocol=recovery._read(directory/recovery.FILES["protocol"])
    source=Path(configuration["output_root"])/source_id
    summary=recovery._read(source/"failure.json")["summary"]
    contract=review_contract()
    checks={name:True for name in contract.REQUIRED_CHECKS}
    report={"schema_version":1,"kind":"saved_sliced_artifact_recovery_review","task_id":task_id,
            "artifact_review_implementation_version":3,
            "computation_task_id":source_id,"source_task_id":source_id,"status":"passed","prepublication":True,
            "execution_source_sha256":protocol["execution_source_sha256"],
            "checks":checks,"passed_checks":len(checks),"total_checks":len(checks),
            "source_failure_sha256":recovery._sha256(source/"failure.json"),
            "source_manifest_sha256":recovery._sha256(directory/recovery.FILES["source_manifest"]),
            "task_protocol_sha256":recovery._sha256(directory/recovery.FILES["protocol"]),
            "independent_reviewer_sha256":protocol["independent_reviewer_sha256"],
            "primary_scientific_verifier_sha256":contract.PRIMARY_SHA256,
            "verified_source_summary":summary,"verified_source_summary_sha256":recovery._canonical(summary),
            "original_business_status":"failed","original_completion_absent":True,
            "original_pipeline_acceptance_passed":False,"recovery_review_seconds":0.,
            "original_budget_reset":False,"original_final_review_completed_within_1800_seconds":False,
            "model_used":False,"gpu_inference_performed_by_reviewer":False,
            "new_predict_calls":0,"new_gpu_calls":0,"new_gpu_seconds":0}
    recovery._write(output,report)
    return report


class ArtifactRecoveryTests(unittest.TestCase):
    def complete(self,root):
        configuration,source,summary=fixture(root)
        with patch.object(recovery,"_invoke_review",side_effect=fake_review):
            report=recovery.run_sliced_artifact_recovery(configuration,"fixture-recovery",source_id=source.name)
        self.assertEqual(report["status"],"completed",report["errors"])
        return configuration,source,summary,report

    def test_publication_last_zero_new_gpu_and_original_failed_bytes_unchanged(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            original={path:path.read_bytes() for path in source.rglob("*") if path.is_file()}
            with patch.object(recovery,"_invoke_review",side_effect=fake_review),patch.object(recovery,"_atomic_text",wraps=recovery._atomic_text) as writes:
                result=recovery.run_sliced_artifact_recovery(configuration,"fixture-recovery",source_id=source.name)
            self.assertEqual(result["status"],"completed",result["errors"])
            self.assertEqual(writes.call_args_list[-1].args[0].name,"completion.json")
            self.assertFalse((source/"completion.json").exists())
            self.assertEqual(result["summary"]["new_formal_calls"],0)
            self.assertEqual(result["summary"]["new_warmup_calls"],0)
            self.assertEqual(result["summary"]["new_gpu_seconds"],0.)
            self.assertFalse(result["summary"]["original_pipeline_acceptance_passed"])
            self.assertEqual(result["summary"]["source_execution"]["formal_calls"],2)
            self.assertNotIn("formal_calls",{key:value for key,value in result["summary"].items() if key!="source_execution"})
            for path,content in original.items():
                self.assertEqual(path.read_bytes(),content)

    def test_missing_science_check_one_true_and_typed_receipt_tampering_never_publish(self):
        changes=[{"checks":{"one_fake_check":True},"passed_checks":1,"total_checks":1},
                 {"total_checks":0},{"passed_checks":True},{"kind":"other"},{"prepublication":False},
                 {"independent_reviewer_sha256":"0"*64},{"primary_scientific_verifier_sha256":"0"*64},
                 {"source_failure_sha256":"0"*64},{"model_used":True},{"new_predict_calls":False}]
        changes.extend({"artifact_review_implementation_version":version} for version in (None,1,2,True,"3",3.0))
        for change in changes:
            with self.subTest(change=change),temporary_workspace() as root:
                configuration,source,_=fixture(root)
                def corrupt(*args):
                    report=fake_review(*args)
                    report.update(change)
                    return report
                with patch.object(recovery,"_invoke_review",side_effect=corrupt):
                    result=recovery.run_sliced_artifact_recovery(configuration,"refused",source_id=source.name)
                self.assertEqual(result["status"],"failed")
                self.assertFalse((Path(configuration["output_root"])/"refused"/"completion.json").exists())

    def test_one_removed_required_check_is_rejected_even_with_resealed_counts(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            def remove(*args):
                report=fake_review(*args)
                report["checks"].pop(next(iter(report["checks"])))
                report["passed_checks"]=report["total_checks"]=len(report["checks"])
                return report
            with patch.object(recovery,"_invoke_review",side_effect=remove):
                result=recovery.run_sliced_artifact_recovery(configuration,"refused",source_id=source.name)
            self.assertEqual(result["status"],"failed")

    def test_final_deadline_failure_forbids_completion(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            def deadline(*args):
                events=Path(configuration["output_root"])/"expired"/recovery.FILES["events"]
                if events.exists() and any(row["stage"]=="source_final_content_scan" and row["status"]=="passed"
                                           for row in map(json.loads,events.read_text(encoding="utf-8").splitlines())):
                    raise TimeoutError("600-second budget expired after final scan")
                return 0.
            with patch.object(recovery,"_invoke_review",side_effect=fake_review),patch.object(recovery,"_deadline",side_effect=deadline):
                result=recovery.run_sliced_artifact_recovery(configuration,"expired",source_id=source.name)
            self.assertEqual(result["status"],"failed")
            self.assertFalse((Path(configuration["output_root"])/"expired"/"completion.json").exists())
            self.assertIn("after final scan",result["errors"][-1]["message"])

    def test_saved_reader_checks_hashes_without_rerunning_review(self):
        with temporary_workspace() as root:
            configuration,source,_,report=self.complete(root)
            directory=Path(configuration["output_root"])/report["task_id"]
            with patch.object(recovery,"_invoke_review",side_effect=AssertionError("No independent scorer may rerun on read")):
                self.assertTrue(recovery.verify_sliced_artifact_recovery(directory,report))
                (source/"checkpoints"/"fixture-0.json").write_bytes(b"changed")
                with self.assertRaisesRegex(ValueError,"Original failed-task files changed"):
                    recovery.verify_sliced_artifact_recovery(directory,report)

    def test_saved_summary_lie_is_rejected(self):
        with temporary_workspace() as root:
            configuration,_,_,report=self.complete(root)
            directory=Path(configuration["output_root"])/report["task_id"]
            lied=copy.deepcopy(report)
            lied["summary"]["baseline"]["tp"]=99
            with self.assertRaisesRegex(ValueError,"summary differs"):
                recovery.verify_sliced_artifact_recovery(directory,lied)

    def test_wrong_artifact_pointer_and_changed_review_configuration_are_refused(self):
        with temporary_workspace() as root:
            configuration,_,_,report=self.complete(root)
            directory=Path(configuration["output_root"])/report["task_id"]
            lied=copy.deepcopy(report)
            lied["artifacts"]["independent"]=str(root/"different-proof.json")
            with self.assertRaisesRegex(ValueError,"artifact pointers"):
                recovery.verify_sliced_artifact_recovery(directory,lied)
            saved=copy.deepcopy(report["configuration"])
            saved["weights_path"]=str(root/"other-weight.pt")
            recovery._write(directory/recovery.FILES["configuration"],saved)
            with self.assertRaisesRegex(ValueError,"saved review configuration"):
                recovery.verify_sliced_artifact_recovery(directory,report)

    def test_original_nms_false_and_incomplete_worker_are_refused(self):
        for changed in ("nms","incomplete"):
            with self.subTest(changed=changed),temporary_workspace() as root:
                configuration,source,_=fixture(root)
                if changed=="nms":
                    environment=recovery._read(source/"environment.json")
                    environment["actual_predictor_options"]["nms"]=False
                    recovery._write(source/"environment.json",environment)
                else:
                    recovery._write(source/"worker_receipt.json",{"status":"failed","observations":1})
                with patch.object(recovery,"_invoke_review") as independent:
                    result=recovery.run_sliced_artifact_recovery(configuration,"refused",source_id=source.name)
                    independent.assert_not_called()
                self.assertEqual(result["status"],"failed")

    def test_existing_recovery_and_unsafe_id_are_preserved(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            directory=Path(configuration["output_root"])/"existing"
            directory.mkdir()
            (directory/"completion.json").write_bytes(b"preserve")
            with patch.object(recovery,"_invoke_review") as independent:
                result=recovery.run_sliced_artifact_recovery(configuration,"existing",source_id=source.name)
                unsafe=recovery.run_sliced_artifact_recovery(configuration,"../unsafe",source_id=source.name)
                independent.assert_not_called()
            self.assertEqual(result["status"],"failed")
            self.assertEqual(unsafe["status"],"failed")
            self.assertEqual((directory/"completion.json").read_bytes(),b"preserve")

    def test_producer_two_boundary_scans_and_public_reader_always_scans_fresh(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            with patch.object(recovery,"_invoke_review",side_effect=fake_review), \
                    patch.object(recovery,"_source_manifest",wraps=recovery._source_manifest) as scans, \
                    patch.object(recovery,"verify_sliced_artifact_recovery",side_effect=AssertionError("Public reader is not a producer bypass flag")):
                report=recovery.run_sliced_artifact_recovery(configuration,"scan-budget",source_id=source.name)
            self.assertEqual(report["status"],"completed",report["errors"])
            self.assertEqual(scans.call_count,2)
            directory=Path(configuration["output_root"])/report["task_id"]
            protocol=recovery._read(directory/recovery.FILES["protocol"])
            self.assertIs(type(protocol["artifact_review_implementation_version"]),int)
            self.assertEqual(protocol["artifact_review_implementation_version"],3)
            events=list(map(json.loads,(directory/recovery.FILES["events"]).read_text(encoding="utf-8").splitlines()))
            boundaries=[row for row in events if row["stage"] in ("source_initial_content_scan","source_final_content_scan") and row["status"]=="passed"]
            self.assertEqual(len(boundaries),2)
            self.assertEqual({row["source_files_checked"] for row in boundaries},{8})
            self.assertEqual(len({row["source_bytes_checked"] for row in boundaries}),1)
            self.assertTrue(all(row["elapsed_seconds"]>=0 and row["fresh_content_sha256"] is True for row in boundaries))
            with patch.object(recovery,"_source_manifest",wraps=recovery._source_manifest) as reader_scan:
                self.assertTrue(recovery.verify_sliced_artifact_recovery(directory,report))
                self.assertEqual(reader_scan.call_count,1)
            report.update(skip_source_validation=True,source_scan_verified=True,internal_publication=True)
            (source/"checkpoints"/"fixture-0.json").write_bytes(b"changed")
            with self.assertRaisesRegex(ValueError,"Original failed-task files changed"):
                recovery.verify_sliced_artifact_recovery(directory,report)

    def test_final_fresh_scan_rejects_added_removed_or_changed_source_after_review(self):
        for change in ("added","removed","changed"):
            with self.subTest(change=change),temporary_workspace() as root:
                configuration,source,_=fixture(root)
                def mutate(*args):
                    review=fake_review(*args)
                    checkpoint=source/"checkpoints"/"fixture-0.json"
                    if change=="added": (source/"checkpoints"/"extra.json").write_bytes(b"new")
                    elif change=="removed": checkpoint.unlink()
                    else: checkpoint.write_bytes(b"different")
                    return review
                with patch.object(recovery,"_invoke_review",side_effect=mutate):
                    report=recovery.run_sliced_artifact_recovery(configuration,"changed-source",source_id=source.name)
                self.assertEqual(report["status"],"failed")
                self.assertIn("Original failed-task files changed",report["errors"][-1]["message"])
                directory=Path(configuration["output_root"])/report["task_id"]
                self.assertFalse((directory/"completion.json").exists())
                self.assertTrue((directory/"failure.json").exists())

    def test_source_manifest_linear_resolution_hashing_and_deterministic_membership(self):
        with temporary_workspace() as root:
            source=root/"many-small-files"
            (source/"nested").mkdir(parents=True)
            for number in range(256):
                (source/"nested"/f"{number:04d}.json").write_bytes(f"fixture-{number}".encode())
            calls=[]
            original=Path.resolve
            def resolving(path,*args,**kwargs):
                calls.append(path)
                return original(path,*args,**kwargs)
            with patch.object(Path,"resolve",new=resolving), \
                    patch.object(recovery,"_source_file_digest",wraps=recovery._source_file_digest) as hashing:
                manifest=recovery._source_manifest(source)
            self.assertEqual(calls,[source])
            self.assertEqual(hashing.call_count,256)
            self.assertEqual(manifest["file_count"],256)
            self.assertEqual([row["relative_path"] for row in manifest["files"]],sorted(row["relative_path"] for row in manifest["files"]))
            self.assertEqual(manifest,recovery._source_manifest(source))

    def test_same_size_same_mtime_mutation_and_unsafe_manifest_cannot_hide_content_changes(self):
        with temporary_workspace() as root:
            source=root/"plain";source.mkdir()
            path=source/"a.json";path.write_bytes(b"aaaa")
            manifest=recovery._source_manifest(source)
            before=path.stat()
            path.write_bytes(b"bbbb")
            os.utime(path,ns=(before.st_atime_ns,before.st_mtime_ns))
            with self.assertRaisesRegex(ValueError,"Original failed-task files changed"):
                recovery._check_source_manifest(source,manifest)
            manifest=recovery._source_manifest(source)
            unsafe=copy.deepcopy(manifest);unsafe["files"][0]["relative_path"]="../outside.json"
            with self.assertRaises(ValueError): recovery._check_source_manifest(source,unsafe)
            duplicate=copy.deepcopy(manifest);duplicate["files"].append(copy.deepcopy(duplicate["files"][0]));duplicate["file_count"]+=1
            with self.assertRaises(ValueError): recovery._check_source_manifest(source,duplicate)

    def test_symlink_junction_and_nonregular_metadata_are_rejected(self):
        for mode,attributes in ((stat.S_IFLNK|0o777,0),(stat.S_IFDIR|0o777,0x400),(stat.S_IFREG|0o666,0x400),(stat.S_IFIFO|0o666,0)):
            with self.subTest(mode=mode,attributes=attributes),self.assertRaises(ValueError):
                recovery._require_plain_source_entry(SimpleNamespace(st_mode=mode,st_file_attributes=attributes))

    def test_source_link_is_refused_before_hashing_target(self):
        with temporary_workspace() as root:
            source=root/"source";source.mkdir()
            outside=root/"outside.json";outside.write_bytes(b"outside")
            try:
                (source/"link.json").symlink_to(outside)
            except (OSError,NotImplementedError):
                # Exercise the exact enumerator path when Windows disallows
                # symlink creation for this account; do not skip the guard.
                entry=SimpleNamespace(name="link.json",stat=lambda **kwargs:SimpleNamespace(st_mode=stat.S_IFLNK|0o777,st_file_attributes=0))
                listing=MagicMock();listing.__enter__.return_value=[entry]
                with patch.object(os,"scandir",return_value=listing), \
                        patch.object(recovery,"_source_file_digest",side_effect=AssertionError("Linked bytes cannot be read")), \
                        self.assertRaisesRegex(ValueError,"Linked"):
                    recovery._source_manifest(source)
            else:
                with patch.object(recovery,"_source_file_digest",side_effect=AssertionError("Linked bytes cannot be read")),self.assertRaisesRegex(ValueError,"Linked"):
                    recovery._source_manifest(source)

    def test_open_handle_file_mutation_is_rejected(self):
        with temporary_workspace() as root:
            path=root/"a.json";path.write_bytes(b"fixture")
            expected=path.lstat();real_fstat=os.fstat;count=0
            def changed_stat(fd):
                nonlocal count
                count+=1
                info=real_fstat(fd)
                if count==1:return info
                fields={key:getattr(info,key) for key in ("st_dev","st_ino","st_mode","st_size","st_mtime_ns","st_ctime_ns")}
                fields["st_size"]+=1
                return SimpleNamespace(**fields)
            with patch.object(os,"fstat",side_effect=changed_stat),self.assertRaisesRegex(ValueError,"changed while hashing"):
                recovery._source_file_digest(path,expected)

    def test_reparse_source_root_is_rejected_before_source_state_reads(self):
        with temporary_workspace() as root:
            configuration,source,_=fixture(root)
            actual_lstat=Path.lstat
            def root_link(path,*args,**kwargs):
                if path==source:return SimpleNamespace(st_mode=stat.S_IFDIR|0o777,st_file_attributes=0x400)
                return actual_lstat(path,*args,**kwargs)
            with patch.object(Path,"lstat",new=root_link), \
                    patch.object(recovery,"_source_state",side_effect=AssertionError("Source links cannot be read")) as reading:
                result=recovery.run_sliced_artifact_recovery(configuration,"linked-root",source_id=source.name)
                reading.assert_not_called()
            self.assertEqual(result["status"],"failed")
            self.assertIn("Linked",result["errors"][-1]["message"])

    def test_protocol_version_must_be_exact_int_three(self):
        for version in (None,1,2,True,"3",3.0):
            with self.subTest(version=version),temporary_workspace() as root:
                configuration,_,_,report=self.complete(root)
                directory=Path(configuration["output_root"])/report["task_id"]
                protocol=recovery._read(directory/recovery.FILES["protocol"])
                if version is None:protocol.pop("artifact_review_implementation_version")
                else:protocol["artifact_review_implementation_version"]=version
                recovery._write(directory/recovery.FILES["protocol"],protocol)
                with self.assertRaisesRegex(ValueError,"contract differs"):
                    recovery.verify_sliced_artifact_recovery(directory,report)


if __name__=="__main__":
    unittest.main()
