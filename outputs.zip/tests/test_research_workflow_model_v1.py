"""Official-origin, fresh-execution and exact-claim negatives for Agnes V1."""
import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import unittest

from tools.verify_research_workflow_model_v1 import (PATH, SCOPE_SENTENCE, UNKNOWN, check_ledger,
    _official_projection, _official_workspace_path, final_value, official_payload, scope_policy,
    terminal_compact, validate_final, validate_protocol, verify_local_binding)


def fixture(*, read_approval=True):
    identity = "research-workflow-v1-agnesv1-20261012-01"
    workspace = str(Path(__file__).resolve().parents[1] / ".runtime/model-fixture")
    protocol = {"schema_version": 1, "workspace_root": workspace, "server_id": "dr-workflow-v1",
                "request_id": "agnesv1-20261012-01", "workflow_id": identity, "case_id": "repair_coordinates",
                "budget": {"domain_invocations": 6, "wall_seconds": 120, "gpu_seconds": 0, "model_requests": 0},
                "qualified_start_tool": "mcp_dr_workflow_v1_a78bff84_run_bounded_research_workflow_v1",
                "qualified_status_tool": "mcp_dr_workflow_v1_a78bff84_get_research_workflow_status_v1",
                "max_start_calls": 1, "max_status_calls": 6, "max_model_requests": 8, "max_wall_seconds": 120,
                "new_inference_allowed": False}
    target = {"status": "completed", "workflow_id": identity, "research_status": "stopped", "case_id": "repair_coordinates",
              "actual_tool_path": PATH[:], "domain_invocations": 6, "next_action": "stop_no_registered_candidate",
              "synthetic_only": True, "new_inference_calls": 0, "new_model_requests": 0,
              "relative_small": {"definition_id": "area_ratio_lt_0_005", "gt": 94, "tp_640": 5, "tp_960": 13},
              "tiny_small": {"definition_id": "area_lt_1024_px2", "gt": 4, "tp_640": 0, "tp_960": 0},
              "resolution": {"fp_640": 149, "fp_960": 252},
              "slicing": {"candidate_status": "stop", "failed_gate_count": 5},
              "evidence_ids": [identity + ":" + kind + ":" + str(index) for index, kind in enumerate(("geometry", "repair", "copy_geometry", "science"), 1)]}
    terminal = {key: copy.deepcopy(value) for key, value in target.items() if key not in ("relative_small", "tiny_small", "resolution", "slicing")}
    terminal["scientific_summary"] = {key: copy.deepcopy(target[key]) for key in ("relative_small", "tiny_small", "resolution")}
    terminal["scientific_summary"]["slicing"] = {"candidate_status": "stop", "failed_gates": list("abcde")}
    terminal["report_path"] = str(Path(workspace) / "outputs" / identity / "report.md")
    terminal["evidence"] = {"directory": str(Path(workspace) / "outputs" / identity), "completion_sha256": "a" * 64}
    # Official export.cwd redacts literal workspace prefixes inside JSON tool
    # result text. Public SDK payload remains the original absolute observation.
    official_terminal = copy.deepcopy(terminal)
    official_terminal["report_path"] = "<workspace>" + terminal["report_path"][len(workspace):]
    official_terminal["evidence"]["directory"] = "<workspace>" + terminal["evidence"]["directory"][len(workspace):]
    final = SCOPE_SENTENCE + "\n```json\n" + json.dumps(target, ensure_ascii=False) + "\n```"
    origin, prefix = "ext:plugin/@defect-researcher/research-scope-v1", "plugin/research-scope-v1"
    public_policy = copy.deepcopy(scope_policy(protocol)); public_policy["workspace_root"] = "<workspace>"
    start_args = {key: copy.deepcopy(protocol[key]) for key in ("request_id", "case_id", "budget")}
    rows = [
        {"type": "session/start", "data": {"key": "new-session"}},
        {"type": prefix + "/scope-ready", "origin": origin, "data": {"session_key": "new-session", "workspace_root": "<workspace>", "mode": "bounded-research-workflow-v1", "policy": public_policy}},
        {"type": "request/sent", "data": {"model": {"id": "agnes-3.0-flash", "route": "account-defect-researcher"}}},
        {"type": "cost/ledger", "data": {"purpose": "inference", "model": "agnes-3.0-flash", "response": {"status": 200}}},
        {"type": "tool/call", "origin": "model", "data": {"toolUseId": "call-start", "name": protocol["qualified_start_tool"], "args": start_args}},
        {"type": prefix + "/scope-decision", "origin": origin, "data": {"session_key": "new-session", "name": protocol["qualified_start_tool"], "tool_use_id": "call-start", "allow": True, "reason": None}},
        {"type": "approval/decided", "data": {"verdict": "allowed-once", "scope": "tool:" + protocol["qualified_start_tool"] + ":execute"}},
        {"type": "tool/result", "sourceEventSeqs": [5], "data": {"toolUseId": "call-start", "isError": False, "code": "OK", "content": [{"type": "text", "text": json.dumps({"workflow_id": identity, "status": "running"})}]}},
        {"type": "request/sent", "data": {"model": {"id": "agnes-3.0-flash", "route": "account-defect-researcher"}}},
        {"type": "cost/ledger", "data": {"purpose": "inference", "model": "agnes-3.0-flash", "response": {"status": 200}}},
        {"type": "tool/call", "origin": "model", "data": {"toolUseId": "call-status", "name": protocol["qualified_status_tool"], "args": {"workflow_id": identity}}},
        {"type": prefix + "/scope-decision", "origin": origin, "data": {"session_key": "new-session", "name": protocol["qualified_status_tool"], "tool_use_id": "call-status", "allow": True, "reason": None}},
        {"type": "approval/decided", "data": {"verdict": "allowed-once", "scope": "tool:" + protocol["qualified_status_tool"] + ":execute"}},
        {"type": "tool/result", "sourceEventSeqs": [11], "data": {"toolUseId": "call-status", "isError": False, "code": "OK", "content": [{"type": "text", "text": json.dumps(official_terminal)}]}},
        {"type": "assistant/message", "data": {"content": [{"type": "text", "text": final}]}},
        {"type": "turn/end", "data": {"reason": "completed", "lastAssistantSeq": 15}},
    ]
    if not read_approval:
        rows.pop(12)
        rows[-1]["data"]["lastAssistantSeq"] = 14
    begin = datetime(2026, 10, 12, tzinfo=timezone.utc).timestamp() * 1000
    for index, row in enumerate(rows, 1):
        row.update(seq=index, ts=datetime.fromtimestamp((begin + index * 1000) / 1000, timezone.utc).isoformat().replace("+00:00", "Z"), trust="trusted")
        row.setdefault("origin", "system")
        if row["type"] == "tool/result":
            name = next(call["data"]["name"] for call in rows if call["type"] == "tool/call" and call["data"]["toolUseId"] == row["data"]["toolUseId"])
            row.update(origin="tool:" + name, trust="untrusted")
        elif row["type"].endswith(("/scope-ready", "/scope-decision")):
            row["trust"] = "untrusted"
        elif row["type"] == "assistant/message":
            row["origin"] = "model"
    sdk_ready = copy.deepcopy(rows[1]); sdk_ready["data"]["workspace_root"] = workspace; sdk_ready["data"]["policy"]["workspace_root"] = workspace
    calls = [row for row in rows if row["type"] == "tool/call"]
    results = [row for row in rows if row["type"] == "tool/result"]
    run = {"session_id": "new-session", "status": "completed", "scope_ready": sdk_ready, "cwd": workspace, "policy": copy.deepcopy(scope_policy(protocol)),
           "model_started_epoch_ms": begin, "deadline_epoch_ms": begin + 120000, "finished_epoch_ms": begin + 17000,
           "calls": [{"seq": row["seq"], "origin": row["origin"], "name": row["data"]["name"], "args": copy.deepcopy(row["data"]["args"])} for row in calls],
           "results": [{"seq": row["seq"], "tool_use_id": row["data"]["toolUseId"], "is_error": False, "payload": json.loads(row["data"]["content"][0]["text"])} for row in results],
           "hook_events": [copy.deepcopy(row) for row in rows if row["type"].endswith("/scope-decision")],
           "permissions": [{"tool": row["data"]["name"], "input": copy.deepcopy(row["data"]["args"]), "tool_call_id": row["data"]["toolUseId"], "decision": "allowed-once"} for row in calls if read_approval or row["data"]["name"] == protocol["qualified_start_tool"]],
           "final_texts": [copy.deepcopy(next(row for row in rows if row["type"] == "assistant/message"))], "final_json": copy.deepcopy(target), "model_request_count": 2,
           "new_model_inference_performed": True, "new_detection_inference_performed": False, "tool_catalog_narrowed": False}
    run["results"][-1]["payload"] = copy.deepcopy(terminal)
    return rows, run, protocol, target


class ResearchModelLedgerTests(unittest.TestCase):
    def reject(self, mutation, check=None):
        data = fixture(); mutation(*data); report = check_ledger(*data)
        self.assertTrue(report["errors"], report)
        if check:
            self.assertIs(report["checks"][check], False, report)

    def test_valid_start_and_read(self):
        report = check_ledger(*fixture())
        self.assertFalse(report["errors"], report)
        self.assertEqual(report["model_request_count"], 2)
        self.assertEqual(report["approval_count"], 2)

    def test_native_read_without_approval_is_honest(self):
        report = check_ledger(*fixture(read_approval=False))
        self.assertFalse(report["errors"], report)
        self.assertEqual(report["approval_count"], 1)

    def test_start_approval_cannot_be_omitted(self):
        self.reject(lambda r,s,p,t: s["permissions"].pop(0))

    def test_read_approval_cannot_be_fabricated(self):
        rows, run, protocol, target = fixture(read_approval=False)
        run["permissions"].append({"tool": protocol["qualified_status_tool"], "tool_call_id": "call-status", "input": {"workflow_id": protocol["workflow_id"]}, "decision": "allowed-once"})
        self.assertTrue(check_ledger(rows, run, protocol, target)["errors"])

    def test_gap(self): self.reject(lambda r,s,p,t: r[2].update(seq=40))
    def test_bool_sequence(self): self.reject(lambda r,s,p,t: r[0].update(seq=True))
    def test_time_backwards(self): self.reject(lambda r,s,p,t: r[5].update(ts=r[0]["ts"]))
    def test_wrong_session(self): self.reject(lambda r,s,p,t: r[0]["data"].update(key="old-session"))
    def test_untrusted_start(self): self.reject(lambda r,s,p,t: r[0].update(trust="untrusted"))
    def test_reset_deadline(self): self.reject(lambda r,s,p,t: s.update(deadline_epoch_ms=s["deadline_epoch_ms"] + 120000))
    def test_wrong_workspace(self): self.reject(lambda r,s,p,t: s.update(cwd="E:/wrong"))
    def test_non_model_origin(self): self.reject(lambda r,s,p,t: r[4].update(origin="system"))
    def test_untrusted_model_call(self): self.reject(lambda r,s,p,t: r[4].update(trust="untrusted"))
    def test_extra_tool(self): self.reject(lambda r,s,p,t: r[10]["data"].update(name="shell"))
    def test_duplicate_start(self): self.reject(lambda r,s,p,t: r[10]["data"].update(name=p["qualified_start_tool"]))
    def test_start_extra_path(self): self.reject(lambda r,s,p,t: r[4]["data"]["args"].update(path="E:/dataset"))
    def test_start_other_case(self): self.reject(lambda r,s,p,t: r[4]["data"]["args"].update(case_id="normal_clipped"))
    def test_start_over_budget(self): self.reject(lambda r,s,p,t: r[4]["data"]["args"]["budget"].update(domain_invocations=7))
    def test_read_other_id(self): self.reject(lambda r,s,p,t: r[10]["data"]["args"].update(workflow_id="research-workflow-v1-old"))
    def test_read_resume(self): self.reject(lambda r,s,p,t: r[10]["data"]["args"].update(resume=True))
    def test_duplicate_tool_id(self): self.reject(lambda r,s,p,t: r[10]["data"].update(toolUseId="call-start"))
    def test_wrong_ready_policy(self): self.reject(lambda r,s,p,t: r[1]["data"]["policy"].update(max_start_calls=2))
    def test_wrong_sdk_ready(self): self.reject(lambda r,s,p,t: s["scope_ready"]["data"].update(workspace_root="E:/wrong"))
    def test_result_pair(self): self.reject(lambda r,s,p,t: r[7].update(sourceEventSeqs=[3]))
    def test_hook_denied(self): self.reject(lambda r,s,p,t: r[5]["data"].update(allow=False))
    def test_hook_wrong_extension(self): self.reject(lambda r,s,p,t: r[5].update(origin="ext:plugin/other"))
    def test_result_error(self): self.reject(lambda r,s,p,t: r[7]["data"].update(isError=True))
    def test_result_model_origin_is_not_tool_evidence(self): self.reject(lambda r,s,p,t: r[7].update(origin="model", trust="trusted"))
    def test_sdk_result_wrong_count(self): self.reject(lambda r,s,p,t: s["results"][1]["payload"]["scientific_summary"]["resolution"].update(fp_960=149))
    def test_sdk_call_wrong_args(self): self.reject(lambda r,s,p,t: s["calls"][0]["args"].update(case_id="normal_clipped"))
    def test_sdk_gate_wrong(self): self.reject(lambda r,s,p,t: s["hook_events"][0]["data"].update(reason="rejected"))
    def test_persistent_approval(self): self.reject(lambda r,s,p,t: r[6]["data"].update(verdict="allowed-always"))
    def test_sdk_persistent_approval(self): self.reject(lambda r,s,p,t: s["permissions"][0].update(decision="allowed-always"))
    def test_approval_different_input(self): self.reject(lambda r,s,p,t: s["permissions"][0]["input"].update(case_id="normal_clipped"))
    def test_wrong_model(self): self.reject(lambda r,s,p,t: r[2]["data"]["model"].update(id="other"))
    def test_cost_failed(self): self.reject(lambda r,s,p,t: r[3]["data"]["response"].update(status=500))
    def test_no_real_model_flag(self): self.reject(lambda r,s,p,t: s.update(new_model_inference_performed=False))
    def test_deadline_escaped(self): self.reject(lambda r,s,p,t: s.update(model_started_epoch_ms=s["model_started_epoch_ms"]-120000, deadline_epoch_ms=s["deadline_epoch_ms"]-120000))
    def test_turn_stopped(self): self.reject(lambda r,s,p,t: r[15]["data"].update(reason="aborted"))
    def test_final_system_origin_is_not_model_claim(self): self.reject(lambda r,s,p,t: r[14].update(origin="system"))
    def test_false_final_json(self): self.reject(lambda r,s,p,t: s["final_json"]["relative_small"].update(gt=4))
    def test_export_failed(self): self.reject(lambda r,s,p,t: s.update(export_failure={"type": "TimeoutError"}))
    def test_false_detector_boundary(self): self.reject(lambda r,s,p,t: s.update(new_detection_inference_performed=True))
    def test_false_catalog_claim(self): self.reject(lambda r,s,p,t: s.update(tool_catalog_narrowed=True))


class ResearchModelFinalTests(unittest.TestCase):
    def test_valid_integer_compact(self): self.assertEqual(validate_final(fixture()[3]), fixture()[3])
    def test_bool_count_rejected(self):
        value = fixture()[3]; value["new_model_requests"] = False
        with self.assertRaises(ValueError): validate_final(value)
    def test_float_count_rejected(self):
        value = fixture()[3]; value["relative_small"]["gt"] = 94.0
        with self.assertRaises(ValueError): validate_final(value)
    def test_missing_source_id_rejected(self):
        value = fixture()[3]; value["evidence_ids"].pop()
        with self.assertRaises(ValueError): validate_final(value)
    def test_swapped_definition_rejected(self):
        value = fixture()[3]; value["tiny_small"]["definition_id"] = "area_ratio_lt_0_005"
        with self.assertRaises(ValueError): validate_final(value)
    def test_extra_key_rejected(self):
        value = fixture()[3]; value["autonomous"] = True
        with self.assertRaises(ValueError): validate_final(value)
    def test_literal_mask_unknown(self):
        value, masks = official_payload('{"elapsed_seconds": 0.[REDACTED:id], "status":"running"}')
        self.assertEqual(value["elapsed_seconds"], UNKNOWN); self.assertEqual(masks, [["elapsed_seconds"]])
    def test_duplicate_json_rejected(self):
        with self.assertRaises(ValueError): official_payload('{"status":"a","status":"b"}')
    def test_final_requires_scope(self):
        with self.assertRaises(ValueError): final_value("```json\n" + json.dumps(fixture()[3]) + "\n```")
    def test_final_rejects_unbound_prose(self):
        with self.assertRaises(ValueError): final_value(SCOPE_SENTENCE + " 此方案保证提高检测性能。\n```json\n" + json.dumps(fixture()[3]) + "\n```")
    def test_final_rejects_second_block(self):
        text = SCOPE_SENTENCE + "\n```json\n" + json.dumps(fixture()[3]) + "\n```"
        with self.assertRaises(ValueError): final_value(text + "\n" + text)
    def test_real_terminal_projection(self): self.assertEqual(terminal_compact(fixture()[1]["results"][1]["payload"]), fixture()[3])
    def test_protocol_exact_case(self):
        value = fixture()[2]; value["case_id"] = "normal_clipped"
        with self.assertRaises(ValueError): validate_protocol(value)
    def test_protocol_failed_long_sid_rejected(self):
        value = fixture()[2]; value["server_id"] = "defect-researcher-workflow-v1"
        with self.assertRaises(ValueError): validate_protocol(value)
    def test_protocol_float_budget_rejected(self):
        value = fixture()[2]; value["budget"]["domain_invocations"] = 6.0
        with self.assertRaises(ValueError): validate_protocol(value)
    def test_protocol_budget_bool_rejected(self):
        value = fixture()[2]; value["budget"]["gpu_seconds"] = False
        with self.assertRaises(ValueError): validate_protocol(value)
    def test_protocol_valid(self): self.assertEqual(validate_protocol(fixture()[2]), fixture()[2])
    def test_old_workflow_cannot_be_reused_as_new(self):
        rows, run, protocol, target = fixture()
        run.update(workflow_directory=str(Path(__file__).resolve().parents[1] / "outputs/research-workflow-local-acceptance-v1"), registry_directory=protocol["workspace_root"])
        report = verify_local_binding(protocol, run, check_ledger(rows, run, protocol, target))
        self.assertIs(report["checks"]["owned_new_workflow_and_registry_paths"], False)


class ResearchModelOfficialPrivacyTests(unittest.TestCase):
    def test_real_cwd_projection_and_sdk_metadata_normalized_before_review(self):
        rows, run, protocol, target = fixture(read_approval=False)
        # The SDK wrapper has transport _meta; root's recorded payload removes
        # it. The verifier consumes that exact normalized public observation.
        sdk_response = {**copy.deepcopy(run["results"][-1]["payload"]), "_meta": {"progressToken": "fixture-progress"}}
        run["results"][-1]["payload"] = {key: value for key, value in sdk_response.items() if key != "_meta"}
        before = copy.deepcopy(run["results"][-1]["payload"])
        report = check_ledger(rows, run, protocol, target)
        self.assertFalse(report["errors"], report)
        self.assertEqual(run["results"][-1]["payload"], before)
        self.assertTrue(before["report_path"].startswith(protocol["workspace_root"]))
        self.assertIn("<workspace>", rows[13 - 1]["data"]["content"][0]["text"])

    def test_sdk_payload_metadata_not_ignored_by_verifier(self):
        rows, run, protocol, target = fixture()
        run["results"][-1]["payload"]["_meta"] = {"progressToken": "unexpected"}
        self.assertTrue(check_ledger(rows, run, protocol, target)["errors"])

    def test_wrong_redacted_suffix_rejected(self):
        rows, run, protocol, target = fixture()
        value = json.loads(rows[13]["data"]["content"][0]["text"])
        value["report_path"] = "<workspace>/outputs/wrong/report.md"
        rows[13]["data"]["content"][0]["text"] = json.dumps(value)
        self.assertTrue(check_ledger(rows, run, protocol, target)["errors"])

    def test_wrong_sdk_absolute_path_rejected(self):
        rows, run, protocol, target = fixture()
        run["results"][-1]["payload"]["evidence"]["directory"] += "-lookalike"
        self.assertTrue(check_ledger(rows, run, protocol, target)["errors"])

    def test_only_two_declared_fields_projected(self):
        workspace = "E:/Project/workspace"
        target = {"other_path": workspace + "/unregistered", "report_path": workspace + "/outputs/report.md"}
        observed = {"other_path": "<workspace>/unregistered", "report_path": "<workspace>/outputs/report.md"}
        self.assertFalse(_official_projection(observed, target, [], workspace))

    def test_windows_case_and_separator_spellings_follow_official_rule(self):
        workspace = "E:\\Project\\workspace\\"
        for spelling in ("e:/PROJECT/workspace", "e:\\project\\WORKSPACE", "E:\\\\Project\\\\workspace"):
            self.assertEqual(_official_workspace_path(spelling + "\\outputs\\report.md", workspace), "<workspace>\\outputs\\report.md")

    def test_workspace_lookalike_prefix_is_not_projected(self):
        workspace = "E:/Project/workspace"
        sibling = workspace + "-other/outputs/report.md"
        self.assertEqual(_official_workspace_path(sibling, workspace), sibling)
        self.assertFalse(_official_projection({"report_path": "<workspace>-other/outputs/report.md"}, {"report_path": sibling}, [], workspace))

    def test_mid_string_literal_is_not_a_typed_path(self):
        workspace = "E:/Project/workspace"
        value = "See " + workspace + "/outputs/report.md"
        self.assertEqual(_official_workspace_path(value, workspace), value)

    def test_posix_case_sensitivity_preserved(self):
        workspace = "/work/Project"
        self.assertEqual(_official_workspace_path(workspace + "/outputs", workspace), "<workspace>/outputs")
        self.assertEqual(_official_workspace_path("/work/project/outputs", workspace), "/work/project/outputs")

    def test_combined_numeric_mask_stays_unknown_and_sdk_unmodified(self):
        workspace = "E:/Project/workspace"
        target = {"report_path": workspace + "/outputs/report.md", "elapsed_seconds": .12345678901234567}
        observed = {"report_path": "<workspace>/outputs/report.md", "elapsed_seconds": UNKNOWN}
        before = copy.deepcopy(target)
        self.assertTrue(_official_projection(observed, target, [["elapsed_seconds"]], workspace))
        self.assertEqual(target, before)
        self.assertEqual(observed["elapsed_seconds"], UNKNOWN)

    def test_scientific_integer_mask_cannot_be_restored_through_path_projection(self):
        workspace = "E:/Project/workspace"
        target = {"report_path": workspace + "/outputs/report.md", "domain_invocations": 6}
        observed = {"report_path": "<workspace>/outputs/report.md", "domain_invocations": UNKNOWN}
        with self.assertRaises(ValueError): _official_projection(observed, target, [["domain_invocations"]], workspace)


if __name__ == "__main__":
    unittest.main()
