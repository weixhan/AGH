"""Hand-computed scale boundaries and adverse sealed-evidence cases."""
import copy
import json
import math
from pathlib import Path
import unittest

from test_config import temporary_workspace
from tools import review_plan_scale_alignment as review


def box(xyxy=(0, 0, 10, 10), class_id=0, confidence=None):
    value = {"class_id": class_id, "xyxy": list(xyxy)}
    if confidence is not None:
        value["confidence"] = confidence
    return value


def record(size=640, truth=None, predictions=None, identifier="a", width=1000, height=1000):
    return {"image_id": identifier, "width": width, "height": height,
            "ground_truth": [] if truth is None else truth,
            "predictions": [] if predictions is None else predictions,
            "split": "val", "eval_imgsz": size, "precision": "FP32", "device": "0"}


def paired(truth, predictions):
    return {size: [record(size, copy.deepcopy(truth), copy.deepcopy(predictions))]
            for size in (640, 960)}


def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def sealed_fixture(root):
    """A tiny synthetic chain tests the checker without touching real evidence."""
    task = root / "task"
    task.mkdir()
    bound_files, input_evidence = [], {}
    sources = root / "sources"
    sources.mkdir()
    for index, role in enumerate(sorted(review.SOURCE_ROLES)):
        path = sources / f"source-{index}.txt"
        path.write_text(role, encoding="utf-8")
        digest = review.sha(path)
        input_evidence[role] = {"path": str(path), "sha256": digest}
        bound_files.append({"role": role, "path": str(path), "size_bytes": path.stat().st_size,
                            "sha256_before": digest, "sha256_after": digest, "unchanged": True})
    for name in review.ARTIFACT_NAMES:
        (task / name).write_text("{}", encoding="utf-8")
    dump(task / "inputs.json", {"task_id": review.TASK_ID, "all_unchanged": True, "files": bound_files})
    reseal(task, input_evidence)
    return task


def reseal(task, input_evidence=None):
    old = task / "artifact_manifest.json"
    if input_evidence is None:
        input_evidence = json.loads(old.read_text(encoding="utf-8"))["input_evidence"]
    manifest = {"task_id": review.TASK_ID, "tool": review.TOOL, "status": "completed",
                "files": [{"name": name, "path": str(task / name),
                           "size_bytes": (task / name).stat().st_size, "sha256": review.sha(task / name)}
                          for name in sorted(review.ARTIFACT_NAMES)], "input_evidence": input_evidence}
    dump(old, manifest)
    completion = {"task_id": review.TASK_ID, "tool": review.TOOL, "status": "completed",
                  "artifact_manifest": str(old), "artifact_manifest_sha256": review.sha(old),
                  "artifacts_sha256": {entry["name"]: entry["sha256"] for entry in manifest["files"]}}
    dump(task / "completion.json", completion)


def fixture_check(task, **overrides):
    return review.verify_artifact_chain(task, completion_sha=overrides.get("completion_sha", review.sha(task / "completion.json")),
                                        manifest_sha=overrides.get("manifest_sha", review.sha(task / "artifact_manifest.json")))


class PlanScaleMatchingTests(unittest.TestCase):
    def test_both_strict_boundaries_and_different_denominators(self):
        # Original image area=1,000,000. Ratio threshold=5000, absolute=1024.
        truth = [box((0, 0, 32, 32)), box((50, 0, 90, 25)),
                 box((100, 0, 200, 50)), box((300, 0, 400, 49.9))]
        result = review.analyse_records(paired(truth, [box((0, 0, 32, 32), confidence=.9)]), ["a"])
        subsets = result["results"]["640"]["scale_definitions"]
        self.assertEqual(subsets["plan_area_ratio_lt_0_005"], {"gt": 3, "tp": 1, "fn": 2, "recall": 1 / 3})
        self.assertEqual(subsets["implemented_area_lt_1024_px2"], {"gt": 1, "tp": 0, "fn": 1, "recall": 0})

    def test_same_class_one_to_one_and_wrong_class(self):
        truth = [box(), box((40, 0, 50, 10), class_id=1)]
        predictions = [box(confidence=.9), box(confidence=.8), box((40, 0, 50, 10), class_id=0, confidence=.95)]
        self.assertEqual(review.match_image(record(truth=truth, predictions=predictions)), ({0}, 2))

    def test_confidence_greedy_and_exact_gt_tie_break(self):
        truth = [box(), box((5, 0, 15, 10))]
        predictions = [box(confidence=.8), box((0, 0, 15, 10), confidence=.9)]
        # Highest confidence first; broad box ties at 2/3 and consumes GT 0.
        self.assertEqual(review.match_image(record(truth=truth, predictions=predictions)), ({0}, 1))

    def test_prediction_confidence_ties_preserve_saved_order(self):
        truth = [box(), box((5, 0, 15, 10))]
        broad, exact = box((0, 0, 15, 10), confidence=.9), box(confidence=.9)
        self.assertEqual(review.match_image(record(truth=truth, predictions=[broad, exact])), ({0}, 1))
        self.assertEqual(review.match_image(record(truth=truth, predictions=[exact, broad])), ({0, 1}, 0))

    def test_iou_and_confidence_inclusive_operating_boundaries(self):
        truth = [box((0, 0, 20, 10)), box((40, 0, 60, 10)), box((80, 0, 100, 10))]
        predictions = [box((0, 0, 10, 10), confidence=.25),
                       box((40, 0, 40 + math.nextafter(10, 0), 10), confidence=.9),
                       box((80, 0, 100, 10), confidence=math.nextafter(.25, 0))]
        # A nextafter offset at 40 may round back; use 9.999999 for strict below.
        predictions[1]["xyxy"][2] = 49.999999
        self.assertEqual(review.match_image(record(truth=truth, predictions=predictions)), ({0}, 1))

    def test_all_gt_match_before_scale_subset_is_counted(self):
        # Broader non-small GT has greater IoU and must consume the prediction.
        truth = [box((0, 0, 100, 100)), box((0, 0, 10, 10))]
        result = review.analyse_records(paired(truth, [box((0, 0, 100, 100), confidence=.9)]), ["a"])
        self.assertEqual(result["results"]["640"]["scale_definitions"]["plan_area_ratio_lt_0_005"]["tp"], 0)

    def test_empty_scale_denominator_is_none(self):
        result = review.analyse_records(paired([], []), ["a"])
        self.assertIsNone(result["results"]["640"]["scale_definitions"]["plan_area_ratio_lt_0_005"]["recall"])

    def test_incomplete_duplicate_or_wrong_members_are_rejected(self):
        for groups, expected in (({640: [], 960: []}, ["a"]),
                                 ({640: [record(), record()], 960: [record(960), record(960)]}, ["a", "b"]),
                                 (paired([], []), ["b"])):
            with self.subTest(expected=expected), self.assertRaises(review.ScaleReviewError):
                review.analyse_records(groups, expected)

    def test_changed_ground_truth_or_paired_dimensions_rejected(self):
        groups = paired([box()], [])
        groups[960][0]["ground_truth"][0]["xyxy"][2] = 11
        with self.assertRaisesRegex(review.ScaleReviewError, "identity mismatch"):
            review.analyse_records(groups, ["a"])
        groups = paired([box()], [])
        groups[960][0]["width"] = 1001
        with self.assertRaisesRegex(review.ScaleReviewError, "identity mismatch"):
            review.analyse_records(groups, ["a"])

    def test_bad_dimensions_nonfinite_coordinates_controls_and_confidence_rejected(self):
        for key, value in (("width", 0), ("width", True), ("height", 1000.0),
                           ("eval_imgsz", 960), ("split", "test"), ("device", "cpu")):
            groups = paired([box()], [])
            groups[640][0][key] = value
            with self.subTest(key=key, value=value), self.assertRaises(review.ScaleReviewError):
                review.analyse_records(groups, ["a"])
        for bad in (box((0, 0, float("nan"), 10)), box((0, 0, 1001, 10)), box(class_id=True)):
            with self.assertRaises(review.ScaleReviewError):
                review.analyse_records(paired([bad], []), ["a"])
        with self.assertRaises(review.ScaleReviewError):
            review.analyse_records(paired([], [box(confidence=1.1)]), ["a"])

    def test_json_duplicate_and_nonfinite_rejected(self):
        for text in ('{"width":10,"width":20}', '{"width":NaN}', '{"width":Infinity}'):
            with self.subTest(text=text), self.assertRaises(review.ScaleReviewError):
                review.loads(text)


class PlanScaleChainTests(unittest.TestCase):
    def test_complete_chain_and_actual_declared_source_bindings(self):
        with temporary_workspace() as root:
            task = sealed_fixture(root)
            checked = fixture_check(task)
            self.assertEqual(checked["sealed_artifact_count"], 10)
            self.assertEqual(checked["current_declared_source_hashes_verified"], 7)
            self.assertFalse(checked["original_all_inputs_rehashed"])
            self.assertEqual(len(checked["bindings"]), 19)

    def test_original_completion_anchor_refuses_self_rebinding(self):
        with temporary_workspace() as root:
            task = sealed_fixture(root)
            anchor = review.sha(task / "completion.json")
            data = json.loads((task / "completion.json").read_text(encoding="utf-8"))
            data["status"] = "failed"
            dump(task / "completion.json", data)
            with self.assertRaisesRegex(review.ScaleReviewError, "completion hash"):
                fixture_check(task, completion_sha=anchor)

    def test_missing_or_mutated_artifact_rejected(self):
        for missing in (True, False):
            with temporary_workspace() as root:
                task = sealed_fixture(root)
                target = task / "predictions_640.jsonl"
                if missing:
                    target.unlink()
                else:
                    target.write_text("[]", encoding="utf-8")  # Same two-byte size, different hash.
                with self.assertRaisesRegex(review.ScaleReviewError, "artifact|Artifact"):
                    fixture_check(task)

    def test_mutated_declared_source_rejected(self):
        with temporary_workspace() as root:
            task = sealed_fixture(root)
            manifest = json.loads((task / "artifact_manifest.json").read_text(encoding="utf-8"))
            target = Path(manifest["input_evidence"]["weights"]["path"])
            target.write_text("tamper", encoding="utf-8")
            with self.assertRaisesRegex(review.ScaleReviewError, "source hash mismatch"):
                fixture_check(task)

    def test_duplicate_or_escaped_manifest_member_rejected(self):
        for mode in ("duplicate", "escaped"):
            with temporary_workspace() as root:
                task = sealed_fixture(root)
                path = task / "artifact_manifest.json"
                manifest = json.loads(path.read_text(encoding="utf-8"))
                if mode == "duplicate":
                    manifest["files"][1] = copy.deepcopy(manifest["files"][0])
                else:
                    manifest["files"][0]["path"] = str(root / manifest["files"][0]["name"])
                dump(path, manifest)
                completion = json.loads((task / "completion.json").read_text(encoding="utf-8"))
                completion["artifact_manifest_sha256"] = review.sha(path)
                dump(task / "completion.json", completion)
                with self.assertRaisesRegex(review.ScaleReviewError, "membership|path"):
                    fixture_check(task)

    def test_missing_input_role_and_disagreed_source_binding_rejected(self):
        for mode in ("missing", "mismatch"):
            with temporary_workspace() as root:
                task = sealed_fixture(root)
                path = task / "inputs.json"
                data = json.loads(path.read_text(encoding="utf-8"))
                if mode == "missing":
                    data["files"] = data["files"][:-1]
                else:
                    data["files"][0]["sha256_before"] = "0" * 64
                    data["files"][0]["sha256_after"] = "0" * 64
                dump(path, data)
                reseal(task)
                with self.assertRaisesRegex(review.ScaleReviewError, "bindings missing|binding mismatch"):
                    fixture_check(task)


if __name__ == "__main__":
    unittest.main()
