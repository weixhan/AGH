"""Acceptance checks for independent numeric and direction-sensitive goldens."""
import ast
import json
import math
from pathlib import Path
import unittest
from unittest.mock import patch

from defect_researcher import independent_geometry as geometry


class IndependentGeometryTests(unittest.TestCase):
    def test_frozen_fixture_suite_passes_all_cases(self):
        report = geometry.run_fixture_suite()
        self.assertEqual(report["status"], "passed", report)
        self.assertGreaterEqual(report["counts"]["total"], 12)
        self.assertGreater(report["counts"]["real"], 0)
        self.assertGreater(report["counts"]["expected_errors"], 0)
        self.assertEqual(report["counts"]["failed"], 0)
        self.assertTrue(report["evidence"]["fixtures"]["hash_verified"])

    def test_corrupt_reference_hash_cannot_pass(self):
        with patch.object(geometry, "EXPECTED_FIXTURE_SHA256", "0" * 64):
            report = geometry.run_fixture_suite()
        self.assertEqual(report["status"], "failed")
        self.assertFalse(report["evidence"]["fixtures"]["hash_verified"])
        self.assertIn("SHA256", report["errors"][0]["message"])

    def test_suite_detects_wrong_numeric_output(self):
        original = geometry.oracle_geometry

        def incorrect(*args, **kwargs):
            result = original(*args, **kwargs)
            if result["yolo"] is not None:
                result["yolo"][0] += 0.01
            return result

        with patch.object(geometry, "oracle_geometry", side_effect=incorrect):
            report = geometry.run_fixture_suite()
        self.assertEqual(report["status"], "failed")
        failures = [case for case in report["cases"] if case["status"] == "failed"]
        self.assertTrue(any(d["field"].startswith("yolo") for c in failures for d in c["differences"]))

    def test_suite_detects_wrong_rotation_direction(self):
        original = geometry.oracle_geometry

        def reversed_rotation(bbox, rotation, image_width, image_height):
            return original(bbox, -float(rotation), image_width, image_height)

        with patch.object(geometry, "oracle_geometry", side_effect=reversed_rotation):
            report = geometry.run_fixture_suite()
        self.assertEqual(report["status"], "failed")
        failures = {case["id"]: case for case in report["cases"] if case["status"] == "failed"}
        self.assertIn("positive_quarter_turn", failures)
        self.assertTrue(any(d["field"].startswith("corners") for d in failures["positive_quarter_turn"]["differences"]))

    def test_invalid_geometry_raises_value_error(self):
        for bbox, angle, width, height in (
            ([0, 0, 0, 1], 0, 100, 100), ([0, 0, 1, -1], 0, 100, 100),
            ([0, 0, 1], 0, 100, 100), ([0, 0, math.nan, 1], 0, 100, 100),
            ([0, 0, 1, 1], math.inf, 100, 100), ([0, 0, 1, 1], 0, 0, 100),
            ([0, 0, 1, 1], 0, 100, math.inf), (None, 0, 100, 100),
            ({0: 0, 1: 0, 2: 1, 3: 1}, 0, 100, 100), ({0, 1, 2, 3}, 0, 100, 100),
            ([0, 0, 1, 1], 0, True, 100),
        ):
            with self.subTest(bbox=bbox, angle=angle, width=width, height=height):
                with self.assertRaises(ValueError):
                    geometry.oracle_geometry(bbox, angle, width, height)

    def test_off_image_and_zero_area_intersection_are_discarded(self):
        for bbox in ([-50, -50, 10, 10], [100, 5, 10, 10]):
            result = geometry.oracle_geometry(bbox, 0, 100, 100)
            self.assertIsNone(result["hbb"])
            self.assertIsNone(result["yolo"])
            self.assertTrue(result["clipped"])

    def test_reference_has_no_production_geometry_or_checker_import(self):
        tree = ast.parse(Path(geometry.__file__).read_text(encoding="utf-8"))
        imported = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imported.extend(item.name for item in node.names)
            elif isinstance(node, ast.ImportFrom):
                imported.append(node.module or "")
        self.assertTrue(imported)
        self.assertFalse(any("cableinspect_geometry" in name or "checker" in name for name in imported))
        document = json.loads(geometry.FIXTURE_PATH.read_text(encoding="utf-8"))
        self.assertTrue(all(case["kind"] in {"synthetic", "real"} and case["source"] for case in document["cases"]))


if __name__ == "__main__":
    unittest.main()
