"""Cross-implementation and tamper checks for diagnostic evidence."""
import copy
import json
import os
from pathlib import Path
import unittest

from test_config import temporary_workspace
from defect_researcher.detection_diagnosis import diagnose_detections
from tools.verify_diagnosis_run import (
    CLASSES, GRID, decode, decision_checks, detail_checks, digest, equal,
    expected_details, independent_iou, independent_matching, independent_threshold_curve,
    publication, selection_checks, threshold_checks, valid_predictions,
)


def gt(box=(0, 0, 10, 10), class_id=0):
    return {"class_id": class_id, "xyxy": list(box)}


def pred(confidence=.9, box=(0, 0, 10, 10), class_id=0):
    return {**gt(box, class_id), "confidence": confidence}


def image(name, truths, predictions):
    return {"image_id": name, "width": 100, "height": 100, "ground_truth": truths, "predictions": predictions,
            "split": "val", "eval_imgsz": 640, "precision": "FP32", "device": "0"}


def cases():
    return [
        image("conflict", [gt(), gt((1, 0, 11, 10))], [pred()]),
        image("low", [gt()], [pred(.1)]),
        image("wrong", [gt()], [pred(.8, class_id=1)]),
        image("local", [gt()], [pred(.8, (5, 5, 15, 15))]),
        image("absent", [gt()], []),
        image("duplicate", [gt()], [pred(.9), pred(.8)]),
        image("normal", [], [pred(.9, class_id=3)]),
        image("any_class", [gt()], [pred(.9, (0, 0, 8, 8)), pred(.8, class_id=1)]),
    ]


class IndependentDiagnosisEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.records = cases()
        self.actual = diagnose_detections(self.records, CLASSES)

    def check_details(self, actual=None):
        actual = actual or self.actual
        return detail_checks(self.records, actual["gt_details"], actual["fp_details"])

    def test_handwritten_reviewer_matches_all_five_fn_and_four_fp_cases(self):
        checks = self.check_details()
        self.assertTrue(all(checks.values()), checks)
        categories = {r["fn_category"] for r in self.actual["gt_details"] if r["status"] == "fn"}
        self.assertEqual(categories, {"matching_conflict", "localized_low_confidence", "wrong_class_candidate", "localization_candidate", "no_overlap_candidate"})
        self.assertEqual({r["fp_category"] for r in self.actual["fp_details"]}, {"duplicates", "wrong_class", "localization", "background"})

    def test_tp_still_has_absolute_best_any_iou_over_wrong_class_candidates(self):
        row = next(r for r in self.actual["gt_details"] if r["image_id"] == "any_class")
        self.assertEqual(row["status"], "tp")
        self.assertEqual(row["best_any_class_iou"], 1)
        self.assertAlmostEqual(row["best_same_class_iou"], .64)
        row["best_any_class_iou"] = .1
        checks = self.check_details()
        self.assertFalse(checks["best_any_iou_at_least_best_same_iou"])
        self.assertFalse(checks["all_gt_candidates_and_matching_independently_recomputed"])

    def test_forged_matching_gt_index_rejected_even_when_category_counts_unchanged(self):
        row = next(r for r in self.actual["gt_details"] if r["image_id"] == "conflict" and r["gt_index"] == 1)
        row["category_candidate"]["matched_gt_index"] = 1
        self.assertFalse(self.check_details()["all_gt_candidates_and_matching_independently_recomputed"])

    def test_candidate_confidence_cannot_be_filled_from_a_different_prediction(self):
        row = next(r for r in self.actual["gt_details"] if r["image_id"] == "low")
        row["category_candidate"]["confidence"] = .9
        self.assertFalse(self.check_details()["all_gt_candidates_and_matching_independently_recomputed"])

    def test_reclassifying_fn_with_same_total_rejected(self):
        row = next(r for r in self.actual["gt_details"] if r["image_id"] == "low")
        row["fn_category"] = "localization_candidate"
        checks = self.check_details()
        self.assertTrue(checks["gt_categories_mutually_exclusive_and_sum_to_fn"])
        self.assertFalse(checks["all_gt_candidates_and_matching_independently_recomputed"])

    def test_duplicate_gt_and_missing_fp_rows_rejected(self):
        self.actual["gt_details"].append(copy.deepcopy(self.actual["gt_details"][0]))
        self.actual["fp_details"].pop()
        checks = self.check_details()
        self.assertFalse(checks["gt_detail_ids_unique_and_complete"])
        self.assertFalse(checks["fp_detail_ids_unique_and_complete"])

    def test_fp_matching_target_tamper_rejected(self):
        row = next(r for r in self.actual["fp_details"] if r["fp_category"] == "duplicates")
        row["category_gt"]["matched_prediction_index"] = 1
        self.assertFalse(self.check_details()["all_fp_candidates_and_categories_independently_recomputed"])

    def test_evidence_ids_bind_exact_image_and_input_index(self):
        self.actual["gt_details"][0]["evidence_id"] = "a-plausible-but-unbound-id"
        self.assertFalse(self.check_details()["detail_evidence_ids_unique"])

    def test_candidate_iou_tie_uses_input_order_instead_of_confidence(self):
        records = [image("ties", [gt()], [pred(.1), pred(.9)])]
        actual = diagnose_detections(records, CLASSES)
        expected, _, _ = expected_details(records)
        self.assertEqual(expected[0]["best_any_candidate"]["prediction_index"], 0)
        self.assertEqual(actual["gt_details"][0]["best_any_candidate"]["prediction_index"], 0)
        self.assertTrue(all(detail_checks(records, actual["gt_details"], actual["fp_details"]).values()))

    def test_threshold_curve_cross_implementation_and_tamper_detection(self):
        actual = self.actual["threshold_curve"]
        self.assertTrue(equal(actual, independent_threshold_curve(self.records)))
        actual[0]["recovered_fn"] += 1
        self.assertFalse(threshold_checks(self.records, actual)["threshold_curve_independently_recomputed"])

    def test_posthoc_threshold_added_to_curve_rejected(self):
        actual = copy.deepcopy(self.actual["threshold_curve"])
        actual.append({**actual[-1], "confidence_threshold": .6})
        self.assertFalse(threshold_checks(self.records, actual)["threshold_grid_exact_no_posthoc_entries"])

    def test_gain_on_one_image_does_not_pass_five_image_gate(self):
        candidate = {"confidence_threshold": .1, "tp": 10, "precision": 1., "tp_gain": 5,
                     "gain_images_vs_baseline": 1, "within_normal_fp_budget": True, "normal_images": 245}
        forged = {"status": "selected", "reason": "fixed_grid_gain_and_normal_fp_budget_passed", "baseline_threshold": .25,
                  "selected_threshold": .1, "selected_operating_point": candidate, "candidate_thresholds": [.1], "threshold_applied": False}
        self.assertFalse(selection_checks([candidate], forged)["threshold_selection_exact_fixed_budget_and_gain_gates"])

    def test_non_budget_candidate_cannot_be_manually_selected(self):
        candidate = {"confidence_threshold": .1, "tp": 10, "precision": 1., "tp_gain": 5,
                     "gain_images_vs_baseline": 5, "within_normal_fp_budget": False, "normal_images": 245}
        forged = {"status": "selected", "reason": "fixed_grid_gain_and_normal_fp_budget_passed", "baseline_threshold": .25,
                  "selected_threshold": .1, "selected_operating_point": candidate, "candidate_thresholds": [.1], "threshold_applied": False}
        self.assertFalse(selection_checks([candidate], forged)["threshold_selection_exact_fixed_budget_and_gain_gates"])

    def test_selection_ties_require_highest_pre_frozen_threshold(self):
        a = {"confidence_threshold": .1, "tp": 10, "precision": .8, "tp_gain": 5, "gain_images_vs_baseline": 5,
             "within_normal_fp_budget": True, "normal_images": 245}
        b = {**a, "confidence_threshold": .2}
        selected = {"status": "selected", "reason": "fixed_grid_gain_and_normal_fp_budget_passed", "baseline_threshold": .25,
                    "selected_threshold": .2, "selected_operating_point": b, "candidate_thresholds": [.1, .2], "threshold_applied": False}
        self.assertTrue(all(selection_checks([a, b], selected).values()))
        selected["selected_threshold"], selected["selected_operating_point"] = .1, a
        self.assertFalse(selection_checks([a, b], selected)["threshold_selection_exact_fixed_budget_and_gain_gates"])

    def test_small_four_gt_cannot_be_promoted_to_supported_slicing(self):
        records = [image(f"small-{i}", [gt()], []) for i in range(4)] + [image("normal", [], [])]
        actual = diagnose_detections(records, CLASSES)
        threshold = {"curve": actual["threshold_curve"], "selection": actual["selection"]}
        decision = {"recommendations": actual["recommendations"], "selection": actual["selection"], "new_inference_budget": 0, "automatically_applied": False}
        checks = decision_checks(records, actual["gt_details"], threshold, decision)
        self.assertTrue(all(checks.values()), checks)
        actual["recommendations"]["slicing"]["size_support"][0]["supported"] = True
        actual["recommendations"]["next_branch"] = "sliced_inference_controlled"
        checks = decision_checks(records, actual["gt_details"], threshold, decision)
        self.assertFalse(checks["slicing_minimum_evidence_and_enrichment_recomputed"])
        self.assertFalse(checks["next_branch_follows_pre_frozen_evidence_priority"])

    def test_recommendation_cannot_claim_spending_or_threshold_application(self):
        threshold = {"curve": self.actual["threshold_curve"], "selection": self.actual["selection"]}
        decision = {"recommendations": self.actual["recommendations"], "selection": self.actual["selection"], "new_inference_budget": 1, "automatically_applied": True}
        self.assertFalse(decision_checks(self.records, self.actual["gt_details"], threshold, decision)["decision_does_not_spend_new_inference_or_apply_threshold"])

    def test_nonfinite_duplicate_json_and_bool_numeric_equality_rejected(self):
        for text in ('{"a":1,"a":2}', '{"a":NaN}', '{"a":1e400}'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                decode(text)
        self.assertFalse(equal(True, 1))
        self.assertFalse(equal(False, 0))

    def test_saved_confidence_floor_and_class_type_guarded(self):
        self.assertTrue(valid_predictions(self.records))
        altered = copy.deepcopy(self.records)
        altered[0]["predictions"][0]["confidence"] = .0005
        self.assertFalse(valid_predictions(altered))
        altered = copy.deepcopy(self.records)
        altered[0]["predictions"][0]["class_id"] = False
        self.assertFalse(valid_predictions(altered))

    def test_iou_identical_disjoint_and_no_positive_union(self):
        self.assertEqual(independent_iou([0, 0, 10, 10], [0, 0, 10, 10]), 1)
        self.assertEqual(independent_iou([0, 0, 10, 10], [11, 11, 21, 21]), 0)
        with self.assertRaises(ValueError):
            independent_iou([0, 0, 0, 0], [0, 0, 0, 0])


class DiagnosisPublicationEvidenceTests(unittest.TestCase):
    def publish(self, directory):
        artifact = directory / "report.json"
        artifact.write_text('{"value":1}\n', encoding="utf-8")
        row = {"name": artifact.name, "path": str(artifact), "size_bytes": artifact.stat().st_size, "sha256": digest(artifact)}
        manifest = directory / "artifact_manifest.json"
        manifest.write_text(json.dumps({"task_id": directory.name, "tool": "diagnose_validation_errors", "status": "completed", "files": [row]}), encoding="utf-8")
        completion = directory / "completion.json"
        completion.write_text(json.dumps({"task_id": directory.name, "tool": "diagnose_validation_errors", "status": "completed", "artifact_manifest": str(manifest),
                                          "artifact_manifest_sha256": digest(manifest), "artifacts_sha256": {row["name"]: row["sha256"]}}), encoding="utf-8")

    def test_sealed_artifact_mutation_and_completion_order_rejected(self):
        with temporary_workspace() as root:
            directory = Path(root)
            self.publish(directory)
            self.assertTrue(publication(directory, directory.name, "diagnose_validation_errors", {"report.json"}))
            old = (directory / "completion.json").stat().st_mtime_ns
            os.utime(directory / "completion.json", ns=(old - 1000000000, old - 1000000000))
            self.assertFalse(publication(directory, directory.name, "diagnose_validation_errors", {"report.json"}))
            self.publish(directory)
            (directory / "report.json").write_text('{"value":2}\n', encoding="utf-8")
            self.assertFalse(publication(directory, directory.name, "diagnose_validation_errors", {"report.json"}))

    def test_required_artifact_cannot_be_omitted_or_replaced_by_duplicate_name(self):
        with temporary_workspace() as root:
            directory = Path(root)
            self.publish(directory)
            self.assertFalse(publication(directory, directory.name, "diagnose_validation_errors", {"report.json", "gt_details.jsonl"}))
            manifest = json.loads((directory / "artifact_manifest.json").read_text(encoding="utf-8"))
            manifest["files"].append(copy.deepcopy(manifest["files"][0]))
            (directory / "artifact_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
            completion = json.loads((directory / "completion.json").read_text(encoding="utf-8"))
            completion["artifact_manifest_sha256"] = digest(directory / "artifact_manifest.json")
            (directory / "completion.json").write_text(json.dumps(completion), encoding="utf-8")
            self.assertFalse(publication(directory, directory.name, "diagnose_validation_errors", {"report.json"}))


if __name__ == "__main__":
    unittest.main()
