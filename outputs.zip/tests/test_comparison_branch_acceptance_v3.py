"""Negative branch/accounting acceptance checks; no model or service calls."""
import copy
import hashlib
import unittest
import json
from pathlib import Path
import shutil
from uuid import uuid4
from contextlib import contextmanager

from tools.summarize_comparison_branches_v3 import (
    branch_acceptance, canonical, reported_selection, request_accounting, selected_trials, time_acceptance, phase_capacity_accounting, unselected_observations, runtime_binding,
)


@contextmanager
def test_directory():
    parent = Path(__file__).resolve().parents[1] / "outputs"
    directory = parent / ("_local_v9_acceptance_test_" + uuid4().hex)
    directory.mkdir()
    try:
        yield str(directory)
    finally:
        resolved = directory.resolve()
        if resolved.parent != parent.resolve():
            raise ValueError("Test cleanup escaped the owned outputs directory")
        shutil.rmtree(resolved)


def branch(case="refuse_source_hash"):
    business = {"status": "passed", "correct_completion": True, "unsupported_atomic_claims": 0,
                "invalid_artifact_accepted": False, "checks": [
                    {"name": "original_input_exact_membership_and_bytes", "passed": True},
                    {"name": "source_refusal_without_any_copy", "passed": True}]}
    verifier = {"evidence_id": "verify", "action": "verify_input", "result": {
        "execution_status": "completed", "semantic_status": "failed", "task_chain_verified": True,
        "summary": {"independent_geometry_verification": True, "issues_by_code": {"declared_input_hash": 1}}}}
    return dict(driver_status="completed", run_status="completed", engineering_status="passed", business=business,
                candidate={"outcome": "refused", "target": "none", "evidence_ids": ["verify"]},
                evidence=[verifier], actions=["verify_input", "publish_report"],
                actual_changed_files=None, copied_content_present=False)


def selection():
    cases = ["normal_unrotated", "repair_coordinates", "refuse_source_hash"]
    trials = [{"trial_id": f"trial-{index}", "trial_handle": "cmp_" + f"{index:032x}", "case_id": case, "arm": arm}
              for index, (case, arm) in enumerate(((case, arm) for case in cases for arm in ("C", "U", "F")), 1)]
    selected = [row for row in trials if row["arm"] == "F" and row["case_id"] == "refuse_source_hash"]
    value = {"schema_version": 1, "arm": "F", "case_ids": cases[2:], "trial_handles": [row["trial_handle"] for row in selected]}
    public = {"engineering_diagnostic": {"selection": value, "selection_sha256": hashlib.sha256(canonical(value)).hexdigest(),
                "selected_trials": selected, "selected_trial_count": 1, "planned_comparison_trials": 9},
              "scope_policy": {"allowed_handles": value["trial_handles"]},
              "phase_model_budget": {"total_cap": 48, "prior_closed_request_slots": 34, "request_slots_debited": 41,
                                      "this_pilot_cap": 7, "phase_remaining_before_diagnostic": 7,
                                      "legacy_token_usage_closed": False}}
    return {"trials": trials}, public


def accounting(request_count=1):
    end = {"type": "turn/end", "data": {"reason": "completed"}}
    requested = {"type": "x/host/session-title", "data": {"status": "requested"}}
    terminal = {"type": "x/host/session-title", "data": {"status": "generated"}}
    events = [{"type": "request/sent"}, {"type": "cost/ledger", "data": {
        "purpose": "inference", "tokens": {"input": 1, "output": 1, "cacheRead": 0, "cacheWrite": 0}, "response": {"status": 200}}}, end, requested,
        {"type": "cost/ledger", "data": {"purpose": "title", "tokens": {"input": 1, "output": 1, "cacheRead": 0, "cacheWrite": 0}}}, terminal]
    events = [copy.deepcopy(row) for _ in range(request_count) for row in events[:2]] + events[2:]
    run = {"model_request_count": request_count, "model_requests_including_title": request_count + 1, "turn_end": end,
           "title_request_event": requested, "title_terminal_event": terminal}
    return events, run


class BranchAcceptanceTests(unittest.TestCase):
    def test_current_exact_refusal_passes(self):
        self.assertTrue(branch_acceptance("refuse_source_hash", **branch())["joint_correct_completion"])

    def test_repair_case_cannot_replace_current_selected_refusal(self):
        self.assertFalse(branch_acceptance("repair_coordinates", **branch())["joint_correct_completion"])

    def test_bad_business_artifact_cannot_pass(self):
        data = branch()
        data["business"].update(correct_completion=False, invalid_artifact_accepted=True)
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_engineering_failure_cannot_be_business_success(self):
        data = branch()
        data["engineering_status"] = "failed"
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_selected_unstarted_cannot_pass(self):
        data = branch()
        data.update(driver_status=None, run_status=None)
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_original_membership_or_bytes_must_be_independently_unchanged(self):
        for replacement in (False, None, True):
            data = branch()
            if replacement is True:
                data["business"]["checks"] = []
            else:
                data["business"]["checks"][0]["passed"] = replacement
            self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_uncited_or_missing_explicit_input_verification_is_insufficient(self):
        data = branch()
        data["candidate"]["evidence_ids"] = []
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])
        data = branch()
        data["actions"].remove("verify_input")
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_refusal_without_hash_basis_fails(self):
        data = branch("refuse_source_hash")
        data["evidence"][0]["result"]["summary"]["issues_by_code"] = {"yolo_geometry": 1}
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_refusal_repair_attempt_or_copied_directory_fails(self):
        data = branch("refuse_source_hash")
        data["actions"].append("repair_copy")
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])
        data = branch("refuse_source_hash")
        data["copied_content_present"] = True
        self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_unsupported_or_unknown_claims_fail(self):
        for count in (None, True, 1):
            data = branch()
            data["business"]["unsupported_atomic_claims"] = count
            self.assertFalse(branch_acceptance("refuse_source_hash", **data)["joint_correct_completion"])

    def test_selection_matches_exact_new_protocol_order(self):
        protocol, public = selection()
        self.assertEqual([row["case_id"] for row in selected_trials(protocol, public)], ["refuse_source_hash"])
        protocol["trials"][8]["case_id"] = "repair_coordinates"
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)

    def test_selection_hash_or_old_phase_allocation_fails(self):
        protocol, public = selection()
        public["engineering_diagnostic"]["selection_sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)
        protocol, public = selection()
        public["phase_model_budget"]["request_slots_debited"] = 34
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)

    def test_selected_unstarted_slot_preserved_and_foreign_report_rejected(self):
        protocol, public = selection()
        selected = selected_trials(protocol, public)
        valid, observations = reported_selection(selected, [])
        self.assertTrue(valid)
        self.assertEqual(observations, [None])
        valid, observations = reported_selection(selected, [{**selected[0], "status": "failed"}])
        self.assertTrue(valid)
        self.assertEqual(observations[0]["status"], "failed")
        valid, _ = reported_selection(selected, [protocol["trials"][5]])
        self.assertFalse(valid)
        valid, _ = reported_selection(selected, [selected[0], selected[0]])
        self.assertFalse(valid)

    def test_original_capacity_and_unknown_history_cannot_be_promoted(self):
        for key, value in (("total_cap", 49), ("this_pilot_cap", 8), ("request_slots_debited", 34),
                           ("legacy_token_usage_closed", True), ("prior_versions_actual_requests", 41)):
            protocol, public = selection()
            public["phase_model_budget"][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                selected_trials(protocol, public)

    def test_phase_actual_always_unknown_despite_closed_current_diagnostic(self):
        for current in (0, 2, 7, None, True, 8):
            value = phase_capacity_accounting(current)
            self.assertIsNone(value["model_requests_phase_actual"])
            self.assertIsNone(value["phase_actual_usage_closed"])
            self.assertIs(value["legacy_token_usage_closed"], False)
            self.assertEqual(value["request_slots_debited_after_conservative_reservation"], 48)
            self.assertEqual(value["within_original_capacity"], type(current) is int and 0 <= current <= 7)
        self.assertEqual(phase_capacity_accounting(7)["request_slots_debited_after"], 48)
        self.assertIsNone(phase_capacity_accounting(None)["request_slots_debited_after"])

    def test_eight_unselected_positions_have_no_unreported_arm_or_actions(self):
        protocol, public = selection()
        selected = selected_trials(protocol, public)
        with test_directory() as name:
            root = Path(name)
            rows = unselected_observations(protocol, selected, pilot=root)
            self.assertEqual(len(rows), 8)
            self.assertTrue(all(row["arm_file_absent"] and row["driver_record_absent"] and row["execution_journals_absent"] for row in rows))
            directory = root / "runtime/trials" / protocol["trials"][0]["trial_handle"]
            directory.mkdir(parents=True)
            (directory / "budget.jsonl").write_text("{}\n", encoding="utf8")
            self.assertFalse(unselected_observations(protocol, selected, pilot=root)[0]["execution_journals_absent"])
            (directory / "arm.json").write_text("{}", encoding="utf8")
            self.assertFalse(unselected_observations(protocol, selected, pilot=root)[0]["arm_file_absent"])

    def test_modified_runtime_binds_frozen_archives_and_trial_before_after(self):
        with test_directory() as name:
            root = Path(name)
            archive = root / "archive.mjs"
            archive.write_bytes(b"runtime-v9")
            sha = hashlib.sha256(archive.read_bytes()).hexdigest()
            live = root / "live.mjs"
            live.write_bytes(b"later-version-allowed-after-this-diagnostic")
            manifest = root / "repair_verification.json"
            manifest.write_text(json.dumps({"status": "passed_local_repair", "agh_core_modified": True,
                "runtime_files": [{"path": str(live), "archive": str(archive), "sha256": sha}]}), encoding="utf8")
            public = {"runtime_version": {"path": str(manifest), "sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(), "size_bytes": manifest.stat().st_size}}
            suite = {"agh_core_modified": True, "runtime_before": [{"path": str(live), "sha256": sha}],
                     "runtime_after": [{"path": str(live), "sha256": sha}]}
            self.assertTrue(runtime_binding(public, suite, root=root))
            suite["runtime_after"][0]["sha256"] = "0" * 64
            with self.assertRaises(ValueError):
                runtime_binding(public, suite, root=root)
            suite["runtime_after"][0]["sha256"] = sha
            archive.write_bytes(b"changed archive")
            with self.assertRaises(ValueError):
                runtime_binding(public, suite, root=root)

    def test_missing_cost_ledger_is_unknown_not_zero(self):
        self.assertIsNone(request_accounting(None, {})["actual_total_model_requests"])
        events, run = accounting()
        events = [row for row in events if row.get("type") != "cost/ledger"]
        result = request_accounting(events, run)
        self.assertEqual(result["observed_total_model_requests"], 2)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_title_and_turn_costs_must_both_settle(self):
        events, run = accounting()
        self.assertEqual(request_accounting(events, run)["actual_total_model_requests"], 2)
        for kind in ("x/host/session-title", "turn/end"):
            with self.subTest(kind=kind):
                incomplete = [row for row in events if row["type"] != kind]
                self.assertIsNone(request_accounting(incomplete, run)["actual_total_model_requests"])
        events, run = accounting()
        events[1]["data"]["tokens"] = None
        self.assertIsNone(request_accounting(events, run)["actual_total_model_requests"])

    def test_interrupted_native_title_or_unknown_zero_usage_stays_unknown(self):
        for update in ({"interrupted": True}, {"tokens": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}},
                       {"tokens": {"input": 1, "output": 1}}, {"tokens": {"input": True, "output": 1, "cacheRead": 0, "cacheWrite": 0}}):
            events, run = accounting()
            events[-2]["data"].update(update)
            result = request_accounting(events, run)
            self.assertEqual(result["observed_total_model_requests"], 2)
            self.assertIsNone(result["actual_total_model_requests"])
            self.assertIs(result["model_costs_known_and_closed"], False)

    def test_optional_reasoning_usage_is_safe_and_does_not_supply_positive_title_usage(self):
        events, run = accounting()
        events[1]["data"]["tokens"]["reasoning"] = 2
        events[-2]["data"]["tokens"]["reasoning"] = 2
        self.assertEqual(request_accounting(events, run)["actual_total_model_requests"], 2)
        self.assertNotIn("interrupted", events[-2]["data"])
        for update in ({"input": 0, "output": 0, "cacheRead": 1, "cacheWrite": 0, "reasoning": 2},
                       {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0, "reasoning": 2}):
            events, run = accounting()
            events[-2]["data"]["tokens"] = update
            self.assertIsNone(request_accounting(events, run)["actual_total_model_requests"])

    def test_unknown_token_fields_or_unsafe_integers_cannot_close_usage(self):
        for field, value in (("reasoning", True), ("reasoning", -1), ("reasoning", 0.5),
                             ("reasoning", 9_007_199_254_740_992), ("output", 9_007_199_254_740_992),
                             ("unrecognizedTokenCount", 1)):
            for cost_index in (1, -2):
                events, run = accounting()
                events[cost_index]["data"]["tokens"][field] = value
                with self.subTest(field=field, value=value, cost_index=cost_index):
                    self.assertIsNone(request_accounting(events, run)["actual_total_model_requests"])
        events, run = accounting()
        events[-2]["data"]["tokens"]["output"] = 9_007_199_254_740_991
        self.assertEqual(request_accounting(events, run)["actual_total_model_requests"], 2)

    def test_title_after_finalization_or_reset_deadline_fails(self):
        arm = {"started_epoch": 1000, "deadline_epoch": 1120, "started_monotonic": 100, "deadline_monotonic": 220}
        run = {"started_epoch_ms": 1000000, "deadline_epoch_ms": 1120000, "finished_epoch_ms": 1005000,
               "title_terminal_event": {"ts": "1970-01-01T00:16:44+00:00"}}
        self.assertTrue(time_acceptance(run, arm)[0])
        run["title_terminal_event"]["ts"] = "1970-01-01T00:16:46+00:00"
        self.assertFalse(time_acceptance(run, arm)[0])
        run["deadline_epoch_ms"] += 1000
        self.assertFalse(time_acceptance(run, arm)[0])

    def test_primary_seven_rejected_even_without_title_request(self):
        events, run = accounting(request_count=7)
        terminal = {"type": "x/host/session-title", "data": {"status": "failed", "reason": "budget"}}
        events = [row for row in events if row["type"] != "x/host/session-title"
                  and not (row["type"] == "cost/ledger" and row["data"]["purpose"] == "title")] + [terminal]
        run.pop("title_request_event")
        run.update(title_terminal_event=terminal, model_requests_including_title=7)
        result = request_accounting(events, run)
        self.assertEqual(result["main_model_requests"], 7)
        self.assertEqual(result["native_title_requests"], 0)
        self.assertEqual(result["observed_total_model_requests"], 7)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_eight_combined_requests_rejected(self):
        events, run = accounting(request_count=7)
        result = request_accounting(events, run)
        self.assertEqual(result["observed_total_model_requests"], 8)
        self.assertIsNone(result["actual_total_model_requests"])

    def test_six_primary_and_one_title_accepts_exact_new_ceiling(self):
        events, run = accounting(request_count=6)
        result = request_accounting(events, run)
        self.assertEqual(result["main_model_requests"], 6)
        self.assertEqual(result["native_title_requests"], 1)
        self.assertEqual(result["actual_total_model_requests"], 7)


if __name__ == "__main__":
    unittest.main()
