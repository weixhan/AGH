"""Closure rejects stale success, unknown usage and unreported executions."""
from contextlib import contextmanager
import hashlib
from pathlib import Path
import shutil
import unittest
from uuid import uuid4

from tools.close_comparison_branches_v10 import (
    canonical, check_records, joint_acceptance, read, record, reported_selection,
    selected_trials, unselected_observations,
)


@contextmanager
def temporary_directory():
    parent = Path(__file__).resolve().parents[1] / "outputs"
    directory = parent / ("_closure_v10_test_" + uuid4().hex)
    directory.mkdir()
    try:
        yield directory
    finally:
        resolved = directory.resolve()
        if resolved.parent != parent.resolve():
            raise ValueError("Test cleanup escaped its owned outputs directory")
        shutil.rmtree(resolved)


def selection():
    trials = [{"trial_id": f"trial-{index}", "trial_handle": "cmp_" + f"{index:032x}",
               "case_id": case, "arm": arm} for index, (case, arm) in enumerate(
        ((case, arm) for case in ("normal_unrotated", "repair_coordinates", "refuse_source_hash")
         for arm in ("C", "U", "F")), 1)]
    selected = [row for row in trials if row["arm"] == "F" and row["case_id"] != "normal_unrotated"]
    value = {"schema_version": 1, "arm": "F", "case_ids": ["repair_coordinates", "refuse_source_hash"],
             "trial_handles": [row["trial_handle"] for row in selected]}
    public = {"engineering_diagnostic": {"selection": value,
        "selection_sha256": hashlib.sha256(canonical(value)).hexdigest(), "selected_trials": selected,
        "selected_trial_count": 2, "planned_comparison_trials": 9},
        "scope_policy": {"allowed_handles": value["trial_handles"]}}
    return {"trials": trials}, public


def completed():
    return {"driver_status": "completed", "run_status": "completed", "engineering": {"status": "passed"},
            "runtime": {"status": "passed", "native_title_usage_closed": True},
            "business": {"status": "passed", "correct_completion": True,
                         "unsupported_atomic_claims": 0, "invalid_artifact_accepted": False},
            "accounting": {"model_costs_known_and_closed": True, "actual_total_model_requests": 5}}


class ClosureAcceptanceTests(unittest.TestCase):
    def test_positive_joint_and_each_missing_acceptance_rejected(self):
        self.assertTrue(joint_acceptance(**completed())["joint_correct_completion"])
        for key, replacement in (("driver_status", "failed"), ("run_status", "failed"),
                                 ("engineering", {"status": "failed"}), ("runtime", {"status": "passed"}),
                                 ("business", {"status": "passed", "correct_completion": False}),
                                 ("accounting", {"model_costs_known_and_closed": True, "actual_total_model_requests": None})):
            data = completed()
            data[key] = replacement
            with self.subTest(key=key):
                self.assertFalse(joint_acceptance(**data)["joint_correct_completion"])

    def test_unknown_boolean_zero_or_over_budget_usage_not_success(self):
        for count in (None, True, 0, 8, 5.0):
            data = completed()
            data["accounting"]["actual_total_model_requests"] = count
            with self.subTest(count=count):
                self.assertFalse(joint_acceptance(**data)["joint_correct_completion"])

    def test_hidden_source_mutation_or_wrong_file_size_rejected(self):
        with temporary_directory() as temporary:
            path = Path(temporary) / "source.py"
            path.write_bytes(b"expected")
            pinned = record(path)
            self.assertEqual(check_records([pinned]), 1)
            for size in (len(b"expected") - 1, True):
                with self.subTest(size=size), self.assertRaises(ValueError):
                    check_records([{**pinned, "size_bytes": size}])
            path.write_bytes(b"modified")
            with self.assertRaises(ValueError):
                check_records([pinned])

    def test_foreign_replayed_reordered_selection_rejected(self):
        protocol, public = selection()
        expected = selected_trials(protocol, public)
        for rows in ([expected[1]], [expected[0], expected[0]], [protocol["trials"][0]]):
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                reported_selection(expected, rows)
        observations = reported_selection(expected, [{**expected[0], "status": "failed"}])
        self.assertEqual(observations[0]["status"], "failed")
        self.assertIsNone(observations[1])
        public["engineering_diagnostic"]["selection"]["trial_handles"].reverse()
        with self.assertRaises(ValueError):
            selected_trials(protocol, public)

    def test_unselected_empty_model_directory_and_arm_are_real_execution_breaches(self):
        protocol, public = selection()
        selected = selected_trials(protocol, public)
        with temporary_directory() as temporary:
            pilot = Path(temporary)
            observations = unselected_observations(protocol, selected, pilot=pilot)
            self.assertEqual(len(observations), 7)
            self.assertTrue(all(row["no_execution_observed"] for row in observations))
            handle = observations[0]["trial_handle"]
            (pilot / "model_runs" / handle).mkdir(parents=True)
            observations = unselected_observations(protocol, selected, pilot=pilot)
            self.assertFalse(observations[0]["no_execution_observed"])
            trial = pilot / "runtime/trials" / handle
            trial.mkdir(parents=True)
            (trial / "arm.json").write_text("{}", encoding="utf8")
            observations = unselected_observations(protocol, selected, pilot=pilot)
            self.assertFalse(observations[0]["arm_file_absent"])

    def test_duplicate_and_overflowing_json_receipts_rejected(self):
        with temporary_directory() as temporary:
            path = Path(temporary) / "receipt.json"
            for value in ('{"actual":0,"actual":5}', '{"actual":1e999}', '{"actual":NaN}'):
                path.write_text(value, encoding="utf8")
                with self.subTest(value=value), self.assertRaises(ValueError):
                    read(path)


if __name__ == "__main__":
    unittest.main()
