"""Actual shared inputs, treatment differences and original-budget boundaries."""
from pathlib import Path
import copy
import json
import unittest
from unittest.mock import patch

from defect_researcher.config import load_config
from defect_researcher import comparison_case_runtime_v1 as runtime
from defect_researcher import labelguard_fixtures
from test_config import temporary_workspace


class ComparisonRuntimeTests(unittest.TestCase):
    def instance(self, directory, **kwargs):
        return runtime.Runtime({**load_config(), "output_root": str(directory / "comparison")}, **kwargs)

    def prepared(self, instance, arm="F", case="normal_unrotated", identity="trial"):
        value = instance.prepare(identity, case, arm)
        handle = value["trial_handle"]
        instance.arm(handle)
        return handle, instance.root / "trials" / handle

    def report(self, handle, evidence, *, outcome="clean", claim_value=None):
        result = evidence["result"]
        if evidence["action"] == "inspect_input":
            field, value = "summary.label_files", result["summary"]["label_files"]
        else:
            field, value = "summary.issue_count", result["summary"]["issue_count"]
        return {"schema_version": 1, "trial_handle": handle, "outcome": outcome,
                "target": {"clean": "input", "repaired": "copy", "refused": "none"}[outcome],
                "evidence_ids": [evidence["evidence_id"]],
                "claims": [{"name": "source_claim", "field": field,
                            "value": value if claim_value is None else claim_value,
                            "evidence_id": evidence["evidence_id"]}],
                "scope": {"synthetic_only": True, "historical_evidence_reused": False,
                          "new_detector_calls": 0, "gpu_seconds": 0}}

    def test_three_treatments_share_every_input_byte_and_absolute_path(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            registrations = []
            for arm in ("C", "U", "F"):
                handle = instance.prepare("same-bytes-" + arm, "normal_quarter_turn", arm)["trial_handle"]
                registrations.append(runtime.read(instance.root / "trials" / handle / "registration.json"))
            expected = registrations[0]["input_snapshot"]
            self.assertTrue(all(item["input_snapshot"] == expected for item in registrations))
            self.assertTrue(all(item["prepared_case"] == registrations[0]["prepared_case"] for item in registrations))
            self.assertEqual(len([path for path in (instance.root / "inputs").iterdir() if path.is_dir()]), 1)
            self.assertEqual(len({item["trial_handle"] for item in registrations}), 3)

    def test_preregistered_handle_is_host_only_and_duplicate_identity_cannot_reset(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle = "cmp_" + "a" * 32
            self.assertEqual(instance.prepare("registered", "normal_unrotated", "U", handle)["trial_handle"], handle)
            with self.assertRaises(FileExistsError):
                instance.prepare("registered", "normal_unrotated", "U", "cmp_" + "b" * 32)
            with self.assertRaises(FileExistsError):
                instance.prepare("another", "normal_unrotated", "F", handle)
            self.assertFalse((instance.root / "trials" / ("cmp_" + "b" * 32)).exists())
            with self.assertRaises(ValueError):
                instance.execute({"trial_handle": handle, "action": "inspect_input", "case_id": "normal_unrotated"})

    def test_inspection_has_no_geometry_call_and_does_not_disclose_treatment_or_goldens(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, _ = self.prepared(instance, arm="U", case="repair_coordinates")
            with patch.object(runtime.domain, "verify_case") as verify:
                result = instance.action(handle, "inspect_input")
            verify.assert_not_called()
            self.assertFalse(result["evidence"]["geometry_verifier_called"])
            self.assertEqual(result["budget"]["domain_invocations_used"], 0)
            text = runtime.canonical(result).decode("utf-8")
            for secret in ("repair_coordinates", "case_expected", "case_group", "golden", str(instance.root), "E:\\"):
                self.assertNotIn(secret, text)
            self.assertLessEqual(len(runtime.canonical(result)), 4000)
            self.assertIsNone(result["budget"]["model_requests"])

    def test_all_twelve_real_inputs_and_four_repairs_close_exact_nested_costs(self):
        specification = labelguard_fixtures.load_case_spec()
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            for case in specification["cases"]:
                with self.subTest(case=case["id"]):
                    handle, trial = self.prepared(instance, case=case["id"], identity=case["id"])
                    before = runtime.read(trial / "registration.json")["input_snapshot"]
                    public = instance.action(handle, "verify_input")
                    original = runtime.read(trial / "evidence/verify_input.json")["result"]
                    self.assertEqual(public["budget"]["domain_invocations_used"], 1)
                    self.assertLessEqual(len(runtime.canonical(public)), 4000)
                    decision = runtime.domain.classify_geometry(original)
                    self.assertEqual(decision, {"normal": "clean", "repairable": "repairable", "refused": "untrusted"}[case["group"]])
                    if case["group"] == "repairable":
                        repaired = instance.action(handle, "repair_copy")
                        checked = instance.action(handle, "verify_copy")
                        self.assertEqual(repaired["evidence"]["semantic_status"], "passed")
                        self.assertEqual(repaired["evidence"]["summary"]["changed_files"], len(case["expected"]["changed_files"]))
                        self.assertEqual(checked["evidence"]["semantic_status"], "passed")
                        self.assertEqual(checked["budget"]["domain_invocations_used"], 5)
                        private = runtime.read(trial / "evidence/repair_copy.json")["result"]
                        self.assertTrue(all(private["acceptance_checks"].values()))
                    registration = runtime.read(trial / "registration.json")
                    self.assertEqual(runtime.domain.snapshot_case(registration["prepared_case"]), before)

    def test_schema_valid_false_claim_is_accepted_u_and_rejected_f(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            outcomes = {}
            for arm in ("U", "F"):
                handle, trial = self.prepared(instance, arm=arm, identity="false-claim-" + arm)
                instance.action(handle, "verify_input")
                evidence = runtime.read(trial / "evidence/verify_input.json")
                result = instance.action(handle, "publish_report", self.report(handle, evidence, claim_value=999))
                outcomes[arm] = result["status"]
                self.assertEqual((trial / "completion.json").exists(), arm == "U")
                self.assertEqual((trial / "failure.json").exists(), arm == "F")
                self.assertEqual(runtime.read(trial / "publication.json")["gate_enforced"], arm == "F")
                self.assertNotIn("gate_enforced", result["publication"])
            self.assertEqual(outcomes, {"U": "published", "F": "rejected"})

    def test_u_can_choose_no_verifier_while_f_requires_its_publication_role(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            for arm in ("U", "F"):
                handle, trial = self.prepared(instance, arm=arm, identity="omit-verify-" + arm)
                instance.action(handle, "inspect_input")
                evidence = runtime.read(trial / "evidence/inspect_input.json")
                result = instance.action(handle, "publish_report", self.report(handle, evidence))
                self.assertEqual(result["status"], "published" if arm == "U" else "rejected")
                self.assertEqual(result["budget"]["domain_invocations_used"], 0)

    def test_matching_claim_and_verified_role_can_publish_f(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance)
            instance.action(handle, "verify_input")
            evidence = runtime.read(trial / "evidence/verify_input.json")
            result = instance.action(handle, "publish_report", self.report(handle, evidence))
            self.assertEqual(result["status"], "published")
            completion = runtime.read(trial / "completion.json")
            self.assertEqual(completion["publication_sha256"], runtime.sha(trial / "publication.json"))
            self.assertIsNone(completion["budget"]["pending"])
            self.assertEqual(completion["budget"]["domain_invocations_used"], 1)

    def test_full_repair_at_exact_six_cost_capacity_can_publish_without_another_geometry_call(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance, case="repair_coordinates")
            for action in ("inspect_input", "verify_input", "repair_copy", "verify_copy", "read_science"):
                result = instance.action(handle, action)
            self.assertEqual(result["budget"]["domain_invocations_used"], 6)
            checked = runtime.read(trial / "evidence/verify_copy.json")
            science = runtime.read(trial / "evidence/read_science.json")
            candidate = self.report(handle, checked, outcome="repaired")
            candidate["evidence_ids"].append(science["evidence_id"])
            candidate["claims"].append({"name": "relative_small_gt", "field": "summary.relative_small.gt",
                "value": 94, "evidence_id": science["evidence_id"]})
            candidate["scope"]["historical_evidence_reused"] = True
            with patch.object(runtime.domain, "verify_case") as verify_input, \
                    patch.object(runtime.domain, "verify_copy") as verify_copy:
                result = instance.action(handle, "publish_report", candidate)
            verify_input.assert_not_called()
            verify_copy.assert_not_called()
            self.assertEqual(result["status"], "published")
            self.assertEqual(result["budget"]["domain_invocations_used"], 6)
            self.assertEqual(runtime.read(trial / "gate.json")["geometry_calls_performed"], 0)

    def test_copy_byte_change_after_explicit_check_is_rejected_by_f_gate(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance, case="repair_coordinates")
            instance.action(handle, "repair_copy")
            instance.action(handle, "verify_copy")
            checked = runtime.read(trial / "evidence/verify_copy.json")
            candidate = self.report(handle, checked, outcome="repaired")
            copy_root = Path(checked["result"]["configuration"]["dataset_root"])
            target = copy_root / "labels/train/image_1.txt"
            target.write_bytes(target.read_bytes() + b"\n")
            result = instance.action(handle, "publish_report", candidate)
            self.assertEqual(result["status"], "rejected")
            self.assertFalse((trial / "completion.json").exists())
            self.assertTrue((trial / "failure.json").exists())

    def test_late_publication_marker_is_preserved_as_rejected_and_cannot_resume(self):
        now = [100.0, 1000.0]
        with temporary_workspace() as directory:
            instance = self.instance(directory, clock=lambda: now[0], epoch_clock=lambda: now[1])
            handle, trial = self.prepared(instance)
            instance.action(handle, "verify_input")
            checked = runtime.read(trial / "evidence/verify_input.json")
            candidate = self.report(handle, checked)
            original = runtime.write_exclusive
            def late(path, value):
                original(path, value)
                if Path(path).name == "completion.json":
                    now[:] = [221.0, 1121.0]
            with patch.object(runtime, "write_exclusive", side_effect=late):
                with self.assertRaisesRegex(runtime.BudgetError, "deadline expired"):
                    instance.action(handle, "publish_report", candidate)
            self.assertFalse((trial / "completion.json").exists())
            self.assertTrue((trial / "completion_rejected.json").exists())
            self.assertTrue((trial / "failure.json").exists())
            self.assertEqual(runtime._journal(trial / "budget.jsonl")[-1]["event"], "action_closed")

    def test_external_input_byte_change_stops_before_any_action(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance)
            registration = runtime.read(trial / "registration.json")
            path = Path(registration["prepared_case"]["configuration"]["dataset_root"]) / "labels/train/image_1.txt"
            path.write_bytes(path.read_bytes() + b"\n")
            with patch.object(runtime.domain, "verify_case") as verify:
                with self.assertRaisesRegex(ValueError, "input.*changed|Original|original"):
                    instance.action(handle, "verify_input")
            verify.assert_not_called()
            self.assertFalse((trial / "actions.jsonl").exists())
            self.assertFalse((trial / "completion.json").exists())

    def test_original_clock_starts_before_arming_source_io_and_cannot_reset(self):
        now = [100.0, 1000.0]
        with temporary_workspace() as directory:
            instance = self.instance(directory, clock=lambda: now[0], epoch_clock=lambda: now[1])
            handle = instance.prepare("clock", "normal_unrotated", "F")["trial_handle"]
            original = instance._registration
            def delay(handle):
                now[0] += 3
                now[1] += 3
                return original(handle)
            with patch.object(instance, "_registration", side_effect=delay):
                arm = instance.arm(handle)
            self.assertEqual(arm["started_monotonic"], 100)
            self.assertEqual(arm["started_epoch"], 1000)
            self.assertEqual(arm["deadline_monotonic"], 220)
            self.assertEqual(arm["deadline_epoch"], 1120)
            before = (instance.root / "trials" / handle / "arm.json").read_bytes()
            with self.assertRaises(FileExistsError):
                instance.arm(handle)
            self.assertEqual((instance.root / "trials" / handle / "arm.json").read_bytes(), before)

    def test_expired_action_refused_and_unknown_cost_never_resumed(self):
        now = [100.0, 1000.0]
        with temporary_workspace() as directory:
            instance = self.instance(directory, clock=lambda: now[0], epoch_clock=lambda: now[1])
            handle, trial = self.prepared(instance)
            with patch.object(runtime.domain, "verify_case", side_effect=RuntimeError("Unknown invocation cost")):
                with self.assertRaises(RuntimeError):
                    instance.action(handle, "verify_input")
            rows = runtime._journal(trial / "budget.jsonl")
            self.assertEqual(rows[-1]["event"], "action_reserved")
            self.assertEqual(rows[-1]["record"]["reserved_cost"], 1)
            with self.assertRaisesRegex(ValueError, "terminal"):
                instance.action(handle, "inspect_input")
            self.assertTrue((trial / "failure.json").exists())
            self.assertFalse((trial / "completion.json").exists())
        with temporary_workspace() as directory:
            now[:] = [100.0, 1000.0]
            instance = self.instance(directory, clock=lambda: now[0], epoch_clock=lambda: now[1])
            handle, trial = self.prepared(instance)
            now[:] = [220.0, 1120.0]
            with patch.object(runtime.domain, "verify_case") as verify:
                with self.assertRaisesRegex(runtime.BudgetError, "deadline expired"):
                    instance.action(handle, "verify_input")
            verify.assert_not_called()
            self.assertFalse((trial / "completion.json").exists())

    def test_late_known_cost_is_recorded_without_extending_deadline(self):
        now = [100.0, 1000.0]
        with temporary_workspace() as directory:
            instance = self.instance(directory, clock=lambda: now[0], epoch_clock=lambda: now[1])
            handle, trial = self.prepared(instance)
            original = runtime.domain.verify_case
            def late(*args):
                result = original(*args)
                now[:] = [221.0, 1121.0]
                return result
            with patch.object(runtime.domain, "verify_case", side_effect=late):
                with self.assertRaisesRegex(runtime.BudgetError, "deadline expired"):
                    instance.action(handle, "verify_input")
            rows = runtime._journal(trial / "budget.jsonl")
            self.assertEqual(rows[-1]["event"], "action_closed")
            self.assertEqual(rows[-1]["record"]["actual_cost"], 1)
            self.assertEqual(rows[-1]["record"]["used_domain_invocations"], 1)
            self.assertEqual(runtime.read(trial / "arm.json")["deadline_epoch"], 1120)
            self.assertFalse((trial / "completion.json").exists())

    def test_repeat_action_does_not_get_another_call_or_modify_original_budget(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance)
            instance.action(handle, "verify_input")
            before = (trial / "budget.jsonl").read_bytes()
            with patch.object(runtime.domain, "verify_case") as verify:
                with self.assertRaisesRegex(ValueError, "once"):
                    instance.action(handle, "verify_input")
            verify.assert_not_called()
            self.assertEqual((trial / "budget.jsonl").read_bytes(), before)

    def test_unknown_handle_path_and_report_arguments_are_refused(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            for handle in ("../case", "normal_unrotated", "cmp_" + "A" * 32):
                with self.assertRaises(ValueError):
                    instance.execute({"trial_handle": handle, "action": "inspect_input"})
            for arguments in ({"trial_handle": "cmp_" + "a" * 32, "action": "shell"},
                              {"trial_handle": "cmp_" + "a" * 32, "action": "inspect_input", "report": {}},
                              {"trial_handle": "cmp_" + "a" * 32, "action": "publish_report"}):
                with self.assertRaises(ValueError):
                    instance.execute(arguments)
            self.assertFalse(instance.root.exists())

    def test_journal_truncation_or_append_stops_before_a_second_domain_call(self):
        with temporary_workspace() as directory:
            instance = self.instance(directory)
            handle, trial = self.prepared(instance)
            instance.action(handle, "verify_input")
            with (trial / "budget.jsonl").open("ab") as stream:
                stream.write(b'{"unknown":"cost"}\n')
            with patch.object(runtime.domain, "repair_case") as repair:
                with self.assertRaises(runtime.BudgetError):
                    instance.action(handle, "repair_copy")
            repair.assert_not_called()
            self.assertFalse((trial / "completion.json").exists())


if __name__ == "__main__":
    unittest.main()
