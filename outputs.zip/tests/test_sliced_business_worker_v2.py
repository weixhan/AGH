"""Dedicated business worker oracles: fake backend only, no GPU/model imports.

The shared coordinator/request boundary is replaced only in these isolated
tests. Its production contracts and independent verifier have separate suites.
The fixed worker fault, actual journal, immutable checkpoints and crop mapping
remain real. These tests never certify real two-image detection recovery.
"""
from copy import deepcopy
import inspect
import json
from pathlib import Path
import shutil
import sys
import time
from types import ModuleType
import unittest
from unittest.mock import Mock, patch

import cv2
import numpy as np

from defect_researcher import sliced_business_worker_v2 as worker
from defect_researcher import sliced_journal as journal
from defect_researcher.audit import _sha256
from test_config import temporary_workspace


def empty_budget():
    return {"schema_version": 1, "task_started_epoch": time.time(), "task_started_at": "fixture-start",
            "inference_started_epoch": None, "inference_started_at": None,
            "inference_finished_epoch": None, "inference_finished_at": None,
            "formal_attempts": [], "warmup_attempts": [], "formal_calls": 0, "warmup_calls": 0,
            "successful_observations": 0, "gpu_seconds": 0., "task_wall_seconds": 0.,
            "inference_wall_seconds": 0., "resumable": True, "resume_chain": [], "wall_segments": []}


def environment():
    return {"actual_predictor_options": deepcopy(worker.EXPECTED_PREDICTOR_OPTIONS),
            "actual_input_dtype": "torch.float32", "model_parameters_dtype": "torch.float32",
            "actual_input_device": "cuda:0", "actual_predictor_device": "cuda:0",
            "actual_predictor_fp16": False, "tf32_matmul": False, "tf32_cudnn": False,
            "cudnn_benchmark": False, "cudnn_deterministic": True,
            "actual_predictor_imgsz": [640, 640], "fixture_dependency": "fake-only", "peak_allocated_bytes": 1}


class FakeBackend:
    def __init__(self, request, calls, *, timing=None, mutate=None, error=None):
        self.request, self.calls, self.mutate, self.error = request, calls, mutate, error
        self.timing = {"elapsed_seconds": .003, "gpu_seconds": .002} if timing is None else timing
        self.last_timing, self.closed = None, False

    def predict(self, source, shape):
        if isinstance(source, str):
            image_id, pass_id = Path(source).stem, 0
        else:
            image_id = self.request["records"][int(source[0, 0, 2])]["image_id"]
            x = {0: 0, 2: 512, 4: 1024, 5: 1280}[int(source[0, 0, 0])]
            y = {0: 0, 185: 440}[int(source[0, 0, 1])]
            pass_id = 1 + [0, 440].index(y) * 4 + [0, 512, 1024, 1280].index(x)
        self.calls.append((self.request["arm"], image_id, pass_id))
        self.last_timing = deepcopy(self.timing)
        value = {"local_predictions": [{"class_id": 4, "confidence": .75, "xyxy": [1., 2., 11., 12.]}],
                 "effective_options": deepcopy(worker.EXPECTED_PREDICTOR_OPTIONS), "orig_shape": list(shape),
                 "device": "cuda:0", "precision": "FP32", "actual_input_dtype": "torch.float32",
                 "actual_input_device": "cuda:0", "model_parameters_dtype": "torch.float32",
                 "ultralytics_speed_ms": {"inference": 1.}}
        if self.mutate:
            self.mutate(value, image_id, pass_id)
        if self.error and pass_id == 2:
            raise self.error
        return value

    def environment(self, initial=False):
        return {**deepcopy(self.request["reference_environment"]),
                "actual_input_dtype": "torch.float32", "actual_input_device": "cuda:0"}

    def close(self):
        self.closed = True


class SharedState:
    """Explicit fake coordinator; preserves one ledger across three test arms."""
    def __init__(self):
        self.started, self.finished = [], []
        self.open = None
        self.gpu_seconds = 0.
        self.max_calls, self.max_gpu, self.expired = 40, 60., False
        self.unknown = False

    def module(self):
        state = self
        module = ModuleType("defect_researcher.sliced_business_recovery_v2")
        module.validate_worker_request = Mock()
        module.recover_stopped_worker = Mock(side_effect=AssertionError("Normal fixture publication must not fail"))

        class SharedExperimentLedger:
            def __init__(self, request):
                self.request = request

            def check(self):
                if state.open is not None or state.unknown:
                    raise RuntimeError("Shared unfinished or unknown cost")
                if state.expired:
                    raise TimeoutError("Shared original deadline exhausted")
                if len(state.started) >= state.max_calls or state.gpu_seconds >= state.max_gpu:
                    raise RuntimeError("Shared prediction budget exhausted")

            def before_call(self, kind, image_id, pass_id, local_call_index):
                self.check()
                row = {"arm": self.request["arm"], "kind": kind, "image_id": image_id,
                       "pass_id": pass_id, "local_call_index": local_call_index}
                state.started.append(row)
                state.open = len(state.started)
                return state.open

            def finish_call(self, index, attempt):
                if index != state.open:
                    raise AssertionError("One active shared attempt expected")
                state.finished.append({"shared_call_index": index, **deepcopy(attempt)})
                state.open = None
                gpu, elapsed = attempt["gpu_seconds"], attempt["elapsed_seconds"]
                if gpu is None or elapsed is None:
                    state.unknown = True
                    raise RuntimeError("Shared unknown device cost refuses recovery")
                state.gpu_seconds += gpu
                if state.gpu_seconds > state.max_gpu:
                    raise RuntimeError("Shared GPU budget exceeded after durable finish")

        module.SharedExperimentLedger = SharedExperimentLedger
        return module


def prepare(root):
    path = Path(worker.__file__).resolve().parents[1] / "fixtures" / "sliced_business_protocol_v2.json"
    protocol = json.loads(path.read_text(encoding="utf-8"))
    protocol["weight_sha256"] = "2" * 64
    records, hashes = [], {}
    for image_index, image_id in enumerate(protocol["image_ids"]):
        image = np.zeros((1080, 1920, 3), dtype=np.uint8)
        image[:, :, 0] = np.arange(1920, dtype=np.int64)[None, :] % 255
        image[:, :, 1] = np.arange(1080, dtype=np.int64)[:, None] % 255
        image[:, :, 2] = image_index
        image_path = root / f"{image_id}.png"
        if not cv2.imwrite(str(image_path), image):
            raise AssertionError("Fake image fixture write failed")
        hashes[image_id] = _sha256(image_path)
        records.append({"image_id": image_id, "image_path": str(image_path), "width": 1920,
                        "height": 1080, "split": "val", "ground_truth": []})
    base = {"experiment_directory": str(root), "experiment_id": root.name, "protocol": protocol,
            "protocol_sha256": "1" * 64, "scientific_inputs_sha256": "3" * 64,
            "execution_source_sha256": "4" * 64, "input_manifest_sha256": "5" * 64,
            "implementation_freeze_sha256": "6" * 64, "records": records,
            "weights_path": str(root / "fake-never-loaded.pt"), "image_sha256": hashes,
            "reference_environment": environment(), "resume_environment": None,
            "task_monotonic_elapsed_before_worker": 0., "execution_io_version": 2, "tool": worker.TOOL}
    return base


def fresh(base, arm):
    directory = Path(base["experiment_directory"]) / arm
    directory.mkdir()
    worker._write(directory / "budget.json", empty_budget())
    worker._write(directory / "checkpoint_index.json", {"schema_version": 1, "checkpoints": []})
    return {**deepcopy(base), "arm": arm, "directory": str(directory)}


def copied_resume(base):
    source, destination = Path(base["experiment_directory"]) / "fault", Path(base["experiment_directory"]) / "resume"
    destination.mkdir()
    for name in ("budget.json", "checkpoint_index.json", journal.JOURNAL_FILE, "environment.json", worker.FAULT_FILE):
        shutil.copyfile(source / name, destination / name)
    shutil.copytree(source / "checkpoints", destination / "checkpoints")
    budget = worker._read(destination / "budget.json")
    budget["resume_chain"].append({"task_id": source.name,
        "failure_sha256": _sha256(source / "failure.json"),
        "budget_sha256": _sha256(source / "budget.json"),
        "checkpoint_index_sha256": _sha256(source / "checkpoint_index.json"),
        "journal_head_sha256": budget["journal_sha256"],
        "journal_file_sha256": _sha256(source / journal.JOURNAL_FILE), "copied_observations": 2})
    worker._write(destination / "budget.json", budget)
    return {**deepcopy(base), "arm": "resume", "directory": str(destination),
            "resume_environment": worker._read(source / "environment.json")}


class BusinessWorkerTests(unittest.TestCase):
    def run_fake(self, request, module, calls, **changes):
        constructed = []
        def factory(bound):
            value = FakeBackend(bound, calls, **changes)
            constructed.append(value)
            return value
        with patch.dict(sys.modules, {module.__name__: module}):
            receipt = worker._execute(request, backend_factory=factory)
        self.assertTrue(all(value.closed for value in constructed))
        if receipt["status"] == "failed":
            # The test coordinator preserves a separate failed-arm receipt;
            # the worker itself never rewrites an original failure as success.
            worker._write(Path(request["directory"]) / "failure.json",
                          {"status": "failed", "fixture_only": True, "error": receipt["error"]})
        return receipt

    def test_control_fault_resume_exact_39_calls_and_two_cached_steps(self):
        with temporary_workspace() as root:
            base, state, calls = prepare(root), SharedState(), []
            module = state.module()
            control = self.run_fake(fresh(base, "control"), module, calls)
            fault_request = fresh(base, "fault")
            fault = self.run_fake(fault_request, module, calls)
            closed = root / "fault"
            before = {str(path.relative_to(closed)): path.read_bytes() for path in closed.rglob("*") if path.is_file()}
            resumed = self.run_fake(copied_resume(base), module, calls)
            self.assertEqual(control["status"], "completed", control)
            self.assertEqual(fault["status"], "failed", fault)
            self.assertEqual(fault["error"], {"type": "InjectedBusinessFault", "message": worker.FAULT_ERROR})
            self.assertTrue(fault["resumable"])
            self.assertEqual(fault["observations"], 2)
            self.assertEqual(resumed["status"], "completed", resumed)
            self.assertTrue(resumed["fault_consumed"])
            self.assertFalse(control["real_detector_used"] or fault["real_detector_used"] or resumed["real_detector_used"])
            self.assertEqual(len(calls), 39)
            self.assertEqual(len(state.started), 39)
            self.assertEqual(len(state.finished), 39)
            self.assertAlmostEqual(state.gpu_seconds, .078)
            actual_resume = [(image_id, pass_id) for arm, image_id, pass_id in calls if arm == "resume"]
            self.assertEqual(actual_resume, [(base["records"][0]["image_id"], step) for step in range(2, 9)]
                             + [(base["records"][1]["image_id"], step) for step in range(9)])
            self.assertEqual(sum(row["kind"] == "warmup" for row in state.started), 2)
            self.assertFalse(any(row["arm"] == "resume" and row["kind"] == "warmup" for row in state.started))
            self.assertEqual({str(path.relative_to(closed)): path.read_bytes() for path in closed.rglob("*") if path.is_file()}, before)
            budget = worker._read(root / "resume" / "budget.json")
            self.assertEqual((budget["formal_calls"], budget["warmup_calls"], budget["successful_observations"]), (19, 1, 18))
            self.assertEqual(budget["task_started_epoch"], worker._read(closed / "budget.json")["task_started_epoch"])
            self.assertEqual(budget["inference_started_epoch"], worker._read(closed / "budget.json")["inference_started_epoch"])
            self.assertFalse((root / "completion.json").exists())

    def test_fault_raw_return_and_known_timing_bind_the_one_failed_call(self):
        with temporary_workspace() as root:
            base, state, calls = prepare(root), SharedState(), []
            result = self.run_fake(fresh(base, "fault"), state.module(), calls)
            self.assertEqual(result["status"], "failed")
            fault = worker._read(root / "fault" / worker.FAULT_FILE)
            budget = worker._read(root / "fault" / "budget.json")
            failed = budget["formal_attempts"][-1]
            self.assertEqual(fault["output_sha256"], worker._canonical(fault["prediction_output"]))
            self.assertEqual(fault["timing"], {"elapsed_seconds": failed["elapsed_seconds"], "gpu_seconds": failed["gpu_seconds"]})
            self.assertEqual(fault["call_index"], 3)
            self.assertEqual(fault["shared_call_index"], 4)
            self.assertEqual(fault["fault_rule_sha256"], worker._canonical(worker.FAULT_RULE))
            self.assertIsNone(fault["prediction_output"]["effective_options"]["nms"])
            self.assertFalse((root / "fault" / "checkpoints" / "0000-2.json").exists())
            identity = {key: base[key] for key in ("protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256")}
            identity["weight_sha256"] = base["protocol"]["weight_sha256"]
            loaded = journal.load_journal(root / "fault", base["protocol"], identity, require_resumable=True)
            self.assertEqual(loaded.status, "failed")
            self.assertEqual(len(loaded.checkpoint_index["checkpoints"]), 2)

    def test_unknown_timing_failure_does_not_publish_a_fixed_fault_or_resume(self):
        for timing in ({"elapsed_seconds": .003, "gpu_seconds": None},
                       {"elapsed_seconds": None, "gpu_seconds": .002}):
            with self.subTest(timing=timing), temporary_workspace() as root:
                base, state, calls = prepare(root), SharedState(), []
                result = self.run_fake(fresh(base, "fault"), state.module(), calls, timing=timing)
                self.assertEqual(result["status"], "failed")
                self.assertFalse(result["resumable"])
                self.assertFalse((root / "fault" / worker.FAULT_FILE).exists())
                self.assertEqual(len(calls), 1)
                self.assertEqual(len(state.finished), 1)
                self.assertTrue(state.unknown)

    def test_fault_boundary_requires_exact_valid_timing_before_writing(self):
        with temporary_workspace() as root:
            base = fresh(prepare(root), "fault")
            for changed in ({}, {"elapsed_seconds": None, "gpu_seconds": 0.},
                            {"elapsed_seconds": .01, "gpu_seconds": float("nan")},
                            {"elapsed_seconds": True, "gpu_seconds": .1},
                            {"elapsed_seconds": .1, "gpu_seconds": -1.},
                            {"elapsed_seconds": .1, "gpu_seconds": .1, "extra": 0}):
                with self.subTest(timing=changed), self.assertRaises(ValueError):
                    worker._inject_fixed_fault(base, {}, {"image_id": worker.FAULT_RULE["image_id"], "pass_id": 2, "call_index": 3}, changed, 4,
                                               actual_environment={})
            self.assertFalse((Path(base["directory"]) / worker.FAULT_FILE).exists())

    def test_historical_reference_missing_input_dtype_device_uses_current_backend_evidence(self):
        with temporary_workspace() as root:
            request, state, calls = fresh(prepare(root), "fault"), SharedState(), []
            request["reference_environment"].pop("actual_input_dtype")
            request["reference_environment"].pop("actual_input_device")
            before = deepcopy(request["reference_environment"])
            receipt = self.run_fake(request, state.module(), calls)
            self.assertEqual(receipt["error"]["type"], "InjectedBusinessFault", receipt)
            self.assertTrue(receipt["resumable"])
            self.assertEqual(receipt["observations"], 2)
            self.assertEqual(len(calls), 4)
            self.assertEqual(request["reference_environment"], before)
            fault = worker._read(Path(request["directory"]) / worker.FAULT_FILE)
            self.assertEqual(fault["prediction_output"]["actual_input_dtype"], "torch.float32")
            self.assertEqual(fault["prediction_output"]["actual_input_device"], "cuda:0")

    def test_no_arbitrary_fault_callback_and_no_full_population_request_validator(self):
        source = inspect.getsource(worker)
        self.assertEqual(list(inspect.signature(worker._execute).parameters), ["request", "backend_factory"])
        self.assertNotIn("from .sliced_task_v3 import validate_worker_request", source)
        self.assertNotIn("fault_callback", source)
        self.assertNotIn("validation_callback", source)
        self.assertIn("from .sliced_business_recovery_v2 import validate_worker_request", source)
        self.assertEqual(worker.FAULT_RULE["pass_index"], 2)

    def test_request_rejection_is_before_backend_or_shared_constructor(self):
        module = SharedState().module()
        module.validate_worker_request.side_effect = ValueError("changed source or protocol")
        constructor = Mock()
        module.SharedExperimentLedger = constructor
        factory = Mock()
        with patch.dict(sys.modules, {module.__name__: module}), self.assertRaisesRegex(ValueError, "changed source"):
            worker._execute({"directory": "not-created"}, backend_factory=factory)
        factory.assert_not_called()
        constructor.assert_not_called()

    def test_shared_open_gpu_and_deadline_exhaustion_reject_before_fake_predict(self):
        for variation in ("open", "unknown", "gpu", "calls", "deadline"):
            with self.subTest(variation=variation), temporary_workspace() as root:
                request, state = fresh(prepare(root), "control"), SharedState()
                if variation == "open":
                    state.open = 1
                elif variation == "unknown":
                    state.unknown = True
                elif variation == "gpu":
                    state.gpu_seconds = 60.
                elif variation == "calls":
                    state.started = [{}] * 40
                else:
                    state.expired = True
                factory = Mock()
                with patch.dict(sys.modules, {state.module().__name__: state.module()}), self.assertRaises((RuntimeError, TimeoutError)):
                    worker._execute(request, backend_factory=factory)
                factory.assert_not_called()
                self.assertFalse((Path(request["directory"]) / journal.JOURNAL_FILE).exists())

    def test_saved_fault_rule_output_timing_and_identity_tamper_refuse_before_resume_predict(self):
        mutations = {
            "boundary": lambda fault: fault.update(boundary="after_passed"),
            "rule": lambda fault: fault.update(fault_rule_sha256="a" * 64),
            "output": lambda fault: fault["prediction_output"].update(local_predictions=[]),
            "timing": lambda fault: fault["timing"].update(gpu_seconds=.2),
            "source": lambda fault: fault.update(execution_source_sha256="a" * 64),
            "arm": lambda fault: fault.update(arm="control"),
            "call": lambda fault: fault.update(call_index=3.),
            "shared": lambda fault: fault.update(shared_call_index=True),
        }
        for name, mutation in mutations.items():
            with self.subTest(mutation=name), temporary_workspace() as root:
                base, state, calls = prepare(root), SharedState(), []
                module = state.module()
                self.run_fake(fresh(base, "fault"), module, calls)
                request = copied_resume(base)
                path = Path(request["directory"]) / worker.FAULT_FILE
                fault = worker._read(path)
                mutation(fault)
                worker._write(path, fault)
                factory = Mock()
                with patch.dict(sys.modules, {module.__name__: module}), self.assertRaises(ValueError):
                    worker._execute(request, backend_factory=factory)
                factory.assert_not_called()
                self.assertEqual(len(calls), 4)

    def test_resume_without_saved_fault_and_cross_arm_import_refuse_before_predict(self):
        with temporary_workspace() as root:
            base, state, calls = prepare(root), SharedState(), []
            module = state.module()
            self.run_fake(fresh(base, "fault"), module, calls)
            request = copied_resume(base)
            Path(request["directory"], worker.FAULT_FILE).unlink()
            factory = Mock()
            with patch.dict(sys.modules, {module.__name__: module}), self.assertRaisesRegex(ValueError, "durable fixed fault"):
                worker._execute(request, backend_factory=factory)
            factory.assert_not_called()
            copied = {**deepcopy(base), "arm": "control", "directory": str(root / "fault")}
            with patch.dict(sys.modules, {module.__name__: module}), self.assertRaisesRegex(ValueError, "Fresh arms"):
                worker._execute(copied, backend_factory=factory)
            factory.assert_not_called()

    def test_ordinary_error_does_not_gain_an_injected_fault_record(self):
        with temporary_workspace() as root:
            base, state, calls = prepare(root), SharedState(), []
            receipt = self.run_fake(fresh(base, "fault"), state.module(), calls, error=MemoryError("fake backend failure"))
            self.assertEqual(receipt["status"], "failed")
            self.assertEqual(receipt["error"]["type"], "MemoryError")
            self.assertFalse((root / "fault" / worker.FAULT_FILE).exists())
            self.assertEqual(len(calls), 4)

    def test_wrong_nms_refuses_before_backend_factory(self):
        for changed in (False, True, "None", 0, "missing"):
            with self.subTest(nms=changed), temporary_workspace() as root:
                request, state = fresh(prepare(root), "control"), SharedState()
                if changed == "missing":
                    del request["reference_environment"]["actual_predictor_options"]["nms"]
                else:
                    request["reference_environment"]["actual_predictor_options"]["nms"] = changed
                factory = Mock()
                module = state.module()
                with patch.dict(sys.modules, {module.__name__: module}), self.assertRaisesRegex(ValueError, "(nms|missing)"):
                    worker._execute(request, backend_factory=factory)
                factory.assert_not_called()

    def test_shared_gpu_overrun_retains_closed_actual_cost_and_stops(self):
        with temporary_workspace() as root:
            request, state, calls = fresh(prepare(root), "control"), SharedState(), []
            state.max_gpu = .001
            receipt = self.run_fake(request, state.module(), calls)
            self.assertEqual(receipt["status"], "failed")
            self.assertEqual(len(calls), 1)
            self.assertEqual(len(state.finished), 1)
            self.assertEqual(state.gpu_seconds, .002)
            self.assertIsNone(state.open)
            budget = worker._read(Path(request["directory"]) / "budget.json")
            self.assertEqual(budget["gpu_seconds"], .002)

    def test_local_finish_io_failure_retains_shared_known_cost_without_retry_or_observation(self):
        with temporary_workspace() as root:
            request, state, calls = fresh(prepare(root), "control"), SharedState(), []
            module = state.module()
            def recover(directory, saved_request, protocol):
                identity = {key: saved_request[key] for key in (
                    "protocol_sha256", "scientific_inputs_sha256", "execution_source_sha256")}
                identity["weight_sha256"] = protocol["weight_sha256"]
                replay = journal.load_journal(directory, protocol, identity,
                                             check_published=False, inspection_only_allow_truncated_tail=True)
                self.assertFalse(replay.budget["resumable"])
                self.assertIsNone(replay.budget["warmup_attempts"][0]["gpu_seconds"])
                worker._write(Path(directory) / "budget.json", replay.budget)
                worker._write(Path(directory) / "checkpoint_index.json", replay.checkpoint_index)
            module.recover_stopped_worker.side_effect = recover
            with patch.object(journal.PassJournal, "finished", side_effect=OSError("fixed local journal write failure")):
                receipt = self.run_fake(request, module, calls)
            self.assertEqual(receipt["status"], "failed")
            self.assertEqual(receipt["error"]["type"], "OSError")
            self.assertFalse(receipt["resumable"])
            self.assertEqual(receipt["observations"], 0)
            self.assertEqual(len(calls), 1)
            self.assertEqual(len(state.started), 1)
            self.assertEqual(len(state.finished), 1)
            self.assertEqual(state.finished[0]["gpu_seconds"], .002)
            self.assertEqual(state.gpu_seconds, .002)
            self.assertIsNone(state.open)
            self.assertEqual(list((Path(request["directory"]) / "checkpoints").glob("*.json")), [])
            module.recover_stopped_worker.assert_called_once()


if __name__ == "__main__":
    unittest.main()
