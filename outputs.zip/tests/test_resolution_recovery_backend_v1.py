"""Fake dependency checks for the reservation backend; no torch/GPU import."""
import ast
from contextlib import nullcontext
from copy import deepcopy
from functools import lru_cache
import importlib.metadata
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from defect_researcher import resolution_recovery_backend_v1 as backend
from defect_researcher.detection_metrics import score_detections
from test_config import temporary_workspace


@lru_cache(maxsize=1)
def installed_precision_normalizer():
    """Use the installed argument normalizer without importing its GPU modules."""
    source = Path(importlib.metadata.distribution("ultralytics").locate_file("ultralytics/cfg/__init__.py"))
    tree = ast.parse(source.read_text(encoding="utf-8"))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                    and node.name == "_handle_deprecation")
    namespace = {"deprecation_warn": lambda *args: None}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), "exec"), namespace)
    return namespace["_handle_deprecation"]


class Dtype:
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return self.text


class Version(str):
    pass


class FakeTensor:
    def __init__(self, value):
        self.value = value

    def cpu(self):
        return self

    def tolist(self):
        return deepcopy(self.value)


class FakeCuda:
    def __init__(self):
        self.available = True
        self.sync_calls = 0
        self.event_records = 0
        self.empty_calls = 0
        self.fail_sync_at = None
        self.bad_cost = False
        self.current_device_value = 0

    def is_available(self):
        return self.available

    def current_device(self):
        return self.current_device_value

    def synchronize(self):
        self.sync_calls += 1
        if self.sync_calls == self.fail_sync_at:
            raise RuntimeError("fixture CUDA synchronization failed")

    def Event(self, enable_timing):
        parent = self

        class Event:
            def record(self):
                parent.event_records += 1

            def elapsed_time(self, other):
                return float("nan") if parent.bad_cost else 1.0

        return Event()

    def reset_peak_memory_stats(self):
        pass

    def max_memory_allocated(self):
        return 100

    def get_device_name(self, index):
        return "fixture-GPU"

    def get_device_properties(self, index):
        return SimpleNamespace(total_memory=1000)

    def empty_cache(self):
        self.empty_calls += 1


class FakeTorch:
    def __init__(self):
        self.float32 = Dtype("torch.float32")
        self.float16 = Dtype("torch.float16")
        self.cuda = FakeCuda()
        self.__version__ = Version("fixture-torch")
        self.version = SimpleNamespace(cuda="fixture-CUDA")
        self.backends = SimpleNamespace(
            cuda=SimpleNamespace(matmul=SimpleNamespace(allow_tf32=True)),
            cudnn=SimpleNamespace(allow_tf32=True, benchmark=True, deterministic=False,
                                  version=lambda: 9000))

    def inference_mode(self):
        return nullcontext()

    def autocast(self, device_type, enabled):
        if device_type != "cuda" or enabled is not False:
            raise AssertionError("Autocast changed")
        return nullcontext()


class FakeNetwork:
    def __init__(self, torch):
        self.parameter = SimpleNamespace(dtype=torch.float32)
        self.hook = None
        self.removed = False

    def float(self):
        return self

    def parameters(self):
        yield self.parameter

    def register_forward_pre_hook(self, hook):
        self.hook = hook
        parent = self

        class Handle:
            def remove(self):
                parent.removed = True
                parent.hook = None

        return Handle()


class FakeModel:
    def __init__(self, torch, trace):
        self.torch, self.trace = torch, trace
        self.model = FakeNetwork(torch)
        self.names = {key - 1: value for key, value in backend.CATEGORIES.items()}
        self.predictor = None
        self.calls = 0
        self.overrides = {}
        self.input_dtype = torch.float32
        self.input_device = "cuda:0"
        self.predictor_device = "cuda:0"
        self.fp16 = False
        self.imgsz_override = None
        self.throw = None
        self.source_override = None
        self.shape_override = None
        self.class_value = 0.0
        self.confidence = .5
        self.box = [1., 2., 11., 12.]
        self.after_predict = None
        self.normalize_options = installed_precision_normalizer()
        self.raw_options = None

    def predict(self, source, **options):
        self.trace.append("predict")
        self.calls += 1
        if self.throw:
            raise self.throw
        self.raw_options = deepcopy(options)
        normalized = self.normalize_options(deepcopy(options))
        self.predictor = SimpleNamespace(
            args=SimpleNamespace(**{**normalized, **self.overrides}),
            model=SimpleNamespace(fp16=self.fp16, device=self.predictor_device),
            imgsz=self.imgsz_override or [options["imgsz"], options["imgsz"]])
        self.model.hook(self.model, [SimpleNamespace(dtype=self.input_dtype, device=self.input_device)])
        value = SimpleNamespace(path=self.source_override or source,
                                orig_shape=self.shape_override or (80, 100),
                                boxes=SimpleNamespace(xyxy=FakeTensor([self.box]),
                                                      conf=FakeTensor([self.confidence]),
                                                      cls=FakeTensor([self.class_value])),
                                speed={"preprocess": 0., "inference": .1, "postprocess": 0.})
        if self.after_predict:
            self.after_predict(self)
        return [value]


class Clock:
    def __init__(self):
        self.current = 0.

    def __call__(self):
        self.current += .01
        return self.current


class Ledger:
    def __init__(self, trace):
        self.trace = trace
        self.reservations = []
        self.receipts = []
        self.checks = 0
        self.deny_reserve = False
        self.deny_check_at = None
        self.pending = None
        self.after_closed = None

    def reserve(self, kind, step_id, image_id, imgsz):
        self.trace.append("reserve")
        if self.deny_reserve:
            raise RuntimeError("fixture shared call budget exhausted")
        if self.pending is not None:
            raise AssertionError("Unclosed ticket")
        ticket = len(self.reservations) + 1
        self.reservations.append((ticket, kind, step_id, image_id, imgsz))
        self.pending = ticket
        return ticket

    def check(self):
        self.trace.append("check")
        self.checks += 1
        if self.checks == self.deny_check_at:
            raise RuntimeError("fixture original deadline exhausted")

    def closed(self, ticket, status, elapsed_seconds, gpu_seconds, **details):
        self.trace.append("closed")
        if ticket != self.pending:
            raise AssertionError("Receipt did not match reservation")
        self.receipts.append({"ticket": ticket, "status": status, "elapsed_seconds": elapsed_seconds,
                              "gpu_seconds": gpu_seconds, **details})
        self.pending = None
        if self.after_closed:
            self.after_closed()


def records():
    return [{"image_id": f"fixture_{index:04d}", "image_path": f"E:/fixture/image_{index:04d}.png",
             "source_path": f"E:/fixture/raw_{index:04d}.png", "label_path": f"E:/fixture/label_{index:04d}.txt",
             "metadata_path": f"E:/fixture/meta_{index:04d}.json", "width": 100, "height": 80,
             "split": "val", "ground_truth": []} for index in range(640)]


class RecoveryBackendTests(unittest.TestCase):
    def setUp(self):
        self.trace = []
        self.torch = FakeTorch()
        self.model = FakeModel(self.torch, self.trace)
        self.ledger = Ledger(self.trace)
        self.clock = Clock()
        self.protocol = deepcopy(backend.FROZEN_FIELDS)
        self.deps = backend.TestDependencies(self.torch, self.factory, perf_counter=self.clock)
        self.factory_calls = []

    def factory(self, weights, task):
        self.factory_calls.append((weights, task))
        return self.model

    def run_group(self, *, imgsz=640, rows=None, protocol=None, deps=None):
        with temporary_workspace() as root:
            return backend.infer_group(records() if rows is None else rows, root / "fixture.pt",
                                       imgsz, self.protocol if protocol is None else protocol, root,
                                       self.ledger, f"fault/eval_{imgsz}",
                                       test_dependencies=self.deps if deps is None else deps)

    def test_complete_640_rows_have_641_reserved_closed_predict_entries_and_score(self):
        output, environment = self.run_group()
        self.assertEqual(len(output), 640)
        self.assertEqual(self.model.calls, 641)
        self.assertEqual(len(self.ledger.reservations), 641)
        self.assertEqual(len(self.ledger.receipts), 641)
        self.assertEqual([row[1] for row in self.ledger.reservations], ["warmup"] + ["formal"] * 640)
        self.assertTrue(all(row["cost_known"] and row["status"] == "passed" for row in self.ledger.receipts))
        for index, value in enumerate(self.trace):
            if value == "predict":
                self.assertEqual(self.trace[index - 2:index], ["reserve", "check"])
                self.assertEqual(self.trace[index + 1], "closed")
        self.assertIs(environment["real_detector_used"], False)
        self.assertIs(environment["fixture_only"], True)
        self.assertEqual(environment["prediction_entry_calls"], 641)
        self.assertIs(type(environment["torch"]), str)
        self.assertEqual(environment["actual_input_dtype"], "torch.float32")
        self.assertIsNone(environment["actual_predictor_options"]["nms"])
        self.assertEqual(score_detections(output, list(backend.CATEGORIES.values()))["counts"]["images"], 640)
        json.dumps(environment, allow_nan=False)
        self.assertTrue(self.model.model.removed)
        self.assertEqual(self.torch.cuda.empty_calls, 1)

    def test_960_only_changes_resolution_and_keeps_actual_square_cuda_fp32(self):
        output, environment = self.run_group(imgsz=960)
        self.assertTrue(all(row["eval_imgsz"] == 960 for row in output))
        self.assertEqual(environment["actual_predictor_imgsz"], [960, 960])
        self.assertEqual(environment["actual_predictor_device"], "cuda:0")
        self.assertEqual(environment["actual_predictor_options"]["batch"], 1)
        self.assertEqual(self.model.calls, 641)

    def test_installed_normalizer_removes_deprecated_half_without_weakening_fp32(self):
        prior = {name: sys.modules.get(name) for name in ("torch", "ultralytics")}
        normalize = installed_precision_normalizer()
        self.assertEqual(normalize({"half": False, "quantize": None, "nms": None}),
                         {"quantize": None, "nms": None})
        self.assertEqual(normalize({"half": True})["quantize"], 16)
        output, environment = self.run_group()
        self.assertEqual(len(output), 640)
        self.assertIs(self.model.raw_options["half"], False)
        self.assertIsNone(self.model.raw_options["quantize"])
        self.assertFalse(hasattr(self.model.predictor.args, "half"))
        self.assertNotIn("half", environment["actual_predictor_options"])
        self.assertIsNone(environment["actual_predictor_options"]["quantize"])
        self.assertIs(environment["actual_predictor_fp16"], False)
        self.assertEqual(environment["actual_input_dtype"], "torch.float32")
        self.assertEqual(environment["model_parameters_dtype"], "torch.float32")
        self.assertEqual({name: sys.modules.get(name) for name in prior}, prior)

    def test_invalid_protocol_and_partial_or_duplicate_members_refuse_before_import_or_factory(self):
        for key, changed in (("batch", True), ("precision", "FP16"), ("device", "cpu"),
                             ("prediction_confidence", .25), ("nms", False), ("allow_tf32", True)):
            with self.subTest(field=key), self.assertRaises(ValueError):
                self.run_group(protocol={**self.protocol, key: changed})
        duplicate = records()
        duplicate[-1] = duplicate[0]
        for rows in (records()[:-1], duplicate, list(reversed(records()))):
            with self.assertRaises(ValueError):
                self.run_group(rows=rows)
        self.assertEqual(self.factory_calls, [])
        self.assertEqual(self.model.calls, 0)

    def test_non_fixture_injection_refuses_before_model(self):
        with self.assertRaisesRegex(ValueError, "fixture"):
            self.run_group(deps=backend.TestDependencies(self.torch, self.factory, fixture_only=False))
        self.assertEqual(self.factory_calls, [])

    def test_cuda_unavailable_has_no_cpu_fallback_and_releases_cache(self):
        self.torch.cuda.available = False
        with self.assertRaisesRegex(RuntimeError, "CPU fallback"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)
        self.assertEqual(self.factory_calls, [])
        self.assertEqual(self.torch.cuda.empty_calls, 1)

    def test_cuda_events_cannot_measure_a_different_current_device(self):
        self.torch.cuda.current_device_value = 1
        with self.assertRaisesRegex(ValueError, "current device"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)
        self.assertEqual(self.ledger.reservations, [])
        self.assertEqual(self.torch.cuda.empty_calls, 1)

    def test_budget_refusal_occurs_before_predict_and_finally_releases_model_hook(self):
        self.ledger.deny_reserve = True
        with self.assertRaisesRegex(RuntimeError, "budget"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)
        self.assertEqual(self.ledger.receipts, [])
        self.assertTrue(self.model.model.removed)
        self.assertEqual(self.torch.cuda.empty_calls, 1)

    def test_original_deadline_rechecked_after_reservation_before_actual_predict(self):
        self.ledger.deny_check_at = 2
        with self.assertRaisesRegex(RuntimeError, "deadline"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)
        self.assertEqual(len(self.ledger.reservations), 1)
        self.assertEqual(self.ledger.receipts[0]["status"], "failed")
        self.assertIs(self.ledger.receipts[0]["prediction_entered"], False)
        self.assertTrue(self.model.model.removed)

    def test_runtime_error_has_one_closed_failed_cost_and_never_retries(self):
        self.model.throw = RuntimeError("fixture detector OOM")
        with self.assertRaisesRegex(RuntimeError, "OOM"):
            self.run_group()
        self.assertEqual(self.model.calls, 1)
        self.assertEqual(len(self.ledger.receipts), 1)
        self.assertEqual(self.ledger.receipts[0]["status"], "failed")
        self.assertEqual(self.ledger.receipts[0]["gpu_seconds"], .001)
        self.assertIs(self.ledger.receipts[0]["cost_known"], True)
        self.assertTrue(self.model.model.removed)

    def test_unknown_gpu_cost_is_none_not_zero_and_prevents_output(self):
        self.torch.cuda.fail_sync_at = 2
        with self.assertRaisesRegex(RuntimeError, "unknown"):
            self.run_group()
        self.assertEqual(self.model.calls, 1)
        receipt = self.ledger.receipts[0]
        self.assertIsNone(receipt["gpu_seconds"])
        self.assertIs(receipt["cost_known"], False)
        self.assertEqual(receipt["status"], "failed")
        self.assertEqual(self.torch.cuda.empty_calls, 1)

    def test_nan_cuda_event_time_is_unknown_not_resumable(self):
        self.torch.cuda.bad_cost = True
        with self.assertRaisesRegex(RuntimeError, "unknown"):
            self.run_group()
        self.assertIsNone(self.ledger.receipts[0]["gpu_seconds"])
        self.assertIs(self.ledger.receipts[0]["cost_known"], False)

    def test_exact_none_nms_and_typed_predictor_parameters_reject_drift(self):
        for key, value in (("nms", False), ("nms", 0), ("quantize", False), ("quantize", 16), ("quantize", 8),
                           ("batch", True), ("conf", "0.001"), ("rect", 0)):
            with self.subTest(field=key, value=value):
                self.setUp()
                self.model.overrides[key] = value
                with self.assertRaisesRegex(ValueError, key):
                    self.run_group()
                self.assertEqual(self.model.calls, 1)
                self.assertEqual(self.ledger.receipts[0]["status"], "failed")
                self.assertTrue(self.model.model.removed)

    def test_actual_input_tensor_device_dtype_and_predictor_device_shape_are_checked(self):
        changes = {"input_dtype": self.torch.float16, "input_device": "cpu",
                   "predictor_device": "cpu", "imgsz_override": [960, 960], "fp16": True}
        for key, value in changes.items():
            with self.subTest(field=key):
                self.setUp()
                setattr(self.model, key, self.torch.float16 if key == "input_dtype" else value)
                with self.assertRaises(ValueError):
                    self.run_group()
                self.assertEqual(self.model.calls, 1)
                self.assertEqual(self.ledger.receipts[0]["status"], "failed")

    def test_parameter_dtype_and_class_mapping_refuse_before_predict(self):
        self.model.model.parameter.dtype = self.torch.float16
        with self.assertRaisesRegex(ValueError, "parameters"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)
        self.setUp()
        self.model.names[0] = "changed-class"
        with self.assertRaisesRegex(ValueError, "class mapping"):
            self.run_group()
        self.assertEqual(self.model.calls, 0)

    def test_after_warmup_configuration_drift_refuses_before_next_predict(self):
        self.ledger.after_closed = lambda: setattr(self.model.predictor.args, "nms", False)
        with self.assertRaisesRegex(ValueError, "nms"):
            self.run_group()
        self.assertEqual(self.model.calls, 1)
        self.assertEqual(len(self.ledger.reservations), 1)
        self.assertEqual(self.ledger.receipts[0]["status"], "passed")

    def test_invalid_output_source_shape_class_confidence_and_box_refuse(self):
        changes = {"source_override": "E:/fixture/wrong.png", "shape_override": (10, 10),
                   "class_value": .5, "confidence": float("nan"), "box": [0., 0., 101., 12.]}
        for key, value in changes.items():
            with self.subTest(field=key):
                self.setUp()
                setattr(self.model, key, value)
                with self.assertRaises(ValueError):
                    self.run_group()
                self.assertEqual(self.model.calls, 1)
                self.assertEqual(self.ledger.receipts[0]["status"], "failed")

    def test_environment_restored_on_failure_and_metadata_normalization_is_limited(self):
        with patch.dict(os.environ, {"YOLO_CONFIG_DIR": "previous", "MPLBACKEND": "previous"}):
            self.model.throw = RuntimeError("fixture failure")
            with self.assertRaises(RuntimeError):
                self.run_group()
            self.assertEqual(os.environ["YOLO_CONFIG_DIR"], "previous")
            self.assertEqual(os.environ["MPLBACKEND"], "previous")
        self.setUp()
        self.torch.__version__ = 2.5
        with self.assertRaisesRegex(ValueError, "metadata"):
            self.run_group()
        self.assertEqual(self.factory_calls, [])

    def test_fake_dependency_checks_did_not_import_actual_torch_or_ultralytics(self):
        # Also works in a broader suite whose unrelated metadata tests may
        # already have imported torch. This backend may not import either.
        prior = {name: sys.modules.get(name) for name in ("torch", "ultralytics")}
        real_import = __import__

        def guarded(name, *args, **kwargs):
            if name.split(".")[0] in {"torch", "ultralytics"}:
                raise AssertionError("Actual detector dependency import forbidden in fake test")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=guarded):
            self.run_group()
        self.assertEqual({name: sys.modules.get(name) for name in prior}, prior)


if __name__ == "__main__":
    unittest.main()
