"""CPU-only cold metadata repair proof; no detector/CUDA operations occur.

The actual installed TorchVersion is used. Frozen backend environment capture
is replaced with hand-written metadata, and backend construction/prediction is
never invoked. The failed real V1 trial is preserved and never retried here.
"""
from copy import deepcopy
import inspect
import json
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import torch

from defect_researcher import sliced_business_backend_v2 as backend_v2
from defect_researcher import sliced_task_v3 as frozen_task
from defect_researcher import sliced_worker_v3 as frozen_worker


def saved_environment():
    return {"actual_predictor_options": deepcopy(frozen_worker.EXPECTED_PREDICTOR_OPTIONS),
            "actual_input_dtype": "torch.float32", "model_parameters_dtype": "torch.float32",
            "actual_input_device": "cuda:0", "actual_predictor_device": "cuda:0",
            "actual_predictor_fp16": False, "tf32_matmul": False, "tf32_cudnn": False,
            "cudnn_benchmark": False, "cudnn_deterministic": True,
            "actual_predictor_imgsz": [640, 640], "precision": "FP32", "device": "0",
            "torch": str(torch.__version__), "cuda": "fixture-cuda-version",
            "callable_sources": {"fixed-capture": {"sha256": "a"*64}}, "peak_allocated_bytes": 1}


def cold_backend(kind):
    value = object.__new__(kind)
    value.model = SimpleNamespace(predictor=None, predict=Mock(side_effect=AssertionError("No model operation permitted")))
    return value


class OtherStringSubclass(str):
    pass


class BusinessBackendV2Tests(unittest.TestCase):
    def setUp(self):
        # Importing installed torch is permitted for version diagnosis, while
        # every CUDA API this backend could use must remain uncalled.
        for name in ("synchronize", "is_available", "Event", "reset_peak_memory_stats",
                     "max_memory_allocated", "get_device_name", "get_device_properties", "empty_cache"):
            guard = patch.object(torch.cuda, name, side_effect=AssertionError("CUDA operation forbidden in CPU metadata test"))
            guard.start()
            self.addCleanup(guard.stop)

    def test_actual_installed_torchversion_reproduces_frozen_cold_resume_failure(self):
        self.assertIsInstance(torch.__version__, str)
        self.assertIsNot(type(torch.__version__), str)
        self.assertEqual(type(torch.__version__).__name__, "TorchVersion")
        self.assertEqual(type(torch.__version__).__module__, "torch.torch_version")
        prior = json.loads(json.dumps(saved_environment()))
        current = {"torch": torch.__version__, "peak_allocated_bytes": 0}
        self.assertEqual(current["torch"], prior["torch"])
        self.assertFalse(frozen_task._equal(current["torch"], prior["torch"]))
        backend = cold_backend(frozen_worker.DetectorBackend)
        with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current), \
                self.assertRaisesRegex(ValueError, "changed: torch"):
            frozen_worker._starting_environment(backend, prior)
        backend.model.predict.assert_not_called()

    def test_new_subclass_cold_resume_matches_same_saved_json_version_without_warmup(self):
        prior = json.loads(json.dumps(saved_environment()))
        before = deepcopy(prior)
        current = {"torch": torch.__version__, "model_parameters_dtype": "torch.float32", "peak_allocated_bytes": 0}
        backend = cold_backend(backend_v2.DetectorBackendV2)
        with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current) as capture:
            restored = frozen_worker._starting_environment(backend, prior)
        capture.assert_called_once_with(initial=True)
        self.assertIs(type(restored["torch"]), str)
        self.assertEqual(restored["torch"], str(torch.__version__))
        self.assertEqual(prior, before)
        self.assertIsNone(backend.model.predictor)
        backend.model.predict.assert_not_called()
        frozen_task.validate_inference_controls(restored)

    def test_current_capture_only_torch_metadata_is_normalized_and_source_dict_unchanged(self):
        current = saved_environment()
        current["torch"] = torch.__version__
        current["cuda"] = OtherStringSubclass(current["cuda"])
        current["actual_input_dtype"] = OtherStringSubclass(current["actual_input_dtype"])
        before = dict(current)
        normalized = backend_v2.json_stable_version_metadata(current)
        self.assertIs(type(normalized["torch"]), str)
        self.assertIs(type(normalized["cuda"]), OtherStringSubclass)
        self.assertIs(type(normalized["actual_input_dtype"]), OtherStringSubclass)
        self.assertIs(current["torch"], torch.__version__)
        self.assertEqual(current, before)
        self.assertIs(normalized["actual_predictor_options"], current["actual_predictor_options"])
        self.assertEqual(backend_v2.NORMALIZED_VERSION_FIELDS, frozenset({"torch"}))

    def test_true_version_change_is_rejected_after_representation_normalization(self):
        prior = saved_environment()
        current = {"torch": type(torch.__version__)("0.0.0+changed"), "peak_allocated_bytes": 0}
        backend = cold_backend(backend_v2.DetectorBackendV2)
        with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current), \
                self.assertRaisesRegex(ValueError, "changed: torch"):
            frozen_worker._starting_environment(backend, prior)
        backend.model.predict.assert_not_called()

    def test_non_string_and_missing_torch_metadata_are_not_coerced_to_saved_version(self):
        for version in (None, False, True, 0, 2.5, [], {}):
            with self.subTest(version=version):
                current = {"torch": version}
                self.assertIs(backend_v2.json_stable_version_metadata(current)["torch"], version)
                backend = cold_backend(backend_v2.DetectorBackendV2)
                with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current), \
                        self.assertRaisesRegex(ValueError, "changed: torch"):
                    frozen_worker._starting_environment(backend, saved_environment())
                backend.model.predict.assert_not_called()
        self.assertNotIn("torch", backend_v2.json_stable_version_metadata({}))

    def test_initial_and_final_environment_preserve_one_json_stable_version(self):
        value = cold_backend(backend_v2.DetectorBackendV2)
        current = {"torch": torch.__version__, "actual_predictor_options": deepcopy(frozen_worker.EXPECTED_PREDICTOR_OPTIONS)}
        with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current) as capture:
            initial = value.environment(initial=True)
            final = value.environment()
        self.assertEqual(capture.call_args_list[0].kwargs, {"initial": True})
        self.assertEqual(capture.call_args_list[1].kwargs, {"initial": False})
        self.assertEqual(initial, final)
        self.assertIsNone(final["actual_predictor_options"]["nms"])
        self.assertIs(type(json.loads(json.dumps(final))["torch"]), str)

    def test_nms_non_null_typed_controls_still_refuse_before_cold_model_operation(self):
        for version in (False, True, "None", "null", 0, "missing"):
            with self.subTest(nms=version):
                prior = saved_environment()
                if version == "missing":
                    del prior["actual_predictor_options"]["nms"]
                else:
                    prior["actual_predictor_options"]["nms"] = version
                backend = cold_backend(backend_v2.DetectorBackendV2)
                with patch.object(frozen_worker.DetectorBackend, "environment", return_value={"torch": torch.__version__}), \
                        self.assertRaisesRegex(ValueError, "(nms|missing)"):
                    frozen_worker._starting_environment(backend, prior)
                backend.model.predict.assert_not_called()

    def test_actual_tensor_dtype_device_boolean_and_dependency_drift_remain_rejected(self):
        changes = {"actual_input_dtype": "torch.float16", "actual_input_device": "cpu",
                   "actual_predictor_fp16": True, "tf32_matmul": True, "tf32_cudnn": True,
                   "cudnn_benchmark": True, "model_parameters_dtype": "torch.float16",
                   "actual_predictor_imgsz": [960, 960], "device": "cpu",
                   "callable_sources": {"fixed-capture": {"sha256": "b"*64}},
                   "cuda": OtherStringSubclass("fixture-cuda-version")}
        for key, changed in changes.items():
            with self.subTest(field=key):
                backend = cold_backend(backend_v2.DetectorBackendV2)
                current = {"torch": torch.__version__, key: changed}
                with patch.object(frozen_worker.DetectorBackend, "environment", return_value=current), \
                        self.assertRaisesRegex(ValueError, key):
                    frozen_worker._starting_environment(backend, saved_environment())
                backend.model.predict.assert_not_called()

    def test_normalizer_refuses_non_dictionary_environment_without_creating_defaults(self):
        for value in (None, [], "metadata", False):
            with self.subTest(environment=value), self.assertRaises(ValueError):
                backend_v2.json_stable_version_metadata(value)

    def test_backend_subclass_preserves_all_predictor_methods_and_has_no_trial_router(self):
        self.assertTrue(issubclass(backend_v2.DetectorBackendV2, frozen_worker.DetectorBackend))
        self.assertIs(backend_v2.DetectorBackendV2.predict, frozen_worker.DetectorBackend.predict)
        self.assertIs(backend_v2.DetectorBackendV2.__init__, frozen_worker.DetectorBackend.__init__)
        self.assertIs(backend_v2.DetectorBackendV2.close, frozen_worker.DetectorBackend.close)
        source = inspect.getsource(backend_v2)
        self.assertNotIn("run_experiment", source)
        self.assertNotIn("sliced_business_recovery", source)
        self.assertNotIn("torch.cuda", source)
        self.assertNotIn("validate_worker_request", source)


if __name__ == "__main__":
    unittest.main()
