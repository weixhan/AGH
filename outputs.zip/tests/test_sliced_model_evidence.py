"""Fail closed on forged model scope, masked counts and stale science reviews."""
import copy
import json
from pathlib import Path
import unittest
from test_config import temporary_workspace

from tools.verify_sliced_model_run import (
    START_TOOL, STATUS_TOOL, TOOL, UNKNOWN, check_ledger, check_scientific_binding,
    compact_target, digest, final_compact, official_payload, expected_model_workspace,
)


def fixture():
    task = "1a23456789abcdef0123456789abcdef"
    session = "sliced-session"
    workspace = "E:/project/outputs/agh-sliced-model/workspace"
    baseline = {"mAP50": .41068842396135186, "mAP50_95": .16529868184635887,
                "tp": 231, "fp": 149, "fn": 365, "precision": .6078947368421053,
                "recall": .3875838926174497, "normal_fp_images": 5,
                "normal_image_fp_rate": .02040816326530612, "normal_fp_boxes": 5}
    sliced = {"mAP50": .5, "mAP50_95": .2, "tp": 251, "fp": 160, "fn": 345,
              "precision": 251 / 411, "recall": 251 / 596, "normal_fp_images": 8,
              "normal_image_fp_rate": 8 / 245, "normal_fp_boxes": 10}
    summary = {"slicing_status": "passed", "candidate_status": "stop", "reference_reused": True,
               "input_hashes_unchanged": True, "training_performed": False, "test_inference_performed": False,
               "baseline": baseline, "sliced": sliced,
               "medium": {"gt": 77, "images": 74, "medium_tp_gain": 20, "medium_gain_images": 20,
                          "medium_recovered_gt": 20, "medium_lost_gt": 0},
               "failed_gates": ["normal_fp_images", "normal_fp_rate", "overall_fp"],
               "same_weight": True, "successful_observations": 5760, "formal_calls": 5760,
               "warmup_calls": 1, "precision": "FP32", "device": "0", "train_imgsz": 640,
               "eval_imgsz": 640, "split": "val", "threshold_changed": False}
    disk = {"task_id": task, "status": "completed", "tool": TOOL, "summary": summary,
            "evidence": {"source_task_id": "8d1d6900c7d74c90a29824495684807d"}}
    policy = {"schema_version": 1, "workspace_root": "<workspace>", "qualified_start_tool": START_TOOL,
              "qualified_status_tool": STATUS_TOOL, "max_status_calls": 120}
    origin = "ext:plugin/test-extension"
    rows = [
        {"type": "session/start", "data": {"key": session}},
        {"type": "x/plugin/test-extension/scope-ready", "origin": origin,
         "data": {"session_key": session, "workspace_root": "<workspace>", "mode": "sliced", "policy": policy}},
        {"type": "request/sent", "data": {}},
        {"type": "tool/call", "origin": "model", "data": {"name": START_TOOL, "args": {}, "toolUseId": "start"}},
        {"type": "x/plugin/test-extension/scope-decision", "origin": origin,
         "data": {"session_key": session, "name": START_TOOL, "tool_use_id": "start", "allow": True, "reason": None}},
        {"type": "approval/decided", "data": {"verdict": "allowed-once", "scope": f"tool:{START_TOOL}:execute"}},
        {"type": "tool/result", "sourceEventSeqs": [4], "data": {"toolUseId": "start", "isError": False,
         "content": [{"type": "text", "text": json.dumps({"task_id": task, "status": "running"})}]}},
        {"type": "tool/call", "origin": "model", "data": {"name": STATUS_TOOL, "args": {"task_id": task}, "toolUseId": "poll"}},
        {"type": "x/plugin/test-extension/scope-decision", "origin": origin,
         "data": {"session_key": session, "name": STATUS_TOOL, "tool_use_id": "poll", "allow": True, "reason": None}},
        {"type": "tool/result", "sourceEventSeqs": [8], "data": {"toolUseId": "poll", "isError": False,
         "content": [{"type": "text", "text": json.dumps(disk)}]}},
        {"type": "cost/ledger", "data": {"purpose": "inference", "model": "agnes-3.0-flash", "response": {"status": 200}}},
        {"type": "assistant/message", "data": {"content": [{"type": "text", "text": "执行完成，但候选误报超预算。\n```json\n" + json.dumps(compact_target(disk)) + "\n```"}]}},
        {"type": "turn/end", "data": {"reason": "completed", "lastAssistantSeq": 12}},
    ]
    for seq, row in enumerate(rows, 1):
        row["seq"] = seq
    sdk_ready = copy.deepcopy(rows[1])
    sdk_ready["data"]["workspace_root"] = workspace
    sdk_ready["data"]["policy"]["workspace_root"] = workspace
    runner = {"status": "completed", "cwd": workspace, "session_id": session, "task_id": task, "scope_ready": sdk_ready,
              "calls": [{"seq": r["seq"], "name": r["data"]["name"], "args": copy.deepcopy(r["data"]["args"]), "origin": r["origin"]}
                        for r in rows if r["type"] == "tool/call"],
              "polls": [{"seq": 7, "task_id": task, "status": "running"},
                        {"seq": 10, "task_id": task, "status": "completed", "summary": copy.deepcopy(summary), "evidence": copy.deepcopy(disk["evidence"])}],
              "permissions": [{"tool": START_TOOL, "input": {}, "tool_call_id": "start", "decision": "allowed-once"}],
              "hook_events": [copy.deepcopy(rows[4]), copy.deepcopy(rows[8])],
              "final_texts": [copy.deepcopy(rows[11])]}
    return rows, runner, disk


class SlicedModelLedgerTests(unittest.TestCase):
    def test_v2_uses_only_the_previously_registered_fixed_workspace(self):
        root = Path("outputs").resolve()
        self.assertEqual(expected_model_workspace(root / "agh-sliced-model-v2", root), root / "agh-sliced-model/workspace")
        self.assertEqual(expected_model_workspace(root / "other-model", root), root / "other-model/workspace")
        self.assertEqual(expected_model_workspace(root / "nested/agh-sliced-model-v2", root), root / "nested/agh-sliced-model-v2/workspace")

    def setUp(self):
        self.rows, self.runner, self.disk = fixture()

    def checks(self):
        return check_ledger(self.rows, self.runner, self.disk)["checks"]

    def test_valid_session_passes_and_scientific_stop_is_not_execution_failure(self):
        checks = self.checks()
        self.assertTrue(all(checks.values()), checks)
        self.assertTrue(check_ledger(self.rows, self.runner, self.disk)["strict_tool_scope_passed"])
        self.assertEqual(self.disk["summary"]["candidate_status"], "stop")

    def test_shell_attempt_remains_failure_even_if_hook_denies_it(self):
        call = {"seq": 14, "type": "tool/call", "origin": "model", "data": {"name": "shell", "args": {}, "toolUseId": "extra"}}
        decision = {"seq": 15, "type": "x/plugin/test-extension/scope-decision", "origin": "ext:plugin/test-extension",
                    "data": {"session_key": self.runner["session_id"], "name": "shell", "tool_use_id": "extra", "allow": False, "reason": "outside scope"}}
        result = {"seq": 16, "type": "tool/result", "sourceEventSeqs": [14], "data": {"toolUseId": "extra", "isError": True, "code": "HOOK_DENIED"}}
        self.rows.extend((call, decision, result))
        self.runner["calls"].append({"seq": 14, "name": "shell", "args": {}, "origin": "model"})
        self.runner["hook_events"].append(decision)
        report = check_ledger(self.rows, self.runner, self.disk)
        self.assertFalse(report["strict_tool_scope_passed"])
        self.assertFalse(report["checks"]["only_requested_model_tool_attempts"])

    def test_wrong_task_or_extra_status_argument_fails(self):
        self.rows[7]["data"]["args"] = {"task_id": "2" * 32}
        self.assertFalse(self.checks()["status_polls_same_task_after_launch_within_budget"])
        self.rows[7]["data"]["args"] = {"task_id": self.disk["task_id"], "wait": True}
        self.assertFalse(self.checks()["status_polls_same_task_after_launch_within_budget"])

    def test_duplicate_start_and_result_identity_rejected(self):
        self.rows.append({"seq": 14, "type": "tool/call", "origin": "model", "data": {"name": START_TOOL, "args": {}, "toolUseId": "start2"}})
        self.assertFalse(self.checks()["one_empty_argument_model_sliced_start"])
        self.rows.pop()
        self.rows[9]["data"]["toolUseId"] = "start"
        self.assertFalse(self.checks()["unique_call_result_ids_and_exact_pairing"])

    def test_late_ready_wrong_mode_and_wrong_poll_budget_rejected(self):
        self.rows[1]["seq"] = 5
        self.assertFalse(self.checks()["one_scope_ready_before_first_call"])
        self.rows[1]["seq"] = 2
        self.rows[1]["data"]["mode"] = "diagnosis"
        self.assertFalse(self.checks()["scope_ready_mode_session_and_policy_bound"])
        self.rows[1]["data"]["mode"] = "sliced"
        self.rows[1]["data"]["policy"]["max_status_calls"] = 121
        self.assertFalse(self.checks()["scope_ready_mode_session_and_policy_bound"])

    def test_missing_denied_or_foreign_scope_decision_rejected(self):
        self.rows[4]["data"]["allow"] = False
        self.assertFalse(self.checks()["each_attempt_has_one_paired_allowed_scope_decision"])
        self.rows[4]["data"]["allow"] = True
        self.rows[8]["origin"] = "ext:plugin/other"
        self.assertFalse(self.checks()["scope_events_from_same_registered_extension"])

    def test_public_sdk_scope_workspace_or_decision_mismatch_rejected(self):
        self.runner["scope_ready"]["data"]["workspace_root"] = "E:/other"
        self.assertFalse(self.checks()["public_sdk_readiness_exact_workspace_and_event"])
        self.runner["hook_events"][0]["data"]["allow"] = False
        self.assertFalse(self.checks()["public_sdk_scope_decisions_equal_official"])

    def test_wrong_result_source_sequence_or_poll_before_launch_rejected(self):
        self.rows[9]["sourceEventSeqs"] = [4]
        self.assertFalse(self.checks()["unique_call_result_ids_and_exact_pairing"])
        self.rows[9]["sourceEventSeqs"] = [8]
        self.rows[7]["seq"] = 6
        self.assertFalse(self.checks()["status_polls_same_task_after_launch_within_budget"])

    def test_nonempty_start_or_second_approval_rejected(self):
        self.rows[3]["data"]["args"] = {"confidence": .1}
        self.assertFalse(self.checks()["one_empty_argument_model_sliced_start"])
        self.rows[3]["data"]["args"] = {}
        self.rows.append({"seq": 14, "type": "approval/decided", "data": {"verdict": "allowed-once", "scope": f"tool:{START_TOOL}:execute"}})
        self.assertFalse(self.checks()["one_allow_once_for_start_before_result"])

    def test_forged_official_ap_rejected(self):
        payload = json.loads(self.rows[9]["data"]["content"][0]["text"])
        payload["summary"]["sliced"]["mAP50"] = .6
        self.rows[9]["data"]["content"][0]["text"] = json.dumps(payload)
        self.assertFalse(self.checks()["terminal_official_compact_science_matches_disk"])

    def test_forged_public_sdk_ap_or_event_identity_rejected(self):
        self.runner["polls"][1]["summary"]["baseline"]["mAP50"] = .9
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])
        self.runner["polls"][1]["summary"] = copy.deepcopy(self.disk["summary"])
        self.runner["polls"][1]["seq"] = 11
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])

    def test_false_cannot_replace_zero_count_in_model_sdk_or_disk(self):
        value = copy.deepcopy(compact_target(self.disk))
        value["medium"]["medium_lost_gt"] = False
        self.rows[11]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["model_final_unique_compact_json_matches_disk"])
        self.runner["polls"][1]["summary"]["medium"]["medium_lost_gt"] = False
        self.assertFalse(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])
        self.disk["summary"]["medium"]["medium_lost_gt"] = False
        self.assertIsNone(compact_target(self.disk))

    def test_fake_model_ap_or_candidate_status_rejected(self):
        value = copy.deepcopy(compact_target(self.disk))
        value["candidate_status"] = "accepted"
        self.rows[11]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["model_final_unique_compact_json_matches_disk"])
        self.assertTrue(self.checks()["public_sdk_final_model_json_exact_unmasked_science_matches_disk"])

    def test_public_sdk_model_final_must_be_exact_and_event_bound(self):
        self.runner["final_texts"][0]["seq"] = 11
        self.assertFalse(self.checks()["public_sdk_final_model_json_exact_unmasked_science_matches_disk"])
        self.runner["final_texts"][0]["seq"] = 12
        value = copy.deepcopy(compact_target(self.disk))
        value["sliced"]["mAP50_95"] = .9
        self.runner["final_texts"][0]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["public_sdk_final_model_json_exact_unmasked_science_matches_disk"])

    def test_official_decimal_masks_remain_unknown_with_exact_sdk_binding(self):
        text = self.rows[9]["data"]["content"][0]["text"].replace("0.41068842396135186", "0.[REDACTED:id]")
        parsed, paths = official_payload(text)
        self.assertEqual(parsed["summary"]["baseline"]["mAP50"], UNKNOWN)
        self.assertEqual(paths, [["summary", "baseline", "mAP50"]])
        self.rows[9]["data"]["content"][0]["text"] = text
        self.rows[11]["data"]["content"][0]["text"] = self.rows[11]["data"]["content"][0]["text"].replace("0.41068842396135186", "0.[REDACTED:id]")
        report = check_ledger(self.rows, self.runner, self.disk)
        self.assertTrue(all(report["checks"].values()), report["checks"])
        self.assertEqual(report["masked_final_numeric_paths_not_recovered"], [["baseline", "mAP50"]])
        self.assertIn("0.[REDACTED:id]", report["final_model_text"])

    def test_masked_count_cannot_be_laundered_by_exact_sdk_value(self):
        self.rows[9]["data"]["content"][0]["text"] = self.rows[9]["data"]["content"][0]["text"].replace('"tp": 231', '"tp": [REDACTED:id]')
        self.assertFalse(self.checks()["terminal_official_compact_science_matches_disk"])
        self.assertTrue(self.checks()["terminal_public_sdk_exact_summary_and_evidence_matches_disk"])

    def test_fake_unknown_string_and_unrecognized_masks_are_rejected(self):
        value = copy.deepcopy(compact_target(self.disk))
        value["baseline"]["mAP50"] = UNKNOWN
        self.rows[11]["data"]["content"][0]["text"] = "```json\n" + json.dumps(value) + "\n```"
        self.assertFalse(self.checks()["model_final_unique_compact_json_matches_disk"])
        with self.assertRaises(ValueError):
            official_payload('{"mAP50": [UNRECOGNIZED:mask]}')

    def test_duplicate_keys_multiple_blocks_and_final_before_tool_rejected(self):
        self.assertIsNone(final_compact('```json\n{"tp":1,"tp":2}\n```'))
        text = self.rows[11]["data"]["content"][0]["text"]
        self.assertIsNone(final_compact(text + "\n" + text))
        self.rows[11]["seq"] = 9
        self.assertFalse(self.checks()["final_completed_turn_after_completed_tool"])

    def test_wrong_model_missing_detection_calls_or_training_claim_rejected(self):
        self.rows[10]["data"]["model"] = "other-model"
        self.assertFalse(self.checks()["model_requests_use_agnes_with_successful_response"])
        self.disk["summary"]["successful_observations"] = 0
        self.assertFalse(self.checks()["sliced_terminal_actual_inference_population_and_controls"])
        self.disk["summary"]["training_performed"] = True
        self.assertFalse(self.checks()["sliced_terminal_same_weight_no_training_test"])

    def test_multiple_legal_model_turns_keep_one_start_and_same_task_scope(self):
        self.rows[7:7] = [
            {"type": "assistant/message", "data": {"content": [{"type": "text", "text": "任务仍在运行，等待同任务续接。"}]}},
            {"type": "turn/end", "data": {"reason": "completed", "lastAssistantSeq": 8}},
            {"type": "request/sent", "data": {}},
        ]
        for seq, row in enumerate(self.rows, 1):
            row["seq"] = seq
        self.rows[12]["sourceEventSeqs"] = [11]
        self.rows[-1]["data"]["lastAssistantSeq"] = 15
        self.runner["calls"] = [{"seq": r["seq"], "name": r["data"]["name"], "args": copy.deepcopy(r["data"]["args"]), "origin": r["origin"]}
                                for r in self.rows if r["type"] == "tool/call"]
        self.runner["polls"][1]["seq"] = 13
        self.runner["hook_events"] = [copy.deepcopy(r) for r in self.rows if r["type"].endswith("/scope-decision")]
        self.runner["final_texts"] = [copy.deepcopy(r) for r in self.rows if r["type"] == "assistant/message"]
        self.runner["host_pauses"] = [{"duration_ms": 30000, "reason": "bounded same-task continuation"}]
        checks = self.checks()
        self.assertTrue(all(checks.values()), checks)
        self.assertEqual(check_ledger(self.rows, self.runner, self.disk)["model_turn_count"], 2)

    def test_status_calls_over_the_global_120_budget_fail(self):
        self.rows.extend({"seq": 14 + i, "type": "tool/call", "origin": "model",
                          "data": {"name": STATUS_TOOL, "args": {"task_id": self.disk["task_id"]}, "toolUseId": f"extra-{i}"}}
                         for i in range(120))
        self.assertFalse(self.checks()["status_polls_same_task_after_launch_within_budget"])

    def test_approval_must_bind_the_actual_start_call_identity(self):
        self.runner["permissions"][0]["tool_call_id"] = "another-start"
        self.assertFalse(self.checks()["public_sdk_host_approval_budget_exact"])


class ScientificReviewBindingTests(unittest.TestCase):
    def setUp(self):
        workspace = temporary_workspace()
        self.root = workspace.__enter__()
        self.addCleanup(workspace.__exit__, None, None, None)
        self.task_id = "1" * 32
        self.directory = self.root / self.task_id
        self.directory.mkdir()
        self.source = self.root / ("2" * 32)
        self.diagnosis = self.root / ("diagnosis-" + "3" * 32)
        self.source.mkdir()
        self.diagnosis.mkdir()
        self.write(self.source / "completion.json", {"task_id": self.source.name})
        self.write(self.diagnosis / "completion.json", {"task_id": self.diagnosis.name})
        protocol = {"source_task_id": self.source.name, "diagnosis_task_id": self.diagnosis.name}
        self.write(self.directory / "protocol.json", protocol)
        self.write(self.directory / "sliced_result.json", {"task_id": self.task_id, "status": "completed"})
        self.write(self.directory / "sliced_comparison.json", {"scientific_status": "stop"})
        self.write(self.directory / "decision.json", {"status": "stop"})
        files = [{"name": path.name, "path": str(path), "size_bytes": path.stat().st_size, "sha256": digest(path)}
                 for path in sorted(self.directory.iterdir())]
        manifest = {"task_id": self.task_id, "tool": TOOL, "status": "completed", "files": files}
        self.write(self.directory / "artifact_manifest.json", manifest)
        completion = {"task_id": self.task_id, "tool": TOOL, "status": "completed",
                      "artifact_manifest_sha256": digest(self.directory / "artifact_manifest.json"),
                      "artifacts_sha256": {r["name"]: r["sha256"] for r in files}}
        self.write(self.directory / "completion.json", completion)
        self.independent = {"task_id": self.task_id, "status": "passed", "checks": {"complete_science": True},
                            "passed_checks": 1, "total_checks": 1,
                            "task_completion_sha256": digest(self.directory / "completion.json"),
                            "task_manifest_sha256": digest(self.directory / "artifact_manifest.json"),
                            "task_protocol_sha256": digest(self.directory / "protocol.json"),
                            "source_completion_sha256": digest(self.source / "completion.json"),
                            "diagnosis_completion_sha256": digest(self.diagnosis / "completion.json")}

    @staticmethod
    def write(path, value):
        path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True), encoding="utf-8")

    def review(self):
        return check_scientific_binding(self.independent, self.directory, self.root, self.task_id)

    def test_valid_completed_science_report_binds_current_sealed_bytes(self):
        report = self.review()
        self.assertTrue(report["passed"], report)
        self.assertEqual(len(report["hashes_checked"]), 5)

    def test_unbound_missing_hash_or_failed_report_rejected(self):
        del self.independent["task_protocol_sha256"]
        self.assertFalse(self.review()["passed"])
        self.independent["status"] = "failed"
        self.assertFalse(self.review()["passed"])

    def test_old_report_cannot_be_used_for_new_model_task(self):
        self.independent["task_id"] = "4" * 32
        report = self.review()
        self.assertFalse(report["checks"]["independent_review_bound_to_model_launched_task"])
        self.assertFalse(report["passed"])

    def test_each_of_five_binding_hashes_must_match_actual_bytes(self):
        for key in ("task_completion_sha256", "task_manifest_sha256", "task_protocol_sha256",
                    "source_completion_sha256", "diagnosis_completion_sha256"):
            previous = self.independent[key]
            self.independent[key] = "0" * 64
            with self.subTest(key=key):
                self.assertFalse(self.review()["checks"][f"independent_review_{key}_matches_current_bytes"])
            self.independent[key] = previous

    def test_artifact_tamper_rejected_without_repeating_scientific_computation(self):
        self.write(self.directory / "sliced_result.json", {"task_id": self.task_id, "status": "completed", "fake_ap": .9})
        report = self.review()
        self.assertFalse(report["checks"]["previous_review_current_sealed_artifact_bytes_unchanged"])

    def test_parent_completion_tamper_rejected(self):
        self.write(self.source / "completion.json", {"task_id": self.source.name, "changed": True})
        self.assertFalse(self.review()["checks"]["independent_review_source_completion_sha256_matches_current_bytes"])

    def test_boolean_zero_counts_or_inconsistent_check_values_rejected(self):
        self.independent["passed_checks"] = True
        self.assertFalse(self.review()["checks"]["independent_review_passed_with_typed_nonzero_check_counts"])
        self.independent["passed_checks"] = 0
        self.independent["total_checks"] = 0
        self.assertFalse(self.review()["passed"])
        self.independent["passed_checks"] = self.independent["total_checks"] = 1
        self.independent["checks"]["complete_science"] = 1
        self.assertFalse(self.review()["checks"]["independent_review_check_values_all_true"])

    def test_protocol_must_match_the_frozen_candidate_protocol(self):
        report = check_scientific_binding(self.independent, self.directory, self.root, self.task_id,
                                         expected_protocol_sha256="0" * 64)
        self.assertFalse(report["checks"]["task_protocol_matches_frozen_candidate_protocol"])

    def test_saved_protocol_extra_metadata_keeps_exact_frozen_controls(self):
        frozen = {"source_task_id": self.source.name, "diagnosis_task_id": self.diagnosis.name}
        report = check_scientific_binding(self.independent, self.directory, self.root, self.task_id,
                                         expected_frozen_protocol=frozen)
        self.assertTrue(report["passed"], report)
        frozen["source_task_id"] = "4" * 32
        report = check_scientific_binding(self.independent, self.directory, self.root, self.task_id,
                                         expected_frozen_protocol=frozen)
        self.assertFalse(report["checks"]["task_protocol_preserves_all_frozen_scientific_controls"])

    def test_unsafe_task_or_source_identity_rejected(self):
        report = check_scientific_binding(self.independent, self.directory, self.root, "../other")
        self.assertFalse(report["passed"])
        self.write(self.directory / "protocol.json", {"source_task_id": "../escape", "diagnosis_task_id": self.diagnosis.name})
        self.assertFalse(self.review()["passed"])


if __name__ == "__main__":
    unittest.main()
