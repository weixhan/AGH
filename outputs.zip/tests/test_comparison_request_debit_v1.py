"""Capacity cannot erase unknown title usage or reopen a frozen task."""
import copy
import hashlib
import unittest
from pathlib import Path
from unittest.mock import patch

from tools import comparison_request_debit_v1 as debit


def fixture():
    other = [f"cmp_{number:032x}" for number in range(7)]
    handles = other[:4] + [debit.REPAIR] + other[4:5] + [debit.REFUSAL] + other[5:]
    events = [{"seq": i, "type": "irrelevant", "data": {}} for i in range(1, 134)]

    def event(seq, kind, data):
        events[seq - 1] = {"seq": seq, "type": kind, "data": data,
                           "origin": "system", "trust": "trusted", "lane": "main"}

    event(1, "session/start", {"key": debit.SESSION})
    for request_seq, cost_seq in zip([18, 39, 60, 81, 102, 123], [21, 42, 63, 84, 105, 126]):
        event(request_seq, "request/sent", {"model": {"route": "account-defect-researcher", "id": "agnes-3.0-flash"}})
        event(cost_seq, "cost/ledger", {"purpose": "inference", "model": "agnes-3.0-flash",
              "tokens": {"input": 100, "output": 5, "cacheRead": 0, "cacheWrite": 0}})
    event(9, "x/host/session-title", {"status": "pending", "turn": 1, "model": "agnes-3.0-flash"})
    event(131, "x/host/session-title", {"status": "requested", "turn": 1, "model": "agnes-3.0-flash"})
    event(132, "cost/ledger", {"purpose": "title", "sourceTurn": 1, "model": "agnes-3.0-flash",
          "effectId": "title:fixture", "interrupted": True, "creditSource": "estimated",
          "tokens": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}})
    event(133, "x/host/session-title", {"status": "failed", "reason": "incomplete", "turn": 1, "model": "agnes-3.0-flash"})
    return {
        "freeze": {"status": "failed_diagnostic_preserved", "original_driver_status": "stopped",
            "original_engineering_status": "failed", "refusal_selected_not_started": True,
            "model_requests_actual_closed": None, "model_requests_phase_actual_closed": None,
            "title_usage_known": False, "model_requests_observed_this_diagnostic": 7,
            "prior_closed_model_requests": 34, "model_requests_phase_observed": 41},
        "suite": {"status": "stopped", "model_requests_actual": 7, "phase_model_requests_cap_total": 48,
            "prior_versions_model_requests_actual": 34, "trials": [{"trial_handle": debit.REPAIR, "arm": "F"}]},
        "run": {"status": "completed", "trial_handle": debit.REPAIR, "session_id": debit.SESSION,
            "session_key": debit.SESSION, "model_request_count": 6, "model_requests_including_title": 7},
        "verification": {"status": "failed", "suite_status": "stopped", "model_requests_this_diagnostic": None,
            "model_requests_phase_actual": None, "unknown_model_cost_trials": [debit.REPAIR],
            "selected_started_count": 1, "selected_joint_correct_count": 0,
            "selected_not_started": [debit.REFUSAL], "comparison_unexecuted_trials": 8,
            "unselected": [{"trial_handle": handle, "arm_file_absent": True, "driver_record_absent": True} for handle in other],
            "results": [{"trial_handle": debit.REFUSAL, "started": False, "execution_status": "selected_not_started",
                         "proven_no_execution_artifacts": True}]},
        "diagnosis": {"title_usage_known": False, "title_interrupted": True,
            "zero_tokens_not_treated_as_actual_zero": True, "model_requests_actual_closed": None,
            "phase_actual_closed": None, "main_requests_observed": 6, "native_title_requests_observed": 1,
            "model_requests_observed_this_diagnostic": 7, "prior_closed_model_requests": 34,
            "whole_phase_observed_requests": 41, "phase_request_cap": 48,
            "next_model_execution_allowed_under_current_protocol": False},
        "protocol": {"trials": [{"trial_handle": handle} for handle in handles]},
        "public_protocol": {"phase_model_budget": {"total_cap": 48, "prior_versions_actual_requests": 34,
            "this_pilot_cap": 14, "phase_remaining_before_diagnostic": 14, "reconciliation": "old.json"},
            "engineering_diagnostic": {"selected_trials": [
                {"trial_handle": debit.REPAIR, "case_id": "repair_coordinates", "arm": "F"},
                {"trial_handle": debit.REFUSAL, "case_id": "refuse_source_hash", "arm": "F"}]}},
        "events": events,
        "prior_reconciliation": {"status": "passed_observed_cost_accounting", "actual_requests_observed": 17,
                                 "sessions": [{"all_observed_request_usage_closed": True}]},
        "prior_v6_acceptance": {"status": "passed_engineering_diagnostic", "model_requests_this_diagnostic": 10,
                                "model_requests_phase_actual": 27},
        "prior_v6_suite": {"model_requests_actual": 10},
        "prior_v7_acceptance": {"status": "failed", "model_requests_this_diagnostic": 7, "model_requests_phase_actual": 34},
        "prior_v7_suite": {"status": "stopped", "model_requests_actual": 7}}


class RequestDebitTests(unittest.TestCase):
    def setUp(self):
        self.bundle = fixture()

    def reject_bundle(self, section, field, value):
        self.bundle[section][field] = value
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_whole_failed_item_debited_but_usage_stays_unknown(self):
        facts = debit.derive_capacity_facts(self.bundle)
        with patch.object(debit, "_load_evidence", return_value=(facts, [])):
            receipt = debit.make_receipt()
            self.assertEqual(debit.validate_receipt(receipt), receipt)
        self.assertEqual(receipt["phase_model_budget"]["request_slots_debited"], 41)
        self.assertFalse(receipt["phase_model_budget"]["legacy_token_usage_closed"])
        self.assertIsNone(receipt["legacy_title_usage_unknown"][0]["token_usage"])
        self.assertIsNone(receipt["legacy_title_usage_unknown"][0]["financial_cost"])
        self.assertIsNone(receipt["phase_actual_usage_closed"])
        self.assertEqual(len(receipt["v8_preservation"]["unstarted_trial_handles"]), 8)

    def test_wrong_source_hash_rejected(self):
        with self.assertRaises(ValueError):
            debit.verify_file_bytes(b"source", {"sha256": "0" * 64, "size_bytes": 6})

    def test_source_size_cannot_be_boolean(self):
        with self.assertRaises(ValueError):
            debit.verify_file_bytes(b"a", {"sha256": hashlib.sha256(b"a").hexdigest(), "size_bytes": True})

    def test_original_failed_freeze_cannot_be_promoted(self):
        self.reject_bundle("freeze", "status", "passed_branch_diagnostic_frozen")

    def test_original_driver_cannot_be_completed(self):
        self.reject_bundle("suite", "status", "completed")

    def test_original_actual_requests_cannot_be_filled(self):
        self.reject_bundle("verification", "model_requests_this_diagnostic", 7)

    def test_original_phase_actual_requests_cannot_be_filled(self):
        self.reject_bundle("freeze", "model_requests_phase_actual_closed", 41)

    def test_prior_closed_count_is_not_observed_41(self):
        self.reject_bundle("prior_v7_acceptance", "model_requests_phase_actual", 41)

    def test_underestimated_failed_item_count_rejected(self):
        self.reject_bundle("suite", "model_requests_actual", 6)

    def test_fake_title_receipt_still_cannot_close_unknown_usage(self):
        self.reject_bundle("diagnosis", "title_usage_known", True)

    def test_zero_token_fallback_cannot_be_called_real_usage(self):
        self.bundle["events"][131]["data"]["interrupted"] = False
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_new_title_receipt_cannot_backfill_legacy_usage(self):
        self.bundle["events"].append({"seq": 134, "type": "cost/ledger", "origin": "system", "trust": "trusted",
                                      "data": {"purpose": "title", "tokens": {"input": 10, "output": 5}}})
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_extra_primary_invocation_rejected(self):
        self.bundle["events"][20]["type"] = "request/sent"
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_untrusted_title_event_rejected(self):
        self.bundle["events"][130]["trust"] = "untrusted"
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_official_session_substitution_rejected(self):
        self.bundle["events"][0]["data"]["key"] = "other-session"
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_selected_refusal_must_remain_unstarted(self):
        self.bundle["verification"]["results"][0]["started"] = True
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_other_seven_tasks_must_remain_unstarted(self):
        self.bundle["verification"]["unselected"][0]["arm_file_absent"] = False
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_duplicate_official_sequence_rejected(self):
        self.bundle["events"][132]["seq"] = 132
        with self.assertRaises(ValueError):
            debit.derive_capacity_facts(self.bundle)

    def test_nonfinite_json_rejected(self):
        with self.assertRaises(ValueError):
            debit.decode(b'{"value":NaN}')

    def test_duplicate_json_key_rejected(self):
        with self.assertRaises(ValueError):
            debit.decode(b'{"value":1,"value":2}')

    def test_receipt_budget_and_uncertainty_mutations_rejected(self):
        facts = debit.derive_capacity_facts(self.bundle)
        with patch.object(debit, "_load_evidence", return_value=(facts, [])):
            original = debit.make_receipt()
            mutations = [("total_cap", 49), ("request_slots_debited", 40), ("this_pilot_cap", 8),
                         ("prior_closed_request_slots", 41), ("phase_remaining_before_diagnostic", 8),
                         ("legacy_token_usage_closed", True)]
            for key, value in mutations:
                with self.subTest(key=key):
                    receipt = copy.deepcopy(original)
                    receipt["phase_model_budget"][key] = value
                    with self.assertRaises(ValueError):
                        debit.validate_receipt(receipt)
            receipt = copy.deepcopy(original)
            receipt["phase_actual_usage_closed"] = 41
            with self.assertRaises(ValueError):
                debit.validate_receipt(receipt)
            receipt = copy.deepcopy(original)
            receipt["prior_versions_actual_requests"] = 41
            with self.assertRaises(ValueError):
                debit.validate_receipt(receipt)
            receipt = copy.deepcopy(original)
            receipt["legacy_title_usage_unknown"][0]["token_usage"] = {"input": 0, "output": 0}
            with self.assertRaises(ValueError):
                debit.validate_receipt(receipt)

    def test_old_phase_cap_cannot_be_increased(self):
        self.reject_bundle("suite", "phase_model_requests_cap_total", 49)

    def test_wrong_trusted_freeze_hash_rejected(self):
        with patch.object(Path, "read_bytes", return_value=b'{"status":"failed_diagnostic_preserved"}') as read:
            with self.assertRaisesRegex(ValueError, "Trusted V8 freeze hash"):
                debit.make_receipt()
            read.assert_called_once()

    def test_cli_exclusive_create_never_overwrites(self):
        facts = debit.derive_capacity_facts(self.bundle)
        with patch.object(debit, "_load_evidence", return_value=(facts, [])):
            receipt = debit.make_receipt()
        target = debit.ROOT / "outputs/new-capacity/receipt.json"
        with patch.object(debit, "make_receipt", return_value=receipt), \
                patch.object(Path, "is_file", return_value=False), \
                patch.object(Path, "open", side_effect=FileExistsError) as opened:
            with self.assertRaises(FileExistsError):
                debit.main(["--output", str(target)])
            opened.assert_called_once_with("x", encoding="utf-8")

    def test_cli_cannot_append_to_old_frozen_outputs(self):
        facts = debit.derive_capacity_facts(self.bundle)
        with patch.object(debit, "_load_evidence", return_value=(facts, [])):
            receipt = debit.make_receipt()
        target = debit.ROOT / "outputs/comparison-pilot-v8/new-receipt.json"
        with patch.object(debit, "make_receipt", return_value=receipt), patch.object(Path, "open") as opened:
            with self.assertRaises(ValueError):
                debit.main(["--output", str(target)])
            opened.assert_not_called()


if __name__ == "__main__":
    unittest.main()
