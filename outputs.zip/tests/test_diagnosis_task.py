"""Exercise read-only diagnostic publication and independent saved-task guards.

Only _load_source is replaced by a sealed, isolated source fixture. The actual
diagnosis core, publication hashes and runtime completion verification execute.
No detector, training code or production data is accessed.
"""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from defect_researcher import diagnosis_task as runner
from defect_researcher import resolution_comparison as comparison
from defect_researcher import task_runtime as runtime
from defect_researcher.audit import _artifact_record, _configured_paths, _sha256
from defect_researcher.detection_metrics import score_detections
from defect_researcher.geometry_verifier import CATEGORIES, verify_label_geometry
from test_config import temporary_workspace
from test_geometry_verifier import geometry_configuration, write_json
from test_repair_task_runtime import reseal


def sealed_fixture(root):
    configuration = geometry_configuration(root)
    paths = _configured_paths(configuration)
    source_id = runner._protocol()["source_task_id"]
    source = paths["output_root"] / source_id
    source.mkdir(parents=True)
    # A real independent geometry gate provides the nested source contract.
    gate_configuration = {**configuration, "output_root": str(source / "geometry_gate")}
    gate = verify_label_geometry(gate_configuration, "gate")
    if gate["status"] != "completed" or gate["summary"]["verification_status"] != "passed":
        raise AssertionError(gate)
    arms = {}
    for size in (640, 960):
        records = []
        for index in range(640):
            count = 2 if index < 201 else 1 if index < 395 else 0
            truths = [{"class_id": 0, "xyxy": [20 * gt_index, 0, 20 * gt_index + 10, 10]}
                      for gt_index in range(count)]
            predictions = [{**truth, "confidence": .9} for truth in truths]
            if 395 <= index < 400:
                predictions.append({"class_id": 0, "xyxy": [60, 60, 70, 70], "confidence": .9})
            records.append({"image_id": f"fixture-{index:04d}", "width": 100, "height": 100,
                            "split": "val", "eval_imgsz": size, "precision": "FP32",
                            "ground_truth": truths, "predictions": predictions})
        arms[size] = records
        (source / f"predictions_{size}.jsonl").write_text(
            "".join(json.dumps(record) + "\n" for record in records), encoding="utf-8")
    names = {key - 1: value for key, value in CATEGORIES.items()}
    metrics = {str(size): score_detections(records, names) for size, records in arms.items()}
    for size, value in metrics.items():
        write_json(source / f"metrics_{size}.json", value)
    protocol = {**comparison._protocol(), "weight_sha256": "a" * 64}
    write_json(source / "protocol.json", protocol)
    write_json(source / "inputs.json", {"task_id": source_id, "all_unchanged": True, "files": []})
    paired = {"fixture": "same hand-computed saved prediction population"}
    write_json(source / "comparison.json", paired)
    (source / "events.jsonl").write_text("", encoding="utf-8")
    (source / "comparison_report.md").write_text("Isolated sealed source fixture.\n", encoding="utf-8")
    source_report = {
        "task_id": source_id, "tool": runtime.COMPARISON_TOOL, "status": "completed",
        "configuration": {key: str(value) for key, value in paths.items()},
        "summary": {"comparison_status": "passed", "input_hashes_unchanged": True,
                    "split": "val", "eval_imgsz": [640, 960], "train_imgsz": 640,
                    "same_weight": True, "precision": "FP32", "device": "0",
                    "test_inference_performed": False, "training_performed": False,
                    "weight_sha256": protocol["weight_sha256"], "val_images": 640, "val_boxes": 596,
                    "geometry_task_id": "gate", "geometry_completion": gate["artifacts"]["completion"],
                    "metrics": {size: {key: value[key] for key in ("mAP50", "mAP50_95", "operating_point")}
                                for size, value in metrics.items()}, "comparison": paired},
    }
    write_json(source / "comparison_result.json", source_report)
    artifacts = [_artifact_record(source / name) for key, name in comparison.FILES.items()
                 if key not in ("artifact_manifest", "completion")]
    write_json(source / "artifact_manifest.json", {"task_id": source_id, "tool": runtime.COMPARISON_TOOL,
               "status": "completed", "files": artifacts})
    write_json(source / "completion.json", {"task_id": source_id, "tool": runtime.COMPARISON_TOOL,
               "status": "completed", "artifact_manifest": str(source / "artifact_manifest.json"),
               "artifact_manifest_sha256": _sha256(source / "artifact_manifest.json"),
               "artifacts_sha256": {record["name"]: record["sha256"] for record in artifacts},
               "geometry_completion_sha256": _sha256(Path(gate["artifacts"]["completion"]))})
    frozen = root / "frozen-source-input.txt"
    frozen.write_text("unchanged source bytes\n", encoding="utf-8")
    sources = {"fixture_input": frozen,
               **{f"source_artifact/{path.name}": path for path in source.iterdir() if path.is_file()}}

    def load_source(observed_paths, observed_protocol):
        if observed_paths != paths or observed_protocol != runner._protocol():
            raise AssertionError("Fixture was invoked under a different frozen protocol")
        runtime._completed_report(source, source_id, runtime.COMPARISON_TOOL)
        before = {role: {**_artifact_record(path), "role": role} for role, path in sources.items()}
        return source, sources, before, copy.deepcopy(arms)

    return configuration, source, frozen, load_source


class DiagnosisTaskTests(unittest.TestCase):
    def complete(self, root, task_id="diagnostic"):
        configuration, source, frozen, load_source = sealed_fixture(root)
        with patch.object(runner, "_load_source", side_effect=load_source):
            result = runner.run_diagnosis(configuration, task_id)
        self.assertEqual(result["status"], "completed", result["errors"])
        return configuration, Path(configuration["output_root"]) / task_id, source, frozen, result

    def test_frozen_protocol_is_validation_only_with_zero_new_inference_budget(self):
        protocol = runner._protocol()
        self.assertEqual(protocol["new_inference_budget"], 0)
        self.assertEqual(protocol["min_tp_gain"], 5)
        self.assertEqual(protocol["min_gain_images"], 5)
        self.assertFalse(protocol["automatically_apply_threshold"])
        for field, value in (("split", "test"), ("new_inference_budget", 1),
                             ("threshold_grid", [.1, .25]), ("training_performed", True),
                             ("max_normal_fp_images", 6), ("expected_images", True)):
            with self.subTest(field=field), patch.object(runner, "_read", return_value={**protocol, field: value}):
                with self.assertRaisesRegex(ValueError, field):
                    runner._protocol()

    def test_publication_runs_real_core_and_publishes_completion_last(self):
        with temporary_workspace() as root:
            configuration, source, _, load_source = sealed_fixture(root)
            original = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
            with patch.object(runner, "_load_source", side_effect=load_source), patch.object(runner, "_write", wraps=runner._write) as writes:
                result = runner.run_diagnosis(configuration, "diagnostic")
            self.assertEqual(result["status"], "completed", result["errors"])
            self.assertEqual(writes.call_args_list[-1].args[0].name, "completion.json")
            self.assertEqual(result["summary"]["reference"]["operating_point"]["tp"], 596)
            self.assertEqual(result["summary"]["reference"]["operating_point"]["fp"], 5)
            self.assertEqual(result["summary"]["reference"]["operating_point"]["normal_fp_images"], 5)
            self.assertEqual(result["summary"]["threshold_selection"]["status"], "stop")
            self.assertFalse(result["summary"]["new_inference_performed"])
            self.assertFalse(result["summary"]["training_performed"])
            directory = Path(configuration["output_root"]) / "diagnostic"
            self.assertEqual({path.name for path in directory.iterdir()}, set(runner.FILES.values()))
            manifest = json.loads((directory / "artifact_manifest.json").read_text(encoding="utf-8"))
            marker = json.loads((directory / "completion.json").read_text(encoding="utf-8"))
            self.assertEqual(marker["artifact_manifest_sha256"], _sha256(directory / "artifact_manifest.json"))
            for record in manifest["files"]:
                self.assertEqual(_artifact_record(Path(record["path"])), record)
            self.assertEqual(marker["source_completion_sha256"], _sha256(source / "completion.json"))
            for path, content in original.items():
                self.assertEqual(path.read_bytes(), content)
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "completed", observed.get("errors"))
            self.assertEqual(observed["tool"], runtime.DIAGNOSIS_TOOL)

    def test_existing_task_directory_is_never_overwritten_or_marked_failed(self):
        with temporary_workspace() as root:
            configuration = geometry_configuration(root)
            directory = Path(configuration["output_root"]) / "existing"
            directory.mkdir(parents=True)
            write_json(directory / "completion.json", {"old": "preserve this evidence"})
            (directory / "untouched.txt").write_bytes(b"saved result")
            original = {path: path.read_bytes() for path in directory.iterdir()}
            with patch.object(runner, "_load_source") as load_source:
                result = runner.run_diagnosis(configuration, "existing")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["errors"][0]["type"], "FileExistsError")
            self.assertEqual({path: path.read_bytes() for path in directory.iterdir()}, original)
            load_source.assert_not_called()

    def test_unsafe_ids_fail_before_creating_an_output_directory(self):
        with temporary_workspace() as root:
            configuration = geometry_configuration(root)
            for task_id in ("../outside", "..", "bad/slash", "bad\\slash", "a" * 129, True):
                with self.subTest(task_id=task_id):
                    result = runner.run_diagnosis(configuration, task_id)
                    self.assertEqual(result["status"], "failed")
                    self.assertIn("safe single directory", result["errors"][0]["message"])
            self.assertFalse(Path(configuration["output_root"]).exists())

    def test_sealed_source_artifact_hash_damage_prevents_completion(self):
        with temporary_workspace() as root:
            configuration, source, _, load_source = sealed_fixture(root)
            (source / "predictions_640.jsonl").write_text("damaged source\n", encoding="utf-8")
            with patch.object(runner, "_load_source", side_effect=load_source):
                result = runner.run_diagnosis(configuration, "damaged-source")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["errors"][0]["stage"], "source_evidence_validation")
            directory = Path(configuration["output_root"]) / "damaged-source"
            self.assertFalse((directory / "completion.json").exists())
            self.assertFalse((directory / "diagnosis_result.json").exists())

    def test_input_change_during_real_diagnosis_prevents_completion(self):
        with temporary_workspace() as root:
            configuration, _, frozen, load_source = sealed_fixture(root)
            real_event = runner._event
            def event(directory, stage, status, **details):
                real_event(directory, stage, status, **details)
                if stage == "diagnosis" and status == "passed":
                    frozen.write_text("simulated external input change", encoding="utf-8")
            with patch.object(runner, "_load_source", side_effect=load_source), patch.object(runner, "_event", side_effect=event):
                result = runner.run_diagnosis(configuration, "changed-input")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["errors"][0]["stage"], "input_recheck")
            directory = Path(configuration["output_root"]) / "changed-input"
            self.assertFalse((directory / "completion.json").exists())
            evidence = json.loads((directory / "inputs.json").read_text(encoding="utf-8"))
            self.assertFalse(evidence["all_unchanged"])
            self.assertFalse(next(row for row in evidence["files"] if row["role"] == "fixture_input")["unchanged"])

    def test_artifact_change_at_publication_prevents_final_marker(self):
        with temporary_workspace() as root:
            configuration, _, _, load_source = sealed_fixture(root)
            real_write = runner._write
            def write(path, value):
                real_write(path, value)
                if path.name == "artifact_manifest.json":
                    (path.parent / "gt_details.jsonl").write_text("damaged during publication", encoding="utf-8")
            with patch.object(runner, "_load_source", side_effect=load_source), patch.object(runner, "_write", side_effect=write):
                result = runner.run_diagnosis(configuration, "publication-damage")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["errors"][0]["stage"], "artifact_publication")
            self.assertFalse((Path(configuration["output_root"]) / "publication-damage" / "completion.json").exists())

    def test_saved_task_reader_rejects_changed_diagnostic_artifact(self):
        with temporary_workspace() as root:
            configuration, directory, _, _, _ = self.complete(root)
            (directory / "gt_details.jsonl").write_text("changed after publication\n", encoding="utf-8")
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")
            self.assertIn("hash/size", observed["errors"][0]["message"])

    def test_saved_task_reader_rejects_resealed_cross_artifact_decision_lie(self):
        with temporary_workspace() as root:
            configuration, directory, _, _, _ = self.complete(root)
            decision = json.loads((directory / "decision.json").read_text(encoding="utf-8"))
            decision["selection"]["selected_threshold"] = .1
            write_json(directory / "decision.json", decision)
            reseal(directory)
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")
            self.assertIn("differs across sealed", observed["errors"][0]["message"])

    def test_saved_task_reader_rejects_changed_sealed_source_after_completion(self):
        with temporary_workspace() as root:
            configuration, _, source, _, _ = self.complete(root)
            (source / "predictions_960.jsonl").write_text("changed source\n", encoding="utf-8")
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")
            self.assertIn("hash/size", observed["errors"][0]["message"])

    def test_saved_task_reader_rejects_resealed_input_verdict_disagreeing_with_summary(self):
        with temporary_workspace() as root:
            configuration, directory, _, _, _ = self.complete(root)
            path = directory / "inputs.json"
            inputs = json.loads(path.read_text(encoding="utf-8"))
            inputs["all_unchanged"] = False
            write_json(path, inputs)
            reseal(directory)
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")

    def test_saved_task_reader_rejects_resealed_decision_prediction_source_mismatch(self):
        with temporary_workspace() as root:
            configuration, directory, _, _, _ = self.complete(root)
            path = directory / "decision.json"
            decision = json.loads(path.read_text(encoding="utf-8"))
            decision["predictions_sha256"] = "0" * 64
            write_json(path, decision)
            reseal(directory)
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")

    def test_saved_task_reader_rejects_resealed_input_file_hash_inconsistency(self):
        with temporary_workspace() as root:
            configuration, directory, _, _, _ = self.complete(root)
            path = directory / "inputs.json"
            inputs = json.loads(path.read_text(encoding="utf-8"))
            inputs["files"][0]["sha256_after"] = "0" * 64
            write_json(path, inputs)
            reseal(directory)
            observed = runtime.get_task_status(configuration, "diagnostic")
            self.assertEqual(observed["status"], "failed")


if __name__ == "__main__":
    unittest.main()
