"""Manual oracle and tamper cases for the independent slicing evidence reader."""
from __future__ import annotations

from copy import deepcopy
from contextlib import contextmanager
import importlib.util
import json
from pathlib import Path
import shutil
import unittest
import uuid

SPEC = importlib.util.spec_from_file_location("independent_sliced_evidence", Path(__file__).resolve().parents[1] / "tools" / "verify_sliced_run.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)


@contextmanager
def scratch():
    # Default mkdir permissions preserve the workspace ACL on Windows; Python
    # tempfile's private mode creates directories inaccessible to this sandbox.
    root = (Path(__file__).resolve().parents[1] / "outputs").resolve()
    directory = root / f"sliced-review-test-{uuid.uuid4().hex}"
    directory.mkdir()
    try:
        yield directory
    finally:
        target = directory.resolve()
        if target.parent != root or not target.name.startswith("sliced-review-test-"):
            raise ValueError("Unsafe scratch cleanup target")
        shutil.rmtree(target)


def box(xyxy, confidence=None, class_id=0):
    row = {"class_id": class_id, "xyxy": list(xyxy)}
    if confidence is not None:
        row["confidence"] = confidence
    return row


def image(image_id, gt, predictions):
    return {"image_id": image_id, "width": 1920, "height": 1080, "ground_truth": gt, "predictions": predictions}


def observation(pass_id, predictions):
    crop = reviewer.expected_crops()[pass_id]
    return {"pass_id": pass_id, "global_predictions": reviewer.map_predictions(predictions, crop, pass_id)}


def rules():
    return {"acceptance": {"min_tp_gain": 5, "min_gain_images": 5, "min_medium_tp_gain": 5, "min_medium_gain_images": 5,
        "max_normal_fp_images": 5, "max_normal_fp_rate": 5 / 245, "max_fp": 149,
        "min_ap50": .41068842396135186, "min_ap50_95": .16529868184635887}}


def ledger_fixture():
    observations = [{"image_id": "a", "pass_id": 0, "call_index": 1, "elapsed_seconds": .3, "gpu_seconds": .2}]
    formal = [{**observations[0], "status": "passed", "utc_started": "2026-10-10T10:00:01+00:00",
               "utc_finished": "2026-10-10T10:00:01.300000+00:00"}]
    warmup = [{"image_id": "a", "pass_id": 0, "call_index": 1, "status": "passed", "elapsed_seconds": .2, "gpu_seconds": .1,
               "utc_started": "2026-10-10T10:00:00+00:00", "utc_finished": "2026-10-10T10:00:00.200000+00:00"}]
    budget = {"formal_attempts": formal, "warmup_attempts": warmup, "gpu_seconds": .3,
        "formal_calls": 1, "warmup_calls": 1, "successful_observations": 1, "inference_wall_seconds": 3.,
        "task_wall_seconds": 5., "resumable": True, "wall_segments": [{"utc_started": "2026-10-10T09:59:59+00:00",
            "utc_finished": "2026-10-10T10:00:02+00:00", "task_wall_seconds_before": 2., "inference_wall_seconds_before": 0.,
            "monotonic_task_seconds": 3., "monotonic_inference_seconds": 2.8}]}
    return budget, observations


class IndependentSlicedEvidenceTests(unittest.TestCase):
    def test_json_duplicate_keys_refused(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            reviewer.decode('{"tp":1,"tp":2}')

    def test_json_nonfinite_and_overflow_refused(self):
        for text in ("NaN", "Infinity", "1e400"):
            with self.subTest(text=text), self.assertRaises(ValueError):
                reviewer.decode(text)

    def test_boolean_cannot_replace_numeric_evidence(self):
        self.assertFalse(reviewer.same(False, 0))
        self.assertFalse(reviewer.contains({"passed": 1}, {"passed": True}))
        self.assertTrue(reviewer.same(0, 0.))

    def test_grid_has_nine_frozen_covering_rectangles(self):
        crops = reviewer.expected_crops()
        self.assertEqual(crops[0], [0, 0, 1920, 1080])
        self.assertEqual(crops[-1], [1280, 440, 1920, 1080])
        self.assertEqual(len(crops), 9)
        # Every interval between a crop boundary belongs to a tile, so coverage
        # is derived over the complete image rather than a few chosen corners.
        xs = sorted({0, 1920} | {r[i] for r in crops[1:] for i in (0, 2)})
        ys = sorted({0, 1080} | {r[i] for r in crops[1:] for i in (1, 3)})
        for x1, x2 in zip(xs, xs[1:]):
            for y1, y2 in zip(ys, ys[1:]):
                self.assertTrue(any(r[0] <= x1 < x2 <= r[2] and r[1] <= y1 < y2 <= r[3] for r in crops[1:]))

    def test_local_to_global_preserves_original_index(self):
        mapped = reviewer.map_predictions([box([2, 3, 30, 40], .9), box([9, 10, 29, 31], .2)], reviewer.expected_crops()[6], 6)
        self.assertEqual(mapped[0]["xyxy"], [514, 443, 542, 480])
        self.assertEqual([p["prediction_index"] for p in mapped], [0, 1])
        self.assertEqual(mapped[0]["local_xyxy"], [2, 3, 30, 40])

    def test_invalid_local_prediction_refuses_whole_pass(self):
        for broken in (box([-1, 0, 10, 10], .8), box([0, 0, 0, 10], .8), box([0, 0, 641, 10], .8),
                       box([0, 0, 10, 10], .0009), box([0, 0, 10, 10], True), box([0, 0, 10, 10], .8, True)):
            with self.subTest(broken=broken), self.assertRaises(ValueError):
                reviewer.map_predictions([box([0, 0, 1, 1], .9), broken], reviewer.expected_crops()[1], 1)

    def test_nms_exact_point7_is_retained(self):
        observations = [observation(0, [box([0, 0, 17, 10], .8), box([3, 0, 20, 10], .7)])]
        final, trace = reviewer.expected_trace(observations)
        self.assertEqual(reviewer.iou([0, 0, 17, 10], [3, 0, 20, 10]), .7)
        self.assertEqual(len(final), 2)
        self.assertEqual(trace["suppressed_count"], 0)

    def test_nms_above_point7_suppression_has_source_identity(self):
        final, trace = reviewer.expected_trace([observation(0, [box([0, 0, 17, 10], .8)]),
            observation(1, [box([2, 0, 19, 10], .7)])])
        self.assertEqual(len(final), 1)
        self.assertEqual(trace["rows"][1]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})
        self.assertEqual(trace["rows"][1]["status"], "suppressed_iou")

    def test_nms_class_isolation_and_equal_confidence_tie(self):
        final, trace = reviewer.expected_trace([observation(1, [box([0, 0, 10, 10], .8), box([0, 0, 10, 10], .8, 1)]),
            observation(0, [box([0, 0, 10, 10], .8)])])
        self.assertEqual([r["pass_id"] for r in trace["rows"]], [0, 1, 1])
        self.assertEqual([r["class_id"] for r in final], [0, 1])
        self.assertEqual(trace["rows"][1]["status"], "suppressed_iou")

    def test_global_maxdet_is_distinct_from_iou_suppression(self):
        first = observation(0, [box([i * 2, 0, i * 2 + 1, 1], .8) for i in range(300)])
        second = observation(1, [box([620, 0, 621, 1], .8)])
        final, trace = reviewer.expected_trace([second, first])
        self.assertEqual(len(final), 300)
        self.assertEqual(trace["candidate_count"], 301)
        self.assertEqual(trace["nms_survivor_count"], 301)
        self.assertEqual(trace["global_max_det_discarded_count"], 1)
        self.assertEqual(trace["rows"][-1]["status"], "global_max_det")
        self.assertIsNone(trace["rows"][-1]["final_prediction_index"])

    def test_matching_one_gt_consumed_once_wrong_class_is_fp(self):
        rows = [image("a", [box([0, 0, 20, 20])], [box([0, 0, 20, 20], .9), box([0, 0, 20, 20], .8), box([0, 0, 20, 20], .95, 1)])]
        matches, counts = reviewer.matching(rows)
        self.assertEqual(matches, {("a", 2): None, ("a", 0): 0, ("a", 1): None})
        self.assertEqual(counts[0], {"image_id": "a", "gt": 1, "tp": 1, "fp": 2, "fn": 0})

    def test_matching_gt_tie_prefers_original_gt_index(self):
        rows = [image("a", [box([0, 0, 20, 20]), box([0, 0, 20, 20])], [box([0, 0, 20, 20], .5)])]
        matches, _ = reviewer.matching(rows)
        self.assertEqual(matches["a", 0], 0)

    def test_ap101_known_half_recall_value(self):
        self.assertAlmostEqual(reviewer.ap101([0], 2), 51 / 101)
        self.assertEqual(reviewer.ap101([], 2), 0.)
        self.assertIsNone(reviewer.ap101([None], 0))

    def test_metrics_perfect_and_absent_classes(self):
        rows = [image("a", [box([0, 0, 20, 20])], [box([0, 0, 20, 20], .9)]), image("b", [], [])]
        scored = reviewer.metrics(rows)
        self.assertEqual(scored["mAP50"], 1.)
        self.assertEqual(scored["mAP50_95"], 1.)
        self.assertEqual(scored["ap_classes"], [0])
        self.assertIsNone(scored["per_class"][6]["AP50"])
        self.assertEqual(scored["operating_point"]["normal_images"], 1)

    def test_ap_uses_saved_below_operating_threshold_predictions(self):
        rows = [image("a", [box([0, 0, 20, 20])], [box([0, 0, 20, 20], .01)])]
        scored = reviewer.metrics(rows)
        self.assertEqual(scored["mAP50"], 1.)
        self.assertEqual(scored["operating_point"]["tp"], 0)
        self.assertEqual(scored["operating_point"]["fn"], 1)

    def test_prediction_precision_uses_prediction_size_not_gt_size(self):
        rows = [image("a", [box([0, 0, 31, 31])], [box([0, 0, 32, 32], .9), box([100, 100, 132, 132], .8)])]
        strata = reviewer.corrected_strata(rows)["per_size"]
        self.assertEqual(strata["small"]["tp_gt"], 1)
        self.assertEqual(strata["small"]["tp_predictions"], 0)
        self.assertIsNone(strata["small"]["precision_predictions"])
        self.assertEqual(strata["medium"]["tp_predictions"], 1)
        self.assertEqual(strata["medium"]["precision_predictions"], .5)

    def test_prediction_precision_uses_prediction_center_not_gt_center(self):
        rows = [image("a", [box([620, 0, 650, 40])], [box([630, 0, 660, 40], .9)])]
        strata = reviewer.corrected_strata(rows)["per_region"]
        self.assertEqual(strata["top_left"]["tp_gt"], 1)
        self.assertEqual(strata["top_center"]["tp_predictions"], 1)

    def test_recovered_gt_and_net_gain_are_separate(self):
        gt = [box([0, 0, 40, 40]), box([100, 100, 140, 140])]
        baseline = [image("a", gt, [box([0, 0, 40, 40], .9)])]
        sliced = [image("a", gt, [box([100, 100, 140, 140], .9)])]
        review = reviewer.comparison(baseline, sliced, rules())
        self.assertEqual(review["gains"]["tp_gain"], 0)
        self.assertEqual(review["gains"]["recovered_gt"], 1)
        self.assertEqual(review["gains"]["lost_gt"], 1)
        self.assertEqual([r["transition"] for r in review["gt_transitions"]], ["lost_tp", "recovered_fn"])
        self.assertEqual(len(review["class_size"]), 21)

    def test_unchanged_candidate_is_stop_and_null_cells_retained(self):
        rows = [image("a", [box([0, 0, 40, 40])], [box([0, 0, 40, 40], .9)])]
        report = reviewer.comparison(rows, rows, rules())
        self.assertEqual(report["scientific_decision"]["status"], "stop")
        self.assertIn("medium_tp_gain", report["scientific_decision"]["failed_gates"])
        self.assertEqual(len(report["class_size"]), 21)
        self.assertEqual(report["class_size"][-1]["support_status"], "no_gt")
        self.assertIsNone(report["class_size"][-1]["sliced_recall_gt"])

    def test_forged_accepted_decision_and_metric_detected(self):
        rows = [image("a", [box([0, 0, 40, 40])], [])]
        report = reviewer.comparison(rows, rows, rules())
        forged = deepcopy(report)
        forged["scientific_decision"]["status"] = "accepted"
        self.assertFalse(reviewer.contains(forged["scientific_decision"], report["scientific_decision"]))
        forged = deepcopy(report["sliced_metrics"])
        forged["operating_point"]["fn"] = 0
        self.assertFalse(reviewer.contains(forged, report["sliced_metrics"]))

    def test_publication_hash_tamper_and_resealed_subset_refused(self):
        with scratch() as tmp:
            directory = Path(tmp)
            evidence = directory / "metrics.json"
            evidence.write_text('{}\n', encoding="utf-8")
            def seal(files):
                manifest = {"task_id": "fixture", "tool": "fixture_tool", "status": "completed", "files": files}
                (directory / "artifact_manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
                marker = {"task_id": "fixture", "tool": "fixture_tool", "status": "completed",
                    "artifact_manifest": str(directory / "artifact_manifest.json"),
                    "artifact_manifest_sha256": reviewer.digest(directory / "artifact_manifest.json"),
                    "artifacts_sha256": {r["name"]: r["sha256"] for r in files}}
                (directory / "completion.json").write_text(json.dumps(marker), encoding="utf-8")
            files = [{"name": evidence.name, "path": str(evidence), "size_bytes": evidence.stat().st_size, "sha256": reviewer.digest(evidence)}]
            seal(files)
            self.assertTrue(reviewer.publication(directory, "fixture", "fixture_tool", {"metrics.json"}))
            (directory / "completion.json").rename(directory / "completion_candidate.json")
            self.assertFalse((directory / "completion.json").exists())
            self.assertTrue(reviewer.publication(directory, "fixture", "fixture_tool", {"metrics.json"}, "completion_candidate.json"))
            (directory / "completion_candidate.json").rename(directory / "completion.json")
            evidence.write_text('{"tp":99}\n', encoding="utf-8")
            self.assertFalse(reviewer.publication(directory, "fixture", "fixture_tool", {"metrics.json"}))
            seal([])
            self.assertFalse(reviewer.publication(directory, "fixture", "fixture_tool", {"metrics.json"}))

    def test_scoped_evidence_path_escape_refused(self):
        with scratch() as tmp:
            directory = Path(tmp)
            inside = directory / "task"
            inside.mkdir()
            outside = directory / "outside.json"
            outside.write_text('{}', encoding="utf-8")
            with self.assertRaises(ValueError):
                reviewer.scoped_file(outside, [inside])

    def test_gpu_cost_includes_warmup_and_formal(self):
        budget, observations = ledger_fixture()
        checks = reviewer.ledger_checks(budget, observations)
        self.assertTrue(checks["cumulative_gpu_cost_includes_all_calls_and_warmup"])
        budget["gpu_seconds"] = .2  # Omit warmup from the declared aggregate.
        self.assertFalse(reviewer.ledger_checks(budget, observations)["cumulative_gpu_cost_includes_all_calls_and_warmup"])

    def test_gpu_overspend_refused_even_with_consistent_sum(self):
        budget, observations = ledger_fixture()
        budget["formal_attempts"][0]["gpu_seconds"] = 901.
        budget["gpu_seconds"] = 901.1
        self.assertFalse(reviewer.ledger_checks(budget, observations)["cumulative_gpu_cost_includes_all_calls_and_warmup"])

    def test_inference_wall_cannot_hide_predict_span(self):
        budget, observations = ledger_fixture()
        budget["inference_wall_seconds"] = .6
        checks = reviewer.ledger_checks(budget, observations)
        self.assertFalse(checks["wall_time_contains_entire_recorded_predict_span"])

    def test_monotonic_segments_cannot_reset_inherited_cost(self):
        budget, observations = ledger_fixture()
        self.assertTrue(reviewer.ledger_checks(budget, observations)["monotonic_wall_segments_preserve_cumulative_cost"])
        budget["wall_segments"].append({"utc_started": "2026-10-10T10:00:03+00:00",
            "utc_finished": "2026-10-10T10:00:04+00:00", "task_wall_seconds_before": 0.,
            "inference_wall_seconds_before": 0., "monotonic_task_seconds": 1., "monotonic_inference_seconds": 1.})
        self.assertFalse(reviewer.ledger_checks(budget, observations)["monotonic_wall_segments_preserve_cumulative_cost"])

    def test_call_ledger_overlapping_serial_calls_refused(self):
        budget, observations = ledger_fixture()
        budget["formal_attempts"][0]["utc_started"] = "2026-10-10T10:00:00.100000+00:00"
        self.assertFalse(reviewer.ledger_checks(budget, observations)["all_actual_call_indices_times_and_necessary_failed_retries"])

    def test_incomplete_population_never_becomes_5760_success(self):
        budget, observations = ledger_fixture()
        checks = reviewer.ledger_checks(budget, observations)
        self.assertFalse(checks["budget_5760_formal_successes_no_successful_pass_reruns"])
        self.assertFalse(checks["budget_formal_calls_failed_retry_limit_and_single_warmup"])

    def test_independent_reviewer_does_not_import_project_science(self):
        import ast
        tree = ast.parse(Path(reviewer.__file__).read_text(encoding="utf-8"))
        imports = [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        self.assertFalse(any(name and name.endswith(("sliced_inference", "sliced_task", "detection_metrics", "stratified_statistics")) for name in imports))

    def test_prepublication_receipt_requires_all_checks_and_five_real_bindings(self):
        bindings = {key: str(i) * 64 for i, key in enumerate(("task_completion_sha256", "task_manifest_sha256",
            "task_protocol_sha256", "source_completion_sha256", "diagnosis_completion_sha256"), 1)}
        receipt = {"task_id": "fixture", "status": "passed", "prepublication": True, "passed_checks": 2,
                   "total_checks": 2, "checks": {"source": True, "science": True}, "acceptance_total_wall_seconds": 500., **bindings}
        self.assertTrue(reviewer.prepublication_receipt_valid(receipt, "fixture", bindings))
        for key in bindings:
            broken = deepcopy(receipt)
            broken[key] = "0" * 64
            self.assertFalse(reviewer.prepublication_receipt_valid(broken, "fixture", bindings), key)

    def test_prepublication_receipt_failed_partial_or_wrong_mode_refused(self):
        receipt = {"task_id": "fixture", "status": "passed", "prepublication": True, "passed_checks": 2,
                   "total_checks": 2, "checks": {"source": True, "science": True}, "acceptance_total_wall_seconds": 500.}
        for key, value in (("status", "failed"), ("passed_checks", 1), ("prepublication", False), ("task_id", "wrong")):
            broken = deepcopy(receipt)
            broken[key] = value
            self.assertFalse(reviewer.prepublication_receipt_valid(broken, "fixture", {}))

    def test_prepublication_receipt_numeric_booleans_and_false_check_refused(self):
        receipt = {"task_id": "fixture", "status": "passed", "prepublication": True, "passed_checks": 1,
                   "total_checks": 1, "checks": {"source": True}, "acceptance_total_wall_seconds": 500.}
        for key in ("passed_checks", "total_checks"):
            broken = deepcopy(receipt)
            broken[key] = True
            self.assertFalse(reviewer.prepublication_receipt_valid(broken, "fixture", {}))
        receipt["checks"]["source"] = 1
        self.assertFalse(reviewer.prepublication_receipt_valid(receipt, "fixture", {}))

    def test_prepublication_receipt_acceptance_deadline_not_reset(self):
        receipt = {"task_id": "fixture", "status": "passed", "prepublication": True, "passed_checks": 1,
                   "total_checks": 1, "checks": {"source": True}, "acceptance_total_wall_seconds": 1800.01}
        self.assertFalse(reviewer.prepublication_receipt_valid(receipt, "fixture", {}))


if __name__ == "__main__":
    unittest.main()
