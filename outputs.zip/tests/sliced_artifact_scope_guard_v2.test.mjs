import test from 'node:test';
import assert from 'node:assert/strict';
import { createSlicedArtifactScopeGuard } from '../tools/sliced_artifact_scope_guard.mjs';
const policy = { schema_version: 1, workspace_root: 'E:/project/artifact', task_id: 'c6be75d9328844308bd7987dbf13faec',
 qualified_status_tool: 'mcp_defect_researcher_45e5cef9_get_task_status', max_status_calls: 1 };
const context = { session: { key: 's1', workspaceRoot: 'E:\\project\\artifact' }, replayed: false };
const call = (id = 'one') => ({ toolUseId: id, name: policy.qualified_status_tool, args: { task_id: policy.task_id } });
test('permits exactly one fixed completed artifact read, blocking repeat identity and second read', () => {
 const guard = createSlicedArtifactScopeGuard(policy);
 assert.equal(guard(call(), context).allow, true);
 assert.equal(guard(call(), context).allow, false);
 assert.equal(guard(call('two'), context).allow, false);
});
test('blocks starts, shell, other tasks and broadened arguments without consuming allowed read', () => {
 const guard = createSlicedArtifactScopeGuard(policy);
 for (const name of ['shell', 'read', 'mcp_defect_researcher_45e5cef9_compare_validation_slices'])
  assert.equal(guard({ ...call(), name }, context).allow, false);
 for (const args of [{ task_id: 'f'.repeat(32) }, { task_id: policy.task_id, resume: true }, {}, null, []])
  assert.equal(guard({ ...call(), args }, context).allow, false);
 assert.equal(guard(call(), context).allow, true);
});
test('rejects replay, unpinned or missing sessions and malformed identity', () => {
 const guard = createSlicedArtifactScopeGuard(policy);
 for (const ctx of [{ ...context, replayed: true }, {}, { session: { key: '', workspaceRoot: policy.workspace_root } },
  { session: { key: 's1', workspaceRoot: 'E:/elsewhere' } }]) assert.equal(guard(call(), ctx).allow, false);
 assert.equal(guard(call(''), context).allow, false);
});
test('freezes policy and isolates session budgets', () => {
 const mutable = structuredClone(policy), guard = createSlicedArtifactScopeGuard(mutable);
 mutable.task_id = 'f'.repeat(32);
 assert.equal(guard(call(), context).allow, true);
 assert.equal(guard(call(), { ...context, session: { ...context.session, key: 's2' } }).allow, true);
});
test('refuses permissive and malformed policies', () => {
 for (const patch of [{ max_status_calls: 2 }, { task_id: '*' }, { qualified_status_tool: 'shell' }, { schema_version: 2 }, { extra: true }])
  assert.throws(() => createSlicedArtifactScopeGuard({ ...policy, ...patch }), /Invalid/);
});
