"""Verify quick task launch and rejection of incomplete or damaged results."""
import hashlib
import json
import os
from pathlib import Path
import threading
import time
import unittest
from unittest.mock import patch

from defect_researcher import task_runtime
from defect_researcher.audit import audit_dataset
from defect_researcher.task_runtime import get_task_status, start_audit, start_geometry_verification
from test_audit import CHECKER_RESULT, fixture_configuration
from test_config import temporary_workspace


def publish_geometry_result(config, task_id, findings="passed", *,
                            marker_tool="verify_label_geometry",
                            manifest_tool="verify_label_geometry",
                            result_tool="verify_label_geometry", omit=()):
    """Independent on-disk fixture for the verifier's publication contract."""
    task_dir = Path(config["output_root"]) / task_id
    task_dir.mkdir(parents=True)
    report = {
        "task_id": task_id, "tool": result_tool, "status": "completed",
        "summary": {"verification_status": findings}, "errors": [],
    }
    contents = {
        "verification_result.json": json.dumps(report),
        "geometry_details.jsonl": '{"match":true}\n',
        "fixture_results.json": '{"status":"passed"}',
        "input_manifest.json": '{"files":[]}',
        "events.jsonl": '{"stage":"artifact_publication","status":"ready"}\n',
    }
    records = []
    for name, content in contents.items():
        if name in omit:
            continue
        path = task_dir / name
        path.write_text(content, encoding="utf-8")
        data = path.read_bytes()
        records.append({"name": name, "path": str(path), "size_bytes": len(data),
                        "sha256": hashlib.sha256(data).hexdigest()})
    manifest_path = task_dir / "artifact_manifest.json"
    manifest_path.write_text(json.dumps({
        "task_id": task_id, "tool": manifest_tool, "status": "completed", "files": records,
    }), encoding="utf-8")
    (task_dir / "completion.json").write_text(json.dumps({
        "task_id": task_id, "tool": marker_tool, "status": "completed",
        "artifact_manifest": str(manifest_path),
        "artifact_manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "artifacts_sha256": {record["name"]: record["sha256"] for record in records},
    }), encoding="utf-8")
    return task_dir


def wait_for_terminal(config, task_id):
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        report = get_task_status(config, task_id)
        if report["status"] != "running":
            entry = task_runtime._TASKS.get(task_id)
            if entry is not None:
                entry["thread"].join(timeout=2)
                if entry["thread"].is_alive():
                    raise AssertionError("Test worker did not exit after publishing its result")
            return report
        time.sleep(0.01)
    raise AssertionError("Test task did not reach a terminal status")


class TaskRuntimeTests(unittest.TestCase):
    @unittest.skipUnless(os.name == "nt", "Windows extended-length paths")
    def test_equivalent_windows_parent_spelling_does_not_refuse_saved_task(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            with patch("defect_researcher.audit._run_checker", return_value=(CHECKER_RESULT, "")):
                result = audit_dataset(config, "extended-path")
            task_dir = Path(config["output_root"]) / result["task_id"]
            original_resolve = Path.resolve
            changed = False

            def resolve_once(path, *args, **kwargs):
                nonlocal changed
                value = original_resolve(path, *args, **kwargs)
                if path == task_dir and not changed:
                    changed = True
                    return Path("\\\\?\\" + str(value))
                return value

            with patch.object(Path, "resolve", resolve_once):
                report = get_task_status(config, result["task_id"])
            self.assertTrue(changed)
            self.assertEqual(report["status"], "completed", report)

    def test_saved_result_is_verified_and_damage_is_refused(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            with patch("defect_researcher.audit._run_checker", return_value=(CHECKER_RESULT, "")):
                result = audit_dataset(config, "saved-task")
            self.assertEqual(get_task_status(config, "saved-task")["status"], "completed")
            path = Path(result["artifacts"]["dataset_check"])
            path.write_text('{"status":"changed"}', encoding="utf-8")
            damaged = get_task_status(config, "saved-task")
            self.assertEqual(damaged["status"], "failed")
            self.assertIn("hash/size", damaged["errors"][0]["message"])

    def test_completion_marker_is_required_and_unsafe_id_is_rejected(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            with patch("defect_researcher.audit._run_checker", return_value=(CHECKER_RESULT, "")):
                result = audit_dataset(config, "interrupted-task")
            Path(result["artifacts"]["completion"]).unlink()
            incomplete = get_task_status(config, "interrupted-task")
            self.assertEqual(incomplete["status"], "failed")
            self.assertTrue(incomplete["interrupted"])
            self.assertEqual(incomplete["errors"][0]["type"], "InterruptedTask")
            self.assertEqual(get_task_status(config, "../escape")["status"], "failed")

    def test_geometry_completed_distinguishes_execution_from_findings(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            for findings in ("passed", "failed"):
                task_id = f"saved-geometry-{findings}"
                publish_geometry_result(config, task_id, findings)
                report = get_task_status(config, task_id)
                self.assertEqual(report["status"], "completed")
                self.assertEqual(report["tool"], "verify_label_geometry")
                self.assertEqual(report["summary"]["verification_status"], findings)

    def test_geometry_incomplete_and_hash_damage_are_refused(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            incomplete_dir = publish_geometry_result(config, "geometry-incomplete")
            (incomplete_dir / "completion.json").unlink()
            incomplete = get_task_status(config, "geometry-incomplete")
            self.assertEqual(incomplete["status"], "failed")
            self.assertTrue(incomplete["interrupted"])
            damaged_dir = publish_geometry_result(config, "geometry-damaged")
            (damaged_dir / "geometry_details.jsonl").write_text("changed\n", encoding="utf-8")
            damaged = get_task_status(config, "geometry-damaged")
            self.assertEqual(damaged["status"], "failed")
            self.assertIn("hash/size", damaged["errors"][0]["message"])

    def test_tool_allowlist_and_required_files_cannot_be_bypassed(self):
        cases = [
            {"marker_tool": "unknown", "manifest_tool": "unknown", "result_tool": "unknown"},
            {"marker_tool": None},
            {"manifest_tool": "audit_dataset"},
            {"result_tool": "audit_dataset"},
            {"omit": ("fixture_results.json",)},
            {"marker_tool": "audit_dataset", "manifest_tool": "audit_dataset"},
            {"findings": "unverified"},
        ]
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            for number, options in enumerate(cases):
                with self.subTest(options=options):
                    task_id = f"invalid-contract-{number}"
                    publish_geometry_result(config, task_id, **options)
                    report = get_task_status(config, task_id)
                    self.assertEqual(report["status"], "failed")
                    self.assertTrue(report["errors"])

    def test_legacy_audit_without_tool_markers_remains_readable(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            with patch("defect_researcher.audit._run_checker", return_value=(CHECKER_RESULT, "")):
                result = audit_dataset(config, "legacy-audit")
            manifest_path = Path(result["artifacts"]["artifact_manifest"])
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest.pop("tool", None)
            manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
            completion_path = Path(result["artifacts"]["completion"])
            completion = json.loads(completion_path.read_text(encoding="utf-8"))
            completion.pop("tool", None)
            completion["artifact_manifest_sha256"] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
            completion_path.write_text(json.dumps(completion), encoding="utf-8")
            self.assertEqual(get_task_status(config, "legacy-audit")["status"], "completed")

    def test_launch_is_immediate_and_one_worker_runs_at_a_time(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            entered, release, finished = threading.Event(), threading.Event(), threading.Event()

            def blocked_audit(configuration, task_id):
                entered.set()
                release.wait(5)
                finished.set()
                return {"task_id": task_id, "status": "failed", "errors": [{"message": "test-only failure"}]}

            with patch("defect_researcher.task_runtime.audit_dataset", side_effect=blocked_audit):
                started = time.perf_counter()
                running = start_audit(config)
                self.assertLess(time.perf_counter() - started, 1)
                self.assertTrue(entered.wait(1))
                try:
                    self.assertEqual(running["status"], "running")
                    self.assertEqual(get_task_status(config, running["task_id"])["status"], "running")
                    busy = start_audit(config)
                    self.assertEqual(busy["status"], "failed")
                    self.assertEqual(busy["active_task_id"], running["task_id"])
                    geometry_busy = start_geometry_verification(config)
                    self.assertEqual(geometry_busy["status"], "failed")
                    self.assertEqual(geometry_busy["active_task_id"], running["task_id"])
                    self.assertEqual(geometry_busy["active_tool"], "audit_dataset")
                finally:
                    release.set()
                    finished.wait(2)
                deadline = time.monotonic() + 2
                while time.monotonic() < deadline:
                    terminal = get_task_status(config, running["task_id"])
                    if terminal["status"] != "running":
                        break
                    time.sleep(0.01)
                self.assertEqual(terminal["status"], "failed")
                self.assertEqual(terminal["errors"][0]["message"], "test-only failure")

    def test_geometry_worker_blocks_audit_and_publishes_failed_findings(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            entered, release = threading.Event(), threading.Event()

            def blocked_verification(configuration, task_id):
                entered.set()
                release.wait(5)
                publish_geometry_result(configuration, task_id, "failed")
                return {"task_id": task_id, "tool": "verify_label_geometry", "status": "completed"}

            with patch("defect_researcher.task_runtime._verify_label_geometry", side_effect=blocked_verification):
                started = time.perf_counter()
                running = start_geometry_verification(config)
                self.assertLess(time.perf_counter() - started, 1)
                self.assertTrue(entered.wait(1))
                try:
                    self.assertEqual(running["status"], "running")
                    self.assertEqual(running["tool"], "verify_label_geometry")
                    self.assertEqual(get_task_status(config, running["task_id"])["tool"], "verify_label_geometry")
                    busy = start_audit(config)
                    self.assertEqual(busy["status"], "failed")
                    self.assertEqual(busy["active_tool"], "verify_label_geometry")
                    self.assertEqual(busy["active_task_id"], running["task_id"])
                finally:
                    release.set()
                terminal = wait_for_terminal(config, running["task_id"])
                self.assertEqual(terminal["status"], "completed")
                self.assertEqual(terminal["summary"]["verification_status"], "failed")

    def test_geometry_worker_exception_and_wrong_tool_are_failures(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            for outcome in (RuntimeError("verifier unavailable"), {"task_id": "other", "status": "completed"}):
                with self.subTest(outcome=outcome):
                    options = {"side_effect": outcome} if isinstance(outcome, Exception) else {"return_value": outcome}
                    with patch("defect_researcher.task_runtime._verify_label_geometry", **options):
                        running = start_geometry_verification(config)
                        report = wait_for_terminal(config, running["task_id"])
                    self.assertEqual(report["status"], "failed")
                    self.assertEqual(report["tool"], "verify_label_geometry")
                    self.assertEqual(report["errors"][0]["stage"], "geometry_worker")


if __name__ == "__main__":
    unittest.main()
