"""Hand-computed candidate diagnostics and fixed-budget selection fixtures."""
import copy
import json
import math
import unittest

from defect_researcher.detection_diagnosis import diagnose_detections
from defect_researcher.detection_metrics import score_detections


def gt(class_id=0, xyxy=(0, 0, 10, 10)):
    return {"class_id": class_id, "xyxy": list(xyxy)}


def pred(class_id=0, xyxy=(0, 0, 10, 10), confidence=.9):
    return {**gt(class_id, xyxy), "confidence": confidence}


def image(identifier="a", ground_truth=None, predictions=None, width=100, height=100):
    return {"image_id": identifier, "width": width, "height": height,
            "ground_truth": ground_truth or [], "predictions": predictions or []}


def budget_fixture(extra_low_normal=False, gains=5):
    records = [image(f"defect-{index}", [gt()], [pred(confidence=.2)]) for index in range(gains)]
    for index in range(245):
        predictions = [pred()] if index < 5 else []
        if index == 5 and extra_low_normal:
            predictions = [pred(confidence=.2)]
        records.append(image(f"normal-{index:03d}", predictions=predictions))
    return records


class DetectionDiagnosisTests(unittest.TestCase):
    def test_perfect_detection_and_all_aggregates_are_reconciled(self):
        records = [image("b", [gt()], [pred()]), image("a", predictions=[pred(1)])]
        original = copy.deepcopy(records)
        report = diagnose_detections(records, ["a", "b"])
        self.assertEqual(records, original)
        self.assertEqual(report["operating_point"]["tp"], 1)
        self.assertEqual(report["operating_point"]["fp"], 1)
        self.assertEqual(report["operating_point"]["fn"], 0)
        self.assertEqual(report["fp_details"][0]["fp_category"], "background")
        self.assertIsNone(report["gt_details"][0]["fn_category"])
        for collection in ("per_class", "per_size", "per_region"):
            for count in ("tp", "fp", "fn"):
                self.assertEqual(sum(row[count] for row in report[collection]), report["operating_point"][count])
        self.assertFalse(report["protocol"]["threshold_applied"])
        json.dumps(report, allow_nan=False)

    def test_no_predictions_have_no_overlap_evidence(self):
        report = diagnose_detections([image(ground_truth=[gt()])], ["a"])
        row = report["gt_details"][0]
        self.assertEqual(row["fn_category"], "no_overlap_candidate")
        self.assertEqual(row["best_any_class_iou"], 0)
        self.assertEqual(row["best_same_class_iou"], 0)
        self.assertIsNone(row["best_any_candidate"])
        self.assertIsNone(row["category_candidate"])
        self.assertEqual(report["selection"]["reason"], "normal_image_denominator_missing")

    def test_low_confidence_candidate_has_priority_over_wrong_class_candidate(self):
        report = diagnose_detections([image(ground_truth=[gt()],
            predictions=[pred(confidence=.2), pred(1)])], ["a", "b"])
        row = report["gt_details"][0]
        self.assertEqual(row["fn_category"], "localized_low_confidence")
        self.assertEqual(row["category_candidate"]["prediction_index"], 0)
        self.assertEqual(report["fp_details"][0]["fp_category"], "wrong_class")
        self.assertEqual(report["recommendations"]["threshold_analysis"]["evidence_count"], 1)
        self.assertEqual(report["selection"]["status"], "stop")

    def test_confidence_greedy_conflict_and_duplicate_priority(self):
        records = [image(ground_truth=[gt(), gt(xyxy=(5, 0, 15, 10))],
            predictions=[pred(xyxy=(0, 0, 15, 10)), pred(confidence=.8),
                         pred(xyxy=(5, 0, 15, 10), confidence=.2)])]
        report = diagnose_detections(records, ["a"])
        self.assertEqual(report["gt_details"][0]["matched_prediction_index"], 0)
        missed = report["gt_details"][1]
        self.assertEqual(missed["fn_category"], "matching_conflict")
        self.assertEqual(missed["category_candidate"]["matched_gt_index"], 0)
        self.assertAlmostEqual(missed["category_candidate"]["iou"], 2 / 3)
        self.assertEqual(report["fp_details"][0]["fp_category"], "duplicates")
        self.assertEqual(report["fp_details"][0]["category_gt"]["matched_prediction_index"], 0)
        at_low = next(row for row in report["threshold_curve"] if row["confidence_threshold"] == .2)
        self.assertEqual((at_low["tp"], at_low["fp"], at_low["fn"]), (2, 1, 0))

    def test_wrong_class_overlap_is_candidate_not_causal_proof(self):
        report = diagnose_detections([image(ground_truth=[gt()], predictions=[pred(1)])], ["a", "b"])
        row = report["gt_details"][0]
        self.assertEqual(row["fn_category"], "wrong_class_candidate")
        self.assertEqual(row["best_any_class_iou"], 1)
        self.assertEqual(row["best_same_class_iou"], 0)
        self.assertEqual(report["fp_details"][0]["fp_category"], "wrong_class")

    def test_partial_overlap_is_localization_and_disjoint_is_background(self):
        report = diagnose_detections([image(ground_truth=[gt(xyxy=(0, 0, 20, 10))],
            predictions=[pred(), pred(xyxy=(70, 70, 80, 80), confidence=.8)])], ["a"], match_iou=.6)
        self.assertEqual(report["gt_details"][0]["fn_category"], "localization_candidate")
        self.assertEqual([row["fp_category"] for row in report["fp_details"]], ["localization", "background"])
        self.assertEqual(report["gt_details"][0]["best_same_class_iou"], .5)

    def test_best_any_iou_is_absolute_maximum_even_for_a_true_positive(self):
        report = diagnose_detections([image(ground_truth=[gt()],
            predictions=[pred(xyxy=(0, 0, 9, 10)), pred(1, confidence=.1)])], ["a", "b"])
        row = report["gt_details"][0]
        self.assertEqual(row["status"], "tp")
        self.assertEqual(row["best_any_class_iou"], 1)
        self.assertEqual(row["best_same_class_iou"], .9)
        self.assertGreaterEqual(row["best_any_class_iou"], row["best_same_class_iou"])
        self.assertEqual(row["best_any_candidate"]["prediction_index"], 1)

    def test_best_candidate_tie_uses_input_index_not_confidence(self):
        report = diagnose_detections([image(ground_truth=[gt()],
            predictions=[pred(confidence=.1), pred(confidence=.2)])], ["a"])
        row = report["gt_details"][0]
        self.assertEqual(row["best_same_candidate"]["prediction_index"], 0)
        self.assertEqual(row["category_candidate"]["prediction_index"], 0)
        at_low = next(row for row in report["threshold_curve"] if row["confidence_threshold"] == .2)
        self.assertEqual(at_low["tp"], 1)

    def test_confidence_tie_and_iou_tie_are_deterministic(self):
        report = diagnose_detections([image(ground_truth=[gt(), gt(xyxy=(5, 0, 15, 10))],
            predictions=[pred(xyxy=(0, 0, 15, 10), confidence=.9), pred(confidence=.9)])], ["a"])
        self.assertEqual(report["gt_details"][0]["matched_prediction_index"], 0)
        self.assertEqual(report["gt_details"][1]["fn_category"], "matching_conflict")
        self.assertEqual(report["operating_point"]["tp"], 1)

    def test_inclusive_confidence_and_iou_boundaries(self):
        truth = gt(xyxy=(0, 0, 20, 10))
        report = diagnose_detections([image(ground_truth=[truth], predictions=[pred(confidence=.25)])], ["a"])
        self.assertEqual(report["operating_point"]["tp"], 1)
        below = pred(xyxy=(0, 0, math.nextafter(10, 0), 10), confidence=.25)
        missed = diagnose_detections([image(ground_truth=[truth], predictions=[below])], ["a"])
        self.assertEqual(missed["operating_point"]["tp"], 0)
        self.assertEqual(missed["gt_details"][0]["fn_category"], "localization_candidate")

    def test_fixed_grid_budget_accepts_gain_and_selects_highest_equivalent_threshold(self):
        report = diagnose_detections(budget_fixture(), ["a"])
        selected = report["selection"]
        self.assertEqual(selected["status"], "selected")
        self.assertEqual(selected["selected_threshold"], .2)
        point = selected["selected_operating_point"]
        self.assertEqual((point["tp_gain"], point["gain_images_vs_baseline"]), (5, 5))
        self.assertEqual(point["normal_fp_images"], 5)
        self.assertEqual(point["normal_image_fp_rate"], 5 / 245)
        self.assertEqual(report["recommendations"]["next_branch"], "threshold_analysis")
        self.assertFalse(selected["threshold_applied"])

    def test_one_extra_normal_fp_forces_stop_despite_recall_gain(self):
        report = diagnose_detections(budget_fixture(extra_low_normal=True), ["a"])
        self.assertEqual(report["selection"]["status"], "stop")
        low = next(row for row in report["threshold_curve"] if row["confidence_threshold"] == .2)
        self.assertEqual(low["tp_gain"], 5)
        self.assertEqual(low["normal_fp_images"], 6)
        self.assertFalse(low["within_normal_fp_budget"])

    def test_minimum_tp_gain_rejects_four_recovered_objects(self):
        report = diagnose_detections(budget_fixture(gains=4), ["a"])
        self.assertEqual(report["selection"]["status"], "stop")

    def test_minimum_image_gain_rejects_five_objects_in_one_image(self):
        records = [image(ground_truth=[gt(xyxy=(20 * index, 0, 20 * index + 10, 10)) for index in range(5)],
            predictions=[pred(xyxy=(20 * index, 0, 20 * index + 10, 10), confidence=.2) for index in range(5)])]
        records.extend(image(f"normal-{index:03d}") for index in range(245))
        report = diagnose_detections(records, ["a"])
        low = next(row for row in report["threshold_curve"] if row["confidence_threshold"] == .2)
        self.assertEqual(low["tp_gain"], 5)
        self.assertEqual(low["gain_images_vs_baseline"], 1)
        self.assertEqual(report["selection"]["status"], "stop")

    def test_missing_normal_images_prevents_threshold_selection(self):
        records = [image(str(index), [gt()], [pred(confidence=.2)]) for index in range(5)]
        report = diagnose_detections(records, ["a"])
        self.assertEqual(report["selection"]["reason"], "normal_image_denominator_missing")

    def test_four_small_misses_do_not_trigger_slicing(self):
        records = [image(str(index), [gt()]) for index in range(4)]
        report = diagnose_detections(records, ["a"])
        small = report["recommendations"]["slicing"]["size_support"][0]
        self.assertEqual((small["gt"], small["candidate_fn"]), (4, 4))
        self.assertFalse(small["supported"])
        self.assertEqual(small["reason"], "insufficient_gt_support")
        self.assertEqual(report["recommendations"]["next_branch"], "stop_pending_evidence")

    def test_slicing_candidate_requires_support_and_enrichment_with_both_denominators(self):
        records = [image(f"small-{index}", [gt()]) for index in range(20)]
        records += [image(f"large-{index}", [gt(xyxy=(0, 0, 100, 100))],
                          [pred(xyxy=(0, 0, 100, 100))]) for index in range(20)]
        report = diagnose_detections(records, ["a"])
        support = report["recommendations"]["slicing"]["size_support"][0]
        self.assertTrue(support["supported"])
        self.assertEqual((support["candidate_fn"], support["gt"]), (20, 20))
        self.assertEqual((support["overall_candidate_fn"], support["overall_gt"]), (20, 40))
        self.assertEqual(support["affected_images"], 20)
        self.assertEqual(report["recommendations"]["next_branch"], "sliced_inference_controlled")

    def test_no_scale_enrichment_prevents_slicing_even_with_twenty_small_misses(self):
        report = diagnose_detections([image(str(index), [gt()]) for index in range(20)], ["a"])
        support = report["recommendations"]["slicing"]["size_support"][0]
        self.assertFalse(support["supported"])
        self.assertEqual(support["reason"], "no_candidate_fn_enrichment")

    def test_size_bin_boundaries_and_center_region_boundaries(self):
        report = diagnose_detections([image(ground_truth=[
            gt(xyxy=(0, 0, 32, 32)), gt(xyxy=(0, 0, 96, 96)),
            gt(xyxy=(49, 49, 51, 51)), gt(xyxy=(99, 99, 101, 101))], width=150, height=150)], ["a"])
        self.assertEqual([row["size_bucket"] for row in report["gt_details"]], ["medium", "large", "small", "small"])
        self.assertEqual([row["region"] for row in report["gt_details"]], ["top_left", "top_left", "middle_center", "bottom_right"])

    def test_manual_crosscheck_against_metrics_across_every_frozen_threshold(self):
        records = [image("a", [gt(), gt(xyxy=(5, 0, 15, 10)), gt(1, (40, 0, 60, 10))],
            [pred(xyxy=(0, 0, 15, 10)), pred(confidence=.8), pred(1, (40, 0, 50, 10), .25),
             pred(xyxy=(5, 0, 15, 10), confidence=.2)]), image("b", predictions=[pred(confidence=.15)])]
        report = diagnose_detections(records, {"0": "a", "1": "b"})
        for point in report["threshold_curve"]:
            aggregate = score_detections(records, ["a", "b"], point["confidence_threshold"])["operating_point"]
            for key in ("tp", "fp", "fn", "precision", "recall", "normal_image_fp_rate"):
                self.assertEqual(point[key], aggregate[key])

    def test_disjoint_existing_prediction_does_not_become_overlap_evidence(self):
        report = diagnose_detections([image(ground_truth=[gt()], predictions=[pred(xyxy=(50, 50, 60, 60))])], ["a"])
        row = report["gt_details"][0]
        self.assertEqual(row["fn_category"], "no_overlap_candidate")
        self.assertEqual(row["best_any_candidate"]["iou"], 0)
        self.assertIsNone(row["category_candidate"])

    def test_empty_set_is_json_safe_and_has_no_actionable_branch(self):
        report = diagnose_detections([], ["a"])
        self.assertEqual(report["summary"]["gt"], 0)
        self.assertEqual(report["recommendations"]["next_branch"], "stop_pending_evidence")
        json.dumps(report, allow_nan=False)

    def test_nonfinite_coordinates_and_confidence_and_boolean_numbers_are_rejected(self):
        for bad in (math.nan, math.inf, -math.inf, True):
            with self.subTest(bad=bad):
                records = [image(ground_truth=[gt()])]
                records[0]["ground_truth"][0]["xyxy"][0] = bad
                with self.assertRaises(ValueError):
                    diagnose_detections(records, ["a"])
                with self.assertRaises(ValueError):
                    diagnose_detections([image(predictions=[pred(confidence=bad)])], ["a"])

    def test_invalid_protocol_and_record_inputs_fail_closed(self):
        cases = [dict(threshold_grid=(.1, .2)), dict(threshold_grid=(.25, .2)),
                 dict(threshold_grid=(.1, .25, .25)), dict(threshold_grid=(.0001, .25)),
                 dict(min_tp_gain=0), dict(min_gain_images=True), dict(normal_fp_budget=math.nan),
                 dict(match_iou=0), dict(prediction_floor=.3)]
        for kwargs in cases:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                diagnose_detections([], ["a"], **kwargs)
        for records in ([image(), image()], [image(predictions=[pred(confidence=.0009)])],
                        [image(ground_truth=[gt(3)])], [image(width=0)], [image(ground_truth=[gt(xyxy=(0, 0, 0, 10))])]):
            with self.subTest(records=records), self.assertRaises(ValueError):
                diagnose_detections(records, ["a"])


if __name__ == "__main__":
    unittest.main()
