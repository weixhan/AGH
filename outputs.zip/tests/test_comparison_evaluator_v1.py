"""Independent evidence evaluation, truthful acceptance and gate ablation."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

from defect_researcher import comparison_protocol_v1 as protocol
from defect_researcher import labelguard_fixtures
from test_config import temporary_workspace

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("_comparison_evaluator_test", ROOT / "tools/verify_comparison_case_v1.py")
evaluator = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(evaluator)
HANDLE = "cmp_" + "a" * 32


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def candidate(outcome="clean", evidence_id="ev_verify"):
    return {"schema_version": 1, "trial_handle": HANDLE, "outcome": outcome,
            "target": {"clean": "input", "repaired": "copy", "refused": "none"}[outcome],
            "evidence_ids": [evidence_id],
            "claims": [{"name": "current_verdict", "field": "semantic_status", "value": "passed", "evidence_id": evidence_id}],
            "scope": {"synthetic_only": True, "historical_evidence_reused": False,
                      "new_detector_calls": 0, "gpu_seconds": 0}}


def domain_evidence(directory, action="verify_input", semantic="passed", issues=None):
    directory.mkdir(parents=True)
    dataset = directory / "source_dataset"
    (dataset / "labels").mkdir(parents=True)
    source_label = dataset / "labels/input.txt"
    source_label.write_text("literal source label", encoding="utf-8")
    input_record = evaluator._record(source_label)
    write(directory / "input_manifest.json", {"all_unchanged": True, "files": [
        {"role": "labels/input.txt", "path": str(source_label), "size_bytes": input_record["size_bytes"],
         "sha256_before": input_record["sha256"], "sha256_after": input_record["sha256"], "unchanged": True}]})
    summary = {"verification_status": semantic, "independent_geometry_verification": True,
               "issues_by_code": issues or {}, "issue_count": sum((issues or {}).values())}
    saved = {"task_id": "check", "tool": "verify_label_geometry", "status": "completed",
             "summary": summary, "configuration": {"output_root": str(directory.parent), "dataset_root": str(dataset)}, "errors": []}
    write(directory / "verification_result.json", saved)
    write(directory / "artifact_manifest.json", {"task_id": "check", "tool": saved["tool"], "status": "completed",
                                                 "files": [evaluator._record(directory / "verification_result.json"),
                                                           evaluator._record(directory / "input_manifest.json")]})
    write(directory / "completion.json", {"task_id": "check", "tool": saved["tool"],
                                          "artifact_manifest_sha256": protocol.digest(directory / "artifact_manifest.json")})
    result = {"tool": saved["tool"], "task_id": "check", "task_dir": str(directory),
              "configuration": saved["configuration"], "execution_status": "completed", "semantic_status": semantic,
              "summary": summary, "errors": [], "task_chain_verified": True, "synthetic_only": True,
              "inference_performed": False, "model_used": False,
              "input_before_after": {"unchanged": True},
              "task_files": [evaluator._record(path) for path in directory.iterdir() if path.is_file()],
              "cost": {"domain_tool_calls": 1}}
    return {"evidence_id": "ev_verify", "trial_handle": HANDLE, "action": action,
            "task_manifest": evaluator._record(directory / "artifact_manifest.json"), "result": result}


def append(path, event, record):
    rows = []
    if path.exists():
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    row = {"schema_version": 1, "sequence": len(rows), "event": event,
           "previous_sha256": rows[-1]["sha256"] if rows else "0" * 64, "record": record}
    row["sha256"] = hashlib.sha256(protocol.canonical(row)).hexdigest()
    with path.open("a", encoding="utf-8") as stream:
        stream.write(protocol.canonical(row).decode("utf-8") + "\n")


def complete_trial(root, arm="U", bad_claim=False):
    spec = protocol.load_case_spec()
    case = spec["cases"][0]
    production = root / "production"
    production.mkdir()
    (production / "cableinspect_geometry.py").write_text("# literal fixture only; not imported\n", encoding="utf-8")
    input_root = root / "inputs" / case["id"]
    input_root.parent.mkdir()
    built = labelguard_fixtures.build_case(input_root, case, spec, production)
    directory = root / "trials" / HANDLE
    directory.mkdir(parents=True)
    prepared = {"configuration": built["configuration"], "case_root": str(input_root),
                "source_snapshot": evaluator._record(built["snapshot_path"])}
    registration = {"schema_version": 1, "kind": "comparison_case_trial_v1", "trial_id": "test-1",
                    "owner": "defect_researcher.comparison_case_runtime_v1",
                    "trial_handle": HANDLE, "case_id": case["id"], "arm": arm,
                    "configuration": {**built["configuration"], "output_root": str(root)}, "prepared_case": prepared,
                    "input_snapshot": built["frozen"]["files"],
                    "source_binding": {"files": [evaluator._record(production / "cableinspect_geometry.py"),
                        evaluator._record(ROOT / "outputs/research-workflow-implementation-v1/freeze.json")],
                        "prior_freeze_sha256": "83dcad36f461008073837c2ca1ab6237c8e74019eacf232c821d1f104a087260"}}
    write(directory / "registration.json", registration)
    write(directory / "registration_binding.json", evaluator._record(directory / "registration.json"))
    original = {"schema_version": 1, "trial_handle": HANDLE, "started_epoch": 1000.0,
                "started_monotonic": 10.0, "deadline_epoch": 1120.0, "deadline_monotonic": 130.0,
                "budget": {"domain_invocations": 6, "model_requests": 8, "wall_seconds": 120, "gpu_seconds": 0},
                "registration_sha256": protocol.digest(directory / "registration.json")}
    write(directory / "arm.json", original)
    write(directory / "arm_binding.json", evaluator._record(directory / "arm.json"))
    evidence = domain_evidence(directory / "domain_input/check")
    write(directory / "evidence/verify_input.json", evidence)
    report = candidate()
    if bad_claim:
        report["claims"][0]["value"] = "incorrect"
    write(directory / "candidate.json", report)
    gate = evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE,
                                        require_verified=arm == "F", check_claims=arm == "F")
    write(directory / "gate.json", gate)
    journal = directory / "budget.jsonl"
    append(journal, "ledger_opened", {**original, "used_domain_invocations": 0, "pending": None})
    for step, (action, cost) in enumerate((("verify_input", 1), ("publish_report", 0))):
        append(journal, "action_reserved", {"action": action, "reserved_cost": cost,
                                            "current_epoch": 1001.0 + step * 2, "current_monotonic": 11.0 + step * 2})
        append(journal, "action_closed", {"action": action, "actual_cost": cost, "used_domain_invocations": 1,
                                          "current_epoch": 1002.0 + step * 2, "current_monotonic": 12.0 + step * 2})
        append(directory / "actions.jsonl", "action_started", {"action": action})
        append(directory / "actions.jsonl", "action_finished", {"action": action,
                 "evidence_id": "ev_verify" if action == "verify_input" else None})
    budget = {**{key: original[key] for key in ("started_epoch", "started_monotonic", "deadline_epoch", "deadline_monotonic")},
              "domain_invocations_used": 1, "domain_invocations_reserved": 0, "pending": None,
              "journal_sha256": protocol.digest(journal)}
    publication = {"schema_version": 1, "trial_handle": HANDLE, "accepted": gate["status"] == "passed",
                   "gate_enforced": arm == "F", "candidate_sha256": protocol.digest(directory / "candidate.json"),
                   "gate_sha256": protocol.digest(directory / "gate.json"), "budget": budget}
    write(directory / "publication.json", publication)
    if publication["accepted"]:
        write(directory / "completion.json", {"publication_sha256": protocol.digest(directory / "publication.json")})
    else:
        write(directory / "failure.json", {"reason": "publication_gate_rejected"})
    return directory


class CandidateGateTests(unittest.TestCase):
    def test_actual_evidence_semantics_and_manifest_support_clean_gate(self):
        with temporary_workspace() as root:
            evidence = domain_evidence(root / "task")
            result = evaluator.evaluate_candidate(candidate(), [evidence], trial_handle=HANDLE, require_verified=True)
            self.assertEqual(result["status"], "passed", result)
            self.assertEqual(result["geometry_calls_performed"], 0)
            self.assertFalse(result["literal_answers_consulted"])

    def test_ungated_accepts_same_schema_valid_wrong_claim_full_rejects(self):
        with temporary_workspace() as root:
            evidence = domain_evidence(root / "task")
            report = candidate()
            report["claims"][0]["value"] = "wrong"
            ungated = evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE, check_claims=False)
            full = evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE, require_verified=True)
            self.assertEqual(ungated["status"], "passed")
            self.assertEqual(full["status"], "failed")
            self.assertEqual(ungated["atomic_claims_supported"], 0)

    def test_foreign_trial_duplicate_evidence_and_missing_citation_rejected(self):
        with temporary_workspace() as root:
            evidence = domain_evidence(root / "task")
            other = copy.deepcopy(evidence)
            other["trial_handle"] = "cmp_" + "b" * 32
            for records in ([other], [evidence, evidence], []):
                with self.subTest(count=len(records)):
                    self.assertEqual(evaluator.evaluate_candidate(candidate(), records, trial_handle=HANDLE)["status"], "failed")

    def test_stale_task_manifest_and_same_summary_without_actual_saved_binding_rejected(self):
        with temporary_workspace() as root:
            evidence = domain_evidence(root / "task")
            evidence["result"]["summary"]["issue_count"] = 123
            self.assertEqual(evaluator.evaluate_candidate(candidate(), [evidence], trial_handle=HANDLE)["status"], "failed")
            evidence = domain_evidence(root / "stale")
            (root / "stale/artifact_manifest.json").write_text("{}", encoding="utf-8")
            self.assertEqual(evaluator.evaluate_candidate(candidate(), [evidence], trial_handle=HANDLE)["status"], "failed")

    def test_label_byte_or_membership_change_after_verification_rejected(self):
        with temporary_workspace() as root:
            evidence = domain_evidence(root / "task")
            (root / "task/source_dataset/labels/input.txt").write_text("changed after verification", encoding="utf-8")
            result = evaluator.evaluate_candidate(candidate(), [evidence], trial_handle=HANDLE, require_verified=True)
            self.assertEqual(result["status"], "failed")
            evidence = domain_evidence(root / "second")
            (root / "second/source_dataset/labels/extra.txt").write_text("new unknown label", encoding="utf-8")
            self.assertEqual(evaluator.evaluate_candidate(candidate(), [evidence], trial_handle=HANDLE, require_verified=True)["status"], "failed")

    def test_missing_explicit_verification_rejects_full_but_common_can_publish(self):
        report = candidate(evidence_id="ev_inspect")
        report["claims"][0].update(field="summary.label_files", value=3)
        evidence = {"evidence_id": "ev_inspect", "trial_handle": HANDLE, "action": "inspect_input",
                    "result": {"summary": {"label_files": 3}, "files": []}}
        self.assertEqual(evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE, check_claims=False)["status"], "passed")
        self.assertEqual(evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE, require_verified=True)["status"], "failed")

    def test_failed_source_hash_is_valid_refusal_but_label_fault_is_not(self):
        with temporary_workspace() as root:
            for issues, expected in (({"declared_source_hash": 1}, "passed"), ({"yolo_geometry": 1}, "failed")):
                evidence = domain_evidence(root / expected, semantic="failed", issues=issues)
                report = candidate("refused")
                report["claims"][0]["value"] = "failed"
                result = evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE, require_verified=True)
                self.assertEqual(result["status"], expected, result)

    def test_boolean_does_not_match_integer_evidence(self):
        report = candidate(evidence_id="ev_inspect")
        report["claims"][0].update(field="summary.label_files", value=True)
        evidence = {"evidence_id": "ev_inspect", "trial_handle": HANDLE, "action": "inspect_input",
                    "result": {"summary": {"label_files": 1}, "files": []}}
        self.assertEqual(evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE)["atomic_claims_supported"], 0)

    def test_historical_scope_must_match_actual_science_citation(self):
        report = candidate(evidence_id="ev_science")
        report["claims"][0].update(field="summary.relative_small.gt", value=94)
        evidence = {"evidence_id": "ev_science", "trial_handle": HANDLE, "action": "read_science",
                    "result": {"summary": {"relative_small": {"gt": 94}}, "files": []}}
        self.assertEqual(evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE)["status"], "failed")
        report["scope"]["historical_evidence_reused"] = True
        self.assertEqual(evaluator.evaluate_candidate(report, [evidence], trial_handle=HANDLE)["status"], "passed")


class IndependentEvaluationTests(unittest.TestCase):
    def test_correct_trial_passes_without_touching_execution(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            before = {str(path): path.read_bytes() for path in directory.rglob("*") if path.is_file()}
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "passed", result)
            self.assertTrue(result["correct_completion"])
            after = {str(path): path.read_bytes() for path in directory.rglob("*") if path.is_file()}
            self.assertEqual(before, after)

    def test_ungated_invalid_acceptance_remains_accepted_after_evaluation(self):
        with temporary_workspace() as root:
            directory = complete_trial(root, bad_claim=True)
            before = (directory / "publication.json").read_bytes()
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "failed")
            self.assertTrue(result["group_accepted_candidate"])
            self.assertTrue(result["invalid_artifact_accepted"])
            self.assertEqual(result["unsupported_atomic_claims"], 1)
            self.assertEqual(before, (directory / "publication.json").read_bytes())
            self.assertTrue((directory / "completion.json").exists())

    def test_full_rejected_bad_candidate_not_rewritten_as_accepted(self):
        with temporary_workspace() as root:
            directory = complete_trial(root, arm="F", bad_claim=True)
            result = evaluator.verify(directory)
            self.assertFalse(result["group_accepted_candidate"])
            self.assertFalse(result["invalid_artifact_accepted"])
            self.assertFalse(result["correct_completion"])
            self.assertFalse((directory / "completion.json").exists())

    def test_original_input_byte_changes_fail_even_if_current_label_still_parses(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            (root / "inputs/normal_unrotated/dataset/labels/train/image_1.txt").write_text("0 0.41 0.35 0.4 0.1", encoding="utf-8")
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "failed")
            self.assertTrue(any(row["check"] == "original_input_exact_membership_and_bytes" for row in result["errors"]))

    def test_original_deadline_cannot_be_extended(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            arm = protocol.strict_json(directory / "arm.json")
            arm["deadline_epoch"] += 1
            write(directory / "arm.json", arm)
            self.assertEqual(evaluator.verify(directory)["status"], "failed")

    def test_original_arm_receipt_cannot_be_replaced_with_fresh_budget(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            arm = protocol.strict_json(directory / "arm.json")
            arm["started_epoch"] += 10
            arm["deadline_epoch"] += 10
            write(directory / "arm.json", arm)
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "failed")
            self.assertTrue(any(row["check"] == "immutable_registration_and_arm_receipts" for row in result["errors"]))

    def test_opening_journal_must_bind_exact_original_arm(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            journal = directory / "budget.jsonl"
            rows = [json.loads(line) for line in journal.read_text(encoding="utf-8").splitlines()]
            rows[0]["record"]["started_epoch"] += 1
            previous = "0" * 64
            rewritten = []
            for row in rows:
                row["previous_sha256"] = previous
                bound = {key: value for key, value in row.items() if key != "sha256"}
                row["sha256"] = hashlib.sha256(protocol.canonical(bound)).hexdigest()
                previous = row["sha256"]
                rewritten.append(protocol.canonical(row).decode("utf-8"))
            journal.write_text("\n".join(rewritten) + "\n", encoding="utf-8")
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "failed")
            self.assertTrue(any("opening" in str(row).lower() for row in result["errors"]))

    def test_replayed_hash_chain_rejected(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            journal = directory / "budget.jsonl"
            first = journal.read_text(encoding="utf-8").splitlines()[0]
            with journal.open("a", encoding="utf-8") as stream:
                stream.write(first + "\n")
            result = evaluator.verify(directory)
            self.assertEqual(result["status"], "failed")
            self.assertTrue(any("replay" in str(row).lower() for row in result["errors"]))

    def test_open_unknown_cost_and_over_budget_rejected(self):
        with temporary_workspace() as root:
            directory = complete_trial(root)
            append(directory / "budget.jsonl", "action_reserved", {"action": "verify_copy", "reserved_cost": 1})
            self.assertEqual(evaluator.verify(directory)["status"], "failed")

    def test_evaluator_source_has_no_domain_or_runtime_imports(self):
        import ast
        tree = ast.parse((ROOT / "tools/verify_comparison_case_v1.py").read_text(encoding="utf-8"))
        imports = [node.module or "" for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        self.assertFalse(any("runtime" in name or "geometry" in name or "research_domain" in name for name in imports))


if __name__ == "__main__":
    unittest.main()
