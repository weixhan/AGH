"""Shared recovery budget rejection oracles; no detector or GPU calls."""
from copy import deepcopy
from pathlib import Path
import time
import unittest
from unittest.mock import patch

from defect_researcher import sliced_business_recovery as recovery
from test_config import temporary_workspace


def setup(directory):
    started = time.time()
    coordinator = {"schema_version": 1, "tool": recovery.TOOL, "purpose": recovery.PURPOSE,
        "experiment_id": "sliced-business-v1-test", "start_epoch": started,
        "start_monotonic": time.monotonic(), "deadline_epoch": started+300,
        "limits": {"max_detector_calls": 40, "max_gpu_seconds": 60, "max_wall_seconds": 300},
        "protocol_sha256": "a"*64, "input_manifest_sha256": "b"*64,
        "execution_source_sha256": "c"*64, "implementation_freeze_sha256": "d"*64,
        "real_detector_used": False}
    recovery.write(directory / "coordinator.json", coordinator)
    request = {"experiment_directory": str(directory), "arm": "control", **coordinator}
    return request


def close(ledger, index, *, gpu=.1, status="passed", elapsed=.2):
    ledger.finish_call(index, {"call_index": index, "image_id": "C01_B01_frame_000030", "pass_id": 0,
        "status": status, "utc_started": recovery._timestamp(), "utc_finished": recovery._timestamp(),
        "gpu_seconds": gpu, "elapsed_seconds": elapsed})


class SharedRecoveryTests(unittest.TestCase):
    def test_actual_costs_replay_across_arm_and_finished_rows_are_exact(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            ledger = recovery.SharedExperimentLedger(request)
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            close(ledger, index)
            request["arm"] = "fault"
            fresh = recovery.SharedExperimentLedger(request)
            self.assertEqual(fresh.calls, 1)
            self.assertEqual(fresh.gpu_seconds, .1)
            self.assertIsNone(fresh.pending)
            fresh.check()

    def test_unfinished_shared_call_blocks_next_prediction(self):
        with temporary_workspace() as directory:
            ledger = recovery.SharedExperimentLedger(setup(directory))
            ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            with self.assertRaisesRegex(ValueError, "Unfinished"):
                ledger.before_call("formal", "C01_B01_frame_000030", 1, 2)
            self.assertEqual(ledger.calls, 1)

    def test_unknown_gpu_cost_is_retained_and_cannot_replay(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            ledger = recovery.SharedExperimentLedger(request)
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            with self.assertRaisesRegex(ValueError, "cost unknown"):
                close(ledger, index, gpu=None)
            self.assertIn('"gpu_seconds":null', ledger.path.read_text())
            with self.assertRaisesRegex(ValueError, "cost unknown"):
                recovery.SharedExperimentLedger(request)

    def test_gpu_exact_cap_allows_inspection_and_refuses_next_call(self):
        with temporary_workspace() as directory:
            ledger = recovery.SharedExperimentLedger(setup(directory))
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            close(ledger, index, gpu=60., elapsed=60.)
            ledger.check()
            with self.assertRaisesRegex(RuntimeError, "exhausted before"):
                ledger.before_call("formal", "C01_B01_frame_000030", 1, 2)
            self.assertEqual(ledger.calls, 1)

    def test_gpu_overrun_is_durably_recorded_then_failed(self):
        with temporary_workspace() as directory:
            ledger = recovery.SharedExperimentLedger(setup(directory))
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            with self.assertRaisesRegex(RuntimeError, "exceeded"):
                close(ledger, index, gpu=61., elapsed=61.)
            self.assertEqual(len(ledger.rows), 2)
            self.assertEqual(ledger.gpu_seconds, 61.)

    def test_40_call_cap_is_shared_and_not_reset_by_resume(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            ledger = recovery.SharedExperimentLedger(request)
            for index in range(1, 41):
                token = ledger.before_call("formal", "C01_B01_frame_000030", 0, index)
                close(ledger, token, gpu=0.)
            request["arm"] = "resume"
            resumed = recovery.SharedExperimentLedger(request)
            resumed.check()
            with self.assertRaisesRegex(RuntimeError, "exhausted before"):
                resumed.before_call("formal", "C01_B01_frame_000030", 2, 41)

    def test_original_absolute_clock_is_shared_and_exhausted_before_call(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            value = recovery.read(directory / "coordinator.json")
            value["start_epoch"] -= 301
            value["start_monotonic"] -= 301
            value["deadline_epoch"] -= 301
            recovery.write(directory / "coordinator.json", value)
            ledger = recovery.SharedExperimentLedger(request)
            with self.assertRaisesRegex(RuntimeError, "deadline exhausted"):
                ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            self.assertFalse(ledger.path.exists())

    def test_tail_is_preserved_and_refuses_prediction(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            ledger = recovery.SharedExperimentLedger(request)
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            close(ledger, index)
            with ledger.path.open("ab") as stream:
                stream.write(b'{"event_seq":3')
            before = ledger.path.read_bytes()
            with self.assertRaisesRegex(ValueError, "tail"):
                recovery.SharedExperimentLedger(request)
            self.assertEqual(ledger.path.read_bytes(), before)

    def test_hash_tamper_and_duplicate_keys_cannot_replay(self):
        with temporary_workspace() as directory:
            request = setup(directory)
            ledger = recovery.SharedExperimentLedger(request)
            index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
            close(ledger, index)
            data = ledger.path.read_bytes().replace(b'"event_seq":1', b'"event_seq":2', 1)
            ledger.path.write_bytes(data)
            with self.assertRaisesRegex(ValueError, "hash chain"):
                recovery.SharedExperimentLedger(request)
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            recovery.decode('{"x":1,"x":2}')

    def test_nonfinite_and_boolean_costs_are_not_zero(self):
        for gpu in (True, -1., float("nan"), float("inf")):
            with self.subTest(gpu=gpu), temporary_workspace() as directory:
                ledger = recovery.SharedExperimentLedger(setup(directory))
                index = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
                with self.assertRaises(ValueError):
                    close(ledger, index, gpu=gpu)
                self.assertEqual(ledger.calls, 1)

    def test_cross_arm_science_identity_changes_and_resume_group_is_preserved(self):
        a = recovery.science_identity("a"*64, "b"*64, "control")
        b = recovery.science_identity("a"*64, "b"*64, "fault")
        c = recovery.science_identity("a"*64, "b"*64, "resume")
        self.assertNotEqual(a, b)
        self.assertEqual(b, c)

    def test_boolean_ids_bad_utc_and_impossible_timing_refuse_before_prediction(self):
        for mutation in (lambda row: row.update(schema_version=True),
                         lambda row: row["payload"]["attempt"].update(call_index=True),
                         lambda row: row["payload"]["attempt"].update(pass_id=False),
                         lambda row: row["payload"]["attempt"].update(utc_finished="nonsense"),
                         lambda row: row["payload"]["attempt"].update(gpu_seconds=30., elapsed_seconds=1.)):
            with self.subTest(mutation=mutation), temporary_workspace() as directory:
                request = setup(directory)
                ledger = recovery.SharedExperimentLedger(request)
                token = ledger.before_call("formal", "C01_B01_frame_000030", 0, 1)
                close(ledger, token)
                rows = deepcopy(ledger.rows)
                mutation(rows[-1])
                rows[-1]["event_sha256"] = recovery.digest({key: value for key, value in rows[-1].items() if key != "event_sha256"})
                ledger.path.write_bytes(b"".join(recovery.canonical(row)+b"\n" for row in rows))
                with self.assertRaises(ValueError):
                    recovery.SharedExperimentLedger(request)

    def test_wrong_version_and_purpose_rejected_without_backend(self):
        for version in (True, 3, "1", None):
            with self.subTest(version=version), self.assertRaisesRegex(ValueError, "dedicated"):
                recovery.validate_worker_request({"execution_io_version": version})
        with self.assertRaisesRegex(ValueError, "dedicated"):
            recovery.validate_worker_request({"execution_io_version": 1, "tool": "compare_validation_slices_v3", "arm": "resume"})

    def test_publication_itself_is_charged_and_late_marker_is_preserved_as_rejected(self):
        with temporary_workspace() as directory:
            marker = {"status": "passed", "elapsed_seconds": 299.}
            class DeadlineLedger:
                def check(self):
                    self_marker = directory / "completion.json"
                    assert self_marker.is_file(), "Check must happen after actual publication"
                    raise RuntimeError("Final IO exhausted original deadline")
            with self.assertRaisesRegex(RuntimeError, "Final IO"):
                recovery._publish_marker(directory, marker, DeadlineLedger())
            self.assertFalse((directory / "completion.json").exists())
            self.assertEqual(recovery.read(directory / "completion_rejected.json"), marker)

    def test_successful_publication_checks_remaining_deadline_after_write(self):
        with temporary_workspace() as directory:
            checked = []
            class WithinLedger:
                def check(self):
                    checked.append((directory / "completion.json").is_file())
            marker = {"status": "passed"}
            self.assertEqual(recovery._publish_marker(directory, marker, WithinLedger()), marker)
            self.assertEqual(checked, [True])
            self.assertFalse((directory / "completion_rejected.json").exists())

    def test_frozen_source_byte_change_refuses_the_experiment(self):
        rows = [{"path": str((recovery.ROOT / relative).resolve()),
                 "sha256": recovery._sha256(recovery.ROOT / relative),
                 "size_bytes": (recovery.ROOT / relative).stat().st_size} for relative in recovery.SOURCE_PATHS]
        value = {"schema_version": 1, "tool": recovery.TOOL, "purpose": recovery.PURPOSE,
                 "sources": rows, "execution_source_sha256": recovery.source_digest(rows)}
        recovery.validate_freeze(value)
        changed = deepcopy(value)
        changed["sources"][0]["sha256"] = "0"*64
        with self.assertRaisesRegex(ValueError, "source bytes changed"):
            recovery.validate_freeze(changed)
        changed = deepcopy(value)
        changed["sources"].pop()
        with self.assertRaisesRegex(ValueError, "source set changed"):
            recovery.validate_freeze(changed)


if __name__ == "__main__":
    unittest.main()
