"""Hand-oracle geometry, fusion and frozen scientific-gate tests; no detector."""
import copy
import json
import math
import unittest

from defect_researcher.sliced_inference import analyze_comparison, fuse_predictions, map_predictions, tiles


NAMES = ["broken", "welded", "bent", "scratch", "crushed", "spaced", "deposit"]


def gt(class_id=0, xyxy=(0, 0, 40, 40)):
    return {"class_id": class_id, "xyxy": list(xyxy)}


def pred(class_id=0, xyxy=(0, 0, 40, 40), confidence=.9):
    return {**gt(class_id, xyxy), "confidence": confidence}


def image(identifier="a", ground_truth=None, predictions=None):
    return {"image_id": identifier, "width": 1920, "height": 1080,
            "ground_truth": [] if ground_truth is None else ground_truth,
            "predictions": [] if predictions is None else predictions}


def protocol(records):
    def medium(box):
        x1, y1, x2, y2 = box["xyxy"]
        return 1024 <= (x2 - x1) * (y2 - y1) < 9216
    return {"class_names": NAMES,
            "operating_point": {"confidence": .25, "match_iou": .5},
            "population": {"images": len(records), "gt": sum(len(r["ground_truth"]) for r in records),
                           "normal_images": sum(not r["ground_truth"] for r in records),
                           "medium_gt": sum(medium(g) for r in records for g in r["ground_truth"]),
                           "medium_images": sum(any(medium(g) for g in r["ground_truth"]) for r in records)},
            "acceptance": {"min_tp_gain": 5, "min_gain_images": 5, "min_medium_tp_gain": 5,
                           "min_medium_gain_images": 5, "max_normal_fp_images": 5,
                           "max_normal_fp_rate": .5, "max_fp": 149, "min_ap50": 0., "min_ap50_95": 0.}}


def mapped(pass_id, predictions):
    return map_predictions(predictions, tiles()[pass_id]["crop"], 1920, 1080, pass_id)


class TileAndMappingTests(unittest.TestCase):
    def test_exact_order_and_complete_grid_coverage(self):
        expected = [[0, 0, 1920, 1080], [0, 0, 640, 640], [512, 0, 1152, 640],
                    [1024, 0, 1664, 640], [1280, 0, 1920, 640], [0, 440, 640, 1080],
                    [512, 440, 1152, 1080], [1024, 440, 1664, 1080], [1280, 440, 1920, 1080]]
        self.assertEqual(tiles(), [{"pass_id": i, "crop": crop} for i, crop in enumerate(expected)])
        # Elementary rectangles induced by all grid boundaries cover without a gap.
        xs = sorted({x for crop in expected[1:] for x in (crop[0], crop[2])})
        ys = sorted({y for crop in expected[1:] for y in (crop[1], crop[3])})
        for x1, x2 in zip(xs, xs[1:]):
            for y1, y2 in zip(ys, ys[1:]):
                self.assertTrue(any(c[0] <= x1 and c[2] >= x2 and c[1] <= y1 and c[3] >= y2 for c in expected[1:]))

    def test_dimensions_or_boolean_rejected(self):
        for dimensions in ((1919, 1080), (1920, 1081), (True, 1080), (1920., 1080), (0, 0)):
            with self.subTest(dimensions=dimensions), self.assertRaises(ValueError):
                tiles(*dimensions)

    def test_last_tile_offsets_all_corners_and_preserves_original_indices(self):
        predictions = [pred(6, (0, 0, 640, 640), .001), pred(4, (.5, 1.5, 5.5, 7.5), 1.)]
        original = copy.deepcopy(predictions)
        output = mapped(8, predictions)
        self.assertEqual(output[0]["xyxy"], [1280., 440., 1920., 1080.])
        self.assertEqual(output[1]["xyxy"], [1280.5, 441.5, 1285.5, 447.5])
        self.assertEqual(output[1]["prediction_index"], 1)
        self.assertEqual(output[1]["local_xyxy"], [ .5, 1.5, 5.5, 7.5])
        self.assertEqual(predictions, original)

    def test_pass_zero_keeps_original_full_image_coordinates(self):
        output = mapped(0, [pred(xyxy=(1800, 1000, 1920, 1080))])
        self.assertEqual(output[0]["xyxy"], output[0]["local_xyxy"])

    def test_wrong_crop_or_pass_cannot_remap_coordinate_source(self):
        for crop, pass_id in (([1, 0, 641, 640], 1), ([0, 0, 640, 640], 2),
                              ([0, 0, 1920, 1080], 9), ([False, 0, 640, 640], 1)):
            with self.subTest(crop=crop, pass_id=pass_id), self.assertRaises(ValueError):
                map_predictions([pred()], crop, 1920, 1080, pass_id)

    def test_invalid_local_records_reject_entire_pass(self):
        invalid = [pred(xyxy=(-.001, 0, 40, 40)), pred(xyxy=(0, 0, 640.001, 40)),
                   pred(xyxy=(0, 0, 0, 40)), pred(xyxy=(0, 0, math.nan, 40)),
                   pred(class_id=7), pred(class_id=True), pred(confidence=.000999),
                   pred(confidence=1.001), pred(confidence=math.inf), pred(xyxy=(0, False, 40, 40))]
        for bad in invalid:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                mapped(1, [pred(), bad])

    def test_per_pass_cap_and_empty_pass(self):
        self.assertEqual(mapped(1, []), [])
        with self.assertRaises(ValueError):
            mapped(1, [pred()] * 301)


class FusionTests(unittest.TestCase):
    def test_iou_exact_seven_tenths_is_kept_and_next_float_is_suppressed(self):
        full = mapped(0, [pred(xyxy=(0, 0, 100, 100), confidence=.9)])
        contained = mapped(1, [pred(xyxy=(0, 0, 70, 100), confidence=.8)])
        output, trace = fuse_predictions(full + contained)
        self.assertEqual(len(output), 2)
        self.assertEqual(trace["suppressed_count"], 0)
        greater = mapped(1, [pred(xyxy=(0, 0, math.nextafter(70, math.inf), 100), confidence=.8)])
        output, trace = fuse_predictions(full + greater)
        self.assertEqual(len(output), 1)
        self.assertEqual(trace["rows"][1]["suppressed_by"], {"pass_id": 0, "prediction_index": 0})
        self.assertGreater(trace["rows"][1]["suppression_iou"], .7)

    def test_equal_confidence_prefers_pass_then_original_prediction_index(self):
        candidates = mapped(1, [pred(confidence=.9)]) + mapped(0, [pred(confidence=.9), pred(confidence=.9)])
        output, trace = fuse_predictions(list(reversed(candidates)))
        self.assertEqual(len(output), 1)
        self.assertEqual([(r["pass_id"], r["prediction_index"]) for r in trace["rows"]], [(0, 0), (0, 1), (1, 0)])
        self.assertTrue(all(r["suppressed_by"] == {"pass_id": 0, "prediction_index": 0} for r in trace["rows"][1:]))

    def test_cross_class_identical_boxes_do_not_suppress(self):
        output, trace = fuse_predictions(mapped(0, [pred(0), pred(1)]))
        self.assertEqual(len(output), 2)
        self.assertEqual(trace["suppressed_count"], 0)

    def test_greedy_order_uses_selected_survivors_only(self):
        # A overlaps B>.7, B overlaps C>.7, A/C IoU=2/3. B is suppressed,
        # so it cannot suppress C. Chain-connected-component fusion would fail.
        candidates = mapped(0, [pred(xyxy=(0, 0, 100, 100), confidence=.9),
                                pred(xyxy=(10, 0, 110, 100), confidence=.8),
                                pred(xyxy=(20, 0, 120, 100), confidence=.7)])
        output, trace = fuse_predictions(candidates)
        self.assertEqual([p["xyxy"] for p in output], [[0., 0., 100., 100.], [20., 0., 120., 100.]])
        self.assertEqual([r["status"] for r in trace["rows"]], ["kept", "suppressed_iou", "kept"])

    def test_global_max_det_applies_after_nms_and_retains_trace_for_every_candidate(self):
        # 300 nonoverlapping full-view boxes plus one new tile-view box.
        predictions = [pred(xyxy=(i * 5, 0, i * 5 + 1, 1), confidence=.9) for i in range(300)]
        candidates = mapped(0, predictions) + mapped(1, [pred(xyxy=(0, 5, 1, 6), confidence=.8)])
        output, trace = fuse_predictions(candidates)
        self.assertEqual(len(output), 300)
        self.assertEqual(trace["nms_survivor_count"], 301)
        self.assertEqual(trace["candidate_count"], 301)
        self.assertEqual(trace["global_max_det_discarded_count"], 1)
        self.assertEqual(trace["rows"][-1]["status"], "global_max_det")
        self.assertIsNone(trace["rows"][-1]["final_prediction_index"])
        self.assertEqual([r["final_prediction_index"] for r in trace["rows"][:-1]], list(range(300)))

    def test_truncated_nms_survivor_can_still_have_suppression_associations(self):
        predictions = [pred(xyxy=(i * 5, 0, i * 5 + 1, 1), confidence=.9) for i in range(300)]
        extra = [pred(xyxy=(0, 5, 1, 6), confidence=.8), pred(xyxy=(0, 5, 1, 6), confidence=.7)]
        output, trace = fuse_predictions(mapped(0, predictions) + mapped(1, extra))
        self.assertEqual(len(output), 300)
        self.assertEqual(trace["rows"][-2]["status"], "global_max_det")
        self.assertEqual(trace["rows"][-1]["suppressed_by"], {"pass_id": 1, "prediction_index": 0})
        self.assertEqual(trace["rows"][-1]["status"], "suppressed_iou")

    def test_no_post_fusion_confidence_threshold_and_nonmutation(self):
        candidates = mapped(0, [pred(confidence=.001), pred(1, confidence=.249)])
        original = copy.deepcopy(candidates)
        output, trace = fuse_predictions(candidates)
        self.assertEqual([r["confidence"] for r in output], [.249, .001])
        self.assertEqual(candidates, original)
        json.dumps(trace, allow_nan=False)

    def test_invalid_candidate_offsets_identity_or_frozen_controls_are_rejected(self):
        original = mapped(1, [pred()])[0]
        for field, value in (("xyxy", [1, 0, 40, 40]), ("pass_id", 9), ("pass_id", True),
                             ("prediction_index", 300), ("prediction_index", True), ("confidence", .0001),
                             ("local_xyxy", [-1, 0, 40, 40]), ("crop", [1, 0, 641, 640])):
            bad = copy.deepcopy(original)
            bad[field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                fuse_predictions([bad])
        with self.assertRaises(ValueError):
            fuse_predictions([original, original])
        with self.assertRaises(ValueError):
            fuse_predictions([], nms_iou=.71)
        with self.assertRaises(ValueError):
            fuse_predictions([], max_det=299)
        bad = copy.deepcopy(original)
        bad["prediction_index"] = 1
        with self.assertRaises(ValueError):
            fuse_predictions([bad])

    def test_empty_fusion_is_json_safe(self):
        output, trace = fuse_predictions([])
        self.assertEqual(output, [])
        self.assertEqual(trace["candidate_count"], 0)
        json.dumps(trace, allow_nan=False)


class SlicedAnalysisTests(unittest.TestCase):
    def test_five_distinct_medium_image_gains_and_no_fp_accept_scientific_gates(self):
        baseline = [image(str(i), [gt(4)]) for i in range(5)] + [image("normal")]
        sliced = [image(str(i), [gt(4)], [pred(4)]) for i in range(5)] + [image("normal")]
        report = analyze_comparison(baseline, sliced, protocol(baseline))
        self.assertEqual(report["scientific_decision"]["status"], "accepted")
        self.assertTrue(report["scientific_decision"]["execution_and_evidence_gates_required"])
        self.assertEqual(report["gains"]["tp_gain"], 5)
        self.assertEqual(report["gains"]["medium_gain_images"], 5)
        self.assertEqual(report["paired_medium_recall"]["eligible_images"], 5)
        self.assertEqual(report["paired_medium_recall"]["ci95"], [1., 1.])
        self.assertEqual(report["paired_comparison"]["paired_recall"]["eligible_images"], 5)
        self.assertEqual(len(report["class_size"]), 21)
        self.assertEqual(len(report["per_class_gt"]), 7)
        empty = next(row for row in report["class_size"] if row["class_id"] == 6 and row["size_bucket"] == "small")
        self.assertEqual(empty["gt"], 0)
        self.assertIsNone(empty["sliced_recall_gt"])

    def test_medium_improvement_cannot_pass_over_normal_fp_budget(self):
        baseline = [image(str(i), [gt(4)]) for i in range(5)] + [image("n" + str(i)) for i in range(6)]
        sliced = [image(str(i), [gt(4)], [pred(4)]) for i in range(5)] + [image("n" + str(i), [], [pred(6)]) for i in range(6)]
        report = analyze_comparison(baseline, sliced, protocol(baseline))
        self.assertEqual(report["gains"]["medium_tp_gain"], 5)
        self.assertEqual(report["scientific_decision"]["status"], "stop")
        self.assertIn("normal_fp_images", report["scientific_decision"]["failed_gates"])
        self.assertIn("normal_fp_rate", report["scientific_decision"]["failed_gates"])
        self.assertEqual(report["normal_false_positives"]["sliced"]["fp_boxes"], 6)

    def test_five_recovered_gt_in_one_image_fails_distinct_gain_images(self):
        truths = [gt(xyxy=(i * 60, 0, i * 60 + 40, 40)) for i in range(5)]
        baseline = [image("a", truths), image("normal")]
        sliced = [image("a", truths, [pred(xyxy=t["xyxy"]) for t in truths]), image("normal")]
        report = analyze_comparison(baseline, sliced, protocol(baseline))
        self.assertEqual(report["gains"]["tp_gain"], 5)
        self.assertEqual(report["gains"]["gain_images"], 1)
        self.assertEqual(report["scientific_decision"]["status"], "stop")
        self.assertIn("medium_gain_images", report["scientific_decision"]["failed_gates"])

    def test_recovered_and_lost_are_distinct_from_net_gain(self):
        truths = [gt(xyxy=(0, 0, 40, 40)), gt(xyxy=(100, 0, 140, 40))]
        baseline = [image("a", truths, [pred()]), image("normal")]
        sliced = [image("a", truths, [pred(xyxy=(100, 0, 140, 40))]), image("normal")]
        report = analyze_comparison(baseline, sliced, protocol(baseline))
        self.assertEqual(report["gains"]["recovered_gt"], 1)
        self.assertEqual(report["gains"]["lost_gt"], 1)
        self.assertEqual(report["gains"]["tp_gain"], 0)
        self.assertEqual([r["transition"] for r in report["gt_transitions"]], ["lost_tp", "recovered_fn"])
        self.assertEqual(report["gt_transitions"][0]["evidence_id"], "a:gt:0")
        self.assertEqual(report["paired_medium_recall"]["ci95"], [0., 0.])

    def test_precision_groups_prediction_size_instead_of_gt_size(self):
        # GT area 1024 is medium, contained area 992 prediction is small.
        baseline = [image("a", [gt(xyxy=(0, 0, 32, 32))], [pred(xyxy=(0, 0, 31, 32)), pred(xyxy=(100, 100, 110, 110), confidence=.8)]), image("normal")]
        report = analyze_comparison(baseline, baseline, protocol(baseline))
        rows = {r["size_bucket"]: r for r in report["stratified_statistics"]["baseline"]["size_bucket"]}
        self.assertEqual(rows["medium"]["tp_gt"], 1)
        self.assertEqual(rows["medium"]["tp_predictions"], 0)
        self.assertIsNone(rows["medium"]["precision_predictions"])
        self.assertEqual(rows["small"]["tp_gt"], 0)
        self.assertEqual(rows["small"]["tp_predictions"], 1)
        self.assertEqual(rows["small"]["fp_predictions"], 1)
        self.assertEqual(rows["small"]["precision_predictions"], .5)

    def test_size_boundaries_are_original_gt_and_no_gt_cells_null(self):
        truths = [gt(xyxy=(0, 0, 31, 32)), gt(xyxy=(100, 0, 132, 32)), gt(xyxy=(200, 0, 296, 96))]
        baseline = [image("a", truths), image("normal")]
        report = analyze_comparison(baseline, baseline, protocol(baseline))
        rows = [r for r in report["class_size"] if r["class_id"] == 0]
        self.assertEqual([r["gt"] for r in rows], [1, 1, 1])
        self.assertEqual([r["support_status"] for r in rows], ["insufficient_gt"] * 3)

    def test_precision_groups_prediction_region_when_matched_centers_straddle_boundary(self):
        # GT center x=640 belongs to the center third; prediction center638 is
        # in the left third. The matched TP therefore enters different strata.
        records = [image("a", [gt(xyxy=(620, 0, 660, 40))], [pred(xyxy=(620, 0, 656, 40))]), image("normal")]
        report = analyze_comparison(records, records, protocol(records))
        rows = {r["region"]: r for r in report["stratified_statistics"]["baseline"]["region"]}
        self.assertEqual(rows["top_center"]["tp_gt"], 1)
        self.assertEqual(rows["top_center"]["tp_predictions"], 0)
        self.assertIsNone(rows["top_center"]["precision_predictions"])
        self.assertEqual(rows["top_left"]["tp_gt"], 0)
        self.assertEqual(rows["top_left"]["tp_predictions"], 1)
        self.assertEqual(rows["top_left"]["precision_predictions"], 1)

    def test_matching_iou_half_is_inclusive_and_next_float_below_is_fn(self):
        truth = gt(xyxy=(0, 0, 40, 40))
        baseline = [image("a", [truth], [pred(xyxy=(0, 0, 20, 40))]), image("normal")]
        sliced = [image("a", [truth], [pred(xyxy=(0, 0, math.nextafter(20, 0), 40))]), image("normal")]
        report = analyze_comparison(baseline, sliced, protocol(baseline))
        self.assertEqual(report["baseline_metrics"]["operating_point"]["tp"], 1)
        self.assertEqual(report["sliced_metrics"]["operating_point"]["tp"], 0)
        self.assertEqual(report["gt_transitions"][0]["transition"], "lost_tp")

    def test_confidence_point_inclusive_but_ap_uses_lower_confidence_predictions(self):
        truths = [gt(), gt(xyxy=(100, 0, 140, 40))]
        records = [image("a", truths, [pred(confidence=.25), pred(xyxy=(100, 0, 140, 40), confidence=.249)]), image("normal")]
        report = analyze_comparison(records, records, protocol(records))
        self.assertEqual(report["baseline_metrics"]["operating_point"]["tp"], 1)
        self.assertEqual(report["baseline_metrics"]["mAP50"], 1)
        self.assertEqual(report["gt_transitions"][1]["baseline_status"], "fn")

    def test_matching_ties_and_class_locality_preserve_source_gt_identity(self):
        truths = [gt(xyxy=(0, 0, 40, 40)), gt(xyxy=(20, 0, 60, 40)), gt(1)]
        predictions = [pred(xyxy=(0, 0, 60, 40), confidence=.9), pred(confidence=.8), pred(1)]
        records = [image("a", truths, predictions), image("normal")]
        report = analyze_comparison(records, records, protocol(records))
        self.assertEqual([r["baseline_status"] for r in report["gt_transitions"]], ["tp", "fn", "tp"])
        self.assertEqual(report["baseline_metrics"]["operating_point"]["tp"], 2)
        self.assertEqual(report["baseline_metrics"]["operating_point"]["fp"], 1)

    def test_population_member_or_gt_order_changes_fail_before_decision(self):
        records = [image("a", [gt(), gt(1)]), image("normal")]
        alternate = copy.deepcopy(records)
        alternate[0]["ground_truth"].reverse()
        cases = [(records, records[:-1], protocol(records)), (records, alternate, protocol(records))]
        changed = protocol(records)
        changed["population"]["medium_gt"] = 1
        cases.append((records, records, changed))
        for left, right, configured in cases:
            with self.subTest(configured=configured), self.assertRaises(ValueError):
                analyze_comparison(left, right, configured)

    def test_same_counts_different_population_ids_can_be_bound_and_rejected(self):
        records = [image("a", [gt()]), image("normal")]
        configured = protocol(records)
        configured["population"]["image_ids"] = ["a", "normal"]
        changed = copy.deepcopy(records)
        changed[0]["image_id"] = "b"
        with self.assertRaises(ValueError):
            analyze_comparison(changed, changed, configured)

    def test_no_normal_population_cannot_pass_fp_rate_gate(self):
        records = [image("a", [gt()])]
        report = analyze_comparison(records, records, protocol(records))
        self.assertIsNone(report["baseline_metrics"]["operating_point"]["normal_image_fp_rate"])
        self.assertIn("normal_fp_rate", report["scientific_decision"]["failed_gates"])

    def test_frozen_threshold_floor_bootstrap_and_acceptance_validation(self):
        records = [image("a", [gt()]), image("normal")]
        cases = []
        configured = protocol(records)
        configured["operating_point"]["confidence"] = .2
        cases.append(configured)
        configured = protocol(records)
        configured["prediction_confidence"] = .01
        cases.append(configured)
        configured = protocol(records)
        configured["bootstrap"] = {"seed": 41, "resamples": 2000, "unit": "image_with_at_least_one_gt"}
        cases.append(configured)
        configured = protocol(records)
        del configured["acceptance"]["max_fp"]
        cases.append(configured)
        configured = protocol(records)
        configured["acceptance"]["min_tp_gain"] = True
        cases.append(configured)
        configured = protocol(records)
        configured["acceptance"]["min_ap50"] = math.nan
        cases.append(configured)
        for configured in cases:
            with self.subTest(configured=configured), self.assertRaises(ValueError):
                analyze_comparison(records, records, configured)

    def test_ap_non_degradation_gate_independent_of_operating_point_gains(self):
        baseline = [image(str(i), [gt(4)]) for i in range(5)] + [image("normal")]
        sliced = [image(str(i), [gt(4)], [pred(4, xyxy=(0, 0, 50, 40))]) for i in range(5)] + [image("normal")]
        configured = protocol(baseline)
        configured["acceptance"]["min_ap50_95"] = .9
        report = analyze_comparison(baseline, sliced, configured)
        self.assertEqual(report["gains"]["tp_gain"], 5)
        self.assertEqual(report["sliced_metrics"]["mAP50"], 1)
        self.assertLess(report["sliced_metrics"]["mAP50_95"], .9)
        self.assertEqual(report["scientific_decision"]["status"], "stop")
        self.assertIn("ap50_95_non_degradation", report["scientific_decision"]["failed_gates"])

    def test_overall_fp_gate_and_fp_box_counts_include_defect_and_normal_images(self):
        records = [image("a", [gt()], [pred(), pred(1), pred(2)]), image("normal", [], [pred(), pred(1)])]
        configured = protocol(records)
        configured["acceptance"]["max_fp"] = 3
        report = analyze_comparison(records, records, configured)
        self.assertEqual(report["sliced_metrics"]["operating_point"]["fp"], 4)
        self.assertEqual(report["normal_false_positives"]["sliced"]["fp_boxes"], 2)
        self.assertIn("overall_fp", report["scientific_decision"]["failed_gates"])

    def test_record_bounds_and_invalid_class_cannot_be_hidden_by_matching(self):
        records = [image("a", [gt()], [pred()]), image("normal")]
        for field, value in (("xyxy", [-1, 0, 40, 40]), ("confidence", .0001), ("class_id", 7)):
            changed = copy.deepcopy(records)
            changed[0]["predictions"][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                analyze_comparison(changed, changed, protocol(records))

    def test_bound_source_gt_decimal_rounding_is_preserved_without_clipping(self):
        truth = gt(xyxy=(-.0000096, 0, 40, 40))
        records = [image("a", [truth], [pred()]), image("normal")]
        report = analyze_comparison(records, records, protocol(records))
        self.assertEqual(report["gt_transitions"][0]["xyxy"], truth["xyxy"])
        self.assertEqual(report["baseline_metrics"]["operating_point"]["tp"], 1)
        self.assertEqual(records[0]["ground_truth"][0]["xyxy"][0], -.0000096)

    def test_empty_population_json_safe_and_never_accepts(self):
        report = analyze_comparison([], [], protocol([]))
        self.assertEqual(report["scientific_decision"]["status"], "stop")
        self.assertIsNone(report["paired_medium_recall"]["mean_delta"])
        json.dumps(report, allow_nan=False)

    def test_order_invariance_and_nonmutation(self):
        records = [image("z", [gt()], [pred()]), image("a"), image("m", [gt(6)])]
        snapshot = copy.deepcopy(records)
        report = analyze_comparison(records, records, protocol(records))
        self.assertEqual(report, analyze_comparison(list(reversed(records)), records, protocol(records)))
        self.assertEqual(records, snapshot)
        self.assertEqual(report["paired_comparison"]["delta_direction"], "sliced_minus_baseline")
        json.dumps(report, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
