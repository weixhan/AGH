"""A finished verification must still fail the CLI when its findings fail."""
import contextlib
import io
import json
import unittest
from unittest.mock import patch

from defect_researcher.__main__ import main


class VerificationCLIExitTests(unittest.TestCase):
    def test_comparison_requires_completed_and_passed(self):
        reports = (({"status": "completed", "summary": {"comparison_status": "passed"}}, 0),
                   ({"status": "completed", "summary": {"comparison_status": "failed"}}, 1),
                   ({"status": "completed"}, 1), ({"status": "running"}, 1),
                   ({"status": "failed"}, 1))
        for report, expected in reports:
            with self.subTest(report=report), patch("sys.argv", ["run.py", "compare"]), \
                 patch("defect_researcher.__main__.load_config", return_value={}), \
                 patch("defect_researcher.resolution_comparison.run_comparison", return_value=report), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(), expected)

    def test_repair_requires_both_passed_verdicts(self):
        for summary, expected in (({"repair_status": "passed", "verification_status": "passed"}, 0),
                                  ({"repair_status": "refused", "verification_status": None}, 1),
                                  ({"repair_status": "passed", "verification_status": "failed"}, 1), ({}, 1)):
            with self.subTest(summary=summary), patch("sys.argv", ["run.py", "repair"]), \
                 patch("defect_researcher.__main__.load_config", return_value={}), \
                 patch("defect_researcher.label_repair.repair_label_copy", return_value={"status": "completed", "summary": summary}), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(), expected)

    def test_completed_verification_findings_control_exit_status(self):
        for finding, expected_exit in (("passed", 0), ("failed", 1)):
            report = {"status": "completed", "summary": {"verification_status": finding}}
            with self.subTest(finding=finding), patch("sys.argv", ["run.py", "verify"]), \
                 patch("defect_researcher.__main__.load_config", return_value={}), \
                 patch("defect_researcher.geometry_verifier.verify_label_geometry", return_value=report):
                output = io.StringIO()
                with contextlib.redirect_stdout(output):
                    self.assertEqual(main(), expected_exit)
                self.assertEqual(json.loads(output.getvalue()), report)

    def test_execution_failure_is_not_accepted_as_completed(self):
        report = {"status": "failed", "errors": [{"message": "Missing source"}]}
        with patch("sys.argv", ["run.py", "verify"]), \
             patch("defect_researcher.__main__.load_config", return_value={}), \
             patch("defect_researcher.geometry_verifier.verify_label_geometry", return_value=report), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(), 1)

    def test_nonterminal_or_missing_verdict_is_not_success(self):
        for report in ({"status": "running"}, {"status": "unknown"},
                       {"status": "completed"},
                       {"status": "completed", "summary": {"verification_status": "unknown"}}):
            with self.subTest(report=report), patch("sys.argv", ["run.py", "verify"]), \
                 patch("defect_researcher.__main__.load_config", return_value={}), \
                 patch("defect_researcher.geometry_verifier.verify_label_geometry", return_value=report), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(), 1)
