"""CPU-only full population/step recovery contracts; never real acceptance."""
from copy import deepcopy
from contextlib import nullcontext
from datetime import datetime, timezone
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from defect_researcher import resolution_recovery_coordinator_v1 as coordinator
from defect_researcher.resolution_recovery_backend_v1 import CONTROL_KEYS
from defect_researcher import resolution_recovery_ledger_v1 as ledger_module
from test_config import temporary_workspace


class Clock:
    def __init__(self):
        self.epoch = 1000.
        self.mono = 2000.

    def time(self):
        return self.epoch

    def monotonic(self):
        return self.mono

    def advance(self, seconds):
        self.epoch += seconds
        self.mono += seconds


def chain(directory, task_id, tool, name, result):
    directory.mkdir(parents=True)
    coordinator.write(directory / name, result)
    rows = [coordinator._artifact_record(directory / name)]
    coordinator.write(directory / "artifact_manifest.json", {
        "task_id": task_id, "tool": tool, "status": "completed", "files": rows})
    coordinator.write(directory / "completion.json", {
        "task_id": task_id, "tool": tool, "status": "completed",
        "artifact_manifest": str(directory / "artifact_manifest.json"),
        "artifact_manifest_sha256": coordinator.sha(directory / "artifact_manifest.json"),
        "artifacts_sha256": {name: rows[0]["sha256"]}})


class Fixture:
    def __init__(self, root, *, fast_journal_checks=False):
        self.root = root
        self.clock = Clock()
        self.fast_journal_checks = fast_journal_checks
        self.steps = []
        self.hooks = {}
        self.audit_calls = self.geometry_calls = 0
        self.verifier_calls = 0
        self.inputs_file = root / "frozen-input.txt"
        self.inputs_file.write_text("fixture source bytes", encoding="utf-8")
        self.config = {"research_root": str(root / "research"), "dataset_root": str(root / "dataset"),
                       "raw_root": str(root / "raw"), "split_dir": str(root / "splits"),
                       "weights_path": str(root / "research" / "best.pt"), "output_root": str(root / "outputs")}
        self.rows = [{"image_id": f"fixture_{index:04d}", "image_path": str(root / f"image{index}.png"),
                      "source_path": str(root / f"raw{index}.png"), "label_path": str(root / f"label{index}.txt"),
                      "metadata_path": str(root / f"meta{index}.json"), "width": 100, "height": 80,
                      "split": "val", "ground_truth": [{"class_id": 0, "xyxy": [1., 2., 11., 12.],
                                                          "source_label": "fixture"}]}
                     for index in range(640)]

    def prepare_inputs(self, paths, protocol):
        return deepcopy(self.rows), {"fixture-input": self.inputs_file}, {"train_imgsz": 640, "fixture_only": True}

    def source_paths(self):
        return [Path(coordinator.__file__).resolve(), Path(__file__).resolve()]

    def audit(self, config, task_id):
        self.audit_calls += 1
        if "audit" in self.hooks:
            self.hooks["audit"]()
        result = {"task_id": task_id, "tool": "audit_dataset", "status": "completed", "configuration": config,
                  "summary": {"checker_status": "passed"}}
        chain(Path(config["output_root"]) / task_id, task_id, "audit_dataset", "audit_result.json", result)
        return result

    def geometry(self, config, task_id):
        self.geometry_calls += 1
        result = {"task_id": task_id, "tool": "verify_label_geometry", "status": "completed", "configuration": config,
                  "summary": {"verification_status": "passed", "independent_geometry_verification": True}}
        chain(Path(config["output_root"]) / task_id, task_id, "verify_label_geometry", "verification_result.json", result)
        return result

    def backend(self, records, weights, imgsz, protocol, directory, ledger, step_id):
        self.steps.append(step_id)
        if step_id in self.hooks:
            self.hooks[step_id](directory, ledger)
        # Negative coordinator tests still use actual ticket/state/cost logic.
        # Repeated whole-journal hashing is omitted only inside their fake
        # predictor loop, then the original full hash check runs at the boundary.
        # The retained integrated fixture leaves this optimization disabled.
        original_check = ledger._assert_current
        checking = patch.object(ledger, "_assert_current", lambda: ledger._assert_open(writable=True)) if self.fast_journal_checks else nullcontext()
        with checking:
            for kind, row in [("warmup", records[0]), *[("formal", row) for row in records]]:
                ticket = ledger.reserve(kind, step_id, row["image_id"], imgsz)
                ledger.check()
                started = datetime.fromtimestamp(self.clock.time(), timezone.utc).isoformat()
                self.clock.advance(.01)
                finished = datetime.fromtimestamp(self.clock.time(), timezone.utc).isoformat()
                ledger.closed(ticket, "passed", .01, .001, cost_known=True,
                              utc_started=started, utc_finished=finished,
                              prediction_entered=True, prediction_returned=True,
                              step_id=step_id, image_id=row["image_id"], imgsz=imgsz, kind=kind,
                              error_type=None, error_message=None, timing_error_type=None)
        original_check()
        output = [{**row, "predictions": [{"class_id": 0, "xyxy": [1., 2., 11., 12.], "confidence": .5}],
                   "eval_imgsz": imgsz, "device": "0", "precision": "FP32", "elapsed_seconds": .01,
                   "gpu_seconds": .001, "ultralytics_speed_ms": {"preprocess": 0., "inference": 0., "postprocess": 0.}}
                  for row in records]
        options = {"imgsz": imgsz, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
                   "rect": False, "augment": False, "agnostic_nms": False, "quantize": None,
                   "nms": None, "device": "0"}
        environment = {"fixture_only": True, "real_detector_used": False,
                       "actual_predictor_options": options, "device": "0", "precision": "FP32",
                       "actual_predictor_fp16": False, "actual_predictor_device": "cuda:0",
                       "actual_input_device": "cuda:0", "actual_input_dtype": "torch.float32",
                       "model_parameters_dtype": "torch.float32", "tf32_matmul": False, "tf32_cudnn": False,
                       "cudnn_benchmark": False, "cudnn_deterministic": True, "prediction_entry_calls": 641,
                       "formal_calls": 640, "warmup_calls": 1, "warmup_images": 1,
                       "prediction_entry": "YOLO.predict", "actual_current_cuda_device": 0,
                       "warmup_seconds": .01, "warmup_gpu_seconds": .001,
                       "closed_prediction_gpu_seconds": 641*.001,
                       "closed_prediction_elapsed_seconds": 641*.01,
                       "group_elapsed_seconds": 641*.01,
                       "python_executable": "fixture-python-executable",
                       "backend_source": coordinator._artifact_record(Path(coordinator.__file__).with_name("resolution_recovery_backend_v1.py")),
                       "callable_sources": {},
                       "actual_predictor_imgsz": [imgsz, imgsz], "python": "fixture-python", "torch": "fixture-torch",
                       "ultralytics": "fixture-ultralytics", "cuda": "fixture-CUDA", "cudnn": 1,
                       "gpu_name": "fixture-GPU", "gpu_total_bytes": 1000}
        if "environment" in self.hooks:
            self.hooks["environment"](environment)
        return output, environment

    def verifier(self, directory, *, prepublication):
        self.verifier_calls += 1
        if "verifier" in self.hooks:
            return self.hooks["verifier"](directory)
        self.assert_prepublication = prepublication
        return {"status": "passed_fixture_only", "checks": {"fixture_contract": True}, "errors": []}

    def dependencies(self):
        return coordinator.TestDependencies(self.prepare_inputs, self.audit, self.geometry, self.backend,
                                            self.verifier, self.clock, self.source_paths)

    def prepare(self, task_id="fixture-task"):
        return coordinator.prepare_task(self.config, task_id, test_dependencies=self.dependencies())

    def run(self, registration):
        return coordinator.run_task(registration["task_directory"], test_dependencies=self.dependencies())


class NormalizedPrecisionEnvironmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # The CPU backend uses AST-extracted installed Ultralytics normalization;
        # it never imports or invokes the actual detector or GPU libraries.
        from test_resolution_recovery_backend_v1 import RecoveryBackendTests
        backend_fixture = RecoveryBackendTests()
        backend_fixture.setUp()
        _, cls.environment = backend_fixture.run_group()

    def test_actual_normalized_environment_without_half_is_accepted(self):
        self.assertNotIn("half", self.environment["actual_predictor_options"])
        self.assertIs(coordinator._environment(self.environment, 640, True), self.environment)

    def test_normalization_does_not_allow_precision_drift_or_broadened_schema(self):
        changes = (("quantize", 16), ("quantize", False), ("half", False),
                   ("actual_predictor_fp16", True), ("actual_input_dtype", "torch.float16"),
                   ("model_parameters_dtype", "torch.float16"))
        for field, value in changes:
            with self.subTest(field=field, value=value):
                environment = json.loads(json.dumps(self.environment))
                target = environment["actual_predictor_options"] if field in {"quantize", "half"} else environment
                target[field] = value
                with self.assertRaises(ValueError):
                    coordinator._environment(environment, 640, True)


class RecoveryCoordinatorTests(unittest.TestCase):
    def setUp(self):
        # Durability has dedicated ledger tests; CPU contract fixtures omit
        # physical fsync while maintaining actual journal writes and hashes.
        proxy = SimpleNamespace(name=ledger_module.os.name, fstat=ledger_module.os.fstat, fsync=lambda _: None)
        self.durability_patch = patch.object(ledger_module, "os", proxy)
        self.durability_patch.start()
        self.addCleanup(self.durability_patch.stop)
    def test_full_five_group_population_reuses_audit_geometry_and_first_group_only(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            result = fixture.run(registration)
            self.assertEqual(result["status"], "passed_fixture_only", result)
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES))
            self.assertEqual((fixture.audit_calls, fixture.geometry_calls), (1, 1))
            self.assertEqual(result["final_budget"]["prediction_calls"], 3205)
            self.assertEqual(result["final_budget"]["formal_calls"], 3200)
            self.assertEqual(result["final_budget"]["warmup_calls"], 5)
            directory = Path(registration["task_directory"])
            self.assertFalse((directory / "completion.json").exists())
            self.assertFalse((directory / "groups" / "fault_960" / "completion.json").exists())
            for name in ("reference_640", "reference_960", "fault_640", "resume_960"):
                self.assertTrue((directory / "groups" / name / "completion.json").is_file())
            before = coordinator.read(directory / "fault_tree_before_resume.json")
            after = coordinator.read(directory / "fault_tree_after_resume.json")
            self.assertEqual(before, after)
            self.assertEqual(coordinator.read(directory / "resume_receipt.json")["recovery_attempt"], 1)
            self.assertIs(result["real_recovery_accepted"], False)

    def test_exclusive_registration_and_execution_do_not_overwrite_old_evidence(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            before = (directory / "registration.json").read_bytes()
            with self.assertRaises(FileExistsError):
                fixture.prepare()
            self.assertEqual((directory / "registration.json").read_bytes(), before)
            coordinator.write(directory / "execution_claim.json", {"fixture": "already claimed"})
            with self.assertRaises(FileExistsError):
                fixture.run(registration)
            self.assertEqual(fixture.audit_calls, 0)

    def test_clock_origin_precedes_audit_and_expiry_does_not_reset_or_predict(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            fixture.hooks["audit"] = lambda: setattr(fixture.clock, "epoch", 2800.)
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["original_deadline_epoch"], 2800.)
            self.assertEqual(fixture.steps, [])
            self.assertEqual(fixture.geometry_calls, 0)

    def test_source_hash_change_refuses_before_audit_or_inference(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            fixture.inputs_file.write_text("changed input bytes", encoding="utf-8")
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.audit_calls, 0)
            self.assertEqual(fixture.steps, [])

    def test_resealed_registration_is_not_accepted_under_original_receipt(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            mutated = coordinator.read(directory / "registration.json")
            mutated["started_epoch"] = 1001.
            (directory / "registration.json").write_text(json.dumps(mutated), encoding="utf-8")
            with self.assertRaises(ValueError):
                fixture.run(registration)
            self.assertEqual(fixture.steps, [])

    def test_fixture_backend_cannot_claim_it_is_a_real_detector(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            fixture.hooks["environment"] = lambda env: env.update(fixture_only=False, real_detector_used=True)
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.steps, ["reference_640"])
            self.assertNotIn("resume_960", fixture.steps)

    def test_unknown_predict_cost_never_reaches_resume(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()

            def unknown(directory, ledger):
                ticket = ledger.reserve("warmup", "fault_960", fixture.rows[0]["image_id"], 960)
                ledger.closed(ticket, "failed", .01, None, cost_known=False)
                raise RuntimeError("fixture unknown CUDA cost")

            fixture.hooks["fault_960"] = unknown
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertNotIn("resume_960", fixture.steps)
            self.assertIs(result["ledger"]["cost_known"], False)
            self.assertFalse((Path(registration["task_directory"]) / "completion.json").exists())

    def test_corrupt_completed_640_reuse_refuses_before_resume(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            taskdir = Path(registration["task_directory"])

            def corrupt(directory, ledger):
                (taskdir / "groups" / "fault_640" / "metrics.json").write_text("{}", encoding="utf-8")

            fixture.hooks["fault_960"] = corrupt
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertNotIn("resume_960", fixture.steps)
            self.assertTrue((taskdir / "fault" / "failure.json").is_file())

    def test_verifier_refusal_prevents_parent_completion_after_all_groups(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            fixture.hooks["verifier"] = lambda directory: {"status": "failed", "checks": {"fixture_check": False}, "errors": ["injected verifier refusal"]}
            result = fixture.run(registration)
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES))
            self.assertFalse((Path(registration["task_directory"]) / "completion.json").exists())
            self.assertEqual(fixture.verifier_calls, 1)

    def test_staged_gate_failure_wait_and_single_resume_reopen_the_same_ledger(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            dependencies = fixture.dependencies()
            preflight = coordinator.run_preflight(directory, test_dependencies=dependencies)
            self.assertEqual(preflight["status"], "preflight_passed", preflight)
            self.assertEqual(fixture.steps, [])
            self.assertEqual((fixture.audit_calls, fixture.geometry_calls), (1, 1))
            pending = coordinator.run_until_fault(directory, test_dependencies=dependencies)
            self.assertEqual(pending["status"], "recovery_pending", pending)
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES)[:4])
            self.assertEqual(pending["ledger"]["prediction_calls"], 2564)
            self.assertIs(pending["automatic_recovery"], False)
            self.assertFalse((directory / "groups" / "resume_960").exists())
            with ledger_module.Ledger(directory, coordinator.read(directory / "ledger_registration.json"), clock=fixture.clock) as inspected:
                self.assertEqual(inspected.summary()["prediction_calls"], 2564)
            original_fault = coordinator.read(directory / "fault_tree_before_resume.json")
            fixture.clock.advance(.5)
            result = coordinator.resume_task(directory, test_dependencies=dependencies)
            self.assertEqual(result["status"], "passed_fixture_only", result)
            self.assertEqual(result["execution_mode"], "explicit_staged_research")
            self.assertEqual(result["final_budget"]["prediction_calls"], 3205)
            self.assertEqual((fixture.audit_calls, fixture.geometry_calls), (1, 1))
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES))
            self.assertEqual(coordinator.read(directory / "fault_tree_after_resume.json"), original_fault)
            self.assertEqual(coordinator.read(directory / "registration.json")["deadline_epoch"], registration["deadline_epoch"])
            self.assertFalse((directory / "completion.json").exists())
            with self.assertRaises(FileExistsError):
                coordinator.resume_task(directory, test_dependencies=dependencies)

    def test_late_preflight_gate_mutation_refuses_all_prediction(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            coordinator.run_preflight(directory, test_dependencies=fixture.dependencies())
            (directory / "audit" / "task" / "audit_result.json").write_text("{}", encoding="utf8")
            result = coordinator.run_until_fault(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.steps, [])
            self.assertFalse((directory / "pending_recovery_receipt.json").exists())

    def test_original_pending_deadline_expiry_never_opens_a_resume_prediction(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            coordinator.run_preflight(directory, test_dependencies=fixture.dependencies())
            pending = coordinator.run_until_fault(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(pending["status"], "recovery_pending", pending)
            journal = (directory / "shared_prediction_journal.jsonl").read_bytes()
            fixture.clock.epoch = registration["deadline_epoch"]
            with self.assertRaises(RuntimeError):
                coordinator.resume_task(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES)[:4])
            self.assertEqual((directory / "shared_prediction_journal.jsonl").read_bytes(), journal)
            self.assertFalse((directory / "groups" / "resume_960").exists())

    def test_late_input_change_while_waiting_refuses_recovery(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            coordinator.run_preflight(directory, test_dependencies=fixture.dependencies())
            pending = coordinator.run_until_fault(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(pending["status"], "recovery_pending", pending)
            fixture.inputs_file.write_text("late input replacement", encoding="utf8")
            result = coordinator.resume_task(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES)[:4])
            self.assertFalse((directory / "groups" / "resume_960").exists())

    def test_original_incomplete_second_step_is_immutable_during_pending_wait(self):
        with temporary_workspace() as root:
            fixture = Fixture(root, fast_journal_checks=True)
            registration = fixture.prepare()
            directory = Path(registration["task_directory"])
            coordinator.run_preflight(directory, test_dependencies=fixture.dependencies())
            pending = coordinator.run_until_fault(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(pending["status"], "recovery_pending", pending)
            (directory / "groups" / "fault_960" / "metrics.json").write_text("{}", encoding="utf8")
            result = coordinator.resume_task(directory, test_dependencies=fixture.dependencies())
            self.assertEqual(result["status"], "failed")
            self.assertEqual(fixture.steps, list(coordinator.STEP_SIZES)[:4])
            self.assertFalse((directory / "groups" / "resume_960").exists())


if __name__ == "__main__":
    unittest.main()
