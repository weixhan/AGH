"""Independent checker tests use real isolated geometry and tampered evidence."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

from defect_researcher.geometry_verifier import verify_label_geometry
from defect_researcher import research_domain_v1 as domain
from defect_researcher.research_protocol_v1 import BudgetLedger
from defect_researcher.config import load_config
from defect_researcher.research_workflow_v1 import run_workflow
from test_config import temporary_workspace
from test_geometry_verifier import geometry_configuration

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("workflow_v1_independent_checker", ROOT / "tools" / "verify_research_workflow_v1.py")
checker = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(checker)


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def reseal_domain(directory):
    manifest = checker.read(directory / "artifact_manifest.json")
    for row in manifest["files"]:
        target = Path(row["path"])
        row["sha256"] = checker.digest(target)
        row["size_bytes"] = target.stat().st_size
    write(directory / "artifact_manifest.json", manifest)
    marker = checker.read(directory / "completion.json")
    marker["artifact_manifest_sha256"] = checker.digest(directory / "artifact_manifest.json")
    marker["artifacts_sha256"] = {row["name"]: row["sha256"] for row in manifest["files"]}
    write(directory / "completion.json", marker)


def rehash_budget(path, rows):
    previous = "0" * 64
    for index, row in enumerate(rows):
        row["sequence"] = index
        row["previous_sha256"] = previous
        unsigned = {key: value for key, value in row.items() if key != "sha256"}
        row["sha256"] = hashlib.sha256(checker.canonical(unsigned)).hexdigest()
        previous = row["sha256"]
    path.write_bytes(b"".join(checker.canonical(row) + b"\n" for row in rows))


def reseal_workflow(directory):
    manifest = checker.read(directory / "artifact_manifest.json")
    for row in manifest["files"]:
        path = Path(row["path"])
        row["sha256"] = checker.digest(path)
        row["size_bytes"] = path.stat().st_size
    write(directory / "artifact_manifest.json", manifest)
    marker = checker.read(directory / "completion.json")
    marker["artifact_manifest_sha256"] = checker.digest(directory / "artifact_manifest.json")
    marker["artifacts_sha256"] = {row["name"]: row["sha256"] for row in manifest["files"]}
    write(directory / "completion.json", marker)


class CompleteWorkflowChecks(unittest.TestCase):
    def run_fixture(self, root, *, case="normal_quarter_turn", cap=6):
        config = load_config()
        config["output_root"] = str(root / "outputs")
        request = {"schema_version": 1, "workflow_version": 1, "request_id": "independent-checker-fixture",
                   "case_id": case, "budget": {"domain_invocations": cap, "wall_seconds": 120.0, "gpu_seconds": 0, "model_requests": 0}}
        result = run_workflow(request, config)
        self.assertEqual(result["status"], "completed", result.get("error"))
        directory = Path(result["directory"])
        report = checker.verify(directory)
        self.assertEqual(report["status"], "passed", report.get("errors"))
        return directory, result

    def test_actual_normal_workflow_passes_saved_independent_review(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            self.assertEqual(result["research_status"], "stopped")
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry", "read_scientific_evidence"])

    def test_actual_repair_workflow_changes_tool_path_and_stops_known_candidate(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="repair_metadata_rotation")
            self.assertEqual(result["domain_invocations"], 6)
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence"])

    def test_actual_missing_label_guard_preserves_failure_and_allows_verified_copy(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="repair_missing_label")
            initial = checker.read(directory / "evidence.json")["entries"][0]["domain"]
            self.assertEqual(initial["execution_status"], "failed")
            self.assertFalse((Path(initial["task_dir"]) / "completion.json").exists())
            self.assertEqual(result["research_status"], "stopped")

    def test_rehashed_failed_repair_acceptance_row_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="repair_class")
            evidence = checker.read(directory / "evidence.json")
            repair = next(row for row in evidence["entries"] if row["kind"] == "repair")
            repair["domain"]["acceptance_checks"]["changes_match_frozen_case_scope"] = False
            write(directory / "evidence.json", evidence)
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("did not all pass", checked["errors"][0]["message"])

    def test_rehashed_missing_label_guard_broadened_scope_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="repair_missing_label")
            evidence = checker.read(directory / "evidence.json")
            evidence["entries"][0]["domain"]["source_guard"]["planned_changed_files"].append("metadata/train/image_1.json")
            write(directory / "evidence.json", evidence)
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("exactly one absent label", checked["errors"][0]["message"])

    def test_actual_untrusted_source_refuses_without_repair_or_science(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="refuse_source_hash")
            self.assertEqual(result["research_status"], "refused")
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry"])

    def test_zero_budget_is_honest_insufficient_evidence_completion(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, cap=0)
            self.assertEqual(result["research_status"], "insufficient_evidence")
            self.assertEqual(result["actual_tool_path"], [])

    def test_exhausted_repair_budget_stops_before_fresh_copy_check(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, case="repair_class", cap=4)
            self.assertEqual(result["research_status"], "insufficient_evidence")
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry", "repair_label_copy"])

    def test_rehashed_invented_claim_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            claims = checker.read(directory / "claims.json")
            claim = next(row for row in claims["claims"] if row["field"] == "summary.relative_small.tp_960")
            claim["value"] = 94
            write(directory / "claims.json", claims)
            report = (directory / "report.md").read_text(encoding="utf-8")
            report = report.replace(f"- {claim['claim_id']}: 13 ", f"- {claim['claim_id']}: 94 ")
            (directory / "report.md").write_text(report, encoding="utf-8")
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("Claim value contradicts", checked["errors"][0]["message"])

    def test_rehashed_illegal_transition_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            rows = checker.lines(directory / "events.jsonl")
            rows[1]["from_state"] = "verified"
            (directory / "events.jsonl").write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("state sequence", checked["errors"][0]["message"])

    def test_rehashed_small_definition_mix_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            evidence = checker.read(directory / "evidence.json")
            summary = next(row for row in evidence["entries"] if row["kind"] == "science")["summary"]
            summary["relative_small"] = summary["tiny_small"]
            write(directory / "evidence.json", evidence)
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("mixes definitions", checked["errors"][0]["message"])

    def test_rehashed_source_registry_omission_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            registry = checker.read(directory / "source_registry.json")
            registry["files"] = registry["files"][:-1]
            write(directory / "source_registry.json", registry)
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("exact 18", checked["errors"][0]["message"])

    def test_original_case_byte_change_after_completion_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root)
            prepared = checker.read(directory / "input_case.json")
            label = Path(prepared["configuration"]["dataset_root"]) / "labels" / "train" / "image_1.txt"
            label.write_bytes(b"0 0.0 0.0 1.0 1.0")
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("Input snapshot", checked["errors"][0]["message"])

    def test_fake_engineering_marker_without_independent_pass_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, cap=0)
            report = checker.read(directory / "independent_verification.json")
            report["status"] = "failed"
            write(directory / "independent_verification.json", report)
            reseal_workflow(directory)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("passed independent", checked["errors"][0]["message"])

    def test_late_completion_marker_is_refused(self):
        with temporary_workspace() as root:
            directory, result = self.run_fixture(root, cap=0)
            marker = checker.read(directory / "completion.json")
            marker["completed_epoch"] = marker["original_deadline_epoch"]
            write(directory / "completion.json", marker)
            checked = checker.verify(directory)
            self.assertEqual(checked["status"], "failed")
            self.assertIn("original publication budget", checked["errors"][0]["message"])


class BudgetAndReportChecks(unittest.TestCase):
    def budget_fixture(self, root, *, close=True):
        directory = root / "research-workflow-v1-workflow"
        request = {"schema_version": 1, "workflow_version": 1, "request_id": "workflow", "case_id": "normal_unrotated",
                   "budget": {"domain_invocations": 6, "wall_seconds": 120.0, "gpu_seconds": 0, "model_requests": 0}}
        ledger = BudgetLedger(directory, request)
        token = ledger.reserve("verify_label_geometry", 1)
        if close:
            ledger.close(token, 1)
        snapshot = ledger.snapshot()
        start = checker.lines(directory / "budget.jsonl")[0]["record"]
        runtime = {key: start[key] for key in ("started_epoch", "deadline_epoch", "started_monotonic", "deadline_monotonic")}
        runtime.update({"schema_version": 1, "workflow_id": directory.name, "budget": request["budget"]})
        write(directory / "runtime.json", runtime)
        write(directory / "result.json", {"final_budget": snapshot})
        write(directory / "request.json", request)
        write(directory / "protocol.json", checker.read(ROOT / "fixtures" / "research_workflow_protocol_v1.json"))
        return directory, request

    def test_budget_replays_real_reserved_and_closed_receipt(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            report = checker.budget_replay(directory, request, prepublication=True)
            self.assertEqual(report["used"], 1)
            self.assertEqual(report["actions"], ["verify_label_geometry"])

    def test_open_unknown_cost_cannot_be_completed(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root, close=False)
            with self.assertRaisesRegex(ValueError, "Open/unknown"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_modified_hash_link_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            rows[1]["sha256"] = "0" * 64
            (directory / "budget.jsonl").write_bytes(b"".join(checker.canonical(row) + b"\n" for row in rows))
            with self.assertRaisesRegex(ValueError, "hash chain"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_rehashed_original_deadline_extension_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            rows[0]["record"]["deadline_epoch"] += 120
            rows[0]["record"]["deadline_monotonic"] += 120
            rehash_budget(directory / "budget.jsonl", rows)
            with self.assertRaisesRegex(ValueError, "deadline was reset"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_rehashed_overlapping_reservation_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            rows.insert(2, json.loads(json.dumps(rows[1])))
            rehash_budget(directory / "budget.jsonl", rows)
            with self.assertRaisesRegex(ValueError, "reservation overlaps"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_rehashed_close_actual_cost_mismatch_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            rows[2]["record"]["actual_cost"] = 0
            rehash_budget(directory / "budget.jsonl", rows)
            with self.assertRaisesRegex(ValueError, "cost was hidden"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_rehashed_reopening_ledger_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            rows.append(json.loads(json.dumps(rows[0])))
            rehash_budget(directory / "budget.jsonl", rows)
            with self.assertRaisesRegex(ValueError, "reopening"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_rehashed_expired_closed_receipt_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            rows = checker.lines(directory / "budget.jsonl")
            start = rows[0]["record"]
            close = rows[2]["record"]
            close.update({"current_monotonic": start["deadline_monotonic"], "current_epoch": start["deadline_epoch"],
                          "elapsed_wall_seconds": request["budget"]["wall_seconds"], "expired": True})
            rehash_budget(directory / "budget.jsonl", rows)
            with self.assertRaisesRegex(ValueError, "Expired budget"):
                checker.budget_replay(directory, request, prepublication=True)

    def test_boolean_request_domain_count_is_refused(self):
        with temporary_workspace() as root:
            directory, request = self.budget_fixture(root)
            request["budget"]["domain_invocations"] = True
            write(directory / "request.json", request)
            with self.assertRaisesRegex(ValueError, "budget exceeds"):
                checker.request_and_protocol(directory)

    def test_claim_boolean_cannot_impersonate_integer(self):
        with temporary_workspace() as root:
            request = {"request_id": "workflow", "case_id": "normal_unrotated"}
            entries = [{"evidence_id": "g", "summary": {"issue_count": 1}}]
            result = {"claims_count": 1, "research_status": "stopped", "workflow_id": "workflow"}
            plan = {"next_action": "stop_no_registered_candidate"}
            write(root / "claims.json", {"claims": [{"claim_id": "c", "evidence_id": "g", "field": "summary.issue_count", "value": True}]})
            with self.assertRaisesRegex(ValueError, "Claim value contradicts"):
                checker.report_claims(root, request, entries, result, plan)

    def test_unsupported_claim_field_is_refused(self):
        with temporary_workspace() as root:
            request = {"request_id": "workflow", "case_id": "normal_unrotated"}
            entries = [{"evidence_id": "g", "summary": {"issue_count": 1}}]
            result = {"claims_count": 1, "research_status": "stopped", "workflow_id": "workflow"}
            plan = {"next_action": "stop_no_registered_candidate"}
            write(root / "claims.json", {"claims": [{"claim_id": "c", "evidence_id": "g", "field": "summary.training_accuracy", "value": 1}]})
            with self.assertRaisesRegex(ValueError, "Claim field is absent"):
                checker.report_claims(root, request, entries, result, plan)

    def test_report_invented_text_is_refused(self):
        with temporary_workspace() as root:
            request = {"request_id": "workflow", "case_id": "normal_unrotated"}
            result = {"claims_count": 0, "research_status": "insufficient_evidence", "workflow_id": "workflow"}
            plan = {"next_action": "stop_budget"}
            write(root / "claims.json", {"claims": []})
            (root / "report.md").write_text("Independent success 100% autonomous research", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "unsupported text"):
                checker.report_claims(root, request, [], result, plan)


class DomainIndependentChecks(unittest.TestCase):
    def saved_geometry(self, root):
        config = geometry_configuration(root)
        result = verify_label_geometry(config, "verified")
        self.assertEqual(result["status"], "completed", result.get("errors"))
        return config, Path(config["output_root"]) / "verified"

    def test_actual_isolated_geometry_passes(self):
        with temporary_workspace() as root:
            config, directory = self.saved_geometry(root)
            self.assertEqual(checker.geometry(directory, "passed")["summary"]["verification_status"], "passed")

    def test_source_byte_drift_is_refused(self):
        with temporary_workspace() as root:
            config, directory = self.saved_geometry(root)
            (Path(config["raw_root"]) / "cable_1.json").write_bytes(b"{}")
            with self.assertRaisesRegex(ValueError, "source hash"):
                checker.geometry(directory)

    def test_rehashed_false_passed_annotation_is_refused(self):
        with temporary_workspace() as root:
            config, directory = self.saved_geometry(root)
            path = directory / "geometry_details.jsonl"
            rows = checker.lines(path)
            next(row for row in rows if row["record_type"] == "annotation")["status"] = "failed"
            path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            reseal_domain(directory)
            with self.assertRaisesRegex(ValueError, "detail rows"):
                checker.geometry(directory)

    def test_missing_annotation_population_is_refused_after_rehash(self):
        with temporary_workspace() as root:
            config, directory = self.saved_geometry(root)
            path = directory / "geometry_details.jsonl"
            rows = [row for row in checker.lines(path) if row["record_type"] != "annotation"]
            path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            reseal_domain(directory)
            with self.assertRaisesRegex(ValueError, "population"):
                checker.geometry(directory)

    def test_independent_vertices_refuse_forged_label_even_if_rehashed(self):
        with temporary_workspace() as root:
            config, directory = self.saved_geometry(root)
            label = Path(config["dataset_root"]) / "labels" / "train" / "image_1.txt"
            label.write_text("0 0.4 0.35 0.4 0.1", encoding="utf-8")
            path = directory / "input_manifest.json"
            inputs = checker.read(path)
            row = next(row for row in inputs["files"] if Path(row["path"]) == label)
            row["sha256_before"] = row["sha256_after"] = checker.digest(label)
            row["size_bytes"] = label.stat().st_size
            write(path, inputs)
            reseal_domain(directory)
            with self.assertRaisesRegex(ValueError, "Independent label geometry"):
                checker.geometry(directory)

    def test_duplicate_json_keys_are_refused(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            checker.decode('{"status":"failed","status":"passed"}')

    def test_nonfinite_and_overflow_json_are_refused(self):
        for value in ('{"x":NaN}', '{"x":Infinity}', '{"x":1e400}'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                checker.decode(value)

    def test_checker_imports_only_standard_library(self):
        tree = ast.parse((ROOT / "tools" / "verify_research_workflow_v1.py").read_text(encoding="utf-8"))
        imports = [node.module or "" for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
        imports += [alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names]
        self.assertFalse(any("defect_researcher" in name or "research_workflow" in name for name in imports))

    def test_actual_repair_and_fresh_copy_recheck_are_independently_accepted(self):
        research = Path("E:/PythonProject/projects/cableinspect-ad-code/project_start")
        with temporary_workspace() as root:
            prepared = domain.prepare_case(root / "inputs", "repair_coordinates", research)
            workflow = root / "workflow"
            original = domain.verify_case(prepared, workflow / "initial", "initial")
            repaired = domain.repair_case(prepared, workflow / "repairs", "repair")
            fresh = domain.verify_copy(prepared, repaired, workflow / "copy", "copy")
            for kind, proof in (("geometry", original), ("repair", repaired), ("copy_geometry", fresh)):
                entry = {"kind": kind, "origin": "new_execution", "domain": proof, "summary": proof["summary"]}
                verified = checker.domain_evidence(entry, prepared, workflow)
                self.assertEqual(verified["status"], "failed" if kind == "geometry" else "passed")
            self.assertEqual(checker.repair(Path(repaired["task_dir"]))["summary"]["changed_files"], 1)

    def test_initial_missing_label_keeps_failed_execution_proof_then_repairs_copy(self):
        research = Path("E:/PythonProject/projects/cableinspect-ad-code/project_start")
        with temporary_workspace() as root:
            prepared = domain.prepare_case(root / "inputs", "repair_missing_label", research)
            workflow = root / "workflow"
            original = domain.verify_case(prepared, workflow / "initial", "initial")
            repaired = domain.repair_case(prepared, workflow / "repairs", "repair")
            entry = {"kind": "geometry", "origin": "new_execution", "domain": original, "summary": original["summary"]}
            self.assertEqual(checker.domain_evidence(entry, prepared, workflow)["status"], "execution_failed")
            entry = {"kind": "repair", "origin": "new_execution", "domain": repaired, "summary": repaired["summary"]}
            self.assertEqual(checker.domain_evidence(entry, prepared, workflow)["status"], "passed")

    def test_saved_science_definitions_are_recalculated_separately(self):
        statistics = checker.independently_count_saved_small(ROOT / "outputs" / "8d1d6900c7d74c90a29824495684807d")
        self.assertEqual(statistics["640"]["scale_definitions"]["plan_area_ratio_lt_0_005"]["gt"], 94)
        self.assertEqual(statistics["960"]["scale_definitions"]["plan_area_ratio_lt_0_005"]["tp"], 13)
        self.assertEqual(statistics["640"]["scale_definitions"]["implemented_area_lt_1024_px2"]["gt"], 4)
        self.assertEqual(statistics["960"]["scale_definitions"]["implemented_area_lt_1024_px2"]["tp"], 0)


if __name__ == "__main__":
    unittest.main()
