"""Independent manual control oracles for version 3 slicing evidence.

These tests use recorded dictionaries only. They perform no prediction, create
no detector, and do not substitute two images for the full scientific population.
"""
from __future__ import annotations

from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "independent_sliced_evidence_v3", ROOT / "tools" / "verify_sliced_run_v3.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)


def controls():
    # Explicit manual oracle, not a copy of the production control helper.
    return {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
            "rect": False, "augment": False, "agnostic_nms": False,
            "quantize": None, "nms": None}


class Version3IndependentControlTests(unittest.TestCase):
    def test_explicit_null_external_nms_passes(self):
        self.assertTrue(reviewer.strict_external_nms(controls(), controls()))

    def test_reference_nms_missing_is_rejected(self):
        reference = controls()
        del reference["nms"]
        self.assertFalse(reviewer.strict_external_nms(controls(), reference))

    def test_actual_nms_missing_is_rejected(self):
        actual = controls()
        del actual["nms"]
        self.assertFalse(reviewer.strict_external_nms(actual, controls()))

    def test_both_missing_cannot_be_equated_with_null(self):
        actual = controls()
        del actual["nms"]
        self.assertFalse(reviewer.strict_external_nms(actual, deepcopy(actual)))

    def test_all_non_null_nms_types_rejected_on_each_side(self):
        for value in (False, True, 0, 1, .0, "null", "None", "false", [], {}):
            changed = {**controls(), "nms": value}
            for actual, reference in ((changed, controls()), (controls(), changed),
                                      (changed, deepcopy(changed))):
                with self.subTest(value=value, actual=actual, reference=reference):
                    self.assertFalse(reviewer.strict_external_nms(actual, reference))

    def test_control_dictionaries_are_required(self):
        for value in (None, False, [], "null"):
            with self.subTest(value=value):
                self.assertFalse(reviewer.strict_external_nms(value, controls()))
                self.assertFalse(reviewer.strict_external_nms(controls(), value))

    def test_missing_other_control_cannot_pass_reference_equality(self):
        for key in controls():
            changed = controls()
            del changed[key]
            with self.subTest(key=key):
                self.assertFalse(reviewer.strict_external_nms(changed, deepcopy(changed)))

    def test_other_control_changes_rejected_even_when_both_match(self):
        mutations = {"imgsz": 960, "batch": True, "conf": .25, "iou": .5,
                     "max_det": 301, "rect": 0, "augment": True,
                     "agnostic_nms": True, "quantize": False}
        for key, value in mutations.items():
            changed = {**controls(), key: value}
            with self.subTest(key=key):
                self.assertFalse(reviewer.strict_external_nms(changed, deepcopy(changed)))

    def test_recorded_option_dictionaries_must_match_exactly(self):
        changed = {**controls(), "unregistered_option": None}
        self.assertFalse(reviewer.strict_external_nms(changed, controls()))
        self.assertFalse(reviewer.strict_external_nms(controls(), changed))
        self.assertFalse(reviewer.strict_external_nms(changed, deepcopy(changed)))

    def test_integer_control_types_cannot_be_resealed_as_floats(self):
        for key in ("imgsz", "batch", "max_det"):
            changed = {**controls(), key: float(controls()[key])}
            for actual, reference in ((changed, controls()), (controls(), changed),
                                      (changed, deepcopy(changed))):
                with self.subTest(key=key):
                    self.assertFalse(reviewer.strict_external_nms(actual, reference))

    def test_nonfinite_options_are_rejected(self):
        for value in (float("nan"), float("inf"), -float("inf")):
            changed = {**controls(), "conf": value}
            with self.subTest(value=value):
                self.assertFalse(reviewer.strict_external_nms(changed, deepcopy(changed)))

    def test_contains_requires_null_key_presence(self):
        self.assertTrue(reviewer.contains({"nms": None}, {"nms": None}, 0))
        self.assertFalse(reviewer.contains({}, {"nms": None}, 0))
        self.assertFalse(reviewer.contains({"nms": False}, {"nms": None}, 0))

    def test_new_tool_and_exact_integer_version_pass(self):
        self.assertTrue(reviewer.version_3_execution(
            {"tool": "compare_validation_slices_v3", "execution_io_version": 3}))

    def test_execution_version_missing_or_wrong_type_rejected(self):
        for value in (None, False, True, 2, 4, 3., "3"):
            with self.subTest(value=value):
                self.assertFalse(reviewer.version_3_execution(
                    {"tool": "compare_validation_slices_v3", "execution_io_version": value}))
        self.assertFalse(reviewer.version_3_execution({"tool": "compare_validation_slices_v3"}))

    def test_legacy_or_unknown_tool_cannot_use_version3(self):
        for tool in (None, "compare_validation_slices", "compare_validation_slices_v4", True):
            with self.subTest(tool=tool):
                self.assertFalse(reviewer.version_3_execution(
                    {"tool": tool, "execution_io_version": 3}))

    def test_existing_nine_pass_scientific_grid_is_preserved(self):
        self.assertEqual(reviewer.expected_crops(), [
            [0, 0, 1920, 1080], [0, 0, 640, 640], [512, 0, 1152, 640],
            [1024, 0, 1664, 640], [1280, 0, 1920, 640], [0, 440, 640, 1080],
            [512, 440, 1152, 1080], [1024, 440, 1664, 1080], [1280, 440, 1920, 1080]])

    def test_independent_json_rejects_ambiguous_or_nonfinite_controls(self):
        for value in ('{"nms":null,"nms":false}', '{"conf":NaN}', '{"conf":1e400}'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                reviewer.decode(value)


if __name__ == "__main__":
    unittest.main()
