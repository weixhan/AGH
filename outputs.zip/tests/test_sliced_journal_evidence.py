"""Hand-built durability oracles and adversarial, resealed journal evidence."""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import unittest
import uuid

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("manual_independent_journal", ROOT / "tools" / "verify_sliced_journal.py")
reviewer = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(reviewer)


@contextmanager
def scratch():
    root = ROOT / "outputs"
    directory = root / f"journal-evidence-test-{uuid.uuid4().hex}"
    directory.mkdir()
    try:
        yield directory
    finally:
        if directory.resolve().parent != root.resolve() or not directory.name.startswith("journal-evidence-test-"):
            raise ValueError("Unsafe scratch cleanup")
        shutil.rmtree(directory)


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


def sha(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def save(path, value):
    path.write_bytes(canonical(value) + b"\n")


def rows_write(directory, records):
    head = "0" * 64
    for row in records:
        row["previous_sha256"] = head
        body = {k: v for k, v in row.items() if k != "sha256"}
        row["sha256"] = sha(body)
        head = row["sha256"]
    (directory / reviewer.JOURNAL_FILE).write_bytes(b"".join(canonical(row) + b"\n" for row in records))


def fixture(directory):
    """Manually specified two-observation experiment, with no detector/import."""
    rules = {**reviewer.CAPS, "successful_observations": 2, "max_formal_calls": 12}
    protocol = {"budgets": rules}
    identity = {k: chr(97 + i) * 64 for i, k in enumerate(sorted(reviewer.IDENTITY))}
    t0 = datetime(2026, 10, 11, 3, tzinfo=timezone.utc).timestamp()
    budget = {"schema_version": 1, "task_started_epoch": t0, "inference_started_epoch": None,
        "formal_attempts": [], "warmup_attempts": [], "formal_calls": 0, "warmup_calls": 0,
        "successful_observations": 0, "gpu_seconds": 0., "task_wall_seconds": 0.,
        "inference_wall_seconds": 0., "resumable": True, "resume_chain": [], "wall_segments": []}
    # Sorted identity produces a..e, all valid SHA hex.
    records, entries, observations = [], [], []
    def add(event, payload):
        records.append({"sequence": len(records) + 1, "previous_sha256": "", "event": event,
                        "payload": deepcopy(payload), "sha256": ""})
    def wall():
        return {k: deepcopy(budget[k]) for k in reviewer.WALL}
    def utc(epoch):
        return datetime.fromtimestamp(epoch, timezone.utc).isoformat()
    add("header", {"journal_version": 2, "identity": identity, "limits": rules, "initial_budget": budget})
    (directory / "checkpoints").mkdir()
    for i, kind in enumerate(("warmup", "formal", "formal")):
        pi = 0 if kind == "warmup" else i - 1
        started = t0 + i + 1
        if budget["inference_started_epoch"] is None:
            budget["inference_started_epoch"] = started
        budget["task_wall_seconds"] = started - t0
        budget["inference_wall_seconds"] = started - budget["inference_started_epoch"]
        row = {"call_index": 1 if kind == "warmup" else i, "image_id": "a", "pass_id": pi,
            "status": "started", "utc_started": utc(started), "utc_finished": None,
            "elapsed_seconds": None, "gpu_seconds": None}
        add("started", {"kind": kind, "attempt": row, "wall": wall()})
        budget[f"{kind}_calls"] += 1
        row.update(status="passed", utc_finished=utc(started + .2), elapsed_seconds=.2, gpu_seconds=.1)
        budget["gpu_seconds"] += .1
        budget["task_wall_seconds"] = started + .2 - t0
        budget["inference_wall_seconds"] = started + .2 - budget["inference_started_epoch"]
        add("finished", {"kind": kind, "attempt": row, "wall": wall()})
        budget[f"{kind}_attempts"].append(deepcopy(row))
        if kind == "formal":
            inputs = {"image_id": "a", "pass_id": pi, **{k: identity[k] for k in (
                "protocol_sha256", "weight_sha256", "scientific_inputs_sha256")},
                "source_image_sha256": "1" * 64, "decoded_image_sha256": "2" * 64, "input_pixels_sha256": "3" * 64}
            observed = {**inputs, "call_index": i, "elapsed_seconds": .2, "gpu_seconds": .1,
                "environment_identity": "4" * 64, "local_predictions": [], "global_predictions": []}
            relative = f"checkpoints/0000-{pi}.json"
            save(directory / relative, {"identity": inputs, "environment_identity": "4" * 64,
                "observation": observed, "observation_sha256": sha(observed)})
            entry = {"image_id": "a", "pass_id": pi, "call_index": i, "relative_path": relative,
                "sha256": hashlib.sha256((directory / relative).read_bytes()).hexdigest(),
                "size_bytes": (directory / relative).stat().st_size}
            add("checkpoint", {"entry": entry, "wall": wall()})
            entries.append(entry)
            observations.append(observed)
            budget["successful_observations"] += 1
    final = {k: v for k, v in budget.items() if k not in {"formal_attempts", "warmup_attempts", *reviewer.WALL}}
    add("closed", {"status": "completed", "wall": wall(), "final_fields": final})
    rows_write(directory, records)
    budget.update(journal_version=2, journal_events=len(records), journal_sha256=records[-1]["sha256"],
        journal_bytes=(directory / reviewer.JOURNAL_FILE).stat().st_size)
    index = {"schema_version": 1, "checkpoints": entries, "journal_version": 2,
        "journal_events": len(records), "journal_sha256": records[-1]["sha256"]}
    save(directory / "budget.json", budget)
    save(directory / "checkpoint_index.json", index)
    return protocol, identity, records, observations, t0


def failed_prefix(directory):
    value = fixture(directory)
    records = value[2][:6]
    initial = deepcopy(records[0]["payload"]["initial_budget"])
    initial.update(deepcopy(records[-1]["payload"]["wall"]))
    initial.update(formal_attempts=[deepcopy(records[4]["payload"]["attempt"])],
        warmup_attempts=[deepcopy(records[2]["payload"]["attempt"])],
        formal_calls=1, warmup_calls=1, successful_observations=1)
    final = {k: v for k, v in initial.items() if k not in {"formal_attempts", "warmup_attempts", *reviewer.WALL}}
    records.append({"sequence": 7, "previous_sha256": "", "sha256": "", "event": "closed",
        "payload": {"status": "failed", "wall": deepcopy(records[-1]["payload"]["wall"]), "final_fields": final}})
    rows_write(directory, records)
    initial.update(journal_version=2, journal_events=7, journal_sha256=records[-1]["sha256"],
        journal_bytes=(directory / reviewer.JOURNAL_FILE).stat().st_size)
    index = {"schema_version": 1, "checkpoints": [deepcopy(records[5]["payload"]["entry"])],
        "journal_version": 2, "journal_events": 7, "journal_sha256": records[-1]["sha256"]}
    save(directory / "budget.json", initial)
    save(directory / "checkpoint_index.json", index)
    save(directory / "failure.json", {"task_id": directory.name, "status": "failed", "reason": "Manual known-cost IO failure"})
    (directory / "checkpoints/0000-1.json").unlink()
    return value[0], value[1], records, value[3][:1], value[4]


def resume_prefix(parent, directory, value):
    directory.mkdir()
    shutil.copytree(parent / "checkpoints", directory / "checkpoints")
    records = deepcopy(value[2])
    prior_budget = json.loads((parent / "budget.json").read_text())
    prior_index = json.loads((parent / "checkpoint_index.json").read_text())
    binding = {"task_id": parent.name,
        **{key: hashlib.sha256((parent / name).read_bytes()).hexdigest() for key, name in (
            ("failure_sha256", "failure.json"), ("budget_sha256", "budget.json"),
            ("checkpoint_index_sha256", "checkpoint_index.json"), ("journal_file_sha256", reviewer.JOURNAL_FILE))},
        "journal_head_sha256": records[-1]["sha256"]}
    final = deepcopy(records[-1]["payload"]["final_fields"])
    final["resume_chain"].append(binding)
    final_wall = deepcopy(records[-1]["payload"]["wall"])
    final_wall["task_wall_seconds"] += .5
    final_wall["inference_wall_seconds"] += .5
    records.append({"sequence": len(records) + 1, "event": "resumed", "previous_sha256": "", "sha256": "",
        "payload": {"prior_journal_sha256": records[-1]["sha256"], "prior_journal_events": len(records),
            "prior_journal_bytes": (parent / reviewer.JOURNAL_FILE).stat().st_size,
            "wall": final_wall, "final_fields": final}})
    rows_write(directory, records)
    return value[0], value[1], records, deepcopy(value[3]), value[4]


class IndependentJournalEvidenceTests(unittest.TestCase):
    def verify(self, directory, value, **kwargs):
        protocol, identity, _, observations, _ = value
        return reviewer.verify_journal(directory, protocol, identity, observations=observations, **kwargs)

    def tamper(self, change, expected=None):
        with scratch() as directory:
            value = fixture(directory)
            change(directory, value)
            if expected:
                with self.assertRaisesRegex(reviewer.JournalVerificationError, expected):
                    self.verify(directory, value)
            else:
                with self.assertRaises(reviewer.JournalVerificationError):
                    self.verify(directory, value)

    def mutate(self, action, expected=None):
        def change(directory, value):
            action(value[2])
            rows_write(directory, value[2])
        self.tamper(change, expected)

    def test_manual_complete_oracle_has_ten_independent_checks(self):
        with scratch() as directory:
            value = fixture(directory)
            result = self.verify(directory, value)
            self.assertEqual(result["status"], "passed")
            self.assertEqual(len(result["checks"]), 10)
            self.assertTrue(all(result["checks"].values()))
            self.assertEqual(result["journal_events"], 10)
            self.assertAlmostEqual(result["replayed_budget"]["gpu_seconds"], .3)

    def test_independent_reader_never_imports_writer_or_predictor(self):
        source = (ROOT / "tools" / "verify_sliced_journal.py").read_text(encoding="utf-8")
        self.assertNotIn("from defect_researcher", source)
        self.assertNotIn("import sliced_journal", source)
        self.assertNotIn("import torch", source)

    def test_version_one_header_is_refused(self):
        self.mutate(lambda r: r[0]["payload"].update(journal_version=1), "header")

    def test_execution_source_changed_is_refused_even_when_resealed(self):
        self.mutate(lambda r: r[0]["payload"]["identity"].update(execution_source_sha256="0" * 64), "source")

    def test_writer_source_changed_is_refused_even_when_resealed(self):
        self.mutate(lambda r: r[0]["payload"]["identity"].update(journal_source_sha256="0" * 64), "source")

    def test_budget_relaxation_is_refused(self):
        self.mutate(lambda r: r[0]["payload"]["limits"].update(max_gpu_seconds=901), "limits")

    def test_old_calls_cannot_be_imported_into_header(self):
        self.mutate(lambda r: r[0]["payload"]["initial_budget"]["formal_attempts"].append({}), "Fresh")

    def test_sequence_duplicate_is_refused(self):
        self.mutate(lambda r: r[2].update(sequence=2), "sequence")

    def test_hash_chain_tamper_is_refused(self):
        def change(directory, value):
            value[2][2]["previous_sha256"] = "0" * 64
            (directory / reviewer.JOURNAL_FILE).write_bytes(b"".join(canonical(r) + b"\n" for r in value[2]))
        self.tamper(change, "chain")

    def test_line_hash_tamper_is_refused(self):
        def change(directory, value):
            value[2][2]["sha256"] = "0" * 64
            (directory / reviewer.JOURNAL_FILE).write_bytes(b"".join(canonical(r) + b"\n" for r in value[2]))
        self.tamper(change, "hash")

    def test_unfinished_tail_is_refused(self):
        self.tamper(lambda d, v: (d / reviewer.JOURNAL_FILE).write_bytes((d / reviewer.JOURNAL_FILE).read_bytes()[:-1]), "tail")

    def test_duplicate_json_field_is_refused(self):
        with self.assertRaises(reviewer.JournalVerificationError):
            reviewer.decode('{"sequence":1,"sequence":1}')

    def test_nonfinite_and_overflow_cost_is_refused(self):
        for value in ("NaN", "Infinity", "1e400"):
            with self.subTest(value=value), self.assertRaises(reviewer.JournalVerificationError):
                reviewer.decode(value)

    def test_finish_without_start_is_refused(self):
        self.mutate(lambda r: r[1].update(event="finished"), "matching")

    def test_concurrent_start_is_refused(self):
        self.mutate(lambda r: r[2].update(event="started"), "Concurrent")

    def test_changed_finish_identity_is_refused(self):
        self.mutate(lambda r: r[2]["payload"]["attempt"].update(pass_id=1), "identity")

    def test_call_indices_are_continuous(self):
        self.mutate(lambda r: r[3]["payload"]["attempt"].update(call_index=2), "duplicated")

    def test_actual_call_clock_cannot_go_backwards(self):
        self.mutate(lambda r: r[3]["payload"]["attempt"].update(utc_started="2026-10-11T02:00:00+00:00"), "clock")

    def test_absolute_start_cannot_be_reset(self):
        self.mutate(lambda r: r[3]["payload"]["wall"].update(inference_started_epoch=r[3]["payload"]["wall"]["inference_started_epoch"] + 1), "Absolute")

    def test_cumulative_wall_cannot_decrease(self):
        self.mutate(lambda r: r[3]["payload"]["wall"].update(task_wall_seconds=.5), "decreased")

    def test_unclosed_cost_cannot_publish_checkpoint(self):
        def action(rows):
            rows[4]["payload"]["attempt"]["gpu_seconds"] = None
            rows[4]["payload"]["wall"].update(gpu_seconds=.1, resumable=False)
        self.mutate(action, "closed known-cost")

    def test_gpu_aggregate_cannot_omit_warmup(self):
        self.mutate(lambda r: r[2]["payload"]["wall"].update(gpu_seconds=0.), "GPU total")

    def test_checkpoint_cannot_bind_warmup(self):
        self.mutate(lambda r: r[2].update(event="checkpoint"))

    def test_duplicate_checkpoint_is_refused(self):
        self.mutate(lambda r: r[8]["payload"].update(entry=deepcopy(r[5]["payload"]["entry"])), "Duplicate")

    def test_checkpoint_file_bytes_tamper_is_refused(self):
        self.tamper(lambda d, v: (d / "checkpoints/0000-0.json").write_bytes(b"{}\n"), "bytes")

    def test_checkpoint_path_escape_is_refused(self):
        self.mutate(lambda r: r[5]["payload"]["entry"].update(relative_path="../budget.json"), "path")

    def test_closure_cannot_rewrite_call_arrays(self):
        self.mutate(lambda r: r[-1]["payload"]["final_fields"].update(formal_attempts=[]), "rewrites")

    def test_closure_cannot_rewrite_aggregate_counts(self):
        self.mutate(lambda r: r[-1]["payload"]["final_fields"].update(formal_calls=1), "aggregate")

    def test_published_budget_must_equal_independent_replay(self):
        def change(directory, value):
            budget = json.loads((directory / "budget.json").read_text())
            budget["gpu_seconds"] = .2
            save(directory / "budget.json", budget)
        self.tamper(change, "Published budget")

    def test_published_index_must_equal_independent_replay(self):
        def change(directory, value):
            index = json.loads((directory / "checkpoint_index.json").read_text())
            index["checkpoints"].reverse()
            save(directory / "checkpoint_index.json", index)
        self.tamper(change, "Published index")

    def test_published_observations_must_equal_journal_checkpoints(self):
        self.tamper(lambda d, v: v[3].reverse(), "observation population")

    def test_extra_unjournaled_checkpoint_is_refused(self):
        self.tamper(lambda d, v: save(d / "checkpoints/extra.json", {}), "Unjournaled")

    def test_completed_journal_cannot_resume(self):
        with scratch() as directory:
            value = fixture(directory)
            with self.assertRaisesRegex(reviewer.JournalVerificationError, "resume"):
                self.verify(directory, value, require_completed=False, require_resumable=True, now_epoch=value[4] + 4)

    def test_incomplete_known_cost_journal_may_resume_with_original_deadline(self):
        with scratch() as directory:
            value = fixture(directory)
            rows_write(directory, value[2][:-1])
            result = self.verify(directory, value, require_completed=False, require_resumable=True,
                now_epoch=value[4] + 4, check_published=False)
            self.assertEqual(result["status"], "passed")
            self.assertEqual(result["business_status"], "running")
            with self.assertRaisesRegex(reviewer.JournalVerificationError, "deadline"):
                self.verify(directory, value, require_completed=False, require_resumable=True,
                    now_epoch=value[4] + 905, check_published=False)

    def test_success_without_checkpoint_cannot_resume(self):
        with scratch() as directory:
            value = fixture(directory)
            rows_write(directory, value[2][:-2])
            (directory / "checkpoints/0000-1.json").unlink()
            with self.assertRaisesRegex(reviewer.JournalVerificationError, "resume"):
                reviewer.verify_journal(directory, value[0], value[1], require_completed=False,
                    require_resumable=True, now_epoch=value[4] + 4, check_published=False)

    def test_snapshot_is_never_recovery_authority(self):
        with scratch() as directory:
            value = fixture(directory)
            save(directory / "budget_snapshot.json", {"gpu_seconds": 0, "formal_calls": 0})
            self.assertEqual(self.verify(directory, value)["status"], "passed")

    def test_known_cost_failed_prefix_is_auditable_and_resumable(self):
        with scratch() as directory:
            value = failed_prefix(directory)
            report = self.verify(directory, value, require_completed=False, require_resumable=True, now_epoch=value[4] + 4)
            self.assertEqual(report["status"], "passed")
            self.assertEqual(report["business_status"], "failed")
            with self.assertRaisesRegex(reviewer.JournalVerificationError, "not completed"):
                self.verify(directory, value)

    def test_resume_keeps_prior_hashes_costs_and_prefix(self):
        with scratch() as root:
            parent = root / "old-task"
            parent.mkdir()
            value = failed_prefix(parent)
            new = root / "new-task"
            resumed = resume_prefix(parent, new, value)
            report = self.verify(new, resumed, require_completed=False, require_resumable=True,
                now_epoch=value[4] + 4, check_published=False)
            self.assertEqual(report["status"], "passed")
            self.assertEqual(report["replayed_budget"]["formal_calls"], 1)
            self.assertEqual(report["replayed_budget"]["task_started_epoch"], value[4])
            self.assertAlmostEqual(report["replayed_budget"]["gpu_seconds"], .2)
            self.assertEqual(report["replayed_budget"]["resume_chain"][-1]["task_id"], "old-task")

    def test_resume_cannot_reset_start_or_prefix_head(self):
        for field in ("task_started_epoch", "prior_journal_sha256", "journal_file_sha256"):
            with self.subTest(field=field), scratch() as root:
                parent = root / "old-task"
                parent.mkdir()
                value = failed_prefix(parent)
                new = root / "new-task"
                resumed = resume_prefix(parent, new, value)
                payload = resumed[2][-1]["payload"]
                if field == "task_started_epoch":
                    payload["wall"][field] += 1
                elif field == "prior_journal_sha256":
                    payload[field] = "0" * 64
                else:
                    payload["final_fields"]["resume_chain"][-1][field] = "0" * 64
                rows_write(new, resumed[2])
                with self.assertRaises(reviewer.JournalVerificationError):
                    self.verify(new, resumed, require_completed=False, require_resumable=True,
                        now_epoch=value[4] + 4, check_published=False)

    def test_resume_parent_failure_files_are_bound(self):
        with scratch() as root:
            parent = root / "old-task"
            parent.mkdir()
            value = failed_prefix(parent)
            new = root / "new-task"
            resumed = resume_prefix(parent, new, value)
            save(parent / "failure.json", {"status": "completed"})
            with self.assertRaisesRegex(reviewer.JournalVerificationError, "prior failure"):
                self.verify(new, resumed, require_completed=False, require_resumable=True,
                    now_epoch=value[4] + 4, check_published=False)

    def test_unknown_cost_or_active_call_cannot_resume(self):
        for unknown in (False, True):
            with self.subTest(unknown=unknown), scratch() as directory:
                value = fixture(directory)
                records = value[2][:2]
                if unknown:
                    finished = deepcopy(value[2][2])
                    finished["payload"]["attempt"].update(elapsed_seconds=None, gpu_seconds=None)
                    finished["payload"]["wall"].update(gpu_seconds=0., resumable=False)
                    records.append(finished)
                rows_write(directory, records)
                for path in (directory / "checkpoints").iterdir():
                    path.unlink()
                with self.assertRaisesRegex(reviewer.JournalVerificationError, "resume"):
                    reviewer.verify_journal(directory, value[0], value[1], require_completed=False,
                        require_resumable=True, now_epoch=value[4] + 4, check_published=False)

    def test_known_gpu_is_charged_even_when_elapsed_is_unknown(self):
        with scratch() as directory:
            value = fixture(directory)
            records = value[2][:3]
            records[-1]["payload"]["attempt"]["elapsed_seconds"] = None
            records[-1]["payload"]["wall"]["resumable"] = False
            rows_write(directory, records)
            report = reviewer.verify_journal(directory, value[0], value[1], require_completed=False, check_published=False)
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["replayed_budget"]["gpu_seconds"], .1)
            self.assertFalse(report["replayed_budget"]["resumable"])


if __name__ == "__main__":
    unittest.main()
