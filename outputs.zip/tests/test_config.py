"""Check portable path resolution and refusal to write into source data."""
import json
from contextlib import contextmanager
from pathlib import Path
import shutil
import unittest
import uuid

from defect_researcher.config import load_config

TEMP_ROOT = Path(__file__).resolve().parents[1] / ".runtime" / "test-tmp"


@contextmanager
def temporary_workspace():
    directory = (TEMP_ROOT / uuid.uuid4().hex).resolve()
    directory.mkdir(parents=True)
    try:
        yield directory
    finally:
        if directory.parent != TEMP_ROOT.resolve():
            raise RuntimeError("Refusing cleanup outside test workspace")
        shutil.rmtree(directory)


class ConfigTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        TEMP_ROOT.mkdir(parents=True, exist_ok=True)

    def test_portable_paths_and_references(self):
        with temporary_workspace() as directory:
            root = Path(directory)
            data = {
                "schema_version": 1, "research_root": "research",
                "dataset_root": "${research_root}/dataset", "raw_root": "raw",
                "split_dir": "${research_root}/splits",
                "weights_path": "${research_root}/best.pt", "output_root": "outputs",
            }
            path = root / "settings.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            result = load_config(path)
            self.assertEqual(Path(result["dataset_root"]), root / "research" / "dataset")
            self.assertEqual(Path(result["output_root"]), root / "outputs")
            data["output_root"] = "${research_root}/outputs"
            path.write_text(json.dumps(data), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "separate"):
                load_config(path)

    def test_unknown_field_and_reference_refused(self):
        with temporary_workspace() as directory:
            path = Path(directory) / "settings.json"
            path.write_text('{"schema_version":1,"api_key":"invalid"}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Unknown"):
                load_config(path)


if __name__ == "__main__":
    unittest.main()
