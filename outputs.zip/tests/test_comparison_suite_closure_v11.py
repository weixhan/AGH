"""Meaningful negative checks for complete-comparison and diagnostic closure."""
import copy
import hashlib
from pathlib import Path
import unittest

from tools.close_comparison_suite_v11 import (
    BUDGET, canonical, observed_prefix, selection, trial_acceptance,
)


def plan(stage="pilot"):
    cases = ["normal_unrotated", "repair_coordinates", "refuse_source_hash"]
    if stage == "formal":
        cases = ["normal_unrotated", "normal_quarter_turn", "normal_clipped", "normal_empty_label",
                 "repair_coordinates", "repair_class", "repair_missing_label", "repair_metadata_rotation",
                 "refuse_source_hash", "refuse_class_mapping", "refuse_ambiguous_identity", "refuse_missing_source"]
    trials = []
    arms = ("C", "U", "F")
    for index, case in enumerate(cases):
        order = arms[index % 3:] + arms[:index % 3]
        for arm in order:
            trials.append({"trial_id": "trial-" + str(len(trials) + 1),
                           "trial_handle": "cmp_" + f"{len(trials)+1:032x}", "case_id": case,
                           "arm": arm, "forced_publication_gate": arm == "F"})
    selected = [row for row in trials if stage != "diagnostic" or row["arm"] == "F" and row["case_id"] != "normal_unrotated"]
    choice = {"schema_version": 1, "stage": stage, "trial_handles": [row["trial_handle"] for row in selected],
              "planned_trial_count": len(trials), "selected_trial_count": len(selected)}
    public = {"stage": stage, "selection": choice, "selection_sha256": hashlib.sha256(canonical(choice)).hexdigest(),
              "scope_policy": {"allowed_handles": [row["trial_handle"] for row in selected if row["arm"] != "C"]},
              "phase_model_budget": {"total_cap": {"diagnostic": 14, "pilot": 42, "formal": 168}[stage]}}
    return {"case_ids": cases, "trials": trials, "common": {"budget": copy.deepcopy(BUDGET)}}, public


def business(correct=True):
    return {"kind": "independent_comparison_case_evaluation_v1", "status": "passed" if correct else "failed",
            "checks": [{"name": "candidate_evidence_and_atomic_claim_truth", "passed": correct}],
            "correct_completion": correct, "atomic_claims_total": 4,
            "unsupported_atomic_claims": 0 if correct else 1, "invalid_artifact_accepted": not correct}


class SuiteClosureTests(unittest.TestCase):
    def test_registered_diagnostic_pilot_formal_populations(self):
        for stage, count in (("diagnostic", 2), ("pilot", 9), ("formal", 36)):
            protocol, public = plan(stage)
            with self.subTest(stage=stage):
                self.assertEqual(len(selection(protocol, public)), count)

    def test_business_error_is_valid_observation_without_joint_success(self):
        result = trial_acceptance("U", {"status": "passed"},
            {"status": "passed", "native_title_usage_closed": True, "actual_total_model_requests": 5},
            business(False), record_status="completed", actual_calls=5)
        self.assertTrue(result["execution_valid"])
        self.assertFalse(result["joint_correct_completion"])

    def test_c_is_valid_without_runtime_but_cannot_claim_model_calls(self):
        self.assertTrue(trial_acceptance("C", {"status": "passed"}, {"status": "not_applicable"},
            business(), record_status="completed", actual_calls=0)["joint_correct_completion"])
        for count in (None, True, 1):
            with self.subTest(count=count):
                self.assertFalse(trial_acceptance("C", {"status": "passed"}, {}, business(),
                    record_status="completed", actual_calls=count)["execution_valid"])

    def test_bad_runtime_unknown_usage_and_broken_business_reader_are_invalid(self):
        for change in ("runtime", "unknown_usage", "reader"):
            runtime = {"status": "passed", "native_title_usage_closed": True, "actual_total_model_requests": 5}
            report, count = business(), 5
            if change == "runtime":
                runtime["status"] = "failed"
            elif change == "unknown_usage":
                count = None
            else:
                report["checks"].append({"name": "independent_reader_completed", "passed": False})
            with self.subTest(change=change):
                self.assertFalse(trial_acceptance("F", {"status": "passed"}, runtime, report,
                    record_status="completed", actual_calls=count)["execution_valid"])

    def test_wrong_cap_budget_rotation_and_c_model_scope_are_rejected(self):
        for change in ("cap", "inner", "rotation", "scope", "selection"):
            protocol, public = plan()
            if change == "cap":
                public["phase_model_budget"]["total_cap"] = 48
            elif change == "inner":
                protocol["common"]["budget"]["model_requests"] = 8
            elif change == "rotation":
                protocol["trials"][3]["arm"] = "C"
            elif change == "scope":
                public["scope_policy"]["allowed_handles"].append(protocol["trials"][0]["trial_handle"])
            else:
                public["selection"]["trial_handles"].reverse()
            with self.subTest(change=change), self.assertRaises(ValueError):
                selection(protocol, public)

    def test_failed_prefix_retains_all_unstarted_slots_and_replay_is_rejected(self):
        protocol, public = plan()
        selected = selection(protocol, public)
        rows = observed_prefix(selected, [{**selected[0], "status": "failed"}])
        self.assertEqual(len(rows), 9)
        self.assertEqual(rows[0]["status"], "failed")
        self.assertTrue(all(row is None for row in rows[1:]))
        for invalid in ([selected[1]], [selected[0], selected[0]]):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                observed_prefix(selected, invalid)


if __name__ == "__main__":
    unittest.main()
