"""Entry-point failure boundaries, without editing any sealed execution source."""
from pathlib import Path
import time
import unittest
from unittest.mock import patch

from defect_researcher.config import load_config
from defect_researcher import research_workflow_v1 as workflow
from defect_researcher.research_protocol_v1 import BudgetLedger
from test_config import temporary_workspace


class WorkflowBoundaryTests(unittest.TestCase):
    def request(self, identity="entry", budget=0):
        return {"schema_version": 1, "workflow_version": 1, "request_id": identity,
                "case_id": "normal_unrotated", "budget": {"domain_invocations": budget,
                "wall_seconds": 120, "gpu_seconds": 0, "model_requests": 0}}

    def config(self, directory):
        return {**load_config(), "output_root": str(directory / "outputs")}

    def test_unknown_request_field_refused_before_output(self):
        with temporary_workspace() as directory:
            request = {**self.request(), "script": "ignored"}
            with self.assertRaises(ValueError):
                workflow.run_workflow(request, self.config(directory))
            self.assertFalse((directory / "outputs").exists())

    def test_arbitrary_case_and_path_refused_before_output(self):
        for identity in ("../escaped", "normal_not_registered"):
            with self.subTest(identity=identity), temporary_workspace() as directory:
                request = {**self.request(), "case_id": identity}
                with self.assertRaises(ValueError):
                    workflow.run_workflow(request, self.config(directory))
                self.assertFalse((directory / "outputs").exists())

    def test_protected_input_overlap_refused(self):
        with temporary_workspace() as directory:
            configuration = self.config(directory)
            configuration["output_root"] = configuration["dataset_root"]
            with self.assertRaisesRegex(ValueError, "overlaps"):
                workflow.run_workflow(self.request(), configuration)

    def test_existing_request_cannot_reset_budget_even_without_completion(self):
        with temporary_workspace() as directory:
            configuration = self.config(directory)
            existing = Path(configuration["output_root"]) / "research-workflow-v1-entry"
            existing.mkdir(parents=True)
            original = existing / "failure.json"
            original.write_text('{"status":"failed"}', encoding="utf-8")
            before = original.read_bytes()
            with self.assertRaisesRegex(FileExistsError, "no overwrite"):
                workflow.run_workflow(self.request(), configuration)
            self.assertEqual(original.read_bytes(), before)
            self.assertEqual(list(existing.iterdir()), [original])

    def test_unknown_action_exception_leaves_open_cost_and_no_marker(self):
        with temporary_workspace() as directory:
            with patch.object(workflow.domain, "verify_case", side_effect=RuntimeError("unknown business cost")):
                result = workflow.run_workflow(self.request(budget=1), self.config(directory))
            task = Path(result["directory"])
            self.assertEqual(result["status"], "failed")
            self.assertIsNotNone(result["budget"]["pending"])
            self.assertEqual(result["budget"]["reserved_domain_invocations"], 1)
            self.assertFalse((task / "completion.json").exists())
            self.assertTrue((task / "failure.json").is_file())
            self.assertEqual(workflow.read_workflow_status(task)["status"], "failed")

    def test_source_drift_stops_before_first_domain_call(self):
        with temporary_workspace() as directory:
            with patch.object(workflow, "_fresh_sources", side_effect=ValueError("source drift")), \
                    patch.object(workflow.domain, "verify_case") as action:
                result = workflow.run_workflow(self.request(budget=1), self.config(directory))
            self.assertEqual(result["status"], "failed")
            action.assert_not_called()
            self.assertEqual(result["actual_tool_path"], [])
            self.assertFalse((Path(result["directory"]) / "completion.json").exists())

    def test_independent_gate_failure_never_publishes_completion(self):
        with temporary_workspace() as directory:
            rejection = {"status": "failed", "error": "negative independent gate"}
            with patch.object(workflow, "_checker", return_value=rejection):
                result = workflow.run_workflow(self.request(), self.config(directory))
            task = Path(result["directory"])
            self.assertEqual(result["status"], "failed")
            self.assertFalse((task / "completion.json").exists())
            self.assertTrue((task / "independent_verification.json").is_file())

    def test_original_deadline_covers_case_preparation(self):
        with temporary_workspace() as directory:
            current = [time.monotonic(), time.time()]
            ledger_factory = lambda path, request: BudgetLedger(path, request, clock=lambda: current[0], epoch_clock=lambda: current[1])
            original_prepare = workflow.domain.prepare_case
            def slow_prepare(*args):
                prepared = original_prepare(*args)
                current[0] += 121
                current[1] += 121
                return prepared
            with patch.object(workflow, "BudgetLedger", side_effect=ledger_factory), \
                    patch.object(workflow.domain, "prepare_case", side_effect=slow_prepare), \
                    patch.object(workflow.domain, "verify_case") as action:
                result = workflow.run_workflow(self.request(budget=1), self.config(directory))
            self.assertEqual(result["status"], "failed")
            action.assert_not_called()
            self.assertTrue(result["budget"]["expired"])
            self.assertFalse((Path(result["directory"]) / "completion.json").exists())

    def test_independent_gate_time_does_not_extend_deadline(self):
        with temporary_workspace() as directory:
            current = [time.monotonic(), time.time()]
            ledger_factory = lambda path, request: BudgetLedger(path, request, clock=lambda: current[0], epoch_clock=lambda: current[1])
            def slow_gate(*args, **kwargs):
                current[0] += 121
                current[1] += 121
                return {"status": "passed"}
            with patch.object(workflow, "BudgetLedger", side_effect=ledger_factory), \
                    patch.object(workflow, "_checker", side_effect=slow_gate):
                result = workflow.run_workflow(self.request(), self.config(directory))
            task = Path(result["directory"])
            self.assertEqual(result["status"], "failed")
            self.assertFalse((task / "completion.json").exists())
            self.assertTrue((task / "independent_verification.json").is_file())

    def test_late_marker_is_quarantined_after_publication_io(self):
        with temporary_workspace() as directory:
            current = [time.monotonic(), time.time()]
            ledger_factory = lambda path, request: BudgetLedger(path, request, clock=lambda: current[0], epoch_clock=lambda: current[1])
            original_write = workflow.write
            def slow_marker(path, value):
                original_write(path, value)
                if Path(path).name == "completion.json":
                    current[0] += 121
                    current[1] += 121
            with patch.object(workflow, "BudgetLedger", side_effect=ledger_factory), \
                    patch.object(workflow, "_checker", return_value={"status": "passed"}), \
                    patch.object(workflow, "write", side_effect=slow_marker):
                result = workflow.run_workflow(self.request(), self.config(directory))
            task = Path(result["directory"])
            self.assertEqual(result["status"], "failed")
            self.assertFalse((task / "completion.json").exists())
            self.assertTrue((task / "completion_rejected.json").is_file())
            self.assertTrue((task / "failure.json").is_file())


if __name__ == "__main__":
    unittest.main()
