"""Exercise the two-tool protocol boundary and actual UTF-8 stdio processes."""
from __future__ import annotations

import copy
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

from defect_researcher.research_mcp_server_v2 import (
    PROTOCOL_VERSION, ResearchMCPServer, RUN_TOOL_NAME, STATUS_TOOL_NAME, serve,
)
from test_config import temporary_workspace


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INITIALIZED = {"jsonrpc": "2.0", "method": "notifications/initialized"}


def request(identifier, method, params=None):
    value = {"jsonrpc": "2.0", "id": identifier, "method": method}
    if params is not None:
        value["params"] = params
    return value


def initialize(version=PROTOCOL_VERSION):
    return request(1, "initialize", {
        "protocolVersion": version, "capabilities": {},
        "clientInfo": {"name": "test-bounded-client", "version": "1"},
    })


def arguments():
    return {"request_id": "bounded-test", "case_id": "normal_unrotated",
            "budget": {"domain_invocations": 6, "wall_seconds": 120,
                       "gpu_seconds": 0, "model_requests": 0}}


def call(name=RUN_TOOL_NAME, value=None, identifier=2):
    return request(identifier, "tools/call", {
        "name": name, "arguments": arguments() if value is None else value,
    })


def completed(workflow_id="research-workflow-v1-bounded-test"):
    return {"workflow_id": workflow_id, "status": "completed",
            "research_status": "stopped", "verification": {
                "status": "passed", "checks_total": 178, "checks_passed": 178,
                "completion_sha256": "a" * 64}, "claims": []}


class FakeRuntime:
    def __init__(self, report=None):
        self.calls = []
        self.report = report

    def start(self, value):
        self.calls.append(("start", copy.deepcopy(value)))
        return copy.deepcopy(self.report if self.report is not None else {
            "status": "running", "workflow_id": "research-workflow-v1-" + value["request_id"]})

    def get_status(self, value):
        self.calls.append(("get_status", copy.deepcopy(value)))
        return copy.deepcopy(self.report if self.report is not None else completed(value["workflow_id"]))


def ready(runtime=None, version=PROTOCOL_VERSION):
    server = ResearchMCPServer(configuration={}, runtime=runtime or FakeRuntime())
    server.handle_message(initialize(version))
    server.handle_message(INITIALIZED)
    return server


def tool_payload(response):
    return json.loads(response["result"]["content"][0]["text"])


def source_lock(directory):
    paths = [PROJECT_ROOT / "defect_researcher/research_mcp_runtime_v2.py",
             PROJECT_ROOT / "defect_researcher/research_mcp_server_v2.py",
             PROJECT_ROOT / "run_research_mcp_v2.py",
             PROJECT_ROOT / "defect_researcher/research_workflow_clock_v2.py",
             PROJECT_ROOT / "config/local.json",
             PROJECT_ROOT / "outputs/research-workflow-implementation-v1/freeze.json"]
    value = {"schema_version": 1, "kind": "research_mcp_implementation_v2",
             "status": "passed", "files": [
                 {"role": str(index), "path": str(path.resolve()),
                  "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                  "size_bytes": path.stat().st_size}
                 for index, path in enumerate(paths)]}
    location = Path(directory) / "source_lock.json"
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    location.write_bytes(raw)
    return location, hashlib.sha256(raw).hexdigest()


def launch_command(lock_path, lock_sha):
    return [sys.executable, "-X", "utf8", "-B", str(PROJECT_ROOT / "run_research_mcp_v2.py"),
            "--source-lock", str(lock_path), "--expected-lock-sha256", lock_sha]


class ResearchTransportTests(unittest.TestCase):
    def test_implementation_version_is_independent_from_workflow_api(self):
        server = ResearchMCPServer(runtime=FakeRuntime())
        identity = server.handle_message(initialize())["result"]["serverInfo"]
        self.assertEqual(identity, {"name": "defect-researcher-bounded-workflow-v2",
                                    "version": "2.0.0"})
        server.handle_message(INITIALIZED)
        tools = server.handle_message(request(2, "tools/list"))["result"]["tools"]
        self.assertEqual([tool["name"] for tool in tools],
                         [RUN_TOOL_NAME, STATUS_TOOL_NAME])

    def test_caller_cannot_inject_worker_clock_anchors_or_deadlines(self):
        for field in ("trusted_clock_anchor", "started_epoch", "started_monotonic",
                      "deadline_epoch", "deadline_monotonic", "implementation_version"):
            with self.subTest(field=field):
                runtime = FakeRuntime()
                value = {**arguments(), field: 120}
                self.assertIn("error", ready(runtime).handle_message(call(value=value)))
                self.assertFalse(runtime.calls)

    def test_lifecycle_does_not_start_before_ready(self):
        runtime = FakeRuntime()
        server = ResearchMCPServer(runtime=runtime)
        self.assertEqual(server.handle_message(call())["error"]["code"], -32002)
        self.assertIsNone(server.handle_message(INITIALIZED))
        self.assertFalse(server.ready)
        server.handle_message(initialize())
        self.assertEqual(server.handle_message(call())["error"]["code"], -32002)
        self.assertIsNone(server.handle_message(INITIALIZED))
        self.assertFalse(server.handle_message(call())["result"]["isError"])
        self.assertEqual(len(runtime.calls), 1)

    def test_duplicate_initialize_cannot_reset_session(self):
        server = ready()
        self.assertEqual(server.handle_message(initialize())["error"]["code"], -32600)
        self.assertTrue(server.ready)

    def test_future_protocol_negotiates_supported_version(self):
        server = ResearchMCPServer(runtime=FakeRuntime())
        self.assertEqual(server.handle_message(initialize("future-version"))["result"]["protocolVersion"], PROTOCOL_VERSION)

    def test_old_protocol_omits_annotations(self):
        tools = ready(version="2024-11-05").handle_message(request(3, "tools/list"))["result"]["tools"]
        self.assertTrue(all("annotations" not in tool for tool in tools))

    def test_directory_exposes_only_two_strict_cpu_tools(self):
        tools = ready().handle_message(request(3, "tools/list"))["result"]["tools"]
        self.assertEqual([tool["name"] for tool in tools], [RUN_TOOL_NAME, STATUS_TOOL_NAME])
        schema = tools[0]["inputSchema"]
        self.assertEqual(schema["required"], ["request_id", "case_id", "budget"])
        self.assertFalse(schema["additionalProperties"])
        self.assertEqual(len(schema["properties"]["case_id"]["enum"]), 12)
        budget = schema["properties"]["budget"]
        self.assertFalse(budget["additionalProperties"])
        self.assertEqual(budget["properties"]["domain_invocations"]["maximum"], 6)
        self.assertEqual(budget["properties"]["wall_seconds"]["maximum"], 120)
        self.assertEqual(budget["properties"]["gpu_seconds"]["enum"], [0])
        self.assertEqual(budget["properties"]["model_requests"]["enum"], [0])
        self.assertTrue(tools[1]["annotations"]["readOnlyHint"])

    def test_tool_directory_mutation_cannot_expand_later_calls(self):
        server = ready()
        tools = server.handle_message(request(3, "tools/list"))["result"]["tools"]
        tools[0]["inputSchema"]["properties"]["case_id"]["enum"].append("arbitrary")
        again = server.handle_message(request(4, "tools/list"))["result"]["tools"]
        self.assertNotIn("arbitrary", again[0]["inputSchema"]["properties"]["case_id"]["enum"])

    def test_valid_run_passes_only_three_normalized_fields(self):
        runtime = FakeRuntime()
        response = ready(runtime).handle_message(call())
        self.assertEqual(tool_payload(response)["workflow_id"], "research-workflow-v1-bounded-test")
        action, value = runtime.calls[0]
        self.assertEqual(action, "start")
        self.assertEqual(set(value), {"request_id", "case_id", "budget"})
        self.assertIs(type(value["budget"]["wall_seconds"]), float)

    def test_every_frozen_case_is_accepted(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        cases = server.handle_message(request(3, "tools/list"))["result"]["tools"][0]["inputSchema"]["properties"]["case_id"]["enum"]
        for case_id in cases:
            with self.subTest(case_id=case_id):
                value = arguments()
                value["case_id"] = case_id
                self.assertFalse(server.handle_message(call(value=value))["result"]["isError"])
        self.assertEqual(len(runtime.calls), 12)

    def test_zero_domain_budget_is_valid_reporting_request(self):
        runtime = FakeRuntime()
        value = arguments()
        value["budget"]["domain_invocations"] = 0
        self.assertFalse(ready(runtime).handle_message(call(value=value))["result"]["isError"])
        self.assertEqual(runtime.calls[0][1]["budget"]["domain_invocations"], 0)

    def test_invalid_run_arguments_never_reach_runtime(self):
        bad = [None, [], "invalid", {}, {**arguments(), "path": "C:/data"},
               {**arguments(), "schema_version": 1},
               {**arguments(), "request_id": "../escape"},
               {**arguments(), "request_id": "a" * 65},
               {**arguments(), "request_id": True},
               {**arguments(), "case_id": "unknown"},
               {key: value for key, value in arguments().items() if key != "budget"}]
        for value in bad:
            with self.subTest(value=value):
                runtime = FakeRuntime()
                message = request(2, "tools/call", {"name": RUN_TOOL_NAME, "arguments": value})
                response = ready(runtime).handle_message(message)
                self.assertIn("error", response)
                self.assertFalse(runtime.calls)

    def test_invalid_budgets_never_reach_runtime(self):
        changes = [
            ("domain_invocations", True), ("domain_invocations", 6.0),
            ("domain_invocations", -1), ("domain_invocations", 7),
            ("wall_seconds", True), ("wall_seconds", 0), ("wall_seconds", -1),
            ("wall_seconds", 121), ("wall_seconds", float("nan")),
            ("wall_seconds", float("inf")), ("wall_seconds", "120"),
            ("gpu_seconds", True), ("gpu_seconds", 1),
            ("model_requests", False), ("model_requests", 0.0),
            ("model_requests", 1), ("script", "launch"),
        ]
        for field, changed in changes:
            with self.subTest(field=field, changed=changed):
                runtime = FakeRuntime()
                value = arguments()
                value["budget"][field] = changed
                self.assertIn("error", ready(runtime).handle_message(call(value=value)))
                self.assertFalse(runtime.calls)
        runtime = FakeRuntime()
        value = arguments()
        value["budget"].pop("model_requests")
        self.assertIn("error", ready(runtime).handle_message(call(value=value)))
        self.assertFalse(runtime.calls)

    def test_status_requires_namespace_and_single_field(self):
        valid_id = "research-workflow-v1-bounded-test"
        bad = [{}, {"workflow_id": "other-task"}, {"workflow_id": "../escape"},
               {"workflow_id": valid_id, "resume": True}, {"workflow_id": True},
               {"workflow_id": "research-workflow-v1-" + "a" * 65}]
        runtime = FakeRuntime()
        server = ready(runtime)
        for value in bad:
            self.assertIn("error", server.handle_message(call(STATUS_TOOL_NAME, value)))
        self.assertFalse(runtime.calls)
        response = server.handle_message(call(STATUS_TOOL_NAME, {"workflow_id": valid_id}))
        self.assertFalse(response["result"]["isError"])
        self.assertEqual(runtime.calls, [("get_status", {"workflow_id": valid_id})])

    def test_old_seven_tools_and_unknown_tool_cannot_dispatch(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        names = ["audit_dataset", "verify_label_geometry", "repair_label_copy",
                 "compare_validation_resolutions", "diagnose_validation_errors",
                 "compare_validation_slices", "get_task_status", "unknown"]
        for name in names:
            self.assertIn("error", server.handle_message(call(name, {})))
        self.assertFalse(runtime.calls)

    def test_notifications_cannot_execute_either_tool(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for name, value in [(RUN_TOOL_NAME, arguments()), (STATUS_TOOL_NAME,
                            {"workflow_id": "research-workflow-v1-bounded-test"})]:
            message = call(name, value)
            message.pop("id")
            self.assertIsNone(server.handle_message(message))
        self.assertFalse(runtime.calls)

    def test_notification_initialize_cannot_initialize(self):
        server = ResearchMCPServer(runtime=FakeRuntime())
        message = initialize()
        message.pop("id")
        self.assertIsNone(server.handle_message(message))
        self.assertFalse(server.initialized)

    def test_bad_initialized_notification_cannot_mark_ready(self):
        server = ResearchMCPServer(runtime=FakeRuntime())
        server.handle_message(initialize())
        server.handle_message({**INITIALIZED, "params": {"path": "unused"}})
        self.assertFalse(server.ready)

    def test_invalid_rpc_ids_cannot_start_workflow(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for identifier in (True, False, None, [], {}, 1.5, float("nan"), float("inf")):
            with self.subTest(identifier=identifier):
                self.assertIn("error", server.handle_message(call(identifier=identifier)))
        self.assertFalse(runtime.calls)

    def test_bad_envelopes_and_call_params_fail_without_runtime(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        messages = [None, [], "invalid", {**call(), "jsonrpc": "1.0"},
                    {**call(), "path": "unused"}, {**call(), "params": []},
                    request(2, "tools/call", {"name": []}),
                    request(2, "tools/call", {"name": RUN_TOOL_NAME}),
                    request(2, "tools/call", {"name": RUN_TOOL_NAME, "arguments": arguments(), "script": "unused"}),
                    request(2, "tools/call", {"name": RUN_TOOL_NAME, "arguments": arguments(), "_meta": []})]
        for message in messages:
            with self.subTest(message=message):
                self.assertIn("error", server.handle_message(message))
        self.assertFalse(runtime.calls)

    def test_client_metadata_does_not_expand_arguments(self):
        runtime = FakeRuntime()
        message = call()
        message["params"]["_meta"] = {"progressToken": "token"}
        response = ready(runtime).handle_message(message)
        self.assertFalse(response["result"]["isError"])
        self.assertEqual(set(runtime.calls[0][1]), {"request_id", "case_id", "budget"})

    def test_batch_keeps_ids_and_ignores_notifications(self):
        runtime = FakeRuntime()
        server = ResearchMCPServer(runtime=runtime)
        response = server.handle_message([initialize(), INITIALIZED, call(identifier=7),
                                          {"jsonrpc": "2.0", "method": "tools/call", "params": call()["params"]},
                                          request("ping-id", "ping"), []])
        self.assertEqual([item["id"] for item in response], [1, 7, "ping-id", None])
        self.assertEqual(len(runtime.calls), 1)
        self.assertEqual(response[-1]["error"]["code"], -32600)

    def test_notification_only_batch_has_no_response(self):
        self.assertIsNone(ready().handle_message([INITIALIZED, {"jsonrpc": "2.0", "method": "unknown"}]))

    def test_ping_and_unknown_methods_do_not_call_runtime(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        self.assertEqual(server.handle_message(request(9, "ping"))["result"], {})
        self.assertEqual(server.handle_message(request(10, "shell"))["error"]["code"], -32601)
        self.assertFalse(runtime.calls)

    def test_unknown_cursors_and_bad_initialize_are_refused(self):
        runtime = FakeRuntime()
        self.assertIn("error", ready(runtime).handle_message(request(2, "tools/list", {"cursor": "next"})))
        for field, value in [("capabilities", []), ("clientInfo", {}),
                             ("protocolVersion", True), ("path", "unused")]:
            message = initialize()
            message["params"][field] = value
            server = ResearchMCPServer(runtime=runtime)
            self.assertIn("error", server.handle_message(message))
            self.assertFalse(server.initialized)
        self.assertFalse(runtime.calls)

    def test_runtime_execution_failure_sets_iserror(self):
        runtime = FakeRuntime({"status": "failed", "workflow_id": "research-workflow-v1-bounded-test", "error": "stopped"})
        response = ready(runtime).handle_message(call())
        self.assertTrue(response["result"]["isError"])
        self.assertEqual(tool_payload(response)["status"], "failed")

    def test_semantic_refusal_and_insufficient_evidence_can_complete(self):
        for state in ("refused", "insufficient_evidence"):
            report = completed()
            report["research_status"] = state
            response = ready(FakeRuntime(report)).handle_message(call())
            self.assertFalse(response["result"]["isError"])
            self.assertEqual(tool_payload(response)["research_status"], state)

    def test_bad_runtime_status_and_id_fail_closed(self):
        bad = [[], {"status": "unknown", "workflow_id": "research-workflow-v1-bounded-test"},
               {"status": "running", "workflow_id": "wrong"},
               {"status": "running"}, {"status": "running", "workflow_id": "research-workflow-v1-bounded-test", "gpu_seconds": float("nan")}]
        for report in bad:
            response = ready(FakeRuntime(report)).handle_message(call())
            self.assertTrue(response["result"]["isError"])
            self.assertEqual(tool_payload(response)["status"], "failed")

    def test_completed_requires_complete_finite_independent_gate(self):
        bad = [None, {}, {"status": "failed", "checks_total": 178, "checks_passed": 178, "completion_sha256": "a" * 64},
               {"status": "passed", "checks_total": 178, "checks_passed": 177, "completion_sha256": "a" * 64},
               {"status": "passed", "checks_total": True, "checks_passed": True, "completion_sha256": "a" * 64},
               {"status": "passed", "checks_total": 0, "checks_passed": 0, "completion_sha256": "a" * 64},
               {"status": "passed", "checks_total": 178, "checks_passed": 178, "completion_sha256": "wrong"}]
        for gate in bad:
            report = completed()
            report["verification"] = gate
            self.assertTrue(ready(FakeRuntime(report)).handle_message(call())["result"]["isError"])

    def test_runtime_exception_is_tool_failure_not_protocol_crash(self):
        class Raises(FakeRuntime):
            def start(self, value):
                raise OSError("worker unavailable")
        response = ready(Raises()).handle_message(call())
        self.assertTrue(response["result"]["isError"])
        self.assertEqual(tool_payload(response)["errors"][0]["stage"], "workflow_start")


class ResearchStdioTests(unittest.TestCase):
    def test_strict_parsing_recovers_after_invalid_lines_without_start(self):
        runtime = FakeRuntime()
        bad = [b'\xff\n', b'{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}\n',
               b'{"x":NaN}\n', b'{"x":Infinity}\n', b'{"x":1e999}\n', b'{broken}\n']
        messages = [initialize(), INITIALIZED, call()]
        source = io.BytesIO(b"".join(bad) + b"".join(json.dumps(item).encode("utf-8") + b"\n" for item in messages))
        destination = io.BytesIO()
        serve(runtime=runtime, stdin=source, stdout=destination)
        responses = [json.loads(line) for line in destination.getvalue().splitlines()]
        self.assertTrue(all(item["error"]["code"] == -32700 for item in responses[:len(bad)]))
        self.assertEqual(len(runtime.calls), 1)
        self.assertEqual(responses[-1]["id"], 2)

    def test_nested_duplicate_arguments_never_execute(self):
        runtime = FakeRuntime()
        prefix = b"".join(json.dumps(item).encode() + b"\n" for item in [initialize(), INITIALIZED])
        bad = json.dumps(call()).replace('"model_requests": 0', '"model_requests": 0, "model_requests": 0').encode() + b"\n"
        output = io.BytesIO()
        serve(runtime=runtime, stdin=io.BytesIO(prefix + bad), stdout=output)
        self.assertEqual(json.loads(output.getvalue().splitlines()[-1])["error"]["code"], -32700)
        self.assertFalse(runtime.calls)

    def test_real_launcher_handshake_and_unknown_tool_stdout_is_json_only(self):
        messages = [initialize("2024-11-05"), INITIALIZED, request(3, "tools/list"),
                    call("audit_dataset", {}), request("中文-id", "ping")]
        with temporary_workspace() as directory:
            lock_path, lock_sha = source_lock(directory)
            process = subprocess.run(launch_command(lock_path, lock_sha),
                                     input=b"".join(json.dumps(item, ensure_ascii=False).encode("utf-8") + b"\n" for item in messages),
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=PROJECT_ROOT, timeout=15)
        self.assertEqual(process.returncode, 0, process.stderr.decode("utf-8", errors="replace"))
        responses = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual(len(responses), 4)
        self.assertEqual([item["id"] for item in responses], [1, 3, 2, "中文-id"])
        self.assertEqual(len(responses[1]["result"]["tools"]), 2)
        self.assertTrue(all("annotations" not in item for item in responses[1]["result"]["tools"]))
        self.assertFalse(process.stderr)

    def test_production_launcher_requires_both_deployment_pins_before_handshake(self):
        for extra in ([], ["--source-lock", "missing.json"],
                      ["--expected-lock-sha256", "a" * 64]):
            with self.subTest(extra=extra):
                process = subprocess.run([sys.executable, "-X", "utf8", "-B",
                                          str(PROJECT_ROOT / "run_research_mcp_v2.py"), *extra],
                                         input=json.dumps(initialize()).encode() + b"\n",
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         cwd=PROJECT_ROOT, timeout=15)
                self.assertEqual(process.returncode, 2)
                self.assertFalse(process.stdout)
                self.assertTrue(process.stderr)

    def test_changed_deployment_lock_refuses_startup_before_handshake(self):
        with temporary_workspace() as directory:
            location, sha = source_lock(directory)
            location.write_bytes(location.read_bytes() + b" ")
            process = subprocess.run(launch_command(location, sha),
                                     input=json.dumps(initialize()).encode() + b"\n",
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=PROJECT_ROOT, timeout=15)
        self.assertEqual(process.returncode, 2)
        self.assertFalse(process.stdout)
        self.assertIn(b"startup refused", process.stderr)

    def test_sdk_real_stdio_negotiation_directory_and_refusal(self):
        # Use the installed AGH dependency itself. This checks the SDK's actual
        # schemas, negotiation and stdio framing without a model or domain run.
        modules = PROJECT_ROOT.parent / "agnes-harness/node_modules/.pnpm"
        candidates = sorted(modules.glob("@modelcontextprotocol+sdk@*/node_modules/@modelcontextprotocol/sdk/dist/esm"))
        node = shutil.which("node")
        if node is None and Path("E:/nodejs24.15.0/node.exe").is_file():
            node = "E:/nodejs24.15.0/node.exe"
        if not candidates or node is None:
            self.skipTest("Installed AGH MCP SDK and Node.js are required for this integration smoke test")
        script = r"""
import { pathToFileURL } from 'node:url';
const [sdk, python, launcher, lock, sha, cwd] = process.argv.slice(1);
const { Client } = await import(pathToFileURL(sdk + '/client/index.js').href);
const { StdioClientTransport } = await import(pathToFileURL(sdk + '/client/stdio.js').href);
const transport = new StdioClientTransport({ command: python,
    args: ['-X','utf8','-B',launcher,'--source-lock',lock,'--expected-lock-sha256',sha],
    cwd, stderr: 'pipe' });
const diagnostics = [];
transport.stderr.on('data', chunk => diagnostics.push(chunk.toString('utf8')));
const client = new Client({ name: 'bounded-local-sdk-smoke', version: '1' }, { capabilities: {} });
try {
    await client.connect(transport);
    const { tools } = await client.listTools();
    let oldToolError;
    try { await client.callTool({ name: 'audit_dataset', arguments: {} }); }
    catch (error) { oldToolError = error.code; }
    const missing = await client.callTool({ name: 'get_research_workflow_status_v1',
        arguments: { workflow_id: 'research-workflow-v1-sdk-unknown-id' } });
    await client.ping();
    console.log(JSON.stringify({ server: client.getServerVersion(),
        names: tools.map(tool => tool.name), oldToolError,
        missingIsError: missing.isError, missing: JSON.parse(missing.content[0].text),
        diagnostics: diagnostics.join('') }));
} finally { await client.close(); }
"""
        with temporary_workspace() as directory:
            location, sha = source_lock(directory)
            process = subprocess.run([node, "--input-type=module", "-e", script,
                                      str(candidates[0].resolve()), sys.executable,
                                      str(PROJECT_ROOT / "run_research_mcp_v2.py"),
                                      str(location), sha, str(PROJECT_ROOT)],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=PROJECT_ROOT, timeout=25)
        self.assertEqual(process.returncode, 0, process.stderr.decode("utf-8", errors="replace"))
        report = json.loads(process.stdout)
        self.assertEqual(report["server"]["name"], "defect-researcher-bounded-workflow-v2")
        self.assertEqual(report["server"]["version"], "2.0.0")
        self.assertEqual(report["names"], [RUN_TOOL_NAME, STATUS_TOOL_NAME])
        self.assertEqual(report["oldToolError"], -32602)
        self.assertTrue(report["missingIsError"])
        self.assertEqual(report["missing"]["status"], "failed")
        self.assertEqual(report["missing"]["errors"][0]["stage"], "workflow_status")
        self.assertFalse(report["diagnostics"])
        self.assertFalse(process.stderr)

    def test_process_runtime_print_cannot_corrupt_protocol_stdout(self):
        # A simulated worker prints deliberately; serve keeps it off the
        # retained binary stdout used for protocol frames for the whole process.
        code = """from defect_researcher.research_mcp_server_v2 import serve
class Runtime:
    def start(self, value):
        print('worker diagnostic')
        return {'status':'running','workflow_id':'research-workflow-v1-'+value['request_id']}
serve(runtime=Runtime())
"""
        messages = [initialize(), INITIALIZED, call()]
        process = subprocess.run([sys.executable, "-X", "utf8", "-B", "-c", code],
                                 input=b"".join(json.dumps(item).encode() + b"\n" for item in messages),
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 cwd=PROJECT_ROOT, timeout=15)
        self.assertEqual(process.returncode, 0)
        responses = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual(len(responses), 2)
        self.assertFalse(responses[-1]["result"]["isError"])
        self.assertIn(b"worker diagnostic", process.stderr)
        self.assertNotIn(b"worker diagnostic", process.stdout)


if __name__ == "__main__":
    unittest.main()
