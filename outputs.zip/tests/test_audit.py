"""Exercise publication, failure, and protection of source data."""
import hashlib
import json
from pathlib import Path
import struct
import unittest
from unittest.mock import patch

from defect_researcher.audit import audit_dataset
from test_config import temporary_workspace


def fixture_configuration(root):
    research, dataset, raw, splits = [root / name for name in ("research", "dataset", "raw", "splits")]
    for path in (research / "数据处理", dataset / "images" / "val", raw, splits):
        path.mkdir(parents=True, exist_ok=True)
    geometry = research / "cableinspect_geometry.py"
    geometry.write_text('GEOMETRY_VERSION = "fixture"\n', encoding="utf-8")
    checker = research / "数据处理" / "7检查YOLO标注数据.py"
    checker.write_text("# test-only checker; patched at its boundary\n", encoding="utf-8")
    manifest = dataset / "manifest.json"
    manifest.write_text(json.dumps({"geometry_module_sha256": hashlib.sha256(geometry.read_bytes()).hexdigest()}), encoding="utf-8")
    header = b"\x89PNG\r\n\x1a\n" + struct.pack(">I", 13) + b"IHDR" + struct.pack(">II", 16, 8)
    (raw / "fixture.png").write_bytes(header)
    (dataset / "images" / "val" / "fixture.png").write_bytes(header)
    (splits / "val.txt").write_text(str(raw / "fixture.png") + "\n", encoding="utf-8")
    weight = research / "best.pt"
    weight.write_bytes(b"test-only non-checkpoint")
    return {"research_root": str(research), "dataset_root": str(dataset), "raw_root": str(raw),
            "split_dir": str(splits), "weights_path": str(weight), "output_root": str(root / "outputs")}


CHECKER_RESULT = {"status": "passed", "geometry_version": "fixture", "counts": {"val": {"images": 1}}, "excluded_buffer_images": 0}


class AuditTests(unittest.TestCase):
    def test_success_is_hash_verifiable_and_existing_task_is_preserved(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            before = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
            with patch("defect_researcher.audit._run_checker", return_value=(CHECKER_RESULT, "fixture checker\n")):
                result = audit_dataset(config, "known-task")
            self.assertEqual(result["status"], "completed", result["errors"])
            self.assertFalse(result["summary"]["independent_geometry_verification"])
            self.assertFalse(result["summary"]["inference_performed"])
            completion_path = Path(result["artifacts"]["completion"])
            completion = json.loads(completion_path.read_text(encoding="utf-8"))
            manifest_path = Path(completion["artifact_manifest"])
            self.assertEqual(hashlib.sha256(manifest_path.read_bytes()).hexdigest(), completion["artifact_manifest_sha256"])
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            for item in manifest["files"]:
                self.assertEqual(hashlib.sha256(Path(item["path"]).read_bytes()).hexdigest(), item["sha256"])
            for path, value in before.items():
                self.assertEqual(path.read_bytes(), value)
            completed_bytes = completion_path.read_bytes()
            repeated = audit_dataset(config, "known-task")
            self.assertEqual(repeated["status"], "failed")
            self.assertEqual(completion_path.read_bytes(), completed_bytes)
            self.assertFalse((completion_path.parent / "failure.json").exists())

    def test_missing_input_records_failure_without_completion(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            Path(config["weights_path"]).unlink()
            result = audit_dataset(config, "missing-weight")
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["errors"][0]["stage"], "input_provenance")
            self.assertTrue(Path(result["artifacts"]["failure"]).exists())
            self.assertFalse((Path(config["output_root"]) / "missing-weight" / "completion.json").exists())

    def test_output_inside_source_and_unsafe_task_ids_are_refused(self):
        with temporary_workspace() as root:
            config = fixture_configuration(root)
            config["output_root"] = str(Path(config["dataset_root"]) / "bad-output")
            result = audit_dataset(config, "attempt")
            self.assertEqual(result["status"], "failed")
            self.assertFalse(Path(config["output_root"]).exists())
            result = audit_dataset(config, "../escape")
            self.assertEqual(result["status"], "failed")
            self.assertIn("safe single", result["errors"][0]["message"])


if __name__ == "__main__":
    unittest.main()
