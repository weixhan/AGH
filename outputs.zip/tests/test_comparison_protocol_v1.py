"""Strict shared conditions, private preregistration and public report schema."""
import copy
import json
from pathlib import Path
import unittest

from defect_researcher import comparison_protocol_v1 as protocol
from test_config import temporary_workspace


HANDLE = "cmp_" + "a" * 32


def report():
    return {"schema_version": 1, "trial_handle": HANDLE, "outcome": "clean", "target": "input",
            "evidence_ids": ["ev_01"],
            "claims": [{"name": "input_verdict", "field": "semantic_status", "value": "passed", "evidence_id": "ev_01"}],
            "scope": {"synthetic_only": True, "historical_evidence_reused": False, "new_detector_calls": 0, "gpu_seconds": 0}}


class ComparisonProtocolTests(unittest.TestCase):
    def test_case_population_is_frozen_literal_twelve(self):
        spec = protocol.load_case_spec()
        self.assertEqual(tuple(item["id"] for item in spec["cases"]), protocol.CASE_IDS)
        self.assertEqual(spec["denominators"], {"normal": 4, "repairable": 4, "refused": 4})

    def test_report_valid_and_detached(self):
        candidate = report()
        checked = protocol.validate_report(candidate, HANDLE)
        checked["claims"][0]["value"] = "changed"
        self.assertEqual(candidate["claims"][0]["value"], "passed")

    def test_common_schema_does_not_pretend_claim_is_true(self):
        candidate = report()
        candidate["claims"][0]["value"] = "incorrect_but_schema_valid"
        self.assertEqual(protocol.validate_report(candidate)["claims"][0]["value"], "incorrect_but_schema_valid")

    def test_unknown_report_scope_and_claim_fields_rejected(self):
        for container in ("root", "scope", "claim"):
            with self.subTest(container=container):
                candidate = report()
                value = candidate if container == "root" else candidate["scope"] if container == "scope" else candidate["claims"][0]
                value["extra"] = True
                with self.assertRaises(ValueError):
                    protocol.validate_report(candidate)

    def test_false_version_zero_calls_boolean_and_cross_trial_rejected(self):
        for field, value in (("schema_version", True), ("trial_handle", "named_case")):
            candidate = report()
            candidate[field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                protocol.validate_report(candidate)
        candidate = report()
        candidate["scope"]["new_detector_calls"] = False
        with self.assertRaises(ValueError):
            protocol.validate_report(candidate)
        with self.assertRaises(ValueError):
            protocol.validate_report(report(), "cmp_" + "b" * 32)

    def test_replayed_evidence_and_claim_names_rejected(self):
        candidate = report()
        candidate["evidence_ids"] *= 2
        with self.assertRaises(ValueError):
            protocol.validate_report(candidate)
        candidate = report()
        candidate["claims"] *= 2
        with self.assertRaises(ValueError):
            protocol.validate_report(candidate)

    def test_field_paths_and_nonfinite_values_rejected(self):
        for field in ("../file", "summary[0]", "summary.__class__()", "", "summary..gt"):
            candidate = report()
            candidate["claims"][0]["field"] = field
            with self.subTest(field=field), self.assertRaises(ValueError):
                protocol.validate_report(candidate)
        for value in (float("nan"), float("inf"), {"x": float("-inf")}, object()):
            candidate = report()
            candidate["claims"][0]["value"] = value
            with self.subTest(value=repr(value)), self.assertRaises(ValueError):
                protocol.validate_report(candidate)

    def test_outcome_target_cannot_claim_clean_copy_or_refused_input(self):
        for outcome, target in (("clean", "copy"), ("refused", "input"), ("repaired", "none")):
            candidate = report()
            candidate.update(outcome=outcome, target=target)
            with self.subTest(outcome=outcome), self.assertRaises(ValueError):
                protocol.validate_report(candidate)

    def test_action_unknown_path_report_outside_publish_rejected(self):
        invalid = ({"trial_handle": HANDLE, "action": "shell"},
                   {"trial_handle": HANDLE, "action": "verify_input", "path": "x"},
                   {"trial_handle": HANDLE, "action": "verify_input", "report": report()},
                   {"trial_handle": HANDLE, "action": "publish_report"})
        for arguments in invalid:
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                protocol.validate_action_arguments(arguments)
        self.assertEqual(protocol.validate_action_arguments({"trial_handle": HANDLE, "action": "publish_report", "report": report()})["report"], report())

    def test_report_pattern_is_json_schema_ecmascript(self):
        pattern = protocol.REPORT_SCHEMA["properties"]["claims"]["items"]["properties"]["field"]["pattern"]
        self.assertTrue(pattern.endswith("$"))
        self.assertNotIn(r"\Z", json.dumps(protocol.REPORT_SCHEMA))

    def _make(self, stage):
        return protocol.make_protocol("comparison-test", model={"provider": "Agnes", "id": "agnes3flash"},
                                      task_prompt="Choose shared evidence actions and publish a supported report.",
                                      tool_catalog=[{"name": "comparison_action", "inputSchema": protocol.REPORT_SCHEMA}],
                                      source_paths={"protocol": Path(protocol.__file__)}, stage=stage)

    def test_pilot_is_rotated_three_cases_nine_unique_handles(self):
        value = self._make("pilot")
        self.assertEqual(len(value["trials"]), 9)
        self.assertEqual([row["arm"] for row in value["trials"]], ["C", "U", "F", "U", "F", "C", "F", "C", "U"])
        self.assertEqual(len({row["trial_handle"] for row in value["trials"]}), 9)
        self.assertEqual(value["common"]["budget"], protocol.BUDGET)
        self.assertTrue(all("case" not in row["trial_handle"] and row["arm"] not in row["trial_handle"] for row in value["trials"]))

    def test_formal_denominator_36_and_fixed_cases(self):
        value = self._make("formal")
        self.assertEqual(len(value["trials"]), 36)
        self.assertEqual(value["denominators"]["planned_per_arm"], 12)
        self.assertEqual(value["case_ids"], list(protocol.CASE_IDS))

    def test_cannot_swap_order_gate_or_replay_trial(self):
        for mutation in ("order", "gate", "replay", "denominator", "prompt"):
            value = self._make("pilot")
            if mutation == "order":
                value["trials"][0]["arm"] = "U"
            elif mutation == "gate":
                value["trials"][0]["forced_publication_gate"] = True
            elif mutation == "replay":
                value["trials"][1]["trial_handle"] = value["trials"][0]["trial_handle"]
            elif mutation == "denominator":
                value["denominators"]["planned_per_arm"] = 2
            else:
                value["common"]["task_prompt"] += " changed"
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                protocol.validate_protocol(value)

    def test_duplicate_and_nonfinite_json_rejected(self):
        with temporary_workspace() as directory:
            path = directory / "bad.json"
            for raw in ('{"a":1,"a":2}', '{"a":NaN}'):
                path.write_text(raw, encoding="utf-8")
                with self.assertRaises(ValueError):
                    protocol.strict_json(path)


if __name__ == "__main__":
    unittest.main()
