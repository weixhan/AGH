"""Version 3 worker rejection tests using only Python backend/CUDA stubs."""
from contextlib import nullcontext
from copy import deepcopy
import builtins
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from defect_researcher import sliced_worker_v3 as worker


OPTIONS = {"imgsz": 640, "batch": 1, "conf": .001, "iou": .7, "max_det": 300,
           "rect": False, "augment": False, "agnostic_nms": False,
           "quantize": None, "nms": None}


def options(**changes):
    return {**OPTIONS, **changes}


class Event:
    def __init__(self, **unused):
        self.record = Mock()

    def elapsed_time(self, other):
        return 2.5


def tensor(values):
    return SimpleNamespace(cpu=lambda: SimpleNamespace(tolist=lambda: values))


def predictor(option_values):
    return SimpleNamespace(args=SimpleNamespace(**option_values), imgsz=[640, 640],
                           model=SimpleNamespace(device="cuda:0", fp16=False))


def torch_stub():
    value = ModuleType("torch")
    value.__version__ = "stub-torch"
    value.float32 = "torch.float32"
    value.version = SimpleNamespace(cuda="stub-cuda")
    value.cuda = SimpleNamespace(is_available=lambda: True, synchronize=Mock(),
        Event=Event, reset_peak_memory_stats=Mock(), max_memory_allocated=lambda: 0,
        get_device_name=lambda device: "stub-gpu",
        get_device_properties=lambda device: SimpleNamespace(total_memory=0), empty_cache=Mock())
    value.backends = SimpleNamespace(cuda=SimpleNamespace(matmul=SimpleNamespace(allow_tf32=False)),
        cudnn=SimpleNamespace(allow_tf32=False, benchmark=False, deterministic=True, version=lambda: 0))
    value.inference_mode = nullcontext
    value.autocast = lambda **unused: nullcontext()
    return value


def backend(*, existing=None, creation_options=None):
    """Construct the real predict method's state without any imported backend."""
    value = object.__new__(worker.DetectorBackend)
    value.torch = torch_stub()
    value.expected_environment = {"actual_predictor_options": deepcopy(OPTIONS)}
    value.options = {**OPTIONS, "half": False, "device": "0"}
    value.actual_input_dtype, value.actual_input_device = "torch.float32", "cuda:0"
    value.last_timing = None
    network = SimpleNamespace(parameters=lambda: iter([SimpleNamespace(dtype="torch.float32")]))
    model = SimpleNamespace(predictor=existing, model=network)
    result = SimpleNamespace(path="input.png", orig_shape=(1080, 1920),
        boxes=SimpleNamespace(xyxy=tensor([[1., 2., 3., 4.]]), conf=tensor([.5]), cls=tensor([0.])),
        speed={"preprocess": 1., "inference": 1., "postprocess": 1.})
    def run(**kwargs):
        if model.predictor is None:
            model.predictor = predictor(deepcopy(OPTIONS if creation_options is None else creation_options))
        return [result]
    model.predict = Mock(side_effect=run)
    value.model = model
    return value


class SlicedWorkerV3Tests(unittest.TestCase):
    def test_reference_none_matches_the_exact_ten_sealed_controls(self):
        self.assertEqual(worker._validate_reference_options({"actual_predictor_options": deepcopy(OPTIONS)}), OPTIONS)
        self.assertIs(worker.EXPECTED_PREDICTOR_OPTIONS["nms"], None)

    def test_bad_reference_nms_refuses_before_any_heavy_import(self):
        original_import = builtins.__import__
        heavy = []
        def guarded_import(name, *args, **kwargs):
            if name.split(".", 1)[0] in {"torch", "ultralytics", "cv2", "numpy"}:
                heavy.append(name)
                raise AssertionError("Heavy import is forbidden in this rejection test")
            return original_import(name, *args, **kwargs)
        for bad in (False, True, "None", "false", 0, 0., [], {}):
            with self.subTest(nms=bad), patch("builtins.__import__", side_effect=guarded_import):
                with self.assertRaisesRegex(ValueError, "nms"):
                    worker.DetectorBackend({"reference_environment": {"actual_predictor_options": options(nms=bad)}})
        self.assertEqual(heavy, [])

    def test_missing_reference_controls_refuse_before_backend_setup(self):
        for environment in (None, {}, {"actual_predictor_options": None},
                            {"actual_predictor_options": {k: v for k, v in OPTIONS.items() if k != "nms"}}):
            with self.subTest(environment=environment), patch.dict(worker.os.environ, {}, clear=True):
                before = dict(worker.os.environ)
                with self.assertRaises(ValueError):
                    worker.DetectorBackend({"reference_environment": environment})
                self.assertEqual(dict(worker.os.environ), before)

    def test_reference_control_types_are_not_coerced(self):
        changes = {"imgsz": 640., "batch": True, "conf": "0.001", "iou": ".7",
                   "max_det": 300., "rect": 0, "augment": 0, "agnostic_nms": 0,
                   "quantize": False, "nms": False}
        for key, changed in changes.items():
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, key):
                worker._validate_reference_options({"actual_predictor_options": options(**{key: changed})})

    def test_reference_unknown_control_and_each_missing_control_refuse(self):
        changed = options(extra=False)
        with self.assertRaisesRegex(ValueError, "unexpected"):
            worker._validate_reference_options({"actual_predictor_options": changed})
        for key in OPTIONS:
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "missing"):
                worker._validate_reference_options({"actual_predictor_options": {k: v for k, v in OPTIONS.items() if k != key}})

    def test_constructor_explicitly_passes_none_without_real_backend_imports(self):
        torch = torch_stub()
        net = SimpleNamespace(float=Mock(), register_forward_pre_hook=Mock(return_value=SimpleNamespace(remove=Mock())))
        model = SimpleNamespace(model=net, names={0: "crushed"}, predictor=None)
        ultra, cv2 = ModuleType("ultralytics"), ModuleType("cv2")
        ultra.YOLO = Mock(return_value=model)
        ultra.__version__, cv2.__version__ = "stub-ultra", "stub-cv2"
        environment = {"actual_predictor_options": deepcopy(OPTIONS), "python": "stub", "torch": "stub",
            "ultralytics": "stub", "cuda": "stub", "cudnn": "stub", "gpu_name": "stub", "gpu_total_bytes": 0}
        request = {"reference_environment": environment, "directory": "unused-test-directory",
                   "weights_path": "unused-test-weights", "protocol": {"class_names": {"0": "crushed"}}}
        with patch.dict(sys.modules, {"torch": torch, "ultralytics": ultra, "cv2": cv2}), \
             patch.object(worker.DetectorBackend, "environment", return_value=environment), \
             patch.dict(worker.os.environ):
            value = worker.DetectorBackend(request)
        self.assertIn("nms", value.options)
        self.assertIsNone(value.options["nms"])
        ultra.YOLO.assert_called_once_with("unused-test-weights", task="detect")
        torch.cuda.synchronize.assert_not_called()

    def test_first_prediction_with_none_preserves_returned_evidence(self):
        value = backend()
        observed = value.predict("input.png", (1080, 1920))
        value.model.predict.assert_called_once()
        self.assertIn("nms", value.model.predict.call_args.kwargs)
        self.assertIsNone(value.model.predict.call_args.kwargs["nms"])
        self.assertEqual(observed["effective_options"], OPTIONS)
        self.assertIsNone(observed["effective_options"]["nms"])
        self.assertEqual(observed["local_predictions"], [{"class_id": 0, "confidence": .5, "xyxy": [1., 2., 3., 4.]}])
        self.assertEqual(value.last_timing["gpu_seconds"], .0025)

    def test_existing_predictor_every_control_checked_before_prediction(self):
        changes = {"imgsz": 960, "batch": True, "conf": .01, "iou": .6,
                   "max_det": 299, "rect": 0, "augment": True, "agnostic_nms": True,
                   "quantize": False, "nms": False}
        for key, changed in changes.items():
            with self.subTest(key=key):
                value = backend(existing=predictor(options(**{key: changed})))
                with self.assertRaisesRegex(ValueError, key):
                    value.predict("input.png", (1080, 1920))
                value.model.predict.assert_not_called()
                value.torch.cuda.synchronize.assert_not_called()
                self.assertIsNone(value.last_timing)

    def test_existing_predictor_missing_control_refuses_before_prediction(self):
        for key in OPTIONS:
            with self.subTest(key=key):
                value = backend(existing=predictor({k: v for k, v in OPTIONS.items() if k != key}))
                with self.assertRaisesRegex(ValueError, key):
                    value.predict("input.png", (1080, 1920))
                value.model.predict.assert_not_called()
                value.torch.cuda.synchronize.assert_not_called()

    def test_first_creation_drift_closes_timing_but_returns_no_observation(self):
        changes = {"imgsz": 640., "batch": True, "conf": "0.001", "iou": .6,
                   "max_det": 299, "rect": 0, "augment": True, "agnostic_nms": True,
                   "quantize": False, "nms": False}
        for key, changed in changes.items():
            with self.subTest(key=key):
                value = backend(creation_options=options(**{key: changed}))
                with self.assertRaisesRegex(ValueError, key):
                    value.predict("input.png", (1080, 1920))
                value.model.predict.assert_called_once()
                self.assertEqual(value.last_timing["gpu_seconds"], .0025)

    def test_first_creation_missing_nms_has_no_implicit_fallback(self):
        value = backend(creation_options={k: v for k, v in OPTIONS.items() if k != "nms"})
        with self.assertRaisesRegex(ValueError, "missing: nms"):
            value.predict("input.png", (1080, 1920))
        value.model.predict.assert_called_once()
        self.assertEqual(value.last_timing["gpu_seconds"], .0025)

    def test_none_then_reused_predictor_false_refuses_second_call(self):
        value = backend()
        value.predict("input.png", (1080, 1920))
        value.model.predictor.args.nms = False
        sync_calls = value.torch.cuda.synchronize.call_count
        with self.assertRaisesRegex(ValueError, "nms"):
            value.predict("input.png", (1080, 1920))
        self.assertEqual(value.model.predict.call_count, 1)
        self.assertEqual(value.torch.cuda.synchronize.call_count, sync_calls)
        self.assertIsNone(value.last_timing)

    def test_outgoing_and_reference_options_drift_refuse_without_prediction(self):
        for target in ("requested", "reference"):
            with self.subTest(target=target):
                value = backend(existing=predictor(OPTIONS))
                (value.options if target == "requested" else value.expected_environment["actual_predictor_options"])["nms"] = False
                with self.assertRaisesRegex(ValueError, "nms"):
                    value.predict("input.png", (1080, 1920))
                value.model.predict.assert_not_called()
                value.torch.cuda.synchronize.assert_not_called()

    def test_final_environment_option_drift_refuses_before_source_imports(self):
        value = backend(existing=predictor(options(nms=False)))
        with self.assertRaisesRegex(ValueError, "nms"):
            value.environment()

    def test_noninitial_environment_requires_a_created_predictor(self):
        value = backend()
        with self.assertRaisesRegex(ValueError, "missing"):
            value.environment()

    def test_cold_resume_uses_verified_environment_without_free_warmup(self):
        value = backend()
        prior = {"actual_predictor_options": deepcopy(OPTIONS), "actual_input_dtype": "torch.float32",
                 "model_parameters_dtype": "torch.float32", "actual_input_device": "cuda:0",
                 "actual_predictor_device": "cuda:0", "actual_predictor_fp16": False,
                 "tf32_matmul": False, "tf32_cudnn": False, "cudnn_benchmark": False,
                 "cudnn_deterministic": True, "actual_predictor_imgsz": [640, 640],
                 "python": "fixture", "gpu_name": "fixture", "peak_allocated_bytes": 10}
        current = {"python": "fixture", "gpu_name": "fixture", "peak_allocated_bytes": 1}
        with patch.object(value, "environment", return_value=current) as environment:
            merged = worker._starting_environment(value, prior)
        environment.assert_called_once_with(initial=True)
        self.assertEqual(merged["actual_predictor_options"], OPTIONS)
        self.assertEqual(merged["peak_allocated_bytes"], 1)
        value.model.predict.assert_not_called()
        value.torch.cuda.synchronize.assert_not_called()
        value.predict("input.png", (1080, 1920))
        value.model.predict.assert_called_once()  # one formal call, no preceding warmup

    def test_cold_resume_dependency_drift_refuses_without_prediction(self):
        value = backend()
        prior = {"actual_predictor_options": deepcopy(OPTIONS), "actual_input_dtype": "torch.float32",
                 "model_parameters_dtype": "torch.float32", "actual_input_device": "cuda:0",
                 "actual_predictor_device": "cuda:0", "actual_predictor_fp16": False,
                 "tf32_matmul": False, "tf32_cudnn": False, "cudnn_benchmark": False,
                 "cudnn_deterministic": True, "actual_predictor_imgsz": [640, 640], "gpu_name": "old"}
        with patch.object(value, "environment", return_value={"gpu_name": "changed"}), \
                self.assertRaisesRegex(ValueError, "gpu_name"):
            worker._starting_environment(value, prior)
        value.model.predict.assert_not_called()

    def test_bad_saved_resume_controls_refuse_before_imports_backend_or_output(self):
        from defect_researcher import sliced_task_v3
        factory = Mock()
        for bad in (False, True, "null", 0):
            request = {"reference_environment": {"actual_predictor_options": deepcopy(OPTIONS)},
                       "resume_environment": {"actual_predictor_options": options(nms=bad)}}
            with self.subTest(nms=bad), patch.object(sliced_task_v3, "validate_worker_request"), \
                    self.assertRaisesRegex(ValueError, "nms"):
                worker._execute(request, backend_factory=factory)
        factory.assert_not_called()

    def test_exhausted_gpu_or_exact_deadline_has_no_remaining_prediction_budget(self):
        protocol = {"budgets": {"max_formal_calls": 10, "max_warmup_calls": 1, "max_gpu_seconds": 1.,
                               "max_inference_wall_seconds": 10., "max_task_wall_seconds": 20.}}
        budget = {"formal_attempts": [], "warmup_attempts": [], "gpu_seconds": 0.,
                  "inference_started_epoch": 90., "task_started_epoch": 80.,
                  "inference_wall_seconds": 0., "task_wall_seconds": 0.}
        for variation, changed in (("gpu", {"gpu_seconds": 1.}),
                                   ("inference", {}), ("task", {"inference_started_epoch": None})):
            candidate = {**budget, **changed}
            now = 99. if variation == "gpu" else 100.
            with self.subTest(variation=variation), self.assertRaises((RuntimeError, TimeoutError)):
                worker._check_prediction_budget(candidate, protocol, now=now)
        worker._check_prediction_budget({**budget, "gpu_seconds": .999}, protocol, now=99.)

    def test_request_validation_runs_before_imports_backend_or_output_access(self):
        from defect_researcher import sliced_task_v3
        factory = Mock()
        with patch.object(sliced_task_v3, "validate_worker_request", side_effect=ValueError("unbound execution source")) as validator:
            with self.assertRaisesRegex(ValueError, "unbound execution source"):
                worker._execute({"directory": "not-created"}, backend_factory=factory)
        validator.assert_called_once_with({"directory": "not-created"})
        factory.assert_not_called()

    def test_bad_reference_rejected_after_request_binding_before_backend(self):
        from defect_researcher import sliced_task_v3
        factory = Mock()
        request = {"reference_environment": {"actual_predictor_options": options(nms=False)}}
        with patch.object(sliced_task_v3, "validate_worker_request") as validator:
            with self.assertRaisesRegex(ValueError, "nms"):
                worker._execute(request, backend_factory=factory)
        validator.assert_called_once_with(request)
        factory.assert_not_called()

    def test_no_production_override_or_fault_injection_interface(self):
        import inspect
        source = inspect.getsource(worker)
        self.assertNotIn("fault_injection", source)
        self.assertNotIn("validation_callback", source)
        self.assertIn("from .sliced_task_v3 import validate_worker_request", source)
        self.assertEqual(list(inspect.signature(worker._execute).parameters), ["request", "backend_factory"])


if __name__ == "__main__":
    unittest.main()
