"""CPU contract tests; fixtures never publish real recovery acceptance."""
from copy import deepcopy
from io import BytesIO
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from defect_researcher import resolution_research_mcp_v1 as module
from defect_researcher.resolution_research_mcp_server_v1 import ResolutionResearchMCPServer, serve, ACTION_TOOL, READ_TOOL
from test_config import temporary_workspace


class Clock:
    epoch = 1000.
    mono = 2000.
    def time(self): return self.epoch
    def monotonic(self): return self.mono


class Fixture:
    def __init__(self, root):
        self.root = root
        self.clock = Clock()
        self.steps = []
        self.cost_known = True
        self.verification_passed = True
        self.missing_denominator = False
        self.candidate_better = False
        self.invalid_metric = False
        self.config = {key: str(root / key) for key in ("research_root", "dataset_root", "raw_root", "split_dir", "weights_path", "output_root")}
        self.protocol = {"schema_version": 1, "kind": "resolution_research_mcp_deployment_v1", "request_id": "fixed",
                         "task_id": module.PREFIX + "fixed", "workspace_root": str(root),
                         "started_epoch": 1000., "started_monotonic": 2000., "deadline_epoch": 3400.,
                         "deadline_monotonic": 4400., "contract_sha256": module.sha(module.CONTRACT)}

    def runtime(self):
        return module.Runtime(test_dependencies=module.TestDependencies(self.config, self.protocol, self.root / "registry", self, self.verify, self.clock))

    def prepare_task(self, config, task_id):
        directory = Path(config["output_root"]) / task_id
        directory.mkdir(parents=True, exist_ok=False)
        value = {"task_directory": str(directory), "task_id": task_id, "started_epoch": 1000., "deadline_epoch": 2800.,
                 "started_monotonic": 2000., "deadline_monotonic": 3800., "fixture_only": True}
        module.write(directory / "registration.json", value)
        self.steps.append("prepare")
        return value

    def run_preflight(self, directory):
        self.steps.append("audit_geometry")
        value = {"status": "preflight_passed", "task_id": self.protocol["task_id"], "fixture_only": True, "new_prediction_calls": 0,
                 "original_deadline_epoch": 2800., "original_deadline_monotonic": 3800., "deadline_reset": False}
        module.write(Path(directory) / "staged_preflight_receipt.json", value)
        return value

    def run_until_fault(self, directory):
        self.steps.extend(["reference_640", "reference_960", "fault_640", "fault_960"])
        fault = Path(directory) / "fault"
        fault.mkdir()
        module.write(fault / "failure.json", {"closed_cost": self.cost_known, "ledger": {"cost_known": self.cost_known, "open_call": None, "failed_detector_call": False}})
        return {"status": "recovery_pending", "task_id": self.protocol["task_id"], "fixture_only": True}

    def resume_task(self, directory):
        self.steps.append("resume_960")
        baseline = {"mAP50": .4, "mAP50_95": .2, "operating_point": {"normal_image_fp_rate": .02, "normal_images": 20}}
        candidate = {"mAP50": .5 if self.candidate_better else .3, "mAP50_95": .3 if self.candidate_better else .1,
                     "operating_point": {"normal_image_fp_rate": .02 if self.candidate_better else .1, "normal_images": 20}}
        if self.missing_denominator:
            candidate["operating_point"].pop("normal_images")
        if self.invalid_metric:
            candidate["mAP50"] = None
        for name, value in (("reference_640", baseline), ("reference_960", candidate)):
            root = Path(directory) / "groups" / name
            root.mkdir(parents=True)
            module.write(root / "metrics.json", value)
        return {"status": "passed_fixture_only", "task_id": self.protocol["task_id"], "fixture_only": True}

    def verify(self, directory, prepublication=False):
        return {"status": "passed_fixture_only" if self.verification_passed else "failed", "real_recovery_accepted": False,
                "fixture_only": True, "checks": {"fixture_contract": self.verification_passed}}


def call(runtime, action, read=False):
    return runtime.call({"request_id": "fixed", "action": action}, read_only=read)


class RuntimeTests(unittest.TestCase):
    def prepare(self, fixture):
        runtime = fixture.runtime()
        response = call(runtime, "audit_geometry")
        self.assertEqual((response["status"], response["phase"], response["host_wait_required"]), ("running", "preflight", True))
        self.assertEqual(runtime.inspect_owned_worker()["status"], "preflight_passed")
        call(runtime, "register_hypothesis")
        call(runtime, "start_registered_experiment")
        return runtime

    def reviewed(self, fixture):
        runtime = self.prepare(fixture)
        self.assertEqual(call(runtime, "status", True)["status"], "recovery_pending")
        self.assertNotIn("resume_960", fixture.steps)
        call(runtime, "resume_registered_failure")
        self.assertEqual(call(runtime, "status", True)["status"], "experiment_completed")
        return runtime, call(runtime, "independent_review", True)

    def test_explicit_model_owned_recovery_and_stop_decision_fixture_only(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            runtime, review = self.reviewed(fixture)
            self.assertEqual(review["only_supported_decision_action"], "decide_stop_resolution")
            call(runtime, "decide_stop_resolution")
            report = call(runtime, "publish_report")
            self.assertEqual(report["report"]["resolution_decision"], "resolution_candidate_stopped")
            self.assertFalse(report["science_accepted"])
            self.assertFalse(report["report"]["recovery_accepted"])
            self.assertFalse((runtime.taskdir / "completion.json").exists())
            self.assertEqual(fixture.steps[-1], "resume_960")
            self.assertEqual(report["report"]["budget_scope"]["domain_wall_seconds"], 1800)
            self.assertEqual(report["report"]["budget_scope"]["outer_wall_seconds"], 2400)

    def test_model_must_read_actual_fault_before_resuming(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            runtime = self.prepare(fixture)
            with self.assertRaisesRegex(ValueError, "read the actual fault"):
                call(runtime, "resume_registered_failure")
            self.assertNotIn("resume_960", fixture.steps)

    def test_unknown_cost_is_rejected_and_stop_report_preserves_failed_experiment(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            fixture.cost_known = False
            runtime = self.prepare(fixture)
            call(runtime, "status", True)
            with self.assertRaisesRegex(ValueError, "Unknown/open/failed"):
                call(runtime, "resume_registered_failure")
            call(runtime, "stop_insufficient_evidence")
            report = call(runtime, "publish_report")
            self.assertFalse(report["science_accepted"])
            self.assertEqual(report["report"]["resolution_decision"], "insufficient_evidence_stop")
            self.assertNotIn("resume_960", fixture.steps)

    def test_unsupported_model_decision_rejected_before_action_consumption(self):
        with temporary_workspace() as root:
            runtime, _ = self.reviewed(Fixture(root))
            with self.assertRaisesRegex(ValueError, "unsupported"):
                call(runtime, "decide_retain_resolution")
            self.assertEqual(call(runtime, "decide_stop_resolution")["status"], "decided")

    def test_missing_normal_denominator_requires_insufficient_stop(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            fixture.missing_denominator = True
            runtime, report = self.reviewed(fixture)
            self.assertEqual(report["only_supported_decision_action"], "decide_insufficient_evidence")
            call(runtime, "decide_insufficient_evidence")
            self.assertEqual(call(runtime, "publish_report")["report"]["resolution_decision"], "insufficient_evidence_stop")

    def test_missing_metric_value_cannot_accept_resolution_candidate(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            fixture.invalid_metric = True
            runtime, report = self.reviewed(fixture)
            self.assertEqual(report["only_supported_decision_action"], "decide_insufficient_evidence")
            call(runtime, "decide_insufficient_evidence")
            self.assertFalse(call(runtime, "publish_report")["science_accepted"])

    def test_incomplete_production_source_lock_refuses_before_registry_or_task_creation(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            protocol, lock = root / "protocol.json", root / "lock.json"
            module.write(protocol, fixture.protocol)
            module.write(lock, {"kind": "resolution_research_mcp_source_lock_v1", "status": "passed_engineering_only", "files": []})
            with self.assertRaisesRegex(ValueError, "omits a required"):
                module.Runtime(protocol, module.sha(protocol), lock, module.sha(lock))
            self.assertFalse((root / "mcp-owned").exists())
            self.assertFalse((Path(fixture.config["output_root"]) / fixture.protocol["task_id"]).exists())

    def test_deployment_pin_drift_refuses_before_registry(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            protocol, lock = root / "protocol.json", root / "lock.json"
            module.write(protocol, fixture.protocol)
            module.write(lock, {})
            expected = module.sha(protocol)
            protocol.write_text('{}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, "pin changed"):
                module.Runtime(protocol, expected, lock, module.sha(lock))
            self.assertFalse((root / "mcp-owned").exists())

    def test_improved_candidate_stays_validation_only_and_never_registers_next_experiment(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            fixture.candidate_better = True
            runtime, report = self.reviewed(fixture)
            self.assertEqual(report["only_supported_decision_action"], "decide_retain_resolution")
            call(runtime, "decide_retain_resolution")
            self.assertFalse(call(runtime, "publish_report")["report"]["next_plan"]["new_experiment_registered"])

    def test_resume_status_and_independent_review_are_once_only(self):
        with temporary_workspace() as root:
            runtime, _ = self.reviewed(Fixture(root))
            for action, readonly in (("resume_registered_failure", False), ("status", True), ("independent_review", True)):
                with self.assertRaises(ValueError):
                    call(runtime, action, readonly)

    def test_review_must_follow_model_observation_of_completion(self):
        with temporary_workspace() as root:
            runtime = self.prepare(Fixture(root))
            call(runtime, "status", True)
            call(runtime, "resume_registered_failure")
            with self.assertRaisesRegex(ValueError, "One independent review"):
                call(runtime, "independent_review", True)

    def test_original_outer_clock_expiry_and_reversal_reject(self):
        for epoch in (3400., 999.):
            with temporary_workspace() as root:
                fixture = Fixture(root)
                runtime = fixture.runtime()
                fixture.clock.epoch = epoch
                with self.assertRaisesRegex(RuntimeError, "deadline expired or clock reversed"):
                    call(runtime, "audit_geometry")

    def test_request_arguments_cannot_select_paths_budget_commands_or_fixture(self):
        with temporary_workspace() as root:
            runtime = Fixture(root).runtime()
            for key in ("path", "budget", "command", "test_dependencies"):
                with self.assertRaises(ValueError):
                    runtime.call({"request_id": "fixed", "action": "audit_geometry", key: "escape"})
            with self.assertRaises(ValueError):
                runtime.call({"request_id": "other", "action": "audit_geometry"})

    def test_preflight_evidence_drift_blocks_hypothesis(self):
        with temporary_workspace() as root:
            runtime = Fixture(root).runtime()
            call(runtime, "audit_geometry")
            runtime.inspect_owned_worker()
            (runtime.taskdir / "staged_preflight_receipt.json").write_text('{}', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, "Evidence changed"):
                call(runtime, "register_hypothesis")

    def test_preflight_worker_wrapper_binds_original_clocks_and_host_observation_has_no_model_debit(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            runtime = fixture.runtime()
            result = call(runtime, "audit_geometry")
            self.assertEqual(result["phase"], "preflight")
            for _ in range(2):
                notice = runtime.inspect_owned_worker()
                self.assertTrue(notice["host_notification_allowed"])
                self.assertEqual(notice["evidence"]["new_prediction_calls"], 0)
                self.assertFalse(notice["evidence"]["deadline_reset"])
            state = module.read(runtime.state_path)
            self.assertEqual(state["used_actions"], ["audit_geometry"])
            self.assertEqual((state["running_reads"], state["fault_reads"], state["completed_reads"]), (0, 0, 0))
            self.assertEqual(fixture.steps, ["prepare", "audit_geometry"])
            with self.assertRaisesRegex(ValueError, "host-observed"):
                call(runtime, "status", True)

    def test_preflight_failure_requires_explicit_stop_and_cannot_start_inference(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            runtime = fixture.runtime()
            with patch.object(fixture, "run_preflight", side_effect=ValueError("actual CPU gate refused")):
                self.assertEqual(call(runtime, "audit_geometry")["status"], "running")
            notice = runtime.inspect_owned_worker()
            self.assertEqual(notice["status"], "preflight_failed")
            self.assertEqual(notice["failure"]["error"], "actual CPU gate refused")
            with self.assertRaisesRegex(ValueError, "evidence-bound stage"):
                call(runtime, "register_hypothesis")
            call(runtime, "stop_insufficient_evidence")
            self.assertFalse(call(runtime, "publish_report")["science_accepted"])
            self.assertEqual(fixture.steps, ["prepare"])

    def test_preflight_worker_result_clock_or_receipt_tamper_is_refused(self):
        for field, replacement in (("outer_deadline_epoch", 9999), ("deadline_reset", True), ("request_id", "other")):
            with temporary_workspace() as root:
                runtime = Fixture(root).runtime()
                call(runtime, "audit_geometry")
                result_path = runtime.registry / "preflight-result.json"
                wrapper = module.read(result_path)
                wrapper[field] = replacement
                module.write(result_path, wrapper, replace=True)
                with self.assertRaisesRegex(ValueError, "binding changed"):
                    runtime.inspect_owned_worker()
                self.assertEqual(module.read(runtime.state_path)["stage"], "running")

    def test_registry_reopen_never_resets_actions_or_clock(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            first = fixture.runtime()
            call(first, "audit_geometry")
            second = fixture.runtime()
            with self.assertRaises(ValueError):
                call(second, "audit_geometry")

    def test_failed_fresh_publication_review_cannot_publish_success(self):
        with temporary_workspace() as root:
            fixture = Fixture(root)
            runtime, _ = self.reviewed(fixture)
            call(runtime, "decide_stop_resolution")
            fixture.verification_passed = False
            with self.assertRaisesRegex(ValueError, "pre-report"):
                call(runtime, "publish_report")
            self.assertFalse((runtime.registry / "research_report.json").exists())


class FakeRuntime:
    protocol = {"request_id": "fixed"}
    def __init__(self): self.calls = []
    def call(self, arguments, read_only=False):
        self.calls.append((deepcopy(arguments), read_only))
        return {"request_id": "fixed", "task_id": module.PREFIX + "fixed", "status": "preflight_passed", "fixture_only": True, "science_accepted": False}


def rpc(method, params=None, identifier=1):
    return {"jsonrpc": "2.0", "id": identifier, "method": method, "params": params or {}}


class ServerTests(unittest.TestCase):
    def ready(self):
        runtime = FakeRuntime()
        server = ResolutionResearchMCPServer(runtime)
        server.handle_message(rpc("initialize", {"protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}}))
        server.handle_message({"jsonrpc": "2.0", "method": "notifications/initialized"})
        return runtime, server

    def test_two_tools_and_only_fixed_id_action_enums(self):
        _, server = self.ready()
        rows = server.handle_message(rpc("tools/list"))["result"]["tools"]
        self.assertEqual({row["name"] for row in rows}, {ACTION_TOOL, READ_TOOL})
        for row in rows:
            self.assertEqual(set(row["inputSchema"]["properties"]), {"request_id", "action"})
            self.assertFalse(row["inputSchema"]["additionalProperties"])
            self.assertEqual(row["inputSchema"]["properties"]["request_id"]["enum"], ["fixed"])

    def test_unknown_tool_extra_fields_wrong_id_and_actions_do_not_execute(self):
        runtime, server = self.ready()
        base = {"name": ACTION_TOOL, "arguments": {"request_id": "fixed", "action": "audit_geometry"}}
        for params in ({**base, "name": "exec"}, {**base, "arguments": {**base["arguments"], "path": "x"}},
                       {**base, "arguments": {"request_id": "other", "action": "audit_geometry"}},
                       {**base, "arguments": {"request_id": "fixed", "action": "run_task"}}):
            self.assertEqual(server.handle_message(rpc("tools/call", params))["error"]["code"], -32602)
        self.assertEqual(runtime.calls, [])

    def test_notifications_and_uninitialized_requests_never_execute(self):
        runtime = FakeRuntime()
        server = ResolutionResearchMCPServer(runtime)
        params = {"name": ACTION_TOOL, "arguments": {"request_id": "fixed", "action": "audit_geometry"}}
        self.assertEqual(server.handle_message(rpc("tools/call", params))["error"]["code"], -32002)
        self.assertIsNone(server.handle_message({"jsonrpc": "2.0", "method": "tools/call", "params": params}))
        self.assertEqual(runtime.calls, [])

    def test_transport_rejects_duplicate_nonfinite_overflow_and_invalid_utf8(self):
        incoming = BytesIO(b'{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}\n{"value":NaN}\n{"value":1e400}\n\xff\n')
        outgoing = BytesIO()
        serve(FakeRuntime(), stdin=incoming, stdout=outgoing)
        rows = [json.loads(line) for line in outgoing.getvalue().splitlines()]
        self.assertEqual([row["error"]["code"] for row in rows], [-32700] * 4)

    def test_fixture_cannot_be_claimed_as_science_accepted(self):
        runtime, server = self.ready()
        with patch.object(runtime, 'call', return_value={"request_id": "fixed", "task_id": module.PREFIX + "fixed", "status": "reviewed", "fixture_only": True, "science_accepted": True}):
            value = server.handle_message(rpc("tools/call", {"name": ACTION_TOOL, "arguments": {"request_id": "fixed", "action": "audit_geometry"}}))
            self.assertTrue(value["result"]["isError"])


if __name__ == '__main__': unittest.main()
