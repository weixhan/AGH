"""Test the comparison protocol boundary without a model or detector run."""
from __future__ import annotations

import copy
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import unittest

from defect_researcher.comparison_mcp_server_v6 import (
    ACTIONS, ACTION_TOOL_NAME, ComparisonMCPServer, PROTOCOL_VERSION, serve,
)
from defect_researcher.config import load_config
from test_config import temporary_workspace


PROJECT_ROOT = Path(__file__).resolve().parents[1]
HANDLE = "cmp_" + "a" * 32
INITIALIZED = {"jsonrpc": "2.0", "method": "notifications/initialized"}


def request(identifier, method, params=None):
    value = {"jsonrpc": "2.0", "id": identifier, "method": method}
    if params is not None:
        value["params"] = params
    return value


def initialize(version=PROTOCOL_VERSION):
    return request(1, "initialize", {
        "protocolVersion": version, "capabilities": {},
        "clientInfo": {"name": "comparison-boundary-test", "version": "1"},
    })


def report():
    return {"schema_version": 1, "trial_handle": HANDLE, "outcome": "clean",
            "target": "input", "evidence_ids": ["evidence1"],
            "claims": [{"name": "geometry", "field": "semantic_status",
                        "value": "ok", "evidence_id": "evidence1"}],
            "scope": {"synthetic_only": True, "historical_evidence_reused": False,
                      "new_detector_calls": 0, "gpu_seconds": 0}}


def arguments(action="inspect_input"):
    value = {"trial_handle": HANDLE, "action": action}
    if action == "publish_report":
        value["report"] = report()
    return value


def call(name=ACTION_TOOL_NAME, value=None, identifier=2):
    return request(identifier, "tools/call", {
        "name": name, "arguments": arguments() if value is None else value,
    })


class FakeRuntime:
    def __init__(self, response=None):
        self.calls = []
        self.response = response

    def execute(self, value):
        self.calls.append(copy.deepcopy(value))
        return copy.deepcopy(self.response if self.response is not None else {
            "schema_version": 1, "trial_handle": value["trial_handle"],
            "action": value["action"], "status": "executed"})


def ready(runtime=None, version=PROTOCOL_VERSION):
    server = ComparisonMCPServer(runtime=runtime or FakeRuntime())
    server.handle_message(initialize(version))
    server.handle_message(INITIALIZED)
    return server


def payload(response):
    return json.loads(response["result"]["content"][0]["text"])


def deployment(directory):
    """Pin the real launcher with a private test output root and no trial."""
    directory = Path(directory)
    configuration = load_config(PROJECT_ROOT / "config/local.json")
    configuration["output_root"] = str((directory / "outputs").resolve())
    config_path = directory / "server-config.json"
    config_path.write_text(json.dumps({"schema_version": 1, **configuration}), encoding="utf-8")
    paths = [PROJECT_ROOT / "defect_researcher/comparison_case_runtime_v1.py",
             PROJECT_ROOT / "defect_researcher/comparison_protocol_v1.py",
             PROJECT_ROOT / "defect_researcher/comparison_mcp_server_v1.py",
             PROJECT_ROOT / "run_comparison_mcp_v1.py",
             PROJECT_ROOT / "defect_researcher/comparison_mcp_server_v6.py",
             PROJECT_ROOT / "tools/verify_comparison_case_v1.py",
             PROJECT_ROOT / "run_comparison_mcp_v6.py",
             PROJECT_ROOT / "outputs/research-workflow-implementation-v1/freeze.json",
             PROJECT_ROOT / "fixtures/labelguard_cases.json",
             PROJECT_ROOT / "config/local.json", config_path]
    value = {"schema_version": 1, "kind": "comparison_case_implementation_v1", "status": "passed",
             "files": [{"role": str(index), "path": str(path.resolve()),
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                        "size_bytes": path.stat().st_size}
                       for index, path in enumerate(paths)]}
    location = directory / "source-lock.json"
    raw = (json.dumps(value, indent=2) + "\n").encode("utf-8")
    location.write_bytes(raw)
    return config_path, location, hashlib.sha256(raw).hexdigest()


def launch_command(config_path, lock_path, lock_sha):
    return [sys.executable, "-X", "utf8", "-B", str(PROJECT_ROOT / "run_comparison_mcp_v6.py"),
            "--config", str(config_path), "--source-lock", str(lock_path),
            "--expected-lock-sha256", lock_sha]


class ComparisonTransportTests(unittest.TestCase):
    def test_catalogue_has_exactly_one_shared_explicit_action_tool(self):
        server = ComparisonMCPServer(runtime=FakeRuntime())
        self.assertEqual(server.handle_message(initialize())["result"]["serverInfo"],
                         {"name": "defect-researcher-comparison-cases-v1", "version": "1.0.0"})
        server.handle_message(INITIALIZED)
        tools = server.handle_message(request(2, "tools/list"))["result"]["tools"]
        self.assertEqual([tool["name"] for tool in tools], [ACTION_TOOL_NAME])
        schema = tools[0]["inputSchema"]
        self.assertEqual(set(schema["properties"]), {"trial_handle", "action", "report"})
        self.assertEqual(schema["properties"]["action"]["enum"], list(ACTIONS))
        self.assertFalse(schema["additionalProperties"])
        self.assertIn("allOf", schema)
        self.assertNotIn("arm", schema["properties"])
        self.assertFalse(tools[0]["annotations"]["readOnlyHint"])

    def test_supported_protocol_versions_and_fallback(self):
        for version in (PROTOCOL_VERSION, "2024-11-05", "unsupported-version"):
            with self.subTest(version=version):
                server = ComparisonMCPServer(runtime=FakeRuntime())
                response = server.handle_message(initialize(version))
                expected = PROTOCOL_VERSION if version == "unsupported-version" else version
                self.assertEqual(response["result"]["protocolVersion"], expected)
                server.handle_message(INITIALIZED)
                tools = server.handle_message(request(2, "tools/list"))["result"]["tools"]
                self.assertEqual("annotations" in tools[0], expected != "2024-11-05")

    def test_tools_require_complete_handshake(self):
        runtime = FakeRuntime()
        server = ComparisonMCPServer(runtime=runtime)
        self.assertEqual(server.handle_message(call())["error"]["code"], -32002)
        server.handle_message(initialize())
        self.assertEqual(server.handle_message(call())["error"]["code"], -32002)
        self.assertFalse(runtime.calls)
        server.handle_message(INITIALIZED)
        self.assertFalse(server.handle_message(call())["result"]["isError"])

    def test_each_action_reaches_runtime_without_sequence_or_arm_added(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for action in ACTIONS:
            value = arguments(action)
            self.assertFalse(server.handle_message(call(value=value))["result"]["isError"])
            self.assertEqual(runtime.calls[-1], value)
        self.assertEqual(len(runtime.calls), 6)

    def test_model_cannot_select_private_trial_parameters(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for field in ("arm", "case_id", "path", "input_root", "output_root", "budget",
                      "deadline_epoch", "deadline_monotonic", "trusted_clock_anchor",
                      "started_epoch", "model_requests", "gpu_seconds", "source_lock",
                      "configuration", "script", "resume", "reset"):
            with self.subTest(field=field):
                self.assertIn("error", server.handle_message(call(value={**arguments(), field: "unused"})))
        self.assertFalse(runtime.calls)

    def test_handle_is_exact_opaque_namespace(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for handle in (None, True, [], {}, "normal_unrotated", "cmp-" + "a" * 32,
                       "cmp_" + "a" * 31, "cmp_" + "a" * 33,
                       "cmp_" + "A" * 32, "cmp_" + "g" * 32,
                       HANDLE + "\n", "../" + HANDLE):
            with self.subTest(handle=handle):
                self.assertIn("error", server.handle_message(call(value={**arguments(), "trial_handle": handle})))
        self.assertFalse(runtime.calls)

    def test_action_must_be_one_exact_enum_string(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for action in (None, True, [], {}, "start", "inspect_input\n", "inspect_input;repair_copy"):
            self.assertIn("error", server.handle_message(call(value={**arguments(), "action": action})))
        self.assertFalse(runtime.calls)

    def test_report_required_only_for_publication(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        self.assertIn("error", server.handle_message(call(value={"trial_handle": HANDLE, "action": "publish_report"})))
        for action in ACTIONS[:-1]:
            self.assertIn("error", server.handle_message(call(value={**arguments(action), "report": report()})))
        self.assertFalse(runtime.calls)

    def test_publication_schema_rejects_unbound_and_unsafe_reports(self):
        variants = []
        for field, value in [("trial_handle", "cmp_" + "b" * 32), ("schema_version", True),
                             ("target", "copy"), ("evidence_ids", []),
                             ("evidence_ids", ["evidence1", "evidence1"]), ("claims", [])]:
            variants.append({**report(), field: value})
        for container, field, value in [("scope", "new_detector_calls", True),
                                        ("scope", "gpu_seconds", 1),
                                        ("scope", "synthetic_only", False),
                                        ("scope", "path", "unused")]:
            candidate = report()
            candidate[container][field] = value
            variants.append(candidate)
        for field, value in [("field", "../input"), ("value", float("nan")),
                             ("evidence_id", "foreign"), ("script", "unused")]:
            candidate = report()
            candidate["claims"][0][field] = value
            variants.append(candidate)
        variants.append({**report(), "arm": "F"})
        runtime = FakeRuntime()
        server = ready(runtime)
        for candidate in variants:
            with self.subTest(candidate=candidate):
                self.assertIn("error", server.handle_message(call(value={**arguments("publish_report"), "report": candidate})))
        self.assertFalse(runtime.calls)

    def test_transport_does_not_validate_claim_truth_or_add_treatment_gate(self):
        value = arguments("publish_report")
        value["report"]["claims"][0]["value"] = "unsupported-by-evidence"
        response = {"schema_version": 1, "trial_handle": HANDLE,
                    "action": "publish_report", "status": "published",
                    "publication": {"accepted": True, "gate_enforced": False,
                                    "report_sha256": "a" * 64}}
        runtime = FakeRuntime(response)
        result = ready(runtime).handle_message(call(value=value))
        self.assertFalse(result["result"]["isError"])
        self.assertEqual(payload(result), response)
        self.assertEqual(runtime.calls[0], value)

    def test_rejected_domain_action_is_tool_error_and_cannot_be_relabelled(self):
        response = {"schema_version": 1, "trial_handle": HANDLE,
                    "action": "inspect_input", "status": "rejected",
                    "errors": [{"code": "trial_not_registered"}]}
        result = ready(FakeRuntime(response)).handle_message(call())
        self.assertTrue(result["result"]["isError"])
        self.assertEqual(payload(result), response)

    def test_runtime_response_must_be_finite_and_bound_to_action(self):
        base = {"schema_version": 1, "trial_handle": HANDLE,
                "action": "inspect_input", "status": "executed"}
        candidates = [[], {}, {**base, "schema_version": True}, {**base, "status": "completed"},
                      {**base, "trial_handle": "cmp_" + "b" * 32},
                      {**base, "action": "repair_copy"}, {**base, "value": float("inf")}]
        for candidate in candidates:
            result = ready(FakeRuntime(candidate)).handle_message(call())
            self.assertTrue(result["result"]["isError"])
            self.assertEqual(payload(result)["status"], "rejected")
            self.assertEqual(payload(result)["trial_handle"], HANDLE)
            self.assertEqual(payload(result)["action"], "inspect_input")

    def test_runtime_exception_is_tool_failure_and_protocol_survives(self):
        class Raises(FakeRuntime):
            def execute(self, value):
                raise ValueError("trial is not armed")
        server = ready(Raises())
        result = server.handle_message(call())
        self.assertTrue(result["result"]["isError"])
        self.assertEqual(payload(result)["errors"][0]["stage"], "case_action")
        self.assertEqual(server.handle_message(request(3, "ping"))["result"], {})

    def test_runtime_exception_does_not_disclose_private_case_path_or_treatment(self):
        class Raises(FakeRuntime):
            def execute(self, value):
                raise FileNotFoundError("E:/private/repair_coordinates/arm_F/case_expected.json")
        result = ready(Raises()).handle_message(call())
        text = result["result"]["content"][0]["text"]
        for hidden in ("E:/private", "repair_coordinates", "arm_F", "case_expected"):
            self.assertNotIn(hidden, text)
        self.assertEqual(payload(result)["errors"][0]["code"], "case_action_refused")

    def test_unknown_and_previous_tools_never_dispatch(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        names = ("audit_dataset", "repair_label_copy", "verify_label_geometry",
                 "run_bounded_research_workflow_v1", "get_research_workflow_status_v1",
                 "get_task_status", "unknown")
        for name in names:
            self.assertEqual(server.handle_message(call(name, {}))["error"]["code"], -32602)
        self.assertFalse(runtime.calls)

    def test_notifications_never_execute_actions(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for action in ACTIONS:
            message = call(value=arguments(action))
            message.pop("id")
            self.assertIsNone(server.handle_message(message))
        self.assertFalse(runtime.calls)

    def test_initialize_notification_and_nonempty_ready_notification_are_ignored(self):
        server = ComparisonMCPServer(runtime=FakeRuntime())
        message = initialize()
        message.pop("id")
        self.assertIsNone(server.handle_message(message))
        self.assertFalse(server.initialized)
        server.handle_message(initialize())
        server.handle_message({**INITIALIZED, "params": {"arm": "F"}})
        self.assertFalse(server.ready)

    def test_invalid_rpc_ids_do_not_dispatch(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        for identifier in (True, False, None, [], {}, 1.5, float("nan")):
            self.assertIn("error", server.handle_message(call(identifier=identifier)))
        self.assertFalse(runtime.calls)

    def test_invalid_envelopes_and_metadata_do_not_dispatch(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        messages = [None, [], "invalid", {**call(), "jsonrpc": "1.0"},
                    {**call(), "arm": "U"}, {**call(), "params": []},
                    request(2, "tools/call", {"name": []}),
                    request(2, "tools/call", {"name": ACTION_TOOL_NAME}),
                    request(2, "tools/call", {**call()["params"], "budget": 120}),
                    request(2, "tools/call", {**call()["params"], "_meta": []})]
        for message in messages:
            self.assertIn("error", server.handle_message(message))
        self.assertFalse(runtime.calls)

    def test_client_metadata_cannot_expand_domain_arguments(self):
        runtime = FakeRuntime()
        message = call()
        message["params"]["_meta"] = {"progressToken": "token", "arm": "F"}
        self.assertFalse(ready(runtime).handle_message(message)["result"]["isError"])
        self.assertEqual(runtime.calls, [arguments()])

    def test_batch_and_utf8_ids_keep_framing_and_ignore_notifications(self):
        runtime = FakeRuntime()
        server = ComparisonMCPServer(runtime=runtime)
        response = server.handle_message([initialize(), INITIALIZED, call(identifier="中文"),
                                          {"jsonrpc": "2.0", "method": "tools/call", "params": call()["params"]},
                                          request(9, "ping"), []])
        self.assertEqual([item["id"] for item in response], [1, "中文", 9, None])
        self.assertEqual(runtime.calls, [arguments()])
        self.assertIsNone(server.handle_message([INITIALIZED]))

    def test_catalogue_is_fresh_copy_not_mutable_session_policy(self):
        server = ready()
        first = server.handle_message(request(2, "tools/list"))["result"]["tools"]
        first[0]["inputSchema"]["properties"]["report"]["properties"].clear()
        second = server.handle_message(request(3, "tools/list"))["result"]["tools"]
        self.assertIn("scope", second[0]["inputSchema"]["properties"]["report"]["properties"])

    def test_bad_initialize_cursor_and_unknown_method_are_refused(self):
        runtime = FakeRuntime()
        server = ready(runtime)
        self.assertIn("error", server.handle_message(request(2, "tools/list", {"cursor": "next"})))
        self.assertEqual(server.handle_message(request(3, "shell"))["error"]["code"], -32601)
        for field, value in [("capabilities", []), ("clientInfo", {}),
                             ("protocolVersion", True), ("path", "unused")]:
            message = initialize()
            message["params"][field] = value
            uninitialized = ComparisonMCPServer(runtime=runtime)
            self.assertIn("error", uninitialized.handle_message(message))
            self.assertFalse(uninitialized.initialized)
        self.assertFalse(runtime.calls)


class ComparisonStdioTests(unittest.TestCase):
    def test_real_launcher_negotiates_and_refuses_unregistered_handle(self):
        frames = [initialize("2024-11-05"), INITIALIZED, request(3, "tools/list"), call(),
                  request("中文-id", "ping")]
        with temporary_workspace() as directory:
            configuration, location, digest = deployment(directory)
            process = subprocess.run(launch_command(configuration, location, digest),
                                     input=b"".join(json.dumps(item, ensure_ascii=False).encode("utf-8") + b"\n" for item in frames),
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=PROJECT_ROOT, timeout=15)
        self.assertEqual(process.returncode, 0, process.stderr.decode("utf-8", errors="replace"))
        results = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual([item["id"] for item in results], [1, 3, 2, "中文-id"])
        self.assertEqual([tool["name"] for tool in results[1]["result"]["tools"]], [ACTION_TOOL_NAME])
        self.assertNotIn("annotations", results[1]["result"]["tools"][0])
        self.assertTrue(results[2]["result"]["isError"])
        self.assertEqual(payload(results[2])["errors"][0]["stage"], "case_action")
        self.assertFalse(process.stderr)

    def test_changed_lock_or_bound_configuration_refuses_before_handshake(self):
        for changed in ("source_lock", "bound_configuration"):
            with self.subTest(changed=changed), temporary_workspace() as directory:
                configuration, location, digest = deployment(directory)
                target = location if changed == "source_lock" else configuration
                target.write_bytes(target.read_bytes() + b" ")
                process = subprocess.run(launch_command(configuration, location, digest),
                                         input=json.dumps(initialize()).encode() + b"\n",
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         cwd=PROJECT_ROOT, timeout=15)
                self.assertEqual(process.returncode, 2)
                self.assertFalse(process.stdout)
                self.assertIn(b"startup refused", process.stderr)

    def test_strict_parsing_recovers_after_invalid_frames(self):
        runtime = FakeRuntime()
        bad = [b"\xff\n", b'{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}\n',
               b'{"x":NaN}\n', b'{"x":Infinity}\n', b'{"x":1e999}\n', b'{broken}\n']
        frames = [initialize(), INITIALIZED, call()]
        source = io.BytesIO(b"".join(bad) + b"".join(json.dumps(item).encode() + b"\n" for item in frames))
        output = io.BytesIO()
        serve(runtime=runtime, stdin=source, stdout=output)
        responses = [json.loads(line) for line in output.getvalue().splitlines()]
        self.assertTrue(all(item["error"]["code"] == -32700 for item in responses[:len(bad)]))
        self.assertEqual(runtime.calls, [arguments()])
        self.assertEqual(responses[-1]["id"], 2)

    def test_nested_duplicate_action_fields_never_dispatch(self):
        runtime = FakeRuntime()
        prefix = b"".join(json.dumps(item).encode() + b"\n" for item in [initialize(), INITIALIZED])
        duplicate = json.dumps(call()).replace('"action": "inspect_input"',
                                              '"action": "inspect_input", "action": "repair_copy"')
        output = io.BytesIO()
        serve(runtime=runtime, stdin=io.BytesIO(prefix + duplicate.encode() + b"\n"), stdout=output)
        self.assertEqual(json.loads(output.getvalue().splitlines()[-1])["error"]["code"], -32700)
        self.assertFalse(runtime.calls)

    def test_launcher_requires_config_and_both_source_pins_before_handshake(self):
        variants = [[], ["--config", "missing.json"], ["--source-lock", "missing.json"],
                    ["--expected-lock-sha256", "a" * 64],
                    ["--config", "missing.json", "--source-lock", "missing.json",
                     "--expected-lock-sha256", "INVALID"]]
        for extra in variants:
            with self.subTest(extra=extra):
                process = subprocess.run([sys.executable, "-X", "utf8", "-B",
                                          str(PROJECT_ROOT / "run_comparison_mcp_v6.py"), *extra],
                                         input=json.dumps(initialize()).encode() + b"\n",
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         cwd=PROJECT_ROOT, timeout=15)
                self.assertEqual(process.returncode, 2)
                self.assertFalse(process.stdout)
                self.assertTrue(process.stderr)

    def test_process_worker_print_cannot_corrupt_stdout_frames(self):
        code = """from defect_researcher.comparison_mcp_server_v6 import serve
class Runtime:
    def execute(self, value):
        print('worker diagnostic')
        return {'schema_version':1,'status':'executed', 'trial_handle':value['trial_handle'],'action':value['action']}
serve(runtime=Runtime())
"""
        frames = [initialize(), INITIALIZED, call()]
        process = subprocess.run([sys.executable, "-X", "utf8", "-B", "-c", code],
                                 input=b"".join(json.dumps(item).encode() + b"\n" for item in frames),
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 cwd=PROJECT_ROOT, timeout=15)
        self.assertEqual(process.returncode, 0)
        responses = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual(len(responses), 2)
        self.assertFalse(responses[-1]["result"]["isError"])
        self.assertIn(b"worker diagnostic", process.stderr)
        self.assertNotIn(b"worker diagnostic", process.stdout)

    def test_official_sdk_real_stdio_exact_catalogue_and_injection_rejection(self):
        modules = PROJECT_ROOT.parent / "agnes-harness/node_modules/.pnpm"
        candidates = sorted(modules.glob("@modelcontextprotocol+sdk@*/node_modules/@modelcontextprotocol/sdk/dist/esm"))
        node = shutil.which("node")
        if node is None and Path("E:/nodejs24.15.0/node.exe").is_file():
            node = "E:/nodejs24.15.0/node.exe"
        if not candidates or node is None:
            self.skipTest("Installed AGH MCP SDK and Node.js are required")
        script = r"""
import { pathToFileURL } from 'node:url';
const [sdk, python, launcher, config, lock, sha, cwd, handle] = process.argv.slice(1);
const { Client } = await import(pathToFileURL(sdk + '/client/index.js').href);
const { StdioClientTransport } = await import(pathToFileURL(sdk + '/client/stdio.js').href);
const transport = new StdioClientTransport({ command: python,
    args: ['-X','utf8','-B',launcher,'--config',config,'--source-lock',lock,'--expected-lock-sha256',sha],
    cwd, stderr: 'pipe' });
const diagnostics = [];
transport.stderr.on('data', chunk => diagnostics.push(chunk.toString('utf8')));
const client = new Client({ name: 'comparison-sdk-boundary-smoke', version: '1' }, { capabilities: {} });
try {
    await client.connect(transport);
    const { tools } = await client.listTools();
    let oldToolError, injectionError;
    try { await client.callTool({ name: 'audit_dataset', arguments: {} }); }
    catch (error) { oldToolError = error.code; }
    try { await client.callTool({ name: 'execute_case_action_v1',
        arguments: {trial_handle:handle,action:'inspect_input',arm:'F'} }); }
    catch (error) { injectionError = error.code; }
    const missing = await client.callTool({name:'execute_case_action_v1',
        arguments:{trial_handle:handle,action:'inspect_input'}},undefined,{timeout:10000});
    await client.ping();
    console.log(JSON.stringify({server:client.getServerVersion(),
        names:tools.map(tool=>tool.name),actions:tools[0].inputSchema.properties.action.enum,
        oldToolError,injectionError,missingIsError:missing.isError,
        missing:JSON.parse(missing.content[0].text),diagnostics:diagnostics.join('')}));
} finally { await client.close(); }
"""
        with temporary_workspace() as directory:
            configuration, location, digest = deployment(directory)
            process = subprocess.run([node, "--input-type=module", "-e", script,
                                      str(candidates[0].resolve()), sys.executable,
                                      str(PROJECT_ROOT / "run_comparison_mcp_v6.py"),
                                      str(configuration), str(location), digest,
                                      str(PROJECT_ROOT), HANDLE],
                                     stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                     cwd=PROJECT_ROOT, timeout=25)
        self.assertEqual(process.returncode, 0, process.stderr.decode("utf-8", errors="replace"))
        result = json.loads(process.stdout)
        self.assertEqual(result["server"], {"name": "defect-researcher-comparison-cases-v1", "version": "1.0.0"})
        self.assertEqual(result["names"], [ACTION_TOOL_NAME])
        self.assertEqual(result["actions"], list(ACTIONS))
        self.assertEqual(result["oldToolError"], -32602)
        self.assertEqual(result["injectionError"], -32602)
        self.assertTrue(result["missingIsError"])
        self.assertEqual(result["missing"]["errors"][0]["stage"], "case_action")
        self.assertEqual(result["missing"]["trial_handle"], HANDLE)
        self.assertFalse(result["diagnostics"])
        self.assertFalse(process.stderr)


if __name__ == "__main__":
    unittest.main()
