"""Real isolated COCO/label fixtures test independent verification and publication."""
import hashlib
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from defect_researcher import geometry_verifier as verifier
from test_config import temporary_workspace


def write_json(path, value):
    path.write_text(json.dumps(value, allow_nan=False), encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry_configuration(root):
    research, dataset, raw, splits = [root / name for name in ("research", "dataset", "raw", "splits")]
    for directory in (research, dataset, raw, splits):
        directory.mkdir()
    counts, source_hashes, split_hashes, label_hashes = {}, {}, {}, {}
    categories = [{"id": identifier, "name": name} for identifier, name in verifier.CATEGORIES.items()]
    for index, split in enumerate(verifier.SPLITS, 1):
        for kind in ("images", "labels", "metadata"):
            (dataset / kind / split).mkdir(parents=True)
        relative, image_id = f"cable_{index}/image_{index}.png", index * 10
        image = raw / relative
        image.parent.mkdir()
        image.write_bytes(b"fixture image membership only; no pixel decode")
        (dataset / "images" / split / image.name).write_bytes(image.read_bytes())
        annotations = []
        items = []
        if index == 1:
            annotations = [{"id": 101, "image_id": image_id, "category_id": 1,
                            "bbox": [20, 30, 40, 10], "attributes": {"rotation": 90, "gradation": 2, "anomaly_id": "A1"}}]
            # Hand-derived right-angle geometry, independent of every geometry implementation.
            items = [{"annotation_id": 101, "image_id": image_id, "category_id": 1, "class": "broken_strand",
                      "source_json": "cable_1.json", "original_bbox": [20, 30, 40, 10], "rotation": 90,
                      "hbb_xyxy": [35, 15, 45, 55], "rotated_corners": [[45, 15], [45, 55], [35, 55], [35, 15]],
                      "bbox_clipped": False, "geometry_version": "hbb_v1", "gradation": 2, "anomaly_id": "A1"}]
        label = dataset / "labels" / split / f"image_{index}.txt"
        label.write_text("0 0.40000000 0.35000000 0.10000000 0.40000000" if items else "", encoding="utf-8")
        write_json(dataset / "metadata" / split / f"image_{index}.json",
                   {"image": relative, "image_id": image_id, "source_json": f"cable_{index}.json",
                    "width": 100, "height": 100, "geometry_version": "hbb_v1", "annotations": items})
        source = raw / f"cable_{index}.json"
        write_json(source, {"categories": categories, "images": [{"id": image_id, "file_name": relative,
                                                                 "width": 100, "height": 100}], "annotations": annotations})
        source_hashes[source.name] = digest(source)
        split_path = splits / f"{split}.txt"
        split_path.write_text(str(image) + "\n", encoding="utf-8")
        split_hashes[split_path.name] = digest(split_path)
        label_hashes[split] = hashlib.sha256(label.relative_to(dataset).as_posix().encode("utf-8") + b"\0" + label.read_bytes() + b"\0").hexdigest()
        counts[split] = {"images": 1, "normal_images": int(not items), "abnormal_images": int(bool(items)),
                         "annotations": len(items), "source_annotations": len(items), "nonzero_rotation_attributes": len(items),
                         "rotated_annotations": len(items), "clipped_annotations": 0, "invalid_annotations": 0}
    (splits / "excluded_buffer.txt").write_text("", encoding="utf-8")
    split_hashes["excluded_buffer.txt"] = digest(splits / "excluded_buffer.txt")
    (dataset / "data.yaml").write_text("names:\n" + "".join(f"  {k - 1}: {v}\n" for k, v in verifier.CATEGORIES.items()), encoding="utf-8")
    write_json(dataset / "manifest.json", {"geometry_version": "hbb_v1", "categories": {str(k): v for k, v in verifier.CATEGORIES.items()},
                                          "source_sha256": source_hashes, "split_sha256": split_hashes,
                                          "label_tree_sha256": label_hashes, "counts": counts,
                                          "totals": {key: sum(c[key] for c in counts.values()) for key in counts["train"]},
                                          "raw_images": 3, "raw_annotations": 1, "excluded_buffer_images": 0})
    return {"research_root": str(research), "dataset_root": str(dataset), "raw_root": str(raw),
            "split_dir": str(splits), "weights_path": str(research / "unused.pt"), "output_root": str(root / "outputs")}


class GeometryVerifierTests(unittest.TestCase):
    def test_passed_report_has_complete_hash_verified_artifacts_and_preserves_inputs(self):
        with temporary_workspace() as root:
            configuration = geometry_configuration(root)
            before = {path: path.read_bytes() for path in root.rglob("*") if path.is_file()}
            with patch.object(verifier, "_write", wraps=verifier._write) as publish:
                report = verifier.verify_label_geometry(configuration, "right-angle")
            self.assertEqual(report["status"], "completed", report["errors"])
            self.assertEqual(report["summary"]["verification_status"], "passed", report["summary"])
            self.assertEqual(report["summary"]["totals"]["images"], 3)
            self.assertEqual(report["summary"]["totals"]["annotations"], 1)
            self.assertTrue(report["summary"]["inputs_unchanged"])
            self.assertEqual(report["summary"]["fixture_counts"]["total"], 30)
            self.assertEqual(report["summary"]["fixture_counts"]["failed"], 0)
            self.assertLess(len(json.dumps(report).encode("utf-8")), 10 * 1024)
            self.assertEqual(publish.call_args_list[-1].args[0].name, "completion.json")
            directory = Path(report["artifacts"]["completion"]).parent
            self.assertEqual({path.name for path in directory.iterdir()}, set(verifier.FILES.values()))
            completion = json.loads((directory / "completion.json").read_text(encoding="utf-8"))
            manifest = json.loads((directory / "artifact_manifest.json").read_text(encoding="utf-8"))
            self.assertEqual(completion["tool"], "verify_label_geometry")
            self.assertEqual(manifest["tool"], "verify_label_geometry")
            self.assertEqual(digest(directory / "artifact_manifest.json"), completion["artifact_manifest_sha256"])
            for record in manifest["files"]:
                path = Path(record["path"])
                self.assertEqual(path.stat().st_size, record["size_bytes"])
                self.assertEqual(digest(path), record["sha256"])
                self.assertEqual(digest(path), completion["artifacts_sha256"][path.name])
            details = [json.loads(line) for line in (directory / "geometry_details.jsonl").read_text(encoding="utf-8").splitlines()]
            self.assertEqual(len([r for r in details if r["record_type"] == "annotation"]), 1)
            self.assertEqual(len([r for r in details if r["record_type"] == "image"]), 3)
            inputs = json.loads((directory / "input_manifest.json").read_text(encoding="utf-8"))
            self.assertTrue(inputs["all_unchanged"])
            self.assertTrue({"oracle", "fixtures", "verifier", "labels/train/image_1.txt"} <= {r["role"] for r in inputs["files"]})
            for path, content in before.items():
                self.assertEqual(path.read_bytes(), content)
            completed = (directory / "completion.json").read_bytes()
            repeated = verifier.verify_label_geometry(configuration, "right-angle")
            self.assertEqual(repeated["status"], "failed")
            self.assertEqual((directory / "completion.json").read_bytes(), completed)
            self.assertFalse((directory / "failure.json").exists())

    def test_coordinate_change_and_ignored_rotation_are_completed_failed_with_annotation_id(self):
        for value in ("0 0.41 0.35 0.10 0.40", "0 0.40 0.35 0.40 0.10"):
            with self.subTest(value=value), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                label = Path(configuration["dataset_root"]) / "labels/train/image_1.txt"
                label.write_text(value, encoding="utf-8")
                report = verifier.verify_label_geometry(configuration)
                self.assertEqual(report["status"], "completed", report["errors"])
                self.assertEqual(report["summary"]["verification_status"], "failed")
                self.assertTrue(any(row.get("annotation_id") == 101 and row["code"] == "yolo_geometry"
                                    for row in report["summary"]["issue_samples"]))
                self.assertTrue(Path(report["artifacts"]["completion"]).exists())
                self.assertFalse((Path(report["artifacts"]["completion"]).parent / "failure.json").exists())

    def test_metadata_ignoring_rotation_identifies_each_geometry_difference(self):
        with temporary_workspace() as root:
            configuration = geometry_configuration(root)
            path = Path(configuration["dataset_root"]) / "metadata/train/image_1.json"
            metadata = json.loads(path.read_text(encoding="utf-8"))
            metadata["annotations"][0].update(rotation=0, hbb_xyxy=[20, 30, 60, 40],
                                              rotated_corners=[[20, 30], [60, 30], [60, 40], [20, 40]])
            write_json(path, metadata)
            report = verifier.verify_label_geometry(configuration)
            self.assertEqual(report["status"], "completed", report["errors"])
            self.assertEqual(report["summary"]["verification_status"], "failed")
            fields = {r["field"] for r in report["summary"]["issue_samples"] if r["code"] == "metadata_geometry"}
            self.assertEqual(fields, {"rotation", "hbb_xyxy", "rotated_corners"})

    def test_extra_rows_and_nonfinite_labels_never_pass_or_publish_nan(self):
        for value, code in (("0 nan 0.35 0.1 0.4", "label_nonfinite_or_range"),
                            ("0 0.4 0.35 0.1 0.4\n0 0.4 0.35 0.1 0.4", "annotation_count")):
            with self.subTest(value=value), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                (Path(configuration["dataset_root"]) / "labels/train/image_1.txt").write_text(value, encoding="utf-8")
                report = verifier.verify_label_geometry(configuration)
                self.assertEqual(report["status"], "completed", report["errors"])
                self.assertEqual(report["summary"]["verification_status"], "failed")
                self.assertIn(code, report["summary"]["issues_by_code"])
                directory = Path(report["artifacts"]["completion"]).parent
                for path in directory.iterdir():
                    for line in path.read_text(encoding="utf-8").splitlines() if path.suffix == ".jsonl" else [path.read_text(encoding="utf-8")]:
                        json.loads(line, parse_constant=lambda constant: self.fail(f"Non-finite JSON token {constant}"))

    def test_missing_source_or_metadata_is_execution_failure_without_completion(self):
        for key, relative in (("raw_root", "cable_2.json"), ("dataset_root", "metadata/train/image_1.json")):
            with self.subTest(relative=relative), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                (Path(configuration[key]) / relative).unlink()
                report = verifier.verify_label_geometry(configuration, "missing-input")
                self.assertEqual(report["status"], "failed")
                directory = Path(configuration["output_root"]) / "missing-input"
                self.assertTrue((directory / "failure.json").exists())
                self.assertFalse((directory / "completion.json").exists())

    def test_duplicate_annotation_and_escaping_split_paths_are_refused(self):
        for change in ("duplicate", "escape"):
            with self.subTest(change=change), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                if change == "duplicate":
                    path = Path(configuration["raw_root"]) / "cable_1.json"
                    source = json.loads(path.read_text(encoding="utf-8"))
                    source["annotations"].append(source["annotations"][0])
                    write_json(path, source)
                else:
                    (root / "outside.png").write_bytes(b"preserved")
                    (Path(configuration["split_dir"]) / "train.txt").write_text(str(root / "outside.png"), encoding="utf-8")
                report = verifier.verify_label_geometry(configuration)
                self.assertEqual(report["status"], "failed")
                self.assertIn("Duplicate" if change == "duplicate" else "escapes", report["errors"][0]["message"])

    def test_changes_during_execution_prevent_completion(self):
        from defect_researcher import independent_geometry
        with temporary_workspace() as root:
            configuration = geometry_configuration(root)
            original_suite = independent_geometry.run_fixture_suite

            def change_label():
                result = original_suite()
                (Path(configuration["dataset_root"]) / "labels/train/image_1.txt").write_text("0 0.41 0.35 0.1 0.4", encoding="utf-8")
                return result

            with patch.object(independent_geometry, "run_fixture_suite", side_effect=change_label):
                report = verifier.verify_label_geometry(configuration, "changed-input")
            self.assertEqual(report["status"], "failed")
            self.assertEqual(report["errors"][0]["stage"], "input_immutability")
            self.assertFalse((Path(configuration["output_root"]) / "changed-input/completion.json").exists())

    def test_declared_hashes_require_all_sources_and_splits_and_sha256_format(self):
        for group, key, replacement in (("source_sha256", "cable_2.json", None),
                                        ("split_sha256", "val.txt", None),
                                        ("source_sha256", None, {}), ("split_sha256", None, {}),
                                        ("split_sha256", "val.txt", "not-a-sha256")):
            with self.subTest(group=group, key=key), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                path = Path(configuration["dataset_root"]) / "manifest.json"
                manifest = json.loads(path.read_text(encoding="utf-8"))
                if key is None:
                    manifest[group] = replacement
                elif replacement is None:
                    del manifest[group][key]
                else:
                    manifest[group][key] = replacement
                write_json(path, manifest)
                report = verifier.verify_label_geometry(configuration)
                self.assertEqual(report["status"], "completed", report["errors"])
                self.assertEqual(report["summary"]["verification_status"], "failed")
                self.assertIn("declared_hash_format" if replacement == "not-a-sha256" else "declared_hash_membership",
                              report["summary"]["issues_by_code"])

    def test_invalid_source_rotation_or_category_reports_the_annotation_identity(self):
        for field, invalid in (("rotation", True), ("rotation", "invalid"), ("category_id", True), ("category_id", 1.0)):
            with self.subTest(field=field, invalid=invalid), temporary_workspace() as root:
                configuration = geometry_configuration(root)
                path = Path(configuration["raw_root"]) / "cable_1.json"
                source = json.loads(path.read_text(encoding="utf-8"))
                annotation = source["annotations"][0]
                if field == "rotation":
                    annotation["attributes"][field] = invalid
                else:
                    annotation[field] = invalid
                write_json(path, source)
                report = verifier.verify_label_geometry(configuration)
                self.assertEqual(report["status"], "failed")
                if field == "rotation":
                    message = report["errors"][0]["message"]
                    self.assertIn("source_json=cable_1.json", message)
                    self.assertIn("image=cable_1/image_1.png", message)
                    self.assertIn("annotation_id=101", message)
                self.assertFalse(Path(report["artifacts"]["failure"]).parent.joinpath("completion.json").exists())


if __name__ == "__main__":
    unittest.main()
