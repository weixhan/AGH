"""Hand-computed metric fixtures; no detector, library matcher or GPU is needed."""
import copy
import json
import math
import unittest

from defect_researcher.detection_metrics import compare_scores, score_detections


def gt(class_id=0, xyxy=(0, 0, 10, 10)):
    return {"class_id": class_id, "xyxy": list(xyxy)}


def pred(class_id=0, xyxy=(0, 0, 10, 10), confidence=.9):
    return {**gt(class_id, xyxy), "confidence": confidence}


def image(identifier="a", ground_truth=None, predictions=None):
    return {"image_id": identifier, "width": 100, "height": 100,
            "ground_truth": [] if ground_truth is None else ground_truth,
            "predictions": [] if predictions is None else predictions}


class DetectionMetricTests(unittest.TestCase):
    def test_perfect_detection_and_no_gt_class_excluded_from_macro_ap(self):
        score = score_detections([image(ground_truth=[gt()], predictions=[pred()])], ["defect", "absent"])
        self.assertEqual(score["mAP50"], 1)
        self.assertEqual(score["mAP50_95"], 1)
        self.assertEqual(score["ap_classes"], [0])
        self.assertIsNone(score["per_class"][1]["AP50"])
        self.assertEqual(score["operating_point"]["tp"], 1)
        self.assertEqual(score["operating_point"]["small_recall"], 1)
        self.assertIsNone(score["operating_point"]["normal_image_fp_rate"])

    def test_no_predictions_count_all_gt_as_missed(self):
        score = score_detections([image(ground_truth=[gt(), gt(1)])], ["a", "b"])
        self.assertEqual(score["mAP50"], 0)
        self.assertTrue(score["ap_defined"])
        self.assertEqual(score["operating_point"]["fn"], 2)
        self.assertEqual(score["operating_point"]["fp"], 0)
        self.assertFalse(score["operating_point"]["precision_defined"])
        self.assertEqual(score["per_image"][0]["small_fn"], 2)

    def test_no_gt_false_positive_and_empty_set_remain_json_safe(self):
        score = score_detections([image(predictions=[pred()]), image("b")], ["a"])
        self.assertFalse(score["ap_defined"])
        self.assertEqual(score["mAP50"], 0)
        self.assertEqual(score["operating_point"]["fp"], 1)
        self.assertEqual(score["operating_point"]["normal_image_fp_rate"], .5)
        empty = score_detections([], ["a"])
        self.assertEqual(empty["counts"], {"images": 0, "gt": 0, "predictions": 0})
        json.dumps([score, empty, compare_scores(empty, empty)], allow_nan=False)

    def test_duplicate_predictions_are_false_positive_but_late_fp_does_not_lower_ap(self):
        score = score_detections([image(ground_truth=[gt()], predictions=[pred(), pred(confidence=.8)])], ["a"])
        self.assertEqual(score["mAP50"], 1)
        self.assertEqual(score["operating_point"]["tp"], 1)
        self.assertEqual(score["operating_point"]["fp"], 1)
        self.assertEqual(score["operating_point"]["precision"], .5)

    def test_wrong_class_prediction_is_fp_and_gt_remains_fn(self):
        score = score_detections([image(ground_truth=[gt()], predictions=[pred(1)])], ["a", "b"])
        self.assertEqual(score["mAP50"], 0)
        self.assertEqual(score["operating_point"]["tp"], 0)
        self.assertEqual(score["operating_point"]["fp"], 1)
        self.assertEqual(score["operating_point"]["fn"], 1)

    def test_higher_confidence_false_positive_precedes_true_positive_for_ap(self):
        # At all recall levels the best subsequent precision is 1/2.
        bad = pred(xyxy=(40, 40, 50, 50), confidence=.95)
        good = pred(confidence=.4)
        score = score_detections([image(ground_truth=[gt()], predictions=[good, bad])], ["a"])
        self.assertEqual(score["mAP50"], .5)
        self.assertEqual(score["mAP50_95"], .5)

    def test_partial_recall_101_point_ap_includes_zero_and_half_recall(self):
        # One of two GT detected: recall samples 0.00..0.50 are 51/101.
        score = score_detections([image(ground_truth=[gt(), gt(xyxy=(30, 30, 40, 40))], predictions=[pred()])], ["a"])
        self.assertAlmostEqual(score["mAP50"], 51 / 101)
        self.assertEqual(score["operating_point"]["recall"], .5)

    def test_precision_envelope_with_true_false_true_ranking(self):
        # Recall 0..0.50 has interpolated P=1, recall .51..1 has P=2/3.
        truth = [gt(), gt(xyxy=(30, 30, 40, 40))]
        predictions = [pred(confidence=.9), pred(xyxy=(70, 70, 80, 80), confidence=.8),
                       pred(xyxy=(30, 30, 40, 40), confidence=.7)]
        score = score_detections([image(ground_truth=truth, predictions=predictions)], ["a"])
        self.assertAlmostEqual(score["mAP50"], (51 + 50 * 2 / 3) / 101)
        self.assertEqual(score["operating_point"]["precision"], 2 / 3)

    def test_iou_half_boundary_is_inclusive_and_next_float_below_misses(self):
        # GT area 200, contained prediction area 100 -> IoU exactly 0.5.
        truth = gt(xyxy=(0, 0, 20, 10))
        hit = pred(xyxy=(0, 0, 10, 10))
        exact = score_detections([image(ground_truth=[truth], predictions=[hit])], ["a"])
        self.assertEqual(exact["mAP50"], 1)
        self.assertAlmostEqual(exact["mAP50_95"], .1)
        below = pred(xyxy=(0, 0, math.nextafter(10, 0), 10))
        missed = score_detections([image(ground_truth=[truth], predictions=[below])], ["a"])
        self.assertEqual(missed["mAP50"], 0)
        self.assertEqual(missed["operating_point"]["fn"], 1)

    def test_confidence_boundary_inclusive_and_ap_uses_lower_confidence_predictions(self):
        truth = [gt(), gt(xyxy=(20, 20, 30, 30))]
        predictions = [pred(confidence=.25), pred(xyxy=(20, 20, 30, 30), confidence=.249)]
        score = score_detections([image(ground_truth=truth, predictions=predictions)], ["a"])
        self.assertEqual(score["counts"]["predictions"], 2)
        self.assertEqual(score["operating_point"]["predictions"], 1)
        self.assertEqual(score["operating_point"]["tp"], 1)
        self.assertEqual(score["operating_point"]["fn"], 1)
        self.assertEqual(score["mAP50"], 1)

    def test_confidence_greedy_differs_from_global_highest_iou_assignment(self):
        # High-score broad box overlaps both GT by 2/3, choosing the first.
        # Low-score exact-first box cannot steal that consumed GT. An IoU-first
        # matcher would match it first and obtain two TP, a different protocol.
        truth = [gt(xyxy=(0, 0, 10, 10)), gt(xyxy=(5, 0, 15, 10))]
        predictions = [pred(xyxy=(0, 0, 15, 10), confidence=.9), pred(confidence=.8)]
        score = score_detections([image(ground_truth=truth, predictions=predictions)], ["a"])
        self.assertEqual(score["operating_point"]["tp"], 1)
        self.assertEqual(score["operating_point"]["fp"], 1)
        self.assertEqual(score["operating_point"]["fn"], 1)

    def test_prediction_chooses_highest_available_iou_and_matches_are_image_local(self):
        # Broad GT is first but an exact narrower second GT has larger overlap.
        truth = [gt(xyxy=(0, 0, 15, 10)), gt(xyxy=(0, 0, 10, 10))]
        predictions = [pred(confidence=.9), pred(xyxy=(5, 0, 15, 10), confidence=.8)]
        records = [image("a", truth, predictions), image("b", [gt()], [pred(confidence=.95)])]
        score = score_detections(records, ["a"])
        self.assertEqual(score["operating_point"]["tp"], 3)
        self.assertEqual(score["operating_point"]["fn"], 0)
        self.assertEqual(score["operating_point"]["fp"], 0)

    def test_small_area_strict_boundary_original_coordinates(self):
        truth = [gt(xyxy=(0, 0, 32, 32)), gt(xyxy=(50, 50, 81, 82))]
        score = score_detections([image(ground_truth=truth, predictions=[pred(xyxy=(0, 0, 32, 32))])], ["a"])
        self.assertEqual(score["operating_point"]["small_gt"], 1)
        self.assertEqual(score["operating_point"]["small_fn"], 1)
        self.assertEqual(score["operating_point"]["small_recall"], 0)

    def test_ap_macro_classes_and_micro_operating_point_have_distinct_denominators(self):
        records = [image(ground_truth=[gt(0), gt(0, (30, 30, 40, 40)), gt(1)], predictions=[pred(0)])]
        score = score_detections(records, ["a", "b"])
        self.assertAlmostEqual(score["mAP50"], 51 / 202)
        self.assertAlmostEqual(score["operating_point"]["recall"], 1 / 3)

    def test_json_serializable_nonmutating_and_record_order_stable(self):
        records = [image("z", [gt()], [pred()]), image("a", [], [pred(confidence=.95)])]
        original = copy.deepcopy(records)
        score = score_detections(records, {"0": "a"})
        self.assertEqual(records, original)
        self.assertEqual(score, score_detections(list(reversed(records)), ["a"]))
        json.dumps(score, allow_nan=False)

    def test_invalid_inputs_are_rejected_before_scoring(self):
        valid = image(ground_truth=[gt()], predictions=[pred()])
        invalid = []
        for key, value in (("width", 0), ("height", float("nan")), ("image_id", "")):
            record = copy.deepcopy(valid)
            record[key] = value
            invalid.append([record])
        invalid.append([valid, valid])
        for field, value in (("confidence", float("inf")), ("confidence", 1.1), ("class_id", True),
                             ("class_id", 7), ("xyxy", [0, 0, 0, 10]), ("xyxy", [0, 0, float("nan"), 10])):
            record = copy.deepcopy(valid)
            record["predictions"][0][field] = value
            invalid.append([record])
        for records in invalid:
            with self.subTest(records=records), self.assertRaises(ValueError):
                score_detections(records, ["a"])
        for kwargs in ({"conf_threshold": -1}, {"match_iou": 0}, {"match_iou": float("nan")}):
            with self.assertRaises(ValueError):
                score_detections([valid], ["a"], **kwargs)


class ComparisonMetricTests(unittest.TestCase):
    def scores(self):
        left = [image("a", [gt()], []), image("b", [gt()], [pred()]), image("normal", [], [])]
        right = [image("a", [gt()], [pred()]), image("b", [gt()], [pred()]), image("normal", [], [pred()])]
        return score_detections(left, ["a"]), score_detections(right, ["a"])

    def test_paired_recall_bootstrap_excludes_normal_images_and_is_reproducible(self):
        left, right = self.scores()
        report = compare_scores(left, right)
        self.assertEqual(report["paired_recall"]["eligible_images"], 2)
        self.assertEqual(report["paired_recall"]["mean_delta"], .5)
        self.assertEqual(report["paired_recall"]["ci95"], [0, 1])
        self.assertEqual(report["delta_960_minus_640"]["recall"], .5)
        self.assertEqual(report["delta_960_minus_640"]["normal_image_fp_rate"], 1)
        self.assertEqual(compare_scores(left, right), report)
        self.assertEqual(report["scope"], "validation_only_same_weight")
        self.assertTrue(any("correlated" in note for note in report["limitations"]))
        json.dumps(report, allow_nan=False)

    def test_identical_scores_zero_difference_and_no_gt_is_undefined(self):
        left, _ = self.scores()
        report = compare_scores(left, left)
        self.assertEqual(report["paired_recall"]["ci95"], [0, 0])
        empty = score_detections([image()], ["a"])
        report = compare_scores(empty, empty)
        self.assertIsNone(report["paired_recall"]["mean_delta"])
        self.assertIsNone(report["paired_recall"]["ci95"])
        self.assertEqual(report["paired_recall"]["eligible_images"], 0)

    def test_changed_geometry_with_same_counts_rejected(self):
        left, right = self.scores()
        altered = score_detections([image("a", [gt(xyxy=(1, 1, 11, 11))]),
                                   image("b", [gt()], [pred()]), image("normal")], ["a"])
        with self.assertRaises(ValueError):
            compare_scores(left, altered)
        for field in ("confidence_threshold", "iou_threshold"):
            altered = copy.deepcopy(right)
            altered["operating_point"][field] += .01
            with self.subTest(field=field), self.assertRaises(ValueError):
                compare_scores(left, altered)
        altered = copy.deepcopy(right)
        altered["per_class"][0]["class_name"] = "changed"
        with self.assertRaises(ValueError):
            compare_scores(left, altered)


if __name__ == "__main__":
    unittest.main()
