"""Artifact recovery is a saved result readable through the existing status tool."""
import hashlib
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import Mock, patch

from defect_researcher import task_runtime as runtime
from defect_researcher.mcp_server import AuditMCPServer
from test_config import temporary_workspace


class SlicedArtifactRuntimeTests(unittest.TestCase):
    def test_artifact_kind_cannot_launch_a_worker(self):
        with patch.object(runtime, "_configured_paths") as paths, patch.object(runtime.threading, "Thread") as thread:
            report = runtime._start_task({}, runtime.SLICED_ARTIFACT_RECOVERY_TOOL)
        self.assertEqual(report["status"], "failed")
        self.assertIn("read-only", report["errors"][0]["message"])
        paths.assert_not_called()
        thread.assert_not_called()

    def test_existing_status_dispatches_only_lightweight_reader(self):
        with temporary_workspace() as temporary:
            task_id = "a" * 32
            directory = Path(temporary) / task_id
            directory.mkdir()
            report = {"task_id": task_id, "tool": runtime.SLICED_ARTIFACT_RECOVERY_TOOL,
                      "status": "completed", "summary": {"artifact_recovery_status": "passed"}}
            records = []
            for name in runtime._TASK_ARTIFACTS[runtime.SLICED_ARTIFACT_RECOVERY_TOOL]["required"]:
                path = directory / name
                path.write_text(json.dumps(report) if name == "recovery_result.json" else "{}\n", encoding="utf-8")
                records.append({"name": name, "path": str(path), "size_bytes": path.stat().st_size,
                                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
            manifest = directory / "artifact_manifest.json"
            manifest.write_text(json.dumps({"task_id": task_id, "tool": report["tool"],
                                            "status": "completed", "files": records}), encoding="utf-8")
            (directory / "completion.json").write_text(json.dumps({
                "task_id": task_id, "tool": report["tool"], "status": "completed",
                "artifact_manifest": str(manifest), "artifact_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
                "artifacts_sha256": {row["name"]: row["sha256"] for row in records}}), encoding="utf-8")
            reader = types.ModuleType("defect_researcher.sliced_artifact_recovery")
            reader.verify_sliced_artifact_recovery = Mock()
            with patch.dict(sys.modules, {reader.__name__: reader}), patch.object(runtime, "_configured_paths", return_value={"output_root": Path(temporary)}):
                actual = runtime.get_task_status({}, task_id)
            self.assertEqual(actual["status"], "completed")
            reader.verify_sliced_artifact_recovery.assert_called_once()
            self.assertEqual(reader.verify_sliced_artifact_recovery.call_args.args[0], directory)
            (directory / "independent_verification.json").write_text("tampered", encoding="utf-8")
            with patch.dict(sys.modules, {reader.__name__: reader}), patch.object(runtime, "_configured_paths", return_value={"output_root": Path(temporary)}):
                rejected = runtime.get_task_status({}, task_id)
            self.assertEqual(rejected["status"], "failed")
            self.assertIn("hash/size", rejected["errors"][0]["message"])
            self.assertEqual(reader.verify_sliced_artifact_recovery.call_count, 1)

    def test_no_new_public_start_tool_is_exposed(self):
        server = AuditMCPServer({})
        server.handle_message({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
            "protocolVersion": "2025-03-26", "capabilities": {}, "clientInfo": {"name": "fixture", "version": "1"}}})
        server.handle_message({"jsonrpc": "2.0", "method": "notifications/initialized"})
        response = server.handle_message({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
        names = {row["name"] for row in response["result"]["tools"]}
        self.assertEqual(len(names), 7)
        self.assertIn("get_task_status", names)
        self.assertNotIn(runtime.SLICED_ARTIFACT_RECOVERY_TOOL, names)
        response = server.handle_message({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {
            "name": runtime.SLICED_ARTIFACT_RECOVERY_TOOL, "arguments": {}}})
        self.assertEqual(response["error"]["code"], -32602)


if __name__ == "__main__":
    unittest.main()
