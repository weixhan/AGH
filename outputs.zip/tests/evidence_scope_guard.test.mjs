import test from 'node:test';
import assert from 'node:assert/strict';
import { createEvidenceScopeGuard, createDiagnosticScopeGuard } from '../tools/evidence_scope_guard.mjs';

const policy = { schema_version: 1, workspace_root: 'E:/project/scoped',
  task_id: '8d1d6900c7d74c90a29824495684807d',
  qualified_status_tool: 'mcp_defect_researcher_45e5cef9_get_task_status', max_status_calls: 1 };
const context = { session: { key: 'fresh-session', workspaceRoot: 'E:\\project\\scoped' }, replayed: false };
const status = (toolUseId = 'first') => ({ name: policy.qualified_status_tool,
  args: { task_id: policy.task_id }, toolUseId });

test('permits one exact completed-task read and rejects duplicate identity and further reads', () => {
  const guard = createEvidenceScopeGuard(policy);
  assert.equal(guard(status(), context).allow, true);
  assert.match(guard(status(), context).reason, /duplicate/);
  assert.match(guard(status('second'), context).reason, /once/);
});
test('denies native tools, alternate MCP tools, and another task before consuming the allowed read', () => {
  const guard = createEvidenceScopeGuard(policy);
  for (const name of ['shell', 'read', 'run_code', 'mcp_defect_researcher_45e5cef9_compare_validation_resolutions'])
    assert.equal(guard({ ...status(), name }, context).allow, false);
  assert.equal(guard({ ...status(), args: { task_id: 'f'.repeat(32) } }, context).allow, false);
  assert.equal(guard(status(), context).allow, true);
});
test('rejects missing workspace, replay, malformed input, extra fields, and empty call identity', () => {
  const guard = createEvidenceScopeGuard(policy);
  for (const args of [null, [], { task_id: policy.task_id, path: '/other' }, {}])
    assert.equal(guard({ ...status(), args }, context).allow, false);
  assert.equal(guard(status(), { ...context, replayed: true }).allow, false);
  assert.equal(guard(status(), { session: { key: 'x', workspaceRoot: 'E:/other' } }).allow, false);
  assert.equal(guard(status(''), context).allow, false);
  assert.equal(guard(status(), {}).allow, false);
});
test('pins a private policy copy and separates the one-call budgets of different sessions', () => {
  const mutable = structuredClone(policy);
  const guard = createEvidenceScopeGuard(mutable);
  mutable.task_id = 'f'.repeat(32);
  assert.equal(guard(status(), context).allow, true);
  assert.equal(guard(status(), { ...context, session: { ...context.session, key: 'another-session' } }).allow, true);
});
test('rejects broader policies rather than silently weakening the completed-evidence protocol', () => {
  for (const patch of [{ max_status_calls: 2 }, { qualified_status_tool: 'shell' },
    { schema_version: 2 }, { extra: true }, { task_id: '*' }])
    assert.throws(() => createEvidenceScopeGuard({ ...policy, ...patch }), /Invalid/);
});

const diagnosticPolicy = { schema_version: 1, workspace_root: policy.workspace_root,
  qualified_start_tool: 'mcp_defect_researcher_45e5cef9_diagnose_validation_errors',
  qualified_status_tool: policy.qualified_status_tool, max_status_calls: 20 };
const start = { name: diagnosticPolicy.qualified_start_tool, args: {}, toolUseId: 'start' };
const result = taskId => ({ toolUseId: 'start', result: {
  content: [{ type: 'text', text: JSON.stringify({ task_id: taskId, status: 'running' }) }] } });
test('diagnosis binds only an accepted start result, rejects premature or wrong-task polls and duplicate starts', () => {
  const guard = createDiagnosticScopeGuard(diagnosticPolicy);
  guard.tool_result(result(policy.task_id), context);
  assert.equal(guard.tool_call(status(), context).allow, false);
  assert.equal(guard.tool_call(start, context).allow, true);
  assert.equal(guard.tool_call({ ...start, toolUseId: 'second-start' }, context).allow, false);
  assert.equal(guard.tool_call(status(), context).allow, false);
  guard.tool_result({ ...result(policy.task_id), toolUseId: 'unrelated' }, context);
  assert.equal(guard.tool_call(status(), context).allow, false);
  guard.tool_result(result(policy.task_id), context);
  assert.equal(guard.tool_call(status(), context).allow, true);
  assert.equal(guard.tool_call({ ...status('wrong'), args: { task_id: 'f'.repeat(32) } }, context).allow, false);
  assert.equal(guard.tool_call({ ...status('shell'), name: 'shell' }, context).allow, false);
});
test('diagnosis fails closed on malformed/failed start results and enforces polling budget', () => {
  const guard = createDiagnosticScopeGuard(diagnosticPolicy);
  assert.equal(guard.tool_call(start, context).allow, true);
  guard.tool_result({ toolUseId: 'start', result: { isError: true, content: [] } }, context);
  guard.tool_result({ toolUseId: 'start', result: { content: [{ type: 'text', text: 'invalid' }] } }, context);
  assert.equal(guard.tool_call(status(), context).allow, false);
  guard.tool_result(result(policy.task_id), context);
  for (let index = 0; index < 20; index++) assert.equal(guard.tool_call(status(`read-${index}`), context).allow, true);
  assert.equal(guard.tool_call(status('over-budget'), context).allow, false);
});
