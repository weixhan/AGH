"""Reject impossible model-ledger order and ambiguous tool result pairing."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from test_config import temporary_workspace
from tools.verify_geometry_model_run import check_run, summary_matches_disk, ROOT
from tools.verify_resolution_model_run import repair_ci_export_mask


class ResolutionExportEvidenceTests(unittest.TestCase):
    def test_single_known_ci_decimal_needs_separately_observed_sdk_reference(self):
        text = '{"ci95": [-0.075, 0.[REDACTED:id]]}'
        reference = {"comparison": {"paired_recall": {"ci95": [-0.075, 0.004219409282700422]}}}
        repaired = repair_ci_export_mask(text, reference)
        self.assertEqual(json.loads(repaired)["ci95"], reference["comparison"]["paired_recall"]["ci95"])
        with self.assertRaises(ValueError):
            repair_ci_export_mask(text, None)

    def test_unrelated_or_multiple_masked_science_fields_are_not_filled(self):
        reference = {"comparison": {"paired_recall": {"ci95": [-0.075, 0.004219409282700422]}}}
        for text in ('{"mAP50": 0.[REDACTED:id]}',
                     '{"ci95": [-0.075, 0.[REDACTED:id]], "recall": 0.[REDACTED:id]}'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                repair_ci_export_mask(text, reference)

    def test_unmasked_science_is_never_rewritten_to_reference(self):
        text = '{"ci95": [-0.075, 0.123]}'
        reference = {"comparison": {"paired_recall": {"ci95": [-0.075, 0.004219409282700422]}}}
        self.assertEqual(repair_ci_export_mask(text, reference), text)


def ledger():
    tool = "mcp_defect_researcher_45e5cef9_"
    summary = {"verification_status": "passed", "fixture_status": "passed"}
    def result(use, payload, source):
        return {"type": "tool/result", "sourceEventSeqs": [source],
                "data": {"toolUseId": use, "isError": False,
                         "content": [{"type": "text", "text": json.dumps(payload)}]}}
    rows = [
        {"type": "session/start", "data": {"key": "test-session"}},
        {"type": "request/sent", "data": {"effectId": "e"}},
        {"type": "tool/call", "origin": "model", "data": {"toolUseId": "start", "name": tool + "verify_label_geometry", "args": {}}},
        {"type": "approval/decided", "data": {"verdict": "allowed-once", "scope": "tool:" + tool + "verify_label_geometry:execute"}},
        result("start", {"status": "running", "task_id": "geometry-1"}, 3),
        {"type": "tool/call", "origin": "model", "data": {"toolUseId": "poll", "name": tool + "get_task_status", "args": {"task_id": "geometry-1"}}},
        result("poll", {"status": "completed", "tool": "verify_label_geometry", "task_id": "geometry-1", "summary": summary}, 6),
        {"type": "cost/ledger", "data": {"purpose": "inference", "model": "agnes-3.0-flash", "response": {"status": 200}}},
        {"type": "turn/end", "data": {"reason": "completed"}},
    ]
    for index, row in enumerate(rows, 1):
        row["seq"] = index
    return rows, {"status": "completed", "tool": "verify_label_geometry", "task_id": "geometry-1", "summary": summary}


class ModelLedgerEvidenceTests(unittest.TestCase):
    def test_official_copy_path_redaction_preserves_exact_task_suffix(self):
        saved = {"repair_status": "passed", "changed_files": 0,
                 "copy_root": str(ROOT / "outputs" / "repair-1" / "dataset_copy")}
        redacted = {**saved, "copy_root": "<workspace>" + saved["copy_root"][len(str(ROOT)):]}
        self.assertTrue(summary_matches_disk(redacted, saved, True))
        self.assertFalse(summary_matches_disk({**redacted, "copy_root": redacted["copy_root"].replace("repair-1", "repair-2")}, saved, True))

    def test_redaction_alignment_never_changes_numeric_or_status_findings(self):
        saved = {"repair_status": "passed", "changed_files": 0,
                 "copy_root": str(ROOT / "outputs" / "repair-1" / "dataset_copy")}
        redacted = {**saved, "copy_root": "<workspace>" + saved["copy_root"][len(str(ROOT)):]}
        self.assertFalse(summary_matches_disk({**redacted, "changed_files": 1}, saved, True))
        self.assertFalse(summary_matches_disk({**redacted, "repair_status": "refused"}, saved, True))
        self.assertFalse(summary_matches_disk(redacted, saved, False))

    def verify(self, rows):
        _, disk = ledger()
        with temporary_workspace() as root:
            root = Path(root)
            task = root / "relocated" / "geometry-1"
            task.mkdir(parents=True)
            (task / "verification_result.json").write_text(json.dumps(disk), encoding="utf-8")
            directory = root / "exports"
            directory.mkdir()
            (directory / "session.jsonl").write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
            (directory / "session.html").write_text("synthetic test export", encoding="utf-8")
            with patch("tools.verify_geometry_model_run.load_config", return_value={"output_root": str(task.parent)}), \
                 patch("tools.verify_geometry_model_run.get_task_status", return_value=disk):
                return check_run(directory, "test-session")

    def test_valid_order_uses_configured_relocated_output(self):
        rows, _ = ledger()
        report = self.verify(rows)
        self.assertEqual(report["status"], "passed", report["reasons"])
        self.assertTrue(report["checks"]["task_artifact_scan_inside_configured_output"])

    def test_result_before_call_cannot_pass(self):
        rows, _ = ledger()
        rows[5], rows[6] = rows[6], rows[5]
        rows[5]["seq"], rows[6]["seq"] = 6, 7
        rows[5]["sourceEventSeqs"] = [7]
        report = self.verify(rows)
        self.assertEqual(report["status"], "failed")
        self.assertFalse(report["checks"]["mcp_results_paired"])

    def test_duplicate_result_id_cannot_pass(self):
        rows, _ = ledger()
        duplicate = copy.deepcopy(rows[6])
        duplicate["seq"] = 10
        rows.append(duplicate)
        report = self.verify(rows)
        self.assertEqual(report["status"], "failed")
        self.assertFalse(report["checks"]["unique_call_and_result_ids"])

    def test_wrong_task_id_result_cannot_pass(self):
        rows, _ = ledger()
        payload = json.loads(rows[6]["data"]["content"][0]["text"])
        payload["task_id"] = "other"
        rows[6]["data"]["content"][0]["text"] = json.dumps(payload)
        report = self.verify(rows)
        self.assertEqual(report["status"], "failed")
        self.assertFalse(report["checks"]["all_tool_results_match_task"])

    def test_repair_contract_requires_both_repair_and_independent_verification(self):
        rows, disk = ledger()
        for row in rows:
            row["data"] = json.loads(json.dumps(row["data"]).replace("verify_label_geometry", "repair_label_copy"))
        disk["tool"] = "repair_label_copy"
        disk["summary"] = {"repair_status": "passed", "verification_status": "passed"}
        payload = json.loads(rows[6]["data"]["content"][0]["text"])
        payload["summary"] = disk["summary"]
        rows[6]["data"]["content"][0]["text"] = json.dumps(payload)
        with temporary_workspace() as root:
            root = Path(root)
            task = root / "outputs" / "geometry-1"
            task.mkdir(parents=True)
            directory = root / "exports"
            directory.mkdir()
            (directory / "session.jsonl").write_text("\n".join(json.dumps(row) for row in rows), encoding="utf-8")
            (directory / "session.html").write_text("synthetic test export", encoding="utf-8")
            config = {"output_root": str(task.parent)}
            with patch("tools.verify_geometry_model_run.get_task_status", return_value=disk):
                good = check_run(directory, "test-session", "repair_label_copy", config)
                self.assertEqual(good["status"], "passed", good["reasons"])
                disk["summary"]["verification_status"] = "failed"
                bad = check_run(directory, "test-session", "repair_label_copy", config)
                self.assertFalse(bad["checks"]["repair_and_independent_verification_passed"])

    def test_unknown_tool_contract_is_rejected(self):
        with self.assertRaises(ValueError):
            check_run(Path("unused"), "unused", "unregistered")
