"""Owned-process, deadline, evidence and deployment boundaries of the sidecar."""
import json
import os
from pathlib import Path
import time
import unittest
from unittest.mock import patch

from defect_researcher.config import load_config
from defect_researcher import research_mcp_runtime_v1 as runtime
from defect_researcher import research_workflow_v1 as workflow
from test_config import temporary_workspace


class IdleProcess:
    """A live caller process stands in for a worker which has not executed."""
    pid = os.getpid()

    def poll(self):
        return None


class ResearchMCPRuntimeTests(unittest.TestCase):
    def arguments(self, case="normal_unrotated", identity="owned", calls=6, wall=120):
        return {"request_id": identity, "case_id": case,
                "budget": {"domain_invocations": calls, "wall_seconds": wall,
                           "gpu_seconds": 0, "model_requests": 0}}

    def configuration(self, directory):
        return {**load_config(), "output_root": str(directory / "outputs")}

    def owner(self, directory):
        return runtime.Runtime(self.configuration(directory))

    def wait_terminal(self, owner, identity):
        deadline = time.monotonic() + 30
        result = None
        while time.monotonic() < deadline:
            result = owner.get_status({"workflow_id": identity})
            if result["status"] != "running":
                # Keep temporary-directory cleanup separate from a process
                # which is still closing its log and exit records.
                process = owner._processes.get(identity)
                if process is not None:
                    process.wait(timeout=10)
                return result
            time.sleep(0.05)
        self.fail("The CPU-only worker failed to finish within 30 seconds: " + str(result))

    def start_idle(self, owner, arguments=None):
        with patch.object(runtime.subprocess, "Popen", return_value=IdleProcess()):
            return owner.start(arguments or self.arguments())

    def test_real_clean_worker_restart_and_source_bound_claims(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            initial = owner.start(self.arguments(calls=2))
            self.assertIn(initial["status"], ("running", "completed"))
            result = self.wait_terminal(owner, initial["workflow_id"])
            self.assertEqual(result["status"], "completed", result)
            self.assertEqual(result["research_status"], "stopped")
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry", "read_scientific_evidence"])
            self.assertEqual(result["domain_invocations"], 2)
            self.assertEqual(result["scientific_summary"]["relative_small"]["definition_id"], "area_ratio_lt_0_005")
            self.assertEqual(result["scientific_summary"]["tiny_small"]["definition_id"], "area_lt_1024_px2")
            self.assertEqual(result["scientific_summary"]["slicing"]["candidate_status"], "stop")
            self.assertEqual(result["next_action"], "stop_no_registered_candidate")
            self.assertEqual(result["new_inference_calls"], 0)
            self.assertEqual(result["new_model_requests"], 0)
            self.assertEqual(result["verification"]["checks_total"], result["verification"]["checks_passed"])
            self.assertGreater(result["verification"]["checks_total"], 0)
            task = Path(result["evidence"]["directory"])
            evidence = {row["evidence_id"]: row for row in runtime._read(task / "evidence.json")["entries"]}
            source_hashes = {row["source_id"]: row["sha256"] for row in result["sources"]}
            for claim in result["claims"]:
                entry = evidence[claim["evidence_id"]]
                value = entry
                for key in claim["field"].split("."):
                    value = value[key]
                self.assertEqual(claim["value"], value)
                self.assertEqual({source_hashes[identity] for identity in claim["source_ids"]},
                                 {row["sha256"] for row in entry["files"]})
            registry = owner.registry_root / result["workflow_id"]
            original = runtime._registration(registry / "registration.json")
            worker_request = runtime._read(registry / "worker_request.json")
            self.assertLess(worker_request["budget"]["wall_seconds"], original["request"]["budget"]["wall_seconds"])
            self.assertLessEqual(runtime._read(task / "completion.json")["completed_epoch"], original["deadline_epoch"])
            restarted = self.owner(directory).get_status({"workflow_id": result["workflow_id"]})
            self.assertEqual(restarted, result)
            # The terminal payload contains aggregate findings, identifiers and
            # hashes, rather than a prediction file or credential field.
            self.assertNotIn("predictions", result)
            self.assertNotIn("api_key", result)

    def test_real_repair_worker_keeps_original_input_and_charges_internal_checks(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            result = self.wait_terminal(owner, owner.start(self.arguments("repair_coordinates"))["workflow_id"])
            self.assertEqual(result["status"], "completed", result)
            self.assertEqual(result["domain_invocations"], 6)
            self.assertEqual(result["actual_tool_path"], ["verify_label_geometry", "repair_label_copy", "verify_copy", "read_scientific_evidence"])
            task = Path(result["evidence"]["directory"])
            self.assertTrue(runtime._read(task / "input_snapshots.json")["unchanged"])
            self.assertEqual(result["budget_summary"]["gpu_seconds"], 0)
            entries = runtime._read(task / "evidence.json")["entries"]
            repair = next(row for row in entries if row["kind"] == "repair")
            self.assertEqual(repair["domain"]["cost"]["domain_tool_calls"], 3)
            self.assertEqual(repair["domain"]["cost"]["geometry_verification_calls"], 2)

    def test_real_source_refusal_and_zero_budget_are_completed_stops(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            for identity, case, cap, status, path in (
                    ("refused", "refuse_source_hash", 6, "refused", ["verify_label_geometry"]),
                    ("no-budget", "normal_unrotated", 0, "insufficient_evidence", [])):
                with self.subTest(identity=identity):
                    result = self.wait_terminal(owner, owner.start(self.arguments(case, identity, cap))["workflow_id"])
                    self.assertEqual(result["status"], "completed", result)
                    self.assertEqual(result["research_status"], status)
                    self.assertEqual(result["actual_tool_path"], path)
                    self.assertIsNone(result["scientific_summary"])
                    self.assertEqual(result["domain_invocations"], len(path))

    def test_strict_model_arguments_refuse_paths_booleans_and_unknown_fields(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            examples = [None, [], {**self.arguments(), "output_root": str(directory)},
                        {**self.arguments(), "request_id": "../escape"},
                        {**self.arguments(), "case_id": "../normal_unrotated"},
                        {**self.arguments(), "budget": {**self.arguments()["budget"], "domain_invocations": True}},
                        {**self.arguments(), "budget": {**self.arguments()["budget"], "domain_invocations": 6.0}},
                        {**self.arguments(), "budget": {**self.arguments()["budget"], "wall_seconds": float("nan")}}]
            for arguments in examples:
                with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                    owner.start(arguments)
            for arguments in ({"workflow_id": "../escape"}, {"workflow_id": "research-workflow-v1-owned", "path": "x"}, []):
                with self.assertRaises(ValueError):
                    owner.get_status(arguments)
            self.assertFalse(owner.registry_root.exists())

    def test_server_config_refuses_input_changes_outside_workspace_and_overlap(self):
        with temporary_workspace() as directory:
            configuration = self.configuration(directory)
            for key, value in (("research_root", str(directory / "research")),
                               ("output_root", str(directory.parent.parent.parent.parent)),
                               ("output_root", configuration["dataset_root"]),
                               ("output_root", str(runtime.PROJECT_ROOT.parent))):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    runtime.Runtime({**configuration, key: value})
            with self.assertRaises(ValueError):
                runtime.Runtime({**configuration, "script": "x"})

    def test_duplicate_and_unknown_ids_cannot_import_or_reset_a_workflow(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            initial = self.start_idle(owner)
            registration = owner.registry_root / initial["workflow_id"] / "registration.json"
            before = registration.read_bytes()
            with self.assertRaises(FileExistsError):
                self.start_idle(owner)
            self.assertEqual(registration.read_bytes(), before)
            unknown = "research-workflow-v1-imported"
            task = Path(owner.configuration["output_root"]) / unknown
            task.mkdir(parents=True)
            (task / "completion.json").write_text('{"status":"completed"}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "not registered"):
                owner.get_status({"workflow_id": unknown})
            with self.assertRaises(FileExistsError):
                owner.start(self.arguments(identity="imported"))

    def test_frozen_source_drift_refuses_launch_or_fails_registered_run(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            with patch.object(runtime, "_verify_frozen_sources", side_effect=ValueError("source drift")), \
                    patch.object(runtime.subprocess, "Popen") as launch:
                with self.assertRaisesRegex(ValueError, "source drift"):
                    owner.start(self.arguments())
                launch.assert_not_called()
            self.assertFalse(owner.registry_root.exists())
            initial = self.start_idle(owner)
            with patch.object(runtime, "_verify_frozen_sources", side_effect=ValueError("source drift")):
                result = owner.get_status({"workflow_id": initial["workflow_id"]})
            self.assertEqual(result["status"], "failed")
            self.assertFalse(result["resumable"])
            self.assertEqual(owner.get_status({"workflow_id": initial["workflow_id"]})["status"], "failed")

    def test_unknown_worker_cost_and_exit_have_no_completion_or_auto_resume(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            initial = self.start_idle(owner)
            entry = owner.registry_root / initial["workflow_id"]
            with patch.object(workflow, "run_workflow", side_effect=RuntimeError("unknown business cost")):
                self.assertEqual(runtime.worker(entry / "registration.json"), 1)
            result = owner.get_status({"workflow_id": initial["workflow_id"]})
            self.assertEqual(result["status"], "failed")
            self.assertTrue(result["unknown_business_cost"])
            self.assertFalse(result["resumable"])
            self.assertFalse((Path(owner.configuration["output_root"]) / initial["workflow_id"] / "completion.json").exists())
            with self.assertRaises(FileExistsError):
                owner.start(self.arguments())

    def test_expired_original_deadline_never_launches_or_resets(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            with patch.object(runtime.subprocess, "Popen") as launch:
                initial = owner.start(self.arguments(wall=0.000001))
                launch.assert_not_called()
            self.assertEqual(initial["status"], "failed")
            entry = owner.registry_root / initial["workflow_id"]
            registration = runtime._registration(entry / "registration.json")
            self.assertEqual(registration["deadline_epoch"], registration["started_epoch"] + 0.000001)
            with self.assertRaises(FileExistsError):
                owner.start(self.arguments())

    def test_late_completion_is_preserved_under_rejected_marker(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            initial = self.start_idle(owner)
            task = Path(owner.configuration["output_root"]) / initial["workflow_id"]
            task.mkdir(parents=True)
            marker = task / "completion.json"
            value = {"completed_epoch": initial["original_deadline_epoch"] + 1, "status": "completed"}
            runtime._write_exclusive(marker, value)
            before = marker.read_bytes()
            result = owner.get_status({"workflow_id": initial["workflow_id"]})
            self.assertEqual(result["status"], "failed")
            self.assertEqual(result["error_code"], "late_controller_completion_rejected")
            self.assertFalse(marker.exists())
            self.assertEqual((task / "completion_rejected.json").read_bytes(), before)
            self.assertFalse(owner.get_status({"workflow_id": initial["workflow_id"]})["resumable"])

    def test_deployment_lock_requires_paired_pin_current_source_and_old_freeze(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            lock = directory / "source_lock.json"
            records = [{"role": role, "path": str(path.resolve()), "sha256": runtime._sha(path), "size_bytes": path.stat().st_size}
                       for role, path in (("runtime", Path(runtime.__file__)),
                                          ("sidecar", runtime.PROJECT_ROOT / "defect_researcher/research_mcp_server_v1.py"),
                                          ("launcher", runtime.PROJECT_ROOT / "run_research_mcp_v1.py"),
                                          ("sealed_workflow", runtime.FREEZE))]
            value = {"schema_version": 1, "kind": "research_mcp_implementation_v1", "status": "passed", "files": records}
            runtime._write_exclusive(lock, value)
            pin = {runtime.LOCK_PATH_ENV: str(lock), runtime.LOCK_SHA_ENV: runtime._sha(lock)}
            with patch.dict(os.environ, pin):
                pinned = self.owner(directory)
                self.assertEqual(pinned.source_lock["sha256"], pin[runtime.LOCK_SHA_ENV])
                lock.write_text(json.dumps({**value, "status": "failed"}), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "source lock changed"):
                    pinned.start(self.arguments())
            with patch.dict(os.environ, {runtime.LOCK_PATH_ENV: str(lock)}):
                with self.assertRaisesRegex(ValueError, "both"):
                    self.owner(directory)
            lock.write_text(json.dumps({**value, "files": records[:1]}), encoding="utf-8")
            with patch.dict(os.environ, {runtime.LOCK_PATH_ENV: str(lock), runtime.LOCK_SHA_ENV: runtime._sha(lock)}):
                with self.assertRaisesRegex(ValueError, "sealed workflow freeze"):
                    self.owner(directory)
            self.assertFalse(owner.registry_root.exists())

    def test_registration_and_completed_evidence_tamper_are_rejected(self):
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            initial = self.start_idle(owner)
            registration = owner.registry_root / initial["workflow_id"] / "registration.json"
            value = runtime._read(registration)
            value["deadline_epoch"] += 1
            registration.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "registration changed"):
                owner.get_status({"workflow_id": initial["workflow_id"]})
        with temporary_workspace() as directory:
            owner = self.owner(directory)
            result = self.wait_terminal(owner, owner.start(self.arguments(calls=0))["workflow_id"])
            task = Path(result["evidence"]["directory"])
            (task / "report.md").write_text("Unsupported report", encoding="utf-8")
            rejected = owner.get_status({"workflow_id": result["workflow_id"]})
            self.assertEqual(rejected["status"], "failed")
            self.assertFalse(rejected["resumable"])


if __name__ == "__main__":
    unittest.main()
