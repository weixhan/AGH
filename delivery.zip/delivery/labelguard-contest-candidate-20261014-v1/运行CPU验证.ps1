param([string]$PythonExecutable = 'python')
$ErrorActionPreference = 'Stop'
$candidateRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$candidateCode = Join-Path $candidateRoot 'code\DefectResearcher-CPU-v1'
$candidateParent = Split-Path -Parent $candidateRoot
$candidateEvidence = Join-Path $candidateParent ('LabelGuard-verification-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
if (Test-Path -LiteralPath $candidateEvidence) { throw 'New evidence directory already exists.' }
Push-Location $candidateCode
try {
    & $PythonExecutable -I -S -B 'tools/migration_smoke_v1.py' --output $candidateEvidence
    if ($LASTEXITCODE -ne 0) { throw "CPU verification failed; preserved evidence: $candidateEvidence" }
    Write-Host "Evidence: $candidateEvidence"
} finally { Pop-Location }
