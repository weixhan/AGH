"""Verify YOLO labels and metadata against source annotations and split hashes."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from cableinspect_geometry import GEOMETRY_VERSION, annotation_to_hbb, coco_bbox_to_yolo, coco_bbox_to_rotated_corners


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def label_tree_sha256(dataset: Path, split: str) -> str:
    digest = hashlib.sha256()
    for path in sorted((dataset / "labels" / split).glob("*.txt")):
        digest.update(path.relative_to(dataset).as_posix().encode("utf-8") + b"\0")
        digest.update(path.read_bytes() + b"\0")
    return digest.hexdigest()


def check_dataset(dataset: Path, raw_root: Path, split_dir: Path) -> dict:
    dataset, raw_root, split_dir = dataset.resolve(), raw_root.resolve(), split_dir.resolve()
    manifest = json.loads((dataset / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("geometry_version") != GEOMETRY_VERSION:
        raise ValueError(f"Geometry version mismatch: {manifest.get('geometry_version')}")
    for name, digest in manifest["source_sha256"].items():
        if sha256_file(raw_root / name) != digest:
            raise ValueError(f"Source COCO hash changed: {name}")
    for name, digest in manifest["split_sha256"].items():
        if sha256_file(split_dir / name) != digest:
            raise ValueError(f"Split hash changed: {name}")
    records = {}
    for cable in ("cable_1", "cable_2", "cable_3"):
        data = json.loads((raw_root / f"{cable}.json").read_text(encoding="utf-8"))
        image_paths = {}
        for image in data["images"]:
            relative = image["file_name"].replace("\\", "/").replace("Cable_", "cable_")
            if image["id"] in image_paths or relative in records:
                raise ValueError(f"Duplicate COCO image ID/path: {relative}")
            image_paths[image["id"]] = relative
            records[relative] = {"image": image, "annotations": [], "source_json": f"{cable}.json"}
        for annotation in data["annotations"]:
            records[image_paths[annotation["image_id"]]]["annotations"].append(annotation)
    statistics, all_paths, all_stems = {}, set(), set()
    for split in ("train", "val", "test"):
        paths = [Path(line.strip()).resolve().relative_to(raw_root).as_posix()
                 for line in (split_dir / f"{split}.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
        if len(paths) != len(set(paths)) or all_paths.intersection(paths):
            raise ValueError(f"Duplicate paths within/across splits: {split}")
        all_paths.update(paths)
        stems = {Path(path).stem for path in paths}
        if len(stems) != len(paths) or all_stems.intersection(stems):
            raise ValueError(f"Duplicate flattened basename: {split}")
        all_stems.update(stems)
        for kind, extension in (("images", "*.png"), ("labels", "*.txt"), ("metadata", "*.json")):
            actual = {path.stem for path in (dataset / kind / split).glob(extension)}
            if actual != stems:
                raise ValueError(f"{split}/{kind} membership mismatch: missing={len(stems - actual)}, extra={len(actual - stems)}")
        if label_tree_sha256(dataset, split) != manifest["label_tree_sha256"][split]:
            raise ValueError(f"Label tree hash changed: {split}")
        counts = Counter()
        for relative in paths:
            record = records[relative]
            image = record["image"]
            width, height = image["width"], image["height"]
            stem = Path(relative).stem
            labels = [line.split() for line in (dataset / "labels" / split / f"{stem}.txt").read_text().splitlines() if line.strip()]
            metadata = json.loads((dataset / "metadata" / split / f"{stem}.json").read_text(encoding="utf-8"))
            image_expected = {"geometry_version": GEOMETRY_VERSION, "image": relative,
                              "width": width, "height": height, "image_id": image["id"], "source_json": record["source_json"]}
            if any(metadata.get(key) != value for key, value in image_expected.items()):
                raise ValueError(f"Metadata provenance/dimensions mismatch: {relative}")
            valid_annotations = []
            for annotation in record["annotations"]:
                box, clipped = annotation_to_hbb(annotation, width, height)
                counts["source_annotations"] += 1
                rotation = float(annotation.get("attributes", {}).get("rotation", 0))
                counts["nonzero_rotation_attributes"] += int(rotation != 0)
                counts["rotated_annotations"] += int(rotation % 360 != 0)
                if box is None:
                    counts["invalid_annotations"] += 1
                    continue
                counts["clipped_annotations"] += int(clipped)
                valid_annotations.append((annotation, box, clipped))
            if len(labels) != len(valid_annotations) or len(metadata["annotations"]) != len(valid_annotations):
                raise ValueError(f"Annotation count mismatch: {relative}")
            for label, item, (annotation, box, clipped) in zip(labels, metadata["annotations"], valid_annotations):
                attributes = annotation.get("attributes", {})
                rotation = float(attributes.get("rotation", 0))
                yolo_box, _ = coco_bbox_to_yolo(annotation["bbox"], width, height, rotation)
                if len(label) != 5 or int(label[0]) != annotation["category_id"] - 1:
                    raise ValueError(f"Malformed label/class: {relative}")
                values = [float(value) for value in label[1:]]
                if not all(math.isfinite(value) and 0 <= value <= 1 for value in values):
                    raise ValueError(f"Non-finite/out-of-range YOLO coordinate: {relative}")
                if max(abs(value - expected) for value, expected in zip(values, yolo_box)) > 5.1e-9:
                    raise ValueError(f"YOLO geometry differs from source: {relative}, annotation={annotation['id']}")
                expected = {
                    "geometry_version": GEOMETRY_VERSION, "source_json": record["source_json"],
                    "annotation_id": annotation["id"], "image_id": image["id"],
                    "category_id": annotation["category_id"],
                    "class": manifest["categories"][str(annotation["category_id"])],
                    "rotation": rotation, "original_bbox": annotation["bbox"],
                    "hbb_xyxy": list(box), "bbox_clipped": clipped,
                    "rotated_corners": coco_bbox_to_rotated_corners(annotation["bbox"], rotation),
                    "gradation": attributes.get("gradation"), "anomaly_id": attributes.get("anomaly_id"),
                }
                expected = json.loads(json.dumps(expected))
                if any(item.get(key) != value for key, value in expected.items()):
                    raise ValueError(f"Metadata content mismatch: {relative}, annotation={annotation['id']}")
            counts["images"] += 1
            counts["annotations"] += len(labels)
            counts["abnormal_images" if labels else "normal_images"] += 1
        statistics[split] = {key: counts[key] for key in manifest["counts"][split]}
        if statistics[split] != manifest["counts"][split]:
            raise ValueError(f"Manifest counts mismatch: {split}")
    excluded_file = split_dir / "excluded_buffer.txt"
    excluded = [Path(line.strip()).resolve().relative_to(raw_root).as_posix()
                for line in excluded_file.read_text(encoding="utf-8-sig").splitlines() if line.strip()] if excluded_file.exists() else []
    if len(excluded) != len(set(excluded)) or all_paths.intersection(excluded):
        raise ValueError("Buffer exclusions duplicate retained/excluded images")
    if all_paths.union(excluded) != set(records) or any(records[path]["annotations"] for path in excluded):
        raise ValueError("Splits + normal-only buffer do not cover source images")
    if len(excluded) != manifest["excluded_buffer_images"]:
        raise ValueError("Manifest buffer count mismatch")
    totals = Counter()
    for counts in statistics.values():
        totals.update(counts)
    if dict(totals) != manifest["totals"] or len(records) != manifest["raw_images"]:
        raise ValueError("Manifest global totals mismatch")
    return {"geometry_version": GEOMETRY_VERSION, "dataset": str(dataset), "counts": statistics,
            "excluded_buffer_images": len(excluded), "status": "passed"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=ROOT / "dataset" / "CableInspect_YOLO")
    parser.add_argument("--raw-root", type=Path, default=Path(r"E:\Datasets\线缆\CableInspect-AD"))
    parser.add_argument("--split-dir", type=Path, default=ROOT / "splits_anomaly_grouped")
    parser.add_argument("--output-json", type=Path)
    args = parser.parse_args()
    report = check_dataset(args.dataset, args.raw_root, args.split_dir)
    if args.output_json:
        args.output_json.parent.mkdir(parents=True, exist_ok=True)
        args.output_json.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
