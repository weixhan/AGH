# DefectResearcher CPU delivery bundle v1

This initial source bundle executes twelve frozen synthetic LabelGuard cases (4 normal, 4 real copy repairs, 4 refusals), thirty independent geometry fixtures and twelve saved-task crosschecks with Python's standard library.

Extract to a new path. Use Python 3.10 or newer, then run from the extracted root:

```powershell
python -I -S -B tools/migration_smoke_v1.py --output ../smoke-evidence-new
```

The output directory must be new and outside this immutable bundle. No package installation is needed. The smoke refuses model/GPU libraries, network calls and child processes. It checks the complete source manifest before and after execution.

Source and license provenance: `provenance.json`, `licenses/`, `agh-runtime-fixes.json`. Actual team details: `config/submission-team.json`. The source project's original README is preserved in `docs/source-project-README.md`; its historical output links refer to the original workspace and are outside this package.

Final reports, V12 evidence, AGH/Provider setup, full data/weights, GPU execution, other-computer validation and redistribution permissions remain pending. This ZIP is a local reviewable CPU milestone, not a final contest submission or a verified AGH installation.
